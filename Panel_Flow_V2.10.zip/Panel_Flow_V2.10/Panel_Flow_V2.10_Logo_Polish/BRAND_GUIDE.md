# Panel Flow brand assets (V2.10)

The supplied Panel Flow artwork remains the identity source. The V2.10 pass polishes its existing geometry rather than redesigning it: wave contours are smoothed into cubic Bézier curves, the circular emblem is rebuilt from mathematically concentric SVG arcs, and all icon variants use uniform scaling on consistent square artboards. Transparent negative space is preserved.

## Official palette

| Purpose | Color | Hex |
|---|---|---|
| Primary navy | Deep slate navy | `#24374F` |
| Primary accent red | Wave red on light surfaces | `#A03340` |
| Dark-mode red | Contrast-adjusted wave accent | `#D75A68` |
| Light-mark white | Soft white | `#F1F4F7` |
| App-icon background | Midnight navy | `#172A43` |

## Files

- `website/public/brand/panelflow-primary-light.svg` / `.png` — complete circular emblem and wordmark for light surfaces.
- `website/public/brand/panelflow-primary-dark.svg` / `.png` — complete emblem for dark surfaces.
- `website/public/brand/panelflow-wave-light.svg` / `.png` — standalone navy/red wave, transparent background.
- `website/public/brand/panelflow-wave-dark.svg` / `.png` — standalone white/red wave for dark surfaces.
- `website/public/brand/panelflow-app-icon.svg` / `.png` — square app tile with a mathematically circular medallion.
- `website/public/panelflow-mark.svg` — compact circular browser favicon.
- `website/public/apple-touch-icon.png` — 180px home-screen icon.
- `website/public/panel-flow-share.svg` / `.png` — 1200 × 630 social-sharing preview.

## Geometry and rendering rules

- The main emblem rings share one center and use exact SVG circle arcs; outer radius is 558 units and the red ring radius is 528 units.
- Wave art keeps its original `855:524` aspect ratio. Never set independent width and height values that change that ratio.
- Header, footer, hero, and sign-in mark containers use the same `855 / 524` CSS `aspect-ratio`.
- App and favicon marks are centered with a uniform scale; circular backgrounds remain circles rather than ellipses.
- SVG is the preferred web asset. PNG exports are provided for systems that require raster images.

## Website placement and responsive behavior

The responsive horizontal lockup is composed from the standalone wave SVG plus the live `PANEL FLOW` wordmark in the site header and footer. The homepage hero centerpiece and sign-in panel also use the wave mark. The full circular emblem remains available for larger brand placements and print assets.

At tablet/mobile widths the header mark and wordmark shrink while preserving the symbol's aspect ratio. The small tagline is hidden on the narrowest screens. The standalone symbol remains visible. The desktop sign-in action moves into the collapsible navigation on mobile so the logo, language switch, theme control, and menu do not compete for the same narrow row. Brand artwork stays left-to-right even when the surrounding website is Persian RTL.

## Usage rules

- Use the light SVG on pale surfaces and the dark SVG on dark surfaces.
- Prefer SVG for website/app placement; use PNG exports where an image-only workflow is required.
- Do not stretch, rotate, recolor, skew, or add effects to the logo.
- Leave clear space around the symbol. Do not place text or buttons over it.
- The site-wide UI accent/status palette is intentionally not globally recolored by this logo refinement.
