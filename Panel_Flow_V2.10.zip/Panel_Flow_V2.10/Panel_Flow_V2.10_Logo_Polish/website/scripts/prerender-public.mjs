import fs from 'node:fs';
import path from 'node:path';

const dist = path.resolve('dist');
const source = path.join(dist, 'index.html');
if (!fs.existsSync(source)) throw new Error('Vite index.html was not generated');
const html = fs.readFileSync(source, 'utf8');
const publicSite = (process.env.VITE_PUBLIC_SITE_URL || '').replace(/\/$/, '');
const homeTitle = 'Panel Flow — Find your next conversation';
const homeDescription = 'Discover thoughtful discussion panels and local hosts across cities in Iran. Find your next conversation with Panel Flow.';
let homeHtml = html
  .replace(/<title>[^<]*<\/title>/, `<title>${homeTitle}</title>`)
  .replace(/<meta name=\"description\" content=\"[^\"]*\"\s*\/>/, `<meta name=\"description\" content=\"${homeDescription}\" />`)
  .replace(/<meta property=\"og:title\" content=\"[^\"]*\"\s*\/>/, `<meta property=\"og:title\" content=\"${homeTitle}\" />`)
  .replace(/<meta property=\"og:description\" content=\"[^\"]*\"\s*\/>/, `<meta property=\"og:description\" content=\"${homeDescription}\" />`)
  .replace(/<meta property=\"og:url\"[^>]*\/?>/g, '')
  .replace(/<link rel=\"canonical\"[^>]*\/?>/g, '');
if (publicSite) homeHtml = homeHtml.replace('</head>', `<link rel=\"canonical\" href=\"${publicSite}/\" />\n  <meta property=\"og:url\" content=\"${publicSite}/\" />\n  </head>`);
fs.writeFileSync(source, homeHtml);
const pages = [
  { path: 'events', title: 'Upcoming panels | Panel Flow', description: 'Discover upcoming discussion panels and in-person gatherings across Iran.' },
  { path: 'cities', title: 'Cities & hosts | Panel Flow', description: 'Explore cities across Iran and discover the panels hosted in each city.' },
  { path: 'calendar', title: 'Panel calendar | Panel Flow', description: 'Browse upcoming Panel Flow sessions in the Persian calendar.' },
  { path: 'community', title: 'Panel Flow community', description: 'Explore challenges, ideas, and conversations from the Panel Flow community.' },
  { path: 'about', title: 'About Panel Flow', description: 'The story behind Panel Flow: a community built around meaningful conversations.' },
];
for (const page of pages) {
  const canonical = publicSite ? `${publicSite}/${page.path}` : `/${page.path}`;
  let pageHtml = homeHtml
    .replace(/<title>[^<]*<\/title>/, `<title>${page.title}</title>`)
    .replace(/<meta name="description" content="[^"]*"\s*\/>/, `<meta name="description" content="${page.description}" />`)
    .replace(/<meta property="og:url"[^>]*\/?>/g, '')
    .replace(/<link rel="canonical"[^>]*\/?>/g, '')
    .replace(/<meta property="og:title"[^>]*\/?>/g, '')
    .replace(/<meta property="og:description"[^>]*\/?>/g, '');
  const routeSeoTags = `<link rel="canonical" href="${canonical}" />\n  <meta property="og:title" content="${page.title}" />\n  <meta property="og:description" content="${page.description}" />${publicSite ? `\n  <meta property="og:url" content="${canonical}" />` : ''}`;
  pageHtml = pageHtml.replace('</head>', `${routeSeoTags}\n  </head>`);
  const target = path.join(dist, page.path, 'index.html');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, pageHtml);
}
const privatePages = [
  { path: 'sign-in', title: 'Sign in | Panel Flow' },
  { path: 'me', title: 'My profile | Panel Flow' },
  { path: 'dashboard', title: 'My dashboard | Panel Flow' },
  { path: 'my-bookings', title: 'My bookings | Panel Flow' },
  { path: 'my-organizations', title: 'My organizations | Panel Flow' },
  { path: 'become-a-host', title: 'Become a host | Panel Flow' },
  { path: 'host-application', title: 'Host application | Panel Flow' },
  { path: 'saved', title: 'Saved panels | Panel Flow' },
  { path: 'workspace', title: 'Staff workspace | Panel Flow' },
];
for (const page of privatePages) {
  const privateHtml = homeHtml
    .replace(/<title>[^<]*<\/title>/, `<title>${page.title}</title>`)
    .replace(/<meta name=\"robots\" content=\"[^\"]*\"\s*\/>/, '<meta name=\"robots\" content=\"noindex,nofollow\" />')
    .replace(/<link rel=\"canonical\" href=\"[^\"]*\"\s*\/>/, '');
  const target = path.join(dist, page.path, 'index.html');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, privateHtml);
}
console.log(`Prerendered ${pages.length} public and ${privatePages.length} private route shells.`);
