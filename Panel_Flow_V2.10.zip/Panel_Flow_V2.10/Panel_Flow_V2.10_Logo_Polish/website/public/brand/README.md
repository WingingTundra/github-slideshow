# Panel Flow logo assets

All logo assets in this folder are generated from one cleaned vector master. Circular outlines use concentric mathematical SVG arcs; symbol variants preserve the original wave aspect ratio and are uniformly scaled.

- `panelflow-primary-light.svg` / `.png`: complete circular emblem for light backgrounds.
- `panelflow-primary-dark.svg` / `.png`: complete emblem for dark backgrounds.
- `panelflow-wave-light.svg` / `.png`: horizontal wave symbol for light backgrounds.
- `panelflow-wave-dark.svg` / `.png`: horizontal wave symbol for dark backgrounds.
- `panelflow-app-icon.svg` / `.png`: square app tile containing a true circular medallion.
- `/panelflow-mark.svg`: small circular browser favicon.
- `/apple-touch-icon.png`: 180px app icon export.
- `/panel-flow-share.svg` / `.png`: 1200×630 social sharing card.

Source palette: navy `#24374F`, red `#A03340`, light `#F1F4F7`.
