export const API_BASE = (import.meta.env.VITE_API_BASE || '/api/v1').replace(/\/$/, '');
export const TOKEN_KEY = 'pf_access_token';

export type ApiError = Error & { status?: number; code?: string; retryable?: boolean };

const friendlyErrorByStatus: Record<number, string> = {
  400: 'Some of the information is invalid. Please check the fields and try again.',
  401: 'Your session has expired. Please sign in again.',
  403: 'You do not have permission to perform this action.',
  404: 'This item is no longer available.',
  409: 'This item has changed. Refresh the page and try again.',
  413: 'This file is too large. Choose a smaller file and try again.',
  422: 'Please review the information and correct the highlighted fields.',
  429: 'Too many requests. Please wait a moment and try again.',
  500: 'The server encountered a problem. Please try again shortly.',
  502: 'The service is temporarily unavailable. Please try again shortly.',
  503: 'The service is temporarily unavailable. Please try again shortly.',
  504: 'The request took too long. Please try again.',
};

const friendlyErrorByCode: Record<string, string> = {
  INVALID_TOKEN: 'Your session is no longer valid. Please sign in again.',
  TOKEN_EXPIRED: 'Your session has expired. Please sign in again.',
  SESSION_EXPIRED: 'Your session has expired. Please sign in again.',
  AUTH_REQUIRED: 'Please sign in to continue.',
  EVENT_NOT_FOUND: 'This panel is no longer available.',
  EVENT_NOT_OPEN: 'Registration for this panel is currently closed.',
  EVENT_FULL: 'This panel is fully booked.',
  RECEIPT_CHANGED: 'The payment receipt has changed. Refresh the payment status and try again.',
  HOST_SUBSCRIPTION_INACTIVE: 'This host account does not currently have an active subscription.',
};

// Coalesce identical in-flight GETs only. This cuts duplicate reads when
// sibling components mount together without caching stale data or deduplicating
// any mutation (especially bookings, payments, follows, or reviews).
const inFlightGetRequests = new Map<string, Promise<unknown>>();
const publicGetCache = new Map<string, { expiresAt: number; value: unknown }>();
let apiCacheGeneration = 0;
const PUBLIC_GET_TTL_MS = 10_000;
const PUBLIC_GET_CACHE_LIMIT = 80;
export const PLATFORM_TIME_ZONE = 'Asia/Tehran';

export function clearApiCache() {
  apiCacheGeneration += 1;
  publicGetCache.clear();
  inFlightGetRequests.clear();
}

function isCacheablePublicGet(path: string, method: string, options: RequestInit, token?: string | null) {
  return method === 'GET' && !token && !options.signal && options.cache !== 'no-store'
    && !path.startsWith('/me/') && !path.startsWith('/staff/');
}

export async function api<T>(path: string, options: RequestInit = {}, token?: string | null): Promise<T> {
  const method = (options.method || 'GET').toUpperCase();
  if (method !== 'GET') clearApiCache();
  if (method !== 'GET' || options.signal) return performApiRequest<T>(path, options, token);
  const headerKey = Array.from(new Headers(options.headers || {}).entries()).sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${key}:${value}`).join('|');
  const requestKey = `${token || 'anonymous'}\u0000${path}\u0000${options.cache || ''}\u0000${headerKey}`;
  const cacheable = isCacheablePublicGet(path, method, options, token);
  if (cacheable) {
    const cached = publicGetCache.get(requestKey);
    if (cached && cached.expiresAt > Date.now()) return cached.value as T;
    if (cached) publicGetCache.delete(requestKey);
  }
  const existing = inFlightGetRequests.get(requestKey);
  if (existing) return existing as Promise<T>;
  const generationAtStart = apiCacheGeneration;
  const request = performApiRequest<T>(path, options, token);
  inFlightGetRequests.set(requestKey, request);
  try {
    const result = await request;
    if (cacheable && generationAtStart === apiCacheGeneration) {
      if (publicGetCache.size >= PUBLIC_GET_CACHE_LIMIT) {
        const oldestKey = publicGetCache.keys().next().value;
        if (oldestKey) publicGetCache.delete(oldestKey);
      }
      publicGetCache.set(requestKey, { expiresAt: Date.now() + PUBLIC_GET_TTL_MS, value: result });
    }
    return result;
  } finally { if (inFlightGetRequests.get(requestKey) === request) inFlightGetRequests.delete(requestKey); }
}

async function performApiRequest<T>(path: string, options: RequestInit, token?: string | null): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (token) headers.set('Authorization', `Bearer ${token}`);
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  headers.set('Accept', 'application/json');
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, { ...options, headers });
  } catch (cause) {
    if (cause instanceof DOMException && cause.name === 'AbortError') throw cause;
    const message = typeof navigator !== 'undefined' && navigator.onLine === false
      ? 'You appear to be offline. Check your connection and try again.'
      : 'Panel Flow could not reach the service. Check your connection and try again.';
    const error = new Error(message) as ApiError;
    error.retryable = true;
    throw error;
  }
  if (!response.ok) {
    let payload: any = null;
    try { payload = await response.json(); } catch { /* A proxy or gateway may return an empty/non-JSON response. */ }
    const detail = payload?.detail;
    const code = (typeof detail === 'object' && detail !== null ? detail.code : null) || payload?.code;
    const serverMessage = (typeof detail === 'object' && detail !== null ? detail.message : detail)
      || payload?.message;
    const message = (typeof code === 'string' && friendlyErrorByCode[code])
      || (typeof serverMessage === 'string' && serverMessage.trim())
      || friendlyErrorByStatus[response.status]
      || 'The request could not be completed. Please try again.';
    const error = new Error(message) as ApiError;
    error.status = response.status;
    error.code = typeof code === 'string' ? code : undefined;
    error.retryable = response.status === 408 || response.status === 429 || response.status >= 500;
    throw error;
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export function formatMoney(value: number | string | null | undefined, locale = 'en'): string {
  const amount = Number(value || 0);
  const formatted = new Intl.NumberFormat(locale === 'fa' ? 'fa-IR' : 'en-US').format(amount);
  return `${formatted} ${locale === 'fa' ? 'تومان' : 'Toman'}`;
}

export function formatDate(value?: string | null, locale = 'en'): string {
  if (!value) return '—';
  // Backend DateTime columns intentionally remain UTC-naive for compatibility.
  // Treat a timestamp without an explicit offset as UTC, never as the visitor's zone.
  const hasExplicitZone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(value);
  const date = new Date(hasExplicitZone ? value : `${value.replace(' ', 'T')}Z`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(locale === 'fa' ? 'fa-IR' : 'en-US', {
    year: 'numeric', month: 'short', day: 'numeric', timeZone: PLATFORM_TIME_ZONE,
  }).format(date);
}

export function statusLabel(status: string, locale: string): string {
  const en: Record<string, string> = {
    initiated: 'Started', pending_payment: 'Awaiting payment', pending_verification: 'Receipt review',
    confirmed: 'Confirmed', cancelled: 'Cancelled', rejected: 'Payment rejected', expired: 'Expired', waitlisted: 'Waitlisted',
    draft: 'Draft', published: 'Published', completed: 'Completed', postponed: 'Postponed',
  };
  const fa: Record<string, string> = {
    initiated: 'شروع‌شده', pending_payment: 'در انتظار پرداخت', pending_verification: 'در انتظار بررسی رسید',
    confirmed: 'تأییدشده', cancelled: 'لغوشده', rejected: 'رسید تأیید نشد', expired: 'منقضی‌شده', waitlisted: 'فهرست انتظار',
    draft: 'پیش‌نویس', published: 'منتشرشده', completed: 'برگزارشده', postponed: 'به تعویق افتاده',
  };
  return (locale === 'fa' ? fa : en)[status] || status;
}
