import { useMemo, useState } from 'react';
import { CalendarDays, ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

type CalendarEvent = { id: number; title: string; date_iso?: string | null; day: string; date: string; start_time: string; city: string; venue: string };
const weekDaysFa = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنج‌شنبه','جمعه'];
const weekDaysEn = ['Sat','Sun','Mon','Tue','Wed','Thu','Fri'];
const PLATFORM_TIME_ZONE = 'Asia/Tehran';

// Calendar days are date-only values. Anchor them at UTC noon to avoid browser
// timezone shifts, and derive "today" explicitly from the Tehran wall clock.
const dateAtUtcNoon = (year: number, monthIndex: number, day: number) =>
  new Date(Date.UTC(year, monthIndex, day, 12));
const todayInTehran = () => {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: PLATFORM_TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return dateAtUtcNoon(Number(values.year), Number(values.month) - 1, Number(values.day));
};
const partsFor = (date: Date) => {
  const parts = new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', {
    timeZone: 'UTC', year: 'numeric', month: 'numeric', day: 'numeric',
  }).formatToParts(date);
  return {
    year: Number(parts.find(p => p.type === 'year')?.value),
    month: Number(parts.find(p => p.type === 'month')?.value),
    day: Number(parts.find(p => p.type === 'day')?.value),
  };
};
const monthStart = (anchor: Date) => {
  const target = partsFor(anchor);
  for (let delta = -35; delta <= 35; delta++) {
    const candidate = dateAtUtcNoon(anchor.getUTCFullYear(), anchor.getUTCMonth(), anchor.getUTCDate() + delta);
    const p = partsFor(candidate);
    if (p.year === target.year && p.month === target.month && p.day === 1) return candidate;
  }
  return dateAtUtcNoon(anchor.getUTCFullYear(), anchor.getUTCMonth(), 1);
};
const keyFor = (date: Date) => { const p = partsFor(date); return `${p.year}-${p.month}-${p.day}`; };
const toFa = (value: number) => value.toLocaleString('fa-IR');

export function PersianCalendar({ events, locale }: { events: CalendarEvent[]; locale: 'en' | 'fa' }) {
  const [anchor, setAnchor] = useState(() => todayInTehran());
  const [selected, setSelected] = useState(() => keyFor(todayInTehran()));
  const start = useMemo(() => monthStart(anchor), [anchor]);
  const current = partsFor(start);
  const days = useMemo(() => {
    const result: { date: Date; key: string; day: number }[] = [];
    for (let i = 0; i < 32; i++) {
      const d = dateAtUtcNoon(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate() + i);
      const p = partsFor(d);
      if (i > 0 && (p.year !== current.year || p.month !== current.month)) break;
      result.push({ date: d, key: `${p.year}-${p.month}-${p.day}`, day: p.day });
    }
    return result;
  }, [start, current.year, current.month]);
  const grouped = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const event of events) {
      if (!event.date_iso) continue;
      const [y,m,d] = event.date_iso.split('-').map(Number);
      if (!y || !m || !d) continue;
      const key = keyFor(dateAtUtcNoon(y, m - 1, d));
      map.set(key, [...(map.get(key) || []), event]);
    }
    return map;
  }, [events]);
  const offset = (start.getUTCDay() + 1) % 7;
  const selectedEvents = grouped.get(selected) || [];
  const monthLabel = new Intl.DateTimeFormat(locale === 'fa' ? 'fa-IR-u-ca-persian' : 'en-US-u-ca-persian', {
    year: 'numeric', month: 'long', timeZone: 'UTC',
  }).format(start);
  const shift = (amount: number) => {
    const next = dateAtUtcNoon(anchor.getUTCFullYear(), anchor.getUTCMonth(), anchor.getUTCDate() + amount);
    setAnchor(next); setSelected('');
  };
  const todayKey = keyFor(todayInTehran());
  return <div className="calendar-shell" dir={locale === 'fa' ? 'rtl' : 'ltr'}>
    <div className="calendar-main">
      <div className="calendar-head"><div><span className="eyebrow"><CalendarDays size={14}/>{locale === 'fa' ? 'تقویم پنل‌ها' : 'PANEL CALENDAR'}</span><h2>{monthLabel}</h2></div><div className="calendar-nav"><button onClick={() => { setAnchor(todayInTehran()); setSelected(todayKey); }}>{locale === 'fa' ? 'امروز' : 'Today'}</button><button aria-label="Previous month" onClick={() => shift(-35)}><ChevronRight size={17}/></button><button aria-label="Next month" onClick={() => shift(35)}><ChevronLeft size={17}/></button></div></div>
      <div className="calendar-weekdays">{(locale === 'fa' ? weekDaysFa : weekDaysEn).map(day => <span key={day}>{day}</span>)}</div>
      <div className="calendar-days">{Array.from({length:offset}).map((_,i)=><span className="calendar-blank" key={`blank-${i}`}/>)}{days.map(day => { const count = grouped.get(day.key)?.length || 0; return <button key={day.key} className={`${selected===day.key?'selected':''} ${todayKey===day.key?'today':''} ${count?'has-event':''}`} onClick={()=>setSelected(day.key)}><span>{locale === 'fa' ? toFa(day.day) : day.day}</span>{count>0 && <i>{count}</i>}</button>; })}</div>
    </div>
    <aside className="calendar-agenda"><div className="agenda-heading"><strong>{selected ? (locale === 'fa' ? `رویدادهای ${selected.split('-')[2]}` : `Events on day ${selected.split('-')[2]}`) : (locale === 'fa' ? 'یک روز را انتخاب کنید' : 'Select a day')}</strong><span>{selectedEvents.length}</span></div>
      {selectedEvents.length ? selectedEvents.map(event => <Link className="agenda-event" to={`/events/${event.id}`} key={event.id}><span className="agenda-time">{event.start_time}</span><strong>{event.title}</strong><small><MapPin size={12}/>{event.city} · {event.venue}</small></Link>) : <p className="agenda-empty">{locale === 'fa' ? 'برای روز انتخاب‌شده پنل زمان‌بندی‌شده‌ای ثبت نشده است.' : 'No scheduled panels for this date.'}</p>}
    </aside>
  </div>;
}
