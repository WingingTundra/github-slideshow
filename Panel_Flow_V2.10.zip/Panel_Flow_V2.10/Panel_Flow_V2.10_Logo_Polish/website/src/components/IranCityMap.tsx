import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Building2, CalendarDays, MapPin, Activity, CheckCircle2 } from 'lucide-react';
import type { CityData } from '../types';

// A deliberately simplified Iran silhouette; city markers are projected from
// the database's real latitude/longitude coordinates, never index positions.
const outline: [number, number][] = [
  [44.0,39.6],[45.2,38.7],[45.7,37.4],[46.0,36.2],[45.4,35.0],[46.2,33.8],
  [47.0,32.1],[47.7,30.8],[48.2,29.4],[49.2,27.8],[50.3,26.2],[52.2,25.2],
  [54.0,25.3],[55.5,26.0],[57.0,25.8],[58.3,26.2],[59.6,26.4],[60.8,25.8],
  [61.4,27.2],[61.0,28.8],[60.6,30.1],[61.4,31.6],[61.1,33.0],[60.5,34.1],
  [60.8,35.2],[60.0,36.1],[59.0,36.7],[58.1,37.1],[57.0,37.8],[55.5,38.1],
  [54.0,38.5],[52.7,37.9],[51.0,37.7],[49.6,38.1],[48.4,38.8],[47.0,39.3],[45.6,39.8]
];
const project = ([lon, lat]: [number, number]) => ({ x: 34 + ((lon - 43) / 21) * 570, y: 28 + ((40.5 - lat) / 16.5) * 440 });
const topicNames: Record<string, [string, string]> = {
  philosophy: ['فلسفه','Philosophy'], psychology: ['روان‌شناسی','Psychology'], technology: ['فناوری','Technology'],
  science: ['علم','Science'], literature: ['ادبیات','Literature'], economics: ['اقتصاد','Economics'],
  art: ['هنر','Art'], education: ['آموزش','Education'], politics: ['سیاست','Politics'],
  business: ['کسب‌وکار','Business'], culture: ['فرهنگ','Culture'], history: ['تاریخ','History'],
};

export function IranCityMap({ cities, locale, selectedSlug, compact = false }: {
  cities: CityData[]; locale: 'en' | 'fa'; selectedSlug?: string; compact?: boolean;
}) {
  const [localSelected, setLocalSelected] = useState<string | undefined>(selectedSlug);
  const points = useMemo(() => outline.map(project).map(p => `${p.x},${p.y}`).join(' '), []);
  const activeSlug = selectedSlug ?? localSelected;
  const selected = cities.find(city => city.slug === activeSlug) || cities.find(city => city.is_founding_city) || cities[0];
  const name = (city: CityData) => locale === 'fa' ? city.name_fa : city.name_en;
  const openCity = (city: CityData) => setLocalSelected(city.slug);
  return <div className={`iran-map-card${compact ? ' compact' : ''}`}>
    <div className="iran-map-topline"><span className="map-kicker">{locale === 'fa' ? 'شبکه سراسری پنل فلو' : 'PANEL FLOW · NATIONAL NETWORK'}</span><span className="map-city-total">{cities.length} {locale === 'fa' ? 'شهر فعال' : 'active cities'}</span></div>
    <svg className="iran-map-svg" viewBox="0 0 640 500" role="group" aria-label={locale === 'fa' ? 'نقشه تعاملی شهرهای فعال ایران' : 'Interactive map of active Iranian cities'}>
      <defs>
        <linearGradient id="iranFill" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--map-fill-start)" stopOpacity=".38"/><stop offset="1" stopColor="var(--map-fill-end)" stopOpacity=".15"/></linearGradient>
        <pattern id="iranDots" width="16" height="16" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" fill="currentColor" opacity=".16"/></pattern>
      </defs>
      <path d={`M ${points.replaceAll(' ', ' L ')} Z`} fill="url(#iranFill)" stroke="var(--map-outline)" strokeWidth="2.2" strokeLinejoin="round" />
      <path d={`M ${points.replaceAll(' ', ' L ')} Z`} fill="url(#iranDots)" />
      <path d="M70 105 Q160 150 205 210 T335 290 T535 365" fill="none" stroke="var(--map-route)" strokeDasharray="5 8" />
      {cities.map(city => {
        const p = project([city.longitude, city.latitude]);
        const isSelected = selected?.slug === city.slug;
        const activity = city.upcoming_event_count ?? city.event_count;
        return <g key={city.id} className={`iran-map-marker${isSelected ? ' selected' : ''}${activity > 0 ? ' has-events' : ''}${city.is_founding_city ? ' founding-city' : ''}`}
          transform={`translate(${p.x} ${p.y})`} role="button" tabIndex={0} aria-pressed={isSelected}
          aria-label={`${name(city)}. ${activity} ${locale === 'fa' ? 'پنل پیش‌رو' : 'upcoming panels'}, ${city.organization_count || 0} ${locale === 'fa' ? 'سازمان فعال' : 'active organizations'}`}
          onClick={() => openCity(city)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openCity(city); } }}>
          <title>{name(city)} · {activity} {locale === 'fa' ? 'پنل پیش‌رو' : 'upcoming panels'}</title>
          <circle className="marker-halo" r={isSelected ? 15 : 10} />
          <circle className="marker-core" r={isSelected ? 6 : 4.5} />
          {city.is_founding_city && <g className="founding-city-label"><rect x="10" y="-27" width="96" height="17" rx="8"/><text x="58" y="-15">{locale === 'fa' ? 'شهر بنیان‌گذار' : 'FOUNDING CITY'}</text></g>}
        </g>;
      })}
      <text x="38" y="478" className="map-caption">IRAN · {locale === 'fa' ? 'موقعیت‌ها بر پایه مختصات جغرافیایی' : 'REAL CITY COORDINATES · SIMPLIFIED OUTLINE'}</text>
    </svg>
    {selected && <div className="map-selected-city" aria-live="polite">
      <div className="map-selected-heading"><span className="city-directory-pin"><MapPin size={17}/></span><div><strong>{name(selected)}</strong><small>{locale === 'fa' ? selected.province_fa : selected.province_en}</small></div><Link to={`/cities/${selected.slug}`} className="text-link">{locale === 'fa' ? 'کاوش شهر' : 'Explore city'}<ArrowUpRight size={15}/></Link></div>
      <div className="map-selected-stats"><span><CalendarDays size={15}/><b>{selected.upcoming_event_count ?? selected.event_count}</b><small>{locale === 'fa' ? 'پنل پیش‌رو' : 'upcoming panels'}</small></span><span><Building2 size={15}/><b>{selected.organization_count || 0}</b><small>{locale === 'fa' ? 'سازمان فعال' : 'active organizations'}</small></span><span><CheckCircle2 size={15}/><b>{selected.completed_event_count || 0}</b><small>{locale === 'fa' ? 'پنل‌های برگزارشده' : 'completed panels'}</small></span><span><Activity size={15}/><b>{selected.recent_activity_count || 0}</b><small>{locale === 'fa' ? 'به‌روزرسانی پنل‌ها · ۳۰ روز' : 'panel updates · 30 days'}</small></span></div>{(selected.topic_tags || []).length > 0 && <div className="map-city-topics"><strong>{locale === 'fa' ? 'موضوع‌های این شهر' : 'Topics in this city'}</strong><div>{(selected.topic_tags || []).slice(0,5).map(topic=><span key={topic}>{topicNames[topic]?.[locale === 'fa' ? 0 : 1] || topic.replaceAll('_',' ')}</span>)}</div></div>}
    </div>}
    {!compact && <div className="map-legend"><span><i className="legend-dot live" />{locale === 'fa' ? 'دارای پنل منتشرشده' : 'Panels published'}</span><span><i className="legend-dot empty" />{locale === 'fa' ? 'شهر فعال' : 'Active city'}</span></div>}
  </div>;
}
