import { createContext, lazy, Suspense, useCallback, useContext, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link, NavLink, Navigate, Route, Routes, useNavigate, useParams, useLocation } from 'react-router-dom';
import {
  ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, Award, Bookmark, CalendarDays, Check, MapPin,
  CheckCircle2, ChevronDown, CircleHelp, Clock3, Compass, CreditCard,
  ExternalLink, FileImage, FileText, Globe2, Heart, Instagram, Lightbulb, LoaderCircle, LockKeyhole,
  LogOut, Menu, MessageCircle, MessageSquare, Minus, Plus, Save, Search, ShieldCheck, Sparkles, Ticket,
  Trophy, UserRound, Users, Wallet, X, Zap, Moon, Sun, Share2, ImageDown, CalendarPlus, ListOrdered, QrCode,
} from 'lucide-react';
import { useAuth } from './auth';
import { API_BASE, api, formatDate, formatMoney, statusLabel } from './api';
import { copy } from './i18n';
import type { CityData } from './types';
const IranCityMap = lazy(() => import('./components/IranCityMap').then(module => ({ default: module.IranCityMap })));
const PersianCalendar = lazy(() => import('./components/PersianCalendar').then(module => ({ default: module.PersianCalendar })));

type Locale = 'en' | 'fa';
type Theme = 'light' | 'dark';

function readStoredTheme(): Theme {
  try { const value = localStorage.getItem('pf_theme'); if (value === 'light' || value === 'dark') return value; }
  catch { /* Fall through to the operating-system preference. */ }
  try { return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark'; }
  catch { return 'dark'; }
}
function persistTheme(value: Theme) { try { localStorage.setItem('pf_theme', value); } catch { /* In-memory theme still works when storage is blocked. */ } }

function readStoredLocale(): Locale {
  try {
    const value = localStorage.getItem('pf_locale');
    return value === 'fa' || value === 'en' ? value : 'en';
  } catch {
    return 'en';
  }
}

function persistLocale(value: Locale) {
  try { localStorage.setItem('pf_locale', value); } catch { /* Storage can be disabled; keep the in-memory preference. */ }
}

type LanguageContextValue = { locale: Locale; setLocale: (locale: Locale) => void; t: typeof copy.en };
type ThemeContextValue = { theme: Theme; setTheme: (theme: Theme) => void };
type SavedEventsContextValue = { ids: ReadonlySet<number>; toggle: (eventId: number, isSaved: boolean) => Promise<void> };
const SavedEventsContext = createContext<SavedEventsContextValue | null>(null);
function useSavedEvents() { const value = useContext(SavedEventsContext); if (!value) throw new Error('Saved events provider missing'); return value; }
const ThemeContext = createContext<ThemeContextValue | null>(null);
function useTheme() { const value = useContext(ThemeContext); if (!value) throw new Error('Theme provider missing'); return value; }
const LanguageContext = createContext<LanguageContextValue | null>(null);
function useLanguage() { const value = useContext(LanguageContext); if (!value) throw new Error('Language provider missing'); return value; }

type EventData = {
  id: number; volume: string; title: string; language?: string | null; description?: string | null;
  day: string; date: string; date_iso?: string | null; start_time: string; end_time?: string | null; venue: string;
  address?: string | null; map_url?: string | null; city: string; capacity: number; price_per_person: number;
  price_without_cafe_order?: number | null; status: string; registration_open: boolean; availability_label?: string;
  remaining_seats?: number | null; filling_soon?: boolean; waitlist_enabled?: boolean; host_name?: string | null; city_id?: number | null;
  event_type?: 'physical' | 'online' | 'hybrid'; organization_id?: number | null; brand_id?: number | null;
  organization?: { id:number; slug:string; name:string; is_platform_founder?:boolean } | null;
  brand?: { id:number; slug:string; name:string } | null; meeting_platform?: string | null;
  topic_tags?: string[]; agenda_items?: string[]; discussion_questions?: string[];
  cover_image_url?: string | null; cover_image_thumb_url?: string | null; is_postponed?: boolean; postponement_note?: string | null;
  discussion_series?: { id:number; slug:string; title:string; position:number } | null;
};
type Booking = {
  id: number; event_id: number; event_title: string; event_day: string; event_date: string; event_start_time: string;
  event_end_time?: string | null; event_venue: string; event_city: string; participant_count: number; total_amount: number;
  status: string; created_at?: string; confirmed_at?: string | null; cancelled_at?: string | null; expires_at?: string | null;
  payment_status?: string | null; receipt_submitted?: boolean; discount_amount?: number; discount_code?: string | null;
  event_date_iso?: string | null; event_type?: 'physical' | 'online' | 'hybrid';
};

type ApiPage<T> = { items: T[]; total: number };
const TOPIC_LABELS: Record<string, { en: string; fa: string }> = {
  philosophy: { en: 'Philosophy', fa: 'فلسفه' }, psychology: { en: 'Psychology', fa: 'روان‌شناسی' },
  technology: { en: 'Technology', fa: 'فناوری' }, science: { en: 'Science', fa: 'علم' },
  literature: { en: 'Literature', fa: 'ادبیات' }, economics: { en: 'Economics', fa: 'اقتصاد' },
  art: { en: 'Art', fa: 'هنر' }, education: { en: 'Education', fa: 'آموزش' },
  politics: { en: 'Politics', fa: 'سیاست' }, business: { en: 'Business', fa: 'کسب‌وکار' },
  culture: { en: 'Culture', fa: 'فرهنگ' }, history: { en: 'History', fa: 'تاریخ' },
};

function escapeIcs(value: string) {
  return value.replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/\r/g, '').replace(/,/g, '\\,').replace(/;/g, '\\;');
}

function tehranDateTimeUtc(dateIso: string, timeValue: string) {
  const dateParts = dateIso.split('-').map(Number);
  const timeParts = /^(\d{1,2}):(\d{2})/.exec(timeValue || '10:00');
  if (dateParts.length !== 3 || dateParts.some(Number.isNaN) || !timeParts) return null;
  const [year, month, day] = dateParts;
  const hours = Number(timeParts[1]); const minutes = Number(timeParts[2]);
  if (month < 1 || month > 12 || day < 1 || day > 31 || hours > 23 || minutes > 59) return null;
  // Convert the Tehran wall-clock date/time through the IANA zone database.
  const calendarDay = new Date(Date.UTC(year, month - 1, day));
  if (calendarDay.getUTCFullYear() !== year || calendarDay.getUTCMonth() !== month - 1 || calendarDay.getUTCDate() !== day) return null;
  // Convert a Tehran wall-clock value using the browser's IANA timezone database,
  // rather than assuming a fixed offset or the visitor's local timezone.
  const targetAsUtc = Date.UTC(year, month - 1, day, hours, minutes);
  let guess = targetAsUtc;
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Tehran', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  });
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const parts = Object.fromEntries(formatter.formatToParts(new Date(guess)).map(part => [part.type, part.value]));
    const localAsUtc = Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), Number(parts.hour), Number(parts.minute));
    const correction = targetAsUtc - localAsUtc;
    guess += correction;
    if (correction === 0) break;
  }
  return new Date(guess);
}

function icsTimestamp(value: Date) {
  return value.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
}

function downloadCalendarEvent(booking: Booking) {
  if (!booking.event_date_iso) return false;
  const start = tehranDateTimeUtc(booking.event_date_iso, booking.event_start_time);
  if (!start) return false;
  const end = booking.event_end_time ? tehranDateTimeUtc(booking.event_date_iso, booking.event_end_time) : new Date(start.getTime() + 60 * 60_000);
  const safeEnd = end && end > start ? end : new Date(start.getTime() + 60 * 60_000);
  const lines = [
    'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Panel Flow//Member Calendar//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Panel Flow',
    'BEGIN:VEVENT', `UID:panel-flow-booking-${booking.id}@panelflow`, `DTSTAMP:${icsTimestamp(new Date())}`,
    `DTSTART:${icsTimestamp(start)}`, `DTEND:${icsTimestamp(safeEnd)}`,
    `SUMMARY:${escapeIcs(booking.event_title)}`,
    `LOCATION:${escapeIcs([booking.event_venue, booking.event_city].filter(Boolean).join(', '))}`,
    `DESCRIPTION:${escapeIcs(`Panel Flow · ${booking.participant_count} participant(s) · ${booking.event_type || 'panel'}`)}`,
    'END:VEVENT', 'END:VCALENDAR', '',
  ];
  const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
  anchor.href = url; anchor.download = `panel-flow-${booking.id}.ics`; anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
  return true;
}

function wrapCanvasText(ctx: CanvasRenderingContext2D, value: string, maxWidth: number) {
  const words = value.trim().split(/\s+/); const rows: string[] = []; let line = '';
  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (line && ctx.measureText(candidate).width > maxWidth) { rows.push(line); line = word; }
    else line = candidate;
  }
  if (line) rows.push(line);
  return rows.slice(0, 3);
}

async function createEventShareImage(event: EventData, locale: Locale): Promise<Blob> {
  if (document.fonts?.ready) await document.fonts.ready;
  const canvas = document.createElement('canvas'); canvas.width = 1200; canvas.height = 630;
  const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('Your browser cannot create the share image.');
  const bg = ctx.createLinearGradient(0, 0, 1200, 630); bg.addColorStop(0, '#101a31'); bg.addColorStop(.58, '#203c66'); bg.addColorStop(1, '#312e48');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, 1200, 630);
  const glow = ctx.createRadialGradient(1010, 40, 20, 1010, 40, 500); glow.addColorStop(0, 'rgba(254,133,0,.28)'); glow.addColorStop(1, 'rgba(254,133,0,0)');
  ctx.fillStyle = glow; ctx.fillRect(600, 0, 600, 500);
  ctx.strokeStyle = 'rgba(255,255,255,.09)'; ctx.lineWidth = 1;
  for (let x = 45; x < 1200; x += 60) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 630); ctx.stroke(); }
  for (let y = 35; y < 630; y += 60) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(1200, y); ctx.stroke(); }
  ctx.fillStyle = '#fe8500'; ctx.fillRect(74, 70, 8, 42);
  ctx.direction = 'ltr'; ctx.textAlign = 'left'; ctx.fillStyle = '#f6f8fc'; ctx.font = '800 30px Manrope, DM Sans, sans-serif'; ctx.fillText('panel flow', 104, 104);
  ctx.fillStyle = 'rgba(230,238,255,.74)'; ctx.font = '700 16px DM Sans, sans-serif'; ctx.fillText('MEET  ·  DISCUSS  ·  GROW', 104, 137);
  const fa = locale === 'fa'; ctx.direction = fa ? 'rtl' : 'ltr'; ctx.textAlign = fa ? 'right' : 'left';
  const x = fa ? 1120 : 80; const maxWidth = 1010;
  ctx.fillStyle = '#ff9b35'; ctx.font = `700 18px ${fa ? 'Vazirmatn' : 'DM Sans'}, sans-serif`;
  ctx.fillText(`${event.city}  ·  ${event.date}`, x, 245);
  ctx.fillStyle = '#ffffff'; ctx.font = `800 54px ${fa ? 'Vazirmatn' : 'Manrope'}, sans-serif`;
  const titleRows = wrapCanvasText(ctx, event.title, maxWidth);
  titleRows.forEach((line, index) => ctx.fillText(line, x, 330 + index * 68));
  ctx.fillStyle = 'rgba(239,244,255,.78)'; ctx.font = `500 23px ${fa ? 'Vazirmatn' : 'DM Sans'}, sans-serif`;
  ctx.fillText(`${event.start_time}${event.end_time ? ` — ${event.end_time}` : ''}  ·  ${event.venue}`, x, 535);
  ctx.direction = 'ltr'; ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(255,255,255,.58)'; ctx.font = '600 15px DM Sans, sans-serif'; ctx.fillText(typeof window !== 'undefined' ? window.location.host : 'panelflow.ir', 80, 592);
  return await new Promise<Blob>((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('The share image could not be generated.')), 'image/png', .92));
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
  anchor.href = url; anchor.download = filename; anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

function useRequest<T>(path: string, enabled = true) {
  const { token } = useAuth();
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(enabled);
  const [error, setError] = useState('');
  const activeController = useRef<AbortController | null>(null);
  const load = useCallback(async () => {
    if (!enabled) return;
    activeController.current?.abort();
    const controller = new AbortController();
    activeController.current = controller;
    setLoading(true); setError('');
    try { setData(await api<T>(path, { signal: controller.signal }, token)); }
    catch (err) {
      if (!(err instanceof DOMException && err.name === 'AbortError'))
        setError(err instanceof Error ? err.message : 'Request failed');
    } finally {
      if (activeController.current === controller) {
        activeController.current = null;
        setLoading(false);
      }
    }
  }, [path, token, enabled]);
  useEffect(() => {
    void load();
    return () => { activeController.current?.abort(); };
  }, [load]);
  return { data, loading, error, reload: load, setData };
}

function App() {
  const { user, token } = useAuth();
  const { data: savedEvents, reload: reloadSavedEvents } = useRequest<ApiPage<EventData>>('/me/saved-events', Boolean(user && token));
  const savedIds = new Set((user && token ? savedEvents?.items || [] : []).map(event => Number(event.id)));
  const toggleSaved = useCallback(async (eventId: number, isSaved: boolean) => {
    if (!token) throw new Error('Please sign in to save panels.');
    await api(`/me/saved-events/${eventId}`, { method: isSaved ? 'DELETE' : 'PUT' }, token);
    await reloadSavedEvents();
  }, [token, reloadSavedEvents]);
  const [locale, setLocaleState] = useState<Locale>(readStoredLocale);
  const [theme, setThemeState] = useState<Theme>(readStoredTheme);
  const setLocale = (next: Locale) => { persistLocale(next); setLocaleState(next); };
  const setTheme = (next: Theme) => { persistTheme(next); setThemeState(next); };
  const t = copy[locale];
  useEffect(() => { document.documentElement.dataset.theme = theme; document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#21232e' : '#f5f7fb'); }, [theme]);
  return <LanguageContext.Provider value={{ locale, setLocale, t }}><ThemeContext.Provider value={{ theme, setTheme }}><SavedEventsContext.Provider value={{ ids: savedIds, toggle: toggleSaved }}>
    <div className={`${locale === 'fa' ? 'app-shell rtl' : 'app-shell'}`} data-theme={theme} dir={locale === 'fa' ? 'rtl' : 'ltr'}>
      <Header />
      <main className="main-content">
        <RouteSeo />
        <Suspense fallback={<Loading />}><Routes>
          <Route path="/" element={<Home />} />
          <Route path="/events" element={<Discover />} />
          <Route path="/series" element={<SeriesDirectoryPage />} />
          <Route path="/series/:slug" element={<SeriesDetailPage />} />
          <Route path="/preferences" element={<RequireAuth><DiscoveryPreferencesPage /></RequireAuth>} />
          <Route path="/events/:eventId" element={<EventDetail />} />
          <Route path="/cities" element={<Cities />} />
          <Route path="/cities/:slug" element={<CityDetail />} />
          <Route path="/organizations/:slug" element={<OrganizationPage />} />
          <Route path="/organizations/:organizationSlug/brands/:brandSlug" element={<BrandPage />} />
          <Route path="/my-organizations" element={<RequireAuth><MyOrganizations /></RequireAuth>} />
          <Route path="/calendar" element={<CalendarPage />} />
          <Route path="/community" element={<Community />} />
          <Route path="/about" element={<About />} />
          <Route path="/sign-in" element={<SignIn />} />
          <Route path="/become-a-host" element={<RequireAuth><HostApplicationPage /></RequireAuth>} />
          <Route path="/host-application" element={<RequireAuth><HostApplicationPage /></RequireAuth>} />
          <Route path="/hosts/:slug" element={<PublicHostProfilePage />} />
          <Route path="/workspace/host-applications" element={<RequireSuperAdmin><HostApplicationsAdmin /></RequireSuperAdmin>} />
          <Route path="/me" element={<RequireAuth><Profile /></RequireAuth>} />
          <Route path="/dashboard" element={<RequireAuth><MemberDashboard /></RequireAuth>} />
          <Route path="/my-bookings" element={<RequireAuth><MyBookings /></RequireAuth>} />
          <Route path="/saved" element={<RequireAuth><SavedEvents /></RequireAuth>} />
          <Route path="/workspace/*" element={<RequireStaff><Workspace /></RequireStaff>} />
          <Route path="*" element={<NotFound />} />
        </Routes></Suspense>
      </main>
      <Footer />
    </div>
  </SavedEventsContext.Provider></ThemeContext.Provider></LanguageContext.Provider>;
}

function setPageMetadata(title: string, description: string, path: string, noIndex = false) {
  const base = (import.meta.env.VITE_PUBLIC_SITE_URL || window.location.origin).replace(/\/$/, '');
  document.title = title;
  const setMeta = (selector: string, attr: string, value: string) => {
    let element = document.head.querySelector(selector) as HTMLMetaElement | null;
    if (!element) { element = document.createElement('meta'); document.head.appendChild(element); }
    element.setAttribute(attr, value);
  };
  setMeta('meta[name="description"]', 'content', description);
  setMeta('meta[name="robots"]', 'content', noIndex ? 'noindex,nofollow' : 'index,follow,max-image-preview:large');
  setMeta('meta[property="og:title"]', 'content', title);
  setMeta('meta[property="og:description"]', 'content', description);
  setMeta('meta[property="og:url"]', 'content', `${base}${path}`);
  setMeta('meta[property="og:image"]', 'content', `${base}/panel-flow-share.png`);
  setMeta('meta[property="og:image:alt"]', 'content', 'Panel Flow navy and red wave logo');
  setMeta('meta[property="og:image:type"]', 'content', 'image/png');
  setMeta('meta[property="og:image:width"]', 'content', '1200');
  setMeta('meta[property="og:image:height"]', 'content', '630');
  setMeta('meta[name="twitter:image:alt"]', 'content', 'Panel Flow navy and red wave logo');
  setMeta('meta[name="twitter:image"]', 'content', `${base}/panel-flow-share.png`);
  let canonical = document.head.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!canonical) { canonical = document.createElement('link'); canonical.rel = 'canonical'; document.head.appendChild(canonical); }
  canonical.href = `${base}${path}`;
}

function RouteSeo() {
  const location = useLocation(); const { locale } = useLanguage();
  useEffect(() => {
    const path = location.pathname;
    const pages: Record<string, [string,string]> = locale === 'fa' ? {
      '/': ['پنل فلو | گفت‌وگوهایی که ارتباط می‌سازند', 'پنل‌های گفت‌وگو در شهرهای ایران را پیدا کنید، در بحث‌ها شرکت کنید و با آدم‌های تازه آشنا شوید.'],
      '/events': ['پنل‌های پیش‌رو | پنل فلو', 'فهرست پنل‌های گفت‌وگو و نشست‌های حضوری پیش‌رو در پنل فلو.'],
      '/cities': ['شهرهای میزبان | پنل فلو', 'شهرهای ایران را کاوش کنید و پنل‌های در حال برگزاری در هر شهر را ببینید.'],
      '/series': ['مجموعه گفت‌وگوها | پنل فلو', 'مجموعه‌ای از پنل‌های مرتبط را در مسیرهای گفت‌وگویی دنبال کنید.'],
      '/calendar': ['تقویم پنل‌ها | پنل فلو', 'تقویم شمسی پنل‌ها و نشست‌های پیش‌رو در پنل فلو.'],
      '/community': ['جامعه پنل فلو', 'چالش‌ها، ایده‌ها و گفتگوهای جامعه پنل فلو.'],
      '/about': ['درباره پنل فلو', 'داستان پنل فلو؛ جامعه‌ای برای گفتگو، آشنایی و تبادل دیدگاه.'],
      '/sign-in': ['ورود | پنل فلو', 'ورود امن به پنل فلو با تأیید حساب تلگرام.'],
    } : {
      '/': ['Panel Flow — Find your next conversation', 'Discover thoughtful discussion panels across Iran, meet curious people, and become part of the conversation.'],
      '/events': ['Upcoming panels | Panel Flow', 'Discover upcoming discussion panels and in-person gatherings across Iran.'],
      '/cities': ['Cities & hosts | Panel Flow', 'Explore cities across Iran and discover the panels hosted in each city.'],
      '/series': ['Discussion series | Panel Flow', 'Follow connected discussion panels as a learning and conversation series.'],
      '/calendar': ['Panel calendar | Panel Flow', 'Browse upcoming Panel Flow sessions in the Persian calendar.'],
      '/community': ['Panel Flow community', 'Explore challenges, ideas, and conversations from the Panel Flow community.'],
      '/about': ['About Panel Flow', 'The story behind Panel Flow: a community built around meaningful conversations.'],
      '/sign-in': ['Sign in | Panel Flow', 'Securely sign in to Panel Flow using your verified Telegram account.'],
    };
    const privateRoute = ['/me','/dashboard','/my-bookings','/saved','/my-organizations','/become-a-host','/host-application'].includes(path) || path.startsWith('/workspace');
    const knownPublic = Object.prototype.hasOwnProperty.call(pages, path) || path.startsWith('/events/') || path.startsWith('/cities/') || path.startsWith('/series/') || path.startsWith('/organizations/') || path.startsWith('/hosts/');
    const entry = pages[path] || (path.startsWith('/events/') ? (locale === 'fa' ? ['جزئیات پنل | پنل فلو','جزئیات یک پنل منتشرشده در پنل فلو.'] : ['Panel details | Panel Flow','Details for a published Panel Flow event.']) : path.startsWith('/cities/') ? (locale === 'fa' ? ['پنل‌های این شهر | پنل فلو','پنل‌های منتشرشده در این شهر را پیدا کنید.'] : ['Panels in this city | Panel Flow','Find published discussion panels in this city.']) : path.startsWith('/series/') ? (locale === 'fa' ? ['مجموعه گفت‌وگو | پنل فلو','پنل‌های مرتبط در یک مجموعه گفت‌وگو.'] : ['Discussion series | Panel Flow','A connected series of discussion panels.']) : path.startsWith('/hosts/') ? (locale === 'fa' ? ['پروفایل میزبان | پنل فلو','پروفایل عمومی میزبان تأییدشده در پنل فلو.'] : ['Host profile | Panel Flow','A public profile for a verified Panel Flow host.']) : ['Page not found | Panel Flow','The requested Panel Flow page could not be found.']);
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === 'fa' ? 'rtl' : 'ltr';
    setPageMetadata(entry[0], entry[1], path, privateRoute || path === '/sign-in' || !knownPublic);
  }, [location.pathname, locale]);
  return null;
}

function Header() {
  const { t, locale, setLocale } = useLanguage();
  const { theme, setTheme } = useTheme();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname]);
  const name = user?.display_name || user?.first_name || 'My space';
  return <header className="site-header">
    <div className="nav-wrap">
      <Link to="/" className="brand" aria-label="Panel Flow home"><span className="brand-symbol" aria-hidden="true"><img className="brand-wave-dark" src="/brand/panelflow-wave-dark.svg" alt=""/><img className="brand-wave-light" src="/brand/panelflow-wave-light.svg" alt=""/></span><span className="brand-word">PANEL <span>FLOW</span><small>MEET · DISCUSS · GROW</small></span></Link>
      <nav className={open ? 'nav-links open' : 'nav-links'}>
        <NavLink to="/events">{t.nav.discover}</NavLink>
        <NavLink to="/cities">{locale === 'fa' ? 'شهرها' : 'Cities'}</NavLink>
        <NavLink to="/series">{locale === 'fa' ? 'مجموعه‌ها' : 'Series'}</NavLink>
        <NavLink to="/calendar">{locale === 'fa' ? 'تقویم' : 'Calendar'}</NavLink>
        <NavLink to="/community">{t.nav.community}</NavLink>
        <NavLink to="/about">{t.nav.about}</NavLink>
        {!user && <NavLink to="/sign-in" className="mobile-auth-link">{t.nav.login}</NavLink>}
        {user && <NavLink to="/dashboard">{locale === 'fa' ? 'داشبورد من' : 'My dashboard'}</NavLink>}
        {user && <NavLink to="/me">{t.nav.my}</NavLink>}
        {user && <NavLink to="/preferences">{locale === 'fa' ? 'علایق من' : 'My interests'}</NavLink>}
        {user && <NavLink to="/my-organizations">{locale === 'fa' ? 'سازمان‌های من' : 'My organizations'}</NavLink>}
        {user && ['host', 'admin', 'super_admin'].includes(user.role) && <NavLink to="/workspace">{locale === 'fa' ? 'فضای کاری' : 'Workspace'}</NavLink>}
        {user && !['host', 'admin', 'super_admin'].includes(user.role) && <NavLink to="/become-a-host">{locale === 'fa' ? 'میزبان شوید' : 'Become a Host'}</NavLink>}
        {user?.role === 'super_admin' && <NavLink to="/workspace/host-applications">{locale === 'fa' ? 'درخواست‌های میزبانی' : 'Host applications'}</NavLink>}
      </nav>
      <div className="nav-actions">
        <button className="language-switch" onClick={() => setLocale(locale === 'en' ? 'fa' : 'en')} aria-label="Switch language"><Globe2 size={16} />{locale === 'en' ? 'FA' : 'EN'}</button>
        <button className="icon-button theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={theme === 'dark' ? (locale === 'fa' ? 'فعال‌سازی حالت روشن' : 'Switch to light mode') : (locale === 'fa' ? 'فعال‌سازی حالت شب' : 'Switch to dark mode')} title={theme === 'dark' ? 'Light mode' : 'Dark mode'}>{theme === 'dark' ? <Sun size={17}/> : <Moon size={17}/>}</button>
        {user ? <div className="user-menu"><Link to="/me" className="avatar-chip"><span className="avatar">{name.charAt(0).toUpperCase()}</span><span>{name.split(' ')[0]}</span></Link><button className="icon-button" onClick={logout} title={t.nav.logout}><LogOut size={17} /></button></div> : <Link to="/sign-in" className="button button-small button-primary header-sign-in">{t.nav.login}<ArrowUpRight size={15} /></Link>}
        <button className="mobile-menu icon-button" onClick={() => setOpen(!open)} aria-label="Toggle navigation">{open ? <X /> : <Menu />}</button>
      </div>
    </div>
  </header>;
}

function Footer() {
  const { t, locale } = useLanguage();
  const year = locale === 'fa' ? new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', timeZone: 'Asia/Tehran' }).format(new Date()) : new Intl.DateTimeFormat('en-US', { year: 'numeric', timeZone: 'Asia/Tehran' }).format(new Date());
  return <footer className="site-footer"><div className="footer-inner footer-grid">
    <div className="footer-brand-block"><Link to="/" className="brand footer-brand"><span className="brand-symbol" aria-hidden="true"><img className="brand-wave-dark" src="/brand/panelflow-wave-dark.svg" alt=""/><img className="brand-wave-light" src="/brand/panelflow-wave-light.svg" alt=""/></span><span className="brand-word">PANEL <span>FLOW</span><small>MEET · DISCUSS · GROW</small></span></Link><p>{t.footer}</p><div className="footer-social"><a href="https://www.instagram.com/panelflowfestival/" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={17} /></a><a href="https://t.me/PanelFlowFestival" target="_blank" rel="noreferrer" aria-label="Telegram"><SendTelegramIcon /></a></div></div>
    <div className="footer-column"><h3>{locale === 'fa' ? 'کاوش در پنل فلو' : 'Explore Panel Flow'}</h3><Link to="/events">{t.nav.discover}</Link><Link to="/cities">{locale === 'fa' ? 'شهرهای میزبان' : 'Cities & hosts'}</Link><Link to="/calendar">{locale === 'fa' ? 'تقویم پنل‌ها' : 'Panel calendar'}</Link><Link to="/community">{t.nav.community}</Link></div>
    <div className="footer-column"><h3>{locale === 'fa' ? 'درباره و پشتیبانی' : 'About & support'}</h3><Link to="/about">{t.nav.about}</Link><a href="https://t.me/PanelFlowAdmin" target="_blank" rel="noreferrer">{locale === 'fa' ? 'ارتباط با تیم' : 'Contact the team'}</a><Link to="/sign-in">{locale === 'fa' ? 'ورود میزبان و اعضا' : 'Member & host sign in'}</Link></div>
    </div><div className="footer-bottom"><span>© {year} Panel Flow</span><span>{locale === 'fa' ? 'گفت‌وگو، از هر شهر؛ یک جریان مشترک.' : 'Meaningful conversations, across cities.'}</span></div></footer>;
}

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth(); const location = useLocation(); const { t } = useLanguage();
  if (loading) return <Loading />;
  return user ? <>{children}</> : <div className="center-state"><LockKeyhole size={28} /><h2>{t.loginRequired}</h2><p>{t.signInToSee}</p><Link to="/sign-in" state={{ from: `${location.pathname}${location.search}`, resumeSignup: false }} className="button button-primary">{t.nav.login}<ArrowUpRight size={16} /></Link></div>;
}
function RequireStaff({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/sign-in" replace />;
  if (!['host', 'admin', 'super_admin'].includes(user.role)) return <Navigate to="/me" replace />;
  return <>{children}</>;
}
function RequireSuperAdmin({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/sign-in" replace />;
  if (user.role !== 'super_admin') return <Navigate to="/me" replace />;
  return <>{children}</>;
}
function Loading() { const { t } = useLanguage(); return <div className="center-state"><LoaderCircle className="spin" size={26} /><span>{t.loading}</span></div>; }
function ErrorState({ message, retry }: { message: string; retry?: () => void }) { const { t } = useLanguage(); return <div className="notice notice-error"><CircleHelp size={18} /><span>{message || t.error}</span>{retry && <button className="text-button" onClick={retry}>{t.retry}</button>}</div>; }


function useScrollReveals() {
  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>('[data-reveal]'));
    if (!nodes.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) return;
    document.documentElement.classList.add('has-scroll-reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -48px 0px' });
    nodes.forEach(node => observer.observe(node));
    return () => { observer.disconnect(); document.documentElement.classList.remove('has-scroll-reveal'); };
  }, []);
}

function ParticleNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const parent = canvas?.parentElement;
    const ctx = canvas?.getContext('2d', { alpha: true });
    if (!canvas || !parent || !ctx) return;
    const nav = navigator as Navigator & { deviceMemory?: number; connection?: { saveData?: boolean } };
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const lowPower = reduced || nav.connection?.saveData === true || (nav.hardwareConcurrency || 4) <= 2 || (nav.deviceMemory || 4) <= 2;
    const simplified = !lowPower && (nav.hardwareConcurrency || 4) <= 4;
    const count = lowPower ? 12 : simplified ? 22 : 42;
    const points = Array.from({ length: count }, (_, i) => ({
      x: Math.random(), y: Math.random(), vx: (Math.random() - .5) * .00025,
      vy: (Math.random() - .5) * .00025, phase: i * .71,
    }));
    let width = 0, height = 0, frame = 0, last = 0, active = true, visible = true;
    const resize = () => {
      const rect = parent.getBoundingClientRect();
      width = Math.max(1, rect.width); height = Math.max(1, rect.height);
      const dpr = Math.min(window.devicePixelRatio || 1, 1.35);
      canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw(0, false);
    };
    const draw = (time: number, animate: boolean) => {
      ctx.clearRect(0, 0, width, height);
      const line = getComputedStyle(document.documentElement).getPropertyValue('--particle-line').trim() || 'rgba(120,160,255,.24)';
      const dot = getComputedStyle(document.documentElement).getPropertyValue('--particle-dot').trim() || '#83a9ff';
      const reach = simplified || lowPower ? 105 : 140;
      const reachSq = reach * reach;
      if (animate) points.forEach((p) => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < .02 || p.x > .98) p.vx *= -1;
        if (p.y < .04 || p.y > .96) p.vy *= -1;
        p.x = Math.max(.02, Math.min(.98, p.x)); p.y = Math.max(.04, Math.min(.96, p.y));
      });
      ctx.lineWidth = 1;
      for (let i = 0; i < points.length; i++) {
        const a = points[i], ax = a.x * width, ay = a.y * height;
        for (let j = i + 1; j < points.length; j++) {
          const b = points[j], dx = (a.x - b.x) * width, dy = (a.y - b.y) * height;
          const d2 = dx * dx + dy * dy;
          if (d2 < reachSq) {
            ctx.globalAlpha = (1 - d2 / reachSq) * .42;
            ctx.strokeStyle = line; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(b.x * width, b.y * height); ctx.stroke();
          }
        }
        ctx.globalAlpha = .8; ctx.fillStyle = dot; ctx.beginPath(); ctx.arc(ax, ay, i % 8 === 0 ? 2.2 : 1.45, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    };
    const tick = (time: number) => {
      if (!active || !visible || document.hidden) return;
      const interval = lowPower ? Infinity : simplified ? 75 : 34;
      if (interval === Infinity) { draw(time, false); return; }
      if (time - last >= interval) { last = time; draw(time, true); }
      frame = requestAnimationFrame(tick);
    };
    const start = () => { if (lowPower) { draw(0, false); return; } cancelAnimationFrame(frame); frame = requestAnimationFrame(tick); };
    const stop = () => cancelAnimationFrame(frame);
    const intersection = new IntersectionObserver(entries => { visible = Boolean(entries[0]?.isIntersecting); if (visible) start(); else stop(); }, { threshold: 0.01 });
    intersection.observe(parent);
    const visibility = () => { if (document.hidden) stop(); else start(); };
    document.addEventListener('visibilitychange', visibility);
    const observer = 'ResizeObserver' in window ? new ResizeObserver(resize) : null;
    observer?.observe(parent);
    window.addEventListener('resize', resize, { passive: true });
    resize(); start();
    return () => { active = false; stop(); intersection.disconnect(); observer?.disconnect(); window.removeEventListener('resize', resize); document.removeEventListener('visibilitychange', visibility); };
  }, []);
  return <canvas ref={canvasRef} className="particle-canvas" aria-hidden="true" />;
}

function RecommendedSection() {
  const { locale } = useLanguage(); const { user, token } = useAuth();
  const { data, loading, error, reload } = useRequest<ApiPage<any>>('/me/recommendations?limit=4', Boolean(user && token));
  const [feedbackBusy, setFeedbackBusy] = useState<number | null>(null);
  const markNotInterested = async (eventId: number) => {
    if (!token) return;
    setFeedbackBusy(eventId);
    try { await api(`/me/recommendations/${eventId}/feedback`, { method: 'PUT' }, token); await reload(); }
    catch (err) { window.alert(err instanceof Error ? err.message : 'Request failed'); }
    finally { setFeedbackBusy(null); }
  };
  if (!user || !token) return null;
  return <section className="section recommendation-section" data-reveal>
    <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-dot" />{locale === 'fa' ? 'پیشنهادهای متناسب با علایق شما' : 'A PERSONALIZED SHORTLIST'}</div><h2>{locale === 'fa' ? 'پیشنهادشده برای شما' : 'Recommended for you'}<span className="heading-period">.</span></h2></div><Link className="text-link" to="/preferences">{locale === 'fa' ? 'تنظیم علایق' : 'Tune your interests'}<ArrowUpRight size={16}/></Link></div>
    {loading ? <Loading/> : error ? <ErrorState message={error} retry={reload}/> : data?.items?.length ? <div className="event-grid">{data.items.map((event:any) => <div className="recommendation-card" key={event.id}><div className="recommendation-reasons">{(event.recommendation_reasons || []).slice(0,2).map((reason:string)=><span key={reason}>{locale === 'fa' ? ({'Because you follow a topic':'به‌دلیل دنبال‌کردن این موضوع','From an organization you follow':'از سازمانی که دنبال می‌کنید','In your preferred city':'در شهر منتخب شما','In your preferred language':'به زبان دلخواه شما','Matches your preferred format':'مطابق قالب رویداد دلخواه شما','Similar to an organization you attended':'مشابه سازمانی که در رویدادهایش شرکت کرده‌اید','Recently updated':'به‌تازگی به‌روزرسانی شده','Registration is open':'ثبت‌نام باز است'} as Record<string,string>)[reason] || 'متناسب با علایق شما' : reason}</span>)}</div><EventCard event={event}/><button className="recommendation-dismiss" type="button" disabled={feedbackBusy === event.id} onClick={() => void markNotInterested(event.id)}>{feedbackBusy === event.id ? <LoaderCircle className="spin" size={13}/> : <X size={13}/>} {locale === 'fa' ? 'علاقه‌ای ندارم' : 'Not interested'}</button></div>)}</div> : <div className="empty-panel"><Compass size={24}/><p>{locale === 'fa' ? 'برای دریافت پیشنهادهای دقیق‌تر، چند موضوع یا سازمان را دنبال کنید.' : 'Follow a few topics or organizations to get more relevant panel recommendations.'}</p><Link className="button button-outline" to="/preferences">{locale === 'fa' ? 'انتخاب علایق' : 'Choose interests'}</Link></div>}
  </section>;
}

function EventFollowingControls({ event }: { event: EventData }) {
  const { token, user } = useAuth(); const { locale } = useLanguage(); const navigate = useNavigate();
  const { data, reload } = useRequest<{topics:string[];organizations:{id:number}[]}>('/me/follows', Boolean(token && user));
  const [busy, setBusy] = useState('');
  const followedTopics = new Set(data?.topics || []);
  const followedOrganizations = new Set((data?.organizations || []).map(org => org.id));
  const toggle = async (kind: 'topic'|'organization', id: string|number) => {
    if (!token || !user) { navigate('/sign-in', { state: { from: window.location.pathname } }); return; }
    const key = `${kind}-${id}`; const following = kind === 'topic' ? followedTopics.has(String(id)) : followedOrganizations.has(Number(id));
    setBusy(key);
    try {
      const path = kind === 'topic' ? `/me/follows/topics/${id}` : `/me/follows/organizations/${id}`;
      await api(path, { method: following ? 'DELETE' : 'PUT' }, token);
      await reload();
    } catch (error) { window.alert(error instanceof Error ? error.message : 'Request failed'); }
    finally { setBusy(''); }
  };
  if (!(event.topic_tags?.length || event.organization?.id)) return null;
  return <div className="event-following-controls">
    {event.topic_tags?.length ? <div className="event-topic-section"><span className="meta-label">{locale==='fa'?'موضوع‌های این پنل':'DISCUSSION TOPICS'}</span><div className="topic-chip-row">{event.topic_tags.map(key => {
      const following = followedTopics.has(key); const busyKey = busy === `topic-${key}`;
      return <button key={key} type="button" className={`topic-follow-chip${following ? ' following' : ''}`} onClick={() => void toggle('topic', key)} disabled={Boolean(busy)} aria-pressed={following}>{following ? <Check size={13}/> : <Plus size={13}/>} {TOPIC_LABELS[key]?.[locale] || key.charAt(0).toUpperCase()+key.slice(1)} <small>{following ? (locale==='fa'?'دنبال می‌کنید':'Following') : (locale==='fa'?'دنبال‌کردن':'Follow')}</small>{busyKey && <LoaderCircle className="spin" size={12}/>}</button>;
    })}</div></div> : null}
    {event.organization?.id ? <div className="event-follow-organization"><span>{locale==='fa'?'از برنامه‌های بعدی این سازمان باخبر شوید.':'Keep up with this organization’s upcoming panels.'}</span><button type="button" className={`button button-small ${followedOrganizations.has(event.organization.id) ? 'button-outline' : 'button-primary'}`} onClick={() => event.organization && void toggle('organization', event.organization.id)} disabled={Boolean(busy)} aria-pressed={followedOrganizations.has(event.organization.id)}>{followedOrganizations.has(event.organization.id) ? <Check size={14}/> : <Plus size={14}/>} {followedOrganizations.has(event.organization.id) ? (locale==='fa'?'دنبال می‌کنید':'Following') : (locale==='fa'?'دنبال‌کردن سازمان':'Follow organization')}{busy === `organization-${event.organization.id}` && <LoaderCircle className="spin" size={12}/>}</button></div> : null}
  </div>;
}

function DiscoveryPreferencesPage() {
  const { locale } = useLanguage(); const { token } = useAuth();
  const { data: topicsData } = useRequest<ApiPage<any>>('/discovery/topics');
  const { data: citiesData } = useRequest<ApiPage<CityData>>('/cities');
  const { data: organizationsData } = useRequest<ApiPage<any>>('/organizations');
  const { data: followsData, reload: reloadFollows } = useRequest<{topics:string[];organizations:any[]}>('/me/follows');
  const { data: preferencesData, reload: reloadPreferences } = useRequest<any>('/me/discovery/preferences');
  const [preferences, setPreferences] = useState<any>({ preferred_city_id: '', preferred_language: '', preferred_format: '', notify_followed_topics: false, notify_followed_organizations: false, notify_panel_changes: true, notify_registration_reminders: true, digest_frequency: 'immediate', quiet_hours_start: '', quiet_hours_end: '' });
  const [busy, setBusy] = useState(''); const [message, setMessage] = useState('');
  useEffect(() => { if (preferencesData) setPreferences({ ...preferencesData, preferred_city_id: preferencesData.preferred_city_id || '' }); }, [preferencesData]);
  const toggleTopic = async (key: string) => { setBusy(key); setMessage(''); try { const followed=followsData?.topics?.includes(key); await api(`/me/follows/topics/${key}`,{method:followed?'DELETE':'PUT'},token); await reloadFollows(); } catch(e){setMessage(e instanceof Error?e.message:'Request failed');} finally{setBusy('');} };
  const toggleOrganization = async (id: number) => { setBusy(`org-${id}`); setMessage(''); try { const followed=followsData?.organizations?.some(org=>org.id===id); await api(`/me/follows/organizations/${id}`,{method:followed?'DELETE':'PUT'},token); await reloadFollows(); } catch(e){setMessage(e instanceof Error?e.message:'Request failed');} finally{setBusy('');} };
  const save = async (e:FormEvent) => { e.preventDefault(); setBusy('save'); setMessage(''); try { await api('/me/discovery/preferences',{method:'PATCH',body:JSON.stringify({...preferences,preferred_city_id:preferences.preferred_city_id?Number(preferences.preferred_city_id):null,preferred_language:preferences.preferred_language||null,preferred_format:preferences.preferred_format||null,quiet_hours_start:preferences.quiet_hours_start||null,quiet_hours_end:preferences.quiet_hours_end||null})},token); await reloadPreferences(); setMessage(locale==='fa'?'تنظیمات علایق ذخیره شد.':'Your discovery preferences are saved.'); } catch(err){setMessage(err instanceof Error?err.message:'Preferences could not be saved.');} finally{setBusy('');} };
  return <div className="page-shell preferences-page"><AccountHeading title={locale==='fa'?'علایق و پیشنهادها':'Your discovery preferences'} subtitle={locale==='fa'?'موضوع‌ها و سازمان‌های موردعلاقه را دنبال کنید تا پیشنهادها و اعلان‌ها مرتبط‌تر شوند.':'Follow topics and organizations to personalize recommendations and optional updates.'}/>
    {message&&<div className="notice notice-info" role="status">{message}</div>}
    <section className="surface-card preferences-card"><div className="surface-heading"><div><span className="eyebrow">TOPIC FOLLOWING</span><h2>{locale==='fa'?'موضوع‌هایی که دنبال می‌کنید':'Topics you follow'}</h2><p>{locale==='fa'?'از دسته‌بندی‌های رسمی پنل فلو انتخاب کنید.':'Choose from the platform topic taxonomy.'}</p></div><span className="count-badge">{followsData?.topics?.length||0}</span></div><div className="topic-picker">{(topicsData?.items||[]).map((topic:any)=><button key={topic.key} type="button" className={`topic-follow-chip${followsData?.topics?.includes(topic.key)?' following':''}`} onClick={()=>void toggleTopic(topic.key)} disabled={Boolean(busy)} aria-pressed={Boolean(followsData?.topics?.includes(topic.key))}>{followsData?.topics?.includes(topic.key)?<Check size={13}/>:<Plus size={13}/>} {locale==='fa'?topic.name_fa:topic.name_en}</button>)}</div></section>
    <section className="surface-card preferences-card"><div className="surface-heading"><div><span className="eyebrow">ORGANIZATION FOLLOWING</span><h2>{locale==='fa'?'سازمان‌های دنبال‌شده':'Organizations you follow'}</h2><p>{locale==='fa'?'از برنامه‌های جدید سازمان‌های موردعلاقه باخبر شوید.':'Keep up with upcoming panels from organizations you like.'}</p></div><span className="count-badge">{followsData?.organizations?.length||0}</span></div><div className="follow-organization-list">{(organizationsData?.items||[]).map((org:any)=><div className="follow-organization-row" key={org.id}><span><strong>{org.name}</strong><small>{org.description||org.slug}</small></span><button type="button" className="button button-small button-outline" disabled={Boolean(busy)} onClick={()=>void toggleOrganization(org.id)}>{followsData?.organizations?.some(item=>item.id===org.id)?(locale==='fa'?'لغو دنبال‌کردن':'Unfollow'):(locale==='fa'?'دنبال‌کردن':'Follow')}</button></div>)}</div></section>
    <form className="surface-card preferences-card preferences-form" onSubmit={save}><div className="surface-heading"><div><span className="eyebrow">RECOMMENDATION SIGNALS</span><h2>{locale==='fa'?'ترجیحات کشف پنل':'Discovery preferences'}</h2></div></div><div className="form-row"><label>{locale==='fa'?'شهر ترجیحی':'Preferred city'}<select value={preferences.preferred_city_id} onChange={e=>setPreferences((p:any)=>({...p,preferred_city_id:e.target.value}))}><option value="">{locale==='fa'?'همه شهرها':'All cities'}</option>{(citiesData?.items||[]).map(city=><option key={city.id} value={city.id}>{locale==='fa'?city.name_fa:city.name_en}</option>)}</select></label><label>{locale==='fa'?'زبان ترجیحی':'Preferred language'}<select value={preferences.preferred_language} onChange={e=>setPreferences((p:any)=>({...p,preferred_language:e.target.value}))}><option value="">{locale==='fa'?'همه زبان‌ها':'Any language'}</option><option>English</option><option>فارسی</option></select></label><label>{locale==='fa'?'قالب پنل':'Preferred format'}<select value={preferences.preferred_format} onChange={e=>setPreferences((p:any)=>({...p,preferred_format:e.target.value}))}><option value="">{locale==='fa'?'همه قالب‌ها':'Any format'}</option><option value="physical">{locale==='fa'?'حضوری':'In person'}</option><option value="online">Online</option><option value="hybrid">Hybrid</option></select></label></div><div className="notification-preferences"><strong>{locale==='fa'?'اعلان‌های اختیاری':'Optional notifications'}</strong>{([['notify_followed_topics',locale==='fa'?'پنل‌های موضوع‌های دنبال‌شده':'New panels in followed topics'],['notify_followed_organizations',locale==='fa'?'پنل‌های سازمان‌های دنبال‌شده':'New panels from followed organizations'],['notify_panel_changes',locale==='fa'?'تغییرات پنل‌های ثبت‌نام‌شده':'Changes to panels you registered for'],['notify_registration_reminders',locale==='fa'?'یادآوری ثبت‌نام و برگزاری':'Registration and event reminders']] as [string,string][]).map(([key,label])=><label className="checkbox-line" key={key}><input type="checkbox" checked={Boolean(preferences[key])} onChange={e=>setPreferences((p:any)=>({...p,[key]:e.target.checked}))}/>{label}</label>)}</div><div className="form-row notification-delivery-options"><label>{locale==='fa'?'زمان‌بندی اعلان پنل‌های تازه':'New-panel notification delivery'}<select value={preferences.digest_frequency||'immediate'} onChange={e=>setPreferences((p:any)=>({...p,digest_frequency:e.target.value}))}><option value="immediate">{locale==='fa'?'فوری':'Immediately'}</option><option value="daily">{locale==='fa'?'خلاصه روزانه':'Daily digest'}</option><option value="weekly">{locale==='fa'?'خلاصه هفتگی':'Weekly digest'}</option></select></label><label>{locale==='fa'?'شروع ساعات سکوت (اختیاری)':'Quiet hours start (optional)'}<input type="time" value={preferences.quiet_hours_start||''} onChange={e=>setPreferences((p:any)=>({...p,quiet_hours_start:e.target.value,quiet_hours_end:e.target.value?(p.quiet_hours_end||'08:00'):''}))}/></label><label>{locale==='fa'?'پایان ساعات سکوت':'Quiet hours end'}<input type="time" value={preferences.quiet_hours_end||''} onChange={e=>setPreferences((p:any)=>({...p,quiet_hours_end:e.target.value}))}/></label></div><p className="form-hint">{locale==='fa'?'ساعات سکوت و خلاصه‌های روزانه/هفتگی فقط برای اعلان‌های اختیاری پنل‌های تازه اعمال می‌شوند. اعلان‌های مهم رزرو و تغییرات پنل‌های ثبت‌نام‌شده فوری باقی می‌مانند.':'Quiet hours and digests apply only to optional new-panel alerts. Booking confirmations and important changes to panels you registered for remain immediate.'}</p><button className="button button-orange" disabled={busy==='save'}>{busy==='save'?<LoaderCircle size={16} className="spin"/>:<Check size={16}/>} {locale==='fa'?'ذخیره ترجیحات':'Save preferences'}</button></form>
  </div>;
}


function Home() {
  const { t, locale } = useLanguage();
  useScrollReveals();
  const { data, loading, error, reload } = useRequest<ApiPage<EventData>>('/events?limit=6');
  const featured = data?.items?.slice(0, 3) || [];
  return <>
    <section className="hero-section" data-reveal>
      <ParticleNetwork />
      <div className="hero-grid" />
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot" />{t.heroEyebrow}</div><h1>{t.heroTitle.split('\n').map((line, index) => <span key={line}>{line}{index === 0 && <br />}</span>)}</h1><p>{t.heroText}</p><div className="hero-actions"><Link to="/events" className="button button-orange">{t.explore}<ArrowUpRight size={18} /></Link><a href="#how" className="button button-ghost">{t.how}<ArrowDownRight size={17} /></a></div><div className="hero-proof"><div className="proof-avatars"><span>PF</span><span>✦</span><span>+</span></div><span>{locale === 'fa' ? 'گفت‌وگوهای واقعی، آدم‌های کنجکاو' : 'Real conversations. Curious people.'}</span></div></div>
      <div className="hero-art" aria-label="Abstract Panel Flow visual"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" /><div className="art-core"><span className="core-dot" /><span className="core-line" /><img className="hero-brand-wave brand-wave-dark" src="/brand/panelflow-wave-dark.svg" alt=""/><img className="hero-brand-wave brand-wave-light" src="/brand/panelflow-wave-light.svg" alt=""/><small>MEET · DISCUSS · GROW</small></div><div className="floating-note note-one"><MessageCircle size={15} /><span>{locale === 'fa' ? 'دیدگاه تازه' : 'Fresh perspective'}</span></div><div className="floating-note note-two"><Sparkles size={15} /><span>{locale === 'fa' ? 'ارتباط واقعی' : 'Real connection'}</span></div><div className="floating-stamp">MEET<br />&<br />GROW</div></div>
      <div className="hero-bottom"><span>01 / 03</span><div className="hero-progress"><span /></div><span>DISCOVER THE FLOW</span></div>
    </section>

    <RecommendedSection />

    <section className="section events-section" id="upcoming" data-reveal><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-dot" />DISCOVER YOUR NEXT ROOM</div><h2>{t.upcoming}<span className="heading-period">.</span></h2></div><Link to="/events" className="text-link">{t.viewAll}<ArrowUpRight size={17} /></Link></div>
      {loading ? <Loading /> : error ? <ErrorState message={error} retry={reload} /> : featured.length ? <div className="event-grid">{featured.map((event, i) => <EventCard key={event.id} event={event} index={i} />)}</div> : <div className="empty-panel"><CalendarDays size={28} /><p>{t.emptyEvents}</p></div>}
    </section>

    <CityHubPreview />
    <section className="section calendar-teaser" data-reveal><div><div className="eyebrow"><span className="eyebrow-dot" />{locale === 'fa' ? 'زمان‌بندی گفتگوها' : 'FIND YOUR DATE'}</div><h2>{locale === 'fa' ? 'برنامه پنل‌ها را در یک نگاه ببینید' : 'A clearer view of what’s coming.'}</h2><p>{locale === 'fa' ? 'پنل‌های زمان‌بندی‌شده را در تقویم شمسی دنبال کنید.' : 'Browse scheduled panels in a familiar Persian calendar.'}</p></div><Link to="/calendar" className="button button-outline">{locale === 'fa' ? 'باز کردن تقویم' : 'Open calendar'}<CalendarDays size={17}/></Link></section>

    <section className="section value-section" data-reveal><div className="section-heading compact"><div><div className="eyebrow"><span className="eyebrow-dot" />WHY PANEL FLOW</div><h2>{locale === 'fa' ? 'بیشتر از یک دورهمی' : 'More than a meetup'}<span className="heading-period">.</span></h2></div><p className="section-side-copy">{locale === 'fa' ? 'فضایی برای مکث، شنیدن و ساختن ارتباط‌هایی که بعد از پایان پنل هم ادامه دارند.' : 'A place to pause, listen, and build connections that last beyond the room.'}</p></div>
      <div className="value-grid"><article className="value-card"><div className="value-icon blue"><Lightbulb size={22} /></div><h3>{t.curated}</h3><p>{t.curatedText}</p><span className="value-index">01</span></article><article className="value-card"><div className="value-icon orange"><Users size={22} /></div><h3>{t.people}</h3><p>{t.peopleText}</p><span className="value-index">02</span></article><article className="value-card"><div className="value-icon violet"><Zap size={22} /></div><h3>{t.grow}</h3><p>{t.growText}</p><span className="value-index">03</span></article></div>
    </section>

    <section className="section how-section" id="how" data-reveal><div className="how-head"><div className="eyebrow"><span className="eyebrow-dot" />SIMPLE BY DESIGN</div><h2>{t.howTitle}<span className="heading-period">.</span></h2></div><div className="steps-grid"><div className="step"><span className="step-number">01</span><div className="step-icon"><Compass size={24} /></div><h3>{t.step1}</h3><p>{t.step1Text}</p></div><div className="step-step-line" /><div className="step"><span className="step-number">02</span><div className="step-icon"><Ticket size={24} /></div><h3>{t.step2}</h3><p>{t.step2Text}</p></div><div className="step-step-line" /><div className="step"><span className="step-number">03</span><div className="step-icon"><MessageCircle size={24} /></div><h3>{t.step3}</h3><p>{t.step3Text}</p></div></div></section>

    <section className="community-banner" data-reveal><div className="banner-glow" /><div className="banner-content"><div className="eyebrow"><span className="eyebrow-dot" />THE CONVERSATION CONTINUES</div><h2>{t.community}</h2><p>{t.communityText}</p><Link to="/community" className="button button-orange">{t.joinCommunity}<ArrowUpRight size={18} /></Link></div><div className="banner-mark"><div className="banner-ring"><span>PF</span></div><Sparkles className="banner-spark" size={26} /></div></section>
  </>;
}

function EventCard({ event, index = 0 }: { event: EventData; index?: number }) {
  const { t, locale } = useLanguage();
  const { user, token } = useAuth(); const navigate = useNavigate();
  const { ids, toggle } = useSavedEvents(); const saved = ids.has(event.id);
  const [busy, setBusy] = useState(false);
  const toggleSave = async () => {
    if (!user || !token) { navigate('/sign-in', { state: { from: window.location.pathname } }); return; }
    setBusy(true);
    try { await toggle(event.id, saved); }
    catch (err) { window.alert(err instanceof Error ? err.message : t.error); }
    finally { setBusy(false); }
  };
  return <article className={`event-card event-card-${index % 3}`}>
    <div className="event-card-top"><span className="event-volume">{event.volume}</span><button className={`save-button ${saved ? 'is-saved' : ''}`} onClick={toggleSave} disabled={busy} aria-label={saved ? t.removeSaved : t.save}>{saved ? <Heart size={17} fill="currentColor" /> : <Bookmark size={17} />}</button></div>
    <Link to={`/events/${event.id}`} className="event-card-main"><div className="event-date-line"><CalendarDays size={15} />{event.day} · {event.date}</div><h3>{event.title}</h3><p className="event-location"><span className="location-dot" />{event.venue}, {event.city}</p></Link>
    {(event.brand || event.organization) && <div className="event-attribution event-card-attribution">{event.brand && <Link to={`/organizations/${event.organization?.slug || ''}/brands/${event.brand.slug}`}>{event.brand.name}</Link>}{event.brand && event.organization && <span> · </span>}{event.organization && <Link to={`/organizations/${event.organization.slug}`}>{event.organization.name}</Link>}<small>Powered by Panel Flow</small></div>}
    <div className="event-card-bottom"><div><span className="meta-label">{t.price}</span><strong>{Number(event.price_per_person) === 0 ? (locale === 'fa' ? 'رایگان' : 'Free') : formatMoney(event.price_per_person, locale)}</strong></div><div className="availability-pill"><span className="availability-dot" />{event.availability_label || `${t.capacity}: ${event.capacity}`}</div><Link to={`/events/${event.id}`} className="card-arrow" aria-label={t.details}><ArrowUpRight size={19} /></Link></div>
  </article>;
}

function Discover() {
  const { t, locale } = useLanguage(); const location = useLocation(); const navigate = useNavigate();
  const initial = new URLSearchParams(location.search);
  const [query, setQuery] = useState(initial.get('q') || ''); const [sort, setSort] = useState(initial.get('sort') || 'newest');
  const [cityId, setCityId] = useState(initial.get('city_id') || ''); const [topic, setTopic] = useState(initial.get('topic') || '');
  const [organizationId, setOrganizationId] = useState(initial.get('organization_id') || '');
  const [language, setLanguage] = useState(initial.get('language') || ''); const [eventFormat, setEventFormat] = useState(initial.get('event_type') || '');
  const [dateFrom, setDateFrom] = useState(initial.get('date_from') || ''); const [dateTo, setDateTo] = useState(initial.get('date_to') || '');
  const [availability, setAvailability] = useState(initial.get('availability') || '');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try { const parsed = JSON.parse(localStorage.getItem('pf_recent_searches') || '[]'); return Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === 'string').slice(0, 5) : []; }
    catch { return []; }
  });
  const [appliedSearch, setAppliedSearch] = useState(location.search); const [linkMessage, setLinkMessage] = useState('');
  useEffect(() => {
    const timer = window.setTimeout(() => {
      const params = new URLSearchParams();
      const fields: [string, string][] = [['q',query.trim()],['city_id',cityId],['topic',topic],['organization_id',organizationId],['language',language],['event_type',eventFormat],['date_from',dateFrom],['date_to',dateTo],['availability',availability],['sort',sort]];
      for (const [key, value] of fields) if (value) params.set(key, value);
      const next = params.toString(); const nextSearch = next ? `?${next}` : '';
      setAppliedSearch(nextSearch);
      if (nextSearch !== location.search) navigate({ pathname: '/events', search: nextSearch }, { replace: true });
    }, 300);
    return () => window.clearTimeout(timer);
  }, [query, cityId, topic, organizationId, language, eventFormat, dateFrom, dateTo, availability, sort, location.search, navigate]);
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    setQuery(params.get('q') || ''); setCityId(params.get('city_id') || ''); setTopic(params.get('topic') || '');
    setOrganizationId(params.get('organization_id') || ''); setLanguage(params.get('language') || '');
    setEventFormat(params.get('event_type') || ''); setDateFrom(params.get('date_from') || '');
    setDateTo(params.get('date_to') || ''); setAvailability(params.get('availability') || '');
    setSort(params.get('sort') || 'newest'); setAppliedSearch(location.search);
  }, [location.search]);
  const requestPath = `/events?limit=100${appliedSearch ? `&${appliedSearch.slice(1)}` : ''}`;
  const { data: topicsData } = useRequest<ApiPage<any>>('/discovery/topics');
  const { data: organizationsData } = useRequest<ApiPage<any>>('/organizations');
  const { data, loading, error, reload } = useRequest<ApiPage<EventData>>(requestPath);
  const { data: cityData } = useRequest<ApiPage<CityData>>('/cities');
  const events = data?.items || [];
  const reset = () => { setQuery(''); setCityId(''); setTopic(''); setOrganizationId(''); setLanguage(''); setEventFormat(''); setDateFrom(''); setDateTo(''); setAvailability(''); setSort('newest'); };
  const rememberSearch = () => {
    const text = query.trim(); if (!text) return;
    const next = [text, ...recentSearches.filter(item => item.toLocaleLowerCase() !== text.toLocaleLowerCase())].slice(0, 5);
    setRecentSearches(next); try { localStorage.setItem('pf_recent_searches', JSON.stringify(next)); } catch { /* Search still works without storage. */ }
  };
  const hasFilters = Boolean(query || cityId || topic || organizationId || language || eventFormat || dateFrom || dateTo || availability);
  return <div className="page-shell">
    <div className="page-intro"><div className="eyebrow"><span className="eyebrow-dot" />FIND YOUR NEXT CONVERSATION</div><h1>{t.upcoming}<span className="heading-period">.</span></h1><p>{t.heroText}</p></div>
    <div className="toolbar discovery-filters">
      <label className="search-box"><Search size={18} /><input value={query} list="panel-search-suggestions" onKeyDown={e => { if (e.key === 'Enter') rememberSearch(); }} onChange={e => setQuery(e.target.value)} placeholder={locale === 'fa' ? 'جست‌وجوی پنل، موضوع، میزبان یا محل…' : 'Search panels, topics, hosts, or venues…'} aria-label={locale==='fa'?'جست‌وجوی پنل‌ها':'Search panels'}/></label>
      <datalist id="panel-search-suggestions">{events.slice(0, 8).map(event => <option key={event.id} value={event.title}/>)}</datalist>
      <select aria-label={locale==='fa'?'شهر':'City'} value={cityId} onChange={e => setCityId(e.target.value)}><option value="">{locale === 'fa' ? 'همه شهرها' : 'All cities'}</option>{(cityData?.items || []).map(city => <option key={city.id} value={city.id}>{locale === 'fa' ? city.name_fa : city.name_en}</option>)}</select>
      <select aria-label={locale==='fa'?'موضوع':'Topic'} value={topic} onChange={e=>setTopic(e.target.value)}><option value="">{locale==='fa'?'همه موضوع‌ها':'All topics'}</option>{(topicsData?.items||[]).map((item:any)=><option key={item.key} value={item.key}>{locale==='fa'?item.name_fa:item.name_en}</option>)}</select>
      <select aria-label={locale==='fa'?'سازمان':'Organization'} value={organizationId} onChange={e=>setOrganizationId(e.target.value)}><option value="">{locale==='fa'?'همه سازمان‌ها':'All organizations'}</option>{(organizationsData?.items||[]).map((org:any)=><option key={org.id} value={org.id}>{org.name}</option>)}</select>
      <select aria-label={locale==='fa'?'زبان':'Language'} value={language} onChange={e=>setLanguage(e.target.value)}><option value="">{locale==='fa'?'همه زبان‌ها':'All languages'}</option><option value="English">English</option><option value="فارسی">فارسی</option></select>
      <select aria-label={locale==='fa'?'قالب':'Format'} value={eventFormat} onChange={e=>setEventFormat(e.target.value)}><option value="">{locale==='fa'?'همه قالب‌ها':'All formats'}</option><option value="physical">{locale==='fa'?'حضوری':'In person'}</option><option value="online">Online</option><option value="hybrid">Hybrid</option></select>
      <label className="date-filter-label">{locale==='fa'?'از تاریخ':'From date'}<input type="date" value={dateFrom} max={dateTo || undefined} onChange={e=>setDateFrom(e.target.value)}/></label>
      <label className="date-filter-label">{locale==='fa'?'تا تاریخ':'To date'}<input type="date" value={dateTo} min={dateFrom || undefined} onChange={e=>setDateTo(e.target.value)}/></label>
      <select aria-label={locale==='fa'?'وضعیت ظرفیت':'Availability'} value={availability} onChange={e=>setAvailability(e.target.value)}><option value="">{locale==='fa'?'همه وضعیت‌ها':'Any availability'}</option><option value="open">{locale==='fa'?'ثبت‌نام باز':'Registration open'}</option><option value="waitlist">{locale==='fa'?'فهرست انتظار':'Waitlist available'}</option></select>
      <select aria-label={locale==='fa'?'مرتب‌سازی':'Sort'} value={sort} onChange={e => setSort(e.target.value)}><option value="newest">{locale === 'fa' ? 'جدیدترین' : 'Recently published'}</option><option value="upcoming">{locale === 'fa' ? 'نزدیک‌ترین تاریخ' : 'Upcoming date'}</option><option value="relevance">{locale === 'fa' ? 'مرتبط‌ترین' : 'Most relevant'}</option><option value="price">{locale === 'fa' ? 'کمترین هزینه' : 'Price: low to high'}</option><option value="title">{locale === 'fa' ? 'عنوان' : 'Title'}</option></select>
      {hasFilters && <button type="button" className="button button-small button-outline" onClick={reset}>{locale==='fa'?'پاک‌کردن فیلترها':'Clear filters'}</button>}
    </div>
    {recentSearches.length > 0 && <div className="recent-search-row"><span>{locale==='fa'?'جست‌وجوهای اخیر':'Recent searches'}</span>{recentSearches.map(item=><button key={item} type="button" onClick={()=>setQuery(item)}>{item}</button>)}</div>}
    <div className="search-results-meta"><span>{loading ? (locale==='fa'?'در حال جست‌وجو…':'Searching…') : `${data?.total ?? events.length} ${locale==='fa'?'نتیجه':'results'}`}</span><button type="button" className="text-button" onClick={async () => { const url = `${window.location.origin}/events${window.location.search}`; try { if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(url); setLinkMessage(locale==='fa'?'پیوند فیلترها کپی شد.':'Filtered link copied.'); } else { window.prompt(locale==='fa'?'پیوند را کپی کنید':'Copy this filtered link', url); } } catch { window.prompt(locale==='fa'?'پیوند را کپی کنید':'Copy this filtered link', url); } }}>{locale==='fa'?'کپی لینک فیلترها':'Copy filtered link'}<Share2 size={14}/></button></div>{linkMessage&&<div className="notice notice-success search-link-notice" role="status">{linkMessage}</div>}
    {loading ? <Loading /> : error ? <ErrorState message={error} retry={reload} /> : events.length ? <div className="event-grid full-event-grid">{events.map((event, index) => <EventCard event={event} index={index} key={event.id} />)}</div> : <div className="empty-panel"><Search size={28} /><p>{t.emptyEvents}</p>{hasFilters && <button className="button button-outline" onClick={reset}>{locale==='fa'?'نمایش همه پنل‌ها':'Show all panels'}</button>}</div>}
  </div>;
}

function EventDetail() {
  const { eventId } = useParams(); const { t, locale } = useLanguage(); const { token, user } = useAuth(); const navigate = useNavigate(); const location = useLocation();
  const { data: event, loading, error, reload } = useRequest<EventData>(`/events/${eventId}`);
  const { data: relatedEvents } = useRequest<ApiPage<EventData>>(`/events/${eventId}/related`);
  useEffect(() => { if (event) setPageMetadata(`${event.title} | Panel Flow`, event.description || `${event.title} · ${event.city} · ${event.venue}`, `/events/${event.id}`); }, [event]);
  const [bookingOpen, setBookingOpen] = useState(false); const [waitlistOpen, setWaitlistOpen] = useState(false);
  const { ids: savedIds, toggle: toggleSaved } = useSavedEvents(); const saved = !!event && savedIds.has(event.id);
  const recordedViewRef = useRef<string | null>(null);
  useEffect(() => {
    const viewKey = event?.id && token ? `${event.id}:${user?.id || 'member'}` : null;
    if (!viewKey || recordedViewRef.current === viewKey) return;
    recordedViewRef.current = viewKey;
    void api(`/me/recent-events/${event!.id}`, { method: 'POST' }, token).catch(() => { recordedViewRef.current = null; });
  }, [event?.id, token, user?.id]);
  useEffect(() => { const state = location.state as any; if (user && state?.resumeSignup) { if (state.resumeWaitlist) setWaitlistOpen(true); else setBookingOpen(true); navigate(location.pathname, { replace: true, state: null }); } }, [user, location.key, location.pathname, location.state, navigate]);
  const save = async () => { if (!token) return navigate('/sign-in', { state: { from: location.pathname, resumeSignup: false } }); if (!event) return; try { await toggleSaved(event.id, saved); } catch (e) { window.alert(e instanceof Error ? e.message : t.error); } };
  if (loading) return <Loading />; if (error || !event) return <div className="page-shell"><ErrorState message={error || t.pageNotFound} retry={reload} /><Link className="text-link" to="/events"><ArrowLeft size={16} />{t.back}</Link></div>;
  return <div className="page-shell detail-shell"><Link className="back-link" to="/events"><ArrowLeft size={16} />{t.back}</Link><div className="detail-layout"><article className="detail-main"><div className={`detail-cover${event.cover_image_url ? ' has-cover-image' : ''}`} style={(event.cover_image_thumb_url || event.cover_image_url) ? { backgroundImage: `linear-gradient(90deg,rgba(10,14,27,.72),rgba(10,14,27,.12)),url(${event.cover_image_thumb_url || event.cover_image_url})` } : undefined}><div className="cover-pattern" /><span className="event-volume">{event.volume}</span><span className="cover-word">CONVERSATION<br /><b>STARTS HERE.</b></span><div className="cover-id">PF / {String(event.id).padStart(3, '0')}</div></div>{event.is_postponed && <div className="event-postponed-alert" role="status"><strong>{locale==='fa'?'این پنل به تعویق افتاده است':'This panel has been postponed'}</strong><span>{event.postponement_note || (locale==='fa'?'جزئیات زمان‌بندی جدید متعاقباً اعلام می‌شود.':'Updated scheduling details will be announced later.')}</span></div>}<div className="detail-heading"><div className="eyebrow"><span className="eyebrow-dot" />{event.language || 'PANEL FLOW SESSION'} · {locale==='fa'?({physical:'حضوری',online:'آنلاین',hybrid:'ترکیبی'}[event.event_type||'physical']):({physical:'PHYSICAL',online:'ONLINE',hybrid:'HYBRID'}[event.event_type||'physical'])}</div><h1>{event.title}</h1><p>{event.description || (locale === 'fa' ? 'برای شنیدن دیدگاه‌های تازه و ساختن یک گفت‌وگوی متفاوت کنار هم جمع می‌شویم.' : 'Come together to hear fresh perspectives and create a different kind of conversation.')}</p>{(event.organization || event.brand) && <div className="event-attribution">{event.brand && <Link to={`/organizations/${event.organization?.slug || ''}/brands/${event.brand.slug}`}>{event.brand.name}</Link>}{event.brand && event.organization && <span> · </span>}{event.organization && <Link to={`/organizations/${event.organization.slug}`}>{event.organization.name}</Link>}<small>Powered by Panel Flow</small></div>}</div>{event.discussion_series&&<Link className="event-series-link" to={`/series/${event.discussion_series.slug}`}><ListOrdered size={17}/><span><strong>{event.discussion_series.title}</strong><small>{locale==='fa'?'این پنل بخشی از یک مجموعه گفت‌وگوست':'Part of a connected discussion series'}</small></span><ArrowUpRight size={15}/></Link>}<EventFollowingControls event={event}/><div className="detail-info-grid"><div><CalendarDays size={20} /><span>{event.day}<strong>{event.date}</strong></span></div><div><Clock3 size={20} /><span>{locale === 'fa' ? 'زمان' : 'Time'}<strong>{event.start_time}{event.end_time ? ` — ${event.end_time}` : ''}</strong></span></div><div><Users size={20} /><span>{t.capacity}<strong>{event.capacity} {t.seats}</strong></span></div><div><Compass size={20} /><span>{event.event_type==='online'?(locale==='fa'?'بستر برگزاری': 'Meeting platform'):event.event_type==='hybrid'?(locale==='fa'?'محل و بستر برگزاری':'Venue & meeting platform'):(locale==='fa'?'محل برگزاری':'Location')}<strong>{event.event_type==='online'?(event.meeting_platform||'Online'):event.event_type==='hybrid'?`${event.venue}, ${event.city} · ${event.meeting_platform||'Online'}`:`${event.venue}, ${event.city}`}</strong></span></div></div>{event.remaining_seats != null && event.capacity > 0 && <div className="capacity-visual"><div><strong>{locale==='fa'?'ظرفیت باقی‌مانده':'Seats remaining'}</strong><span>{event.remaining_seats} / {event.capacity}</span></div><div className="capacity-track" role="progressbar" aria-valuemin={0} aria-valuemax={event.capacity} aria-valuenow={Math.max(0,event.capacity-event.remaining_seats)} aria-label={locale==='fa'?'ظرفیت ثبت‌نام':'Registration capacity'}><span style={{width:`${Math.max(0,Math.min(100,((event.capacity-event.remaining_seats)/event.capacity)*100))}%`}}/></div></div>}{event.agenda_items?.length ? <section className="event-content-section"><div className="eyebrow">{locale==='fa'?'مسیر گفت‌وگو':'THE DISCUSSION FLOW'}</div><h2>{locale==='fa'?'دستور جلسه':'Discussion agenda'}</h2><ol className="agenda-list">{event.agenda_items.map((item,index)=><li key={`${index}-${item}`}><span>{String(index+1).padStart(2,'0')}</span>{item}</li>)}</ol></section> : null}{event.discussion_questions?.length ? <section className="event-content-section questions-content"><div className="eyebrow">{locale==='fa'?'پرسش‌های محوری':'QUESTIONS TO EXPLORE'}</div><h2>{locale==='fa'?'درباره چه چیزی گفت‌وگو می‌کنیم؟':'What will we discuss?'}</h2><ul>{event.discussion_questions.map((question,index)=><li key={`${index}-${question}`}>{question}</li>)}</ul></section> : null}{event.address && <div className="address-strip"><span>{event.address}</span>{event.map_url && <a href={event.map_url} target="_blank" rel="noreferrer" className="text-link">{locale === 'fa' ? 'نمایش نقشه' : 'Open map'}<ExternalLink size={15} /></a>}</div>}<div className="detail-notes"><h3>{locale === 'fa' ? 'پیش از ثبت‌نام' : 'Before you join'}</h3><p>{locale === 'fa' ? 'پس از ثبت رزرو، وضعیت آن را از بخش رزروهای من پیگیری کنید. در صورت نیاز به پرداخت، رسید شما پس از ارسال توسط مدیر بررسی می‌شود.' : 'After reserving, track your booking from My bookings. When payment is required, your receipt will be reviewed by the Panel Flow team.'}</p></div></article>
    <aside className="booking-panel"><div className="booking-price"><span>{t.price}</span><strong>{event.price_per_person === 0 ? (locale === 'fa' ? 'رایگان' : 'Free') : formatMoney(event.price_per_person, locale)}</strong>{event.price_without_cafe_order != null && <small>{locale === 'fa' ? 'گزینه بدون سفارش کافه نیز موجود است.' : 'An option without a café order is available.'}</small>}</div><div className="availability-detail"><div><span className="availability-dot" />{event.availability_label}</div>{event.remaining_seats != null && <strong>{event.remaining_seats} {t.seats}</strong>}</div>{event.is_postponed ? <button className="button button-outline button-block" disabled>{locale==='fa'?'ثبت‌نام تا اطلاع بعدی بسته است':'Registration paused until further notice'}</button> : event.registration_open ? <button className="button button-orange button-block" onClick={() => user ? setBookingOpen(true) : navigate('/sign-in', { state: { from: location.pathname, resumeSignup: true } })}>{t.register}<ArrowUpRight size={17} /></button> : event.waitlist_enabled ? <button className="button button-orange button-block" onClick={() => user ? setWaitlistOpen(true) : navigate('/sign-in', { state: { from: location.pathname, resumeSignup: true, resumeWaitlist: true } })}>{locale === 'fa' ? 'عضویت در فهرست انتظار' : 'Join the waitlist'}<ArrowUpRight size={17} /></button> : <button className="button button-outline button-block" disabled>{t.closed}</button>}<button className="button button-outline button-block" onClick={save}>{saved ? <Heart size={17} fill="currentColor" /> : <Bookmark size={17} />}{saved ? t.saved : t.save}</button><EventShareTools event={event}/><div className="secure-note"><ShieldCheck size={16} /><span>{locale === 'fa' ? 'رزرو امن با همگام‌سازی کامل ربات و وب‌سایت' : 'Secure booking, synced with the Telegram bot'}</span></div></aside></div>{relatedEvents?.items?.length ? <section className="section related-panels"><div className="section-heading"><div><div className="eyebrow">{locale==='fa'?'ادامه مسیر کشف':'KEEP EXPLORING'}</div><h2>{locale==='fa'?'پنل‌های مرتبط و دوره‌های پیشین':'Related panels & previous editions'}<span className="heading-period">.</span></h2></div></div><div className="event-grid">{relatedEvents.items.map(row=><EventCard key={row.id} event={row}/>)}</div></section> : null}{bookingOpen && <BookingModal event={event} onClose={() => setBookingOpen(false)} />}{waitlistOpen && <WaitlistModal event={event} onClose={() => setWaitlistOpen(false)} />}</div>;
}

function EventShareTools({ event }: { event: EventData }) {
  const { locale } = useLanguage(); const [busy, setBusy] = useState(false); const [message, setMessage] = useState('');
  const shareUrl = `${window.location.origin}/share/events/${event.id}`;
  const shareLink = async () => {
    setMessage('');
    try {
      if (navigator.share) await navigator.share({ title: event.title, text: `${event.title} · ${event.city} · ${event.date}`, url: shareUrl });
      else if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(shareUrl); setMessage(locale==='fa'?'پیوند پنل کپی شد.':'Panel link copied.'); }
      else { window.prompt(locale==='fa'?'پیوند پنل را کپی کنید':'Copy the panel link', shareUrl); }
    } catch (err) { if (err instanceof Error && err.name !== 'AbortError') setMessage(locale==='fa'?'اشتراک‌گذاری انجام نشد.':'Sharing could not be completed.'); }
  };
  const downloadCard = async () => {
    setBusy(true); setMessage('');
    try { const blob = await createEventShareImage(event, locale); downloadBlob(blob, `panel-flow-event-${event.id}.png`); setMessage(locale==='fa'?'تصویر آماده شد.':'Share image downloaded.'); }
    catch (err) { setMessage(err instanceof Error ? err.message : 'Share image could not be created.'); }
    finally { setBusy(false); }
  };
  return <div className="event-share-tools"><div className="event-share-buttons"><button type="button" className="button button-outline button-block" onClick={() => void shareLink()}><Share2 size={16}/>{locale==='fa'?'اشتراک‌گذاری پنل':'Share panel'}</button><button type="button" className="button button-outline button-block" onClick={() => void downloadCard()} disabled={busy}>{busy?<LoaderCircle className="spin" size={16}/>:<ImageDown size={16}/>} {locale==='fa'?'دریافت کارت تصویری':'Download share card'}</button></div>{message && <small role="status">{message}</small>}</div>;
}

function WaitlistModal({ event, onClose }: { event: EventData; onClose: () => void }) {
  const { locale, t } = useLanguage(); const { token } = useAuth();
  const [count, setCount] = useState(1); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [done, setDone] = useState<number | null>(null);
  const submit = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setError(''); try { const result = await api<{ position: number }>(`/events/${event.id}/waitlist`, { method: 'POST', body: JSON.stringify({ participant_count: count }) }, token); setDone(result.position); } catch (err) { setError(err instanceof Error ? err.message : t.error); } finally { setBusy(false); } };
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><div className="modal-card booking-modal"><button className="modal-close" onClick={onClose}><X size={19} /></button>{done != null ? <div className="success-state"><span className="success-icon"><CheckCircle2 size={32} /></span><h2>{locale === 'fa' ? 'در فهرست انتظار ثبت شدید' : 'You are on the waitlist'}</h2><p>{locale === 'fa' ? `جایگاه فعلی شما: ${done}. عضویت در صف به معنی رزرو قطعی نیست؛ در صورت آزاد شدن ظرفیت به شما اطلاع می‌دهیم.` : `Your current position is ${done}. This is not a confirmed booking; we will notify you if a place becomes available.`}</p><button className="button button-primary button-block" onClick={onClose}>{t.back}</button></div> : <><div className="modal-kicker">{locale === 'fa' ? 'فهرست انتظار' : 'WAITLIST'}</div><h2>{event.title}</h2><p className="modal-description">{locale === 'fa' ? 'درخواست شما رزرو قطعی یا نگه‌داشتن ظرفیت نیست. در صورت رسیدن نوبت، برای ادامه ثبت‌نام اطلاع‌رسانی می‌شود.' : 'Joining the waitlist does not reserve a seat. We will notify you when it is your turn to register.'}</p><form className="stack-form" onSubmit={submit}><label>{locale === 'fa' ? 'تعداد نفرات' : 'Number of participants'}<select value={count} onChange={e => setCount(Number(e.target.value))}>{[1,2,3].map(n => <option key={n} value={n}>{n}</option>)}</select></label>{error && <ErrorState message={error} />}<button className="button button-orange button-block" disabled={busy}>{busy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}{locale === 'fa' ? 'ثبت درخواست' : 'Join waitlist'}</button></form></>}</div></div>;
}

function BookingModal({ event, onClose }: { event: EventData; onClose: () => void }) {
  const { t, locale } = useLanguage(); const { token } = useAuth(); const navigate = useNavigate();
  const [people, setPeople] = useState([{ first_name: '', last_name: '', phone_number: '' }]);
  const [phone, setPhone] = useState(''); const [discount, setDiscount] = useState(''); const [pricing, setPricing] = useState<'base' | 'without_cafe_order'>('base');
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const [result, setResult] = useState<any>(null); const [receipt, setReceipt] = useState<File | null>(null); const [receiptText, setReceiptText] = useState(''); const [receiptSent, setReceiptSent] = useState(false);
  const requestKey = useRef<string>(`web-${event.id}-${typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`}`.slice(0,64));
  const updatePerson = (index: number, key: string, value: string) => setPeople(prev => prev.map((p, i) => i === index ? { ...p, [key]: value } : p));
  const create = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setError(''); try {
      const response = await api<any>('/bookings', { method: 'POST', body: JSON.stringify({ event_id: event.id, participants: people, contact_phone: phone || undefined, pricing_option: pricing, discount_code: discount || undefined, idempotency_key: requestKey.current }) }, token);
      setResult(response);
    } catch (err) { setError(err instanceof Error ? err.message : t.error); } finally { setBusy(false); }
  };
  const sendReceipt = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setError(''); try {
      const form = new FormData(); if (receipt) form.append('receipt', receipt); if (receiptText.trim()) form.append('receipt_text', receiptText.trim());
      await api(`/bookings/${result.booking.id}/receipt`, { method: 'POST', body: form }, token); setReceiptSent(true);
    } catch (err) { setError(err instanceof Error ? err.message : t.error); } finally { setBusy(false); }
  };
  const close = () => { onClose(); if (result) navigate('/my-bookings'); };
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && close()}><div className="modal-card booking-modal"><button className="modal-close" onClick={close}><X size={19} /></button>
    {!result ? <><div className="modal-kicker">{event.volume}</div><h2>{t.bookingTitle}</h2><p className="modal-description">{event.title}</p><form onSubmit={create} className="stack-form"><div className="form-section-label">{t.participants} <span>{people.length}/3</span></div>{people.map((p, index) => <div className="participant-form" key={index}><div className="participant-title"><strong>{t.participants} {index + 1}</strong>{index > 0 && <button type="button" className="text-button danger-text" onClick={() => setPeople(prev => prev.filter((_, i) => i !== index))}>{t.removePerson}</button>}</div><div className="form-row"><label>{t.firstName}<input required value={p.first_name} onChange={e => updatePerson(index, 'first_name', e.target.value)} maxLength={100} /></label><label>{t.lastName}<input required value={p.last_name} onChange={e => updatePerson(index, 'last_name', e.target.value)} maxLength={100} /></label></div></div>)}{people.length < 3 && <button type="button" className="add-person" onClick={() => setPeople(prev => [...prev, { first_name: '', last_name: '', phone_number: '' }])}><Plus size={16} />{t.addPerson}</button>}
      <label>{t.phone}<input value={phone} onChange={e => setPhone(e.target.value)} placeholder="09…" /></label>
      {event.price_without_cafe_order != null && <label>{t.pricing}<select value={pricing} onChange={e => setPricing(e.target.value as any)}><option value="base">{t.regularPrice} · {formatMoney(event.price_per_person * people.length, locale)}</option><option value="without_cafe_order">{t.noCafe} · {formatMoney(event.price_without_cafe_order * people.length, locale)}</option></select></label>}
      <label>{t.discount} <span className="muted-inline">({t.optional})</span><input value={discount} onChange={e => setDiscount(e.target.value.toUpperCase())} maxLength={64} /></label>
      {error && <ErrorState message={error} />}<button className="button button-orange button-block" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}{t.confirmBooking}</button></form></> : <>
      {receiptSent ? <div className="success-state"><span className="success-icon"><CheckCircle2 size={32} /></span><h2>{locale === 'fa' ? 'رسید ارسال شد' : 'Receipt submitted'}</h2><p>{locale === 'fa' ? 'رسید شما دریافت شد و پس از بررسی مدیر، نتیجه در ربات و وب‌سایت به‌روزرسانی می‌شود.' : 'Your receipt is in the review queue. The decision will be reflected in both the website and Telegram bot.'}</p><button onClick={close} className="button button-primary button-block">{t.bookings}<ArrowRight size={17} /></button></div> : result.booking.total_amount === 0 ? <div className="success-state"><span className="success-icon"><CheckCircle2 size={32} /></span><h2>{t.freeSuccess}</h2><p>{locale === 'fa' ? 'رزرو شما در هر دو پلتفرم تأیید شد.' : 'Your reservation is confirmed across both platforms.'}</p><button onClick={close} className="button button-primary button-block">{t.bookings}<ArrowRight size={17} /></button></div> : <><div className="modal-kicker">{t.paymentTitle}</div><h2>{formatMoney(result.booking.total_amount, locale)}</h2><p className="modal-description">{t.paymentCopy}</p><div className="payment-instructions"><span>{t.account}</span><strong>{result.payment_instructions?.account_name || '—'}</strong><span>{t.card}</span><div className="card-number-row"><strong dir="ltr">{result.payment_instructions?.card_number || '—'}</strong><button type="button" className="text-button" onClick={() => navigator.clipboard.writeText(result.payment_instructions?.card_number || '')}>{locale === 'fa' ? 'کپی' : 'Copy'}</button></div></div><form onSubmit={sendReceipt} className="stack-form"><label>{t.receipt}<input type="file" accept=".jpg,.jpeg,.png,.pdf,application/pdf,image/jpeg,image/png" onChange={e => setReceipt(e.target.files?.[0] || null)} /></label><label>{t.receiptText}<textarea rows={3} value={receiptText} onChange={e => setReceiptText(e.target.value)} maxLength={4000} /></label>{error && <ErrorState message={error} />}<button className="button button-orange button-block" disabled={busy || (!receipt && !receiptText.trim())}>{busy ? <LoaderCircle className="spin" size={17} /> : <FileText size={17} />}{t.submitReceipt}</button><p className="form-footnote">{locale === 'fa' ? `مهلت نگهداری رزرو: ${result.reservation_timeout_minutes} دقیقه. پس از پایان مهلت، صندلی آزاد می‌شود.` : `Your seat is held for ${result.reservation_timeout_minutes} minutes. The seat is released when the hold expires.`}</p></form></>}
    </>}
  </div></div>;
}

function SignIn() {
  const { t, locale } = useLanguage(); const { user, login, loginPending, botLoginUrl, loading } = useAuth(); const navigate = useNavigate(); const location = useLocation();
  const [error, setError] = useState(''); const [submitting, setSubmitting] = useState(false);
  useEffect(() => { if (user) { const state = location.state as any; const destination = typeof state?.from === 'string' && state.from.startsWith('/') ? state.from : '/me'; navigate(destination, { replace: true, state: state?.resumeSignup ? { resumeSignup: true, resumeWaitlist: !!state.resumeWaitlist } : null }); } }, [user, navigate, location.state]);
  const start = async () => { setSubmitting(true); setError(''); try { await login(); } catch (e) { setError(e instanceof Error ? e.message : t.error); } finally { setSubmitting(false); } };
  return <div className="auth-layout"><div className="auth-visual"><div className="auth-orbit" /><div className="auth-brand-mark" aria-label="Panel Flow"><img className="auth-brand-image" src="/brand/panelflow-wave-dark.svg" alt=""/></div><div className="auth-visual-copy"><span>YOUR PEOPLE. YOUR PERSPECTIVE.</span><h2>Come for the topic.<br /><em>Stay for the people.</em></h2></div><div className="auth-visual-foot"><span>MEET · DISCUSS · GROW</span><span>01 / AUTHENTICATION</span></div></div><div className="auth-content"><div className="auth-card"><div className="eyebrow"><span className="eyebrow-dot" />PANEL FLOW ACCOUNT</div><h1>{t.signInTitle}</h1><p>{t.signInText}</p>{error && <ErrorState message={error} />}{loginPending ? <div className="login-pending"><LoaderCircle className="spin" size={22} /><strong>{t.waiting}</strong><span>{t.loginHint}</span>{botLoginUrl && <a className="button button-primary button-block" href={botLoginUrl} target="_blank" rel="noreferrer">{t.openBot}<ArrowUpRight size={17} /></a>}</div> : <button className="button button-orange button-block sign-in-button" onClick={start} disabled={submitting || loading}>{submitting ? <LoaderCircle className="spin" size={18} /> : <SendTelegramIcon />}{t.signIn}</button>}{!import.meta.env.VITE_TELEGRAM_BOT_USERNAME && !window.Telegram?.WebApp?.initData && <small className="form-footnote">{t.noBot}</small>}<div className="auth-trust"><ShieldCheck size={16} /><span>{locale === 'fa' ? 'ورود با تأیید مستقیم در ربات تلگرام انجام می‌شود؛ رمز جداگانه‌ای برای سایت نگهداری نمی‌شود.' : 'Your identity is verified through Telegram; the website does not maintain a separate password.'}</span></div><p className="auth-new-member">{locale === 'fa' ? 'هنوز عضو نیستی؟ حساب خود را در ربات رسمی Panel Flow بساز؛ همین حساب برای وب‌سایت هم استفاده می‌شود.' : 'New to Panel Flow? Create your account in the official Telegram bot, then use this same account here.'} <a href={`https://t.me/${(import.meta.env.VITE_TELEGRAM_BOT_USERNAME || 'PanelFlow_Bot').replace(/^@/, '')}`} target="_blank" rel="noreferrer">{locale === 'fa' ? 'شروع ثبت‌نام' : 'Start registration'}<ArrowUpRight size={13}/></a></p><Link className="text-link back-home" to="/"><ArrowLeft size={16} />{t.back}</Link></div></div></div>;
}
function SendTelegramIcon() { return <span className="telegram-glyph">➤</span>; }

function MyBookings() {
  const { t, locale } = useLanguage(); const { token } = useAuth();
  const { data, loading, error, reload } = useRequest<ApiPage<Booking>>('/me/bookings?limit=100');
  const { data: waitlist, reload: reloadWaitlist } = useRequest<ApiPage<any>>('/me/waitlist');
  const [busyId, setBusyId] = useState<number | null>(null); const [message, setMessage] = useState('');
  const [receiptBooking, setReceiptBooking] = useState<Booking | null>(null);
  const cancel = async (booking: Booking) => { if (!window.confirm(locale === 'fa' ? 'رزرو لغو شود؟' : 'Cancel this booking?')) return; setBusyId(booking.id); try { await api(`/bookings/${booking.id}/cancel`, { method: 'POST' }, token); setMessage(locale === 'fa' ? 'رزرو لغو شد.' : 'Booking cancelled.'); await reload(); } catch (e) { setMessage(e instanceof Error ? e.message : t.error); } finally { setBusyId(null); } };
  const leaveWaitlist = async (entry: any) => { if (!window.confirm(locale === 'fa' ? 'درخواست عضویت در فهرست انتظار لغو شود؟' : 'Leave this waitlist?')) return; try { await api(`/me/waitlist/${entry.id}`, { method: 'DELETE' }, token); await reloadWaitlist(); } catch (e) { setMessage(e instanceof Error ? e.message : t.error); } };
  return <div className="page-shell account-shell"><AccountHeading title={t.bookings} subtitle={locale === 'fa' ? 'رزروها و وضعیت پرداخت خود را از اینجا پیگیری کنید.' : 'Track your reservations and payment status in one place.'} />{message && <div className="notice notice-success"><CheckCircle2 size={17} />{message}<button onClick={() => setMessage('')}><X size={15} /></button></div>}{loading ? <Loading /> : error ? <ErrorState message={error} retry={reload} /> : data?.items.length ? <div className="booking-list">{data.items.map(booking => <article className="booking-row" key={booking.id}><div className="booking-date"><CalendarDays size={18} /><strong>{booking.event_date}</strong><span>{booking.event_day}</span></div><div className="booking-info"><div className="booking-title-row"><h3>{booking.event_title}</h3><StatusPill status={booking.status} /></div><p>{booking.event_venue} · {booking.event_city}</p><div className="booking-meta"><span><Users size={14} />{booking.participant_count} {t.seats}</span><span><Wallet size={14} />{formatMoney(booking.total_amount, locale)}</span>{booking.payment_status && <span><CreditCard size={14} />{statusLabel(booking.payment_status, locale)}</span>}</div></div><div className="booking-actions">{['pending_payment', 'rejected'].includes(booking.status) && <button className="button button-small button-primary" disabled={busyId === booking.id} onClick={() => setReceiptBooking(booking)}>{t.submitReceipt}</button>}{['pending_payment', 'pending_verification', 'rejected'].includes(booking.status) && <button className="text-button danger-text" disabled={busyId === booking.id} onClick={() => cancel(booking)}>{t.cancel}</button>}{booking.status === 'confirmed' && booking.total_amount === 0 && <button className="text-button danger-text" disabled={busyId === booking.id} onClick={() => cancel(booking)}>{t.cancel}</button>}{booking.status === 'confirmed' && booking.event_date_iso && <button type="button" className="button button-small button-outline" onClick={() => { if (!downloadCalendarEvent(booking)) setMessage(locale==='fa'?'تاریخ این پنل برای تقویم در دسترس نیست.':'A calendar date is not available for this panel.'); }}><CalendarPlus size={15}/>{locale==='fa'?'افزودن به تقویم':'Add to calendar'}</button>}{booking.status === 'confirmed' && <BookingMeetingDetails bookingId={booking.id} locale={locale} token={token} />}</div></article>)}</div> : <div className="empty-panel"><Ticket size={28} /><p>{t.noBookings}</p><Link to="/events" className="button button-primary">{t.explore}<ArrowUpRight size={16} /></Link></div>}{(waitlist?.items || []).length > 0 && <section className="surface-card waitlist-account"><div className="surface-heading"><div><span className="eyebrow">YOUR QUEUE</span><h2>{locale === 'fa' ? 'فهرست‌های انتظار من' : 'My waitlists'}</h2><p className="muted-copy">{locale==='fa'?'دعوت به ثبت‌نام تا زمان درج‌شده اعتبار دارد؛ دعوت، به‌تنهایی صندلی را رزرو نمی‌کند.':'An invitation is valid until the displayed expiry; it does not hold a seat by itself.'}</p></div><Users size={18} /></div><div className="shop-history">{waitlist?.items.map((entry: any) => <div className="shop-history-row waitlist-entry-row" key={entry.id}><span><strong>{entry.event_title}</strong><small>{entry.event_date} · {entry.requested_participant_count} {t.seats}</small><small>{entry.status==='invited'?(locale==='fa'?`دعوت تا ${formatDate(entry.invitation_expires_at,locale)} معتبر است`:`Invitation expires ${formatDate(entry.invitation_expires_at,locale)}`):(locale==='fa'?`جایگاه تقریبی ${entry.position}`:`Queue position ${entry.position}`)}</small></span><StatusPill status={entry.status}/><Link to={`/events/${entry.event_id}`} className="text-link">{locale==='fa'?'نمایش پنل':'Open panel'}<ArrowUpRight size={13}/></Link>{['waiting','invited'].includes(entry.status) && <button className="text-button danger-text" onClick={() => leaveWaitlist(entry)}>{locale === 'fa' ? 'لغو درخواست' : 'Leave queue'}</button>}</div>)}</div></section>}{receiptBooking && <ExistingReceiptModal booking={receiptBooking} onClose={() => setReceiptBooking(null)} onSubmitted={async () => { setReceiptBooking(null); setMessage(locale === 'fa' ? 'رسید جدید ارسال شد و در انتظار بررسی است.' : 'Your new receipt was submitted for review.'); await reload(); }} />}</div>;
}

function BookingMeetingDetails({ bookingId, locale, token }: { bookingId:number; locale:Locale; token:string|null }) {
  const [details,setDetails] = useState<any>(null); const [expanded,setExpanded] = useState(false); const [error,setError] = useState('');
  const load = async()=>{setError('');try{const row=await api<any>(`/me/bookings/${bookingId}/meeting-details`,{},token);setDetails(row);setExpanded(true);}catch(e){setError(e instanceof Error?e.message:'');}};
  return <div className="booking-meeting-access">{details && expanded ? <div className="meeting-link-released"><strong>{details.meeting_platform}</strong><a href={details.meeting_link} target="_blank" rel="noreferrer">{locale==='fa'?'ورود به جلسه':'Join meeting'}<ExternalLink size={13}/></a></div> : <button type="button" className="text-button" onClick={()=>void load()}>{locale==='fa'?'بررسی لینک جلسه':'Check meeting link'}</button>}{error && <small>{locale==='fa'?'لینک جلسه هنوز منتشر نشده است.':'Meeting link is not available yet.'}</small>}</div>;
}

function ExistingReceiptModal({ booking, onClose, onSubmitted }: { booking: Booking; onClose: () => void; onSubmitted: () => void | Promise<void> }) {
  const { t, locale } = useLanguage(); const { token } = useAuth();
  const [instructions, setInstructions] = useState<{ card_number?: string; account_name?: string } | null>(null);
  const [receipt, setReceipt] = useState<File | null>(null); const [receiptText, setReceiptText] = useState('');
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const result = booking.status === 'rejected'
          ? await api<{ payment_instructions: { card_number?: string; account_name?: string } }>(`/bookings/${booking.id}/retry-payment`, { method: 'POST' }, token)
          : await api<{ payment_instructions: { card_number?: string; account_name?: string } }>(`/bookings/${booking.id}/payment-instructions`, {}, token);
        if (alive) setInstructions(result.payment_instructions);
      } catch (e) { if (alive) setError(e instanceof Error ? e.message : t.error); }
    })();
    return () => { alive = false; };
  }, [booking.id, booking.status, token, t.error]);
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try { const form = new FormData(); if (receipt) form.append('receipt', receipt); if (receiptText.trim()) form.append('receipt_text', receiptText.trim());
      await api(`/bookings/${booking.id}/receipt`, { method: 'POST', body: form }, token); await onSubmitted();
    } catch (e) { setError(e instanceof Error ? e.message : t.error); } finally { setBusy(false); }
  };
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><div className="modal-card booking-modal"><button className="modal-close" onClick={onClose}><X size={19} /></button><div className="modal-kicker">{locale === 'fa' ? 'پرداخت رزرو' : 'BOOKING PAYMENT'}</div><h2>{booking.event_title}</h2><p className="modal-description">{formatMoney(booking.total_amount, locale)}</p>{error && <ErrorState message={error} />}{!instructions && !error ? <Loading /> : instructions && <><div className="payment-instructions"><span>{t.account}</span><strong>{instructions.account_name || '—'}</strong><span>{t.card}</span><div className="card-number-row"><strong dir="ltr">{instructions.card_number || '—'}</strong><button type="button" className="text-button" onClick={() => navigator.clipboard.writeText(instructions.card_number || '')}>{locale === 'fa' ? 'کپی' : 'Copy'}</button></div></div><form onSubmit={submit} className="stack-form"><label>{t.receipt}<input type="file" accept=".jpg,.jpeg,.png,.pdf,application/pdf,image/jpeg,image/png" onChange={e => setReceipt(e.target.files?.[0] || null)} /></label><label>{t.receiptText}<textarea rows={3} value={receiptText} onChange={e => setReceiptText(e.target.value)} maxLength={4000} /></label>{error && <ErrorState message={error} />}<button className="button button-orange button-block" disabled={busy || (!receipt && !receiptText.trim())}>{busy ? <LoaderCircle className="spin" size={17} /> : <FileText size={17} />}{t.submitReceipt}</button></form></>}</div></div>;
}
function StatusPill({ status }: { status: string }) { const { locale } = useLanguage(); const kind = status === 'confirmed' || status === 'approved' ? 'good' : ['pending_payment', 'pending_verification', 'pending'].includes(status) ? 'pending' : ['rejected', 'cancelled', 'expired'].includes(status) ? 'bad' : ''; return <span className={`status-pill ${kind}`}>{statusLabel(status, locale)}</span>; }

function SavedEvents() {
  const { t } = useLanguage(); const { token } = useAuth(); const { data, loading, error, reload } = useRequest<ApiPage<EventData>>('/me/saved-events');
  const remove = async (id: number) => { try { await api(`/me/saved-events/${id}`, { method: 'DELETE' }, token); await reload(); } catch (e) { window.alert(e instanceof Error ? e.message : t.error); } };
  return <div className="page-shell"><AccountHeading title={t.savedPanels} subtitle={t.noSaved} />{loading ? <Loading /> : error ? <ErrorState message={error} retry={reload} /> : data?.items.length ? <div className="event-grid">{data.items.map((e, i) => <div key={e.id} className="saved-card-wrap"><EventCard event={e} index={i} /><button className="remove-saved" onClick={() => remove(e.id)}><X size={14} />{t.removeSaved}</button></div>)}</div> : <div className="empty-panel"><Bookmark size={28} /><p>{t.noSaved}</p><Link to="/events" className="button button-primary">{t.explore}<ArrowUpRight size={16} /></Link></div>}</div>;
}

function MemberDashboard() {
  const { locale } = useLanguage(); const { user } = useAuth();
  const { data, loading, error, reload } = useRequest<any>('/me/activity');
  if (loading) return <Loading/>;
  if (error) return <div className="page-shell"><ErrorState message={error} retry={reload}/></div>;
  const counts = data?.counts || {};
  return <div className="page-shell account-shell member-dashboard">
    <AccountHeading title={locale==='fa'?'داشبورد من':'My dashboard'} subtitle={locale==='fa'?`سلام ${user?.display_name || user?.first_name || 'دوست پنل فلو'}؛ مسیر گفتگوهای خود را از اینجا دنبال کنید.`:'Your upcoming panels, saved discoveries, and followed communities in one place.'}/>
    <div className="stats-grid dashboard-stats"><StatTile icon={<CalendarDays/>} label={locale==='fa'?'رزروهای پیش‌رو':'Upcoming bookings'} value={counts.upcoming_bookings||0}/><StatTile icon={<Bookmark/>} label={locale==='fa'?'پنل‌های ذخیره‌شده':'Saved panels'} value={counts.saved_panels||0}/><StatTile icon={<Compass/>} label={locale==='fa'?'پنل‌های دیده‌شده':'Recently viewed'} value={counts.recently_viewed||0}/><StatTile icon={<Heart/>} label={locale==='fa'?'علایق دنبال‌شده':'Followed topics'} value={counts.followed_topics||0}/></div>
    <section className="surface-card dashboard-section"><div className="surface-heading"><div><span className="eyebrow">YOUR NEXT CONVERSATIONS</span><h2>{locale==='fa'?'رزروهای پیش‌رو':'Upcoming bookings'}</h2></div><Link className="text-link" to="/my-bookings">{locale==='fa'?'همه رزروها':'All bookings'}<ArrowUpRight size={15}/></Link></div>
      {data?.upcoming_bookings?.length ? <div className="dashboard-booking-list">{data.upcoming_bookings.map((row:any)=><article className="dashboard-booking-row" key={row.id}><div className="dashboard-booking-date"><CalendarDays size={18}/><strong>{row.event_date}</strong><small>{row.event_day}</small></div><div className="dashboard-booking-info"><Link to={`/events/${row.event_id}`}><strong>{row.event_title}</strong></Link><small>{row.event_start_time} · {row.event_venue} · {row.event_city}</small><StatusPill status={row.status}/></div><Link className="button button-small button-outline" to={`/events/${row.event_id}`}>{locale==='fa'?'جزئیات':'Details'}<ArrowUpRight size={14}/></Link></article>)}</div> : <div className="empty-inline">{locale==='fa'?'رزرو پیش‌رویی ندارید.':'No upcoming bookings yet.'} <Link to="/events">{locale==='fa'?'کشف پنل‌ها':'Discover panels'}</Link></div>}
    </section>
    <section className="section dashboard-section"><div className="section-heading"><div><div className="eyebrow">SAVED FOR LATER</div><h2>{locale==='fa'?'پنل‌های ذخیره‌شده':'Saved panels'}<span className="heading-period">.</span></h2></div><Link to="/saved" className="text-link">{locale==='fa'?'همه موارد':'View all'}<ArrowUpRight size={15}/></Link></div>{data?.saved_panels?.length ? <div className="event-grid">{data.saved_panels.map((event:EventData,index:number)=><EventCard key={event.id} event={event} index={index}/>)}</div> : <div className="empty-inline">{locale==='fa'?'هنوز پنلی ذخیره نکرده‌اید.':'Save a panel to keep it here for later.'}</div>}</section>
    <section className="section dashboard-section"><div className="section-heading"><div><div className="eyebrow">PICK UP WHERE YOU LEFT OFF</div><h2>{locale==='fa'?'اخیراً مشاهده‌شده':'Recently viewed'}<span className="heading-period">.</span></h2></div></div>{data?.recently_viewed?.length ? <div className="event-grid">{data.recently_viewed.map((event:EventData,index:number)=><EventCard key={event.id} event={event} index={index}/>)}</div> : <div className="empty-inline">{locale==='fa'?'پنلی برای نمایش وجود ندارد.':'Panels you open while signed in will appear here.'}</div>}</section>
    <section className="surface-card dashboard-section"><div className="surface-heading"><div><span className="eyebrow">YOUR INTERESTS</span><h2>{locale==='fa'?'موضوع‌ها و سازمان‌های دنبال‌شده':'Followed topics & organizations'}</h2></div><Link to="/preferences" className="text-link">{locale==='fa'?'مدیریت علایق':'Manage interests'}<ArrowUpRight size={15}/></Link></div>
      <div className="dashboard-follow-groups"><div><strong>{locale==='fa'?'موضوع‌ها':'Topics'}</strong><div className="brand-chip-row">{(data?.followed_topics||[]).map((key:string)=><Link className="brand-chip" key={key} to={`/events?topic=${encodeURIComponent(key)}`}>{TOPIC_LABELS[key]?.[locale] || key}</Link>)}{!data?.followed_topics?.length && <small className="muted-copy">{locale==='fa'?'موضوعی دنبال نمی‌کنید.':'No topics followed yet.'}</small>}</div></div><div><strong>{locale==='fa'?'سازمان‌ها':'Organizations'}</strong><div className="brand-chip-row">{(data?.followed_organizations||[]).map((org:any)=><Link className="brand-chip" key={org.id} to={`/organizations/${org.slug}`}>{org.name}<ArrowUpRight size={12}/></Link>)}{!data?.followed_organizations?.length && <small className="muted-copy">{locale==='fa'?'سازمانی دنبال نمی‌کنید.':'No organizations followed yet.'}</small>}</div></div></div>
    </section>
    <AttendanceHistoryPanel />
  </div>;
}

function AttendanceHistoryPanel() {
  const {locale}=useLanguage(); const fa=locale==='fa';
  const {data,loading,error,reload}=useRequest<any>('/me/attendance');
  return <section className="surface-card dashboard-section attendance-history-member"><div className="surface-heading"><div><span className="eyebrow">VERIFIED PARTICIPATION</span><h2>{fa?'سابقه حضور تأییدشده':'Verified attendance history'}</h2><p>{fa?'فقط حضورهایی نمایش داده می‌شوند که با QR، کد ورود یا توسط میزبان ثبت شده‌اند.':'Only attendance explicitly confirmed by QR, check-in code or an authorized host appears here.'}</p></div><CheckCircle2 size={19}/></div>{loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:data?.items?.length?<div className="attendance-history-list">{data.items.map((row:any)=><article key={row.event_id}><span className="attendance-history-check"><Check size={16}/></span><div><Link to={`/events/${row.event_id}`}><strong>{row.event_title}</strong></Link><small>{row.event_date} · {row.city} · {(row.participants||[]).length} {fa?'شرکت‌کننده':'attended'}</small><small>{(row.participants||[]).map((person:any)=>person.name).join('، ')}</small></div></article>)}</div>:<div className="empty-inline">{fa?'هنوز حضور تأییدشده‌ای برای حساب شما ثبت نشده است.':'No verified attendance has been recorded for your account yet.'}</div>}</section>;
}

function Profile() {
  const { t, locale } = useLanguage(); const { token, user, refreshUser } = useAuth();
  const { data, loading, error, reload } = useRequest<any>('/me/overview');
  const [displayName, setDisplayName] = useState(''); const [saving, setSaving] = useState(false); const [feedback, setFeedback] = useState('');
  const [eligibleReviews, setEligibleReviews] = useState<any[]>([]); const [reviewDrafts, setReviewDrafts] = useState<Record<number, { rating: number; text: string; discussion_quality?: number | null; moderator_rating?: number | null; topic_relevance?: number | null; would_attend_again?: boolean | null }>>({}); const [reviewBusy, setReviewBusy] = useState<number | null>(null);
  useEffect(() => { if (data?.profile) setDisplayName(data.profile.display_name || ''); }, [data]);
  const loadEligibleReviews = useCallback(async () => { try { const result = await api<ApiPage<any>>('/me/reviews/eligible', {}, token); setEligibleReviews(result.items); } catch { setEligibleReviews([]); } }, [token]);
  useEffect(() => { void loadEligibleReviews(); }, [loadEligibleReviews]);
  const submitReview = async (eventId: number) => { const draft = reviewDrafts[eventId]; if (!draft) return; setReviewBusy(eventId); setFeedback(''); try { await api('/me/reviews', { method: 'POST', body: JSON.stringify({ event_id: eventId, rating: draft.rating, text: draft.text, discussion_quality: draft.discussion_quality ?? null, moderator_rating: draft.moderator_rating ?? null, topic_relevance: draft.topic_relevance ?? null, would_attend_again: draft.would_attend_again ?? null }) }, token); setEligibleReviews(prev => prev.filter(row => row.id !== eventId)); setFeedback(locale === 'fa' ? 'نظر شما برای بررسی ارسال شد.' : 'Your review was submitted for moderation.'); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } finally { setReviewBusy(null); } };
  const requestShopOffer = async (offer: any) => { try { await api('/me/shop/requests', { method: 'POST', body: JSON.stringify({ offer_id: offer.id, expected_revision: offer.revision || 1 }) }, token); await reload(); setFeedback(locale === 'fa' ? 'درخواست فروشگاه ثبت شد؛ XP تا بررسی مدیر رزرو می‌شود.' : 'Your shop request was submitted. XP is reserved pending review.'); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } };
  const cancelShopRequest = async (requestId: number) => { try { await api(`/me/shop/requests/${requestId}/cancel`, { method: 'POST' }, token); await reload(); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } };
  const saveName = async (e: FormEvent) => { e.preventDefault(); setSaving(true); setFeedback(''); try { await api('/me/profile', { method: 'PATCH', body: JSON.stringify({ display_name: displayName }) }, token); await refreshUser(); await reload(); setFeedback(locale === 'fa' ? 'نام نمایشی به‌روزرسانی شد.' : 'Display name updated.'); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } finally { setSaving(false); } };
  if (loading) return <Loading />; if (error) return <div className="page-shell"><ErrorState message={error} retry={reload} /></div>;
  const stats = data?.stats || {};
  return <div className="page-shell account-shell"><div className="profile-hero"><div className="profile-avatar">{(user?.display_name || user?.first_name || 'P').charAt(0).toUpperCase()}</div><div><span className="eyebrow"><span className="eyebrow-dot" />PANEL FLOW MEMBER</span><h1>{data?.profile?.display_name || data?.profile?.first_name || 'Welcome back'}</h1><p>{data?.profile?.username ? `@${data.profile.username}` : '—'} · {locale === 'fa' ? 'عضو جامعه از' : 'Member since'} {formatDate(data?.profile?.created_at, locale)}</p></div><div className="profile-xp"><span>{t.availableXP}</span><strong><Zap size={19} />{data?.available_shop_xp ?? 0}</strong></div></div>
    <div className="stats-grid"><StatTile icon={<Ticket />} label={locale === 'fa' ? 'پنل‌های برگزارشده' : 'Panels attended'} value={stats.attended_panels || 0} /><StatTile icon={<Sparkles />} label={locale === 'fa' ? 'چالش‌ها' : 'Challenges'} value={stats.challenge_participations || 0} /><StatTile icon={<Users />} label={t.referrals} value={stats.referrals || 0} /><StatTile icon={<Award />} label={t.badges} value={data?.badges?.length || 0} /></div>
    <div className="profile-columns"><section className="surface-card"><div className="surface-heading"><div><span className="eyebrow">ACCOUNT SETTINGS</span><h2>{t.profile}</h2></div><LockKeyhole size={18} /></div><form className="stack-form" onSubmit={saveName}><label>{locale === 'fa' ? 'نام نمایشی' : 'Display name'}<input value={displayName} onChange={e => setDisplayName(e.target.value)} minLength={2} maxLength={255} required /></label><button className="button button-primary" disabled={saving}>{saving ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}{locale === 'fa' ? 'ذخیره تغییرات' : 'Save changes'}</button>{feedback && <span className="form-footnote">{feedback}</span>}</form><div className="referral-box"><div><span>{locale === 'fa' ? 'کد دعوت شما' : 'Your referral code'}</span><strong>{data?.referral_code}</strong></div><button className="button button-small button-outline" onClick={() => navigator.clipboard.writeText(String(data?.referral_code || ''))}>{locale === 'fa' ? 'کپی کد' : 'Copy code'}</button></div></section>
      <section className="surface-card"><div className="surface-heading"><div><span className="eyebrow">YOUR JOURNEY</span><h2>{t.recentXP}</h2></div><Zap size={18} /></div><div className="xp-list">{(data?.recent_xp || []).length ? data.recent_xp.map((row: any, i: number) => <div className="xp-row" key={`${row.type}-${i}`}><span className="xp-icon"><Zap size={15} /></span><span><strong>{row.note || row.type.replaceAll('_', ' ')}</strong><small>{formatDate(row.created_at, locale)}</small></span><b className={row.points < 0 ? 'negative' : ''}>{row.points > 0 ? '+' : ''}{row.points} XP</b></div>) : <p className="muted-copy">—</p>}</div></section></div>
    <section className="surface-card account-extra-section"><div className="surface-heading"><div><span className="eyebrow">REWARDS CATALOGUE</span><h2>{locale === 'fa' ? 'فروشگاه امتیاز' : 'XP Shop'}</h2></div><Award size={19} /></div>{data?.shop_enabled ? <>{(data?.shop_offers || []).length ? <div className="shop-offer-grid">{data.shop_offers.map((offer: any) => <article className="shop-offer" key={offer.id}><span className="offer-discount">{offer.discount_percent}%</span><h3>{offer.title}</h3>{offer.description && <p>{offer.description}</p>}<div className="offer-cost">{offer.xp_cost} XP</div><button className="button button-orange button-small" disabled={(data?.available_shop_xp || 0) < offer.xp_cost} onClick={() => requestShopOffer(offer)}>{locale === 'fa' ? 'درخواست پیشنهاد' : 'Request offer'}</button></article>)}</div> : <p className="muted-copy">{locale === 'fa' ? 'در حال حاضر پیشنهاد فعالی وجود ندارد.' : 'There are no active offers right now.'}</p>}</> : <p className="muted-copy">{locale === 'fa' ? 'فروشگاه امتیاز در حال حاضر غیرفعال است.' : 'The XP Shop is currently disabled.'}</p>}{(data?.shop_history || []).length > 0 && <div className="shop-history"><h3>{locale === 'fa' ? 'درخواست‌های اخیر' : 'Recent requests'}</h3>{data.shop_history.map((row: any) => <div className="shop-history-row" key={row.id}><span><strong>{row.title}</strong><small>{row.xp_cost} XP · {formatDate(row.created_at, locale)}</small></span><span>{row.status_label}</span>{row.status === 'pending' && <button className="text-button danger-text" onClick={() => cancelShopRequest(row.id)}>{t.cancel}</button>}</div>)}</div>}</section>
    <section className="surface-card account-extra-section"><div className="surface-heading"><div><span className="eyebrow">KEEP THE CONVERSATION GOING</span><h2>{locale === 'fa' ? 'ثبت نظر درباره پنل‌ها' : 'Review past panels'}</h2></div><MessageSquare size={19} /></div>{eligibleReviews.length ? <div className="eligible-review-list">{eligibleReviews.map((row: any) => <article className="eligible-review" key={row.id}><div><strong>{row.title}</strong><small>{row.date} · {row.venue}</small></div><label>{locale === 'fa' ? 'امتیاز' : 'Rating'}<select value={reviewDrafts[row.id]?.rating || 5} onChange={e => setReviewDrafts(prev => ({ ...prev, [row.id]: { ...prev[row.id], rating: Number(e.target.value), text: prev[row.id]?.text || '' } }))}>{[5,4,3,2,1].map(n => <option value={n} key={n}>{n} / 5</option>)}</select></label><div className="review-structured-grid">{([['discussion_quality', locale==='fa'?'کیفیت گفت‌وگو':'Discussion quality'],['moderator_rating', locale==='fa'?'عملکرد مدیر گفت‌وگو':'Moderator'],['topic_relevance', locale==='fa'?'ارتباط موضوع با انتظار شما':'Topic relevance']] as const).map(([key,label])=><label key={key}>{label}<select value={reviewDrafts[row.id]?.[key] ?? ''} onChange={e=>setReviewDrafts(prev=>({...prev,[row.id]:{rating:prev[row.id]?.rating||5,text:prev[row.id]?.text||'',...prev[row.id],[key]:e.target.value?Number(e.target.value):null}}))}><option value="">{locale==='fa'?'بدون امتیاز':'Skip'}</option>{[5,4,3,2,1].map(n=><option value={n} key={n}>{n} / 5</option>)}</select></label>)}<label>{locale==='fa'?'دوباره شرکت می‌کنید؟':'Would you attend again?'}<select value={reviewDrafts[row.id]?.would_attend_again == null ? '' : reviewDrafts[row.id]?.would_attend_again ? 'yes' : 'no'} onChange={e=>setReviewDrafts(prev=>({...prev,[row.id]:{rating:prev[row.id]?.rating||5,text:prev[row.id]?.text||'',...prev[row.id],would_attend_again:e.target.value===''?null:e.target.value==='yes'}}))}><option value="">{locale==='fa'?'بدون پاسخ':'Skip'}</option><option value="yes">{locale==='fa'?'بله':'Yes'}</option><option value="no">{locale==='fa'?'خیر':'No'}</option></select></label></div><textarea rows={3} minLength={10} maxLength={2000} required value={reviewDrafts[row.id]?.text || ''} placeholder={locale === 'fa' ? 'تجربه خود را بنویسید…' : 'Share your experience…'} onChange={e => setReviewDrafts(prev => ({ ...prev, [row.id]: { ...prev[row.id], rating: prev[row.id]?.rating || 5, text: e.target.value } }))} /><button className="button button-primary button-small" disabled={reviewBusy === row.id || (reviewDrafts[row.id]?.text || '').trim().length < 10} onClick={() => submitReview(row.id)}>{reviewBusy === row.id ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}{locale === 'fa' ? 'ارسال نظر' : 'Submit review'}</button></article>)}</div> : <p className="muted-copy">{locale === 'fa' ? 'پنل تکمیل‌شده‌ای برای ثبت نظر جدید در دسترس نیست.' : 'No completed panels are awaiting your review.'}</p>}</section>
    <div className="quick-account-links"><Link to="/dashboard"><Compass size={18}/>{locale==='fa'?'داشبورد من':'My dashboard'}<ArrowUpRight size={15}/></Link><Link to="/my-bookings"><Ticket size={18} />{t.bookings}<ArrowUpRight size={15} /></Link><Link to="/saved"><Bookmark size={18} />{t.savedPanels}<ArrowUpRight size={15} /></Link><Link to="/community"><Trophy size={18} />{t.community}<ArrowUpRight size={15} /></Link></div>
  </div>;
}
function StatTile({ icon, label, value }: { icon: ReactNode; label: string; value: string | number }) { return <div className="stat-tile"><span>{icon}</span><strong>{value}</strong><small>{label}</small></div>; }
function AccountHeading({ title, subtitle }: { title: string; subtitle: string }) { return <div className="account-heading"><div><div className="eyebrow"><span className="eyebrow-dot" />YOUR PANEL FLOW</div><h1>{title}<span className="heading-period">.</span></h1><p>{subtitle}</p></div><div className="account-heading-mark">PF</div></div>; }

function CityHubPreview() {
  const { locale } = useLanguage();
  const { data, loading } = useRequest<ApiPage<CityData>>('/cities');
  const cities = data?.items || [];
  return <section className="section city-hub-preview" data-reveal><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-dot" />{locale === 'fa' ? 'از شهر شما تا سراسر ایران' : 'FROM YOUR CITY TO THE WHOLE COUNTRY'}</div><h2>{locale === 'fa' ? 'گفت‌وگو در نقشه ایران' : 'The conversation is nationwide'}<span className="heading-period">.</span></h2><p className="section-side-copy">{locale === 'fa' ? 'شهرت را انتخاب کن و پنل‌های همان‌جا را پیدا کن.' : 'Choose a city to discover the panels happening there.'}</p></div><Link to="/cities" className="text-link">{locale === 'fa' ? 'دیدن همه شهرها' : 'Explore all cities'}<ArrowUpRight size={17}/></Link></div>{loading ? <Loading/> : <div className="city-preview-grid"><IranCityMap cities={cities} locale={locale} compact/><div className="city-preview-list">{cities.filter(city => city.event_count > 0).slice(0,5).map(city => <Link to={`/cities/${city.slug}`} key={city.id} className="city-preview-row"><span><strong>{locale === 'fa' ? city.name_fa : city.name_en}</strong><small>{locale === 'fa' ? city.province_fa : city.province_en}</small></span><b>{city.upcoming_event_count ?? city.event_count}</b><ArrowUpRight size={16}/></Link>)}{!cities.some(city => city.event_count > 0) && <p className="agenda-empty">{locale === 'fa' ? 'به‌زودی اولین پنل‌ها در شهرهای بیشتری منتشر می‌شوند.' : 'New panels will appear here as hosts join the network.'}</p>}<Link to="/cities" className="button button-outline button-block">{locale === 'fa' ? 'کاوش نقشه ایران' : 'Explore the Iran map'}<MapPin size={16}/></Link></div></div>}</section>;
}

function Cities() {
  const { locale } = useLanguage(); const [query, setQuery] = useState('');
  const { data, loading, error, reload } = useRequest<ApiPage<CityData>>('/cities');
  const cities = (data?.items || []).filter(city => `${city.name_fa} ${city.name_en} ${city.province_fa} ${city.province_en}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="page-shell cities-shell"><div className="page-intro"><div className="eyebrow"><span className="eyebrow-dot"/>{locale === 'fa' ? 'شبکه سراسری پنل فلو' : 'PANEL FLOW · IRAN'}</div><h1>{locale === 'fa' ? 'هر شهر، یک گفت‌وگوی تازه' : 'A country full of conversations'}<span className="heading-period">.</span></h1><p>{locale === 'fa' ? 'روی شهر موردنظرت بزن تا پنل‌های منتشرشده در آن شهر را ببینی.' : 'Select a city to explore the panels and hosts in that area.'}</p></div>{loading ? <Loading/> : error ? <ErrorState message={error} retry={reload}/> : <><IranCityMap cities={cities} locale={locale}/><label className="search-box city-search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={locale==='fa'?'جست‌وجوی شهر یا استان…':'Search cities or provinces…'}/></label><div className="city-directory-grid">{cities.map(city=><Link to={`/cities/${city.slug}`} key={city.id} className="city-directory-card"><span className="city-directory-pin"><MapPin size={17}/></span><span><strong>{locale==='fa'?city.name_fa:city.name_en}</strong><small>{locale==='fa'?city.province_fa:city.province_en}</small></span><b>{city.upcoming_event_count ?? city.event_count} {locale==='fa'?'پنل پیش‌رو':'upcoming'}</b><small>{city.organization_count||0} {locale==='fa'?'سازمان':'organizations'}</small><ArrowUpRight size={16}/></Link>)}</div><div className="host-invite-card"><div><strong>{locale==='fa'?'در شهر شما هم پنل برگزار می‌شود؟':'Want to host panels in your city?'}</strong><p>{locale==='fa'?'برای پیوستن به شبکه میزبان‌های پنل فلو با تیم ما در ارتباط باشید.':'Talk to the team about joining the Panel Flow host network.'}</p></div><a className="button button-outline" href="https://t.me/PanelFlowAdmin" target="_blank" rel="noreferrer">{locale==='fa'?'درخواست همکاری':'Talk to the team'}<ArrowUpRight size={16}/></a></div></>}</div>;
}

function CityDetail() {
  const { slug = '' } = useParams(); const { locale } = useLanguage();
  const { data, loading, error, reload } = useRequest<{city:CityData;items:EventData[];organizations:any[];total:number;recent_completed_events?:EventData[];popular_topics?:{key:string;panel_count:number}[]}>(`/cities/${slug}`);
  useEffect(() => { if (data?.city) setPageMetadata(`${locale==='fa'?data.city.name_fa:data.city.name_en} | Panel Flow`, locale==='fa'?`پنل‌های گفت‌وگو در ${data.city.name_fa}؛ رویدادهای منتشرشده و میزبان‌های این شهر.`:`Discover published discussion panels in ${data.city.name_en}.`, `/cities/${slug}`); }, [data,locale,slug]);
  if (loading) return <Loading/>; if (error || !data) return <div className="page-shell"><ErrorState message={error||'City not found'} retry={reload}/><Link to="/cities" className="text-link">{locale==='fa'?'بازگشت به نقشه':'Back to cities'}<ArrowUpRight size={16}/></Link></div>;
  const cityName = locale==='fa' ? data.city.name_fa : data.city.name_en;
  return <div className="page-shell city-detail-shell"><Link to="/cities" className="back-link"><ArrowLeft size={16}/>{locale==='fa'?'همه شهرها':'All cities'}</Link>
    <div className="city-detail-heading"><div className="eyebrow"><span className="eyebrow-dot"/>{locale==='fa'?'شهر میزبان':'HOST CITY'}</div><h1>{cityName}<span className="heading-period">.</span></h1><p>{locale==='fa'?data.city.province_fa:data.city.province_en} · {data.total} {locale==='fa'?'پنل منتشرشده':'published panels'}</p></div>
    <IranCityMap cities={[data.city]} locale={locale} selectedSlug={slug} compact/>
    <div className="city-discovery-stats"><StatTile icon={<CalendarDays/>} label={locale==='fa'?'پنل‌های پیش‌رو':'Upcoming panels'} value={data.city.upcoming_event_count ?? 0}/><StatTile icon={<CheckCircle2/>} label={locale==='fa'?'پنل‌های برگزارشده':'Completed panels'} value={data.city.completed_event_count ?? 0}/><StatTile icon={<Users/>} label={locale==='fa'?'سازمان‌های فعال':'Active organizations'} value={data.city.organization_count ?? data.organizations.length}/><StatTile icon={<Zap/>} label={locale==='fa'?'به‌روزرسانی‌های ماه اخیر':'Updates this month'} value={data.city.recent_activity_count ?? 0}/></div>
    {data.city.is_founding_city && <div className="founding-city-banner"><Sparkles size={17}/><span>{locale==='fa'?'مشهد، شهر بنیان‌گذار پنل فلو':'Mashhad · Panel Flow founding city'}</span></div>}
    {(data.popular_topics||[]).length>0 && <section className="surface-card city-topics-section"><div className="surface-heading"><div><span className="eyebrow">DISCUSSION INTERESTS</span><h2>{locale==='fa'?'موضوع‌های پررنگ این شهر':'Popular topics in this city'}</h2><p>{locale==='fa'?'بر اساس پنل‌های منتشرشده و برگزارشده در ۱۲ ماه گذشته.':'Based on public panels published or completed in the last 12 months.'}</p></div></div><div className="brand-chip-row">{(data.popular_topics||[]).map(row=><Link className="brand-chip" key={row.key} to={`/events?city_id=${data.city.id}&topic=${encodeURIComponent(row.key)}`}>{TOPIC_LABELS[row.key]?.[locale]||row.key}<small>{row.panel_count}</small></Link>)}</div></section>}
    {data.organizations?.length > 0 && <section className="city-organizations"><div className="section-heading"><h2>{locale==='fa'?'سازمان‌های فعال در این شهر':'Organizations in this city'}<span className="heading-period">.</span></h2><span className="count-badge">{data.organizations.length}</span></div><div className="organization-card-grid">{data.organizations.map((org:any)=><article className="organization-card" key={org.id}><div className="organization-card-top"><strong>{org.name}</strong>{org.is_platform_founder && <span className="founder-tag">{locale==='fa'?'بنیان‌گذار':'Founding organization'}</span>}</div>{org.description && <p>{org.description}</p>}<div className="brand-chip-row">{org.brands.map((brand:any)=><Link className="brand-chip" key={brand.id} to={`/organizations/${org.slug}/brands/${brand.slug}`}>{brand.name}<ArrowUpRight size={13}/></Link>)}</div><Link className="text-link" to={`/organizations/${org.slug}`}>{locale==='fa'?'نمایش سازمان':'View organization'}<ArrowUpRight size={15}/></Link></article>)}</div></section>}
    <div className="section-heading city-events-heading"><h2>{locale==='fa'?'پنل‌های پیش‌رو':'Upcoming panels'}<span className="heading-period">.</span></h2><Link to={`/events?city_id=${data.city.id}`} className="text-link">{locale==='fa'?'همه فیلترهای شهر':'Explore this city'}<ArrowUpRight size={15}/></Link></div>
    {data.items.length?<div className="event-grid full-event-grid">{data.items.map((event,index)=><EventCard key={event.id} event={{...event,city:cityName}} index={index}/>)}</div>:<div className="empty-panel"><CalendarDays size={28}/><p>{locale==='fa'?'هنوز پنل منتشرشده‌ای در این شهر وجود ندارد.':'No published panels in this city yet.'}</p></div>}
    {(data.recent_completed_events||[]).length>0 && <section className="section city-past-panels"><div className="section-heading"><div><div className="eyebrow">PAST CONVERSATIONS</div><h2>{locale==='fa'?'پنل‌های برگزارشده اخیر':'Recently completed panels'}<span className="heading-period">.</span></h2></div></div><div className="event-grid">{(data.recent_completed_events||[]).map((event,index)=><EventCard key={event.id} event={{...event,city:cityName}} index={index}/>)}</div></section>}
  </div>;
}


function SeriesDirectoryPage() {
  const {locale}=useLanguage(); const fa=locale==='fa';
  const {data,loading,error,reload}=useRequest<ApiPage<any>>('/series');
  useEffect(()=>setPageMetadata(fa?'مجموعه گفت‌وگوها | پنل فلو':'Discussion series | Panel Flow',fa?'پنل‌های مرتبط را در مسیرهای گفت‌وگویی دنبال کنید.':'Explore connected discussion panels, organized into a sequence.', '/series'),[fa]);
  return <div className="page-shell series-page"><div className="page-intro"><div className="eyebrow"><span className="eyebrow-dot"/>PANEL FLOW · DISCUSSION SERIES</div><h1>{fa?'گفت‌وگو، در چند فصل':'Conversations that continue'}<span className="heading-period">.</span></h1><p>{fa?'مجموعه‌هایی از پنل‌های مرتبط را به ترتیب دنبال کنید؛ هر نشست بخشی از یک مسیر بزرگ‌تر است.':'Follow connected panels in sequence. Each session is part of a larger conversation.'}</p></div>{loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:data?.items?.length?<div className="series-directory-grid">{data.items.map((series:any)=><Link className="series-directory-card" key={series.id} to={`/series/${series.slug}`}><span className="series-card-kicker">{fa?'مجموعه گفت‌وگو':'DISCUSSION SERIES'} · {series.event_count} {fa?'پنل':'panels'}</span><h2>{series.title}</h2>{series.description&&<p>{series.description}</p>}<div className="series-mini-events">{(series.events||[]).map((event:any,index:number)=><span key={event.id}><b>{String(index+1).padStart(2,'0')}</b>{event.title}<small>{event.date} · {event.city}</small></span>)}</div><span className="text-link">{fa?'مشاهده مسیر':'Explore this series'}<ArrowUpRight size={15}/></span></Link>)}</div>:<div className="empty-panel"><ListOrdered size={28}/><p>{fa?'هنوز مجموعه عمومی منتشر نشده است.':'No public discussion series have been published yet.'}</p><Link className="text-link" to="/events">{fa?'کشف پنل‌ها':'Discover panels'}<ArrowUpRight size={15}/></Link></div>}</div>;
}

function SeriesDetailPage() {
  const {slug=''}=useParams(); const {locale}=useLanguage(); const fa=locale==='fa';
  const {data,loading,error,reload}=useRequest<any>(`/series/${slug}`);
  useEffect(()=>{if(data)setPageMetadata(`${data.title} | Panel Flow`,data.description||'A connected series of Panel Flow discussions.',`/series/${slug}`);},[data,slug]);
  if(loading)return <Loading/>;if(error||!data)return <div className="page-shell"><ErrorState message={error||'Series not found'} retry={reload}/><Link className="text-link" to="/series">{fa?'همه مجموعه‌ها':'All series'}<ArrowUpRight size={15}/></Link></div>;
  return <div className="page-shell series-detail-page"><Link className="back-link" to="/series"><ArrowLeft size={16}/>{fa?'همه مجموعه‌ها':'All series'}</Link><div className="series-detail-hero"><div className="eyebrow">PANEL FLOW · DISCUSSION SERIES</div><h1>{data.title}<span className="heading-period">.</span></h1>{data.description&&<p>{data.description}</p>}<span className="count-badge">{data.events?.length||0} {fa?'پنل در این مسیر':'sessions in this series'}</span></div><div className="series-timeline">{(data.events||[]).map((event:EventData,index:number)=><article className="series-timeline-item" key={event.id}><span className="series-timeline-number">{String(index+1).padStart(2,'0')}</span><div className="series-timeline-content"><div className="eyebrow">{fa?`جلسه ${index+1}`:`SESSION ${index+1}`}</div><h2>{event.title}</h2><p>{event.date} · {event.start_time} · {event.city}</p><StatusPill status={event.status}/><Link className="button button-small button-outline" to={`/events/${event.id}`}>{fa?'جزئیات و ثبت‌نام':'Details & registration'}<ArrowUpRight size={14}/></Link></div></article>)}</div></div>;
}

function OrganizationFollowButton({ organizationId }: { organizationId: number }) {
  const { locale } = useLanguage(); const { user, token } = useAuth(); const navigate = useNavigate();
  const { data, reload } = useRequest<{topics:string[];organizations:{id:number}[]}>('/me/follows', Boolean(user && token));
  const [busy, setBusy] = useState(false);
  const following = (data?.organizations || []).some(row => Number(row.id) === organizationId);
  const toggle = async () => {
    if (!user || !token) { navigate('/sign-in', { state: { from: window.location.pathname } }); return; }
    setBusy(true);
    try { await api(`/me/follows/organizations/${organizationId}`, { method: following ? 'DELETE' : 'PUT' }, token); await reload(); }
    catch (err) { window.alert(err instanceof Error ? err.message : 'Request failed'); }
    finally { setBusy(false); }
  };
  return <button type="button" className={`button ${following ? 'button-outline' : 'button-orange'}`} onClick={() => void toggle()} disabled={busy} aria-pressed={following}>
    {busy ? <LoaderCircle className="spin" size={16}/> : following ? <Check size={16}/> : <Plus size={16}/>} {following ? (locale==='fa'?'دنبال می‌کنید':'Following') : (locale==='fa'?'دنبال‌کردن سازمان':'Follow organization')}
  </button>;
}

function OrganizationPage() {
  const { slug = '' } = useParams(); const { locale } = useLanguage();
  const { data, loading, error, reload } = useRequest<any>(`/organizations/${slug}`);
  useEffect(() => { if (data?.organization) setPageMetadata(`${data.organization.name} | Panel Flow`, data.organization.description || 'Organization profile on Panel Flow.', `/organizations/${slug}`); }, [data, locale, slug]);
  if (loading) return <Loading/>;
  if (error || !data) return <div className="page-shell"><ErrorState message={error || 'Organization not found'} retry={reload}/></div>;
  return <div className="page-shell organization-page"><Link to="/cities" className="back-link"><ArrowLeft size={16}/>{locale==='fa'?'بازگشت به شهرها':'Explore cities'}</Link><div className="organization-page-hero"><div className="organization-profile-heading">{data.organization.logo_url ? <img className="organization-profile-logo" src={data.organization.logo_url} alt={`${data.organization.name} logo`} loading="lazy"/> : <div className="organization-profile-logo organization-profile-logo-fallback" aria-hidden="true">{data.organization.name.slice(0,1)}</div>}<div><div className="eyebrow"><span className="eyebrow-dot"/>PANEL FLOW NETWORK</div><h1>{data.organization.name}<span className="heading-period">.</span></h1></div></div><p>{data.organization.description || (locale==='fa'?'سازمان عضو شبکه ملی پنل فلو.':'An organization in the Panel Flow national network.')}</p><div className="organization-profile-actions"><OrganizationFollowButton organizationId={Number(data.organization.id)}/>{data.organization.verified && <span className="verified-organization"><ShieldCheck size={15}/>{locale==='fa'?'سازمان تأییدشده':'Verified organization'}</span>}{data.organization.is_platform_founder && <span className="founder-tag">{locale==='fa'?'سازمان بنیان‌گذار پنل فلو':'Panel Flow founding organization'}</span>}</div><div className="organization-profile-stats"><span><strong>{data.organization.followers_count || 0}</strong>{locale==='fa'?'دنبال‌کننده':'Followers'}</span><span><strong>{data.organization.panels_count || 0}</strong>{locale==='fa'?'پنل برگزارشده':'Published panels'}</span><span><strong>{data.organization.active_city_count || 0}</strong>{locale==='fa'?'شهر فعال':'Active cities'}</span></div></div><section className="section"><div className="section-heading"><h2>{locale==='fa'?'برندها':'Brands'}<span className="heading-period">.</span></h2></div>{data.brands.length ? <div className="organization-card-grid">{data.brands.map((brand:any)=><Link className="organization-card brand-profile-card" key={brand.id} to={`/organizations/${slug}/brands/${brand.slug}`}><strong>{brand.name}</strong><p>{brand.description || ''}</p><span className="text-link">{locale==='fa'?'نمایش برند':'View brand'}<ArrowUpRight size={15}/></span></Link>)}</div> : <div className="empty-inline">{locale==='fa'?'هنوز برندی منتشر نشده است.':'No published brands yet.'}</div>}</section><section className="section"><div className="section-heading"><h2>{locale==='fa'?'شهرهای فعالیت':'Operating cities'}</h2></div><div className="brand-chip-row">{data.cities.map((city:any)=><Link className="brand-chip" key={city.id} to={`/cities/${city.slug}`}>{locale==='fa'?city.name_fa:city.name_en}<ArrowUpRight size={13}/></Link>)}</div></section><section className="section"><div className="section-heading"><h2>{locale==='fa'?'پنل‌های پیش‌رو':'Upcoming panels'}<span className="heading-period">.</span></h2></div>{data.upcoming_events?.length?<div className="event-grid">{data.upcoming_events.map((event:any)=><Link className="organization-card" key={event.id} to={`/events/${event.id}`}><strong>{event.title}</strong><p>{event.city} · {event.day} · {event.date}</p><small>{event.event_type}</small></Link>)}</div>:<div className="empty-inline">{locale==='fa'?'پنل پیش‌رویی وجود ندارد.':'No upcoming panels.'}</div>}</section><section className="section"><div className="section-heading"><h2>{locale==='fa'?'پنل‌های گذشته':'Past panels'}</h2></div>{data.past_events?.length?<div className="event-grid">{data.past_events.map((event:any)=><Link className="organization-card" key={event.id} to={`/events/${event.id}`}><strong>{event.title}</strong><p>{event.city} · {event.day} · {event.date}</p></Link>)}</div>:<div className="empty-inline">{locale==='fa'?'سابقه پنلی ثبت نشده است.':'No past panels yet.'}</div>}</section><div className="powered-by">Powered by Panel Flow</div></div>;
}

function BrandPage() {
  const { organizationSlug = '', brandSlug = '' } = useParams(); const { locale } = useLanguage();
  const { data, loading, error, reload } = useRequest<any>(`/organizations/${organizationSlug}/brands/${brandSlug}`);
  useEffect(() => { if (data?.brand) setPageMetadata(`${data.brand.name} | ${data.organization.name} | Panel Flow`, data.brand.description || 'Brand profile on Panel Flow.', `/organizations/${organizationSlug}/brands/${brandSlug}`); }, [data, locale, organizationSlug, brandSlug]);
  if (loading) return <Loading/>;
  if (error || !data) return <div className="page-shell"><ErrorState message={error || 'Brand not found'} retry={reload}/></div>;
  return <div className="page-shell organization-page"><Link to={`/organizations/${organizationSlug}`} className="back-link"><ArrowLeft size={16}/>{data.organization.name}</Link><div className="organization-page-hero"><div className="organization-profile-heading">{data.brand.logo_url ? <img className="organization-profile-logo" src={data.brand.logo_url} alt={`${data.brand.name} logo`} loading="lazy"/> : <div className="organization-profile-logo organization-profile-logo-fallback" aria-hidden="true">{data.brand.name.slice(0,1)}</div>}<div><div className="eyebrow">BRAND PROFILE</div><h1>{data.brand.name}<span className="heading-period">.</span></h1></div></div><p>{data.brand.description || ''}</p><small>{locale==='fa'?'متعلق به':'Operated by'} <Link to={`/organizations/${organizationSlug}`}>{data.organization.name}</Link></small></div><section className="section"><div className="section-heading"><h2>{locale==='fa'?'پنل‌های پیش‌رو':'Upcoming panels'}<span className="heading-period">.</span></h2></div>{data.upcoming_events?.length ? <div className="event-grid">{data.upcoming_events.map((event:any)=><Link className="organization-card" key={event.id} to={`/events/${event.id}`}><strong>{event.title}</strong><p>{event.city} · {event.day} · {event.date}</p><small>{event.event_type}</small></Link>)}</div> : <div className="empty-inline">{locale==='fa'?'پنل پیش‌رویی برای این برند وجود ندارد.':'No upcoming panels for this brand yet.'}</div>}</section><section className="section"><div className="section-heading"><h2>{locale==='fa'?'پنل‌های گذشته':'Past panels'}</h2></div>{data.past_events?.length ? <div className="event-grid">{data.past_events.map((event:any)=><Link className="organization-card" key={event.id} to={`/events/${event.id}`}><strong>{event.title}</strong><p>{event.city} · {event.day} · {event.date}</p></Link>)}</div> : <div className="empty-inline">{locale==='fa'?'سابقه پنلی ثبت نشده است.':'No past panels yet.'}</div>}</section><section className="section"><h2>{locale==='fa'?'شهرهای فعالیت':'Participating cities'}</h2><div className="brand-chip-row">{data.cities.map((city:any)=><Link className="brand-chip" key={city.slug} to={`/cities/${city.slug}`}>{locale==='fa'?city.name_fa:city.name_en}<ArrowUpRight size={13}/></Link>)}</div></section><div className="powered-by">Powered by Panel Flow</div></div>;
}

function MyOrganizations() {
  const { locale } = useLanguage(); const { token } = useAuth();
  const { data: myData, loading, error, reload } = useRequest<ApiPage<any>>('/me/organizations');
  const { data: publicData } = useRequest<ApiPage<any>>('/organizations');
  const [selected, setSelected] = useState<number | null>(null); const [workspace, setWorkspace] = useState<any>(null);
  const [message, setMessage] = useState(''); const [form, setForm] = useState({name:'',slug:'',description:'',city_ids:[] as number[]});
  const [brand, setBrand] = useState({name:'',slug:'',description:''}); const [verification, setVerification] = useState({legal_name:'',national_id:'',verified_mobile:'',email:'',residence_city_id:'',biography:'',hosting_experience:''});
  const [busy, setBusy] = useState(false); const [verificationStatus, setVerificationStatus] = useState<any>(null);
  useEffect(() => { if (!selected && myData?.items?.length) setSelected(myData.items.find((x:any)=>x.membership_status==='approved')?.id || myData.items[0].id); }, [myData, selected]);
  useEffect(() => { let active=true; if (!selected) { setWorkspace(null); return; } api<any>(`/organizations/${selected}/workspace`, {}, token).then(x=>{if(active)setWorkspace(x);}).catch(e=>{if(active)setWorkspace({error:e.message});}); return ()=>{active=false;}; }, [selected, token]);
  useEffect(() => { let active=true; api<any>('/me/host-verification',{},token).then(x=>{if(active)setVerificationStatus(x);}).catch(()=>{}); return ()=>{active=false;}; }, [token]);
  const apply = async(e:FormEvent) => { e.preventDefault(); setBusy(true); setMessage(''); try { await api('/organizations',{method:'POST',body:JSON.stringify({...form,city_ids:form.city_ids})},token); setForm({name:'',slug:'',description:'',city_ids:[]}); setMessage(locale==='fa'?'درخواست سازمان ارسال شد. ابتدا احراز هویت میزبان را تکمیل کنید.':'Organization application submitted. Complete host verification before approval.'); await reload(); } catch(err){setMessage(err instanceof Error?err.message:'Request failed');} finally{setBusy(false);} };
  const submitVerification = async(e:FormEvent) => { e.preventDefault(); setBusy(true); setMessage(''); try { await api('/me/host-verification',{method:'POST',body:JSON.stringify({...verification,residence_city_id:verification.residence_city_id?Number(verification.residence_city_id):null})},token); setVerificationStatus({status:'pending'}); setMessage(locale==='fa'?'درخواست احراز هویت ارسال شد.':'Host verification submitted.'); } catch(err){setMessage(err instanceof Error?err.message:'Request failed');} finally{setBusy(false);} };
  const createBrand = async(e:FormEvent) => { e.preventDefault(); if(!selected)return; setBusy(true); try { await api(`/organizations/${selected}/brands`,{method:'POST',body:JSON.stringify(brand)},token); setBrand({name:'',slug:'',description:''}); setMessage(locale==='fa'?'برند برای بررسی ارسال شد.':'Brand submitted for platform review.'); const x=await api<any>(`/organizations/${selected}/workspace`,{},token);setWorkspace(x); } catch(err){setMessage(err instanceof Error?err.message:'Request failed');} finally{setBusy(false);} };
  const join = async(id:number) => { setBusy(true); try { await api(`/organizations/${id}/membership-requests`,{method:'POST',body:JSON.stringify({requested_role:'host'})},token); setMessage(locale==='fa'?'درخواست عضویت ارسال شد.':'Membership request submitted.'); await reload(); } catch(err){setMessage(err instanceof Error?err.message:'Request failed');} finally{setBusy(false);} };
  return <div className="page-shell organization-workspace"><AccountHeading title={locale==='fa'?'سازمان‌های من':'My organizations'} subtitle={locale==='fa'?'درخواست همکاری، تکمیل احراز هویت و مدیریت فضای سازمانی.':'Apply to the network, complete verification, and manage your approved organization memberships.'}/>{message && <div className="notice notice-success">{message}</div>}
    <section className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">HOST IDENTITY</span><h2>{locale==='fa'?'احراز هویت میزبان':'Host identity verification'}</h2><p>{locale==='fa'?'اطلاعات هویتی فقط برای بررسی داخلی و به‌صورت رمزنگاری‌شده نگهداری می‌شود.':'Identity information is private and the national ID is encrypted before storage.'}</p></div><StatusPill status={verificationStatus?.status || 'not_submitted'}/></div>{verificationStatus?.status !== 'approved' && <form className="platform-form" onSubmit={submitVerification}><label>{locale==='fa'?'نام قانونی کامل':'Legal full name'}<input required value={verification.legal_name} onChange={e=>setVerification(p=>({...p,legal_name:e.target.value}))}/></label><label>{locale==='fa'?'کد ملی':'Iranian national ID'}<input required inputMode="numeric" maxLength={10} value={verification.national_id} onChange={e=>setVerification(p=>({...p,national_id:e.target.value}))}/></label><label>{locale==='fa'?'موبایل تأییدشده':'Verified mobile'}<input required value={verification.verified_mobile} onChange={e=>setVerification(p=>({...p,verified_mobile:e.target.value}))}/></label><label>Email<input required type="email" value={verification.email} onChange={e=>setVerification(p=>({...p,email:e.target.value}))}/></label><label>{locale==='fa'?'بیوگرافی':'Short biography'}<textarea value={verification.biography} onChange={e=>setVerification(p=>({...p,biography:e.target.value}))}/></label><label>{locale==='fa'?'تجربه میزبانی':'Hosting experience'}<textarea value={verification.hosting_experience} onChange={e=>setVerification(p=>({...p,hosting_experience:e.target.value}))}/></label><button className="button button-orange" disabled={busy}>{locale==='fa'?'ارسال برای بررسی':'Submit for verification'}</button></form>}</section>
    <section className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">ORGANIZATION APPLICATION</span><h2>{locale==='fa'?'ایجاد سازمان مستقل':'Create an independent organization'}</h2></div></div><form className="platform-form" onSubmit={apply}><label>{locale==='fa'?'نام سازمان':'Organization name'}<input required minLength={2} value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))}/></label><label>Slug<input required pattern="[a-z0-9]+(-[a-z0-9]+)*" value={form.slug} onChange={e=>setForm(p=>({...p,slug:e.target.value}))}/></label><label>{locale==='fa'?'توضیحات':'Description'}<textarea value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))}/></label><button className="button button-orange" disabled={busy}>{locale==='fa'?'ثبت درخواست سازمان':'Submit organization'}</button></form></section>
    <section className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">EXISTING NETWORK</span><h2>{locale==='fa'?'پیوستن به سازمان موجود':'Join an existing organization'}</h2></div></div>{(publicData?.items||[]).map((org:any)=><div className="organization-member-row" key={org.id}><span><strong>{org.name}</strong><small>{org.description||''}</small></span><button className="button button-small button-outline" disabled={busy || myData?.items?.some((m:any)=>m.id===org.id)} onClick={()=>join(org.id)}>{locale==='fa'?'درخواست عضویت':'Request to join'}</button></div>)}</section>
    <section className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">YOUR WORKSPACES</span><h2>{locale==='fa'?'فضاهای سازمانی':'Organization workspaces'}</h2></div></div>{loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:myData?.items?.length?<><div className="organization-selector">{myData.items.map((org:any)=><button key={org.id} className={selected===org.id?'active':''} onClick={()=>setSelected(org.id)}>{org.name} · {org.membership_status}</button>)}</div>{workspace?.error?<p className="empty-inline">{workspace.error}</p>:workspace && <><OrganizationProfileEditor organization={workspace.organization} brands={workspace.brands} locale={locale} onSaved={async()=>{const x=await api<any>(`/organizations/${selected}/workspace`,{},token);setWorkspace(x);await reload();}} onMessage={setMessage}/><div className="staff-metrics"><StatTile icon={<Users/>} label={locale==='fa'?'اعضای تأییدشده':'Approved members'} value={workspace.metrics.approved_members}/><StatTile icon={<Users/>} label={locale==='fa'?'درخواست‌های در انتظار':'Pending members'} value={workspace.metrics.pending_members}/><StatTile icon={<Compass/>} label={locale==='fa'?'برندها':'Brands'} value={workspace.metrics.brands}/></div><p>{locale==='fa'?'وضعیت اشتراک':'Subscription'}: {workspace.subscription?.status || 'not activated'} · {workspace.subscription?.plan || '—'}</p><div className="organization-brand-list">{workspace.brands.map((b:any)=><div key={b.id}><strong>{b.name}</strong><StatusPill status={b.status}/></div>)}</div>{['owner','admin'].includes(workspace.organization.role) && <OrganizationTeamPanel organizationId={selected} brands={workspace.brands.filter((b:any)=>b.status==='approved')} locale={locale} onMessage={setMessage}/ >}{['owner','admin'].includes(workspace.organization.role) && <form className="platform-form" onSubmit={createBrand}><label>{locale==='fa'?'نام برند جدید':'New brand name'}<input required value={brand.name} onChange={e=>setBrand(p=>({...p,name:e.target.value}))}/></label><label>Slug<input required pattern="[a-z0-9]+(-[a-z0-9]+)*" value={brand.slug} onChange={e=>setBrand(p=>({...p,slug:e.target.value}))}/></label><label>{locale==='fa'?'توضیحات برند':'Brand description'}<textarea value={brand.description} onChange={e=>setBrand(p=>({...p,description:e.target.value}))}/></label><button className="button button-orange" disabled={busy}>{locale==='fa'?'ثبت برند':'Submit brand'}</button></form>}</>}</>:<p className="empty-inline">{locale==='fa'?'هنوز عضویت سازمانی ندارید.':'No organization memberships yet.'}</p>}</section>
  </div>;
}

function OrganizationProfileEditor({ organization, brands, locale, onSaved, onMessage }: { organization:any; brands:any[]; locale:Locale; onSaved:()=>void|Promise<void>; onMessage:(message:string)=>void }) {
  const { token } = useAuth(); const fa = locale === 'fa';
  const [name,setName] = useState(organization?.name || ''); const [description,setDescription] = useState(organization?.description || '');
  const [logo,setLogo] = useState<File|null>(null); const [busy,setBusy] = useState(false); const [error,setError] = useState('');
  useEffect(()=>{setName(organization?.name||'');setDescription(organization?.description||'');setLogo(null);},[organization?.id,organization?.name,organization?.description]);
  const save = async(e:FormEvent) => { e.preventDefault(); if(!organization?.id)return; setBusy(true);setError('');
    try { await api(`/organizations/${organization.id}/profile`,{method:'PATCH',body:JSON.stringify({name,description})},token);
      if(logo){const data=new FormData();data.append('file',logo);await api(`/organizations/${organization.id}/media/logo`,{method:'POST',body:data},token);}
      onMessage(fa?'پروفایل سازمان به‌روزرسانی شد.':'Organization profile updated.');await onSaved();
    } catch(err){setError(err instanceof Error?err.message:'Update failed');} finally{setBusy(false);} };
  const uploadBrand = async(brandId:number,file:File) => {if(!organization?.id)return;setBusy(true);setError('');try{const data=new FormData();data.append('file',file);await api(`/organizations/${organization.id}/brands/${brandId}/media/logo`,{method:'POST',body:data},token);onMessage(fa?'لوگوی برند به‌روزرسانی شد.':'Brand logo updated.');await onSaved();}catch(err){setError(err instanceof Error?err.message:'Upload failed');}finally{setBusy(false);}};
  if(!['owner','admin'].includes(organization?.role))return null;
  return <section className="organization-profile-editor surface-card"><div className="surface-heading"><div><span className="eyebrow">PUBLIC IDENTITY</span><h3>{fa?'هویت عمومی سازمان':'Public organization profile'}</h3><p>{fa?'اطلاعات و نشان سازمانی که در صفحه عمومی نمایش داده می‌شوند.':'Manage the information and logo displayed on the public organization page.'}</p></div></div><form className="platform-form" onSubmit={save}><label>{fa?'نام سازمان':'Organization name'}<input required minLength={2} maxLength={200} value={name} onChange={e=>setName(e.target.value)}/></label><label>{fa?'توضیحات عمومی':'Public description'}<textarea maxLength={5000} rows={3} value={description} onChange={e=>setDescription(e.target.value)}/></label><label>{fa?'لوگوی سازمان':'Organization logo'}<input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>{const file=e.target.files?.[0]||null;if(file&&file.size>8*1024*1024){setError(fa?'حجم تصویر نباید بیشتر از ۸ مگابایت باشد.':'Image must be 8 MB or smaller.');setLogo(null);e.target.value='';}else{setError('');setLogo(file);}}}/><small className="form-footnote">{fa?'حداکثر ۸ مگابایت؛ تصویر در سرور به WebP فشرده می‌شود.':'Max 8 MB. Images are resized and compressed to WebP on the server.'}</small></label><button className="button button-orange" disabled={busy}>{busy?<LoaderCircle className="spin" size={16}/>:<Save size={16}/>} {fa?'ذخیره پروفایل':'Save profile'}</button></form>{brands.filter((b:any)=>b.status==='approved').map((b:any)=><div className="brand-logo-upload" key={b.id}><span><strong>{b.name}</strong><small>{fa?'لوگوی برند':'Brand logo'}</small></span><label className="button button-small button-outline">{fa?'بارگذاری لوگو':'Upload logo'}<input type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e=>{const file=e.target.files?.[0];if(file&&file.size>8*1024*1024){setError(fa?'حجم تصویر نباید بیشتر از ۸ مگابایت باشد.':'Image must be 8 MB or smaller.');e.target.value='';return;}if(file)void uploadBrand(Number(b.id),file);}}/></label></div>)}{error&&<ErrorState message={error}/>}</section>;
}

function OrganizationTeamPanel({ organizationId, brands, locale, onMessage }: { organizationId:number; brands:any[]; locale:Locale; onMessage:(message:string)=>void }) {
  const {token}=useAuth(); const [members,setMembers]=useState<any[]>([]); const [assignments,setAssignments]=useState<Record<number,number[]>>({});
  const [loading,setLoading]=useState(true); const [busy,setBusy]=useState(false); const [error,setError]=useState(''); const fa=locale==='fa';
  const brandIds = brands.filter((b:any)=>b.status==='approved').map((b:any)=>Number(b.id)).join(',');
  const reload=useCallback(async()=>{
    setLoading(true);setError('');
    try {
      const m=await api<ApiPage<any>>(`/organizations/${organizationId}/members`,{},token);setMembers(m.items||[]);
      const ids=brandIds?brandIds.split(',').map(Number):[];
      const pairs=await Promise.all(ids.map(async id=>{const x=await api<ApiPage<any>>(`/organizations/${organizationId}/brands/${id}/hosts`,{},token);return [id,(x.items||[]).map((h:any)=>Number(h.membership_id))] as [number,number[]]}));
      setAssignments(Object.fromEntries(pairs));
    } catch(e){setError(e instanceof Error?e.message:'Request failed');}
    finally{setLoading(false);}
  },[organizationId,brandIds,token]);
  useEffect(()=>{void reload();},[reload]);
  const decide=async(m:any,status:'approved'|'rejected')=>{setBusy(true);setError('');try{await api(`/organizations/${organizationId}/members/${m.membership_id}`,{method:'PATCH',body:JSON.stringify({status,role:'host'})},token);onMessage(fa?'وضعیت درخواست عضویت به‌روزرسانی شد.':'Membership request updated.');await reload();}catch(e){setError(e instanceof Error?e.message:'Request failed');}finally{setBusy(false);}};
  const toggle=async(brandId:number,membershipId:number,checked:boolean)=>{
    const next=checked?[...(assignments[brandId]||[]),membershipId]:(assignments[brandId]||[]).filter(id=>id!==membershipId);
    setBusy(true);setError('');try{await api(`/organizations/${organizationId}/brands/${brandId}/hosts`,{method:'PUT',body:JSON.stringify({membership_ids:next})},token);setAssignments(prev=>({...prev,[brandId]:next}));}
    catch(e){setError(e instanceof Error?e.message:'Request failed');}finally{setBusy(false);}
  };
  const activeHosts=members.filter(m=>m.status==='approved'&&m.role==='host');
  return <section className="surface-card workspace-panel org-team-panel"><div className="surface-heading"><div><span className="eyebrow">TEAM & BRAND ACCESS</span><h3>{fa?'اعضای تیم و دسترسی برندها':'Team members & brand access'}</h3><p>{fa?'درخواست‌ها را بررسی و میزبان‌های تأییدشده را به برندها اختصاص دهید.':'Review membership requests and assign verified hosts to approved brands.'}</p></div><Users size={18}/></div>
    {error&&<ErrorState message={error} retry={reload}/ >}{loading?<Loading/>:<>
      {members.length?members.map(m=><div className="organization-member-row" key={m.membership_id}><span><strong>{m.display_name}</strong><small>{m.role} · {m.status}</small></span>{m.status==='pending'&&<div className="admin-row-actions"><button className="button button-small button-success" disabled={busy} onClick={()=>void decide(m,'approved')}>{fa?'تأیید میزبان':'Approve host'}</button><button className="button button-small button-danger" disabled={busy} onClick={()=>void decide(m,'rejected')}>{fa?'رد':'Reject'}</button></div>}</div>):<div className="empty-inline">{fa?'عضوی ثبت نشده است.':'No team members yet.'}</div>}
      {brands.filter((b:any)=>b.status==='approved').map(b=><div className="brand-host-assignments" key={b.id}><strong>{fa?'میزبان‌های برند':'Hosts for'} {b.name}</strong>{activeHosts.length?activeHosts.map(m=><label className="checkbox-line" key={m.membership_id}><input type="checkbox" checked={(assignments[b.id]||[]).includes(m.membership_id)} disabled={busy} onChange={e=>void toggle(b.id,m.membership_id,e.target.checked)}/>{m.display_name}</label>):<small className="muted-copy">{fa?'میزبان تأییدشده‌ای وجود ندارد.':'No approved hosts to assign.'}</small>}</div>)}
    </>}
  </section>;
}

function CalendarPage() {
  const { locale } = useLanguage(); const { data, loading, error, reload } = useRequest<ApiPage<EventData>>('/calendar/events?limit=2000');
  const events = (data?.items || []).filter(event => !!event.date_iso);
  return <div className="page-shell calendar-page-shell"><div className="page-intro"><div className="eyebrow"><span className="eyebrow-dot"/>{locale==='fa'?'برنامه زمانی':'SCHEDULE'}</div><h1>{locale==='fa'?'تقویم پنل‌ها':'Panel calendar'}<span className="heading-period">.</span></h1><p>{locale==='fa'?'تاریخ پنل‌ها را در تقویم شمسی دنبال کن و برای روزهای پیش‌رو برنامه‌ریزی کن.':'See scheduled panels at a glance and plan the conversations ahead.'}</p></div>{loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:<><PersianCalendar events={events} locale={locale}/><p className="calendar-footnote">{locale==='fa'?'تقویم فقط پنل‌هایی را نشان می‌دهد که تاریخ ساختاریافته دارند؛ پنل‌های قدیمی با تاریخ متنی همچنان در فهرست شهر و پنل‌ها قابل مشاهده‌اند.':'The calendar includes panels with a structured date. Older panels with display-only dates remain available in the city and event listings.'}</p></>}</div>;
}

function Community() {
  const { t, locale } = useLanguage(); const { token, user } = useAuth();
  const { data: overview, loading, error, reload } = useRequest<any>('/community/overview');
  const { data: topics, loading: topicsLoading, reload: reloadTopics } = useRequest<ApiPage<any>>('/community/topics');
  const [challengeList, setChallengeList] = useState<any[]>([]); const [challengeLoading, setChallengeLoading] = useState(false);
  const [suggestion, setSuggestion] = useState(''); const [feedback, setFeedback] = useState('');
  const [answerFor, setAnswerFor] = useState<number | null>(null); const [answer, setAnswer] = useState('');
  useEffect(() => {
    let active = true;
    if (!token) { setChallengeList([]); setChallengeLoading(false); return () => { active = false; }; }
    setChallengeLoading(true);
    api<ApiPage<any>>('/community/challenges', {}, token).then(res => { if (active) setChallengeList(res.items); })
      .catch(() => undefined).finally(() => { if (active) setChallengeLoading(false); });
    return () => { active = false; };
  }, [token]);
  const visibleChallenges = user ? challengeList : (overview?.challenges || []);
  const submitTopic = async (e: FormEvent) => { e.preventDefault(); if (!token) return; try { await api('/community/topics', { method: 'POST', body: JSON.stringify({ title: suggestion }) }, token); setSuggestion(''); setFeedback(locale === 'fa' ? 'پیشنهاد شما برای بررسی ارسال شد.' : 'Your idea has been sent for review.'); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } };
  const submitAnswer = async (e: FormEvent) => { e.preventDefault(); if (!token || answerFor == null) return; try { await api(`/community/challenges/${answerFor}/submit`, { method: 'POST', body: JSON.stringify({ answer_text: answer }) }, token); setChallengeList(prev => prev.map(c => c.id === answerFor ? { ...c, submitted: true, can_submit: false } : c)); setAnswerFor(null); setAnswer(''); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } };
  const vote = async (id: number) => { if (!token) return; try { await api(`/community/topics/${id}/vote`, { method: 'POST' }, token); await reloadTopics(); } catch (err) { setFeedback(err instanceof Error ? err.message : t.error); } };
  return <div className="page-shell"><div className="page-intro"><div className="eyebrow"><span className="eyebrow-dot" />BE PART OF THE FLOW</div><h1>{t.community}<span className="heading-period">.</span></h1><p>{t.communityText}</p></div>{error && <ErrorState message={error} retry={reload} />}
    <div className="community-layout"><section className="surface-card challenge-card"><div className="surface-heading"><div><span className="eyebrow">THINK · CREATE · CONTRIBUTE</span><h2>{t.challenges}</h2></div><Sparkles size={20} /></div>{loading || (user && challengeLoading) ? <Loading /> : visibleChallenges.length ? visibleChallenges.map((challenge: any) => <article className="challenge-item" key={challenge.id}><div className="challenge-icon"><Lightbulb size={21} /></div><div><strong>{challenge.title}</strong><p>{challenge.prompt}</p>{user && challenge.can_submit !== false && <button className="text-link" onClick={() => { setAnswerFor(challenge.id); setAnswer(''); }}>{locale === 'fa' ? 'ارسال پاسخ' : 'Submit an answer'}<ArrowUpRight size={14} /></button>}{user && challenge.submitted && <small className="muted-copy">{locale === 'fa' ? 'پاسخ شما ثبت شده است.' : 'Your answer has been submitted.'}</small>}</div></article>) : <div className="empty-inline">{locale === 'fa' ? 'چالش فعالی برای نمایش وجود ندارد.' : 'No active challenges right now.'}</div>}
      {answerFor != null && <form onSubmit={submitAnswer} className="inline-composer"><label>{t.answer}<textarea rows={3} value={answer} onChange={e => setAnswer(e.target.value)} minLength={1} maxLength={4000} required /></label><div><button className="button button-primary button-small" type="submit">{t.submitAnswer}</button><button className="text-button" type="button" onClick={() => setAnswerFor(null)}>{t.cancel}</button></div></form>}
      {!user && <Link className="button button-outline button-block" to="/sign-in">{t.loginRequired}<ArrowUpRight size={16} /></Link>}
    </section>
    <section className="surface-card leaderboard-card"><div className="surface-heading"><div><span className="eyebrow">CELEBRATING COMMUNITY</span><h2>{t.leaderboard}</h2></div><Trophy size={20} /></div>{overview?.leaderboard?.length ? <div className="leaderboard-list">{overview.leaderboard.map((row: any, i: number) => <div className="leader-row" key={`${row.name}-${i}`}><span className={`leader-rank rank-${i + 1}`}>{String(i + 1).padStart(2, '0')}</span><span className="leader-avatar">{row.name.startsWith('•') ? '•' : row.name.charAt(0)}</span><strong>{row.name}</strong><span>{row.panels} <small>{locale === 'fa' ? 'پنل' : 'panels'}</small></span><b>{row.xp} XP</b></div>)}</div> : <p className="muted-copy">{locale === 'fa' ? 'جدول امتیاز در حال حاضر فعال نیست.' : 'The public leaderboard is not enabled right now.'}</p>}</section></div>
    <section className="topics-section"><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-dot" />SHAPE WHAT COMES NEXT</div><h2>{t.topicIdeas}<span className="heading-period">.</span></h2></div></div><div className="topics-layout"><div className="topics-list">{topicsLoading ? <Loading /> : (topics?.items || []).length ? topics?.items?.map(topic => <article className="topic-row" key={topic.id}><div className="topic-bulb"><MessageSquare size={18} /></div><strong>{topic.title}</strong><span>{topic.votes} {locale === 'fa' ? 'رأی' : 'votes'}</span><button className="text-link" onClick={() => vote(topic.id)} disabled={!user}>{t.vote}<ArrowUpRight size={14} /></button></article>) : <p className="muted-copy">{locale === 'fa' ? 'هنوز موضوع تأییدشده‌ای ثبت نشده است.' : 'No approved ideas have been shared yet.'}</p>}</div><form className="suggest-form surface-card" onSubmit={submitTopic}><div className="suggest-icon"><Lightbulb size={21} /></div><h3>{t.suggestTopic}</h3><p>{locale === 'fa' ? 'چه موضوعی را دوست دارید در پنل بعدی بررسی کنیم؟' : 'What should we explore in an upcoming panel?'}</p><textarea rows={3} value={suggestion} onChange={e => setSuggestion(e.target.value)} minLength={5} maxLength={200} required placeholder={locale === 'fa' ? 'ایده شما…' : 'Your idea…'} /><button className="button button-orange button-block" disabled={!user}>{t.sendSuggestion}<ArrowUpRight size={16} /></button>{!user && <small>{t.loginRequired}</small>}{feedback && <small>{feedback}</small>}</form></div></section>
  </div>;
}

function About() {
  const { t, locale } = useLanguage();
  return <div className="page-shell about-shell"><div className="about-hero"><div className="eyebrow"><span className="eyebrow-dot"/>OUR STORY</div><h1>{t.aboutTitle}<span className="heading-period">.</span></h1><p>{t.aboutText}</p></div>
    <div className="about-timeline"><div><span>JUN 2025</span><strong>{locale === 'fa' ? 'اولین گفتگو' : 'The first conversation'}</strong><p>{locale === 'fa' ? 'اولین نشست در ۳ تیر ۱۴۰۴ برگزار شد؛ جرقه‌ای برای شکل‌گیری یک جامعه.' : 'Our first session took place on June 24, 2025 — the beginning of a community.'}</p></div><div><span>FROM FRIENDS TO COMMUNITY</span><strong>{locale === 'fa' ? 'از یک جمع کوچک تا یک جامعه باز' : 'From a small circle to an open community'}</strong><p>{locale === 'fa' ? 'آنچه با جمعی از دوستان شروع شد، به فضایی برای به‌اشتراک‌گذاشتن ایده‌ها و دیدگاه‌ها تبدیل شد.' : 'What started with a few friends grew into a welcoming place to share ideas and perspectives.'}</p></div><div><span>THE NEXT CHAPTER</span><strong>{locale === 'fa' ? 'گفت‌وگو در سراسر ایران' : 'A conversation across Iran'}</strong><p>{locale === 'fa' ? 'پنل فلو در حال تبدیل‌شدن به خانه‌ای مشترک برای پنل‌ها و میزبان‌های شهرهای مختلف ایران است.' : 'Panel Flow is growing into a shared home for panels and hosts in cities across Iran.'}</p></div></div>
    <section className="about-network"><div><div className="eyebrow"><span className="eyebrow-dot"/>{locale==='fa'?'یک شبکه، چندین شهر':'ONE NETWORK, MANY CITIES'}</div><h2>{locale==='fa'?'هر میزبان، بخشی از یک جریان مشترک':'Independent hosts. One shared discovery hub.'}</h2><p>{locale==='fa'?'میزبان‌ها رویدادهای خود را مدیریت می‌کنند؛ شرکت‌کنندگان از یک نقشه و تقویم واحد، پنل‌های شهرهای مختلف را پیدا می‌کنند.':'Local hosts manage their own panels while participants discover everything through one national map, calendar, and directory.'}</p><Link to="/cities" className="button button-outline">{locale==='fa'?'کاوش شهرها':'Explore the cities'}<ArrowUpRight size={17}/></Link></div><div className="about-network-mark"><span>31</span><small>{locale==='fa'?'شهر پایه در فهرست اولیه':'seeded city locations'}</small><i>PF / IRAN</i></div></section>
    <div className="about-cta"><div><h2>{locale === 'fa' ? 'جای شما در گفتگو خالی است.' : 'There is a place for you in the conversation.'}</h2><p>{locale === 'fa' ? 'پنل بعدی را پیدا کنید و از نزدیک همراه شوید.' : 'Find your next panel and join us in person.'}</p></div><Link to="/events" className="button button-orange">{t.explore}<ArrowUpRight size={17}/></Link></div></div>;
}

function Workspace() {
  const { t, locale } = useLanguage(); const { token, user } = useAuth();
  const [tab, setTab] = useState('overview'); const [refreshKey, setRefreshKey] = useState(0);
  const [search, setSearch] = useState(''); const [feedback, setFeedback] = useState('');
  const { data: dash, loading, error, reload } = useRequest<any>(`/staff/dashboard?refresh=${refreshKey}`);
  const [events, setEvents] = useState<EventData[]>([]); const [auditLogs, setAuditLogs] = useState<any[]>([]); const [payments, setPayments] = useState<any[]>([]); const [reviews, setReviews] = useState<any[]>([]); const [members, setMembers] = useState<any[]>([]); const [topics, setTopics] = useState<any[]>([]); const [shopRequests, setShopRequests] = useState<any[]>([]); const [hosts, setHosts] = useState<any[]>([]); const [cities, setCities] = useState<CityData[]>([]);
  const [dataLoading, setDataLoading] = useState(false); const isAdmin = user?.role === 'admin' || user?.role === 'super_admin'; const isSuperAdmin = user?.role === 'super_admin'; const isHost = user?.role === 'host';
  const loadTab = useCallback(async () => { setDataLoading(true); setFeedback(''); try {
    if (tab === 'events') setEvents((await api<ApiPage<EventData>>('/staff/events?limit=100', {}, token)).items);
    if (tab === 'payments' && isAdmin) setPayments((await api<ApiPage<any>>('/staff/payments?limit=100', {}, token)).items);
    if (tab === 'reviews' && isAdmin) setReviews((await api<ApiPage<any>>('/staff/reviews', {}, token)).items);
    if (tab === 'members' && isAdmin) setMembers((await api<ApiPage<any>>(`/staff/users?q=${encodeURIComponent(search)}`, {}, token)).items);
    if (tab === 'topics' && isAdmin) setTopics((await api<ApiPage<any>>('/staff/topics', {}, token)).items);
    if (tab === 'shop' && isAdmin) setShopRequests((await api<ApiPage<any>>('/staff/shop/requests?limit=100', {}, token)).items);
    if (tab === 'hosts' && isSuperAdmin) setHosts((await api<ApiPage<any>>('/staff/platform/hosts', {}, token)).items);
    if (tab === 'cities' && isAdmin) setCities((await api<ApiPage<CityData>>('/staff/platform/cities', {}, token)).items);
    if (tab === 'audit' && isSuperAdmin) setAuditLogs((await api<ApiPage<any>>('/staff/audit-logs?limit=100', {}, token)).items);
  } catch (e) { setFeedback(e instanceof Error ? e.message : t.error); } finally { setDataLoading(false); } }, [tab, token, isAdmin, isSuperAdmin, search, t.error]);
  useEffect(() => { void loadTab(); }, [loadTab]);
  const doRefresh = async () => { setRefreshKey(v => v + 1); await reload(); await loadTab(); };
  const reviewPayment = async (row: any, decision: 'approved' | 'rejected') => {
    let reason_category: string | undefined; let reason_text: string | undefined;
    if (decision === 'rejected') { const choice = window.prompt(`${t.rejectionReason}: not_received / amount_mismatch / unclear / duplicate / other`, 'unclear'); if (!choice) return; reason_category = choice; reason_text = window.prompt(t.rejectionReason, t.chooseReason) || ''; if (!reason_text) return; }
    try { await api(`/staff/payments/${row.id}/review`, { method: 'POST', body: JSON.stringify({ decision, reason_category, reason_text, receipt_token: row.receipt_token }) }, token); setFeedback(locale === 'fa' ? 'وضعیت پرداخت ثبت شد.' : 'Payment decision saved.'); await loadTab(); } catch (e) { setFeedback(e instanceof Error ? e.message : t.error); }
  };
  const moderate = async (type: 'reviews' | 'topics', id: number, decision: string) => { try { await api(`/staff/${type}/${id}?decision=${decision}`, { method: 'PATCH' }, token); await loadTab(); } catch (e) { setFeedback(e instanceof Error ? e.message : t.error); } };
  const reviewShopRequest = async (row: any, decision: 'approved' | 'denied') => { let reason: string | undefined; if (decision === 'denied') { reason = window.prompt(locale === 'fa' ? 'دلیل رد درخواست را وارد کنید' : 'Enter a reason for denial')?.trim(); if (!reason) return; } try { await api(`/staff/shop/requests/${row.id}/review`, { method: 'POST', body: JSON.stringify({ decision, reason }) }, token); setFeedback(locale === 'fa' ? (decision === 'approved' ? 'درخواست تأیید و XP کسر شد؛ پرونده صدور هدیه ایجاد شد.' : 'درخواست رد شد و XP رزروشده آزاد شد.') : (decision === 'approved' ? 'Request approved. XP debited and a reward-issuance case created.' : 'Request denied and reserved XP released.')); await loadTab(); } catch (e) { setFeedback(e instanceof Error ? e.message : t.error); } };
  const updateMemberRole = async (member:any, role:string) => {
    if (!isSuperAdmin || member.role === 'host' || role === member.role) return;
    if (!window.confirm(locale === 'fa' ? `نقش کاربر به ${role} تغییر کند؟` : `Change this account's role to ${role}?`)) return;
    try { await api(`/staff/platform/users/${member.id}/role`, {method:'PATCH', body:JSON.stringify({role})}, token); setMembers(rows=>rows.map(row=>row.id===member.id?{...row,role}:row)); setFeedback(locale==='fa'?'نقش حساب به‌روزرسانی شد.':'Account role updated.'); }
    catch(e) { setFeedback(e instanceof Error?e.message:t.error); }
  };
  return <div className="page-shell workspace-shell"><div className="workspace-header"><div><div className="eyebrow"><span className="eyebrow-dot" />PANEL FLOW OPERATIONS</div><h1>{t.staffTitle}<span className="heading-period">.</span></h1><p>{t.staffSub}</p></div><button className="button button-outline" onClick={doRefresh}><LoaderCircle size={16} />{t.refresh}</button></div>
    {user?.role === 'host' && dash?.subscription && <div className={`subscription-banner ${dash.subscription.status === 'active' || dash.subscription.status === 'trial' ? '' : 'inactive'}`}><ShieldCheck size={18}/><span><strong>{locale === 'fa' ? 'وضعیت اشتراک میزبانی' : 'Host subscription'}: {dash.subscription.status}</strong><small>{dash.subscription.ends_at ? `${locale === 'fa' ? 'پایان اعتبار' : 'Expires'} · ${formatDate(dash.subscription.ends_at, locale)}` : (locale === 'fa' ? 'بدون تاریخ انقضا' : 'No expiry date')}</small></span></div>}
    <div className="workspace-tabs"><button className={tab === 'overview' ? 'active' : ''} onClick={() => setTab('overview')}>{locale === 'fa' ? 'نمای کلی' : 'Overview'}</button><button className={tab === 'events' ? 'active' : ''} onClick={() => setTab('events')}>{t.manageEvents}</button>{isHost && <><button className={tab === 'participants' ? 'active' : ''} onClick={() => setTab('participants')}>{locale === 'fa' ? 'شرکت‌کنندگان' : 'Participants'}</button><button className={tab === 'host-series' ? 'active' : ''} onClick={() => setTab('host-series')}>{locale === 'fa' ? 'مجموعه پنل‌ها' : 'Discussion series'}</button><button className={tab === 'host-payments' ? 'active' : ''} onClick={() => setTab('host-payments')}>{locale === 'fa' ? 'سوابق مالی' : 'Payments & receipts'}</button><button className={tab === 'host-reviews' ? 'active' : ''} onClick={() => setTab('host-reviews')}>{locale === 'fa' ? 'بازخوردها' : 'Reviews & feedback'}</button><button className={tab === 'host-profile' ? 'active' : ''} onClick={() => setTab('host-profile')}>{locale === 'fa' ? 'پروفایل عمومی' : 'Public profile'}</button><Link to="/host-application" className="workspace-tab-link">{locale === 'fa' ? 'اعلان‌ها و درخواست' : 'Application & notifications'}</Link></>}{isAdmin && <><button className={tab === 'payments' ? 'active' : ''} onClick={() => setTab('payments')}>{t.payments}</button><button className={tab === 'reviews' ? 'active' : ''} onClick={() => setTab('reviews')}>{t.reviews}</button><button className={tab === 'topics' ? 'active' : ''} onClick={() => setTab('topics')}>{t.topicIdeas}</button><button className={tab === 'members' ? 'active' : ''} onClick={() => setTab('members')}>{t.members}</button><button className={tab === 'shop' ? 'active' : ''} onClick={() => setTab('shop')}>{locale === 'fa' ? 'درخواست‌های XP' : 'XP requests'}</button>{isSuperAdmin && <button className={tab === 'hosts' ? 'active' : ''} onClick={() => setTab('hosts')}>{locale === 'fa' ? 'میزبان‌ها و اشتراک‌ها' : 'Hosts & subscriptions'}</button>}<button className={tab === 'cities' ? 'active' : ''} onClick={() => setTab('cities')}>{locale === 'fa' ? 'مدیریت شهرها' : 'City directory'}</button><button className={tab === 'national' ? 'active' : ''} onClick={() => setTab('national')}>{locale === 'fa' ? 'مدیریت شبکه ملی' : 'National network'}</button>{isSuperAdmin && <button className={tab === 'audit' ? 'active' : ''} onClick={() => setTab('audit')}>{locale==='fa'?'گزارش رویدادهای مدیریتی':'Audit log'}</button>}</>}</div>
    {feedback && <div className="notice notice-success"><CheckCircle2 size={17} />{feedback}<button onClick={() => setFeedback('')}><X size={15} /></button></div>}
    {tab === 'overview' && <>{loading ? <Loading /> : error ? <ErrorState message={error} retry={reload} /> : <><div className="staff-metrics"><StatTile icon={<CalendarDays />} label={t.eventsManaged} value={dash?.metrics?.events || 0} /><StatTile icon={<CreditCard />} label={t.pendingReceipts} value={dash?.metrics?.pending_receipts || 0} /><StatTile icon={<MessageSquare />} label={t.pendingReviews} value={dash?.metrics?.pending_reviews || 0} /><StatTile icon={<Wallet />} label={t.revenue} value={formatMoney(dash?.metrics?.confirmed_revenue || 0, locale)} /></div><div className="surface-card"><div className="surface-heading"><div><span className="eyebrow">RECENT ACTIVITY</span><h2>{t.manageEvents}</h2></div><button className="text-link" onClick={() => setTab('events')}>{t.viewAll}<ArrowUpRight size={15} /></button></div><EventManagementTable events={dash?.recent_events || []} isAdmin={isAdmin} onUpdated={doRefresh} /></div></>}</>}
    {tab === 'events' && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">EVENT OPERATIONS</span><h2>{t.manageEvents}</h2></div></div><CreateEventForm onCreated={async () => { await loadTab(); setFeedback(locale === 'fa' ? 'پیش‌نویس پنل ساخته شد.' : 'Draft panel created.'); }} />{dataLoading ? <Loading /> : <EventManagementTable events={events} isAdmin={isAdmin} onUpdated={loadTab} />}</div>}
    {tab === 'participants' && isHost && <HostParticipantsPanel />}
    {tab === 'host-series' && isHost && <HostSeriesPanel />}
    {tab === 'host-payments' && isHost && <HostPaymentsPanel />}
    {tab === 'host-reviews' && isHost && <HostReviewsPanel />}
    {tab === 'host-profile' && isHost && <HostProfileEditor />}
    {tab === 'payments' && isAdmin && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">FINANCIAL OPERATIONS</span><h2>{t.payments}</h2></div><span className="count-badge">{payments.length}</span></div>{dataLoading ? <Loading /> : payments.length ? <div className="admin-list">{payments.map(row => <div className="admin-list-row" key={row.id}><div className="admin-list-content"><strong>{row.event_title}</strong><p>{row.user_name} {row.telegram_username ? `· @${row.telegram_username}` : ''}</p><small>#{row.booking_id} · {row.participant_count} {t.seats} · {formatMoney(row.amount, locale)}</small>{row.receipt_text && <blockquote className="receipt-quote">{row.receipt_text}</blockquote>}{row.has_file && <button className="text-link" onClick={async () => { const response = await fetch(`${API_BASE}/staff/payments/${row.id}/receipt`, { headers: { Authorization: `Bearer ${token}` } }); if (!response.ok) return setFeedback(t.error); const blob = await response.blob(); const url = URL.createObjectURL(blob); window.open(url, '_blank', 'noopener'); window.setTimeout(() => URL.revokeObjectURL(url), 60000); }}><FileImage size={15} />{row.receipt_file_name || 'Open receipt'}</button>}</div><div className="admin-row-actions"><button className="button button-small button-success" onClick={() => reviewPayment(row, 'approved')}>{t.approve}</button><button className="button button-small button-danger" onClick={() => reviewPayment(row, 'rejected')}>{t.reject}</button></div></div>)}</div> : <div className="empty-inline">{t.noPayments}</div>}</div>}
    {tab === 'reviews' && isAdmin && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">COMMUNITY QUALITY</span><h2>{t.reviews}</h2></div></div>{dataLoading ? <Loading /> : reviews.length ? <div className="admin-list">{reviews.map(row => <div className="admin-list-row" key={row.id}><div className="admin-list-content"><strong>{row.event_title}</strong><p>{row.user_name} · {'★'.repeat(row.rating || 0)}</p><blockquote className="receipt-quote">{row.text}</blockquote></div><div className="admin-row-actions"><button className="button button-small button-success" onClick={() => moderate('reviews', row.id, 'approved')}>{t.approve}</button><button className="button button-small button-danger" onClick={() => moderate('reviews', row.id, 'rejected')}>{t.reject}</button></div></div>)}</div> : <div className="empty-inline">{t.noReviews}</div>}</div>}
    {tab === 'topics' && isAdmin && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">MEMBER IDEAS</span><h2>{t.topicIdeas}</h2></div></div>{dataLoading ? <Loading /> : topics.length ? <div className="admin-list">{topics.map(row => <div className="admin-list-row" key={row.id}><div className="admin-list-content"><strong>{row.title}</strong><small>{row.user_name} · {formatDate(row.created_at, locale)}</small></div><div className="admin-row-actions"><button className="button button-small button-success" onClick={() => moderate('topics', row.id, 'approved')}>{t.approve}</button><button className="button button-small button-danger" onClick={() => moderate('topics', row.id, 'rejected')}>{t.reject}</button></div></div>)}</div> : <div className="empty-inline">—</div>}</div>}
    {tab === 'members' && isAdmin && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">MEMBER DIRECTORY</span><h2>{t.members}</h2></div></div><label className="search-box admin-search"><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder={t.searchMembers} /></label>{dataLoading ? <Loading /> : <div className="members-table">{members.map(member => <div className="member-row" key={member.id}><span className="avatar">{(member.name || 'P').charAt(0)}</span><span><strong>{member.name || '—'}</strong><small>{member.username ? `@${member.username}` : member.telegram_id}</small></span>{isSuperAdmin ? <select aria-label={`Role for ${member.name||member.id}`} value={member.role} disabled={member.role==='host'} onChange={e=>void updateMemberRole(member,e.target.value)}><option value="participant">Member</option><option value="admin">Admin</option><option value="super_admin">Superadmin</option>{member.role==='host'&&<option value="host">Host (approval-managed)</option>}</select> : <span>{member.role}</span>}<span>{member.confirmed_bookings} {locale === 'fa' ? 'رزرو' : 'bookings'}</span></div>)}</div>}</div>}
    {tab === 'shop' && isAdmin && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">REWARD OPERATIONS</span><h2>{locale === 'fa' ? 'درخواست‌های فروشگاه امتیاز' : 'XP Shop requests'}</h2></div><span className="count-badge">{shopRequests.length}</span></div>{dataLoading ? <Loading /> : shopRequests.length ? <div className="admin-list">{shopRequests.map(row => <div className="admin-list-row" key={row.id}><div className="admin-list-content"><strong>#{row.id} · {row.title}</strong><p>{locale === 'fa' ? 'شناسه تلگرام' : 'Telegram ID'}: {row.telegram_id}</p><small>{row.discount_percent}% · {row.xp_cost} XP · {formatDate(row.created_at, locale)}</small></div><div className="admin-row-actions"><button className="button button-small button-success" onClick={() => reviewShopRequest(row, 'approved')}>{t.approve}</button><button className="button button-small button-danger" onClick={() => reviewShopRequest(row, 'denied')}>{t.reject}</button></div></div>)}</div> : <div className="empty-inline">{locale === 'fa' ? 'درخواست در انتظاری وجود ندارد.' : 'No XP requests are awaiting review.'}</div>}</div>}
    {tab === 'hosts' && isSuperAdmin && <PlatformHostsPanel hosts={hosts} loading={dataLoading} locale={locale} onReload={loadTab} onMessage={setFeedback} />}
    {tab === 'cities' && isAdmin && <PlatformCitiesPanel cities={cities} loading={dataLoading} locale={locale} onReload={loadTab} onMessage={setFeedback} />}
    {tab === 'national' && isAdmin && <PlatformNationalPanel locale={locale} onMessage={setFeedback} />}
    {tab === 'audit' && isSuperAdmin && <div className="surface-card workspace-panel"><div className="surface-heading"><div><span className="eyebrow">ADMINISTRATIVE HISTORY</span><h2>{locale==='fa'?'گزارش رویدادهای مدیریتی':'Administrative audit log'}</h2><p>{locale==='fa'?'فقط تغییرات مهم مدیریتی؛ اطلاعات خصوصی پرداخت و اعضا نمایش داده نمی‌شود.':'Important administrative decisions only. Private payment evidence and member details are not exposed.'}</p></div><span className="count-badge">{auditLogs.length}</span></div>{dataLoading?<Loading/>:auditLogs.length?<div className="audit-log-list">{auditLogs.map((row:any)=><article className="audit-log-row" key={row.id}><div><strong>{row.action.replace(/[._]/g,' ')}</strong><p>{row.actor_name || 'System'} · {row.source === 'telegram' ? 'Telegram admin' : 'Website'} · {row.target_type || 'record'} {row.target_id ? `#${row.target_id}` : ''}</p><small>{formatDate(row.created_at,locale)} · {row.metadata?.event_id ? `Event #${row.metadata.event_id}` : ''}{row.metadata?.booking_id ? ` · Booking #${row.metadata.booking_id}` : ''}{row.metadata?.from_role ? ` · ${row.metadata.from_role} → ${row.metadata.to_role}` : ''}{row.metadata?.decision ? ` · ${row.metadata.decision}` : ''}</small></div><span className="audit-log-action">{row.organization_id ? `Org #${row.organization_id}` : 'Platform'}</span></article>)}</div>:<div className="empty-inline">{locale==='fa'?'هنوز رویدادی ثبت نشده است.':'No audit entries have been recorded yet.'}</div>}</div>}
  </div>;
}

function HostParticipantsPanel() {
  const { locale } = useLanguage(); const { token } = useAuth(); const fa = locale === 'fa';
  const { data: eventPage, loading: eventsLoading, error: eventsError } = useRequest<ApiPage<EventData>>('/staff/events?limit=100');
  const events = eventPage?.items || [];
  const [eventId, setEventId] = useState(''); const [busyId, setBusyId] = useState<number | null>(null); const [actionError, setActionError] = useState('');
  const [rosterOffset,setRosterOffset]=useState(0); const [waitlistOffset,setWaitlistOffset]=useState(0);
  const [attendanceBusy,setAttendanceBusy]=useState(false); const [waitlistBusy,setWaitlistBusy]=useState(false); const [qrBusy,setQrBusy]=useState(false); const [qrData,setQrData]=useState<any>(null); const [historyOpen,setHistoryOpen]=useState(false);
  useEffect(() => { if (!eventId && events.length) setEventId(String(events[0].id)); }, [eventId, events]);
  useEffect(() => { setQrData(null); setHistoryOpen(false); setRosterOffset(0); setWaitlistOffset(0); }, [eventId]);
  const { data, loading, error, reload } = useRequest<any>(eventId ? `/staff/host/events/${eventId}/participants?limit=50&offset=${rosterOffset}&waitlist_offset=${waitlistOffset}` : '', Boolean(eventId));
  const { data: historyData, reload: reloadHistory } = useRequest<any>(eventId && historyOpen ? `/staff/host/events/${eventId}/attendance-history?limit=100` : '', Boolean(eventId && historyOpen));
  const setAttendance = async (participantId: number, status: string) => {
    if (!eventId) return; setBusyId(participantId); setActionError('');
    try { await api(`/staff/host/events/${eventId}/participants/${participantId}/attendance`, { method: 'PATCH', body: JSON.stringify({ status }) }, token); await reload(); if(historyOpen) await reloadHistory(); }
    catch (e) { setActionError(e instanceof Error ? e.message : 'Attendance update failed.'); }
    finally { setBusyId(null); }
  };
  const toggleAttendance=async(enabled:boolean)=>{ if(!eventId)return;setAttendanceBusy(true);setActionError('');try{await api(`/staff/host/events/${eventId}/attendance`,{method:'PATCH',body:JSON.stringify({enabled})},token);setQrData(null);await reload();}catch(e){setActionError(e instanceof Error?e.message:'Attendance settings could not be updated.');}finally{setAttendanceBusy(false);}};
  const toggleWaitlist=async(enabled:boolean)=>{if(!eventId)return;setWaitlistBusy(true);setActionError('');try{await api(`/staff/host/events/${eventId}/waitlist`,{method:'PATCH',body:JSON.stringify({enabled})},token);await reload();}catch(e){setActionError(e instanceof Error?e.message:'Waitlist settings could not be updated.');}finally{setWaitlistBusy(false);}};
  const createQr=async()=>{if(!eventId)return;setQrBusy(true);setActionError('');try{const result=await api<any>(`/staff/host/events/${eventId}/attendance/qr`,{method:'POST'},token);setQrData(result);}catch(e){setActionError(e instanceof Error?e.message:'QR could not be created.');}finally{setQrBusy(false);}};
  return <div className="surface-card workspace-panel host-workspace-panel"><div className="surface-heading"><div><span className="eyebrow">PANEL REGISTRATIONS</span><h2>{fa ? 'شرکت‌کنندگان پنل‌های من' : 'My panel participants'}</h2><p>{fa ? 'فهرست ثبت‌نام‌ها، صف انتظار و حضور و غیاب پنل‌هایی که میزبان آن‌ها هستید.' : 'Registration roster, waitlist and attendance for panels you host.'}</p></div><Users size={19}/></div>
    {eventsLoading ? <Loading/> : eventsError ? <ErrorState message={eventsError}/> : !events.length ? <div className="empty-inline">{fa ? 'هنوز پنلی ندارید.' : 'You do not have any panels yet.'}</div> : <>
      <label className="host-panel-select">{fa ? 'انتخاب پنل' : 'Select panel'}<select value={eventId} onChange={e=>setEventId(e.target.value)}>{events.map(event=><option key={event.id} value={event.id}>{event.title} · {event.date}</option>)}</select></label>
      {actionError && <ErrorState message={actionError}/>}
      {loading ? <Loading/> : error ? <ErrorState message={error} retry={reload}/> : <>
        <div className="host-registration-settings"><span className={`status-pill ${data?.event?.registration_open?'status-success':'status-neutral'}`}>{fa?'ثبت‌نام':'Registration'}: {data?.event?.registration_open?(fa?'باز':'Open'):(fa?'بسته':'Closed')}</span><span className={`status-pill ${data?.event?.waitlist_enabled?'status-success':'status-neutral'}`}>{fa?'فهرست انتظار':'Waitlist'}: {data?.event?.waitlist_enabled?(fa?'فعال':'Enabled'):(fa?'غیرفعال':'Off')}</span><button className="button button-small button-outline" disabled={waitlistBusy || (data?.event?.status && data.event.status !== 'published' && !data?.event?.waitlist_enabled)} onClick={()=>void toggleWaitlist(!data?.event?.waitlist_enabled)}>{waitlistBusy?<LoaderCircle className="spin" size={15}/>:<ListOrdered size={15}/>} {data?.event?.waitlist_enabled?(fa?'غیرفعال‌کردن فهرست انتظار':'Disable waitlist'):(fa?'فعال‌کردن فهرست انتظار':'Enable waitlist')}</button><small>{fa?'فهرست ثبت‌نام‌ها خصوصی است و فقط برای میزبان مجاز نمایش داده می‌شود.':'The registration roster is private and visible only to the authorized host.'}</small></div>
        <section className="host-attendance-tools"><div className="host-attendance-tools-heading"><div><strong>{fa?'حضور و غیاب با QR':'QR attendance check-in'}</strong><small>{fa?'اختیاری است و فقط برای رزروهای تأییدشده فعال می‌شود.':'Optional; only confirmed bookings can check in.'}</small></div><span className={`status-pill ${data?.event?.attendance_enabled?'status-success':'status-neutral'}`}>{data?.event?.attendance_enabled?(fa?'فعال':'Enabled'):(fa?'غیرفعال':'Off')}</span></div>
          <div className="host-attendance-actions"><button className={`button button-small ${data?.event?.attendance_enabled?'button-outline':'button-orange'}`} disabled={attendanceBusy || (data?.event?.status && !['published','completed'].includes(data.event.status) && !data?.event?.attendance_enabled)} onClick={()=>void toggleAttendance(!data?.event?.attendance_enabled)}>{attendanceBusy?<LoaderCircle className="spin" size={15}/>:<CheckCircle2 size={15}/>} {data?.event?.attendance_enabled?(fa?'غیرفعال‌کردن حضور و غیاب':'Disable attendance'):(fa?'فعال‌کردن حضور و غیاب':'Enable attendance')}</button>{data?.event?.attendance_enabled&&<button className="button button-small button-outline" disabled={qrBusy} onClick={()=>void createQr()}>{qrBusy?<LoaderCircle className="spin" size={15}/>:<QrCode size={15}/>} {fa?'ساخت / نوسازی QR':'Generate / rotate QR'}</button>}{data?.event?.attendance_enabled&&<button className="button button-small button-outline" onClick={()=>setHistoryOpen(value=>!value)}>{fa?'سابقه حضور':'Attendance history'}</button>}</div>
          {qrData&&<div className="host-attendance-qr"><img src={qrData.qr_data_url} alt={fa?'کد QR ثبت حضور این پنل':'QR check-in code for this panel'} loading="lazy"/><div><strong>{fa?'کد دستی ورود':'Manual check-in code'}</strong><code dir="ltr">{qrData.manual_code}</code><a className="button button-small button-outline" href={qrData.qr_data_url} download={`panelflow-checkin-${eventId}.png`}>{fa?'دریافت تصویر QR':'Download QR image'}</a><p>{fa?'شرکت‌کننده باید با همان حساب تلگرامی که رزرو تأییدشده دارد QR را باز کند و نام خودش را انتخاب کند.':'The participant must open the QR using the Telegram account that owns their confirmed booking, then select their own name.'}</p><small>{fa?'ساخت QR جدید، کد قبلی را فوراً باطل می‌کند.':'Generating a new QR immediately invalidates the previous code.'}</small></div></div>}
          {historyOpen&&<div className="host-attendance-history">{(historyData?.items||[]).length?(historyData.items.map((row:any)=><div key={row.id}><span><strong>{row.participant_name}</strong><small>{row.source} · {row.old_status} → {row.new_status}</small></span><time>{formatDate(row.created_at,locale)}</time></div>)):<small className="muted-copy">{fa?'هنوز تغییری ثبت نشده است.':'No attendance changes recorded yet.'}</small>}</div>}
        </section>
        <section className="host-contact-card"><div><strong>{fa?'ارتباط با ثبت‌نام‌شده‌ها':'Contact registered participants'}</strong><p>{fa?'از ربات تلگرام پنل فلو وارد مدیریت همین پنل شوید و بخش «ارتباطات پنل» را باز کنید. متن و مخاطبان را پیش‌نمایش و سپس ارسال را تأیید کنید.':'In the Panel Flow Telegram bot, open management for this panel → “Panel communications”. Review the recipient group and message preview, then explicitly confirm sending. Messages go to booking account holders; additional guests without their own linked account are not independently messaged.'}</p><a className="button button-small button-outline" href={`https://t.me/${(import.meta.env.VITE_TELEGRAM_BOT_USERNAME || 'PanelFlow_Bot').replace(/^@/, '')}?start=pfcontact_${eventId}`} target="_blank" rel="noreferrer">{fa?'بازکردن ارتباطات همین پنل':'Open this panel’s communications'}<ArrowUpRight size={14}/></a></div><MessageCircle size={20}/></section>
        <div className="host-roster-section-heading"><h3>{fa?'فهرست ثبت‌نام':'Registration list'}</h3><span className="count-badge">{data?.total||0}</span></div>
        {(data?.items || []).length ? <div className="host-roster-list">{data.items.map((booking:any)=><article className="host-roster-booking" key={booking.booking_id}><div className="host-roster-heading"><div><strong>{booking.registrant?.display_name || `Booking #${booking.booking_id}`}</strong><small>#{booking.booking_id} · {booking.status} · {booking.participant_count} {fa?'نفر':'participants'}</small></div><span className="status-pill">{booking.status}</span></div>
          <div className="host-roster-participants">{(booking.participants || []).map((person:any)=><div className="host-roster-person" key={person.id}><span><strong>{person.full_name}</strong><small>{person.phone_number || booking.contact_phone || '—'}</small></span>{data.event?.attendance_enabled && booking.status==='confirmed' ? <select disabled={busyId===person.id} aria-label={`Attendance for ${person.full_name}`} value={person.attendance_status} onChange={e=>void setAttendance(person.id,e.target.value)}><option value="unmarked">Unmarked</option><option value="attended">Attended</option><option value="no_show">No show</option></select> : <small className="muted-copy">{person.attendance_status?.replaceAll('_',' ') || '—'}</small>}</div>)}</div>
        </article>)}</div> : <div className="empty-inline">{fa?'ثبت‌نامی برای این پنل ثبت نشده است.':'No registrations have been recorded for this panel.'}</div>}
        {(data?.total||0)>50&&<div className="host-list-pagination"><button className="button button-small button-outline" disabled={rosterOffset<=0} onClick={()=>setRosterOffset(Math.max(0,rosterOffset-50))}>{fa?'قبلی':'Previous'}</button><small>{Math.floor(rosterOffset/50)+1} / {Math.max(1,Math.ceil((data?.total||0)/50))}</small><button className="button button-small button-outline" disabled={rosterOffset+50>=(data?.total||0)} onClick={()=>setRosterOffset(rosterOffset+50)}>{fa?'بعدی':'Next'}</button></div>}
        <div className="host-roster-section-heading"><h3>{fa?'صف انتظار':'Waitlist'}</h3><span className="count-badge">{data?.waitlist_total||0}</span></div>
        {(data?.waitlist||[]).length?<div className="host-waitlist-list">{data.waitlist.map((row:any)=><div className="host-waitlist-row" key={row.id}><span><strong>#{row.position} · {row.member_name}</strong><small>{row.requested_participant_count} {fa?'نفر':'requested seats'} · {formatDate(row.created_at,locale)}</small></span><span className={`status-pill ${row.status==='invited'?'status-success':''}`}>{row.status}{row.status==='invited'&&row.invitation_expires_at?` · ${fa?'مهلت':'expires'} ${formatDate(row.invitation_expires_at,locale)}`:''}</span></div>)}</div>:<div className="empty-inline">{fa?'صف انتظاری وجود ندارد.':'No active waitlist entries.'}</div>}
        {(data?.waitlist_total||0)>50&&<div className="host-list-pagination"><button className="button button-small button-outline" disabled={waitlistOffset<=0} onClick={()=>setWaitlistOffset(Math.max(0,waitlistOffset-50))}>{fa?'قبلی':'Previous'}</button><small>{Math.floor(waitlistOffset/50)+1} / {Math.max(1,Math.ceil((data?.waitlist_total||0)/50))}</small><button className="button button-small button-outline" disabled={waitlistOffset+50>=(data?.waitlist_total||0)} onClick={()=>setWaitlistOffset(waitlistOffset+50)}>{fa?'بعدی':'Next'}</button></div>}
      </>}
    </>}
  </div>;
}

function HostSeriesPanel() {
  const { locale }=useLanguage(); const { token }=useAuth(); const fa=locale==='fa';
  const {data:seriesData,loading,error,reload}=useRequest<ApiPage<any>>('/staff/host/series');
  const {data:eventData,loading:eventLoading,error:eventError}=useRequest<ApiPage<EventData>>('/staff/events?limit=100');
  const available=(eventData?.items||[]).filter(event=>['published','completed'].includes(event.status)&&!event.is_postponed);
  const [title,setTitle]=useState(''); const [description,setDescription]=useState(''); const [eventIds,setEventIds]=useState<number[]>([]);
  const [editingId,setEditingId]=useState<number|null>(null); const [busy,setBusy]=useState(false); const [message,setMessage]=useState(''); const [saveError,setSaveError]=useState('');
  const toggleEvent=(id:number)=>setEventIds(current=>current.includes(id)?current.filter(value=>value!==id):[...current,id]);
  const clearForm=()=>{setTitle('');setDescription('');setEventIds([]);setEditingId(null);setSaveError('');};
  const edit=(item:any)=>{setEditingId(item.id);setTitle(item.title);setDescription(item.description||'');setEventIds(item.event_ids||[]);setMessage('');setSaveError('');};
  const save=async(e:FormEvent)=>{e.preventDefault();setBusy(true);setSaveError('');setMessage('');try{const body=JSON.stringify({title,description:description||null,event_ids:eventIds});await api(editingId?`/staff/host/series/${editingId}`:'/staff/host/series',{method:editingId?'PATCH':'POST',body},token);setMessage(fa?'مجموعه ذخیره شد.':'Series saved.');clearForm();await reload();}catch(err){setSaveError(err instanceof Error?err.message:'Series could not be saved.');}finally{setBusy(false);}};
  const archive=async(id:number)=>{if(!window.confirm(fa?'این مجموعه بایگانی شود؟':'Archive this discussion series?'))return;setBusy(true);try{await api(`/staff/host/series/${id}`,{method:'DELETE'},token);await reload();setMessage(fa?'مجموعه بایگانی شد.':'Series archived.');}catch(err){setSaveError(err instanceof Error?err.message:'Series could not be archived.');}finally{setBusy(false);}};
  return <div className="surface-card workspace-panel host-workspace-panel"><div className="surface-heading"><div><span className="eyebrow">CONNECTED DISCUSSIONS</span><h2>{fa?'مجموعه پنل‌ها':'Discussion series'}</h2><p>{fa?'چند پنل مرتبط را به ترتیب زمانی در یک مسیر گفت‌وگو قرار دهید.':'Connect at least two panels into an ordered discussion journey.'}</p></div><ListOrdered size={20}/></div>
    {(message||saveError)&&<div className={`notice ${saveError?'notice-error':'notice-success'}`}>{saveError||message}</div>}
    <form className="host-series-form" onSubmit={save}><label>{fa?'عنوان مجموعه':'Series title'}<input required minLength={2} maxLength={255} value={title} onChange={e=>setTitle(e.target.value)}/></label><label>{fa?'توضیحات':'Description'}<textarea rows={3} maxLength={3000} value={description} onChange={e=>setDescription(e.target.value)}/></label><div className="host-series-events"><strong>{fa?'ترتیب پنل‌ها (حداقل دو پنل)':'Panels in order (select at least two)'}</strong>{eventLoading?<Loading/>:eventError?<ErrorState message={eventError}/>:available.map(event=><label className="checkbox-line" key={event.id}><input type="checkbox" checked={eventIds.includes(event.id)} onChange={()=>toggleEvent(event.id)}/><span>{event.title}<small>{event.date} · {event.city}</small></span></label>)}</div><div className="host-series-form-actions"><button className="button button-orange" disabled={busy||title.trim().length<2||eventIds.length<2}>{busy?<LoaderCircle className="spin" size={15}/>:<Save size={15}/>} {editingId?(fa?'ذخیره تغییرات':'Save changes'):(fa?'ساخت مجموعه':'Create series')}</button>{editingId&&<button type="button" className="button button-outline" onClick={clearForm}>{fa?'انصراف':'Cancel edit'}</button>}</div></form>
    <div className="host-roster-section-heading"><h3>{fa?'مجموعه‌های من':'My series'}</h3><span className="count-badge">{seriesData?.total||0}</span></div>
    {loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:seriesData?.items?.length?<div className="host-series-list">{seriesData.items.map((item:any)=><article key={item.id} className="host-series-row"><div><strong>{item.title}</strong><small>{(item.events||[]).map((event:any)=>event.title).join(' · ')}</small><Link to={`/series/${item.slug}`} target="_blank" className="text-link">{fa?'صفحه عمومی مجموعه':'Public series page'}<ArrowUpRight size={13}/></Link></div><div><button className="button button-small button-outline" onClick={()=>edit(item)}>{fa?'ویرایش':'Edit'}</button><button className="button button-small button-danger" disabled={busy} onClick={()=>void archive(item.id)}>{fa?'بایگانی':'Archive'}</button></div></article>)}</div>:<div className="empty-inline">{fa?'هنوز مجموعه‌ای نساخته‌اید.':'You have not created a discussion series yet.'}</div>}
  </div>;
}

function HostPaymentsPanel() {
  const { locale } = useLanguage(); const { token } = useAuth(); const fa = locale === 'fa';
  const { data, loading, error, reload } = useRequest<ApiPage<any>>('/staff/host/payments?limit=200');
  const [opening, setOpening] = useState<number | null>(null); const [message, setMessage] = useState('');
  const openReceipt = async (id:number) => { setOpening(id); setMessage(''); try { const response = await fetch(`${API_BASE}/staff/host/payments/${id}/receipt`, { headers: { Authorization: `Bearer ${token}` } }); if (!response.ok) throw new Error(response.status===404?'Receipt not found':'Receipt could not be opened'); const blob=await response.blob(); const url=URL.createObjectURL(blob); window.open(url,'_blank','noopener'); window.setTimeout(()=>URL.revokeObjectURL(url),60000); } catch(e) { setMessage(e instanceof Error?e.message:'Receipt could not be opened'); } finally { setOpening(null); } };
  return <div className="surface-card workspace-panel host-workspace-panel"><div className="surface-heading"><div><span className="eyebrow">HOST FINANCIAL RECORDS</span><h2>{fa?'سوابق پرداخت و رسیدها':'Payments & receipts'}</h2><p>{fa?'گزارش فقط شامل تراکنش‌های پنل‌های شماست؛ تأیید یا رد پرداخت همچنان در اختیار مدیران مجاز است.':'Records are restricted to your own panels. Payment approval and rejection remain with authorized administrators.'}</p></div><Wallet size={19}/></div>
    {message&&<ErrorState message={message}/>}{loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:data?.items?.length?<div className="admin-list">{data.items.map((row:any)=><div className="admin-list-row" key={row.id}><div className="admin-list-content"><strong>{row.event_title}</strong><p>{row.registrant_name} · {row.participant_count} {fa?'نفر':'participants'}</p><small>#{row.booking_id} · {row.payment_status} · {formatMoney(row.amount,locale)} · {formatDate(row.created_at,locale)}</small>{row.receipt_text&&<blockquote className="receipt-quote">{row.receipt_text}</blockquote>}{row.has_file&&<button className="text-link" disabled={opening===row.id} onClick={()=>void openReceipt(row.id)}><FileImage size={15}/>{opening===row.id?(fa?'در حال باز کردن…':'Opening…'):(row.receipt_file_name||'Open receipt')}</button>}</div><StatusPill status={row.payment_status}/></div>)}</div>:<div className="empty-inline">{fa?'تراکنشی برای پنل‌های شما ثبت نشده است.':'No payment records exist for your panels.'}</div>}
  </div>;
}

function HostReviewsPanel() {
  const { locale } = useLanguage(); const fa = locale === 'fa';
  const { data, loading, error, reload } = useRequest<ApiPage<any>>('/staff/host/reviews?limit=200');
  return <div className="surface-card workspace-panel host-workspace-panel"><div className="surface-heading"><div><span className="eyebrow">APPROVED MEMBER FEEDBACK</span><h2>{fa?'بازخورد پنل‌های من':'My panel feedback'}</h2><p>{fa?'فقط دیدگاه‌های تأییدشده درباره پنل‌های شما نمایش داده می‌شود.':'Only approved reviews for panels you host are shown.'}</p></div><MessageSquare size={19}/></div>
    {loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:data?.items?.length?<div className="admin-list">{data.items.map((row:any)=><article className="admin-list-row host-review-row" key={row.id}><div className="admin-list-content"><strong>{row.event_title}</strong><small>{row.reviewer_name} · {'★'.repeat(row.rating||0)} · {formatDate(row.created_at,locale)}</small><blockquote className="receipt-quote">{row.text||'—'}</blockquote><div className="host-review-scores">{([['discussion_quality',fa?'کیفیت گفت‌وگو':'Discussion'],['moderator_rating',fa?'مدیر گفت‌وگو':'Moderator'],['topic_relevance',fa?'ارتباط موضوع':'Topic relevance']] as const).filter(([key])=>row[key]!=null).map(([key,label])=><span key={key}><strong>{label}</strong> {row[key]}/5</span>)}{row.would_attend_again!=null&&<span><strong>{fa?'شرکت دوباره':'Attend again'}</strong> {row.would_attend_again?(fa?'بله':'Yes'):(fa?'خیر':'No')}</span>}</div></div></article>)}</div>:<div className="empty-inline">{fa?'هنوز بازخورد تأییدشده‌ای ثبت نشده است.':'No approved feedback is available yet.'}</div>}
  </div>;
}

function HostProfileEditor() {
  const { locale } = useLanguage(); const { token } = useAuth(); const fa = locale === 'fa';
  const { data, loading, error, reload } = useRequest<any>('/me/host-profile');
  const { data: cityPage } = useRequest<ApiPage<CityData>>('/cities');
  const [displayName,setDisplayName] = useState(''); const [bio,setBio] = useState(''); const [languages,setLanguages] = useState(''); const [topics,setTopics] = useState(''); const [cityIds,setCityIds] = useState<number[]>([]); const [busy,setBusy] = useState(false); const [message,setMessage] = useState(''); const [saveError,setSaveError] = useState('');
  useEffect(()=>{if(data){setDisplayName(data.display_name||'');setBio(data.bio||'');setLanguages((data.languages||[]).join(', '));setTopics((data.topics||[]).join(', '));setCityIds(data.city_ids||[]);}},[data]);
  const toggleCity=(id:number)=>setCityIds(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id]);
  const save=async()=>{setBusy(true);setMessage('');setSaveError('');try{await api('/me/host-profile',{method:'PATCH',body:JSON.stringify({display_name:displayName,bio,languages:languages.split(',').map(x=>x.trim()).filter(Boolean),topics:topics.split(',').map(x=>x.trim()).filter(Boolean),city_ids:cityIds})},token);setMessage(fa?'پروفایل ذخیره شد.':'Public profile saved.');await reload();}catch(e){setSaveError(e instanceof Error?e.message:'Profile could not be saved.');}finally{setBusy(false);}};
  return <div className="surface-card workspace-panel host-workspace-panel"><div className="surface-heading"><div><span className="eyebrow">PUBLIC HOST PROFILE</span><h2>{fa?'پروفایل عمومی من':'My public host profile'}</h2><p>{fa?'این اطلاعات در صفحه عمومی میزبان نمایش داده می‌شود.':'These details are visible on your public host profile.'}</p></div><UserRound size={19}/></div>
    {loading?<Loading/>:error?<ErrorState message={error} retry={reload}/>:<><div className="host-profile-editor"><label>{fa?'نام نمایشی':'Display name'}<input value={displayName} onChange={e=>setDisplayName(e.target.value)} maxLength={255}/></label><label>{fa?'زبان‌ها':'Languages'}<input value={languages} onChange={e=>setLanguages(e.target.value)} placeholder="English, فارسی"/></label><label className="wide">{fa?'معرفی عمومی':'Public biography'}<textarea rows={5} value={bio} onChange={e=>setBio(e.target.value)} maxLength={3000}/></label><label className="wide">{fa?'موضوع‌های موردعلاقه':'Topics'}<input value={topics} onChange={e=>setTopics(e.target.value)} placeholder="Culture, technology, society"/></label><div className="wide"><strong>{fa?'شهرهای پروفایل':'Profile cities'}</strong><div className="host-app-choice-grid">{(cityPage?.items||[]).map(city=><label className="checkbox-line" key={city.id}><input type="checkbox" checked={cityIds.includes(city.id)} onChange={()=>toggleCity(city.id)}/>{fa?city.name_fa:city.name_en}</label>)}</div></div></div>
    {message&&<div className="notice notice-success"><CheckCircle2 size={16}/>{message}</div>}{saveError&&<ErrorState message={saveError}/>}<div className="host-profile-actions"><button className="button button-orange" disabled={busy||displayName.trim().length<2} onClick={()=>void save()}>{busy?<LoaderCircle className="spin" size={16}/>:<Save size={16}/>} {fa?'ذخیره پروفایل':'Save profile'}</button><Link className="button button-outline" to={`/hosts/${data.slug}`} target="_blank" rel="noopener noreferrer">{fa?'مشاهده صفحه عمومی':'View public profile'}<ArrowUpRight size={16}/></Link></div></>}
  </div>;
}

function EventManagementTable({ events, isAdmin, onUpdated }: { events: any[]; isAdmin: boolean; onUpdated: () => void | Promise<void> }) {
  const { t, locale } = useLanguage(); const { token } = useAuth();
  const setStatus = async (event: any, status: string) => { if (!window.confirm(locale === 'fa' ? `وضعیت پنل به «${statusLabel(status, locale)}» تغییر کند؟` : `Change panel status to ${status}?`)) return; try { await api(`/staff/events/${event.id}`, { method: 'PATCH', body: JSON.stringify({ status, registration_open: status === 'published' }) }, token); await onUpdated(); } catch (e) { window.alert(e instanceof Error ? e.message : t.error); } };
  const postpone = async (event:any, paused:boolean) => { const note = paused ? window.prompt(locale==='fa'?'توضیح کوتاه برای شرکت‌کنندگان (اختیاری)':'Short note for registered participants (optional)','') : null; if(paused && note===null)return; const message = paused ? (locale==='fa'?'تعویق این پنل و بستن ثبت‌نام؟':'Postpone this panel and close registration?') : (locale==='fa'?'پنل از حالت تعویق خارج و ثبت‌نام دوباره باز شود؟':'Resume this panel and reopen registration?'); if(!window.confirm(message))return; try { await api(`/staff/events/${event.id}`,{method:'PATCH',body:JSON.stringify(paused?{is_postponed:true,postponement_note:note||''}:{is_postponed:false,registration_open:true})},token); await onUpdated(); } catch(e){window.alert(e instanceof Error?e.message:t.error);} };
  const toggleWaitlist = async (event:any) => { const enabled = !Boolean(event.waitlist_enabled); const message = enabled ? (locale==='fa'?'فهرست انتظار برای این پنل فعال شود؟':'Enable the waitlist for this panel?') : (locale==='fa'?'ثبت درخواست جدید در فهرست انتظار متوقف شود؟':'Pause new waitlist requests for this panel?'); if(!window.confirm(message))return; try { await api(`/staff/events/${event.id}`,{method:'PATCH',body:JSON.stringify({waitlist_enabled:enabled})},token); await onUpdated(); } catch(e){window.alert(e instanceof Error?e.message:t.error);} };
  if (!events.length) return <div className="empty-inline">{t.emptyEvents}</div>;
  return <div className="events-admin-table">{events.map(event => <div className="event-admin-row" key={event.id}><div className="event-admin-main"><strong>{event.title}</strong><span>{event.date} · {event.venue}</span>{event.content_quality && <small className={`content-quality${event.content_quality.ready?' ready':''}`} title={(event.content_quality.missing||[]).join(', ')}>{locale==='fa'?`کیفیت محتوا ${event.content_quality.score}%`:`Content quality ${event.content_quality.score}%`}</small>}<CalendarDateInline event={event} canEdit={isAdmin || Boolean(event.can_publish) || event.status === 'draft'} /></div><div className="event-admin-meta"><StatusPill status={event.status} /><span>{event.capacity} {t.seats}</span></div><div className="event-admin-actions">{(isAdmin || event.can_publish) && event.status === 'draft' && <button className="button button-small button-primary" onClick={() => setStatus(event, 'published')}>{t.publish}</button>}{(isAdmin || event.can_publish) && event.status === 'published' && !event.is_postponed && <><button className="button button-small button-outline" onClick={() => void postpone(event,true)}>{locale === 'fa' ? 'تعویق پنل' : 'Postpone'}</button><button className="button button-small button-outline" onClick={() => setStatus(event, 'completed')}>{locale === 'fa' ? 'اتمام پنل' : 'Complete'}</button></>}{(isAdmin || event.can_publish) && event.status === 'published' && event.is_postponed && <button className="button button-small button-primary" onClick={() => void postpone(event,false)}>{locale === 'fa' ? 'ازسرگیری ثبت‌نام' : 'Resume registration'}</button>}{(isAdmin || event.can_publish) && event.status === 'published' && <button className="button button-small button-outline" onClick={() => void toggleWaitlist(event)}><ListOrdered size={13}/>{event.waitlist_enabled?(locale==='fa'?'توقف فهرست انتظار':'Pause waitlist'):(locale==='fa'?'فعال‌سازی فهرست انتظار':'Enable waitlist')}</button>}{isAdmin && <a className="button button-small button-outline" href={`https://t.me/${(import.meta.env.VITE_TELEGRAM_BOT_USERNAME || 'PanelFlow_Bot').replace(/^@/, '')}?start=pfcontact_${event.id}`} target="_blank" rel="noreferrer"><MessageCircle size={13}/>{locale==='fa'?'ارتباط با ثبت‌نام‌شده‌ها':'Contact participants'}</a>}</div></div>)}</div>;
}

function CalendarDateInline({ event, canEdit }: { event: EventData; canEdit: boolean }) {
  const { locale } = useLanguage(); const { token } = useAuth(); const [dateIso,setDateIso] = useState(event.date_iso || ''); const [busy,setBusy] = useState(false); const [saved,setSaved] = useState(false); const [error,setError] = useState('');
  if (event.date_iso) return <small className="calendar-date-saved"><CalendarDays size={12}/>{locale==='fa'?'در تقویم ثبت شده':'Calendar date set'}</small>;
  if (!canEdit) return <small className="calendar-date-missing">{locale==='fa'?'تاریخ تقویمی ثبت نشده':'No structured calendar date'}</small>;
  const save = async () => { if (!dateIso) return; const labels = formatDateLabels(dateIso,locale); setBusy(true); setError(''); try { await api(`/staff/events/${event.id}`,{method:'PATCH',body:JSON.stringify({date_iso:dateIso,date:labels.date,day:labels.day})},token); setSaved(true); } catch(e) { setError(e instanceof Error?e.message:'Update failed'); } finally { setBusy(false); } };
  return <div className="calendar-date-editor"><input aria-label="Calendar date" type="date" value={dateIso} onChange={e=>{setDateIso(e.target.value);setSaved(false);}}/><button type="button" disabled={!dateIso||busy} onClick={save}>{busy?<LoaderCircle className="spin" size={12}/>:<CalendarDays size={12}/>} {saved?(locale==='fa'?'ثبت شد':'Saved'):(locale==='fa'?'افزودن به تقویم':'Add to calendar')}</button>{error&&<small className="danger-text">{error}</small>}</div>;
}

function formatDateLabels(iso: string, locale: Locale) {
  if (!iso) return { day: '', date: '' };
  const date = new Date(`${iso}T12:00:00Z`);
  return {
    day: new Intl.DateTimeFormat(locale === 'fa' ? 'fa-IR' : 'en-US', { weekday: 'long', timeZone: 'Asia/Tehran' }).format(date),
    date: new Intl.DateTimeFormat(locale === 'fa' ? 'fa-IR-u-ca-persian' : 'en-GB', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Tehran' }).format(date),
  };
}

function CreateEventForm({ onCreated }: { onCreated: () => void | Promise<void> }) {
  const { t, locale } = useLanguage(); const { token, user } = useAuth();
  const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [coverImage,setCoverImage] = useState<File|null>(null); const [createdEventId,setCreatedEventId] = useState<number|null>(null);
  const { data: cityData } = useRequest<ApiPage<CityData>>('/cities');
  const { data: membershipData } = useRequest<ApiPage<any>>('/me/organizations', Boolean(token) && user?.role !== 'super_admin');
  const [organizationId, setOrganizationId] = useState(''); const [brands, setBrands] = useState<any[]>([]); const [brandsLoading, setBrandsLoading] = useState(false);
  const [form, setForm] = useState({ volume: '', title: '', language: 'فارسی', description: '', day: '', date: '', date_iso: '', start_time: '', end_time: '', event_type: 'physical', meeting_platform: 'Google Meet', meeting_link: '', meeting_link_released: false, venue: '', address: '', map_url: '', city: 'Mashhad', city_id: '', capacity: '15', price_per_person: '0', price_without_cafe_order: '', topic_tags: '', agenda_items: '', discussion_questions: '', waitlist_enabled: true });
  const memberships = (membershipData?.items || []).filter((m:any) => m.membership_status === 'approved' && m.organization_status === 'approved');
  const isPlatformAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  useEffect(() => {
    if (isPlatformAdmin || !memberships.length) return;
    if (!organizationId && memberships.length === 1) setOrganizationId(String(memberships[0].id));
  }, [isPlatformAdmin, memberships, organizationId]);
  useEffect(() => {
    if (!organizationId) { setBrands([]); return; }
    let active = true; setBrandsLoading(true);
    api<ApiPage<any>>(`/organizations/${organizationId}/brands`, {}, token)
      .then(result => { if (active) setBrands(result.items || []); })
      .catch(err => { if (active) setError(err instanceof Error ? err.message : t.error); })
      .finally(() => { if (active) setBrandsLoading(false); });
    return () => { active = false; };
  }, [organizationId, token, t.error]);
  const [brandId, setBrandId] = useState('');
  useEffect(() => { if (brandId && !brands.some(b => String(b.id) === brandId)) setBrandId(''); }, [brands, brandId]);
  const change = (key: string, value: string | boolean) => setForm(prev => ({ ...prev, [key]: value }));
  const online = form.event_type === 'online'; const hybrid = form.event_type === 'hybrid'; const needsVenue = !online;
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const payload:any = { ...form, organization_id: organizationId ? Number(organizationId) : null,
        brand_id: brandId ? Number(brandId) : null, city_id: form.city_id ? Number(form.city_id) : null,
        date_iso: form.date_iso || null, capacity: Number(form.capacity), price_per_person: Number(form.price_per_person),
        price_without_cafe_order: form.price_without_cafe_order === '' ? null : Number(form.price_without_cafe_order),
        venue: needsVenue ? form.venue : null, address: needsVenue ? form.address : null, map_url: needsVenue ? form.map_url : null,
        meeting_platform: online || hybrid ? form.meeting_platform : null,
        meeting_link: online || hybrid ? (form.meeting_link || null) : null,
        topic_tags: form.topic_tags.split(',').map(v=>v.trim().toLowerCase()).filter(Boolean),
        agenda_items: form.agenda_items.split('\n').map(v=>v.trim()).filter(Boolean),
        discussion_questions: form.discussion_questions.split('\n').map(v=>v.trim()).filter(Boolean) };
      let eventId = createdEventId;
      if (!eventId) {
        const created = await api<any>('/staff/events', { method: 'POST', body: JSON.stringify(payload) }, token);
        eventId = Number(created?.id || 0) || null;
        if (eventId && coverImage) setCreatedEventId(eventId);
      }
      if (coverImage && eventId) { const upload = new FormData(); upload.append('file',coverImage); await api(`/staff/events/${eventId}/cover-image`,{method:'POST',body:upload},token); }
      setCreatedEventId(null); setCoverImage(null); setOpen(false); await onCreated();
    } catch (err) { setError(err instanceof Error ? err.message : t.error); }
    finally { setBusy(false); }
  };
  return <div className="create-event-wrap"><button className="create-event-toggle" onClick={() => setOpen(!open)}>{open ? <Minus size={17} /> : <Plus size={17} />}{t.createEvent}<ChevronDown size={16} /></button>{open && <form className="create-event-form" onSubmit={submit}>
    {!isPlatformAdmin && <div className="form-row"><label>{locale==='fa'?'سازمان برگزارکننده':'Organizing organization'}<select required value={organizationId} onChange={e=>{setOrganizationId(e.target.value);setBrandId('');}}><option value="">{locale==='fa'?'انتخاب سازمان':'Select organization'}</option>{memberships.map((m:any)=><option key={m.id} value={m.id}>{m.name} · {m.role}</option>)}</select><small className="form-footnote">{locale==='fa'?'فقط عضویت‌های تأییدشده نمایش داده می‌شوند.':'Only approved memberships are available.'} <Link to="/my-organizations">{locale==='fa'?'مدیریت سازمان‌ها':'Manage organizations'}</Link></small></label><label>{locale==='fa'?'برند':'Brand'}<select required value={brandId} onChange={e=>setBrandId(e.target.value)} disabled={!organizationId || brandsLoading}><option value="">{brandsLoading?(locale==='fa'?'در حال دریافت…':'Loading…'):(locale==='fa'?'انتخاب برند':'Select brand')}</option>{brands.map((b:any)=><option key={b.id} value={b.id}>{b.name}</option>)}</select></label></div>}
    {isPlatformAdmin && <small className="form-footnote">{locale==='fa'?'به‌عنوان مدیر کل، پنل بدون انتخاب سازمان به سازمان بنیان‌گذار پنل فلو متصل می‌شود.':'As platform administrator, an event without an organization selection is assigned to the Panel Flow founding organization.'}</small>}
    <div className="form-row"><label>{t.volume}<input required value={form.volume} onChange={e => change('volume', e.target.value)} /></label><label>{t.eventTitle}<input required value={form.title} onChange={e => change('title', e.target.value)} /></label></div>
    <label>{t.description}<textarea rows={3} value={form.description} onChange={e => change('description', e.target.value)} /></label><label>{locale==='fa'?'تصویر کاور پنل':'Panel cover image'}<input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>{const file=e.target.files?.[0]||null;if(file&&file.size>8*1024*1024){setError(locale==='fa'?'حجم تصویر نباید بیشتر از ۸ مگابایت باشد.':'Image must be 8 MB or smaller.');setCoverImage(null);e.target.value='';}else{setError('');setCoverImage(file);}}}/><small className="form-footnote">{locale==='fa'?'حداکثر ۸ مگابایت؛ تصویر در سرور تغییر اندازه داده و به WebP تبدیل می‌شود.':'Max 8 MB. The server resizes and converts the image to WebP.'}</small></label>
    <div className="form-row"><label>{locale==='fa'?'نوع پنل':'Event type'}<select value={form.event_type} onChange={e=>change('event_type',e.target.value)}><option value="physical">{locale==='fa'?'حضوری':'Physical'}</option><option value="online">{locale==='fa'?'آنلاین':'Online'}</option><option value="hybrid">{locale==='fa'?'ترکیبی':'Hybrid'}</option></select></label><label>{t.city}<select required value={form.city_id} onChange={e => { const city = cityData?.items.find(item => String(item.id) === e.target.value); setForm(prev => ({ ...prev, city_id: e.target.value, city: city?.name_en || prev.city })); }}><option value="">{locale === 'fa' ? 'انتخاب شهر' : 'Select a city'}</option>{(cityData?.items || []).map(city => <option key={city.id} value={city.id}>{locale === 'fa' ? city.name_fa : city.name_en}</option>)}</select></label></div>
    <div className="form-row"><label>{t.date}<input required type="date" value={form.date_iso} onChange={e => { const labels = formatDateLabels(e.target.value, locale); setForm(prev => ({ ...prev, date_iso: e.target.value, date: labels.date, day: labels.day })); }} /><small className="form-footnote">{form.date ? `${form.day} · ${form.date}` : (locale === 'fa' ? 'تاریخ با تقویم شمسی نمایش داده می‌شود.' : 'The selected date is also shown in the Persian calendar.')}</small></label><label>{t.startTime}<input required type="time" value={form.start_time} onChange={e => change('start_time', e.target.value)} /></label></div>
    <div className="form-row"><label>{t.endTime}<input type="time" value={form.end_time} onChange={e => change('end_time', e.target.value)} /></label>{needsVenue && <label>{t.venue}<input required value={form.venue} onChange={e => change('venue', e.target.value)} /></label>}</div>
    {(online || hybrid) && <><div className="form-row"><label>{locale==='fa'?'پلتفرم جلسه':'Meeting platform'}<select value={form.meeting_platform} onChange={e=>change('meeting_platform',e.target.value)}><option>Google Meet</option><option>Zoom</option><option>Microsoft Teams</option><option>{locale==='fa'?'سایر':'Other'}</option></select></label><label>{locale==='fa'?'لینک جلسه (اختیاری و خصوصی)':'Meeting link (optional, private)'}<input type="url" value={form.meeting_link} onChange={e=>change('meeting_link',e.target.value)} placeholder="https://…" /></label></div><label className="checkbox-line"><input type="checkbox" checked={form.meeting_link_released} onChange={e=>change('meeting_link_released',e.target.checked)} />{locale==='fa'?'انتشار لینک برای شرکت‌کنندگان تأییدشده':'Release link to confirmed participants now'}</label></>}
    {needsVenue && <><div className="form-row"><label>{locale==='fa'?'نشانی':'Address'}<input value={form.address} onChange={e => change('address', e.target.value)} /></label><label>{locale==='fa'?'لینک نقشه':'Map URL'}<input type="url" value={form.map_url} onChange={e => change('map_url', e.target.value)} /></label></div></>}
    <div className="form-row"><label>{locale==='fa'?'موضوع‌ها (با ویرگول جدا کنید)':'Topics (comma separated)'}<input value={form.topic_tags} onChange={e=>change('topic_tags',e.target.value)} placeholder="philosophy, psychology, technology"/></label><label>{locale==='fa'?'دستور جلسه (هر مورد در یک خط)':'Discussion agenda (one item per line)'}<textarea rows={3} value={form.agenda_items} onChange={e=>change('agenda_items',e.target.value)}/></label></div><label>{locale==='fa'?'پرسش‌های بحث (هر پرسش در یک خط)':'Discussion questions (one per line)'}<textarea rows={3} value={form.discussion_questions} onChange={e=>change('discussion_questions',e.target.value)}/></label>
    <div className="form-row"><label>{t.capacityInput}<input type="number" min="0" required value={form.capacity} onChange={e => change('capacity', e.target.value)} /></label><label>{t.priceInput}<input type="number" min="0" required value={form.price_per_person} onChange={e => change('price_per_person', e.target.value)} /></label></div><label>{t.noCafe}<input type="number" min="0" value={form.price_without_cafe_order} onChange={e => change('price_without_cafe_order', e.target.value)} placeholder={t.optional} /></label><label className="checkbox-line"><input type="checkbox" checked={form.waitlist_enabled} onChange={e=>change('waitlist_enabled',e.target.checked)} />{locale==='fa'?'فعال‌بودن فهرست انتظار در صورت تکمیل ظرفیت':'Enable an optional waitlist when the panel becomes full'}</label>
    {error && <ErrorState message={error} />}<button className="button button-orange" disabled={busy || (!isPlatformAdmin && (!organizationId || !brandId))}>{busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}{createdEventId ? (locale==='fa'?'تلاش دوباره برای بارگذاری تصویر':'Retry image upload') : t.saveDraft}</button>
  </form>}</div>;
}

function PlatformNationalPanel({ locale, onMessage }: { locale:Locale; onMessage:(message:string)=>void }) {
  const { token } = useAuth();
  const [loading,setLoading] = useState(true); const [error,setError] = useState('');
  const [organizations,setOrganizations] = useState<any[]>([]); const [brands,setBrands] = useState<any[]>([]);
  const [hostVerifications,setHostVerifications] = useState<any[]>([]); const [orgVerifications,setOrgVerifications] = useState<any[]>([]);
  const [plans,setPlans] = useState<any[]>([]); const [selectedPlans,setSelectedPlans] = useState<Record<number,string>>({});
  const [planForm,setPlanForm] = useState({code:'starter',name:'Starter',price_amount:'0',currency:'IRR',duration_days:'30',max_brands:'1',max_hosts:'2'});
  const [busy,setBusy] = useState(false);
  const fa = locale === 'fa';
  const reload = useCallback(async()=>{
    setLoading(true); setError('');
    try {
      const [o,b,h,ov,p] = await Promise.all([
        api<ApiPage<any>>('/staff/platform/organizations?status=all',{},token),
        api<ApiPage<any>>('/staff/platform/brands?status=pending',{},token),
        api<ApiPage<any>>('/staff/platform/host-verifications?status=pending',{},token),
        api<ApiPage<any>>('/staff/platform/organization-verifications?status=pending',{},token),
        api<ApiPage<any>>('/staff/platform/subscription-plans',{},token),
      ]);
      setOrganizations(o.items||[]); setBrands(b.items||[]); setHostVerifications(h.items||[]); setOrgVerifications(ov.items||[]); setPlans(p.items||[]);
      setSelectedPlans(prev=>{const next={...prev};(o.items||[]).forEach((org:any)=>{if(!next[org.id] && (p.items||[])[0])next[org.id]=String((p.items||[])[0].id);});return next;});
    } catch(e) { setError(e instanceof Error?e.message:'Request failed'); }
    finally { setLoading(false); }
  },[token]);
  useEffect(()=>{void reload();},[reload]);
  const decide = async(path:string,status:string,needsReason=false) => {
    let reason:string|undefined;
    if(needsReason){reason=window.prompt(fa?'دلیل یا توضیح را وارد کنید':'Enter a reason or explanation')?.trim();if(!reason)return;}
    setBusy(true);
    try { const decision = status === 'pending' ? {status,requested_information:reason} : {status,reason}; await api(path,{method:'PATCH',body:JSON.stringify(decision)},token); onMessage(fa?'تصمیم مدیریتی ثبت شد.':'Administrative decision saved.'); await reload(); }
    catch(e){setError(e instanceof Error?e.message:'Request failed');} finally{setBusy(false);}
  };
  const createPlan = async(e:FormEvent)=>{
    e.preventDefault();setBusy(true);setError('');
    try{await api('/staff/platform/subscription-plans',{method:'POST',body:JSON.stringify({...planForm,price_amount:Number(planForm.price_amount),duration_days:Number(planForm.duration_days),max_brands:Number(planForm.max_brands),max_hosts:Number(planForm.max_hosts),features:{}})},token);setPlanForm({code:'',name:'',price_amount:'0',currency:'IRR',duration_days:'30',max_brands:'1',max_hosts:'2'});onMessage(fa?'طرح اشتراک ساخته شد.':'Subscription plan created.');await reload();}
    catch(e){setError(e instanceof Error?e.message:'Request failed');}finally{setBusy(false);}
  };
  const assignPlan = async(org:any)=>{
    const planId=Number(selectedPlans[org.id]);if(!planId)return;setBusy(true);
    try{await api(`/staff/platform/organizations/${org.id}/subscription`,{method:'POST',body:JSON.stringify({plan_id:planId,status:'active'})},token);onMessage(fa?'اشتراک سازمان فعال شد.':'Organization subscription activated.');await reload();}
    catch(e){setError(e instanceof Error?e.message:'Request failed');}finally{setBusy(false);}
  };
  if(loading)return <div className="surface-card workspace-panel"><Loading/></div>;
  return <div className="platform-national-stack">
    {error&&<ErrorState message={error} retry={reload}/>}
    <section className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">ORGANIZATION REVIEW</span><h2>{fa?'درخواست‌های سازمان':'Organization applications'}</h2><p>{fa?'تأیید سازمان تنها پس از تأیید هویت مالک امکان‌پذیر است.':'Approval is blocked until the organization owner has approved host identity verification.'}</p></div><span className="count-badge">{organizations.filter(o=>o.status==='pending').length}</span></div>
      {organizations.filter(o=>o.status==='pending').length?organizations.filter(o=>o.status==='pending').map(org=><div className="platform-city-row" key={org.id}><span><strong>{org.name}</strong><small dir="ltr">/{org.slug} · {org.status}</small></span><div className="admin-row-actions"><button className="button button-small button-success" disabled={busy} onClick={()=>void decide(`/staff/platform/organizations/${org.id}`,'approved')}>{fa?'تأیید':'Approve'}</button><button className="button button-small button-danger" disabled={busy} onClick={()=>void decide(`/staff/platform/organizations/${org.id}`,'rejected',true)}>{fa?'رد':'Reject'}</button></div></div>):<div className="empty-inline">{fa?'درخواست سازمان در انتظاری وجود ندارد.':'No organization applications are pending.'}</div>}
    </section>
    <section className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">BRAND REVIEW</span><h2>{fa?'برندهای در انتظار تأیید':'Brand approvals'}</h2></div><span className="count-badge">{brands.length}</span></div>{brands.length?brands.map(b=><div className="platform-city-row" key={b.id}><span><strong>{b.name}</strong><small>{b.organization} · /{b.slug}</small></span><div className="admin-row-actions"><button className="button button-small button-success" disabled={busy} onClick={()=>void decide(`/staff/platform/brands/${b.id}`,'approved')}>{fa?'تأیید':'Approve'}</button><button className="button button-small button-danger" disabled={busy} onClick={()=>void decide(`/staff/platform/brands/${b.id}`,'rejected',true)}>{fa?'رد':'Reject'}</button></div></div>):<div className="empty-inline">{fa?'برند در انتظار بررسی وجود ندارد.':'No brands are awaiting review.'}</div>}</section>
    <section className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">HOST VERIFICATION</span><h2>{fa?'احراز هویت میزبان‌ها':'Host identity reviews'}</h2><p>{fa?'شناسه ملی در این صفحه رمزنگاری‌شده و ماسک‌شده باقی می‌ماند.':'National identifiers remain masked in this review interface.'}</p></div><span className="count-badge">{hostVerifications.length}</span></div>{hostVerifications.length?hostVerifications.map(v=><div className="platform-city-row" key={v.id}><span><strong>{v.display_name||v.name}</strong><small>{v.national_id_masked} · {formatDate(v.submitted_at,locale)}</small></span><div className="admin-row-actions"><button className="button button-small button-success" disabled={busy} onClick={()=>void decide(`/staff/platform/host-verifications/${v.id}`,'approved')}>{fa?'تأیید هویت':'Approve identity'}</button><button className="button button-small button-danger" disabled={busy} onClick={()=>void decide(`/staff/platform/host-verifications/${v.id}`,'rejected',true)}>{fa?'رد':'Reject'}</button><button className="button button-small button-outline" disabled={busy} onClick={()=>void decide(`/staff/platform/host-verifications/${v.id}`,'pending',true)}>{fa?'درخواست تکمیل':'Request info'}</button></div></div>):<div className="empty-inline">{fa?'درخواست احراز هویت در انتظاری وجود ندارد.':'No host verification requests are pending.'}</div>}</section>
    <section className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">ORGANIZATION VERIFICATION</span><h2>{fa?'احراز هویت حقوقی سازمان‌ها':'Organization verification'}</h2></div><span className="count-badge">{orgVerifications.length}</span></div>{orgVerifications.length?orgVerifications.map(v=><div className="platform-city-row" key={v.id}><span><strong>{v.organization}</strong><small>{v.official_name} · {formatDate(v.submitted_at,locale)}</small></span><div className="admin-row-actions"><button className="button button-small button-success" disabled={busy} onClick={()=>void decide(`/staff/platform/organization-verifications/${v.id}`,'approved')}>{fa?'تأیید':'Approve'}</button><button className="button button-small button-danger" disabled={busy} onClick={()=>void decide(`/staff/platform/organization-verifications/${v.id}`,'rejected',true)}>{fa?'رد':'Reject'}</button></div></div>):<div className="empty-inline">{fa?'درخواست احراز حقوقی در انتظاری وجود ندارد.':'No organization verification requests are pending.'}</div>}</section>
    <section className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">SUBSCRIPTION PLANS</span><h2>{fa?'طرح‌های اشتراک سازمانی':'Organization subscription plans'}</h2></div><span className="count-badge">{plans.length}</span></div>
      <form className="platform-form" onSubmit={createPlan}><label>Code<input required pattern="[a-z0-9_-]+" value={planForm.code} onChange={e=>setPlanForm(p=>({...p,code:e.target.value}))}/></label><label>{fa?'نام طرح':'Plan name'}<input required value={planForm.name} onChange={e=>setPlanForm(p=>({...p,name:e.target.value}))}/></label><label>{fa?'مبلغ':'Price'}<input required type="number" min="0" value={planForm.price_amount} onChange={e=>setPlanForm(p=>({...p,price_amount:e.target.value}))}/></label><label>{fa?'واحد':'Currency'}<select value={planForm.currency} onChange={e=>setPlanForm(p=>({...p,currency:e.target.value}))}><option value="IRR">IRR</option><option value="TOMAN">Toman</option></select></label><label>{fa?'مدت (روز)':'Duration (days)'}<input required type="number" min="1" value={planForm.duration_days} onChange={e=>setPlanForm(p=>({...p,duration_days:e.target.value}))}/></label><label>{fa?'حداکثر برند':'Maximum brands'}<input required type="number" min="1" value={planForm.max_brands} onChange={e=>setPlanForm(p=>({...p,max_brands:e.target.value}))}/></label><label>{fa?'حداکثر میزبان':'Maximum hosts'}<input required type="number" min="1" value={planForm.max_hosts} onChange={e=>setPlanForm(p=>({...p,max_hosts:e.target.value}))}/></label><button className="button button-orange" disabled={busy}>{fa?'ساخت طرح':'Create plan'}</button></form>
      {organizations.filter(o=>o.status==='approved'&&!o.is_platform_founder).map(org=><div className="platform-city-row" key={`sub-${org.id}`}><span><strong>{org.name}</strong><small>{fa?'فعال‌سازی یا تمدید اشتراک سازمان':'Activate or renew this organization subscription'}</small></span><div className="admin-row-actions"><select className="host-plan-select" value={selectedPlans[org.id]||''} onChange={e=>setSelectedPlans(prev=>({...prev,[org.id]:e.target.value}))}><option value="">{fa?'انتخاب طرح':'Select plan'}</option>{plans.filter(p=>p.is_active).map(p=><option value={p.id} key={p.id}>{p.name} · {p.max_hosts} hosts / {p.max_brands} brands</option>)}</select><button className="button button-small button-success" disabled={busy||!selectedPlans[org.id]} onClick={()=>void assignPlan(org)}>{fa?'فعال‌سازی':'Activate'}</button></div></div>)}
    </section>
  </div>;
}

function PlatformHostsPanel({ hosts, loading, locale, onReload, onMessage }: { hosts:any[]; loading:boolean; locale:Locale; onReload:()=>void|Promise<void>; onMessage:(message:string)=>void }) {
  const { token } = useAuth(); const [telegramId,setTelegramId]=useState(''); const [plan,setPlan]=useState('starter'); const [days,setDays]=useState('30'); const [price,setPrice]=useState('0'); const [currency,setCurrency]=useState('TOMAN'); const [notes,setNotes]=useState(''); const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  const addHost=async(e:FormEvent)=>{e.preventDefault();setBusy(true);setError('');try{await api('/staff/platform/hosts',{method:'POST',body:JSON.stringify({telegram_id:Number(telegramId),plan_code:plan,duration_days:Number(days),price_amount:Number(price),currency,status:'active',notes:notes||null})},token);setTelegramId('');setNotes('');onMessage(locale==='fa'?'میزبان و اشتراک او ایجاد شد.':'Host and subscription created.');await onReload();}catch(err){setError(err instanceof Error?err.message:'Request failed');}finally{setBusy(false);}};
  const update=async(host:any,body:any)=>{try{await api(`/staff/platform/hosts/${host.id}/subscription`,{method:'PATCH',body:JSON.stringify(body)},token);onMessage(locale==='fa'?'اشتراک به‌روزرسانی شد.':'Subscription updated.');await onReload();}catch(err){onMessage(err instanceof Error?err.message:'Request failed');}};
  const deactivate=async(host:any)=>{if(!window.confirm(locale==='fa'?'دسترسی میزبانی این حساب غیرفعال شود؟':'Deactivate this host account?'))return;try{await api(`/staff/platform/hosts/${host.id}/deactivate`,{method:'POST'},token);onMessage(locale==='fa'?'دسترسی میزبان غیرفعال شد.':'Host access deactivated.');await onReload();}catch(err){onMessage(err instanceof Error?err.message:'Request failed');}};
  return <div className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">PLATFORM OWNERSHIP</span><h2>{locale==='fa'?'میزبان‌ها و اشتراک‌ها':'Hosts & subscriptions'}</h2><p>{locale==='fa'?'میزبان باید ابتدا حساب تلگرام Panel Flow داشته باشد.':'Hosts must already have a Panel Flow Telegram account.'}</p></div><span className="count-badge">{hosts.length}</span></div><form className="platform-form" onSubmit={addHost}><label>{locale==='fa'?'شناسه تلگرام میزبان':'Host Telegram ID'}<input required type="number" min="1" value={telegramId} onChange={e=>setTelegramId(e.target.value)} placeholder="123456789"/></label><label>{locale==='fa'?'طرح اشتراک':'Subscription plan'}<select value={plan} onChange={e=>setPlan(e.target.value)}><option value="starter">Starter</option><option value="growth">Growth</option><option value="pro">Pro</option><option value="custom">Custom</option></select></label><label>{locale==='fa'?'مدت (روز)':'Duration (days)'}<input required type="number" min="1" max="730" value={days} onChange={e=>setDays(e.target.value)}/></label><label>{locale==='fa'?'مبلغ ثبت‌شده':'Recorded amount'}<input type="number" min="0" value={price} onChange={e=>setPrice(e.target.value)}/></label><label>{locale==='fa'?'واحد پول':'Currency'}<select value={currency} onChange={e=>setCurrency(e.target.value)}><option value="TOMAN">{locale==='fa'?'تومان':'Toman'}</option><option value="IRR">{locale==='fa'?'ریال':'Rial'}</option></select></label><label className="platform-notes">{locale==='fa'?'یادداشت':'Notes'}<input value={notes} onChange={e=>setNotes(e.target.value)} maxLength={500} placeholder={locale==='fa'?'اختیاری':'Optional'}/></label><button className="button button-orange" disabled={busy}>{busy?<LoaderCircle className="spin" size={16}/>:<Plus size={16}/>} {locale==='fa'?'افزودن میزبان':'Add host'}</button></form>{error&&<ErrorState message={error}/>}<div className="platform-host-list">{loading?<Loading/>:hosts.length?hosts.map(host=><div className="platform-host-row" key={host.id}><div><strong>{host.name}</strong><small dir="ltr">{host.username ? `@${host.username} · ` : ''}{host.telegram_id}</small><span className={`subscription-status ${host.subscription.status}`}>{host.subscription.status} · {host.subscription.plan_code||'—'}{host.subscription.price_amount?` · ${Number(host.subscription.price_amount).toLocaleString()} ${host.subscription.currency||'IRR'}`:''}{host.subscription.ends_at?` · ${formatDate(host.subscription.ends_at,locale)}`:''}</span></div><div className="platform-host-actions"><select className="host-plan-select" aria-label="Subscription plan" value={host.subscription.plan_code||'starter'} onChange={e=>update(host,{plan_code:e.target.value})}><option value="starter">Starter</option><option value="growth">Growth</option><option value="pro">Pro</option><option value="custom">Custom</option><option value="legacy">Legacy</option></select><input className="host-price-input" aria-label="Recorded subscription amount" type="number" min="0" defaultValue={host.subscription.price_amount||0} onBlur={e=>{if(Number(e.target.value)!==Number(host.subscription.price_amount||0))update(host,{price_amount:Number(e.target.value)});}}/><select className="host-plan-select" aria-label="Subscription currency" defaultValue={host.subscription.currency||'TOMAN'} onChange={e=>update(host,{currency:e.target.value})}><option value="TOMAN">Toman</option><option value="IRR">Rial</option></select>{['suspended','expired','cancelled','inactive'].includes(host.subscription.status)?<button className="button button-small button-success" onClick={()=>update(host,{duration_days:30,status:'active',plan_code:host.subscription.plan_code||'starter',price_amount:Number(host.subscription.price_amount||0),currency:host.subscription.currency||'TOMAN'})}>{locale==='fa'?'فعال‌سازی':'Activate'}</button>:<><button className="button button-small button-outline" onClick={()=>update(host,{duration_days:30,status:'active'})}>{locale==='fa'?'تمدید ۳۰ روز':'Extend 30d'}</button><button className="button button-small button-danger" onClick={()=>update(host,{status:'suspended'})}>{locale==='fa'?'تعلیق':'Suspend'}</button></>}<button className="button button-small button-danger" onClick={()=>deactivate(host)}>{locale==='fa'?'حذف دسترسی':'Revoke'}</button></div></div>):<div className="empty-inline">{locale==='fa'?'هنوز میزبانی ثبت نشده است.':'No hosts have been added yet.'}</div>}</div><p className="form-footnote">{locale==='fa'?'پرداخت اشتراک فعلاً به‌صورت دستی ثبت و توسط مدیر فعال می‌شود؛ اتصال درگاه پرداخت در این نسخه انجام نشده است.':'Subscription payments are recorded and activated manually by the platform owner; no payment gateway is connected in this release.'}</p></div>;
}

function PlatformCitiesPanel({ cities, loading, locale, onReload, onMessage }: { cities:CityData[]; loading:boolean; locale:Locale; onReload:()=>void|Promise<void>; onMessage:(message:string)=>void }) {
  const { token }=useAuth();const [form,setForm]=useState({slug:'',name_fa:'',name_en:'',province_fa:'',province_en:'',latitude:'',longitude:'',description_fa:'',description_en:''});const [descriptions,setDescriptions]=useState<Record<number,{fa:string;en:string}>>({});const [busy,setBusy]=useState(false);const [error,setError]=useState('');
  useEffect(()=>{setDescriptions(Object.fromEntries(cities.map(c=>[c.id,{fa:c.description_fa||'',en:c.description_en||''}])));},[cities]);
  const change=(key:string,value:string)=>setForm(prev=>({...prev,[key]:value}));
  const submit=async(e:FormEvent)=>{e.preventDefault();setBusy(true);setError('');try{await api('/staff/platform/cities',{method:'POST',body:JSON.stringify({...form,latitude:Number(form.latitude),longitude:Number(form.longitude)})},token);setForm({slug:'',name_fa:'',name_en:'',province_fa:'',province_en:'',latitude:'',longitude:'',description_fa:'',description_en:''});onMessage(locale==='fa'?'شهر به نقشه اضافه شد.':'City added to the directory.');await onReload();}catch(err){setError(err instanceof Error?err.message:'Request failed');}finally{setBusy(false);}};
  const toggle=async(city:CityData)=>{try{await api(`/staff/platform/cities/${city.id}`,{method:'PATCH',body:JSON.stringify({is_active:!city.is_active})},token);await onReload();}catch(err){onMessage(err instanceof Error?err.message:'Request failed');}};
  const saveDescription=async(city:CityData)=>{const values=descriptions[city.id]||{fa:'',en:''};setBusy(true);try{await api(`/staff/platform/cities/${city.id}`,{method:'PATCH',body:JSON.stringify({description_fa:values.fa,description_en:values.en})},token);onMessage(locale==='fa'?'توضیحات شهر ذخیره شد.':'City descriptions saved.');await onReload();}catch(err){setError(err instanceof Error?err.message:'Request failed');}finally{setBusy(false);}};
  return <div className="surface-card workspace-panel platform-panel"><div className="surface-heading"><div><span className="eyebrow">NATIONAL DIRECTORY</span><h2>{locale==='fa'?'مدیریت شهرهای نقشه':'Manage map cities'}</h2><p>{locale==='fa'?'شهر جدید اضافه کنید، توضیحات را ویرایش کنید یا نمایش شهر را کنترل کنید.':'Add cities, edit descriptions, and control public map visibility.'}</p></div></div><form className="platform-form city-admin-form" onSubmit={submit}><label>Slug<input required pattern="[a-z0-9]+(-[a-z0-9]+)*" value={form.slug} onChange={e=>change('slug',e.target.value)} placeholder="kish"/></label><label>نام فارسی<input required value={form.name_fa} onChange={e=>change('name_fa',e.target.value)}/></label><label>English name<input required value={form.name_en} onChange={e=>change('name_en',e.target.value)}/></label><label>استان فارسی<input required value={form.province_fa} onChange={e=>change('province_fa',e.target.value)}/></label><label>Province<input required value={form.province_en} onChange={e=>change('province_en',e.target.value)}/></label><label>Latitude<input required type="number" step="0.000001" min="24" max="40" value={form.latitude} onChange={e=>change('latitude',e.target.value)}/></label><label>Longitude<input required type="number" step="0.000001" min="43" max="64" value={form.longitude} onChange={e=>change('longitude',e.target.value)}/></label><label>{locale==='fa'?'توضیحات فارسی':'Persian description'}<textarea value={form.description_fa} onChange={e=>change('description_fa',e.target.value)}/></label><label>{locale==='fa'?'توضیحات انگلیسی':'English description'}<textarea value={form.description_en} onChange={e=>change('description_en',e.target.value)}/></label><button className="button button-orange" disabled={busy}>{busy?<LoaderCircle className="spin" size={16}/>:<Plus size={16}/>} {locale==='fa'?'افزودن شهر':'Add city'}</button></form>{error&&<ErrorState message={error}/>}<div className="platform-city-list">{loading?<Loading/>:cities.map(city=><div className="platform-city-row city-admin-row" key={city.id}><span><strong>{city.name_fa} · {city.name_en}</strong><small>{city.province_fa} · {city.event_count} {locale==='fa'?'پنل':'panels'} {city.is_founding_city?' · FOUNDING CITY':''}</small><div className="city-description-editor"><textarea aria-label={`${city.name_fa} Persian description`} value={descriptions[city.id]?.fa||''} onChange={e=>setDescriptions(prev=>({...prev,[city.id]:{...(prev[city.id]||{fa:'',en:''}),fa:e.target.value}}))} placeholder={locale==='fa'?'توضیحات فارسی':'Persian description'}/><textarea aria-label={`${city.name_en} English description`} value={descriptions[city.id]?.en||''} onChange={e=>setDescriptions(prev=>({...prev,[city.id]:{...(prev[city.id]||{fa:'',en:''}),en:e.target.value}}))} placeholder="English description"/><button className="button button-small button-outline" disabled={busy} onClick={()=>void saveDescription(city)}>{locale==='fa'?'ذخیره توضیحات':'Save descriptions'}</button></div></span><button disabled={city.is_founding_city} title={city.is_founding_city?(locale==='fa'?'شهر بنیان‌گذار قابل غیرفعال‌سازی نیست':'The founding city cannot be disabled'):''} className={`button button-small ${city.is_active?'button-outline':'button-success'}`} onClick={()=>toggle(city)}>{city.is_active?(locale==='fa'?'غیرفعال‌کردن':'Disable'):(locale==='fa'?'فعال‌کردن':'Enable')}</button></div>)}</div></div>;
}

type HostApplicationFormState = {
  legal_name: string; national_id: string; date_of_birth: string; verified_mobile: string; email: string;
  residence_city_id: string; english_proficiency: string; english_certification: string;
  relevant_experience: string; hosting_background: string; motivation: string; portfolio_url: string;
  preferred_city_ids: number[]; preferred_topics: string[]; preferred_formats: string[]; availability: string;
  public_display_name: string; public_bio: string; public_languages: string[]; applicant_response: string;
};
const emptyHostApplication: HostApplicationFormState = {
  legal_name: '', national_id: '', date_of_birth: '', verified_mobile: '', email: '', residence_city_id: '',
  english_proficiency: '', english_certification: '', relevant_experience: '', hosting_background: '',
  motivation: '', portfolio_url: '', preferred_city_ids: [], preferred_topics: [], preferred_formats: [],
  availability: '', public_display_name: '', public_bio: '', public_languages: [], applicant_response: '',
};
function hostApplicationStatus(status?: string) {
  const labels: Record<string, string> = {
    draft: 'Draft', submitted: 'Submitted', under_review: 'Under review',
    more_information_required: 'More information required', approved: 'Approved', rejected: 'Rejected', withdrawn: 'Withdrawn',
  };
  return labels[status || 'draft'] || status || 'Not started';
}

function HostApplicationPage() {
  const { locale } = useLanguage(); const { token, user } = useAuth();
  const [form, setForm] = useState<HostApplicationFormState>(emptyHostApplication);
  const formRef = useRef(form); formRef.current = form;
  const [application, setApplication] = useState<any>(null); const [history, setHistory] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]); const [cities, setCities] = useState<CityData[]>([]);
  const [step, setStep] = useState(0); const [ready, setReady] = useState(false); const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false); const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(''); const [error, setError] = useState('');
  const editable = !application || ['draft', 'more_information_required'].includes(application.status);
  const t = locale === 'fa';

  const hydrate = (data: any) => {
    const a = data?.application;
    setApplication(a || null); setHistory(data?.history || []); setNotifications(data?.notifications || []);
    if (a) setForm({
      ...emptyHostApplication,
      legal_name: a.legal_name || '', date_of_birth: a.date_of_birth || '', verified_mobile: a.verified_mobile || '',
      email: a.email || '', residence_city_id: a.residence_city_id ? String(a.residence_city_id) : '',
      english_proficiency: a.english_proficiency || '', english_certification: a.english_certification || '',
      relevant_experience: a.relevant_experience || '', hosting_background: a.hosting_background || '',
      motivation: a.motivation || '', portfolio_url: a.portfolio_url || '', preferred_city_ids: a.preferred_city_ids || [],
      preferred_topics: a.preferred_topics || [], preferred_formats: a.preferred_formats || [], availability: a.availability || '',
      public_display_name: a.public_display_name || '', public_bio: a.public_bio || '', public_languages: a.public_languages || [],
      applicant_response: a.applicant_response || '',
    });
    setDirty(false); setReady(true);
  };
  const reload = useCallback(async () => {
    setReady(false); setError('');
    try {
      const [data, cityResult] = await Promise.all([
        api<any>('/me/host-application', {}, token), api<ApiPage<CityData>>('/cities', {}, token),
      ]);
      hydrate(data); setCities(cityResult.items || []);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load your application.'); setReady(true); }
  }, [token]);
  useEffect(() => { void reload(); }, [reload]);

  const saveDraft = async (quiet = false) => {
    setSaving(true); if (!quiet) setError('');
    try {
      const snapshot = { ...formRef.current };
      const identityValue = snapshot.national_id.trim();
      const payload: any = { ...snapshot, residence_city_id: snapshot.residence_city_id ? Number(snapshot.residence_city_id) : null,
        national_id: identityValue.length === 10 ? identityValue : undefined };
      delete payload.national_id_masked;
      const result = await api<any>('/me/host-application', { method: 'PATCH', body: JSON.stringify(payload) }, token);
      setApplication(result.application);
      if (identityValue.length === 10 && formRef.current.national_id === snapshot.national_id) {
        setForm(previous => ({...previous, national_id: ''})); setDirty(false);
      } else if (JSON.stringify(snapshot) === JSON.stringify(formRef.current)) setDirty(false);
      if (!quiet) setFeedback(t ? 'پیش‌نویس ذخیره شد.' : 'Draft saved.');
      return true;
    } catch (e) { setError(e instanceof Error ? e.message : 'Draft could not be saved.'); return false; }
    finally { setSaving(false); }
  };
  useEffect(() => {
    if (!ready || !dirty || !editable) return;
    const timer = window.setTimeout(() => { void saveDraft(true); }, 750);
    return () => window.clearTimeout(timer);
  }, [form, ready, dirty, editable, token]);

  const change = <K extends keyof HostApplicationFormState>(key: K, value: HostApplicationFormState[K]) => {
    setForm(previous => ({ ...previous, [key]: value })); setDirty(true);
  };
  const toggleArray = (key: 'preferred_city_ids' | 'preferred_topics' | 'preferred_formats' | 'public_languages', value: string | number) => {
    const current = form[key] as Array<string | number>;
    const next = current.includes(value as never) ? current.filter(x => x !== value) : [...current, value as never];
    change(key, next as never);
  };
  const submit = async () => {
    if (!(await saveDraft(true))) return;
    setSubmitting(true); setError(''); setFeedback('');
    try {
      await api('/me/host-application/submit', { method: 'POST' }, token);
      setFeedback(t ? 'درخواست شما برای بررسی ارسال شد.' : 'Your application has been submitted for review.');
      await reload(); setStep(0);
    } catch (e) { setError(e instanceof Error ? e.message : 'Application could not be submitted.'); }
    finally { setSubmitting(false); }
  };
  const withdraw = async () => {
    if (!window.confirm(t ? 'درخواست میزبانی لغو شود؟' : 'Withdraw this host application?')) return;
    try { await api('/me/host-application/withdraw', { method: 'POST' }, token); await reload(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not withdraw application.'); }
  };
  const reapply = async () => {
    try { await api('/me/host-application/reapply', { method: 'POST' }, token); await reload(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not start a new application.'); }
  };
  const markRead = async (id: number) => {
    try { await api(`/me/host-application/notifications/${id}/read`, { method: 'POST' }, token); setNotifications(v => v.map(x => x.id === id ? { ...x, read_at: new Date().toISOString() } : x)); }
    catch { /* Notification remains visible; retry on next visit. */ }
  };
  if (!ready) return <div className="page-shell"><Loading /></div>;
  if (application?.status === 'approved') return <div className="page-shell account-shell"><AccountHeading title={t ? 'میزبان تأییدشده' : 'Host approved'} subtitle={t ? 'فضای کاری میزبان شما فعال شده است.' : 'Your Host Workspace has been activated.'} /><div className="host-application-status success"><ShieldCheck size={26}/><div><strong>{hostApplicationStatus(application.status)}</strong><span>{t ? 'اکانت عضو شما حفظ شده و دسترسی میزبان به آن اضافه شده است.' : 'Your member account remains intact, with host access added to it.'}</span></div><Link to="/workspace" className="button button-orange">{t ? 'ورود به فضای کاری' : 'Open Host Workspace'}<ArrowUpRight size={17}/></Link></div><div className="surface-card host-app-submission-summary"><h2>{t?'اطلاعات ثبت‌شده':'Submitted details'}</h2><p><strong>{application.legal_name}</strong> · {application.email} · {application.verified_mobile}</p><p>{application.public_bio}</p></div>{notifications.map(n=><div className="notice notice-success host-app-notification" key={n.id}><span><strong>{n.title}</strong>{n.message}</span>{!n.read_at&&<button onClick={()=>void markRead(n.id)}>{t?'خواندم':'Mark read'}</button>}</div>)}{history.length>0&&<section className="surface-card host-app-history"><h2>{t?'تاریخچه درخواست':'Application history'}</h2><div className="host-app-timeline">{history.map(row=><article key={row.id}><span className="timeline-dot"/><div><strong>{hostApplicationStatus(row.to_status)||row.action.replaceAll('_',' ')}</strong><p>{row.note||row.action.replaceAll('_',' ')}</p><small>{formatDate(row.created_at,locale)}</small></div></article>)}</div></section>}</div>;
  if (application?.status === 'rejected' || application?.status === 'withdrawn') return <div className="page-shell account-shell"><AccountHeading title={t ? 'درخواست میزبانی' : 'Host application'} subtitle={t ? 'وضعیت نهایی درخواست قبلی' : 'Final status of your previous application'} /><div className="host-application-status"><ShieldCheck size={24}/><div><strong>{hostApplicationStatus(application.status)}</strong><span>{application.rejection_reason || (t ? 'این درخواست بسته شده است.' : 'This application is closed.')}</span></div></div><div className="surface-card host-app-submission-summary"><h2>{t?'اطلاعات ثبت‌شده':'Submitted details'}</h2><p><strong>{application.legal_name}</strong> · {application.email} · {application.verified_mobile}</p><p>{application.public_bio}</p></div>{notifications.map(n=><div className="notice notice-success host-app-notification" key={n.id}><span><strong>{n.title}</strong>{n.message}</span>{!n.read_at&&<button onClick={()=>void markRead(n.id)}>{t?'خواندم':'Mark read'}</button>}</div>)}{history.length>0&&<section className="surface-card host-app-history"><h2>{t?'تاریخچه درخواست':'Application history'}</h2><div className="host-app-timeline">{history.map(row=><article key={row.id}><span className="timeline-dot"/><div><strong>{hostApplicationStatus(row.to_status)||row.action.replaceAll('_',' ')}</strong><p>{row.note||row.action.replaceAll('_',' ')}</p><small>{formatDate(row.created_at,locale)}</small></div></article>)}</div></section>}<button className="button button-orange" onClick={reapply}>{t?'ثبت درخواست جدید':'Start a new application'}<ArrowRight size={17}/></button></div>;

  const steps = t ? ['اطلاعات شخصی', 'زبان و تجربه', 'ترجیحات میزبانی', 'پروفایل عمومی'] : ['Personal details', 'English & experience', 'Hosting preferences', 'Public profile'];
  return <div className="page-shell account-shell host-application-shell">
    <AccountHeading title={t ? 'به شبکه میزبان‌ها بپیوندید' : 'Become a Panel Flow Host'} subtitle={t ? 'یک درخواست برای همین حساب کاربری ارسال کنید؛ حساب جداگانه‌ای ساخته نمی‌شود.' : 'Apply using your existing Panel Flow account. No second account is created.'} />
    {application && <div className={`host-application-status ${application.status === 'more_information_required' ? 'warning' : ''}`}><ShieldCheck size={22}/><div><strong>{hostApplicationStatus(application.status)}</strong><span>{application.status === 'more_information_required' ? (application.requested_information || '') : (application.submitted_at ? `${t?'ارسال شده':'Submitted'} · ${formatDate(application.submitted_at, locale)}` : (t?'پیش‌نویس شما به‌صورت خودکار ذخیره می‌شود.':'Your draft is saved automatically.'))}</span></div></div>}
    {notifications.map(n=><div className="notice notice-success host-app-notification" key={n.id}><span><strong>{n.title}</strong>{n.message}</span>{!n.read_at&&<button onClick={()=>void markRead(n.id)}>{t?'خواندم':'Mark read'}</button>}</div>)}
    {error && <ErrorState message={error} />}{feedback && <div className="notice notice-success"><CheckCircle2 size={17}/>{feedback}</div>}
    {editable ? <section className="surface-card host-application-card">
      <div className="host-app-stepper">{steps.map((name, index)=><button key={name} className={step===index?'active':step>index?'complete':''} onClick={()=>setStep(index)}><span>{index+1}</span>{name}</button>)}</div>
      {step===0 && <div className="host-app-form-grid">
        <label>{t?'نام و نام خانوادگی قانونی':'Legal full name'}<input value={form.legal_name} onChange={e=>change('legal_name',e.target.value)} maxLength={255} required/></label>
        <label>{t?'کد ملی':'National identity number'}<input type="password" autoComplete="off" inputMode="numeric" value={form.national_id} onChange={e=>change('national_id',e.target.value)} placeholder={application?.national_id_masked || (t?'فقط برای ذخیره رمزنگاری‌شده':'Encrypted at rest')}/><small>{t?'این مقدار رمزنگاری می‌شود و در صفحه‌ها فقط به‌صورت پوشیده نمایش داده می‌شود.':'Encrypted before storage; masked in all application views.'}</small></label>
        <label>{t?'تاریخ تولد':'Date of birth'}<input type="date" value={form.date_of_birth} onChange={e=>change('date_of_birth',e.target.value)}/></label>
        <label>{t?'شماره تماس':'Mobile number'}<input value={form.verified_mobile} onChange={e=>change('verified_mobile',e.target.value)} maxLength={50}/></label>
        <label>{t?'ایمیل':'Email'}<input type="email" value={form.email} onChange={e=>change('email',e.target.value)} maxLength={255}/></label>
        <label>{t?'شهر محل سکونت':'Residence city'}<select value={form.residence_city_id} onChange={e=>change('residence_city_id',e.target.value)}><option value="">{t?'انتخاب شهر':'Select a city'}</option>{cities.map(c=><option value={c.id} key={c.id}>{locale==='fa'?c.name_fa:c.name_en}</option>)}</select></label>
      </div>}
      {step===1 && <div className="host-app-form-grid">
        <label>{t?'سطح زبان انگلیسی':'English proficiency'}<select value={form.english_proficiency} onChange={e=>change('english_proficiency',e.target.value)}><option value="">{t?'انتخاب سطح':'Select level'}</option>{['A2','B1','B2','C1','C2','Native / bilingual'].map(x=><option key={x}>{x}</option>)}</select></label>
        <label>{t?'مدرک یا گواهی زبان':'English certificate'}<input value={form.english_certification} onChange={e=>change('english_certification',e.target.value)} placeholder="IELTS, TOEFL, degree…"/></label>
        <label className="wide">{t?'تجربه مرتبط':'Relevant experience'}<textarea rows={3} value={form.relevant_experience} onChange={e=>change('relevant_experience',e.target.value)} maxLength={5000}/></label>
        <label className="wide">{t?'سوابق میزبانی و مدیریت گفتگو':'Hosting and facilitation background'}<textarea rows={4} value={form.hosting_background} onChange={e=>change('hosting_background',e.target.value)} maxLength={5000}/></label>
        <label className="wide">{t?'انگیزه شما برای میزبانی':'Why do you want to host?'}<textarea rows={4} value={form.motivation} onChange={e=>change('motivation',e.target.value)} maxLength={5000}/></label>
        <label className="wide">{t?'نمونه‌کار یا وب‌سایت':'Portfolio or website'}<input type="url" value={form.portfolio_url} onChange={e=>change('portfolio_url',e.target.value)} placeholder="https://…"/></label>
      </div>}
      {step===2 && <div className="host-app-preferences">
        <div><strong>{t?'شهرهای موردنظر برای میزبانی':'Preferred hosting cities'}</strong><div className="host-app-choice-grid">{cities.map(city=><label key={city.id} className="checkbox-line"><input type="checkbox" checked={form.preferred_city_ids.includes(city.id)} onChange={()=>toggleArray('preferred_city_ids',city.id)}/>{locale==='fa'?city.name_fa:city.name_en}</label>)}</div></div>
        <label>{t?'موضوع‌های موردعلاقه':'Preferred discussion topics'}<textarea rows={3} value={form.preferred_topics.join(', ')} onChange={e=>change('preferred_topics',e.target.value.split(',').map(x=>x.trim()).filter(Boolean))} placeholder={t?'هنر، فناوری، جامعه، فرهنگ…':'Art, technology, society, culture…'}/></label>
        <div><strong>{t?'قالب برگزاری':'Hosting formats'}</strong><div className="host-app-choice-grid">{[['in_person',t?'حضوری':'In person'],['online','Online'],['hybrid',t?'ترکیبی':'Hybrid']].map(([value,label])=><label className="checkbox-line" key={value}><input type="checkbox" checked={form.preferred_formats.includes(value)} onChange={()=>toggleArray('preferred_formats',value)}/>{label}</label>)}</div></div>
        <label>{t?'زمان‌های در دسترس':'Availability'}<textarea rows={3} value={form.availability} onChange={e=>change('availability',e.target.value)} placeholder={t?'روزها، ساعت‌ها و محدودیت‌ها…':'Days, times, and scheduling constraints…'}/></label>
      </div>}
      {step===3 && <div className="host-app-form-grid">
        <label>{t?'نام نمایشی عمومی':'Public display name'}<input value={form.public_display_name} onChange={e=>change('public_display_name',e.target.value)} maxLength={255}/></label>
        <label>{t?'زبان‌هایی که می‌توانید با آن‌ها میزبانی کنید':'Languages you can host in'}<input value={form.public_languages.join(', ')} onChange={e=>change('public_languages',e.target.value.split(',').map(x=>x.trim()).filter(Boolean))} placeholder="English, فارسی…"/></label>
        <label className="wide">{t?'معرفی عمومی میزبان':'Public host biography'}<textarea rows={5} value={form.public_bio} onChange={e=>change('public_bio',e.target.value)} maxLength={3000}/></label>
        {application?.status==='more_information_required' && <label className="wide">{t?'پاسخ به درخواست اطلاعات تکمیلی':'Response to the information request'}<textarea rows={4} value={form.applicant_response} onChange={e=>change('applicant_response',e.target.value)} maxLength={3000}/></label>}
        <div className="host-app-review-summary wide"><strong>{t?'پیش از ارسال بررسی کنید':'Before submitting'}</strong><p>{t?'اطمینان حاصل کنید که اطلاعات هویتی، شهرها، قالب برگزاری و معرفی عمومی کامل هستند. تصمیم نهایی فقط توسط مدیر ارشد گرفته می‌شود.':'Make sure identity, city preferences, formats, and public profile details are complete. Approval is always a manual superadmin decision.'}</p></div>
      </div>}
      <div className="host-app-form-footer"><span className="form-footnote">{saving ? (t?'در حال ذخیره…':'Saving…') : dirty ? (t?'تغییرات ذخیره‌نشده':'Unsaved changes') : (t?'ذخیره خودکار فعال است':'Autosave is on')}</span><div><button className="button button-outline" disabled={step===0} onClick={()=>setStep(v=>v-1)}>{t?'قبلی':'Back'}</button>{step<3 ? <button className="button button-primary" onClick={()=>{void saveDraft(true);setStep(v=>Math.min(3,v+1));}}>{t?'مرحله بعد':'Continue'}<ArrowRight size={16}/></button> : <button className="button button-orange" disabled={saving||submitting} onClick={()=>void submit()}>{submitting?<LoaderCircle className="spin" size={16}/>:<Check size={16}/>} {application?.status==='more_information_required'?(t?'ارسال پاسخ و بررسی مجدد':'Resubmit for review'):(t?'ارسال درخواست':'Submit application')}</button>}</div></div>
    </section> : <div className="surface-card host-app-submission-summary"><div className="surface-heading"><div><span className="eyebrow">APPLICATION SUBMISSION</span><h2>{t?'جزئیات ثبت‌شده':'Submitted details'}</h2></div><button className="button button-outline" onClick={()=>void reload()}>{t?'به‌روزرسانی وضعیت':'Refresh status'}</button></div><div className="host-app-detail-grid">{[[t?'نام قانونی':'Legal name',application?.legal_name],[t?'کد ملی':'National ID',application?.national_id_masked],[t?'تاریخ تولد':'Date of birth',application?.date_of_birth],[t?'موبایل':'Mobile',application?.verified_mobile],[t?'ایمیل':'Email',application?.email],[t?'شهر محل سکونت':'Residence city',cities.find(c=>c.id===application?.residence_city_id)?.name_en],[t?'سطح زبان':'English proficiency',application?.english_proficiency],[t?'مدرک زبان':'Certificate',application?.english_certification],[t?'شهرهای ترجیحی':'Preferred cities',(application?.preferred_city_ids||[]).map((id:number)=>cities.find(c=>c.id===id)?.name_en||id).join(', ')],[t?'قالب‌ها':'Formats',(application?.preferred_formats||[]).join(', ')],[t?'موضوع‌ها':'Topics',(application?.preferred_topics||[]).join(', ')],[t?'وب‌سایت نمونه‌کار':'Portfolio',application?.portfolio_url]].map(([k,v])=><div key={String(k)}><small>{k}</small><strong>{v||'—'}</strong></div>)}</div><div className="host-app-detail-section"><strong>{t?'سوابق میزبانی':'Hosting background'}</strong><p>{application?.hosting_background||'—'}</p></div><div className="host-app-detail-section"><strong>{t?'انگیزه':'Motivation'}</strong><p>{application?.motivation||'—'}</p></div><div className="host-app-detail-section"><strong>{t?'معرفی عمومی':'Public profile'}</strong><p>{application?.public_display_name}<br/>{application?.public_bio}</p></div></div>}
    {application && <section className="surface-card host-app-history"><div className="surface-heading"><div><span className="eyebrow">APPLICATION RECORD</span><h2>{t?'تاریخچه درخواست':'Application history'}</h2></div><Clock3 size={18}/></div>{history.length ? <div className="host-app-timeline">{history.map(row=><article key={row.id}><span className="timeline-dot"/><div><strong>{hostApplicationStatus(row.to_status) || row.action.replaceAll('_',' ')}</strong><p>{row.note || row.action.replaceAll('_',' ')}</p><small>{formatDate(row.created_at,locale)}</small></div></article>)}</div> : <p className="muted-copy">—</p>}{['draft','submitted','under_review','more_information_required'].includes(application.status) && <button className="button button-danger button-small" onClick={()=>void withdraw()}>{t?'انصراف از درخواست':'Withdraw application'}</button>}</section>}
  </div>;
}

function HostApplicationsAdmin() {
  const { locale } = useLanguage(); const { token } = useAuth(); const fa = locale === 'fa';
  const [status, setStatus] = useState('all'); const [query, setQuery] = useState(''); const [cityId, setCityId] = useState('');
  const [submittedFrom, setSubmittedFrom] = useState(''); const [submittedTo, setSubmittedTo] = useState('');
  const [rows, setRows] = useState<any[]>([]); const [selected, setSelected] = useState<any>(null); const [detail, setDetail] = useState<any>(null);
  const [cities, setCities] = useState<CityData[]>([]); const [loading, setLoading] = useState(true); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams({status, q: query, limit: '100'}); if (cityId) params.set('city_id', cityId);
      if (submittedFrom) params.set('submitted_from', submittedFrom);
      if (submittedTo) params.set('submitted_to', submittedTo);
      const [result, cityResult] = await Promise.all([api<ApiPage<any>>(`/staff/platform/host-applications?${params}`, {}, token), api<ApiPage<CityData>>('/cities', {}, token)]);
      setRows(result.items || []); setCities(cityResult.items || []);
    } catch(e) { setError(e instanceof Error?e.message:'Request failed'); }
    finally { setLoading(false); }
  }, [status, query, cityId, submittedFrom, submittedTo, token]);
  const openDetail = async (row:any) => { setSelected(row); setDetail(null); try { setDetail(await api<any>(`/staff/platform/host-applications/${row.id}`,{},token)); } catch(e) { setError(e instanceof Error?e.message:'Could not load application'); } };
  useEffect(()=>{void load();},[status, cityId, submittedFrom, submittedTo, token]);
  const act = async(action:string) => {
    if (!selected) return;
    let note = '';
    if (['request_information','reject','add_note','suspend_host','revoke_host'].includes(action)) {
      note = window.prompt(action==='request_information'?(fa?'چه اطلاعاتی لازم است؟':'What information is required?'):action==='reject'?(fa?'دلیل رد درخواست':'Rejection reason'):(fa?'یادداشت':'Internal note'))?.trim() || '';
      if (!note) return;
    }
    const body:any={action}; if(note) body.note=note;
    if(action==='approve' && !window.confirm(fa?'درخواست تأیید و دسترسی میزبان فعال شود؟':'Approve the application and activate host access?')) return;
    if(action==='schedule_interview') { const when=window.prompt(fa?'زمان مصاحبه (YYYY-MM-DDTHH:mm)':'Interview date/time (YYYY-MM-DDTHH:mm)','2026-11-15T18:00'); if(!when)return; body.interview_at=when; body.interview_location=window.prompt(fa?'محل یا لینک مصاحبه':'Interview location or link')||''; body.interview_notes=window.prompt(fa?'یادداشت مصاحبه':'Interview notes')||''; }
    setBusy(true); setError('');
    try { await api(`/staff/platform/host-applications/${selected.id}/review`,{method:'POST',body:JSON.stringify(body)},token); await load(); await openDetail(selected); }
    catch(e) { setError(e instanceof Error?e.message:'Action failed'); }
    finally { setBusy(false); }
  };
  return <div className="page-shell workspace-shell host-app-admin-shell"><div className="workspace-header"><div><div className="eyebrow">SUPERADMIN COMMAND CENTER</div><h1>{fa?'درخواست‌های میزبانی':'Host applications'}<span className="heading-period">.</span></h1><p>{fa?'بررسی درخواست‌ها، سوابق تصمیم و تخصیص دسترسی میزبان.':'Review applications, record decisions, and provision Host Workspaces.'}</p></div><button className="button button-outline" onClick={()=>void load()}><LoaderCircle size={16}/>{fa?'به‌روزرسانی':'Refresh'}</button></div>
    {error && <ErrorState message={error}/>}<div className="surface-card host-app-admin-filters"><label>{fa?'جست‌وجو':'Search'}<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Name, email, Telegram…" onKeyDown={e=>e.key==='Enter'&&void load()}/></label><label>{fa?'وضعیت':'Status'}<select value={status} onChange={e=>setStatus(e.target.value)}>{['all','submitted','under_review','more_information_required','approved','rejected','draft','withdrawn'].map(x=><option key={x} value={x}>{x==='all'?'All':hostApplicationStatus(x)}</option>)}</select></label><label>{fa?'شهر':'City'}<select value={cityId} onChange={e=>setCityId(e.target.value)}><option value="">{fa?'همه شهرها':'All cities'}</option>{cities.map(c=><option key={c.id} value={c.id}>{locale==='fa'?c.name_fa:c.name_en}</option>)}</select></label><label>{fa?'از تاریخ ارسال':'Submitted from'}<input type="date" value={submittedFrom} onChange={e=>setSubmittedFrom(e.target.value)}/></label><label>{fa?'تا تاریخ ارسال':'Submitted to'}<input type="date" value={submittedTo} onChange={e=>setSubmittedTo(e.target.value)}/></label><button className="button button-primary" onClick={()=>void load()}>{fa?'اعمال فیلتر':'Apply filters'}</button></div>
    <div className="host-app-admin-layout"><section className="surface-card host-app-admin-list"><div className="surface-heading"><div><span className="eyebrow">APPLICATION QUEUE</span><h2>{fa?'صف درخواست‌ها':'Review queue'}</h2></div><span>{rows.length}</span></div>{loading?<Loading/>:rows.length?rows.map(row=><button className={`host-app-admin-row ${selected?.id===row.id?'active':''}`} key={row.id} onClick={()=>void openDetail(row)}><span><strong>{row.legal_name || row.member_name}</strong><small>{row.email || '—'} · {row.national_id_masked || 'Identity not provided'}</small><small>{formatDate(row.submitted_at,locale)} · {row.status}</small></span><ArrowUpRight size={16}/></button>):<p className="muted-copy">{fa?'درخواستی با این فیلترها پیدا نشد.':'No applications match these filters.'}</p>}</section>
      <section className="surface-card host-app-admin-detail">{!selected?<div className="empty-inline">{fa?'برای مشاهده جزئیات، یک درخواست را انتخاب کنید.':'Select an application to review its details.'}</div>:!detail?<Loading/>:<><div className="surface-heading"><div><span className="eyebrow">APPLICATION #{detail.application.id}</span><h2>{detail.application.legal_name}</h2><p>{detail.member?.display_name} · {detail.member?.telegram_username?`@${detail.member.telegram_username}`:`User #${detail.member?.id}`}</p></div><span className="status-pill">{hostApplicationStatus(detail.application.status)}</span></div>
        <div className="host-app-detail-grid">{[['Email',detail.application.email],['Mobile',detail.application.verified_mobile],['National ID',detail.application.national_id_masked],['Date of birth',detail.application.date_of_birth],['Residence city',detail.residence_city],['English',detail.application.english_proficiency],['Certificate',detail.application.english_certification],['Portfolio',detail.application.portfolio_url]].map(([k,v])=><div key={k}><small>{k}</small><strong>{v||'—'}</strong></div>)}</div>
        {[['Relevant experience',detail.application.relevant_experience],['Hosting background',detail.application.hosting_background],['Motivation',detail.application.motivation],['Preferred topics',(detail.application.preferred_topics||[]).join(', ')],['Preferred cities',(detail.application.preferred_city_ids||[]).map((id:number)=>cities.find(c=>c.id===id)?.name_en||id).join(', ')],['Formats',(detail.application.preferred_formats||[]).join(', ')],['Availability',detail.application.availability],['Public profile',`${detail.application.public_display_name||''}\n${detail.application.public_bio||''}`],['Applicant response',detail.application.applicant_response],['Requested information',detail.application.requested_information],['Private internal notes',detail.application.internal_notes]].map(([k,v])=><div className="host-app-detail-section" key={k}><strong>{k}</strong><p>{v||'—'}</p></div>)}
        <div className="host-app-admin-actions">{['submitted','more_information_required'].includes(detail.application.status)&&<button disabled={busy} className="button button-outline" onClick={()=>void act('start_review')}>Start review</button>}{['submitted','under_review','more_information_required'].includes(detail.application.status)&&<><button disabled={busy} className="button button-outline" onClick={()=>void act('request_information')}>Request information</button><button disabled={busy} className="button button-success" onClick={()=>void act('approve')}>Approve & provision workspace</button><button disabled={busy} className="button button-danger" onClick={()=>void act('reject')}>Reject</button></>}{detail.application.status==='approved'&&<><button disabled={busy} className="button button-outline" onClick={()=>void act('schedule_interview')}>Schedule interview</button><button disabled={busy} className="button button-danger" onClick={()=>void act('suspend_host')}>Suspend host access</button><button disabled={busy} className="button button-danger" onClick={()=>void act('revoke_host')}>Revoke host access</button></>}<button disabled={busy} className="button button-outline" onClick={()=>void act('add_note')}>Add private note</button></div>
        <div className="host-app-history"><h3>Decision & action history</h3>{(detail.history||[]).map((item:any)=><div className="admin-history-row" key={item.id}><strong>{item.action.replaceAll('_',' ')}</strong><small>{item.from_status||'—'} → {item.to_status||'—'} · {formatDate(item.created_at,locale)}</small>{item.note&&<p>{item.note}</p>}</div>)}</div>
      </>}</section></div></div>;
}

function PublicHostProfilePage() {
  const { slug = '' } = useParams(); const { locale } = useLanguage();
  const { data, loading, error, reload } = useRequest<any>(`/hosts/${slug}`);
  if(loading)return <div className="page-shell"><Loading/></div>;
  if(error||!data)return <div className="page-shell"><ErrorState message={error||'Host profile not found'} retry={reload}/></div>;
  return <div className="page-shell account-shell public-host-profile"><AccountHeading title={data.display_name} subtitle={locale==='fa'?'میزبان تأییدشده پنل فلو':'Verified Panel Flow host profile'}/><div className="surface-card"><p>{data.bio}</p>{(data.languages||[]).length>0&&<p><strong>{locale==='fa'?'زبان‌ها':'Languages'}:</strong> {data.languages.join(', ')}</p>}{(data.topics||[]).length>0&&<p><strong>{locale==='fa'?'موضوع‌ها':'Topics'}:</strong> {data.topics.join(', ')}</p>}<Link to="/events" className="button button-outline">{locale==='fa'?'کاوش پنل‌ها':'Explore panels'}<ArrowUpRight size={16}/></Link></div></div>;
}


function NotFound() { const { t } = useLanguage(); return <div className="center-state"><span className="not-found-code">404</span><h2>{t.pageNotFound}</h2><Link to="/" className="button button-primary">{t.back}<ArrowUpRight size={16} /></Link></div>; }

export default App;
