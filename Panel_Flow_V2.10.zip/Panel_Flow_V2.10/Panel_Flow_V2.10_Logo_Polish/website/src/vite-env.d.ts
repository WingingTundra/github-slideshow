/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE?: string;
  readonly VITE_TELEGRAM_BOT_USERNAME?: string;
  readonly VITE_PUBLIC_SITE_URL?: string;
}
interface ImportMeta { readonly env: ImportMetaEnv; }

interface Window {
  Telegram?: { WebApp?: { initData?: string; ready?: () => void; expand?: () => void; colorScheme?: string } };
}
