import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api, TOKEN_KEY } from './api';

type User = {
  id: number; display_name?: string | null; first_name?: string | null; last_name?: string | null;
  telegram_username?: string | null; phone_number?: string | null; role: string;
};
type AuthValue = {
  token: string | null; user: User | null; loading: boolean; loginPending: boolean;
  botLoginUrl: string | null; login: () => Promise<void>; logout: () => void; refreshUser: () => Promise<void>;
};
const AuthContext = createContext<AuthValue | null>(null);

function readSessionToken(): string | null {
  try { return sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
}

function writeSessionToken(token: string) {
  try { sessionStorage.setItem(TOKEN_KEY, token); } catch { /* Authentication remains usable for this tab if storage is blocked. */ }
}

function clearSessionToken() {
  try { sessionStorage.removeItem(TOKEN_KEY); } catch { /* Ignore unavailable browser storage. */ }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(readSessionToken);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [loginPending, setLoginPending] = useState(false);
  const [botLoginUrl, setBotLoginUrl] = useState<string | null>(null);

  const logout = useCallback(() => {
    clearSessionToken();
    setToken(null); setUser(null); setLoginPending(false); setBotLoginUrl(null);
  }, []);

  const refreshUser = useCallback(async () => {
    if (!token) { setUser(null); return; }
    try {
      const profile = await api<User>('/me', {}, token);
      setUser(profile);
    } catch {
      logout();
    }
  }, [token, logout]);

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!token) { if (alive) setLoading(false); return; }
      try {
        const profile = await api<User>('/me', {}, token);
        if (alive) setUser(profile);
      } catch {
        if (alive) logout();
      } finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, [token, logout]);

  const login = useCallback(async () => {
    setLoading(true);
    // Reserve the tab synchronously during the click gesture so browser popup
    // blockers do not swallow the later Telegram deep-link navigation.
    const loginWindow = window.Telegram?.WebApp?.initData ? null : window.open('about:blank', '_blank');
    try {
      const initData = window.Telegram?.WebApp?.initData;
      if (initData) {
        window.Telegram?.WebApp?.ready?.();
        window.Telegram?.WebApp?.expand?.();
        const result = await api<{ access_token: string; user: User }>('/auth/telegram', {
          method: 'POST', body: JSON.stringify({ init_data: initData }),
        });
        writeSessionToken(result.access_token);
        setToken(result.access_token); setUser(result.user); setLoading(false); return;
      }

      const challenge = await api<{ token: string; expires_in: number }>('/auth/telegram/link', { method: 'POST' });
      const username = (import.meta.env.VITE_TELEGRAM_BOT_USERNAME || '').replace(/^@/, '').trim();
      if (!username) {
        setBotLoginUrl(null);
        loginWindow?.close();
        throw new Error('Bot username is not configured. Set VITE_TELEGRAM_BOT_USERNAME and rebuild the website.');
      }
      const url = `https://t.me/${username}?start=web_${encodeURIComponent(challenge.token)}`;
      setBotLoginUrl(url); setLoginPending(true);
      if (loginWindow) loginWindow.location.href = url;
      const started = Date.now();
      while (Date.now() - started < challenge.expires_in * 1000) {
        await new Promise(resolve => window.setTimeout(resolve, 1800));
        const result = await api<{ status: string; access_token?: string; user?: User }>(
          '/auth/telegram/link/poll',
          { method: 'POST', body: JSON.stringify({ token: challenge.token }) },
        );
        if (result.status === 'authenticated' && result.access_token && result.user) {
          writeSessionToken(result.access_token);
          setToken(result.access_token); setUser(result.user); setLoginPending(false); setLoading(false); return;
        }
      }
      throw new Error('Login link expired. Please try again.');
    } catch (error) {
      loginWindow?.close();
      setLoginPending(false);
      throw error;
    } finally { setLoading(false); }
  }, []);

  const value = useMemo(() => ({ token, user, loading, loginPending, botLoginUrl, login, logout, refreshUser }),
    [token, user, loading, loginPending, botLoginUrl, login, logout, refreshUser]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used within AuthProvider');
  return value;
}
