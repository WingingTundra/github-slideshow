# Panel Flow V2.08 Deployment Notes

## Before deployment
1. Take a verified PostgreSQL backup and a separate backup of the persistent uploads volume.
2. Preserve the existing `.env`, bot/API secrets, PostgreSQL volume, and uploads volume. Do not run `docker compose down -v`.
3. Review the configured public URL, Telegram bot credentials, storage limits, and upload volume space. `APP_TIMEZONE` is intentionally fixed to `Asia/Tehran`; the application rejects a different value.

## Apply and start
1. Deploy the V2.08 source/image while keeping the existing Compose services and volumes.
2. Apply the additive migration as a one-off job:

   ```sh
   docker compose run --rm api python -m app.db.migrate_cli --apply
   ```

   The API and bot containers both receive `APP_TIMEZONE=Asia/Tehran` and `TZ=Asia/Tehran` from Compose. Do not override either with another timezone.
3. Verify migration checksums and that no migrations are pending:

   ```sh
   docker compose run --rm api python -m app.db.migrate_cli --check
   ```
4. Rebuild and start the normal services:

   ```sh
   docker compose up -d --build
   ```
5. Verify the API readiness endpoint returns `{"status":"ready","database":"ok","timezone":"Asia/Tehran"}`:

   ```sh
   curl -fsS http://127.0.0.1:8000/health/ready
   ```
6. Review the operational counters:

   ```sh
   curl -fsS http://127.0.0.1:8000/health/operational
   ```

   Investigate a sustained increase in failed outbox/delivery counts. These endpoints expose only service health and low-cardinality counts, not user identifiers.

## Important rollout behavior
- **Timezone:** all website calendar/date rendering and date-boundary logic use `Asia/Tehran`. Database operational timestamps stay naive UTC for compatibility. Host-entered event date/time labels are still presentation-only and do not trigger automatic closure.
- **Existing QR credentials:** migration 055 gives already-stored QR/manual hashes a one-time 12-hour expiry grace. Rotate any credential that must remain usable after rollout. New tokens/codes expire after 12 hours, and rotating immediately invalidates the previous session.
- **Reviews:** completed events already in the database when migration 055 runs are grandfathered (`feedback_attendance_required=false`) to preserve legitimate historical reviews. Newly completed events are attendance-gated.
- **Images:** new public image uploads consume storage for both full and thumbnail WebP variants. Old images remain accessible; missing thumbnail variants fall back to full-size media.
- **Pagination:** old offset clients continue to work. Newest-first clients may use `next_cursor` with `sort=newest` and `offset=0`.
- **Notifications:** pending outbox rows are retried by the existing periodic worker. The per-recipient delivery ledger remains the authority for sent/failed recipient state.

## Rollback
Migration 055 is additive. If the application image must be rolled back, deploy the previous image only after confirming it safely ignores the added nullable columns/new table/indexes. Do not delete the outbox table or new columns if pending notification jobs or newly generated attendance proofs exist. A rollback does not reverse already-delivered notifications or revoke newly issued QR images; disable attendance or rotate credentials through the application if required.

## Staging acceptance
- Apply migration 055 against a PostgreSQL snapshot, verify `--check`, and confirm old migration checksums remain unchanged.
- Publish/edit a panel through both Telegram-admin and website-host flows; verify outbox rows commit atomically with each event change and retries do not duplicate recipient messages.
- Verify a generated QR/manual code works for the owning confirmed account, fails for another account, fails after expiry/rotation, and still allows each attendee to select only their own participant row.
- Verify a new review is hidden/rejected until the booker-attendee is marked attended; confirm pre-migration completed events retain review access.
- Test postpone → resume with an active waitlist: no messages while postponed, entries are preserved, and normal FIFO invitations resume after explicit reopening.
- Run the frontend production build with the resolved dependencies and test the calendar in browsers configured to timezones other than Tehran.
