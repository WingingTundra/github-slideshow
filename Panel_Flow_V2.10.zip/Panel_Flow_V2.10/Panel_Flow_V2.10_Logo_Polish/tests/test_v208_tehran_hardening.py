from datetime import datetime, timedelta, timezone
from io import BytesIO
from types import SimpleNamespace

import pytest
from PIL import Image

from app.db.models import EventStatus
from app.services.event_lifecycle import (
    archive_completed_event, postpone_event, resume_postponed_event, transition_event,
)
from app.time_utils import (
    PLATFORM_TIMEZONE_NAME, as_utc_aware, tehran_local_to_utc_naive, tehran_now,
)


def _event(**overrides):
    values = dict(
        status=EventStatus.PUBLISHED, archived=False, archived_at=None,
        registration_open=True, registration_closed_reason=None,
        waitlist_enabled=True, is_postponed=False, postponement_note=None,
    )
    values.update(overrides)
    return SimpleNamespace(**values)


def test_platform_timezone_is_tehran_and_local_wall_time_converts_to_utc():
    assert PLATFORM_TIMEZONE_NAME == "Asia/Tehran"
    assert tehran_now().tzinfo is not None
    assert tehran_now().tzinfo.key == "Asia/Tehran"
    assert tehran_local_to_utc_naive(datetime(2026, 11, 8, 12, 0)) == datetime(2026, 11, 8, 8, 30)
    assert as_utc_aware(datetime(2026, 11, 8, 8, 30)).tzinfo == timezone.utc


def test_event_lifecycle_transition_postpone_resume_and_archive():
    event = _event()
    postpone_event(event, note="زمان جدید متعاقباً اعلام می‌شود")
    assert event.is_postponed and not event.registration_open
    assert event.registration_closed_reason == "postponed"
    with pytest.raises(ValueError):
        resume_postponed_event(_event(), reopen_registration=True)
    resume_postponed_event(event, reopen_registration=True)
    assert not event.is_postponed and event.registration_open
    transition_event(event, EventStatus.COMPLETED)
    assert event.status == EventStatus.COMPLETED
    assert not event.registration_open and not event.waitlist_enabled
    archive_completed_event(event)
    assert event.archived and event.archived_at is not None


def test_cancelled_and_completed_events_clear_postponement():
    event = _event(is_postponed=True, postponement_note="paused", registration_open=False)
    transition_event(event, EventStatus.COMPLETED)
    assert not event.is_postponed and event.postponement_note is None


def test_checkin_proof_requires_expiry_and_accepts_nonce_only_for_current_session():
    from app.services.attendance_security import checkin_proof_is_valid, proof_digest

    now = datetime(2026, 11, 8, 12, 0)
    event = SimpleNamespace(
        attendance_checkin_token_hash=proof_digest("a" * 24),
        attendance_checkin_code_hash=proof_digest("123456"),
        attendance_checkin_session_id="0123456789abcdef",
        attendance_checkin_token_expires_at=now + timedelta(hours=1),
        attendance_checkin_code_expires_at=now + timedelta(hours=1),
    )
    assert checkin_proof_is_valid(event, "a" * 24, "token", now=now)
    assert checkin_proof_is_valid(event, "123456", "code", now=now)
    assert checkin_proof_is_valid(event, "0123456789abcdef", "token", now=now)
    assert not checkin_proof_is_valid(event, "ffffffffffffffff", "token", now=now)
    assert not checkin_proof_is_valid(event, "a" * 24, "token", now=now + timedelta(hours=1))
    assert not checkin_proof_is_valid(event, "123456", "code", now=now + timedelta(hours=1))


def test_outbox_event_helper_uses_stable_event_scoped_dedupe_keys():
    from app.services.notification_outbox import enqueue_event_notification

    # Validate the dispatch contract without pretending to run a PostgreSQL session.
    import inspect
    source = inspect.getsource(enqueue_event_notification)
    assert 'f"panel.published:{event_id}"' in source
    assert 'f"panel.changed:{event_id}:{change_key}"' in source
    assert 'payload={"event_id": event_id, "change_key": change_key}' in source


def test_public_media_upload_returns_both_full_and_thumbnail_variants(tmp_path, monkeypatch):
    from fastapi import UploadFile
    from app.config import settings
    from app.services.media_uploads import store_public_image

    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))
    monkeypatch.setattr(settings, "upload_min_free_mb", 0)
    monkeypatch.setattr(settings, "max_upload_storage_mb", 0)
    monkeypatch.setattr(settings, "max_image_upload_mb", 8)
    monkeypatch.setattr(settings, "image_max_dimension", 1200)
    monkeypatch.setattr(settings, "image_webp_quality", 82)

    image = Image.new("RGB", (1600, 900), (100, 120, 150))
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    upload = UploadFile(filename="cover.jpg", file=BytesIO(buffer.getvalue()))

    import asyncio
    stored = asyncio.run(store_public_image(upload, prefix="event-12-cover"))
    assert stored["url"].startswith("/api/v1/media/")
    assert stored["thumbnail_url"].endswith("?variant=thumb")
    full_name = stored["url"].rsplit("/", 1)[-1]
    thumb_name = full_name[:-5] + "-thumb.webp"
    public_root = tmp_path / "public_media"
    with Image.open(public_root / full_name) as full:
        assert full.format == "WEBP" and max(full.size) <= 1200
    with Image.open(public_root / thumb_name) as thumb:
        assert thumb.format == "WEBP" and max(thumb.size) <= 640


def test_waitlist_preserves_queue_during_postponement_and_suppresses_invites():
    import inspect
    from app.services import waitlist

    source = inspect.getsource(waitlist)
    assert 'or bool(getattr(event, "is_postponed", False))' in source
    assert 'Event.is_postponed.is_(False)' in source
    assert 'entry.status = "waiting" if event and event.status == EventStatus.PUBLISHED and not event.archived else "closed"' in source


def test_timezone_is_locked_and_frontend_date_rendering_is_tehran_independent_of_browser_zone():
    from pathlib import Path
    from app.config import Settings

    assert Settings(_env_file=None).app_timezone == "Asia/Tehran"
    with pytest.raises(ValueError):
        Settings(_env_file=None, app_timezone="Europe/Stockholm")

    root = Path(__file__).resolve().parents[1]
    api_source = (root / "website/src/api.ts").read_text(encoding="utf-8")
    calendar_source = (root / "website/src/components/PersianCalendar.tsx").read_text(encoding="utf-8")
    assert "export const PLATFORM_TIME_ZONE = 'Asia/Tehran'" in api_source
    assert "timeZone: PLATFORM_TIME_ZONE" in api_source
    assert "timeZone: PLATFORM_TIME_ZONE" in calendar_source
    assert "Date.UTC(year, monthIndex, day, 12)" in calendar_source
