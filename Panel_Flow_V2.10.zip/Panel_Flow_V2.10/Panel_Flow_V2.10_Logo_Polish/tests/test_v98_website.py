from pathlib import Path

from app.db.models import WebsiteLoginChallenge, WebsiteSavedEvent

ROOT = Path(__file__).resolve().parents[1]


def test_v98_website_models_are_part_of_the_existing_metadata():
    assert WebsiteLoginChallenge.__tablename__ == "website_login_challenges"
    assert WebsiteSavedEvent.__tablename__ == "website_saved_events"
    assert WebsiteLoginChallenge.__table__.metadata is WebsiteSavedEvent.__table__.metadata


def test_v98_website_api_contract_is_registered_without_duplicate_routes():
    from app.api import api

    paths = api.openapi()["paths"]
    required = {
        "/api/v1/auth/telegram/link",
        "/api/v1/auth/telegram/link/poll",
        "/api/v1/events/{event_id}",
        "/api/v1/events/{event_id}/waitlist",
        "/api/v1/me/overview",
        "/api/v1/me/saved-events",
        "/api/v1/me/waitlist",
        "/api/v1/me/shop/requests",
        "/api/v1/me/reviews/eligible",
        "/api/v1/staff/dashboard",
        "/api/v1/staff/payments/{payment_id}/review",
        "/api/v1/staff/shop/requests/{request_id}/review",
    }
    assert required.issubset(paths)
    registrations = [
        (route.path, method)
        for route in api.routes
        if hasattr(route, "methods")
        for method in route.methods or ()
    ]
    assert len(registrations) == len(set(registrations))


def test_v98_migration_is_additive_and_uses_the_existing_sql_migration_runner():
    migration = (ROOT / "migrations/045_website_login_and_saved_events.sql").read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS website_login_challenges" in migration
    assert "CREATE TABLE IF NOT EXISTS website_saved_events" in migration
    assert "ON DELETE CASCADE" in migration
    assert "DROP TABLE" not in migration.upper()
    runner = (ROOT / "app/db/init.py").read_text(encoding="utf-8")
    assert 'MIGRATION_DIR.glob("*.sql")' in runner
    assert "Base.metadata.create_all" in runner


def test_v98_bot_login_handoff_does_not_clear_an_active_user_fsm():
    bot_user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    handoff = bot_user.split('if payload.startswith("web_"):', 1)[1].split("prior_state = await state.get_state()", 1)[0]
    assert "WebsiteLoginChallenge" in handoff
    assert "existing_user =" in handoff
    assert "await state.clear()" not in handoff
    assert "challenge.status = \"authenticated\"" in handoff


def test_v98_website_container_and_api_share_the_existing_upload_volume():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    assert "uploads:/data/uploads" in compose
    assert "website:" in compose
    nginx = (ROOT / "website/nginx.conf").read_text(encoding="utf-8")
    assert "proxy_pass http://api:8000" in nginx
    assert "frame-ancestors 'self' https://web.telegram.org" in nginx


def test_v98_capacity_cannot_be_reduced_below_active_bookings_from_website_admin():
    routes = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    assert '"CAPACITY_BELOW_ACTIVE_BOOKINGS"' in routes
    assert 'if int(changes["capacity"]) < occupied:' in routes


def test_v98_website_inputs_reject_blank_text_and_unsafe_map_schemes():
    import pytest
    from pydantic import ValidationError

    from app.http_api.website_routes import (
        BookingParticipantInput,
        ChallengeAnswerInput,
        EventCreateInput,
        ProfileUpdateInput,
        ReviewCreateInput,
        TopicCreateInput,
    )

    with pytest.raises(ValidationError):
        BookingParticipantInput(first_name="   ", last_name="User")
    with pytest.raises(ValidationError):
        ProfileUpdateInput(display_name="  ")
    with pytest.raises(ValidationError):
        ReviewCreateInput(event_id=1, rating=5, text="          ")
    with pytest.raises(ValidationError):
        ChallengeAnswerInput(answer_text="   ")
    with pytest.raises(ValidationError):
        TopicCreateInput(title="    ")
    valid = {
        "volume": "Vol. 1", "title": "A valid event", "day": "Friday", "date": "TBD",
        "start_time": "18:00", "venue": "Studio", "city": "Mashhad", "capacity": 10,
        "price_per_person": 0,
    }
    with pytest.raises(ValidationError):
        EventCreateInput(**valid, map_url="javascript:alert(1)")
    assert EventCreateInput(**valid, map_url="https://maps.example/place").map_url == "https://maps.example/place"
