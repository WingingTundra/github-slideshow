from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def function_source(text: str, name: str) -> str:
    tree = ast.parse(text)
    node = next(item for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name)
    return ast.get_source_segment(text, node) or ""


def test_welcome_message_is_only_the_two_requested_lines():
    content = source("app/bot/content.py")
    welcome = function_source(content, "main_menu_welcome_text")
    assert r'"🧩 به Panel Flow خوش آمدید!\n"' in welcome
    assert '"فضایی برای گفت‌وگو و آشنایی با آدم‌های تازه."' in welcome
    assert "منوی اصلی" not in welcome


def test_xp_shop_and_giveaways_copy_are_consistent_and_icon_follows_label():
    keyboards = source("app/bot/keyboards.py")
    community_menu = function_source(keyboards, "community_menu_keyboard")
    assert r'\u2067🛍 ⁦XP⁩ شاپ\u2069' in community_menu
    assert r'\u2067🎁 ⁦Giveaways⁩\u2069' in community_menu
    content = source("app/bot/content.py")
    help_text = function_source(content, "user_help_text")
    assert "XP" in help_text and "شاپ" in help_text
    assert "Giveaways" in help_text
    assert "۱۰ نفر برتر" in help_text
    assert "رتبه ابتدا بر اساس" not in help_text


def test_my_bookings_status_formatter_has_its_fallback_import():
    user = source("app/bot/handlers/user.py")
    assert "from app.display_utils import has_end_time_label, volume_label, status_display_label" in user
    formatter = function_source(user, "booking_status_label")
    assert "status_display_label(status)" in formatter


def test_receipt_cancel_is_an_inline_booking_scoped_action_without_extra_reminder():
    keyboards = source("app/bot/keyboards.py")
    factory = function_source(keyboards, "receipt_upload_keyboard")
    assert 'callback_data=f"user:payment:cancel_receipt:{int(booking_id)}"' in factory
    assert "کپی شماره کارت" in factory
    user = source("app/bot/handlers/user.py")
    assert "برای لغو ارسال رسید، از دکمهٔ پایین استفاده کنید" not in user
    assert "_show_receipt_cancel_reply_button" not in user
    cancel = function_source(user, "cancel_receipt_button")
    assert "_show_receipt_cancel_confirmation(c.message, state, target_booking_id, edit_existing=True)" in cancel
    confirmation = function_source(user, "_show_receipt_cancel_confirmation")
    assert "secrets.token_hex(4)" in confirmation
    assert "receipt_cancel_confirmation_token" in confirmation
    assert "user:payment:cancel_confirm:" in confirmation
    assert "user:payment:cancel_back:" in confirmation
    confirm = function_source(user, "confirm_receipt_cancellation")
    assert "confirmation_for != target_id" in confirm
    assert "secrets.compare_digest" in confirm
    assert "confirmation_for not in (0, target_id)" not in confirm


def test_panel_wizard_uses_reply_keyboard_for_back_cancel_and_keeps_final_actions():
    keyboards = source("app/bot/keyboards.py")
    factory = function_source(keyboards, "admin_event_creation_reply_keyboard")
    assert "ReplyKeyboardMarkup" in factory and "KeyboardButton" in factory
    assert "⬅️ مرحلهٔ قبل" in factory and "❌ لغو ایجاد" in factory
    final_markup = function_source(keyboards, "event_creation_choice_keyboard")
    assert "admin:event:create:draft" in final_markup and "admin:event:create:publish" in final_markup
    assert "admin:event:create:back" not in final_markup
    assert "admin:event:create:cancel" not in final_markup
    admin = source("app/bot/handlers/admin.py")
    reply_menu = source("app/bot/handlers/reply_menu.py")
    assert "admin_event_creation_reply_actions" in admin
    assert 'F.text.in_({"⬅️ مرحلهٔ قبل", "❌ لغو ایجاد"})' in reply_menu
    assert "panel_creation_reply_keyboard_action" in reply_menu
    assert "_creation_step_back(message, state)" in admin
    assert "_cancel_creation_flow(message, state, actor_id)" in admin


def test_admin_dashboard_and_challenges_have_swapped_positions():
    menu = function_source(source("app/bot/keyboards.py"), "admin_menu")
    assert menu.index('text="🎯 مدیریت چالش‌ها"') < menu.index('text="📊 داشبورد مدیریتی"')


def test_incomplete_process_button_uses_short_label():
    user = source("app/bot/handlers/user.py")
    admin = source("app/bot/handlers/admin.py")
    assert 'text="لغو فرایند"' in user
    assert 'text="لغو فرایند"' in admin
    assert 'text="لغو فرایند ثبت‌نام"' not in user + admin


def test_telegram_dynamic_callback_payloads_are_compact_and_legacy_routes_remain_supported():
    keys = source("app/bot/keyboards.py")
    reasons = function_source(keys, "payment_rejection_reasons_keyboard")
    confirm = function_source(keys, "payment_rejection_confirm_keyboard")
    assert 'f"prr:{int(payment_id)}:{token}:{scope}' in reasons
    assert 'f"prc:{int(payment_id)}:{token}:{scope}' in reasons
    assert 'f"prf:{int(payment_id)}:{token}:{int(event_id)}:{category}' in confirm
    assert 'f"prb:{int(payment_id)}:{token}:{int(event_id)}' in confirm
    # Largest signed 32-bit IDs, 12-char receipt token and longest category.
    candidates = [
        f"prr:{2147483647}:{'0'*12}:{2147483647}:{reason}"
        for reason in ("not_received", "amount_mismatch", "unclear", "duplicate")
    ] + [
        f"prc:{2147483647}:{'0'*12}:{2147483647}",
        f"prf:{2147483647}:{'0'*12}:{2147483647}:amount_mismatch",
        f"prb:{2147483647}:{'0'*12}:{2147483647}",
    ]
    candidates += [
        f"admin:payment:reject:{2147483647}:{'0'*12}:{2147483647}",
        f"admin:payment:approve:{2147483647}:{'0'*12}:{2147483647}",
    ] + [
        f"mc:{2147483647}:{code}" for code in ("w", "s24", "s7", "b", "r", "b24", "b7", "bf", "s24x", "s7x", "sfx", "c24", "c7", "cf", "ub", "us", "uc")
    ]
    assert max(map(lambda value: len(value.encode()), candidates)) <= 64
    actions = function_source(source("app/bot/handlers/admin_console.py"), "_moderation_start_callback")
    assert 'return f"mc:{int(user_id)}:{code}"' in actions
    assert "mc:\\d+:[a-z0-9]+" in source("app/bot/handlers/admin_console.py")
    parser = function_source(source("app/bot/handlers/admin_payment_actions.py"), "_parse_compact_rejection_callback")
    assert 'parts[0] == "prr"' in parser and 'parts[0] == "prf"' in parser
    assert 'parts[:4] == ["admin", "payment", "reject", "reason"]' in parser


def test_payment_cancel_is_attempt_bound_and_all_exit_paths_remove_stale_wizard_keyboard():
    user = source("app/bot/handlers/user.py")
    confirm = function_source(user, "confirm_receipt_cancellation")
    back = function_source(user, "back_to_receipt_payment")
    assert "receipt_cancel_confirmation_token" in confirm and "compare_digest" in confirm
    assert "receipt_cancel_confirmation_token" in back and "compare_digest" in back
    assert "confirmation_for not in (0, target_id)" not in confirm
    cancel = function_source(user, "cancel_interaction")
    assert "_show_receipt_cancel_confirmation(message, state, booking_id)" in cancel
    navigation = function_source(user, "confirm_navigation_discard")
    assert "ReplyKeyboardRemove()" in navigation
    assert navigation.count("کنترل‌های فرایند قبلی بسته شد.") == 2


def test_booking_status_labels_are_persian_and_unused_admin_channel_state_removed():
    user = source("app/bot/handlers/user.py")
    formatter = function_source(user, "booking_status_label")
    for label in ("در حال تکمیل", "در صف انتظار", "در انتظار پرداخت", "در انتظار بررسی رسید", "تأییدشده", "لغوشده"):
        assert label in formatter
    states = source("app/bot/states.py")
    assert "waiting_group_post" not in states
