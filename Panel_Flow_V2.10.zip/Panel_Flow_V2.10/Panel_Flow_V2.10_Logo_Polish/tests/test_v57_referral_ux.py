"""V57 referral count visibility and user-facing copy regressions."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
USER = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
COMMUNITY = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
REFERRALS = (ROOT / "app/services/referrals.py").read_text(encoding="utf-8")
COMMUNITY_SERVICE = (ROOT / "app/services/community.py").read_text(encoding="utf-8")


def test_my_referral_code_shows_code_count_and_generalized_reward_copy():
    section = USER.split('async def show_my_referral_code', 1)[1].split('\ndef profile_text', 1)[0]
    assert 'count_referrals_for_telegram_id(session, telegram_id)' in section
    assert 'کد شما: <code>{telegram_id}</code>' in section
    assert 'این عدد را برای دوستانتان بفرستید' in section
    assert 'تعداد معرفی‌های موفق شما: <b>{referral_count}</b>' in section
    assert 'با معرفی‌های موفق' in section
    assert 'نوع و مقدار پاداش ممکن است متفاوت باشد' in section
    assert 'آمار معرفی‌ها فقط برای مدیران نمایش داده می‌شود' not in section
    assert 'برای دوستتان بفرستید' not in section


def test_passport_includes_the_same_referral_count():
    passport = COMMUNITY.split('async def community_passport', 1)[1].split('\nasync def _render_user_challenges', 1)[0]
    assert "stats['referrals']" in passport
    assert 'دوستان معرفی‌شده:' in passport
    assert '"referrals": referrals' in COMMUNITY_SERVICE
    assert 'count_referrals_for_telegram_id(session, telegram_id)' in COMMUNITY_SERVICE
    assert 'async def count_referrals_for_telegram_id' in REFERRALS
