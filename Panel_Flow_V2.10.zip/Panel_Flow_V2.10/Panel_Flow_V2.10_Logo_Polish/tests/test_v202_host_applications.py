from datetime import date
from pathlib import Path
from types import SimpleNamespace

import pytest
from pydantic import ValidationError

from app.db.models import Base, HostApplication, UserRole
from app.http_api.host_application_routes import (
    APPLICATION_STATUSES,
    HostApplicationDraftInput,
    _application_payload,
    _can_apply_as_member,
    _history_payload,
)

ROOT = Path(__file__).resolve().parents[1]


def test_v202_host_application_tables_and_admin_role_are_registered():
    assert UserRole.ADMIN.value == "admin"
    assert {
        "host_applications",
        "host_application_history",
        "host_application_notifications",
        "host_public_profiles",
    }.issubset(Base.metadata.tables)


def test_v202_status_set_covers_the_requested_review_lifecycle():
    assert APPLICATION_STATUSES == {
        "draft", "submitted", "under_review", "more_information_required",
        "approved", "rejected", "withdrawn",
    }


def test_v202_application_input_validates_contact_date_url_and_formats():
    with pytest.raises(ValidationError):
        HostApplicationDraftInput(date_of_birth="2099-01-01")
    with pytest.raises(ValidationError):
        HostApplicationDraftInput(email="not-an-email")
    with pytest.raises(ValidationError):
        HostApplicationDraftInput(portfolio_url="javascript:alert(1)")
    with pytest.raises(ValidationError):
        HostApplicationDraftInput(preferred_formats=["unrestricted"])
    with pytest.raises(ValidationError):
        HostApplicationDraftInput(national_id="1111111111")


def test_v202_member_application_gate_rejects_non_member_roles(monkeypatch):
    from app.config import settings

    monkeypatch.setattr(settings, "super_admin_ids", "9001,9002")
    assert _can_apply_as_member(SimpleNamespace(role=UserRole.PARTICIPANT, telegram_id=42))
    assert not _can_apply_as_member(SimpleNamespace(role=UserRole.HOST, telegram_id=42))
    assert not _can_apply_as_member(SimpleNamespace(role=UserRole.ADMIN, telegram_id=42))
    assert not _can_apply_as_member(SimpleNamespace(role=UserRole.SUPER_ADMIN, telegram_id=42))
    assert not _can_apply_as_member(SimpleNamespace(role=UserRole.PARTICIPANT, telegram_id=9001))


def test_v202_applicant_payload_masks_identity_and_excludes_reviewer_private_fields():
    row = SimpleNamespace(
        id=10, user_id=7, status="under_review", legal_name="Applicant",
        national_id_ciphertext=b"encrypted", date_of_birth=date(1999, 1, 1),
        verified_mobile="+989000000000", email="a@example.com", residence_city_id=1,
        english_proficiency="C1", english_certification=None, relevant_experience="x",
        hosting_background="y", motivation="z", portfolio_url=None,
        preferred_city_ids=[1], preferred_topics=["Culture"], preferred_formats=["in_person"],
        availability=None, public_display_name="Public host", public_bio="Bio", public_languages=["English"],
        applicant_response=None, requested_information=None, rejection_reason=None,
        interview_at=None, interview_location=None, submitted_at=None, reviewed_at=None,
        created_at=None, updated_at=None, internal_notes="PRIVATE REVIEW NOTE",
        interview_notes="PRIVATE INTERVIEW NOTE", reviewed_by_user_id=3,
    )
    public = _application_payload(row)
    admin = _application_payload(row, admin=True)
    assert public["national_id_masked"] == "••••••••••"
    assert "internal_notes" not in public and "interview_notes" not in public
    assert admin["internal_notes"] == "PRIVATE REVIEW NOTE"
    assert admin["interview_notes"] == "PRIVATE INTERVIEW NOTE"


def test_v202_internal_notes_are_not_returned_in_applicant_history():
    row = SimpleNamespace(id=1, action="internal_note", from_status="under_review",
                          to_status="under_review", note=None, created_at=None)
    assert _history_payload(row, applicant=True) is None
    assert _history_payload(row, applicant=False)["action"] == "internal_note"


def test_v202_migration_is_additive_and_sql_splitter_keeps_enum_block_intact():
    from app.db.migration_utils import split_sql_statements

    path = ROOT / "migrations/049_host_applications_and_unified_roles.sql"
    sql = path.read_text(encoding="utf-8")
    statements = split_sql_statements(sql)
    assert statements[0].startswith("-- V2.02") or statements[0].startswith("DO $$")
    assert any("ALTER TYPE userrole ADD VALUE IF NOT EXISTS 'ADMIN'" in item for item in statements)
    assert "CREATE TABLE IF NOT EXISTS host_applications" in sql
    assert "CREATE TABLE IF NOT EXISTS host_application_history" in sql
    assert "CREATE TABLE IF NOT EXISTS host_application_notifications" in sql
    assert "CREATE TABLE IF NOT EXISTS host_public_profiles" in sql
    assert "DROP TABLE" not in sql.upper()


def test_v202_routes_are_registered_and_host_workspace_api_is_scoped():
    from app.api import api

    paths = {route.path for route in api.routes if hasattr(route, "path")}
    expected = {
        "/api/v1/me/host-application",
        "/api/v1/me/host-application/submit",
        "/api/v1/me/host-application/reapply",
        "/api/v1/staff/platform/host-applications",
        "/api/v1/staff/platform/host-applications/{application_id}/review",
        "/api/v1/staff/host/events/{event_id}/participants",
        "/api/v1/staff/host/payments",
        "/api/v1/staff/host/payments/{payment_id}/receipt",
        "/api/v1/staff/host/reviews",
        "/api/v1/me/host-profile",
    }
    assert expected.issubset(paths)


def test_v202_compose_passes_identity_key_to_api_and_readme_points_to_v202_docs():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    api_service = compose.split("  api:\n", 1)[1].split("  website:\n", 1)[0]
    assert "HOST_IDENTITY_ENCRYPTION_KEY: ${HOST_IDENTITY_ENCRYPTION_KEY:-}" in api_service
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert readme.startswith("# Panel Flow — V2.06")
    assert "V2.06_DEPLOYMENT_NOTES.md" in readme
    assert "V2.06_CHANGELOG.md" in readme
