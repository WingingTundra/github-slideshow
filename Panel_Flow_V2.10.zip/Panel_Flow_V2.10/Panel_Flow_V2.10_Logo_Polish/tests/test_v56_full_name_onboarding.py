"""V56 regressions for one-message full-name onboarding and menu wording."""
from __future__ import annotations

import ast
from pathlib import Path

from app.bot.validation import parse_full_name

ROOT = Path(__file__).resolve().parents[1]
USER = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
COMMUNITY = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
KEYBOARDS = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
CONTENT = (ROOT / "app/bot/content.py").read_text(encoding="utf-8")
STATES = (ROOT / "app/bot/states.py").read_text(encoding="utf-8")


def _function_source(source: str, name: str) -> str:
    tree = ast.parse(source)
    node = next(
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
    )
    return ast.get_source_segment(source, node) or ""


def test_onboarding_full_name_parser_preserves_database_field_split_and_validates_input():
    assert parse_full_name("Sina Ziaei") == ("Sina", "Ziaei")
    assert parse_full_name("سینا ضیائی") == ("سینا", "ضیائی")
    assert parse_full_name("Mary Ann Smith") == ("Mary", "Ann Smith")
    for invalid in ("Sina", "", "/admin", "/help", "https://example.com", "123456"):
        assert parse_full_name(invalid) is None


def test_initial_onboarding_asks_full_name_once_instead_of_separate_name_steps():
    continue_onboarding = _function_source(USER, "continue_onboarding")
    register = _function_source(USER, "begin_register_from_message")
    save_full_name = _function_source(USER, "save_full_name")
    challenge = _function_source(COMMUNITY, "show_challenge_from_message")

    assert "onboarding_full_name_prompt()" in continue_onboarding
    assert "onboarding_full_name_prompt()" in register
    assert "onboarding_full_name_prompt()" in challenge
    for source in (continue_onboarding, register, challenge):
        assert "ProfileStates.waiting_full_name" in source
        assert "ProfileStates.waiting_first_name" not in source
        assert "ProfileStates.waiting_last_name" not in source

    assert 'parse_full_name(message.text or "")' in save_full_name
    assert "user.first_name = first_name" in save_full_name
    assert "user.last_name = last_name" in save_full_name
    assert 'user.display_name = f"{first_name} {last_name}".strip()' in save_full_name
    assert "await _continue_profile_after_name(message, state)" in save_full_name
    assert "waiting_full_name = State()" in STATES


def test_full_name_transition_preserves_phone_referral_and_deep_link_chain():
    continuation = _function_source(USER, "_continue_profile_after_name")
    assert 'pending_start_payload' in continuation
    assert 'pending_allow_duplicate' in continuation
    assert 'ProfileStates.waiting_phone' in continuation
    assert 'ask_referral_choice(message, state)' in continuation
    assert 'dispatch_start_payload(' in continuation
    phone = _function_source(USER, "save_phone")
    assert 'needs_referral' in phone
    assert 'pending_payload' in phone
    assert 'dispatch_start_payload(' in phone


def test_full_name_export_contract_remains_first_name_last_name_based():
    export_source = (ROOT / "app/services/registered_users_export.py").read_text(encoding="utf-8")
    referral_source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert 'getattr(user, "first_name"' in export_source
    assert 'getattr(user, "last_name"' in export_source
    assert 'user.first_name' in referral_source and 'user.last_name' in referral_source
    assert 'build_referral_report_xlsx' in referral_source


def test_main_menu_and_help_use_the_new_upcoming_panels_label():
    assert 'text="🏠 پنل‌های پیش‌رو"' in KEYBOARDS
    assert 'پنل‌های پیش‌رو</b>' in CONTENT
    assert '<b>🏠 پنل‌های پیش‌رو</b>' in USER
    assert 'text="🏠 پنل‌های منتشرشده"' not in KEYBOARDS
