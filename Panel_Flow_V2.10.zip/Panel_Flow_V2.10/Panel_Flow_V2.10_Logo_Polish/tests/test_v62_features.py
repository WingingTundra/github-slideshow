from __future__ import annotations

import asyncio
import importlib
import sys
import types
import zipfile
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
from xml.etree import ElementTree as ET

import pytest

from app.db.models import (
    AnnouncementBroadcast, AnnouncementDelivery, Base, ChannelAnnouncement,
    PaymentReviewAttempt, RewardBatch, RewardBatchRecipient,
)
from app.services.bulk_rewards import (
    MAX_BULK_FILE_BYTES, MAX_BULK_ROWS, parse_manual_recipients,
    parse_uploaded_recipients,
)
from app.services.payment_review import receipt_fingerprint, receipt_review_token
from app.services.referral_export import build_referral_report_xlsx
from app.services.channel_status import validate_post_destination

ROOT = Path(__file__).resolve().parents[1]


def test_manual_reward_recipient_parser_normalizes_digits_and_reports_duplicates_and_invalid_rows():
    parsed = parse_manual_recipients("123456\n۱۲۳۴۵۶\n ٤٥٦٧٨٩ \nnot-an-id\n,\n")
    assert parsed.ids == [123456, 456789]
    assert parsed.submitted_entries == 6
    assert parsed.duplicates == [{"entry": "خط 2", "telegram_id": 123456}]
    assert len(parsed.invalid) == 3
    assert parsed.invalid[0]["entry"] == "خط 4"
    assert parsed.invalid[0]["value"] == "not-an-id"
    assert all(item["value"] == "" for item in parsed.invalid[1:])


def test_manual_parser_supports_comma_separated_entries_but_not_usernames_or_signed_ids():
    parsed = parse_manual_recipients("123, 456\n@somebody\n-789\n0")
    assert parsed.ids == [123, 456]
    assert [item["value"] for item in parsed.invalid] == ["@somebody", "-789", "0"]


def test_empty_fields_in_comma_separated_lists_are_reported_as_invalid():
    parsed = parse_manual_recipients("123,,456,\n\n789")
    assert parsed.ids == [123, 456, 789]
    assert [item["value"] for item in parsed.invalid] == ["", ""]
    assert parsed.invalid[0]["entry"] == "خط 1، مورد 2"


def test_uploaded_txt_and_csv_accept_header_and_normalize_digits():
    txt = parse_uploaded_recipients("123\n۱۲۳\n٤٥٦\n".encode(), ".txt")
    assert txt.ids == [123, 456]
    assert txt.duplicates[0]["telegram_id"] == 123
    csv = parse_uploaded_recipients("telegram_id,name\n123,Ali\n۴۵۶,Sara\n".encode(), ".csv")
    assert csv.ids == [123, 456]
    assert csv.invalid == []


def test_uploaded_csv_does_not_silently_parse_arbitrary_text():
    parsed = parse_uploaded_recipients("telegram_id\n123abc\n@name\n".encode(), ".csv")
    assert parsed.ids == []
    assert len(parsed.invalid) == 2
    with pytest.raises(ValueError, match="UNSUPPORTED_FILE"):
        parse_uploaded_recipients(b"123", ".xlsx")
    with pytest.raises(ValueError, match="INVALID_ENCODING"):
        parse_uploaded_recipients(b"\xff\xfe", ".txt")


def test_bulk_parser_enforces_file_text_and_row_limits():
    with pytest.raises(ValueError, match="INPUT_TOO_LARGE"):
        parse_manual_recipients("x" * 20_001)
    with pytest.raises(ValueError, match="TOO_MANY_ROWS"):
        parse_manual_recipients("\n".join(str(x + 1000) for x in range(MAX_BULK_ROWS + 1)))
    with pytest.raises(ValueError, match="FILE_TOO_LARGE"):
        parse_uploaded_recipients(b"x" * (MAX_BULK_FILE_BYTES + 1), ".txt")


def test_receipt_fingerprint_changes_for_replacement_and_distinguishes_review_token():
    payment = SimpleNamespace(
        receipt_file="/uploads/receipt-1.jpg", receipt_file_name="receipt.jpg",
        receipt_text=None, receipt_uploaded_at=None,
    )
    first = receipt_fingerprint(payment)
    first_token = receipt_review_token(payment)
    payment.receipt_text = "12345"
    assert receipt_fingerprint(payment) != first
    assert receipt_review_token(payment) != first_token
    payment.receipt_text = None
    payment.receipt_file = "/uploads/receipt-2.jpg"
    assert receipt_fingerprint(payment) != first


def test_v62_models_and_migrations_are_additive_and_have_idempotency_constraints():
    tables = Base.metadata.tables
    assert "payment_review_attempts" in tables
    assert "reward_batches" in tables and "reward_batch_recipients" in tables
    assert "announcement_broadcasts" in tables and "announcement_deliveries" in tables
    assert "destination_type" in ChannelAnnouncement.__table__.columns
    assert any("uq_payment_review_receipt_version" in str(c.name) for c in PaymentReviewAttempt.__table__.constraints)
    assert any("uq_reward_batch_telegram_id" in str(c.name) for c in RewardBatchRecipient.__table__.constraints)
    assert any("uq_announcement_delivery_recipient" in str(c.name) for c in AnnouncementDelivery.__table__.constraints)
    for name in (
        "022_v62_audit_receipt_history_reward_batches_and_post_links.sql",
        "023_v62_resilient_broadcasts.sql",
    ):
        sql = (ROOT / "migrations" / name).read_text(encoding="utf-8").upper()
        assert "CREATE TABLE IF NOT EXISTS" in sql
        assert "DROP TABLE" not in sql and "TRUNCATE" not in sql and "DELETE FROM" not in sql


def test_group_and_channel_target_validation_checks_chat_type_membership_and_rights():
    class FakeBot:
        def __init__(self, chat_type="supergroup", status="member", can_send_messages=True, can_post_messages=True):
            self.chat_type = chat_type
            self.status = status
            self.can_send_messages = can_send_messages
            self.can_post_messages = can_post_messages

        async def get_chat(self, chat_id):
            if chat_id == -999:
                raise RuntimeError("chat not accessible")
            return SimpleNamespace(type=self.chat_type, title="Test target")

        async def get_me(self):
            return SimpleNamespace(id=999)

        async def get_chat_member(self, chat_id, user_id):
            return SimpleNamespace(
                status=self.status, can_send_messages=self.can_send_messages,
                can_post_messages=self.can_post_messages,
            )

    assert asyncio.run(validate_post_destination(FakeBot(), -1001, "group")) == "Test target"
    with pytest.raises(ValueError, match="TARGET_NOT_GROUP"):
        asyncio.run(validate_post_destination(FakeBot(chat_type="channel"), -1001, "group"))
    with pytest.raises(ValueError, match="BOT_NOT_IN_GROUP"):
        asyncio.run(validate_post_destination(FakeBot(status="left"), -1001, "group"))
    with pytest.raises(ValueError, match="BOT_CANNOT_SEND_TO_GROUP"):
        asyncio.run(validate_post_destination(FakeBot(status="restricted", can_send_messages=False), -1001, "group"))
    with pytest.raises(ValueError, match="BOT_NEEDS_CHANNEL_ADMIN"):
        asyncio.run(validate_post_destination(FakeBot(chat_type="channel", status="member"), -1001, "channel"))
    with pytest.raises(ValueError, match="TARGET_CHAT_INACCESSIBLE"):
        asyncio.run(validate_post_destination(FakeBot(), -999, "group"))


def test_referral_export_detail_sheet_contains_lifetime_and_actual_attendance_metrics():
    payload = build_referral_report_xlsx(
        [{"name": "Referrer", "telegram_id": 111, "username": "@ref", "referral_count": 1}],
        [{
            "referrer_name": "Referrer", "referrer_telegram_id": 111,
            "referred_name": "Referred", "referred_telegram_id": 222,
            "username": "@person", "phone_number": "+100", "created_at": None,
            "ever_confirmed_booking": "Yes", "lifetime_confirmed_bookings": 2,
            "confirmed_bookings": 1, "confirmed_panels": 1,
            "panels_attended": 1, "ever_attended_panel": "Yes",
        }],
    )
    with zipfile.ZipFile(BytesIO(payload)) as workbook:
        shared = workbook.read("xl/sharedStrings.xml").decode("utf-8")
        sheet = workbook.read("xl/worksheets/sheet2.xml").decode("utf-8")
    for header in (
        "Phone Number", "Signup Date", "Ever Confirmed Booking (lifetime)",
        "Lifetime Confirmed Bookings", "Distinct Panels Attended", "Ever Attended a Panel",
    ):
        assert header in shared
    # Eleven numeric/text body fields are emitted after the legacy profile fields.
    assert "222" in shared and "@person" in shared
    assert '<c r="L2"' in sheet or 'r="L2"' in sheet


def test_v62_source_enforces_completed_archive_and_review_eligibility_and_admin_pagination():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert "if event.status != EventStatus.COMPLETED" in admin
    assert "Event.status == EventStatus.COMPLETED" in user
    assert "admin:events:page:" in admin
    assert "admin:announcements:page:" in admin
    assert "admin:reviews:eventpage:" in admin
    assert "AnnouncementDelivery" in admin and "send_announcement_to_user" in admin
    assert "personal_reward_created" in admin and "bulk_reward_batch_processed" in admin


@pytest.fixture
def announcement_service(monkeypatch):
    """Load the sender against deterministic aiogram exception stubs for unit testing."""
    saved = {name: sys.modules.get(name) for name in ("aiogram", "aiogram.exceptions", "aiogram.types", "app.services.announcements")}
    aiogram = types.ModuleType("aiogram")
    aiogram.Bot = object
    exceptions = types.ModuleType("aiogram.exceptions")

    class TelegramAPIError(Exception): pass
    class TelegramBadRequest(TelegramAPIError): pass
    class TelegramForbiddenError(TelegramAPIError): pass
    class TelegramNetworkError(TelegramAPIError): pass
    class TelegramServerError(TelegramAPIError): pass
    class TelegramRetryAfter(TelegramAPIError):
        def __init__(self, retry_after):
            self.retry_after = retry_after
            super().__init__(f"retry after {retry_after}")

    for cls in (TelegramAPIError, TelegramBadRequest, TelegramForbiddenError, TelegramNetworkError, TelegramServerError, TelegramRetryAfter):
        setattr(exceptions, cls.__name__, cls)
    telegram_types = types.ModuleType("aiogram.types")
    class InlineKeyboardMarkup: pass
    telegram_types.InlineKeyboardMarkup = InlineKeyboardMarkup
    monkeypatch.setitem(sys.modules, "aiogram", aiogram)
    monkeypatch.setitem(sys.modules, "aiogram.exceptions", exceptions)
    monkeypatch.setitem(sys.modules, "aiogram.types", telegram_types)
    sys.modules.pop("app.services.announcements", None)
    module = importlib.import_module("app.services.announcements")
    module._test_exceptions = SimpleNamespace(
        TelegramRetryAfter=TelegramRetryAfter, TelegramNetworkError=TelegramNetworkError,
        TelegramForbiddenError=TelegramForbiddenError,
    )
    async def no_sleep(_seconds):
        return None
    monkeypatch.setattr(module.asyncio, "sleep", no_sleep)
    yield module
    sys.modules.pop("app.services.announcements", None)
    for name, old in saved.items():
        if old is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = old


def test_broadcast_sender_honors_retry_after_and_retries_transient_network_errors(announcement_service):
    module = announcement_service
    RetryAfter = module._test_exceptions.TelegramRetryAfter
    NetworkError = module._test_exceptions.TelegramNetworkError

    class FakeBot:
        def __init__(self, exceptions): self.exceptions = list(exceptions); self.calls = 0
        async def send_message(self, *args, **kwargs):
            self.calls += 1
            if self.exceptions:
                raise self.exceptions.pop(0)

    bot = FakeBot([RetryAfter(3)])
    result = asyncio.run(module.send_announcement_to_user(bot, 123, "hello", max_attempts=3))
    assert result.status == "sent" and result.attempts == 2 and bot.calls == 2
    bot = FakeBot([NetworkError("socket closed")])
    result = asyncio.run(module.send_announcement_to_user(bot, 123, "hello", max_attempts=3))
    assert result.status == "sent" and result.attempts == 2 and bot.calls == 2


def test_broadcast_sender_stops_permanent_failures_and_marks_uncertain_network_result(announcement_service):
    module = announcement_service
    Forbidden = module._test_exceptions.TelegramForbiddenError
    NetworkError = module._test_exceptions.TelegramNetworkError

    class FakeBot:
        def __init__(self, exc): self.exc = exc; self.calls = 0
        async def send_message(self, *args, **kwargs):
            self.calls += 1
            raise self.exc

    bot = FakeBot(Forbidden("bot blocked"))
    result = asyncio.run(module.send_announcement_to_user(bot, 123, "hello", max_attempts=4))
    assert result.status == "failed" and result.attempts == 1 and bot.calls == 1
    bot = FakeBot(NetworkError("connection timed out"))
    result = asyncio.run(module.send_announcement_to_user(bot, 123, "hello", max_attempts=2))
    assert result.status == "unknown" and result.attempts == 2 and bot.calls == 2
