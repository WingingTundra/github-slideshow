from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

from app.db.models import PaymentStatus, RegistrationStatus
from app.services.discounts import (
    calculate_discount,
    normalize_code,
    parse_personal_discount_value,
    parse_public_code_definition,
)
from app.services.upload_maintenance import cleanup_expired_receipts_once


class _FakeResult:
    def __init__(self, values=(), scalar=None):
        self.values = list(values)
        self.scalar = scalar

    def scalars(self):
        return self

    def all(self):
        return list(self.values)

    def scalar_one_or_none(self):
        if self.scalar is not None:
            return self.scalar
        return self.values[0] if self.values else None


class _FakeSession:
    def __init__(self, *, execute_results=(), get_values=None):
        self.execute_results = list(execute_results)
        self.get_values = get_values or {}
        self.commits = 0
        self.rollbacks = 0

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def execute(self, statement):
        if not self.execute_results:
            return _FakeResult()
        result = self.execute_results.pop(0)
        return result if isinstance(result, _FakeResult) else _FakeResult(values=result)

    async def get(self, model, key, **kwargs):
        return self.get_values.get((model.__name__, key))

    async def commit(self):
        self.commits += 1

    async def rollback(self):
        self.rollbacks += 1


def _factory_for(sessions):
    pending = list(sessions)

    def factory():
        assert pending, "Unexpected database session requested by receipt cleanup"
        return pending.pop(0)

    return factory


def test_discount_code_format_normalizes_and_parses_percentage_and_fixed_amount():
    definition = parse_public_code_definition("girlsday۵۰")
    assert definition.canonical_code == "GIRLSDAY50"
    assert definition.discount_type == "percent"
    assert definition.discount_value == Decimal("50")

    fixed = parse_public_code_definition("PANEL100K")
    assert fixed.canonical_code == "PANEL100K"
    assert fixed.discount_type == "fixed"
    assert fixed.discount_value == Decimal("100000")

    assert normalize_code(" panel ۲۰ ") == "PANEL20"
    assert parse_personal_discount_value("۸۰٪") == ("percent", Decimal("80"))
    assert parse_personal_discount_value("100K") == ("fixed", Decimal("100000"))


def test_discount_math_supports_group_total_and_one_person_scope():
    total = Decimal("300000")
    one_person = Decimal("100000")

    # General 20% promotion applies to the full three-person booking.
    assert calculate_discount(total, one_person, 3, "percent", 20, scope="total") == Decimal("60000")
    # Restricted 50% promotion applies to one admission only.
    assert calculate_discount(total, one_person, 3, "percent", 50, scope="single") == Decimal("50000")
    # A 100% single-person reward leaves the other two admissions payable.
    assert total - calculate_discount(total, one_person, 3, "percent", 100, scope="single") == Decimal("200000")
    # The same reward for one participant produces a free booking without a receipt.
    assert one_person - calculate_discount(one_person, one_person, 1, "percent", 100, scope="single") == Decimal("0")
    # Fixed amount discounts never exceed the selected scope's price.
    assert calculate_discount(total, one_person, 3, "fixed", 250000, scope="single") == Decimal("100000")


def test_30_day_receipt_cleanup_deletes_file_but_preserves_reviewed_booking_and_payment(monkeypatch, tmp_path):
    from app.config import settings

    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))
    monkeypatch.setattr(settings, "receipt_retention_days", 30)
    now = datetime(2026, 10, 11, 12, 0, 0)
    receipt = tmp_path / "old-approved-receipt.jpg"
    receipt.write_bytes(b"receipt")
    event = SimpleNamespace(id=7, volume=21, title="Reviewed", questions_pdf_path=None)
    booking = SimpleNamespace(
        id=17, event_id=7, booked_by_user_id=5, status=RegistrationStatus.CONFIRMED,
        cancelled_at=None, expires_at=None,
    )
    payment = SimpleNamespace(
        id=27, booking_id=17, booking=booking, status=PaymentStatus.APPROVED,
        receipt_uploaded_at=now - timedelta(days=31), receipt_file=str(receipt),
        receipt_file_name="old-approved-receipt.jpg", receipt_text=None,
        reviewed_at=now - timedelta(days=30), reviewed_by=9,
    )
    data_session = _FakeSession(execute_results=[_FakeResult(values=[payment])])
    path_session = _FakeSession(execute_results=[_FakeResult(values=[]), _FakeResult(values=[])])

    deleted_count = asyncio.run(cleanup_expired_receipts_once(
        session_factory=_factory_for([data_session, path_session]), now=now
    ))

    assert deleted_count == 1
    assert not receipt.exists()
    assert payment.receipt_file is None
    assert payment.receipt_file_name is None
    assert payment.receipt_text is None
    assert payment.receipt_uploaded_at == now - timedelta(days=31)
    assert payment.status == PaymentStatus.APPROVED
    assert payment.reviewed_by == 9
    assert booking.status == RegistrationStatus.CONFIRMED
    assert data_session.commits == 1


def test_expired_unreviewed_receipt_releases_pending_seat_but_keeps_payment_history(monkeypatch, tmp_path):
    from app.config import settings
    from app.db.models import Booking, Event, User

    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))
    monkeypatch.setattr(settings, "receipt_retention_days", 30)
    now = datetime(2026, 10, 11, 12, 0, 0)
    receipt = tmp_path / "old-pending-receipt.jpg"
    receipt.write_bytes(b"receipt")
    owner = SimpleNamespace(id=5, telegram_id=555123)
    event = SimpleNamespace(id=7, volume=21, title="Pending", questions_pdf_path=None)
    booking = SimpleNamespace(
        id=17, event_id=7, booked_by_user_id=5, status=RegistrationStatus.PENDING_VERIFICATION,
        cancelled_at=None, expires_at=None,
    )
    payment = SimpleNamespace(
        id=27, booking_id=17, booking=booking, status=PaymentStatus.PENDING,
        receipt_uploaded_at=now - timedelta(days=31), receipt_file=str(receipt),
        receipt_file_name="old-pending-receipt.jpg", receipt_text=None,
        reviewed_at=None, reviewed_by=None,
    )
    first = _FakeSession(execute_results=[_FakeResult(values=[payment])])
    path_check = _FakeSession(execute_results=[_FakeResult(values=[]), _FakeResult(values=[])])
    release = _FakeSession(
        execute_results=[_FakeResult(scalar=payment)],
        get_values={
            (Booking.__name__, booking.id): booking,
            (Event.__name__, event.id): event,
            (User.__name__, owner.id): owner,
        },
    )

    deleted_count = asyncio.run(cleanup_expired_receipts_once(
        session_factory=_factory_for([first, path_check, release]), now=now
    ))

    assert deleted_count == 1
    assert not receipt.exists()
    assert payment.receipt_file is None
    assert payment.receipt_text is None
    assert payment.status == PaymentStatus.REJECTED
    assert payment.reviewed_at == now
    assert payment.reviewed_by is None
    assert booking.status == RegistrationStatus.REJECTED
    assert booking.cancelled_at == now
    assert booking.expires_at is None
    assert release.commits == 1


def test_v31_registration_and_admin_paths_preserve_the_expected_product_rules():
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    user = (root / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    admin = (root / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    keyboard = (root / "app/bot/keyboards.py").read_text(encoding="utf-8")
    model = (root / "app/db/models.py").read_text(encoding="utf-8")
    migration = (root / "migrations/013_discount_codes_and_receipt_retention.sql").read_text(encoding="utf-8")
    cleanup = (root / "app/services/upload_maintenance.py").read_text(encoding="utf-8")

    assert 'DiscountRedemption.status.in_(("pending", "approved", "rejected"))' in user
    assert 'continue_full_price_redemption_id' in user
    assert 'cancel_discount_redemption_id' in user
    assert '🎁 با تأیید این رزرو، تأیید می‌کنید که خودتان یکی از شرکت‌کنندگان هستید' in user
    assert 'if kind == "personal"' in admin and 'recipient_telegram_id == recipient_id' in admin
    assert 'callback_data="admin:pending_payments:page:0"' in keyboard
    assert 'callback_data="admin:discount:requests:page:0"' in keyboard
    assert 'receipt_uploaded_at' in model and 'receipt_uploaded_at TIMESTAMP NULL' in migration
    assert 'RECEIPT_RETENTION_DAYS=30' in (root / ".env.example").read_text(encoding="utf-8")
    assert 'Payment.booking.has(Booking.status == RegistrationStatus.PENDING_VERIFICATION)' in cleanup
    assert 'await session.commit()\n                # Only announce/reconcile after the state transition actually commits.' in cleanup
    assert 'DiscountCodeEvent.event_id.in_(event_ids)' in admin


def test_receipt_cleanup_recovers_stale_pending_seat_if_prior_run_cleared_payload_but_crashed(monkeypatch, tmp_path):
    """A cleanup retry still releases seats when receipt columns were already cleared."""
    from app.config import settings
    from app.db.models import Booking, Event, User

    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))
    monkeypatch.setattr(settings, "receipt_retention_days", 30)
    now = datetime(2026, 10, 11, 12, 0, 0)
    owner = SimpleNamespace(id=5, telegram_id=555124)
    event = SimpleNamespace(id=8, volume=22, title="Recovery", questions_pdf_path=None)
    booking = SimpleNamespace(
        id=18, event_id=8, booked_by_user_id=5, status=RegistrationStatus.PENDING_VERIFICATION,
        cancelled_at=None, expires_at=None,
    )
    payment = SimpleNamespace(
        id=28, booking_id=18, booking=booking, status=PaymentStatus.PENDING,
        receipt_uploaded_at=now - timedelta(days=31), receipt_file=None,
        receipt_file_name=None, receipt_text=None, reviewed_at=None, reviewed_by=None,
    )
    first = _FakeSession(execute_results=[_FakeResult(values=[payment])])
    release = _FakeSession(
        execute_results=[_FakeResult(scalar=payment)],
        get_values={
            (Booking.__name__, booking.id): booking,
            (Event.__name__, event.id): event,
            (User.__name__, owner.id): owner,
        },
    )
    deleted_count = asyncio.run(cleanup_expired_receipts_once(
        session_factory=_factory_for([first, release]), now=now
    ))
    assert deleted_count == 0  # payload was cleared by a prior interrupted run
    assert first.rollbacks == 1
    assert payment.status == PaymentStatus.REJECTED
    assert booking.status == RegistrationStatus.REJECTED
    assert booking.expires_at is None
    assert release.commits == 1
