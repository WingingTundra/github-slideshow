"""Targeted V75 regression checks for UI and operational polish."""
from pathlib import Path
import re

from app.services.pricing import BASE_OPTION, booking_option_detail_label, panel_price_label
from app.services.app_settings import validate_admin_setting_value

ROOT = Path(__file__).resolve().parents[1]


def source(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_website_setting_accepts_https_and_can_be_cleared_by_admin_flow():
    assert validate_admin_setting_value("community_website_url", "https://panelflow.example/") == "https://panelflow.example/"
    assert "community_website_url" in source("app/services/app_settings.py")
    admin = source("app/bot/handlers/admin.py")
    assert 'field == "community_website_url" and raw_link in {"—", "-", ""}' in admin
    assert "https://..." in admin


def test_admin_card_settings_show_full_number_without_changing_access_controls():
    admin = source("app/bot/handlers/admin.py")
    keyboards = source("app/bot/keyboards.py")
    settings_text = admin.split("def _admin_settings_text(", 1)[1].split("async def _show_admin_settings", 1)[0]
    settings_keyboard = keyboards.split("def admin_settings_keyboard(", 1)[1].split("def admin_settings_hub_keyboard", 1)[0]
    assert "_full_card(values.get(\"payment_card_number\", \"\"))" in settings_text
    assert "reveal_card" not in settings_text
    assert "_full_card" not in settings_keyboard
    assert "community_website_url" in settings_keyboard


def test_admin_launchpad_has_two_prominent_top_actions_and_no_draft_recovery_option():
    keyboards = source("app/bot/keyboards.py")
    menu = keyboards.split("def admin_menu(", 1)[1].split("def admin_content_hub_keyboard", 1)[0]
    rows = [line.strip() for line in menu.splitlines() if "InlineKeyboardButton(text=" in line]
    assert rows[0].startswith('[InlineKeyboardButton(text="➕ ایجاد پنل جدید"')
    assert rows[1].startswith('[InlineKeyboardButton(text="📋 مدیریت پنل‌ها"')
    assert 'callback_data="admin:settings:hub"' in menu
    assert "admin:draft:discard" not in menu and "بازیابی پیش‌نویس" not in menu
    assert 'callback_data="admin:content:hub"' in menu
    assert 'callback_data="admin:reports:hub"' in menu


def test_reply_keyboard_is_opt_in_state_guarded_and_contact_share_is_minimal():
    user = source("app/bot/handlers/user.py")
    keyboards = source("app/bot/keyboards.py")
    reply_menu = source("app/bot/handlers/reply_menu.py")
    limiter = source("app/bot/rate_limiting.py")
    assert '@router.message(Command("quickmenu"))' in user
    assert '@router.message(Command("hidekeyboard"))' in user
    contact_keyboard = keyboards.split("if include_contact:", 1)[1].split("rows = [", 1)[0]
    assert 'KeyboardButton(text="📱 ارسال شمارهٔ خودم", request_contact=True)' in contact_keyboard
    assert "one_time_keyboard=True" in contact_keyboard
    assert "if current_state:" in reply_menu and "await state.clear()" not in reply_menu
    assert "if text and text.split(maxsplit=1)[0]" in limiter
    assert "text.split(maxsplit=1)[0].split('@')[0].lower()" in limiter
    assert "از منوی ثابت پایین برای دسترسی سریع" not in user


def test_panel_price_copy_only_mentions_cafe_when_alternative_is_valid():
    assert panel_price_label(80_000, None) == "80,000 تومان"
    assert panel_price_label(80_000, 0) == "80,000 تومان"
    assert "کافه" not in booking_option_detail_label(BASE_OPTION, base_price=80_000, alternative_price=None)
    assert "کافه" in panel_price_label(80_000, 140_000)
    assert "کافه" in booking_option_detail_label(BASE_OPTION, base_price=80_000, alternative_price=140_000)


def test_preview_single_page_history_and_payment_copy_are_polished():
    user = source("app/bot/handlers/user.py")
    admin = source("app/bot/handlers/admin.py")
    keyboards = source("app/bot/keyboards.py")
    compose = source("docker-compose.yml")
    assert "if page_count > 1 else f\"<i>{_fa_digits(total)} پنل</i>\\n\\n\"" in user
    assert 'مرحلهٔ ۲ از ۳ – بررسی و تأیید ثبت‌نام' in user
    assert "برای اصلاح اطلاعات، ویرایش را بزنید" not in user
    assert "volume_label(volume)" in admin and 'panel_detail_line("زبان پنل"' in admin and 'preview_text = "\\n".join(lines)' in admin
    confirm_keyboard = keyboards.split("def booking_confirmation_keyboard(", 1)[1].split("def booking_pricing_keyboard", 1)[0]
    receipt_keyboard = keyboards.split("def receipt_upload_keyboard(", 1)[1].split("def", 1)[0]
    assert "ویرایش" not in confirm_keyboard
    assert 'text="کپی شماره کارت"' in receipt_keyboard
    assert 'text="❌ لغو پرداخت"' not in receipt_keyboard
    assert "receipt_cancel_reply_keyboard" in keyboards
    assert 'KeyboardButton(text="❌ لغو ارسال رسید")' in keyboards
    api_healthcheck = compose.split("  api:", 1)[1].split("  backup:", 1)[0]
    assert "/health/ready" in api_healthcheck and "/health/db" not in api_healthcheck
    assert "interval: 60s" in api_healthcheck


def test_my_bookings_excludes_cancelled_attempts_and_audit_view_omits_verbose_json():
    user = source("app/bot/handlers/user.py")
    admin = source("app/bot/handlers/admin.py")
    bookings = user.split("async def render_my_bookings(", 1)[1].split("@router.callback_query(F.data == \"user:bookings\")", 1)[0]
    audit = admin.split("async def admin_audit_log(", 1)[1].split("async def admin_audit_detail(", 1)[0]
    audit_detail = admin.split("async def admin_audit_detail(", 1)[1].split("@router.callback_query(F.data == \"admin:stats\")", 1)[0]
    assert "RegistrationStatus.CANCELLED" not in bookings.split("current_statuses = (", 1)[1].split(")", 1)[0]
    assert "Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED))" in bookings
    assert "action.details" not in audit
    assert 'callback_data=f"admin:audit:detail:{int(action.id)}:{page}"' in audit
    assert "action.details" in audit_detail and "json.loads(details)" in audit_detail
    assert 'callback_data="admin:reports:hub"' in source("app/bot/keyboards.py")


def test_one_time_settings_migration_applies_requested_links_without_touching_card_number():
    migration = source("migrations/032_v75_requested_bot_settings.sql")
    assert "https://t.me/+KKqbMvF-vI81Zjg0" in migration
    assert "https://t.me/PanelFlowFestival" in migration
    assert "https://www.instagram.com/panelflowfestival?rpxt=YjhrbzY5b2N3enFl" in migration
    assert "سیدسینا ضیائیی" in migration
    assert "community_website_url" in migration and "ON CONFLICT (key) DO NOTHING" in migration
    sql_only = re.sub(r"--.*$", "", migration, flags=re.MULTILINE)
    assert "payment_card_number" not in sql_only
    assert "DELETE FROM" not in migration.upper() and "DROP TABLE" not in migration.upper()
