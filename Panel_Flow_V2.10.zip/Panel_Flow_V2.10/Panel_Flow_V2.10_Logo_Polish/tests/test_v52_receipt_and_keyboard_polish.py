from __future__ import annotations

import ast
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _function(name: str) -> ast.FunctionDef:
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)


def _function_source(path: str, name: str) -> str:
    source = (ROOT / path).read_text(encoding="utf-8")
    tree = ast.parse(source)
    node = next(
        item for item in tree.body
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name
    )
    return ast.get_source_segment(source, node) or ""


def test_title_isolated_from_persian_direction_so_question_mark_stays_with_english_title():
    node = _function("_ltr_display")
    from app.display_utils import volume_label
    namespace = {"escape": escape, "str": str, "volume_label": volume_label}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), "user.py", "exec"), namespace)
    render = namespace["_ltr_display"]
    value = render("Volume 6 – How to make love?")
    assert value == "\u2066Volume 6 – How to make love?\u2069"
    assert render("V6 – A & B?") == "\u2066V6 – A &amp; B?\u2069"


def test_booking_summary_uses_lightweight_section_icons_and_isolates_mixed_direction_values():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    summary = source.split("async def show_booking_summary", 1)[1].split('@router.callback_query(F.data == "booking:discount:enter")', 1)[0]
    assert "🎟 <b>پنل:</b>" in summary
    assert 'panel_detail_line("زبان پنل",' in summary
    assert 'panel_detail_line("روز و تاریخ",' in summary
    assert 'panel_detail_line("ساعت",' in summary
    assert "👥 <b>شرکت‌کنندگان</b>" in summary
    assert 'panel_detail_line("شماره تماس ثبت‌کننده",' in summary
    assert 'panel_detail_line("تعداد نفرات",' in summary
    assert 'panel_detail_line("هزینه هر نفر",' in summary
    assert "💳 <b>مبلغ قابل پرداخت:" in summary
    assert 'panel_label = _booking_summary_panel_label(event)' in summary
    assert 'new_message=new_message' in summary


def test_start_during_receipt_preserves_booking_and_shows_booking_scoped_cancel_confirmation():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    start = source.split("async def start", 1)[1].split('@router.message(Command("help"))', 1)[0]
    assert "prior_state == BookingStates.waiting_receipt.state" in start
    assert "_show_receipt_cancel_confirmation(message, state, booking_id)" in start
    assert "برای ادامه، عکس، فایل یا متن رسید" not in start
    assert "دستور /start رزرو را لغو نمی‌کند" not in start


def test_help_and_admin_commands_do_not_interrupt_receipt_collection():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    help_handler = _function_source("app/bot/handlers/user.py", "help_command")
    admin_handler = _function_source("app/bot/handlers/admin.py", "admin_cmd")
    receipt_handler = _function_source("app/bot/handlers/user.py", "receipt_text_message")
    assert "BookingStates.waiting_receipt.state" in help_handler
    assert 'get("booking_id")' in help_handler
    assert "برای لغو همین رزرو، /cancel را بزنید" in help_handler
    # Admin navigation uses the shared guard; that guard explicitly protects receipt FSM.
    guard = admin.split("async def _request_admin_navigation_confirmation", 1)[1].split("\n\n@router.message(Command(\"admin\"))", 1)[0]
    assert "BookingStates.waiting_receipt.state" in guard
    assert 'data.get("booking_id")' in guard
    assert "برای لغو همان رزرو /cancel را بزنید" in guard
    assert "if await _request_admin_navigation_confirmation(message, state):" in admin_handler
    assert admin_handler.index("_request_admin_navigation_confirmation") < admin_handler.index('await message.answer("<b>داشبورد مدیریتی Panel Flow</b>')
    assert 'if text.startswith("/")' in receipt_handler
    assert "await _save_receipt(message, state, receipt_text=text)" in receipt_handler
    assert "from app.bot.states import" in admin and "BookingStates" in admin.split("from app.bot.states import", 1)[1].splitlines()[0]
    assert "دستور /start رزرو را لغو نمی‌کند" not in user


def test_catalogue_keyboard_remains_inline_on_same_message_and_has_no_trailing_blank_paragraph():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    picker = user.split("async def show_events", 1)[1].split('@router.callback_query(F.data == "user:events")', 1)[0]
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert 'text += "\\n\\n".join(event_blocks)' in picker
    assert "await message_or_query.message.edit_text(limit_telegram_html(text), reply_markup=keyboard" in picker
    assert "await message_or_query.answer(limit_telegram_html(text), reply_markup=keyboard" in picker
    assert "from aiogram.types import CopyTextButton, InlineKeyboardMarkup, InlineKeyboardButton" in keyboards
    available_keyboard = keyboards.split("def available_events_keyboard", 1)[1].split("def duplicate_registration_keyboard", 1)[0]
    assert "return InlineKeyboardMarkup(inline_keyboard=rows)" in available_keyboard
    assert 'callback_data=f"event:open:{event.id}:{max(0, int(page))}"' in available_keyboard
    assert "rows.append([" in available_keyboard
    assert "if len(row) == 2" not in available_keyboard


def test_booking_summary_moves_only_terminal_question_mark_before_ltr_title_for_rtl_layout():
    from types import SimpleNamespace

    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in {"_ltr_display", "_booking_summary_panel_label"}]
    from app.display_utils import volume_label
    namespace = {"escape": escape, "str": str, "volume_label": volume_label}
    module = ast.Module(body=functions, type_ignores=[])
    exec(compile(ast.fix_missing_locations(module), "user.py", "exec"), namespace)
    render = namespace["_booking_summary_panel_label"]

    question_title = render(SimpleNamespace(volume=6, title="How to make love?"))
    assert question_title == f"?\u2066V6 – How to make love\u2069"
    ordinary_title = render(SimpleNamespace(volume=4, title="Opportunity"))
    assert ordinary_title == "\u2066V4 – Opportunity\u2069"


def test_available_panel_keyboard_uses_one_full_width_row_per_panel():
    from types import SimpleNamespace

    source = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    node = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == "available_events_keyboard")

    class FakeButton:
        def __init__(self, text, callback_data):
            self.text = text
            self.callback_data = callback_data

    class FakeMarkup:
        def __init__(self, inline_keyboard):
            self.inline_keyboard = inline_keyboard

    from app.display_utils import truncate_display_text, volume_label
    namespace = {"InlineKeyboardButton": FakeButton, "InlineKeyboardMarkup": FakeMarkup, "str": str, "max": max, "int": int, "truncate_display_text": truncate_display_text, "volume_label": volume_label}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), "keyboards.py", "exec"), namespace)
    panels = [SimpleNamespace(id=i, volume=i, title=f"Panel {i}") for i in range(1, 8)]
    markup = namespace["available_events_keyboard"](panels, page=0)

    assert len(markup.inline_keyboard) == 8  # Seven panels plus Main Menu.
    assert all(len(row) == 1 for row in markup.inline_keyboard)
    assert [row[0].callback_data for row in markup.inline_keyboard[:-1]] == [f"event:open:{i}:0" for i in range(1, 8)]
    assert markup.inline_keyboard[-1][0].callback_data == "user:home"
