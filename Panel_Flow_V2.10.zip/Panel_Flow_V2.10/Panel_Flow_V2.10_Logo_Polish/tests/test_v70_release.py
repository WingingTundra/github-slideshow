from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.bot.admin_notifications import format_receipt_stage_cancel_notice
from app.db.models import Base, Booking, Event, RegistrationStatus, User

ROOT = Path(__file__).resolve().parents[1]


def test_receipt_cancel_notice_contains_clickable_numeric_id_and_username():
    text = format_receipt_stage_cancel_notice(
        event_label="V20 — Masks & Manuals",
        booking_id=2,
        participant_count=1,
        telegram_id=1168013099,
        username="Sina_Test",
    )
    assert "ℹ️ <b>کاربر هنگام ارسال رسید، رزرو را با /cancel لغو کرد.</b>" in text
    assert "پنل: V20 — Masks &amp; Manuals" in text
    assert 'href="tg://user?id=1168013099">1168013099</a>' in text
    assert 'href="https://t.me/Sina_Test">@Sina_Test</a>' in text
    assert "رزرو: #2 | تعداد نفرات: 1" in text


def test_receipt_cancel_notice_handles_missing_or_malformed_username_safely():
    for username in (None, "", "@bad name", 'evil"><b>injected'):
        text = format_receipt_stage_cancel_notice(
            event_label="Panel <script>", booking_id=9, participant_count=2,
            telegram_id=123456, username=username,
        )
        assert 'href="tg://user?id=123456">123456</a>' in text
        assert "Panel &lt;script&gt;" in text
        assert 'href="https://t.me/' not in text
        assert "<script>" not in text


def test_receipt_cancel_notice_is_wired_to_receipt_stage_cancel_handler():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert "format_receipt_stage_cancel_notice(" in source
    cancel = source[source.index("async def _cancel_receipt_stage_booking"):source.index("async def cancel_receipt_button")]
    assert "username=telegram_user.username" in cancel
    assert "telegram_id=int(telegram_user.id)" in cancel
    assert "settings.super_admin_id_set - {int(telegram_user.id)}" in cancel
    assert "notify_waitlist_capacity_available(bot, event_id)" in cancel


def test_models_reject_invalid_capacity_and_booking_participant_count():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    try:
        with Session(engine) as session:
            owner = User(telegram_id=123456789, first_name="Test")
            session.add(owner)
            session.flush()
            bad_event = Event(
                volume="V70", title="Invalid capacity", venue="Test",
                capacity=-1, price_per_person=Decimal("1000"),
            )
            session.add(bad_event)
            with pytest.raises(IntegrityError):
                session.flush()
            session.rollback()

        with Session(engine) as session:
            owner = User(telegram_id=123456790, first_name="Test")
            event = Event(
                volume="V70", title="Capacity test", venue="Test",
                capacity=10, price_per_person=Decimal("1000"),
            )
            session.add_all([owner, event])
            session.flush()
            session.add(Booking(
                event_id=event.id, booked_by_user_id=owner.id, participant_count=4,
                total_amount=Decimal("4000"), status=RegistrationStatus.CONFIRMED,
            ))
            with pytest.raises(IntegrityError):
                session.flush()
    finally:
        engine.dispose()


def test_v70_migration_adds_non_destructive_database_guards_for_legacy_rows():
    migration = (ROOT / "migrations/029_v70_database_invariants.sql").read_text(encoding="utf-8")
    assert "panel_flow_guard_event_capacity" in migration
    assert "panel_flow_guard_booking_participant_count" in migration
    assert "BEFORE INSERT OR UPDATE OF capacity" in migration
    assert "BEFORE INSERT OR UPDATE OF participant_count" in migration
    assert "unrelated status/payment" in migration
    assert "uq_bookings_event" not in migration
    assert "repeat registration is an" in migration


def test_public_events_api_does_not_expose_exact_reserved_participant_count():
    source = (ROOT / "app/services/public_events.py").read_text(encoding="utf-8")
    assert '"reserved_participants"' not in source
    assert '"registration_open": registration_is_open(event)' in source
    assert '"status": display_status(event, used).value' in source


def test_admin_audit_view_and_financial_reconciliation_are_wired_and_admin_only():
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:audit:page:0"' in keyboard
    assert 'callback_data=f"admin:event:reconciliation:{event_id}"' in keyboard
    assert 'async def admin_audit_log(' in admin
    assert 'async def export_financial_reconciliation(' in admin
    assert 'action="financial_reconciliation_export"' in admin
    assert 'if not await is_admin(c.from_user.id)' in admin


def test_release_ci_requires_full_runtime_and_postgres_integration_suite():
    workflow = (ROOT / ".github/workflows/qa.yml").read_text(encoding="utf-8")
    assert "python-version: '3.12'" in workflow
    assert "postgres:17" in workflow
    assert "PANEL_FLOW_TEST_DATABASE_URL" in workflow
    assert "pytest -q -rs" in workflow
    assert "scripts/test-backup-restore.sh" in workflow


def test_receipt_cancel_admin_notice_identifies_inline_button_separately_from_command():
    button_text = format_receipt_stage_cancel_notice(
        event_label="Panel", booking_id=4, participant_count=1,
        telegram_id=123456789, cancellation_method="button",
    )
    command_text = format_receipt_stage_cancel_notice(
        event_label="Panel", booking_id=4, participant_count=1,
        telegram_id=123456789, cancellation_method="command",
    )
    assert "با دکمهٔ انصراف لغو کرد" in button_text
    assert "با /cancel لغو کرد" in command_text
