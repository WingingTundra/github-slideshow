from __future__ import annotations

import asyncio
from pathlib import Path
import pytest

from app.services.rate_limiter import InMemoryLimiter

ROOT = Path(__file__).resolve().parents[1]


def test_v66_rate_limiter_multiplier_scales_refill():
    clock_time = 1000.0
    limiter = InMemoryLimiter(clock=lambda: clock_time)

    # Base burst=4, multiplier=3 -> multiplied burst should be 12
    async def scenario():
        # First call initializes bucket with multiplied burst (12) and takes 1
        ok, _ = await limiter.allow(
            user_id=999, kind="msg", ceiling=30, window=12, burst=4, refill=1.0, multiplier=3
        )
        assert ok is True
        bucket = limiter._state[(999, "msg")]
        # Tokens started at 12, took 1 -> 11
        assert bucket.tokens == 11.0

        # Non-admin with multiplier=1
        ok_reg, _ = await limiter.allow(
            user_id=888, kind="msg", ceiling=12, window=12, burst=4, refill=1.0, multiplier=1
        )
        assert ok_reg is True
        bucket_reg = limiter._state[(888, "msg")]
        # Tokens started at 4, took 1 -> 3
        assert bucket_reg.tokens == 3.0

    asyncio.run(scenario())


def test_v67_backup_script_has_valid_credentials_checksums_and_release_marker():
    backup_sh = (ROOT / "scripts/backup.sh").read_text(encoding="utf-8")
    assert "release=V97" in backup_sh
    assert "release=V66" not in backup_sh
    assert "PGPASSWORD=\"$POSTGRES_PASSWORD\"" in backup_sh
    assert "sha256sum database.dump uploads.tar.gz > SHA256SUMS" in backup_sh


def test_v66_keyboards_have_no_unsupported_style_kwargs():
    keyboards_py = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert 'style="success"' not in keyboards_py
    assert 'style="danger"' not in keyboards_py
    assert 'style=' not in keyboards_py


def test_v66_referral_uses_deterministic_lock_ordering():
    referrals_py = (ROOT / "app/services/referrals.py").read_text(encoding="utf-8")
    assert "sorted([int(invitee_telegram_id), referrer_telegram_id])" in referrals_py
    assert "order_by(User.telegram_id.asc())" in referrals_py


def test_v66_api_health_db_status_code_handling():
    api_py = (ROOT / "app/api.py").read_text(encoding="utf-8")
    assert "response: Response" in api_py
    assert "status.HTTP_503_SERVICE_UNAVAILABLE" in api_py


def test_v66_admin_settings_has_answer_fallback():
    admin_py = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert 'hasattr(target, "edit_text")' in admin_py
    assert 'await target.answer(' in admin_py
