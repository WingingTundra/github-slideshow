"""V40 community ledger integration tests using real SQLAlchemy SQLite storage.

SQLite is used here because the test environment does not provide PostgreSQL.
The async-session adapter only adapts awaitable method calls; SQL statements,
constraints, aggregation, and savepoints are executed by SQLAlchemy's real ORM.
"""
from decimal import Decimal

import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session

from app.db.models import (
    AppSetting, Base, Booking, Event, EventStatus, Payment, PaymentStatus,
    RegistrationStatus, User, UserRole, XPAward,
)
from app.services.community import (
    admin_leaderboard_rows, award_once, leaderboard_rows, public_leaderboard_position,
    paid_panel_count, record_paid_panel_award, reverse_paid_panel_award,
    set_leaderboard_enabled, set_leaderboard_opt_in, total_xp,
)


class _AsyncNested:
    def __init__(self, sync_context):
        self.sync_context = sync_context

    async def __aenter__(self):
        return self.sync_context.__enter__()

    async def __aexit__(self, exc_type, exc, tb):
        return self.sync_context.__exit__(exc_type, exc, tb)


class AsyncSessionAdapter:
    def __init__(self, session: Session):
        self.sync = session

    async def execute(self, *args, **kwargs):
        return self.sync.execute(*args, **kwargs)

    async def scalar(self, *args, **kwargs):
        return self.sync.scalar(*args, **kwargs)

    async def get(self, *args, **kwargs):
        return self.sync.get(*args, **kwargs)

    async def flush(self):
        self.sync.flush()

    async def commit(self):
        self.sync.commit()

    async def rollback(self):
        self.sync.rollback()

    def add(self, row):
        self.sync.add(row)

    def begin_nested(self):
        return _AsyncNested(self.sync.begin_nested())


def _database():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, Session(engine)


def _user(session, telegram_id, first, last):
    row = User(telegram_id=telegram_id, first_name=first, last_name=last,
               display_name=f"{first} {last}", role=UserRole.PARTICIPANT)
    session.add(row)
    session.flush()
    return row


def _event(session, owner, *, volume, title="Same title"):
    row = Event(
        volume=volume, title=title, event_day_label="Thursday", event_date_label="15 October 2026",
        start_time_label="16:30", end_time_label="18:30", venue="Venue", capacity=20,
        price_per_person=Decimal("100000"), status=EventStatus.PUBLISHED,
        registration_open=True, waitlist_enabled=True, host_id=owner.id, host_name="Host",
    )
    session.add(row)
    session.flush()
    return row


def _booking_payment(session, user, event, *, amount=100_000, status=PaymentStatus.APPROVED,
                     booking_status=RegistrationStatus.CONFIRMED, attendees=1):
    booking = Booking(event_id=event.id, booked_by_user_id=user.id, participant_count=attendees,
                      total_amount=Decimal(str(amount)), status=booking_status)
    session.add(booking)
    session.flush()
    payment = Payment(booking_id=booking.id, amount=Decimal(str(amount)), status=status)
    session.add(payment)
    session.flush()
    return booking, payment


def test_paid_panel_award_is_once_per_account_and_database_event_not_per_booking_or_attendee():
    engine, raw = _database()
    try:
        owner = _user(raw, 12001, "Ada", "Morgan")
        event1 = _event(raw, owner, volume="Volume 7")
        event2 = _event(raw, owner, volume="Volume 7")  # same label/title, different event ID
        b1, p1 = _booking_payment(raw, owner, event1, attendees=3)
        b2, p2 = _booking_payment(raw, owner, event1, attendees=1)
        b3, p3 = _booking_payment(raw, owner, event2, attendees=2)
        session = AsyncSessionAdapter(raw)
        import asyncio
        assert asyncio.run(record_paid_panel_award(session, b1, p1)) is True
        assert asyncio.run(record_paid_panel_award(session, b2, p2)) is False
        assert asyncio.run(record_paid_panel_award(session, b3, p3)) is True
        raw.commit()
        assert asyncio.run(paid_panel_count(session, owner.telegram_id)) == 2
        assert asyncio.run(total_xp(session, owner.telegram_id)) == 20
        assert raw.scalar(select(func.count()).select_from(XPAward).where(XPAward.telegram_id == owner.telegram_id)) == 2
    finally:
        raw.close()
        engine.dispose()


def test_pending_rejected_unpaid_and_nonconfirmed_reservations_never_get_paid_panel_xp():
    import asyncio
    engine, raw = _database()
    try:
        owner = _user(raw, 12002, "Taylor", "Test")
        event1 = _event(raw, owner, volume="1")
        event2 = _event(raw, owner, volume="2")
        event3 = _event(raw, owner, volume="3")
        cases = [
            _booking_payment(raw, owner, event1, status=PaymentStatus.PENDING),
            _booking_payment(raw, owner, event2, status=PaymentStatus.REJECTED),
            _booking_payment(raw, owner, event3, amount=0),
        ]
        session = AsyncSessionAdapter(raw)
        for booking, payment in cases:
            assert not asyncio.run(record_paid_panel_award(session, booking, payment))
        raw.commit()
        assert asyncio.run(total_xp(session, owner.telegram_id)) == 0
        assert asyncio.run(paid_panel_count(session, owner.telegram_id)) == 0
    finally:
        raw.close()
        engine.dispose()


def test_leaderboard_orders_completed_attendance_before_xp_and_honors_global_and_user_privacy():
    import asyncio
    engine, raw = _database()
    try:
        top = _user(raw, 12011, "Alex", "Morgan")
        high_xp = _user(raw, 12012, "Sara", "Example")
        next_user = _user(raw, 12013, "Jamie", "Lee")
        s = AsyncSessionAdapter(raw)
        # Public rankings now default off; enable them explicitly for the ranking assertions.
        asyncio.run(set_leaderboard_enabled(s, True))
        # Completed confirmed registrations beat XP-only accounts and remain
        # eligible even though the new score is independent of paid_panel awards.
        for index in range(2):
            event = _event(raw, top, volume=str(index + 1), title="Repeated label")
            event.status = EventStatus.COMPLETED
            booking, payment = _booking_payment(raw, top, event)
            assert asyncio.run(record_paid_panel_award(s, booking, payment))
        event = _event(raw, high_xp, volume="2", title="Repeated label")
        event.status = EventStatus.COMPLETED
        booking, payment = _booking_payment(raw, high_xp, event)
        assert asyncio.run(record_paid_panel_award(s, booking, payment))
        assert asyncio.run(award_once(s, telegram_id=high_xp.telegram_id, points=300,
                                      award_type="test_bonus", award_key="large-test-xp"))
        assert asyncio.run(award_once(s, telegram_id=next_user.telegram_id, points=1,
                                      award_type="test_bonus", award_key="small-test-xp"))
        raw.commit()

        rows = asyncio.run(leaderboard_rows(s))
        assert [row["name"] for row in rows[:2]] == ["Alex Morgan", "Sara Example"]
        assert rows[0]["panels"] == 2 and rows[1]["panels"] == 1
        assert rows[1]["xp"] > rows[0]["xp"]
        assert all("@" not in row["name"] for row in rows)
        assert all(set(row) == {"name", "panels", "xp"} for row in rows)

        asyncio.run(set_leaderboard_opt_in(s, top.telegram_id, False))
        raw.commit()
        opted_out = asyncio.run(leaderboard_rows(s))
        assert opted_out[0]["name"] == "••••••••"
        assert opted_out[0]["panels"] == 2 and opted_out[0]["xp"] == rows[0]["xp"]
        # Hiding a name must not remove the participant or promote lower-ranked users.
        assert opted_out[1]["name"] == "Sara Example"
        position = asyncio.run(public_leaderboard_position(s, top.telegram_id))
        assert position == {"position": 1, "total": 3}
        # The rest of the public ranking remains in the same order.
        assert [row["name"] for row in opted_out[1:]] == [row["name"] for row in rows[1:]]
        asyncio.run(set_leaderboard_opt_in(s, top.telegram_id, True))
        raw.commit()
        restored = asyncio.run(leaderboard_rows(s))
        assert restored[0]["name"] == "Alex Morgan"
        assert restored[1:3] == rows[1:3]
        asyncio.run(set_leaderboard_opt_in(s, top.telegram_id, False))
        raw.commit()

        asyncio.run(set_leaderboard_enabled(s, False))
        raw.commit()
        assert asyncio.run(leaderboard_rows(s)) == []
        assert asyncio.run(total_xp(s, top.telegram_id)) == 20  # private Passport history remains
        asyncio.run(set_leaderboard_enabled(s, True))
        raw.commit()
        assert asyncio.run(leaderboard_rows(s))  # re-enable is reversible
    finally:
        raw.close()
        engine.dispose()


def test_refund_reversal_is_append_only_and_removes_net_paid_panel_credit_once():
    import asyncio
    engine, raw = _database()
    try:
        owner = _user(raw, 12021, "Jordan", "Refund")
        event = _event(raw, owner, volume="41")
        booking, payment = _booking_payment(raw, owner, event)
        s = AsyncSessionAdapter(raw)
        assert asyncio.run(record_paid_panel_award(s, booking, payment))
        raw.commit()
        assert asyncio.run(reverse_paid_panel_award(s, owner.telegram_id, event.id, "refunded"))
        assert not asyncio.run(reverse_paid_panel_award(s, owner.telegram_id, event.id, "duplicate retry"))
        raw.commit()
        assert asyncio.run(paid_panel_count(s, owner.telegram_id)) == 0
        assert asyncio.run(total_xp(s, owner.telegram_id)) == 0
        assert raw.scalar(select(func.count()).select_from(XPAward).where(XPAward.telegram_id == owner.telegram_id)) == 2
    finally:
        raw.close()
        engine.dispose()


def test_challenge_schema_and_migration_preserve_awards_without_submission_foreign_keys():
    from pathlib import Path
    from app.db.models import ChallengeSubmission, CommunityChallenge, CommunityProfile, AchievementUnlock, WrappedReport

    assert {"community_challenges", "challenge_submissions", "xp_awards", "community_profiles",
            "achievement_unlocks", "wrapped_reports"}.issubset(Base.metadata.tables)
    assert any(c.name == "uq_challenge_submission_user" for c in ChallengeSubmission.__table__.constraints)
    award_fks = list(Base.metadata.tables["xp_awards"].foreign_keys)
    assert award_fks == []  # cleared source rows cannot erase the durable ledger
    migration = (Path(__file__).resolve().parents[1] / "migrations" / "018_community_challenges_xp.sql").read_text()
    for expected in ("ON CONFLICT (award_key) DO NOTHING", "uq_challenge_submission_user",
                     "community_challenge_publish_lock", "results_finalized_at"):
        assert expected in migration


def test_wrapped_uses_retained_awards_after_challenge_submission_cleanup_and_nets_refunds():
    import asyncio
    from datetime import datetime
    from app.db.models import AchievementUnlock, CommunityProfile, ChallengeSubmission
    from app.services.community import make_wrapped_text

    engine, raw = _database()
    try:
        user = _user(raw, 12031, "Wrapped", "Member")
        event = _event(raw, user, volume="55", title="Wrapped test")
        event.language = "English"
        event_kept = _event(raw, user, volume="56", title="Still booked")
        event_kept.language = "English"
        raw.add(XPAward(telegram_id=user.telegram_id, points=10, award_type="paid_panel",
                        award_key=f"paid-panel:{user.telegram_id}:{event.id}", event_id=event.id,
                        created_at=datetime(2026, 4, 10)))
        raw.add(XPAward(telegram_id=user.telegram_id, points=10, award_type="paid_panel",
                        award_key=f"paid-panel:{user.telegram_id}:{event_kept.id}", event_id=event_kept.id,
                        created_at=datetime(2026, 7, 10)))
        raw.add(XPAward(telegram_id=user.telegram_id, points=2, award_type="challenge_participation",
                        award_key="challenge-participation:501:12031", challenge_id=501,
                        created_at=datetime(2026, 5, 10)))
        raw.add(XPAward(telegram_id=user.telegram_id, points=2, award_type="knowledge_correct",
                        award_key="challenge-correct:501:12031", challenge_id=501,
                        created_at=datetime(2026, 5, 11)))
        raw.add(XPAward(telegram_id=user.telegram_id, points=-10, award_type="paid_panel_reversal",
                        award_key=f"paid-panel-reversal:{user.telegram_id}:{event.id}", event_id=event.id,
                        created_at=datetime(2027, 1, 5)))
        raw.add(AchievementUnlock(telegram_id=user.telegram_id, achievement_key="test_badge",
                                  title="Test Badge", unlocked_at=datetime(2026, 6, 1)))
        # Raw submissions can disappear on finalized challenge cleanup; the ledger persists.
        challenge_submission = ChallengeSubmission(challenge_id=501, telegram_id=user.telegram_id,
                                                   answer_text="raw answer", judging_status="correct")
        raw.add(challenge_submission)
        raw.commit()
        raw.delete(challenge_submission)
        raw.commit()
        report = asyncio.run(make_wrapped_text(AsyncSessionAdapter(raw), user.telegram_id, 2026))
        assert "تعداد پنل‌های شرکت‌شده: <b>1</b>" in report  # refunded/reversed event is excluded
        assert "پاسخ‌های چالش: <b>1</b>" in report
        assert "پاسخ‌های درست: <b>1</b>" in report
        assert "Test Badge" in report
        assert "English" in report
    finally:
        raw.close()
        engine.dispose()


def test_achievement_unlocks_are_unique_and_cover_exact_v40_thresholds():
    import asyncio
    from app.db.models import AchievementUnlock, CommunityProfile
    from app.services.community import unlock_eligible_achievements

    engine, raw = _database()
    try:
        user = _user(raw, 12041, "Milestone", "Member")
        for event_id in range(1, 61):
            event = _event(raw, user, volume=str(event_id), title="Milestone panel")
            event.status = EventStatus.COMPLETED
            raw.add(Booking(event_id=event.id, booked_by_user_id=user.id, participant_count=1,
                            total_amount=Decimal("0"), status=RegistrationStatus.CONFIRMED,
                            registrant_attends=True))
            # Historic XP remains separate from participation eligibility.
            raw.add(XPAward(telegram_id=user.telegram_id, points=10, award_type="paid_panel",
                            award_key=f"milestone-paid-panel:{event_id}", event_id=event.id))
        profile = CommunityProfile(telegram_id=user.telegram_id, challenge_participations=50,
                                   best_streak=10, current_streak=10)
        raw.add(profile)
        raw.commit()
        s = AsyncSessionAdapter(raw)
        new_rows = asyncio.run(unlock_eligible_achievements(s, user.telegram_id))
        raw.commit()
        assert len(new_rows) == 10
        assert asyncio.run(unlock_eligible_achievements(s, user.telegram_id)) == []
        raw.commit()
        keys = set(raw.execute(select(AchievementUnlock.achievement_key).where(
            AchievementUnlock.telegram_id == user.telegram_id)).scalars().all())
        assert keys == {
            "newcomer", "regular", "community_veteran",
            "curious_mind", "quiz_regular", "challenge_veteran", "grandmaster",
            "three_in_a_row", "five_in_a_row", "unstoppable",
        }
    finally:
        raw.close()
        engine.dispose()


def test_v40_migration_parses_and_router_source_contains_authorized_workflows():
    from pathlib import Path
    from app.db.migration_utils import split_sql_statements

    root = Path(__file__).resolve().parents[1]
    migration = root / "migrations" / "018_community_challenges_xp.sql"
    statements = split_sql_statements(migration.read_text(encoding="utf-8"))
    assert len(statements) >= 12
    community = (root / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    for needle in (
        'async def community_leaderboard', 'async def community_passport',
        'async def challenge_submit_answer', 'async def admin_publish_challenge',
        'async def admin_clear_all_execute', 'async def admin_wrapped_generate',
        'if not await _is_admin(c.from_user.id)', 'challenge-participation:',
    ):
        assert needle in community
    assert '@router.message(CommunityStates.waiting_challenge_answer, F.text, ~F.text.startswith("/"))' in community


def test_leaderboard_never_returns_more_than_ten_rows_even_for_larger_requested_limit():
    engine, raw = _database()
    try:
        for i in range(12):
            user = _user(raw, 12100 + i, f"First{i:02d}", f"Last{i:02d}")
            raw.add(XPAward(telegram_id=user.telegram_id, points=10, award_type="paid_panel",
                            award_key=f"top-ten:{i}", event_id=10_000 + i))
        session = AsyncSessionAdapter(raw)
        __import__("asyncio").run(set_leaderboard_enabled(session, True))
        raw.commit()
        rows = __import__("asyncio").run(leaderboard_rows(session, limit=1000))
        assert len(rows) == 10
        assert all(set(row) == {"name", "panels", "xp"} for row in rows)
    finally:
        raw.close()
        engine.dispose()


def test_one_submission_per_user_per_challenge_is_a_real_database_constraint():
    from sqlalchemy.exc import IntegrityError
    from app.db.models import ChallengeSubmission, CommunityChallenge

    engine, raw = _database()
    try:
        challenge = CommunityChallenge(title="Question", prompt="Why?", challenge_type="knowledge",
                                       reference_answer="Private", winner_count=1, status="open",
                                       created_by_telegram_id=991)
        raw.add(challenge)
        raw.commit()
        raw.add(ChallengeSubmission(challenge_id=challenge.id, telegram_id=12121,
                                    answer_text="First answer", judging_status="unmarked"))
        raw.commit()
        raw.add(ChallengeSubmission(challenge_id=challenge.id, telegram_id=12121,
                                    answer_text="Second answer", judging_status="unmarked"))
        with pytest.raises(IntegrityError):
            raw.commit()
        raw.rollback()
        assert raw.scalar(select(func.count()).select_from(ChallengeSubmission).where(
            ChallengeSubmission.challenge_id == challenge.id,
            ChallengeSubmission.telegram_id == 12121,
        )) == 1
    finally:
        raw.close()
        engine.dispose()



def test_v41_public_leaderboard_defaults_to_disabled_and_can_be_enabled_explicitly():
    from app.services.community import leaderboard_enabled
    engine, raw = _database()
    try:
        session = AsyncSessionAdapter(raw)
        assert __import__("asyncio").run(leaderboard_enabled(session)) is False
        __import__("asyncio").run(set_leaderboard_enabled(session, True))
        raw.commit()
        assert __import__("asyncio").run(leaderboard_enabled(session)) is True
        __import__("asyncio").run(set_leaderboard_enabled(session, False))
        raw.commit()
        assert __import__("asyncio").run(leaderboard_enabled(session)) is False
    finally:
        raw.close()
        engine.dispose()



def test_admin_leaderboard_includes_hidden_users_even_when_public_leaderboard_is_disabled():
    import asyncio
    engine, raw = _database()
    try:
        hidden_user = _user(raw, 12991, "Hidden", "Participant")
        session = AsyncSessionAdapter(raw)
        assert asyncio.run(award_once(
            session, telegram_id=hidden_user.telegram_id, points=17,
            award_type="challenge_participation", award_key="test-admin-leaderboard-hidden-user",
        ))
        asyncio.run(set_leaderboard_opt_in(session, hidden_user.telegram_id, False))
        asyncio.run(set_leaderboard_enabled(session, False))
        raw.commit()

        # Public view remains governed by global enablement; personal privacy only masks names.
        assert asyncio.run(leaderboard_rows(session)) == []

        # Admin view intentionally ignores those filters, but clearly marks the opt-out.
        rows = asyncio.run(admin_leaderboard_rows(session, limit=10))
        assert len(rows) == 1
        assert rows[0]["name"] == "Hidden Participant"
        assert rows[0]["telegram_id"] == hidden_user.telegram_id
        assert rows[0]["xp"] == 17
        assert rows[0]["hidden"] is True
    finally:
        raw.close()
        engine.dispose()
