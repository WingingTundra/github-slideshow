from pathlib import Path

from app.bot.content import about_text
from app.db.models import Question

ROOT = Path(__file__).resolve().parents[1]


def test_v41_question_category_migration_supports_existing_databases():
    migration_path = ROOT / "migrations" / "019_v41_question_category_and_privacy_default.sql"
    migration = migration_path.read_text(encoding="utf-8")
    from app.db.migration_utils import split_sql_statements
    assert len(split_sql_statements(migration)) == 3
    assert "ALTER TABLE questions ADD COLUMN IF NOT EXISTS category VARCHAR(100)" in migration
    assert "CREATE TABLE IF NOT EXISTS app_settings" in migration
    assert "ON CONFLICT (key) DO UPDATE SET value = 'false'" in migration
    assert Question.__table__.c.category.nullable is True


def test_v41_public_leaderboard_migration_turns_off_v40_default():
    migration = (ROOT / "migrations" / "019_v41_question_category_and_privacy_default.sql").read_text(encoding="utf-8")
    assert "community_public_leaderboard_enabled" in migration and "false" in migration
    assert "V40 seeded this setting as true by default" in migration
    assert "set it again" in migration or "enable it again" in migration


def test_v41_challenge_answer_cancel_clears_only_answer_fsm_and_fallback_has_cancel_button():
    source = (ROOT / "app" / "bot" / "handlers" / "community.py").read_text(encoding="utf-8")
    block = source.split('@router.callback_query(F.data == "community:challenges")', 1)[1].split(
        '@router.callback_query(F.data.regexp(r"^community:challenges:page:', 1
    )[0]
    assert "state: FSMContext" in block
    assert "CommunityStates.waiting_challenge_answer.state" in block
    assert "await state.clear()" in block
    prompt_block = source.split("async def challenge_submit_start", 1)[1].split(
        "async def challenge_submit_answer", 1
    )[0]
    assert prompt_block.count('callback_data="community:challenges"') >= 2
    assert "except Exception:" in prompt_block


def test_v41_creative_challenge_winner_selection_uses_a_dedicated_fsm_state():
    states = (ROOT / "app" / "bot" / "states.py").read_text(encoding="utf-8")
    source = (ROOT / "app" / "bot" / "handlers" / "community.py").read_text(encoding="utf-8")
    assert "challenge_winner_count = State()" in states
    assert "await state.set_state(CommunityAdminStates.challenge_winner_count)" in source
    handler = source.split("async def admin_challenge_create_winners", 1)[1].split(
        "async def _render_admin_challenges", 1
    )[0]
    assert "CommunityAdminStates.challenge_winner_count.state" in handler
    assert 'data.get("challenge_type") != "creative"' in handler
    assert 'not data.get("challenge_title")' in handler
    assert 'not data.get("challenge_prompt")' in handler


def test_about_copy_matches_the_current_bilingual_wording():
    about = about_text()
    expected = (
        "<b>🧩 ABOUT PANEL FLOW</b>",
        "<b>Who we are</b>",
        "Panel Flow is a community in Mashhad, Iran, bringing people together for regular, structured discussion panels, with room for different topics and languages.",
        "<b>🌱 Our beginnings</b>",
        "our first session on 3 Tir 1404 (June 24, 2025)",
        "<b>💬 What brings us together</b>",
        "exchange ideas, explore different perspectives, learn from one another, and connect with new people.",
        "<b>🤝 A place for everyone</b>",
        "<b>🧩 دربارهٔ پنل فلو</b>",
        "پنل فلو جامعه‌ای در مشهد است که افراد را برای شرکت در پنل‌های گفت‌وگوی منظم و ساختارمند گرد هم می‌آورد؛ با فضایی برای موضوعات متنوع و زبان‌های مختلف.",
        "علاقه به برگزاری گفت‌وگوها و تشویق یکی از دوستان کمک کرد تا این ایده به نخستین جلسه در ۳ تیر ۱۴۰۴ تبدیل شود.",
        "<b>💬 آنچه ما را دور هم جمع می‌کند</b>",
        "<b>🤝 جایی برای همه</b>",
        "چه آمادهٔ مشارکت در گفت‌وگو باشید و چه ترجیح دهید ابتدا شنونده باشید، در پنل فلو جایی برای شما هست.",
    )
    assert all(phrase in about for phrase in expected)
    assert "weekly discussion panels in English" not in about
    assert "بنیان‌گذار بیش از یک سال تجربه" not in about
    assert about.count("<b>🌱") == 2
    assert about.count("<b>💬") == 2
    assert about.count("<b>🤝") == 2

def test_database_startup_final_error_includes_underlying_nonretryable_cause(monkeypatch):
    import asyncio
    import pytest
    from app.config import settings
    from app.db import init as db_init

    monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://tester:secret@db:5432/panel_flow")
    monkeypatch.setattr(settings, "database_startup_max_attempts", 1)

    async def fail_with_schema_error():
        raise RuntimeError("Database migration 019 failed at statement 2/3 (UndefinedTableError: relation app_settings does not exist)")

    monkeypatch.setattr(db_init, "_init_db_once", fail_with_schema_error)
    with pytest.raises(RuntimeError, match="Root cause: RuntimeError: Database migration 019 failed") as err:
        asyncio.run(db_init.init_db())
    assert "app_settings does not exist" in str(err.value)
    assert "secret" not in str(err.value)


def test_migration_failure_includes_file_statement_index_and_driver_cause(tmp_path, monkeypatch):
    import asyncio
    import pytest
    from app.db import init as db_init

    (tmp_path / "099_test_failure.sql").write_text("SELECT 1; SELECT intentionally_missing_column;", encoding="utf-8")
    monkeypatch.setattr(db_init, "MIGRATION_DIR", tmp_path)

    class Result:
        def all(self):
            return []

    class FakeConnection:
        async def execute(self, statement, params=None):
            return Result()

        async def exec_driver_sql(self, statement):
            if "intentionally_missing_column" in statement:
                raise ValueError("simulated missing column")

    with pytest.raises(RuntimeError, match=r"099_test_failure.sql failed at statement 2/2") as err:
        asyncio.run(db_init._run_migrations(FakeConnection()))
    assert "simulated missing column" in str(err.value)


def test_v43_all_app_settings_migration_inserts_supply_required_timestamps():
    """Legacy app_settings schemas may enforce NOT NULL with no column defaults."""
    from app.db.migration_utils import split_sql_statements

    app_settings_inserts = []
    for path in sorted((ROOT / "migrations").glob("*.sql")):
        source = path.read_text(encoding="utf-8")
        for statement in split_sql_statements(source):
            normalized = " ".join(statement.lower().split())
            if "insert into app_settings" in normalized:
                app_settings_inserts.append((path.name, normalized))
                assert "created_at" in normalized.split("values", 1)[0], (path.name, statement)
                assert "updated_at" in normalized.split("values", 1)[0], (path.name, statement)
                assert "current_timestamp" in normalized, (path.name, statement)

    # Every setting seed/upsert statement must supply timestamps explicitly because
    # ORM Python defaults do not run in raw SQL. V75 and V77 add targeted settings upserts.
    assert len(app_settings_inserts) == 12
    migration_020 = (ROOT / "migrations" / "020_v43_app_settings_timestamp_compat.sql").read_text(encoding="utf-8")
    migration_020_statements = " ".join(" ".join(split_sql_statements(migration_020)).lower().split())
    assert "alter table app_settings alter column created_at set default current_timestamp" in migration_020_statements
    assert "alter table app_settings alter column updated_at set not null" in migration_020_statements


def test_v43_timestamp_compat_migration_repairs_existing_null_timestamps():
    migration = (ROOT / "migrations" / "020_v43_app_settings_timestamp_compat.sql").read_text(encoding="utf-8").lower()
    assert "update app_settings set created_at = current_timestamp where created_at is null" in migration
    assert "update app_settings set updated_at = current_timestamp where updated_at is null" in migration
    assert "on conflict (key) do update set value = 'false', updated_at = current_timestamp" in migration


def test_v43_startup_error_preserves_migration_filename_and_statement_context(monkeypatch):
    import asyncio
    import pytest
    from app.config import settings
    from app.db import init as db_init

    monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://tester:secret@db:5432/panel_flow")
    monkeypatch.setattr(settings, "database_startup_max_attempts", 1)

    async def fail_with_nested_migration_error():
        try:
            raise ValueError('NotNullViolationError: null value in column "created_at"')
        except ValueError as driver_error:
            raise RuntimeError(
                "Database migration 018_community_challenges_xp.sql failed at statement 14/15 "
                "(NotNullViolationError); statement starts: INSERT INTO app_settings(key, value, created_at, updated_at)"
            ) from driver_error

    monkeypatch.setattr(db_init, "_init_db_once", fail_with_nested_migration_error)
    with pytest.raises(RuntimeError, match="Root cause: RuntimeError: Database migration 018_community_challenges_xp.sql failed") as err:
        asyncio.run(db_init.init_db())
    assert "statement 14/15" in str(err.value)
    assert "created_at" in str(err.value)
    assert "secret" not in str(err.value)
