from datetime import datetime
from decimal import Decimal
from io import BytesIO
from types import SimpleNamespace
from zipfile import ZipFile
import xml.etree.ElementTree as ET

from app.services.financial_reconciliation_export import build_financial_reconciliation_workbook
from app.services.admin_audit import format_admin_action_log

NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def _sheet_values(payload: bytes, sheet_path: str) -> tuple[dict[str, object], bool]:
    with ZipFile(BytesIO(payload)) as archive:
        shared_root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
        shared_strings = ["".join(t.text or "" for t in si.findall(".//x:t", NS)) for si in shared_root.findall("x:si", NS)]
        sheet_root = ET.fromstring(archive.read(sheet_path))
        cells: dict[str, object] = {}
        for cell in sheet_root.findall(".//x:c", NS):
            value = cell.find("x:v", NS)
            if value is None:
                continue
            cells[cell.attrib["r"]] = shared_strings[int(value.text)] if cell.attrib.get("t") == "s" else value.text
        return cells, any(sheet_root.iter("{" + NS["x"] + "}f"))


def _booking(*, booking_id, status, amount, payment_status, resolution="not_required", title="Normal"):
    owner = SimpleNamespace(
        display_name=title, first_name=title, last_name="User", telegram_id=1000 + booking_id,
        telegram_username="panel_user",
    )
    payment = None if payment_status is None else SimpleNamespace(
        status=payment_status, reviewed_by=5, receipt_file_name="receipt.png",
        receipt_uploaded_at=datetime(2026, 10, 1, 12, 0), reviewed_at=datetime(2026, 10, 1, 12, 5),
    )
    return SimpleNamespace(
        id=booking_id, booked_by=owner, payment=payment, status=status,
        participant_count=1, total_amount=Decimal(amount), discount_amount=Decimal("0"),
        cancellation_resolution=resolution, cancellation_resolution_note="—",
        created_at=datetime(2026, 10, 1, 11, 0),
    )


def test_financial_reconciliation_workbook_has_ledger_and_summary_without_formulas():
    event = SimpleNamespace(volume="V20", title='=HYPERLINK("https://evil.invalid","title")')
    bookings = [
        _booking(booking_id=1, status="confirmed", amount="5000", payment_status="approved"),
        _booking(booking_id=2, status="cancelled", amount="2500", payment_status="pending", resolution="action_required", title="=cmd|'/C calc'!A0"),
        _booking(booking_id=3, status="confirmed", amount="0", payment_status=None),
    ]
    payload = build_financial_reconciliation_workbook(event, bookings, {5: 999000})
    with ZipFile(BytesIO(payload)) as archive:
        assert "xl/worksheets/sheet1.xml" in archive.namelist()
        assert "xl/worksheets/sheet2.xml" in archive.namelist()
    summary, summary_has_formula = _sheet_values(payload, "xl/worksheets/sheet1.xml")
    ledger, ledger_has_formula = _sheet_values(payload, "xl/worksheets/sheet2.xml")
    assert summary["B4"] == "3"
    assert summary["B5"] == "2"
    assert summary["B6"] == "1"
    assert ledger["A2"] == "1"
    assert ledger["K2"] == "999000"
    assert ledger["B3"].startswith("=cmd")
    assert not summary_has_formula and not ledger_has_formula


def test_financial_reconciliation_report_includes_open_case_and_audit_copy_is_safe():
    event = SimpleNamespace(volume="V20", title="Masks & Manuals")
    booking = _booking(booking_id=7, status="cancelled", amount="1700", payment_status="approved", resolution="action_required")
    payload = build_financial_reconciliation_workbook(event, [booking], {5: 1168013099})
    ledger, contains_formula = _sheet_values(payload, "xl/worksheets/sheet2.xml")
    assert ledger["G2"] == "Approved"
    assert ledger["L2"] == "Financial follow-up required"
    assert ledger["K2"] == "1168013099"
    assert not contains_formula

    formatted = format_admin_action_log(
        actor_telegram_id=123456, action="<script>alert(1)</script>", entity_type="event",
        entity_id=9, details="line one\n<script>unsafe</script>", created_at=datetime(2026, 10, 1, 1, 2),
    )
    assert 'href="tg://user?id=123456"' in formatted
    assert "&lt;script&gt;" in formatted
    assert "<script>" not in formatted
