from pathlib import Path

from app.config import settings
from app.services.booking_pass import (
    booking_pass_payload,
    booking_pass_signature,
    verify_booking_pass_signature,
)


def test_registration_pass_payload_fits_telegram_limit_and_verifies(monkeypatch):
    monkeypatch.setattr(settings, "api_token_secret", "independent-test-secret")
    monkeypatch.setattr(settings, "bot_token", "test-bot-token")
    payload = booking_pass_payload(1234567890123)
    assert len(payload) <= 64
    prefix, booking_id, signature = payload.split("_")
    assert prefix == "bookingverify"
    assert booking_id == "1234567890123"
    assert verify_booking_pass_signature(int(booking_id), signature)
    assert not verify_booking_pass_signature(int(booking_id) + 1, signature)
    assert not verify_booking_pass_signature(int(booking_id), "0" * 24)


def test_registration_pass_uses_bot_token_as_compatible_fallback(monkeypatch):
    monkeypatch.setattr(settings, "api_token_secret", "")
    monkeypatch.setattr(settings, "bot_token", "existing-production-token")
    signature = booking_pass_signature(42)
    assert verify_booking_pass_signature(42, signature)


def test_registration_verification_is_admin_only_and_pass_is_owner_scoped():
    source = Path("app/bot/handlers/user.py").read_text(encoding="utf-8")
    verifier = source.split("async def show_booking_verification_from_message", 1)[1].split("@router.callback_query(F.data == \"user:bookings\")", 1)[0]
    pass_handler = source.split("async def booking_registration_pass", 1)[1].split("async def show_booking_verification_from_message", 1)[0]
    assert "is_admin_telegram_id(int(actor.id))" in verifier
    assert "is_host_telegram_id(int(actor.id))" in verifier
    assert "if not await is_host_telegram_id(int(actor.id))" in verifier
    assert 'payload.startswith("bookingverify_")' in source
    assert "verify_booking_pass_signature(booking_id, signature)" in verifier
    assert "Booking.id == int(booking_id)" in verifier
    assert "int(event.host_id or 0) != int(host_user_id)" in verifier
    assert "if not is_host" in verifier
    assert "اطلاعات هویتی شرکت‌کنندگان در این بررسی نمایش داده نمی‌شود" in verifier
    assert "Booking.booked_by_user_id == user.id" in pass_handler
    assert "status != RegistrationStatus.CONFIRMED" in pass_handler
    assert "مدیر یا میزبان همین پنل" in pass_handler
    assert "این کارت برای پنل‌های تحت میزبانی شما قابل تأیید نیست" in verifier
    assert "این بررسی فقط ثبت‌نام را تأیید می‌کند" in verifier


def test_my_signups_uses_event_aware_cancellation_policy_and_exposes_registration_pass():
    source = Path("app/bot/handlers/user.py").read_text(encoding="utf-8")
    render = source.split("async def render_my_bookings", 1)[1].split("async def booking_registration_pass", 1)[0]
    assert "user_can_cancel_booking(booking, getattr(booking, \"payment\", None), event)" in render
    assert "user:booking:pass:{booking.id}" in render
    assert "لغو رزرو #{booking.id}" in render
