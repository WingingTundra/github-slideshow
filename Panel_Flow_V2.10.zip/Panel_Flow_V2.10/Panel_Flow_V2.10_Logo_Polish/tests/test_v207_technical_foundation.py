from types import SimpleNamespace
import pytest

from app.db.models import EventStatus
from app.services.event_lifecycle import transition_event
from app.time_utils import as_utc_aware, to_utc_naive
from datetime import datetime, timezone, timedelta


def test_event_lifecycle_closes_registration_and_waitlist_on_completion():
    event = SimpleNamespace(
        status=EventStatus.PUBLISHED, archived=False, registration_open=True,
        registration_closed_reason=None, waitlist_enabled=True,
        is_postponed=False, postponement_note=None,
    )
    transition_event(event, EventStatus.COMPLETED)
    assert event.status == EventStatus.COMPLETED
    assert event.registration_open is False
    assert event.waitlist_enabled is False
    assert event.registration_closed_reason == "lifecycle"


def test_event_lifecycle_rejects_reopening_cancelled_event():
    event = SimpleNamespace(
        status=EventStatus.CANCELLED, archived=False, registration_open=False,
        registration_closed_reason="lifecycle", waitlist_enabled=False,
        is_postponed=False, postponement_note=None,
    )
    with pytest.raises(ValueError):
        transition_event(event, EventStatus.PUBLISHED)


def test_utc_helpers_preserve_instant_and_legacy_naive_convention():
    aware = datetime(2026, 11, 8, 12, tzinfo=timezone(timedelta(hours=3, minutes=30)))
    normalized = as_utc_aware(aware)
    assert normalized.hour == 8 and normalized.minute == 30
    assert to_utc_naive(aware) == datetime(2026, 11, 8, 8, 30)
    assert as_utc_aware(datetime(2026, 11, 8, 8, 30)).tzinfo == timezone.utc
