from app.bot.validation import is_link_like_text, normalize_display_time, normalize_iranian_mobile, normalize_panel_language, parse_full_name, to_ascii_digits


def test_iranian_mobile_examples_normalize_to_canonical_format():
    expected = "+989151117889"
    for value in (
        "09151117889",
        "9151117889",
        "+989151117889",
        "+9809151117889",
        "+98 915-111-7889",
        "۰۹۱۵۱۱۱۷۸۸۹",
    ):
        assert normalize_iranian_mobile(value) == expected


def test_iranian_mobile_rejects_wrong_lengths_and_non_mobile_numbers():
    for value in (
        "0915111788",
        "091511178890",
        "0915111788900000000000000",
        "12345678901234567890",
        "+98915111788",
        "+98091511178890",
        "05151117889",
        "+441234567890",
        "0915abc17889",
        "++989151117889",
    ):
        assert normalize_iranian_mobile(value) is None


def test_time_validation_accepts_only_hh_mm_and_returns_western_digits():
    assert normalize_display_time("16:30") == "16:30"
    assert normalize_display_time("09:05") == "09:05"
    assert normalize_display_time("۱۶:۳۰") == "16:30"
    assert normalize_display_time("24:00") is None
    assert normalize_display_time("9:05") is None
    assert normalize_display_time("16:3") is None
    assert normalize_display_time("1630") is None
    assert normalize_display_time("18:60") is None


def test_digit_normalization_is_explicit():
    assert to_ascii_digits("۱ 2 ۳") == "1 2 3"


def test_human_location_text_accepts_persian_and_english_addresses_without_rejecting_normal_punctuation():
    assert is_link_like_text("خیابان ولیعصر، بالاتر از پارک ساعی، کافه فلان") is False
    assert is_link_like_text("Tehran, Revolution St., University of Tehran (Main Gate)") is False
    assert is_link_like_text("Building A.B - Floor 2") is False


def test_human_location_text_rejects_common_url_and_link_forms():
    for value in (
        "https://maps.google.com/?q=tehran",
        "http://example.com/path",
        "https://example.com/path",
        "www.example.com",
        "google.com/maps/place/Tehran",
        "t.me/panelflow",
        "telegram.me/panelflow",
        "bit.ly/abc123",
        "goo.gl/maps/abc123",
        "maps.apple.com/?address=Tehran",
        "openstreetmap.org/#map=18/35.7/51.4",
    ):
        assert is_link_like_text(value) is True


def test_map_link_validation_accepts_http_and_https_urls():
    from app.bot.validation import is_valid_http_url

    assert is_valid_http_url("https://maps.google.com/?q=tehran") is True
    assert is_valid_http_url("http://example.com/maps") is True
    assert is_valid_http_url("www.example.com") is False


def test_full_name_parser_accepts_compound_surname_and_returns_first_last():
    assert parse_full_name("Ali Reza Ahmadi") == ("Ali", "Reza Ahmadi")
    assert parse_full_name("علی احمدی") == ("علی", "احمدی")


def test_full_name_parser_rejects_missing_or_overlong_parts():
    assert parse_full_name("Ali") is None
    assert parse_full_name("") is None
    assert parse_full_name("A " + "B" * 101) is None


def test_panel_language_accepts_common_scripts_and_normalizes_spaces():
    assert normalize_panel_language(" English ") == "English"
    assert normalize_panel_language("Français") == "Français"
    assert normalize_panel_language("فارسی") == "فارسی"
    assert normalize_panel_language("English   and Persian") == "English and Persian"
    assert normalize_panel_language("العربية") == "العربية"


def test_panel_language_rejects_commands_links_handles_and_symbols():
    for value in ("", "   ", "A", "/admin", "/cancel", "@PanelFlowAdmin", "https://example.com", "!!!", "--", "A" * 81):
        assert normalize_panel_language(value) is None
