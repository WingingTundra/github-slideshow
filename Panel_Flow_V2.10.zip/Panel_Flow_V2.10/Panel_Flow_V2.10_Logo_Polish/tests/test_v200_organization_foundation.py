from pathlib import Path
from app.db.models import Base, Organization, OrganizationMembership, Brand, HostVerification, SubscriptionPlan, OrganizationSubscription, PlatformAuditLog

ROOT = Path(__file__).resolve().parents[1]

def test_v200_models_are_registered_and_existing_core_tables_remain():
    expected = {"organizations", "organization_memberships", "brands", "brand_host_assignments",
        "host_verifications", "subscription_plans", "organization_subscriptions", "platform_audit_logs"}
    assert expected.issubset(Base.metadata.tables)
    assert {"users", "events", "bookings", "cities"}.issubset(Base.metadata.tables)
    assert "organization_id" in Base.metadata.tables["events"].columns
    assert "brand_id" in Base.metadata.tables["events"].columns
    assert "event_type" in Base.metadata.tables["events"].columns
    assert "meeting_link" in Base.metadata.tables["events"].columns
    assert "national_id_ciphertext" in HostVerification.__table__.columns

def test_v200_migration_is_additive_and_protects_founder():
    sql = (ROOT / "migrations/047_v200_multi_organization_foundation.sql").read_text()
    assert "CREATE TABLE IF NOT EXISTS organizations" in sql
    assert "CREATE TABLE IF NOT EXISTS organization_memberships" in sql
    assert "CREATE TABLE IF NOT EXISTS brands" in sql
    assert "uq_single_founder_organization" in sql
    assert "is_founding_city" in sql and "WHERE c.slug='mashhad'" in sql
    assert "TRUE,c.id,NULL FROM cities c" in sql
    assert "ALTER TABLE events ADD COLUMN IF NOT EXISTS organization_id" in sql
    assert "ALTER TABLE events ADD COLUMN IF NOT EXISTS meeting_link" in sql
    assert "DROP TABLE" not in sql.upper()

def test_v200_routes_registered_and_founder_flag_not_in_create_input():
    from app.api import api
    from app.http_api.organization_routes import OrganizationCreate
    paths = {r.path for r in api.routes if hasattr(r, "path")}
    assert {"/api/v1/organizations", "/api/v1/me/organizations",
        "/api/v1/organizations/{organization_id}/brands",
        "/api/v1/staff/platform/organizations",
        "/api/v1/staff/platform/organizations/{organization_id}"}.issubset(paths)
    payload = OrganizationCreate(name="Example Organization", slug="example-org")
    assert not hasattr(payload, "is_platform_founder")


def test_v201_tenant_constraints_and_founder_city_visibility_migration():
    from sqlalchemy import ForeignKeyConstraint
    event = Base.metadata.tables["events"]
    assignments = Base.metadata.tables["brand_host_assignments"]
    assert any(isinstance(c, ForeignKeyConstraint) and list(c.column_keys) == ["organization_id", "brand_id"] for c in event.constraints)
    assert any(isinstance(c, ForeignKeyConstraint) and list(c.column_keys) == ["organization_id", "brand_id"] for c in assignments.constraints)
    assert any(isinstance(c, ForeignKeyConstraint) and list(c.column_keys) == ["organization_id", "membership_id"] for c in assignments.constraints)
    sql = (ROOT / "migrations/048_v201_tenant_integrity_and_city_visibility.sql").read_text()
    assert "UPDATE cities SET is_active = (slug = 'mashhad')" in sql
    assert "UPDATE cities SET is_founding_city = (slug = 'mashhad')" in sql
    assert "fk_events_brand_organization" in sql
    assert "ck_events_organization_brand_pair" in sql
    assert "Repair pre-existing mismatched tenant attribution" in sql
    assert "own_brand.organization_id = e.organization_id" in sql
    assert "DROP TABLE" not in sql.upper()


def test_v201_subscription_requires_a_live_plan(monkeypatch):
    import asyncio
    from types import SimpleNamespace
    from fastapi import HTTPException
    from app.services.tenant_access import active_organization_subscription
    from app.time_utils import utc_now_naive

    subscription = SimpleNamespace(status="active", starts_at=utc_now_naive(), ends_at=None, plan_id=4)
    class Session:
        async def execute(self, statement):
            class Result:
                def scalar_one_or_none(self): return subscription
            return Result()
        async def get(self, model, ident): return SimpleNamespace(is_active=False)
    try:
        asyncio.run(active_organization_subscription(Session(), 1))
        assert False, "inactive plan must be rejected"
    except HTTPException as exc:
        assert exc.status_code == 403
        assert exc.detail["code"] == "ORGANIZATION_PLAN_UNAVAILABLE"


def test_v201_event_inputs_enforce_modality_requirements_and_meeting_link_urls():
    import pytest
    from pydantic import ValidationError
    from app.http_api.website_routes import EventCreateInput, EventUpdateInput
    base = dict(volume="01", title="Test panel", day="Sunday", date="8 Nov", start_time="18:00",
        city="Mashhad", capacity=10, price_per_person=0)
    with pytest.raises(ValidationError):
        EventCreateInput(**base, event_type="physical")
    online = EventCreateInput(**base, event_type="online", meeting_platform="Google Meet", venue=None)
    assert online.event_type == "online"
    with pytest.raises(ValidationError):
        EventCreateInput(**base, event_type="online", meeting_platform="Google Meet", meeting_link="javascript:alert(1)")
    with pytest.raises(ValidationError):
        EventUpdateInput(meeting_link="data:text/html,unsafe")


def test_v201_public_event_serializer_exposes_modality_but_never_meeting_link():
    from types import SimpleNamespace
    from app.services.public_events import public_event_payload
    event = SimpleNamespace(id=1, volume="01", title="Online panel", event_day_label="Sunday",
        event_date_label="8 Nov", start_time_label="18:00", end_time_label="19:00", venue="Online",
        address=None, map_url=None, capacity=10, price_per_person=0, price_without_cafe_order=None,
        status="published", archived=False, registration_open=True, language="English", description="Test", city="Mashhad",
        city_id=1, event_date_iso=None, event_type="online", meeting_platform="Google Meet",
        meeting_link="https://secret.example/room")
    payload = public_event_payload(event, 0)
    assert payload["event_type"] == "online"
    assert payload["meeting_platform"] == "Google Meet"
    assert "meeting_link" not in payload
    # FastAPI's response model must preserve the safe public fields while
    # continuing to filter the private URL.
    from app.http_api.schemas import PublicEventRead
    validated = PublicEventRead.model_validate(payload)
    assert validated.event_type == "online"
    assert validated.meeting_platform == "Google Meet"
    assert not hasattr(validated, "meeting_link")


def test_v201_national_identifier_fingerprint_is_domain_separated(monkeypatch):
    import base64, hashlib, hmac
    from app.config import settings
    from app.http_api.organization_routes import _national_fingerprint
    key = b"01234567890123456789012345678901"
    encoded = base64.urlsafe_b64encode(key).decode("ascii")
    monkeypatch.setattr(settings, "host_identity_encryption_key", encoded)
    derived = hmac.new(key, b"panel-flow/national-id-fingerprint/v1", hashlib.sha256).digest()
    expected = hmac.new(derived, b"1234567890", hashlib.sha256).hexdigest()
    assert _national_fingerprint("1234567890") == expected


def test_v201_subscription_price_is_only_visible_to_financial_roles():
    from types import SimpleNamespace
    from app.http_api.organization_routes import subscription_workspace_view

    sub = SimpleNamespace(status="active", starts_at="start", ends_at="end", price_amount=12000, currency="IRR")
    plan = SimpleNamespace(code="standard", max_brands=3, max_hosts=10)

    for role in ("host", "moderator"):
        view = subscription_workspace_view(sub, plan, role)
        assert view["status"] == "active"
        assert "price_amount" not in view and "currency" not in view
    for role in ("owner", "admin", "finance"):
        view = subscription_workspace_view(sub, plan, role)
        assert view["price_amount"] == 12000 and view["currency"] == "IRR"
