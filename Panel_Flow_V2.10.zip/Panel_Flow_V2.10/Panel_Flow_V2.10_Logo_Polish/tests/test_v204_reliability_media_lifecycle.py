from datetime import datetime, timedelta
from io import BytesIO
from types import SimpleNamespace

import pytest
from PIL import Image

from app.db.models import Base, Booking, EventStatus
from app.services.event_quality import evaluate_event_quality
from app.services.events import DisplayEventStatus, display_status, registration_is_open, waitlist_is_available
from app.services.image_processing import optimize_public_image
from app.services.event_notifications import MAX_NOTIFICATION_ATTEMPTS, RETRY_DELAYS_MINUTES


def _image_bytes(fmt: str = "JPEG", size=(1800, 1200), *, frames: int = 1) -> bytes:
    buffer = BytesIO()
    frames_list = [Image.new("RGB", size, (120 + i, 70, 45)) for i in range(frames)]
    if frames > 1:
        frames_list[0].save(buffer, format=fmt, save_all=True, append_images=frames_list[1:], duration=100, loop=0)
    else:
        frames_list[0].save(buffer, format=fmt)
    return buffer.getvalue()


def test_public_image_is_resized_and_converted_to_webp():
    source = _image_bytes()
    optimized = optimize_public_image(source, max_dimension=900, quality=78)
    with Image.open(BytesIO(optimized)) as image:
        assert image.format == "WEBP"
        assert max(image.size) <= 900
    assert len(optimized) < len(source)


def test_public_image_rejects_unknown_and_animated_formats():
    with pytest.raises(ValueError, match="IMAGE_INVALID_OR_UNSAFE"):
        optimize_public_image(b"not an image")
    gif = _image_bytes("GIF", frames=2)
    with pytest.raises(ValueError, match="IMAGE_FORMAT_NOT_ALLOWED"):
        optimize_public_image(gif)


def test_public_image_rejects_oversized_pixel_dimensions():
    # Decompression-bomb dimensions are rejected before pixel data is decoded.
    buffer = BytesIO()
    Image.new("RGB", (1, 1), (0, 0, 0)).save(buffer, format="PNG")
    with Image.open(BytesIO(buffer.getvalue())) as img:
        assert img.size == (1, 1)
    with pytest.raises(ValueError, match="IMAGE_DIMENSIONS_NOT_ALLOWED"):
        optimize_public_image(_image_bytes(size=(6500, 6500)))


def test_postponed_event_is_not_open_and_has_no_waitlist():
    event = SimpleNamespace(
        status=EventStatus.PUBLISHED, archived=False, is_postponed=True,
        registration_open=False, waitlist_enabled=True, capacity=10,
    )
    assert not registration_is_open(event)
    assert not waitlist_is_available(event, used=10)
    assert display_status(event, used=2) is DisplayEventStatus.POSTPONED


def test_event_quality_report_is_non_blocking_and_explains_missing_fields():
    event = SimpleNamespace(
        description="A clear and sufficiently detailed event description that explains what the discussion is about.",
        event_date_iso=datetime(2026, 12, 1).date(), topic_tags=["philosophy"],
        agenda_items=["Opening"], discussion_questions=[], cover_image_url=None,
        organization_id=1, brand_id=2,
    )
    result = evaluate_event_quality(event)
    assert result["score"] == 5 * 100 // 7 or result["score"] == round(100 * 5 / 7)
    assert result["missing"] == ["questions", "cover"]
    assert result["ready"] is True


def test_web_booking_request_index_is_partial_and_unique():
    indexes = {index.name: index for index in Booking.__table__.indexes}
    assert "uq_bookings_web_client_request" in indexes
    index = indexes["uq_bookings_web_client_request"]
    assert index.unique is True
    assert "client_request_id" in {column.name for column in index.columns}


def test_notification_retry_policy_is_bounded_with_increasing_delays():
    assert MAX_NOTIFICATION_ATTEMPTS == 5
    assert RETRY_DELAYS_MINUTES == {1: 5, 2: 30, 3: 120, 4: 360}


def test_optional_notification_digest_and_quiet_hours_use_tehran_time():
    from zoneinfo import ZoneInfo
    from app.services.event_notifications import _defer_for_quiet_hours, _digest_due_at

    # Sunday 11:30 in Tehran -> today's 20:00 digest delivery.
    now = datetime(2026, 11, 8, 8, 0)
    assert _digest_due_at("daily", now) == datetime(2026, 11, 8, 16, 30)
    # A weekly digest is scheduled for Friday at 20:00 Tehran time.
    weekly = _digest_due_at("weekly", now).replace(tzinfo=ZoneInfo("UTC")).astimezone(ZoneInfo("Asia/Tehran"))
    assert weekly.weekday() == 4
    assert (weekly.hour, weekly.minute) == (20, 0)

    preference = SimpleNamespace(quiet_hours_start="22:00", quiet_hours_end="08:00")
    due_in_quiet_hours = datetime(2026, 11, 8, 19, 0)  # 22:30 Tehran
    released = _defer_for_quiet_hours(preference, due_in_quiet_hours)
    assert released == datetime(2026, 11, 9, 4, 30)  # 08:00 Tehran next day


def test_notification_preferences_validate_digest_and_quiet_hour_pair():
    from pydantic import ValidationError
    from app.http_api.website_routes import DiscoveryPreferencesInput

    assert DiscoveryPreferencesInput(digest_frequency="weekly", quiet_hours_start="22:00", quiet_hours_end="08:00")
    with pytest.raises(ValidationError):
        DiscoveryPreferencesInput(quiet_hours_start="22:00")
    with pytest.raises(ValidationError):
        DiscoveryPreferencesInput(digest_frequency="monthly")


def test_recommendation_saved_and_attendance_signals_decay_over_time():
    from app.http_api.website_routes import _recommendation_score

    today = datetime(2026, 11, 8, 12, 0)
    event = SimpleNamespace(
        topic_tags=["literature"], organization_id=44, city_id=None,
        language=None, event_type="online", updated_at=today - timedelta(days=200),
        created_at=today - timedelta(days=200), capacity=20, registration_open=False,
        status=EventStatus.PUBLISHED, archived=False, is_postponed=False,
    )
    common = dict(topic_keys=set(), organization_ids=set(), city_id=None, language=None,
                  event_format=None, attended_organization_ids={44}, saved_topic_keys={"literature"}, now=today)
    recent_score, recent_reasons = _recommendation_score(
        event, **common,
        attended_organization_last_date={44: today.date() - timedelta(days=10)},
        saved_topic_last_at={"literature": today - timedelta(days=10)},
    )
    old_score, old_reasons = _recommendation_score(
        event, **common,
        attended_organization_last_date={44: today.date() - timedelta(days=220)},
        saved_topic_last_at={"literature": today - timedelta(days=220)},
    )
    assert recent_score > old_score
    assert "saved_interest" in recent_reasons
    assert "saved_interest" not in old_reasons
    assert "attendance" in recent_reasons
    assert "attendance" not in old_reasons
