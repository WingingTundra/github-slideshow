from pathlib import Path
import asyncio

from app.db import init as db_init

ROOT = Path(__file__).resolve().parents[1]


def test_app_settings_timestamp_preflight_repairs_before_legacy_migrations():
    source = (ROOT / "app" / "db" / "init.py").read_text(encoding="utf-8")
    create_all = source.index("await conn.run_sync(Base.metadata.create_all)")
    preflight = source.index("await _ensure_app_settings_timestamp_defaults(conn)")
    migrations = source.index("await _run_migrations(conn)")
    assert create_all < preflight < migrations


def test_app_settings_timestamp_preflight_executes_all_repairs_idempotently():
    class FakeConnection:
        def __init__(self):
            self.statements = []

        async def exec_driver_sql(self, statement):
            self.statements.append(" ".join(statement.lower().split()))

    conn = FakeConnection()
    asyncio.run(db_init._ensure_app_settings_timestamp_defaults(conn))

    assert len(conn.statements) == 9
    assert conn.statements[0].startswith("create table if not exists app_settings")
    assert "add column if not exists created_at timestamp" in conn.statements[1]
    assert "add column if not exists updated_at timestamp" in conn.statements[2]
    assert "where created_at is null" in conn.statements[3]
    assert "where updated_at is null" in conn.statements[4]
    assert "alter column created_at set default current_timestamp" in conn.statements[5]
    assert "alter column updated_at set default current_timestamp" in conn.statements[6]
    assert "alter column created_at set not null" in conn.statements[7]
    assert "alter column updated_at set not null" in conn.statements[8]


def test_timestamp_explicit_migration_stays_fixed_for_legacy_seed():
    migration = (ROOT / "migrations" / "018_community_challenges_xp.sql").read_text(encoding="utf-8").lower()
    assert "insert into app_settings(key, value, created_at, updated_at)" in migration
    assert "values ('community_public_leaderboard_enabled', 'true', current_timestamp, current_timestamp)" in migration
