from decimal import Decimal
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.bot.profile import apply_profile_name, apply_profile_phone
from app.db.models import (
    Base,
    Booking,
    Event,
    Participant,
    RegistrationStatus,
    User,
    UserRole,
)


def test_profile_keyboard_offers_name_and_phone_edits_and_back():
    root = Path(__file__).resolve().parents[1]
    source = (root / "app" / "bot" / "keyboards.py").read_text(encoding="utf-8")
    assert 'callback_data="user:profile:edit_name"' in source
    assert 'callback_data="user:profile:edit_phone"' in source
    assert 'callback_data="user:home"' in source


def test_profile_edit_cancel_keyboard_returns_to_profile():
    root = Path(__file__).resolve().parents[1]
    source = (root / "app" / "bot" / "keyboards.py").read_text(encoding="utf-8")
    assert 'callback_data="user:profile:cancel"' in source


def test_apply_profile_name_updates_first_last_and_display_name():
    user = User(
        telegram_id=1001,
        first_name="Old",
        last_name="Name",
        display_name="Old Name",
        role=UserRole.PARTICIPANT,
    )

    assert apply_profile_name(user, "علی رضایی محمدی") is True
    assert user.first_name == "علی"
    assert user.last_name == "رضایی محمدی"
    assert user.display_name == "علی رضایی محمدی"


def test_apply_profile_name_rejects_invalid_input_without_overwriting_existing_profile():
    user = User(
        telegram_id=1002,
        first_name="Correct",
        last_name="Profile",
        display_name="Correct Profile",
        role=UserRole.PARTICIPANT,
    )

    assert apply_profile_name(user, "SingleName") is False
    assert apply_profile_name(user, "") is False
    assert (user.first_name, user.last_name, user.display_name) == (
        "Correct",
        "Profile",
        "Correct Profile",
    )


def test_apply_profile_phone_normalizes_valid_number_and_rejects_invalid_without_overwrite():
    user = User(
        telegram_id=1003,
        phone_number="+989151117889",
        role=UserRole.PARTICIPANT,
    )

    assert apply_profile_phone(user, "۰۹۱۲۳۴۵۶۷۸۹") is True
    assert user.phone_number == "+989123456789"
    assert apply_profile_phone(user, "not a phone number") is False
    assert user.phone_number == "+989123456789"


def test_profile_edits_do_not_mutate_existing_booking_participant_snapshots():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    try:
        with Session(engine) as session:
            user = User(
                telegram_id=1004,
                first_name="Old",
                last_name="AccountName",
                display_name="Old AccountName",
                phone_number="+989151117889",
                role=UserRole.PARTICIPANT,
            )
            session.add(user)
            session.flush()
            event = Event(
                volume=20,
                title="Profile edit regression",
                event_day_label="Friday",
                event_date_label="9 October 2026",
                start_time_label="16:00",
                end_time_label="17:00",
                venue="Test venue",
                capacity=10,
                price_per_person=Decimal("100000"),
            )
            session.add(event)
            session.flush()
            booking = Booking(
                event_id=event.id,
                booked_by_user_id=user.id,
                participant_count=1,
                total_amount=Decimal("100000"),
                status=RegistrationStatus.CONFIRMED,
            )
            session.add(booking)
            session.flush()
            participant = Participant(
                booking_id=booking.id,
                first_name="Booking",
                last_name="Snapshot",
                full_name="Booking Snapshot",
                phone_number="+989351112233",
            )
            session.add(participant)
            session.commit()
            participant_id = participant.id
            booking_id = booking.id
            user_id = user.id

        with Session(engine) as session:
            user = session.get(User, user_id)
            assert apply_profile_name(user, "New AccountName") is True
            assert apply_profile_phone(user, "09351112233") is True
            session.commit()

        with Session(engine) as session:
            updated_user = session.get(User, user_id)
            saved_participant = session.get(Participant, participant_id)
            saved_booking = session.get(Booking, booking_id)
            assert (updated_user.first_name, updated_user.last_name) == ("New", "AccountName")
            assert updated_user.phone_number == "+989351112233"
            assert saved_booking.participant_count == 1
            assert (saved_participant.first_name, saved_participant.last_name) == (
                "Booking",
                "Snapshot",
            )
            assert saved_participant.full_name == "Booking Snapshot"
            assert saved_participant.phone_number == "+989351112233"
    finally:
        engine.dispose()


def test_profile_edit_routes_and_states_are_registered_in_user_handler():
    root = Path(__file__).resolve().parents[1]
    source = (root / "app" / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    assert 'F.data == "user:profile:edit_name"' in source
    assert 'F.data == "user:profile:edit_phone"' in source
    assert 'F.data == "user:profile:cancel"' in source
    assert "@router.message(ProfileEditStates.waiting_full_name)" in source
    assert "@router.message(ProfileEditStates.waiting_phone)" in source
    assert "apply_profile_name(user, message.text or \"\")" in source
    assert "apply_profile_phone(user, normalized_phone)" in source
