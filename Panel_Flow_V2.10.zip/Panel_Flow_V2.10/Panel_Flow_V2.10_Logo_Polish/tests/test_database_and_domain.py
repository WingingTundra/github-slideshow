from decimal import Decimal

from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session
import pytest

from app.config import Settings

from app.db.models import Base, Booking, Event, EventStatus, Participant, Payment, PaymentStatus, RegistrationStatus, User, UserRole
from app.services.events import (
    DisplayEventStatus,
    announcement_events_statement,
    display_status,
    participant_events_statement,
    publish_event,
    registration_is_open,
    waitlist_is_available,
)


def make_session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, Session(engine)


def add_user(session, telegram_id=1001, role=UserRole.PARTICIPANT):
    user = User(telegram_id=telegram_id, first_name="Test", last_name="User", role=role)
    session.add(user)
    session.flush()
    return user


def add_event(session, host, **kwargs):
    params = {
        "volume": 20,
        "title": "Panel Test 1",
        "event_day_label": "Thursday",
        "event_date_label": "15 October 2026",
        "start_time_label": "16:30",
        "end_time_label": "18:30",
        "venue": "Test Venue",
        "capacity": 20,
        "price_per_person": Decimal("100000"),
        "status": EventStatus.DRAFT,
        "registration_open": False,
        "waitlist_enabled": True,
        "host_id": host.id,
        "host_name": "Test Host",
    }
    params.update(kwargs)
    event = Event(**params)
    session.add(event)
    session.flush()
    return event


def test_panel_keeps_start_and_optional_end_times_as_plain_text():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        event = add_event(session, host, start_time_label="16:30", end_time_label="-")
        session.commit()
        assert event.start_time_label == "16:30"
        assert event.end_time_label == "-"
    finally:
        session.close()
        engine.dispose()


def test_publish_is_immediate_and_does_not_parse_or_validate_schedule_text():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        event = add_event(
            session,
            host,
            event_day_label="Thursday",
            event_date_label="A date I entered myself, even if old",
            status=EventStatus.DRAFT,
            registration_open=False,
        )
        publish_event(event)
        assert event.status == EventStatus.PUBLISHED
        assert event.registration_open is True
        assert registration_is_open(event) is True
    finally:
        session.close()
        engine.dispose()


def test_published_panel_cannot_be_republished_to_bypass_manual_registration_closure():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        event = add_event(
            session, host, status=EventStatus.PUBLISHED, registration_open=False,
            registration_closed_reason="manual",
        )
        with pytest.raises(ValueError, match="EVENT_NOT_PUBLISHABLE"):
            publish_event(event)
        assert event.status == EventStatus.PUBLISHED
        assert event.registration_open is False
        assert event.registration_closed_reason == "manual"
    finally:
        session.close()
        engine.dispose()


def test_manual_close_and_reopen_are_the_only_non_capacity_registration_controls():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        event = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=True)
        event.registration_open = False
        assert registration_is_open(event) is False
        event.registration_open = True
        assert registration_is_open(event) is True
    finally:
        session.close()
        engine.dispose()


def test_published_panels_remain_publicly_visible_when_closed_or_full():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        open_event = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=True)
        closed_event = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=False)
        full_event = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=False, capacity=2)
        session.add(Booking(event_id=full_event.id, booked_by_user_id=host.id, participant_count=2, total_amount=0, status=RegistrationStatus.CONFIRMED))
        session.commit()

        visible = {e.id for e in session.execute(participant_events_statement()).scalars().all()}
        assert {open_event.id, closed_event.id, full_event.id}.issubset(visible)
        assert display_status(full_event, used=2) == DisplayEventStatus.FULL
    finally:
        session.close()
        engine.dispose()


def test_archived_and_draft_panels_are_not_publicly_visible():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        draft = add_event(session, host, status=EventStatus.DRAFT, registration_open=False)
        archived = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=True, archived=True)
        cancelled = add_event(session, host, status=EventStatus.CANCELLED, registration_open=False)
        session.commit()
        visible = {e.id for e in session.execute(participant_events_statement()).scalars().all()}
        assert draft.id not in visible
        assert archived.id not in visible
        assert cancelled.id not in visible
    finally:
        session.close()
        engine.dispose()


def test_announcement_query_accepts_published_panels_even_when_registration_is_closed():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        closed = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=False)
        archived = add_event(session, host, status=EventStatus.PUBLISHED, registration_open=False, archived=True)
        session.commit()
        ids = {e.id for e in session.execute(announcement_events_statement()).scalars().all()}
        assert closed.id in ids
        assert archived.id not in ids
    finally:
        session.close()
        engine.dispose()


def test_active_capacity_counts_pending_and_confirmed_but_not_cancelled():
    engine, session = make_session()
    try:
        owner = add_user(session, telegram_id=1001)
        second_owner = add_user(session, telegram_id=1002)
        third_owner = add_user(session, telegram_id=1003)
        event = add_event(session, owner, status=EventStatus.PUBLISHED, registration_open=True, capacity=20)
        session.add_all([
            Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=3, total_amount=300000, status=RegistrationStatus.PENDING_PAYMENT),
            Booking(event_id=event.id, booked_by_user_id=second_owner.id, participant_count=3, total_amount=300000, status=RegistrationStatus.PENDING_VERIFICATION),
            Booking(event_id=event.id, booked_by_user_id=third_owner.id, participant_count=3, total_amount=300000, status=RegistrationStatus.CONFIRMED),
            Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=1, total_amount=100000, status=RegistrationStatus.CANCELLED),
        ])
        session.commit()
        active = session.execute(
            select(func.coalesce(func.sum(Booking.participant_count), 0)).where(
                Booking.event_id == event.id,
                Booking.status.in_((RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.PENDING_VERIFICATION, RegistrationStatus.CONFIRMED)),
            )
        ).scalar_one()
        assert int(active) == 9
    finally:
        session.close()
        engine.dispose()


def test_text_receipt_persists_with_payment_and_survives_session_restart():
    engine, session = make_session()
    try:
        owner = add_user(session)
        event = add_event(session, owner, status=EventStatus.PUBLISHED, registration_open=True)
        booking = Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=1,
            total_amount=Decimal("100000"),
            status=RegistrationStatus.PENDING_VERIFICATION,
        )
        payment = Payment(
            booking=booking,
            amount=Decimal("100000"),
            receipt_text="تاریخ: 1405/07/16\nمبلغ: 2,400,000 تومان",
            status=PaymentStatus.PENDING,
        )
        session.add_all([booking, payment])
        session.commit()
        payment_id = payment.id
        session.close()
        restarted = Session(engine)
        try:
            restored = restarted.get(Payment, payment_id)
            assert restored.receipt_text == "تاریخ: 1405/07/16\nمبلغ: 2,400,000 تومان"
        finally:
            restarted.close()
    finally:
        engine.dispose()


def test_participant_model_supports_multi_person_booking():
    engine, session = make_session()
    try:
        owner = add_user(session)
        event = add_event(session, owner, status=EventStatus.PUBLISHED, registration_open=True)
        booking = Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=2,
            total_amount=Decimal("200000"),
            status=RegistrationStatus.PENDING_PAYMENT,
        )
        booking.participants = [
            Participant(first_name="Ali", last_name="Ahmadi", full_name="Ali Ahmadi"),
            Participant(first_name="Sara", last_name="Karimi", full_name="Sara Karimi"),
        ]
        session.add(booking)
        session.commit()
        assert len(booking.participants) == 2
    finally:
        session.close()
        engine.dispose()


def test_configured_admin_identity_is_the_only_admin_authorization_boundary():
    config = Settings(super_admin_ids="12345", admin_ids="67890")
    assert config.super_admin_id_set == {12345, 67890}
    assert 22222 not in config.super_admin_id_set


def test_capacity_change_reopens_only_capacity_closed_panels():
    from app.services.events import apply_capacity_change
    from app.db.models import Event
    event = Event(capacity=8, registration_open=False, registration_closed_reason="capacity")
    apply_capacity_change(event, 8, 10, 8)
    assert event.capacity == 10
    assert event.registration_open is True
    assert event.registration_closed_reason is None

    manual = Event(capacity=8, registration_open=False, registration_closed_reason="manual")
    apply_capacity_change(manual, 8, 10, 8)
    assert manual.registration_open is False
    assert manual.registration_closed_reason == "manual"


def test_capacity_change_below_reserved_is_rejected():
    from app.services.events import apply_capacity_change
    event = Event(capacity=8, registration_open=False, registration_closed_reason="capacity")
    try:
        apply_capacity_change(event, 8, 6, 7)
        assert False, "capacity below reserved should be rejected"
    except ValueError as exc:
        assert str(exc) == "CAPACITY_BELOW_RESERVED"


def test_review_is_unique_per_user_and_panel():
    from sqlalchemy.exc import IntegrityError
    from app.db.models import Review
    engine, session = make_session()
    try:
        user = add_user(session, 3333)
        event = add_event(session, user, status=EventStatus.PUBLISHED, archived=True)
        first = Review(user_id=user.id, reviewer_telegram_id=user.telegram_id, event_id=event.id, text="Great", rating=5)
        session.add(first); session.commit()
        session.add(Review(user_id=user.id, reviewer_telegram_id=user.telegram_id, event_id=event.id, text="Again", rating=4))
        try:
            session.commit()
            assert False, "duplicate review must be rejected"
        except IntegrityError:
            session.rollback()
    finally:
        session.close(); engine.dispose()


def test_payment_supports_text_receipt_proof():
    payment_columns = {column.name: column for column in Payment.__table__.columns}
    assert "receipt_text" in payment_columns
    assert payment_columns["receipt_text"].nullable is True


def test_waitlist_is_available_when_published_panel_is_full_and_capacity_closed():
    engine, session = make_session()
    try:
        host = add_user(session, role=UserRole.HOST)
        event = add_event(
            session,
            host,
            status=EventStatus.PUBLISHED,
            registration_open=False,
            waitlist_enabled=True,
            capacity=2,
        )
        assert registration_is_open(event) is False
        assert waitlist_is_available(event, used=2) is True
        assert waitlist_is_available(event, used=1) is False
        event.waitlist_enabled = False
        assert waitlist_is_available(event, used=2) is False
        event.waitlist_enabled = True
        event.archived = True
        assert waitlist_is_available(event, used=2) is False
    finally:
        session.close()
        engine.dispose()
