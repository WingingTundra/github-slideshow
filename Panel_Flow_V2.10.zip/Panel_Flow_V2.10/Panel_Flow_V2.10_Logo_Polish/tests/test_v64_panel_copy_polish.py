from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
USER = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")


def _function_source(name: str) -> str:
    import ast

    tree = ast.parse(USER)
    node = next(
        item for item in tree.body
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name
    )
    return ast.get_source_segment(USER, node) or ""


def test_public_panel_preview_labels_match_checkout_summary():
    event_text = _function_source("event_text")
    assert 'panel_detail_line("زبان پنل", escape(event.language)' in event_text
    assert 'panel_detail_line("روز و تاریخ",' in event_text
    assert 'panel_detail_line("ساعت",' in event_text
    summary = _function_source("show_booking_summary")
    assert 'panel_detail_line("روز و تاریخ",' in summary
    assert 'panel_detail_line("ساعت",' in summary


def test_capacity_is_rendered_immediately_after_host():
    event_text = _function_source("event_text")
    host_index = event_text.index('if event.host_name:')
    capacity_index = event_text.index('details.append(panel_detail_line("ظرفیت", f"{_fa_digits(capacity)} نفر", icon="👥"))')
    assert host_index < capacity_index
    assert "should_disclose_remaining_seats(capacity, remaining)" in event_text
    assert "public_event_availability_label" in event_text or "should_disclose_remaining_seats" in event_text
    assert event_text.index('details.append(panel_detail_line("هزینه"') < host_index


def test_checkout_discount_places_minus_after_amount_for_rtl_copy():
    summary = _function_source("show_booking_summary")
    assert 'f"\\nتخفیف ({scope_note}): <b>{int(discount_amount):,}− تومان</b>"' in summary
    assert 'f"\\nتخفیف ({scope_note}): <b>−{int(discount_amount):,} تومان</b>"' not in summary


def test_referral_prompt_message_is_reused_when_panel_deep_link_resumes():
    prompt = _function_source("ask_referral_choice")
    finish = _function_source("_finish_referral_callback")
    dispatch = _function_source("dispatch_start_payload")
    details = _function_source("show_event_details_from_message")
    referral_code = _function_source("referral_code_received")

    assert 'referral_prompt_message_id=int(prompt.message_id)' in prompt
    assert 'replace_message_id=int(c.message.message_id)' in finish
    assert 'replace_message_id=replace_message_id' in dispatch
    assert 'await message.bot.edit_message_text(' in details
    assert 'referral_prompt_message_id = state_data.get("referral_prompt_message_id")' in referral_code
    assert 'replace_message_id=(int(referral_prompt_message_id) if referral_prompt_message_id else None)' in referral_code


def test_registration_deep_link_reuses_onboarding_prompt_as_booking_prompt():
    dispatch = _function_source("dispatch_start_payload")
    assert 'await state.update_data(booking_flow_message_id=int(replace_message_id))' in dispatch
