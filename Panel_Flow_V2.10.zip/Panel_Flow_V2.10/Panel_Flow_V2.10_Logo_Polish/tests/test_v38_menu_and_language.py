from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType

from app.bot.content import about_text, main_menu_welcome_text
from app.bot.validation import normalize_panel_language
from app.db.models import Base, Event

ROOT = Path(__file__).resolve().parents[1]


def _stub_aiogram_markup_types(monkeypatch):
    aiogram_module = ModuleType("aiogram")
    types_module = ModuleType("aiogram.types")

    class InlineKeyboardButton:
        def __init__(self, **kwargs):
            self.text = kwargs.get("text")
            self.callback_data = kwargs.get("callback_data")
            self.url = kwargs.get("url")

    class InlineKeyboardMarkup:
        def __init__(self, **kwargs):
            self.inline_keyboard = kwargs.get("inline_keyboard", [])

    class CopyTextButton:
        def __init__(self, *, text):
            self.text = text

    types_module.CopyTextButton = CopyTextButton
    types_module.InlineKeyboardButton = InlineKeyboardButton
    types_module.InlineKeyboardMarkup = InlineKeyboardMarkup
    aiogram_module.types = types_module
    monkeypatch.setitem(sys.modules, "aiogram", aiogram_module)
    monkeypatch.setitem(sys.modules, "aiogram.types", types_module)


def test_main_menu_welcome_copy_is_exact_and_concise():
    assert main_menu_welcome_text() == (
        "🧩 به Panel Flow خوش آمدید!\n"
        "فضایی برای گفت‌وگو و آشنایی با آدم‌های تازه."
    )
    assert "🌿" not in about_text()
    assert "<b>🧩 ABOUT PANEL FLOW</b>" in about_text()
    assert "<b>🧩 دربارهٔ پنل فلو</b>" in about_text()


def test_main_menu_has_primary_actions_and_polished_paired_rows(monkeypatch):
    _stub_aiogram_markup_types(monkeypatch)
    path = ROOT / "app/bot/keyboards.py"
    spec = importlib.util.spec_from_file_location("panel_flow_v38_keyboard", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    menu = module.main_menu()

    rows = [[button.callback_data for button in row] for row in menu.inline_keyboard]
    assert rows == [
        ["user:events"],
        ["user:bookings"],
        ["user:profile", "user:questions"],
        ["user:pastpanels", "user:suggestions"],
        ["user:reviews"],
        ["community:home"],
        ["user:community_about"],
    ]
    labels = {button.callback_data: button.text for row in menu.inline_keyboard for button in row}
    assert labels["user:suggestions"] == "💡 پیشنهادها"
    assert labels["user:pastpanels"] == "📚 پنل‌های گذشته"
    assert labels["user:community_about"] == "💬 جامعه و دربارهٔ ما"
    # Former community/about callbacks remain accepted as backward-compatible aliases.
    user_source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert '"user:community", "user:about", "user:community_about"' in user_source


def test_panel_language_is_a_nullable_event_field_for_legacy_compatibility():
    event_columns = Base.metadata.tables["events"].columns
    assert "language" in event_columns
    assert event_columns["language"].nullable is True
    assert getattr(Event, "language", None) is not None


def test_creation_and_edit_flow_require_and_persist_language_and_show_it_to_users():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    export = (ROOT / "app/services/excel_export.py").read_text(encoding="utf-8")
    states = (ROOT / "app/bot/states.py").read_text(encoding="utf-8")
    assert "class AdminEventStates(StatesGroup):" in states and "    language = State()" in states
    assert "@router.message(AdminEventStates.language)" in admin
    assert 'value = normalize_panel_language(m.text or "")' in admin
    assert 'language=data["language"]' in admin
    assert 'panel_detail_line("زبان پنل"' in admin and "normalize_panel_language(value)" in admin
    assert 'panel_detail_line("زبان پنل"' in user
    assert 'panel_detail_line("زبان پنل", escape(event.language)' in user
    assert 'summary.write("A9", "زبان پنل", label_fmt)' in export
    assert (ROOT / "migrations/017_panel_language.sql").exists()
