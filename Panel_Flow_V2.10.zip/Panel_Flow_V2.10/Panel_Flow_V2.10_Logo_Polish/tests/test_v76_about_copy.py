"""V76 regression checks for the approved bilingual About section."""

from app.bot.content import about_text


def test_about_section_contains_the_approved_english_and_persian_copy_in_order():
    text = about_text()
    required_sections = (
        "<b>🧩 ABOUT PANEL FLOW</b>",
        "<b>Who we are</b>",
        "regular, structured discussion panels, with room for different topics and languages.",
        "<b>🌱 Our beginnings</b>",
        "3 Tir 1404 (June 24, 2025)",
        "<b>💬 What brings us together</b>",
        "exchange ideas, explore different perspectives, learn from one another, and connect with new people.",
        "<b>🤝 A place for everyone</b>",
        "Whether you come ready to contribute or prefer to listen at first, there's a place for you at Panel Flow.",
        "<b>🧩 دربارهٔ پنل فلو</b>",
        "<b>ما که هستیم</b>",
        "پنل‌های گفت‌وگوی منظم و ساختارمند",
        "<b>🌱 آغاز ما</b>",
        "نخستین جلسه در ۳ تیر ۱۴۰۴",
        "<b>💬 آنچه ما را دور هم جمع می‌کند</b>",
        "تبادل ایده‌ها، آشنایی با دیدگاه‌های گوناگون، یادگیری از یکدیگر و ارتباط با افراد جدید",
        "<b>🤝 جایی برای همه</b>",
        "چه آمادهٔ مشارکت در گفت‌وگو باشید و چه ترجیح دهید ابتدا شنونده باشید، در پنل فلو جایی برای شما هست.",
    )
    positions = [text.index(section) for section in required_sections]
    assert positions == sorted(positions)


def test_about_copy_fits_single_telegram_message_and_contains_no_unsupported_html():
    text = about_text()
    assert len(text) < 4096
    assert text.count("<b>") == text.count("</b>")
    assert "Our story" not in text
    assert "Where we are today" not in text
    assert "beyond a year" not in text
