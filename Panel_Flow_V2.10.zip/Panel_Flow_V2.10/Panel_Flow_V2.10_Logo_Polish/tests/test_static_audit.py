from pathlib import Path
import ast
import re

from app.db.migration_utils import split_sql_statements

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


def all_runtime_text():
    return "\n".join(p.read_text(encoding="utf-8") for p in APP.rglob("*.py"))


def test_all_python_files_parse():
    for path in APP.rglob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def test_required_callbacks_are_present():
    text = all_runtime_text()
    for callback in [
        "admin:event:publish:",
        "admin:event:reopen:",
        "admin:event:close:",
        "admin:event:cancel:",
        "admin:event:archive:",
        "admin:event:delete:",
        "admin:event:participants:",
        "admin:event:payments:",
        "admin:event:questions:",
        "admin:event:announce:",
        "admin:event:today:",
        "admin:event:export:",
        "admin:event:create:questions:skip",
        "admin:questions",
        "admin:question:view:",
        "event:register:",
        "event:waitlist:",
        "user:submit_question",
    ]:
        assert callback in text, callback


def test_no_panel_scheduling_timestamp_logic_remains_in_runtime():
    text = all_runtime_text()
    forbidden = ["registration_deadline", "registration_closed_at"]
    for token in forbidden:
        assert token not in text, token

    models = (APP / "db" / "models.py").read_text(encoding="utf-8")
    event_model = models.split("class Event(Base):", 1)[1].split("class Booking(Base):", 1)[0]
    assert "published_at" not in event_model
    assert "event_date: Mapped" not in event_model
    assert "end_time: Mapped" not in event_model
    # V89 channel publication timestamps belong to the separate publication record,
    # not to panel scheduling or date interpretation.
    assert "class PanelAnnouncementPost(Base):" in models



def test_event_schedule_fields_are_plain_text():
    models = (APP / "db" / "models.py").read_text(encoding="utf-8")
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    assert "event_day_label: Mapped[str]" in models
    assert "event_date_label: Mapped[str]" in models
    assert "start_time_label: Mapped[str]" in models
    assert "end_time_label: Mapped[str]" in models
    assert "normalize_display_time" in admin
    assert "event_day_label" in user and "event_date_label" in user
    assert "start_time_label" in user and "end_time_label" in user


def test_publish_flow_and_capacity_close_are_explicit():
    events = (APP / "services" / "events.py").read_text(encoding="utf-8")
    booking = (APP / "services" / "booking.py").read_text(encoding="utf-8")
    assert "transition_event(event, EventStatus.PUBLISHED)" in events
    assert "event.registration_open = True" in events
    assert "if used + count >= event.capacity:" in booking
    assert "event.registration_open = False" in booking


def test_announcements_are_not_blocked_by_registration_state():
    events = (APP / "services" / "events.py").read_text(encoding="utf-8")
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    assert "def announcement_events_statement()" in events
    assert "announcement_events_statement()" in admin
    assert "event.status != EventStatus.PUBLISHED or event.archived" in admin


def test_panel_creation_includes_manual_day_date_start_and_optional_end_time_flow():
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    assert "@router.message(AdminEventStates.description)" in admin
    assert "async def create_description" in admin
    description_block = admin.split("async def create_description", 1)[1].split("@router.message(AdminEventStates.day_name)", 1)[0]
    assert "state.update_data(description" in description_block
    assert "await state.set_state(AdminEventStates.day_name)" in description_block
    day_block = admin.split("async def create_day_name", 1)[1].split("@router.message(AdminEventStates.date_text)", 1)[0]
    assert "await state.set_state(AdminEventStates.date_text)" in day_block
    date_block = admin.split("async def create_date_text", 1)[1].split("@router.message(AdminEventStates.start_time)", 1)[0]
    assert "await state.set_state(AdminEventStates.start_time)" in date_block
    start_block = admin.split("async def create_start_time", 1)[1].split("@router.message(AdminEventStates.end_time)", 1)[0]
    assert "normalize_display_time" in start_block
    assert "await state.set_state(AdminEventStates.end_time)" in start_block
    end_block = admin.split("async def create_end_time", 1)[1].split("@router.message(AdminEventStates.venue)", 1)[0]
    assert 'raw == "-"' in end_block
    assert "normalize_display_time" in end_block


def test_user_questions_are_readable_to_admin():
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    assert "admin:question:view:" in admin
    assert "question.question_text" in admin


def test_finish_event_creation_uses_the_clicking_admin_not_the_bot_authored_message():
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    start = admin.index("async def _finish_event_creation")
    end = admin.index('@router.callback_query(F.data.regexp(r"^admin:event:create:draft:', start)
    block = admin[start:end]
    assert "actor_user(" not in block
    assert '"کاربر مدیر پیدا نشد."' not in block
    assert "actor_telegram_id: int" in block
    assert "actor = await ensure_admin_user(actor_telegram_id, actor_username)" in block
    assert "host_id=actor.id" in block
    assert 'await _finish_event_creation(c.message, state, "draft", c.from_user.id, c.from_user.username)' in admin
    assert 'await _finish_event_creation(c.message, state, "publish", c.from_user.id, c.from_user.username)' in admin


def test_v72_admin_and_host_permissions_are_checked_at_operation_boundaries():
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    console = (APP / "bot" / "handlers" / "admin_console.py").read_text(encoding="utf-8")
    payments = (APP / "bot" / "handlers" / "admin_payment_actions.py").read_text(encoding="utf-8")
    assert "async def is_admin" in admin
    assert "await ensure_admin_user(tg_id)" in admin
    assert "can_control_event" not in admin
    assert "actor.role != UserRole.HOST" in admin
    assert "event.host_id != actor.id" in admin
    assert "async def _can_manage_role_change" in console
    assert "Only" not in console or "UserRole.HOST" in console
    assert 'async def allowed(tg_id: int)' in payments
    assert 'from app.services.authorization import is_admin_telegram_id' in payments
    assert 'return await is_admin_telegram_id(tg_id)' in payments
    assert "UserRole.HOST" not in payments


def test_optional_question_file_supports_dash_skip_and_publish_without_file():
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot" / "keyboards.py").read_text(encoding="utf-8")
    assert 'value != "-"' in admin
    assert 'questions_path=None' in admin
    assert 'admin:event:create:questions:skip' in admin
    assert 'questions_input_keyboard' in keyboards
    publish_block = admin.split('@router.callback_query(F.data.startswith("admin:event:publish:"))', 1)[1].split('@router.callback_query(F.data.startswith("admin:event:reopen:"))', 1)[0]
    assert 'questions_pdf_path' not in publish_block


def test_attendee_export_is_per_person_and_includes_booking_history_and_waitlist():
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    exporter = (APP / "services" / "excel_export.py").read_text(encoding="utf-8")
    assert 'async def export_participants' in admin
    for token in [
        "نام و نام خانوادگی شرکت‌کننده", "تلفن تماس ثبت‌کننده", "وضعیت رزرو", "وضعیت پرداخت",
        "وضعیت حضور", "Booking History", "Confirmed Only", "Waitlist", "build_attendee_workbook", ".xlsx",
        "ACTIVE_BOOKING_STATUSES", "contact_phone", "PanelFlowParticipants", "PanelFlowConfirmedAttendees", "PanelFlowBookingHistory",
    ]:
        assert token in exporter or token in admin
    assert "select(WaitlistEntry, User)" in admin
    assert "XlsxWriter" in (ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "Excel" in admin


def test_booking_contact_phone_is_separate_from_participant_and_profile_phone():
    models = (APP / "db" / "models.py").read_text(encoding="utf-8")
    booking = (APP / "services" / "booking.py").read_text(encoding="utf-8")
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations" / "009_booking_contact_phone.sql").read_text(encoding="utf-8")
    assert "contact_phone: Mapped[str | None]" in models
    assert "contact_phone: str | None = None" in booking
    assert 'contact_phone=data.get("booker_phone")' in user
    assert "ADD COLUMN IF NOT EXISTS contact_phone" in migration


def test_booking_signup_uses_one_full_name_prompt_and_three_seat_account_limit():
    states = (APP / "bot" / "states.py").read_text(encoding="utf-8")
    booking = (APP / "services" / "booking.py").read_text(encoding="utf-8")
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    validation = (APP / "bot" / "validation.py").read_text(encoding="utf-8")
    assert "MAX_ACTIVE_SEATS_PER_USER_PER_PANEL = 3" in booking
    assert "waiting_participant_name = State()" in states
    assert "waiting_participant_first_name" not in states
    assert "waiting_participant_last_name" not in states
    assert "نام و نام خانوادگی نفر ۱ (خودتان) را وارد کنید" not in user
    assert "booking_count_keyboard(max_count)" in user
    assert 'participants = [] if additional_booking' in user
    assert 'participants = [] if additional_booking else [{' in user
    assert '"first_name": owner.first_name' in user and '"last_name": owner.last_name' in user
    assert "if count == 1 and not additional_booking:\n        await show_booking_summary(message, state)" in user
    assert "parse_full_name" in user and "def parse_full_name" in validation


def test_plain_start_lands_on_main_menu_instead_of_available_panel():
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    start = user.index("async def start")
    end = user.index("async def begin_register_from_message", start)
    block = user[start:end]
    assert "main_menu_welcome_text()" in block
    assert "reply_markup=main_menu()" in block
    assert "message.answer(" in block
    assert "await show_events(message)" not in block


def test_available_panels_are_a_single_list_screen_and_panel_has_back_to_list():
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot" / "keyboards.py").read_text(encoding="utf-8")
    assert "available_events_keyboard(events, page=page)" in user
    assert 'callback_data=f"event:open:{event.id}:{max(0, int(page))}"' in keyboards
    assert 'callback_data="user:home"' in keyboards
    assert 'callback_data="user:events"' in keyboards


def test_registration_confirmation_uses_callback_buttons_and_booker_phone_state():
    states = (APP / "bot" / "states.py").read_text(encoding="utf-8")
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot" / "keyboards.py").read_text(encoding="utf-8")
    assert "waiting_booker_phone" in states
    assert 'F.data == "booking:confirm"' in user
    assert 'F.data == "booking:cancel"' in user
    assert 'callback_data="booking:confirm"' in keyboards
    assert 'callback_data="booking:cancel"' in keyboards
    assert 'panel_detail_line("شماره تماس ثبت‌کننده"' in user
    assert 'contact_phone=data.get("booker_phone")' in user
    phone_handler = user.split("async def booking_booker_phone", 1)[1].split("async def show_booking_summary", 1)[0]
    assert '"phone_number": normalized_phone' not in phone_handler


def test_community_links_are_configuration_driven():
    config = (ROOT / "app/config.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    for field in ("panel_flow_channel_url", "panel_flow_instagram_url", "panel_flow_website_url"):
        assert field in config
    assert "community_keyboard(community_values)" in user
    assert 'if values.get("community_instagram_url")' in keyboards
    assert 'if values.get("community_website_url")' in keyboards


def test_migration_005_removes_old_panel_time_columns_and_preserves_manual_text():
    migration = (ROOT / "migrations" / "005_manual_panel_schedule.sql").read_text(encoding="utf-8")
    assert "ADD COLUMN IF NOT EXISTS event_day_label" in migration
    assert "ADD COLUMN IF NOT EXISTS event_date_label" in migration
    assert "DROP COLUMN IF EXISTS event_date" in migration
    assert "DROP COLUMN IF EXISTS end_time" in migration
    assert "DROP COLUMN IF EXISTS registration_deadline" in migration
    assert "DROP COLUMN IF EXISTS published_at" in migration
    assert "DROP COLUMN IF EXISTS registration_closed_at" in migration
    assert "DROP COLUMN IF EXISTS archived_at" in migration


def test_migration_splitter_preserves_dollar_quoted_blocks_and_string_semicolons():
    sql = """
    ALTER TABLE demo ADD COLUMN note TEXT;
    INSERT INTO demo(note) VALUES ('a; b');
    DO $$
    DECLARE
        message TEXT := 'inside; dollar quote';
    BEGIN
        PERFORM 1;
    END $$;
    """
    statements = split_sql_statements(sql)
    assert len(statements) == 3
    assert statements[0].startswith("ALTER TABLE demo")
    assert "'a; b'" in statements[1]
    assert "PERFORM 1;" in statements[2]


def test_docker_compose_has_separate_bot_api_db_services():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    assert "\n  bot:" in compose
    assert "\n  api:" in compose
    assert '"${API_BIND_HOST:-127.0.0.1}:${API_HOST_PORT:-8000}:${API_PORT:-8000}"' in compose
    assert 'POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?Set POSTGRES_PASSWORD in .env}' in compose
    assert '127.0.0.1' in compose
    assert "postgres_data:/var/lib/postgresql/data" in compose


def test_readme_warns_against_deleting_database_volume():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "docker compose down -v" in readme
    assert "Do not run" in readme


def test_migration_006_adds_presentation_only_panel_times():
    migration = (ROOT / "migrations" / "006_panel_display_times.sql").read_text(encoding="utf-8")
    assert "ADD COLUMN IF NOT EXISTS start_time_label VARCHAR(5)" in migration
    assert "ADD COLUMN IF NOT EXISTS end_time_label VARCHAR(5)" in migration
    assert "never parsed" in migration


def test_panel_deep_link_opens_details_and_reg_deep_link_starts_registration():
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    dispatch_start = user.index("async def dispatch_start_payload")
    dispatch_end = user.index('@router.message(CommandStart())', dispatch_start)
    block = user[dispatch_start:dispatch_end]
    assert 'payload.startswith("panel_")' in block
    assert 'await show_event_details_from_message(' in block
    assert 'replace_message_id=replace_message_id' in block
    assert 'payload.startswith("reg_") or payload.startswith("event_")' in block
    assert 'await begin_register_from_message(message, state, event_id, allow_duplicate=allow_duplicate, telegram_user=telegram_user)' in block
    start = user.index("async def start")
    start_end = user.index('@router.message(Command("help"))', start)
    assert 'pending_start_payload=payload' in user[start:start_end]


def test_event_text_does_not_duplicate_raw_map_url():
    user = (APP / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    start = user.index("def event_text")
    end = user.index("@router.message(CommandStart())", start)
    block = user[start:end]
    assert '"🔗 لینک موقعیت"' not in block
    assert 'event.map_url' not in block
    assert 'event.address' in block
    keyboards = (APP / "bot" / "keyboards.py").read_text(encoding="utf-8")
    assert 'text="📍 مشاهده موقعیت", url=map_url' in keyboards


def test_channel_status_data_model_and_settings_are_persistent():
    models = (ROOT / "app/db/models.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations/007_channel_updates_reviews.sql").read_text(encoding="utf-8")
    service = (ROOT / "app/services/channel_status.py").read_text(encoding="utf-8")
    for token in ["ChannelAnnouncement", "poster_message_id", "status_message_id", "initialized", "last_capacity", "last_remaining"]:
        assert token in models
        assert token in migration or token in {"ChannelAnnouncement", "initialized"}
    assert "channel_updates_enabled" in migration
    assert "INSERT INTO app_settings(key, value, created_at, updated_at)" in migration
    assert "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP" in migration
    assert "channel_update_threshold" in migration
    assert "with_for_update()" in service
    assert 'payload = "event" if can_register else "panel"' in service
    assert 'start={payload}_{event_id}' in service


def test_archive_is_confirmed_and_keeps_delete_separate():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    assert "آرشیو + بازخورد" in keyboards
    assert "تأیید آرشیو" in keyboards
    assert "admin:event:archive:confirm:" in admin
    assert "event.archived = True" in admin
    assert "admin:event:delete:" in admin


def test_archive_action_is_available_in_final_state_submenu_and_confirmation_closes_registration():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    assert 'callback_data=f"admin:event:final:{event_id}"' in keyboards
    assert 'if stored_status == "completed":' in keyboards
    assert 'callback_data=f"admin:event:complete:{event_id}"' in keyboards
    assert 'callback_data=f"admin:event:archive:{event_id}"' in keyboards
    start = admin.index("async def event_archive_confirm")
    end = admin.index('@router.callback_query(F.data.startswith("admin:event:archive:cancel:"))', start)
    block = admin[start:end]
    assert "event.archived" in block
    assert "event.status != EventStatus.COMPLETED" in block
    assert "event.registration_open = False" in block
    assert "event.questions_pdf_path = None" not in block


def test_reviews_are_private_admin_only_and_one_per_event_user():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    models = (ROOT / "app/db/models.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:reviews"' in admin or 'F.data == "admin:reviews"' in admin
    assert 'F.data == "user:reviews"' in user
    assert "Review(" in user and "user_id=user.id" in user
    assert "reviewer_telegram_id=user.telegram_id" in user
    assert "UniqueConstraint(\"event_id\", \"user_id\"" in models
    assert "event.archived" in user


def test_manual_and_capacity_closures_are_distinguished():
    booking = (APP / "services/booking.py").read_text(encoding="utf-8")
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    events = (ROOT / "app/services/events.py").read_text(encoding="utf-8")
    assert 'registration_closed_reason = "capacity"' in booking
    assert 'registration_closed_reason = None if opening else "manual"' in admin
    assert 'event.registration_closed_reason == "capacity"' in events


def test_migration_007_contains_upgrade_safe_review_and_channel_tables():
    migration = (ROOT / "migrations/007_channel_updates_reviews.sql").read_text(encoding="utf-8")
    for token in [
        "CREATE TABLE IF NOT EXISTS app_settings",
        "CREATE TABLE IF NOT EXISTS channel_announcements",
        "ALTER TABLE reviews ADD COLUMN IF NOT EXISTS reviewer_telegram_id",
        "ALTER TABLE reviews ADD COLUMN IF NOT EXISTS booking_id",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_reviews_event_user",
        "ON CONFLICT (key) DO NOTHING",
    ]:
        assert token in migration


def test_blank_channel_id_is_treated_as_unconfigured():
    from app.config import Settings
    base = {"bot_token": "x", "database_url": "postgresql+asyncpg://x:x@localhost/x"}
    assert Settings(**base, panel_flow_channel_id="").panel_flow_channel_id is None
    assert Settings(**base, panel_flow_channel_id="   ").panel_flow_channel_id is None
    assert Settings(**base, panel_flow_channel_id="-1004356039555").panel_flow_channel_id == -1004356039555


def test_archived_and_completed_panels_are_reconcilable():
    channel = (APP / "services" / "channel_status.py").read_text(encoding="utf-8")
    admin = (APP / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    assert "Event.archived.is_(True)" in channel
    assert "EventStatus.COMPLETED" in channel
    assert "event.status != EventStatus.COMPLETED" in admin


def test_repeat_registration_and_text_receipt_wiring_present():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    user_text = (root / "app/bot/handlers/user.py").read_text()
    keyboard_text = (root / "app/bot/keyboards.py").read_text()
    admin_text = (root / "app/bot/handlers/admin_payment_actions.py").read_text()
    assert "event:register_again:" in keyboard_text
    assert "allow_duplicate=bool(data.get(\"allow_duplicate\"))" in user_text
    assert '@router.message(BookingStates.waiting_receipt, F.text)' in user_text
    assert "payment.receipt_text" in user_text
    assert "payment.receipt_text" in admin_text and "payment.receipt_file" in admin_text
    assert "receipt_review_token(payment) == token" in admin_text


def test_location_field_rejects_link_like_text_before_advancing_to_next_state():
    import ast

    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    validation = (APP / "bot/validation.py").read_text(encoding="utf-8")
    tree = ast.parse(admin)
    handlers = {
        node.name: node
        for node in ast.walk(tree)
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef))
        and node.name in {"create_venue", "create_address", "edit_venue", "edit_address"}
    }
    for name, node in handlers.items():
        source = ast.get_source_segment(admin, node)
        assert "is_link_like_text(value)" in source
        assert any(
            isinstance(child, ast.If)
            and "is_link_like_text(value)" in ast.get_source_segment(admin, child)
            and any(isinstance(stmt, ast.Return) for stmt in child.body)
            for child in node.body
        ), name
        first_guard = next(child for child in node.body if isinstance(child, ast.If) and "is_link_like_text(value)" in ast.get_source_segment(admin, child))
        first_state_change = next((i for i, child in enumerate(node.body) if isinstance(child, ast.Await) and "set_state" in ast.get_source_segment(admin, child)), len(node.body))
        guard_index = node.body.index(first_guard)
        assert guard_index < first_state_change, name
    assert "_WEB_SCHEME_RE" in validation
    assert "_DOMAIN_RE" in validation


def test_map_url_field_still_accepts_http_https_urls_after_location_validation():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    for handler in ("async def create_map_url", "async def edit_map"):
        start = admin.index(handler)
        next_router = admin.find("\n@router.", start + 1)
        block = admin[start: next_router if next_router != -1 else len(admin)]
        assert "is_valid_url(value)" in block
        assert "set_state(AdminEventStates.capacity)" in block or "set_state(AdminEditStates.capacity)" in block


def test_booking_limits_are_enforced_at_service_boundary_and_use_event_lock():
    booking = (APP / "services/booking.py").read_text(encoding="utf-8")
    assert "MAX_PARTICIPANTS_PER_BOOKING = 3" in booking
    assert "MAX_ACTIVE_SEATS_PER_USER_PER_PANEL = 3" in booking
    assert "await session.get(Event, event_id, with_for_update=True)" in booking
    assert "active_seats_for_owner(session, event_id, user_id)" in booking
    assert 'raise ValueError("USER_SEAT_LIMIT")' in booking


def test_channel_reconciler_does_not_create_first_status_message_from_poster_row_above_threshold():
    channel = (APP / "services/channel_status.py").read_text(encoding="utf-8")
    assert "row.status_message_id is None" in channel
    assert "remaining > threshold" in channel
    assert "poster association is not itself a status-message trigger" in channel


def test_receipt_review_supports_file_or_text_and_same_approve_reject_flow():
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    actions = (APP / "bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    assert '@router.message(BookingStates.waiting_receipt, F.photo)' in user
    assert '@router.message(BookingStates.waiting_receipt, F.document)' in user
    assert '@router.message(BookingStates.waiting_receipt, F.text)' in user
    assert '"receipt_text":' not in user  # persisted on the Payment model rather than FSM-only data
    assert 'payment.receipt_text = receipt_text.strip() if receipt_text else None' in user
    assert 'f"نوع رسید: {\'متن\' if payment.receipt_text else \'فایل/تصویر\'}"' in admin
    assert "receipt_review_token(payment) == token" in actions
    assert "payment.receipt_file or payment.receipt_text" in actions
    assert 'payment.status = PaymentStatus.APPROVED if approve else PaymentStatus.REJECTED' in actions
    assert 'booking.status = RegistrationStatus.CONFIRMED if approve else RegistrationStatus.REJECTED' in actions
    assert 'await c.bot.send_document(owner_id' not in actions  # user is notified via send_message; receipt itself remains in payment storage
