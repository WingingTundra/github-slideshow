from __future__ import annotations

import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_about_start_payload_precedes_registration_and_preserves_active_state():
    user = read("app/bot/handlers/user.py")
    start = user.split('@router.message(CommandStart())', 1)[1].split('\n\n@router.', 1)[0]
    assert 'payload.casefold() in {"about", "community", "community_about"}' in start
    assert start.index('payload.casefold() in') < start.index('continue_onboarding(message, state, user)')
    assert 'await render_community_links(message)' in start
    # About rendering should happen before normal flow clearing and not mutate FSM state.
    about_branch = start.split('if payload.casefold() in', 1)[1].split('# /start must not silently', 1)[0]
    assert 'await state.clear()' not in about_branch
    assert 'about_text()' in user and 'community_keyboard(community_values)' in user


def test_admin_about_qr_uses_live_username_and_in_memory_png():
    handler = read("app/bot/handlers/admin_features.py")
    keyboards = read("app/bot/keyboards.py")
    requirements = read("requirements.txt")
    assert 'F.data == "admin:settings:about_qr"' in handler
    assert 'await c.bot.get_me()' in handler
    assert 'f"https://t.me/{username}?start=about"' in handler
    assert 'qrcode.QRCode' in handler and 'BytesIO()' in handler
    assert 'logger = logging.getLogger(__name__)' in handler
    assert 'callback_data="admin:settings:about_qr"' in keyboards
    assert 'qrcode[pil]' in requirements


def test_signup_and_profile_explain_phone_use_and_hide_reply_keyboard_after_capture():
    user = read("app/bot/handlers/user.py")
    count_prompt = user.split('async def _booking_count_prompt', 1)[1].split('\n\nasync def ', 1)[0]
    save_phone = user.split('async def save_phone', 1)[1].split('\n\n@router.', 1)[0]
    profile_text = user.split('def profile_text', 1)[1].split('\n\nasync def show_profile', 1)[0]
    assert 'اطلاعات تماس شما از پروفایل ذخیره می‌شود' in count_prompt
    assert 'فهرست عمومی نمایش داده نمی‌شود' in count_prompt
    assert 'reply_markup=hide_reply_keyboard()' in save_phone
    assert 'فهرست عمومی شرکت‌کنندگان' in profile_text


def test_panel_catalog_distinguishes_open_closed_and_full_states():
    user = read("app/bot/handlers/user.py")
    catalog = user.split('async def show_events', 1)[1].split('\n\n@router.callback_query(F.data == "user:events")', 1)[0]
    assert 'registration_is_open(event)' in catalog
    assert 'public_catalogue_availability_label(' in catalog
    assert 'registration_is_open(event)' in catalog
    disclosure = read("app/services/seat_disclosure.py")
    assert 'ظرفیت تکمیل شده است · فهرست انتظار فعال است' in disclosure


def test_admin_home_has_action_queue_and_host_review_is_paginated_and_status_clear():
    keys = read("app/bot/keyboards.py")
    console = read("app/bot/handlers/admin_console.py")
    features = read("app/bot/handlers/admin_features.py")
    assert 'callback_data="admin:dashboard"' in keys
    assert 'admin:console:reviews:page:' in console
    assert 'HOST_REVIEW_PAGE_SIZE = 5' in console
    assert 'در انتظار بررسی: <b>{total}</b>' in console
    assert 'برای عمومی‌شدن، همچنان باید از منوی مدیریت آن را منتشر کنید' in console
    assert 'pending_shop_requests' in features and 'uncertain_reward_deliveries' in features


def test_quick_field_editing_and_dormant_admin_snapshot_writes_removed():
    admin = read("app/bot/handlers/admin.py")
    middleware = read("app/bot/middleware.py")
    main = read("app/bot/main.py")
    assert 'admin:event:fieldedit:' in admin
    assert 'AdminQuickEditStates.waiting_value' in admin
    assert 'AdminQuickEditStates.confirming' in admin
    assert '"host_name": "نام میزبان"' in admin
    assert '"questions_pdf": "فایل سؤالات"' in admin
    assert 'admin:event:fieldedit:pdfremove:confirm:' in admin
    assert 'admin:event:fieldedit:pdfremove:commit:' in admin
    assert 'async def quick_edit_questions_file_remove_confirm' in admin
    assert 'async def quick_edit_questions_file_remove_commit' in admin
    keys = read("app/bot/keyboards.py")
    assert '("👤 نام میزبان", "host_name")' in keys
    assert '("📄 فایل سؤالات", "questions_pdf")' in keys
    assert 'PersistentAdminDraftMiddleware' not in middleware
    assert 'PersistentAdminDraftMiddleware' not in main
    # The legacy service/model remain so existing history is not deleted.
    assert 'class AdminDraftSnapshot' in read("app/db/models.py")


def test_offsite_script_only_copies_encrypted_archives_and_verifies_size(tmp_path):
    script = ROOT / "scripts/copy-backups-offsite.sh"
    bindir = tmp_path / "bin"
    bindir.mkdir()
    # Minimal rclone stand-in: mirror copyto to local path and return object metadata.
    fake = bindir / "rclone"
    fake.write_text('''#!/bin/sh
set -eu
case "$1" in
  copyto) cp "$2" "$3" ;;
  lsjson)
    file="$3"
    size=$(wc -c < "$file" | tr -d '[:space:]')
    printf '{"Path":"%s","Size":%s}' "$(basename "$file")" "$size"
    ;;
  *) exit 9 ;;
esac
''', encoding="utf-8")
    fake.chmod(0o755)
    backups = tmp_path / "backups"
    remote = tmp_path / "remote"
    backups.mkdir(); remote.mkdir()
    archive = backups / "panel-flow-test.tar.gz.enc"
    archive.write_bytes(b"encrypted archive fixture")
    # A plain unrelated file must not be copied.
    (backups / "database.dump").write_text("not an archive", encoding="utf-8")
    env = os.environ.copy()
    env.update({"PATH": f"{bindir}:{env.get('PATH','')}", "BACKUP_DIR": str(backups), "BACKUP_REMOTE_TARGET": str(remote)})
    result = subprocess.run(["sh", str(script)], env=env, text=True, capture_output=True, check=False, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    remote_archive = remote / archive.name
    assert remote_archive.read_bytes() == archive.read_bytes()
    assert archive.exists() and (backups / "database.dump").exists()
    assert not (remote / "database.dump").exists()
    assert "offsite_copy_verified" in result.stdout


def test_v83_release_markers_and_current_documents_are_consistent():
    assert read("README.md").startswith("# Panel Flow — V2.06")
    assert "035_v79_host_notifications.sql" in read("README.md")
    assert "036_v80_persistent_fsm_and_attendance_ranking.sql" in read("README.md")
    assert "release=V97" in read("scripts/backup.sh")
    assert "Panel Flow V97 database initialization started" in read("app/db/init.py")
    assert Path(ROOT / "V93_CHANGELOG.md").exists()
    assert Path(ROOT / "V93_QA_REPORT.md").exists()
    assert Path(ROOT / "V93_DEPLOYMENT_NOTES.md").exists()


def test_creation_wizard_sends_new_prompts_and_supports_back_cancel_for_admin_and_host():
    admin = read("app/bot/handlers/admin.py")
    console = read("app/bot/handlers/admin_console.py")
    keyboards = read("app/bot/keyboards.py")
    reply_menu = read("app/bot/handlers/reply_menu.py")
    assert "async def _creation_prompt" in admin
    prompt_function = admin.split("async def _creation_prompt", 1)[1].split("async def _creation_retry", 1)[0]
    assert "message.answer" in prompt_function
    assert "edit_message_text" not in prompt_function
    assert "event_creation_prompt_message_id" in admin and "_validate_creation_callback" in admin
    for step in ("create_volume", "create_title", "create_language", "create_description", "create_day_name", "create_date_text", "create_start_time", "create_end_time", "create_venue", "create_address", "create_map_url", "create_capacity", "create_alternative_price", "create_waitlist", "create_host"):
        block = admin.split(f"async def {step}", 1)[1].split("\n\n@router.", 1)[0]
        assert "_creation_prompt(" in block, step
    assert 'F.data.regexp(r"^admin:event:create:back:[0-9a-f]{32}$")' in admin
    assert 'F.data.regexp(r"^admin:event:create:cancel:[0-9a-f]{32}$")' in admin
    assert "def admin_event_creation_reply_keyboard" in keyboards
    assert 'KeyboardButton(text="⬅️ مرحلهٔ قبل")' in keyboards
    assert 'KeyboardButton(text="❌ لغو ایجاد")' in keyboards
    assert "async def admin_event_creation_reply_actions" in admin
    assert 'F.text.in_({"⬅️ مرحلهٔ قبل", "❌ لغو ایجاد"})' in reply_menu
    assert "panel_creation_reply_keyboard_action" in reply_menu
    host_start = console.split("async def admin_or_host_create_start", 1)[1].split("@router.callback_query", 1)[0]
    assert "_creation_prompt" in host_start
    assert "event_creation_prompt_message_id" in console and "host_create_submit" in console
    assert "_creation_prompt" in host_start and "event_creation_token" in host_start


def test_host_approval_and_audit_details_are_on_demand_and_revalidated():
    console = read("app/bot/handlers/admin_console.py")
    admin = read("app/bot/handlers/admin.py")
    approve_start = console.split("async def admin_review_approve(", 1)[1].split("async def admin_review_approve_confirm(", 1)[0]
    approve_confirm = console.split("async def admin_review_approve_confirm(", 1)[1].split("async def admin_review_reject_start(", 1)[0]
    assert 'callback_data=approval_callback_data(event_id, submission_revision)' in approve_start
    assert 'submission_revision = current_submission_revision(event)' in approve_start
    assert "پیش‌نویس عمومی منتشر نمی‌شود" in approve_start or "پنل عمومی منتشر نمی‌شود" in approve_start
    assert ".with_for_update()" in approve_confirm
    assert 'event.submission_status != "submitted"' in approve_confirm
    assert 'not submission_revision_matches(event, expected_revision)' in approve_confirm
    assert 'F.data.regexp(r"^admin:console:review:approve_confirm:\\d+$")' in console
    assert 'F.data.regexp(r"^hrap:\\d+:\\d+$")' in console
    audit_summary = admin.split("async def admin_audit_log(", 1)[1].split("async def admin_audit_detail(", 1)[0]
    audit_detail = admin.split("async def admin_audit_detail(", 1)[1].split("async def admin_stats(", 1)[0]
    assert 'callback_data=f"admin:audit:detail:{int(action.id)}:{page}"' in audit_summary
    assert "async def admin_audit_detail" in admin
    assert "json.loads(details)" in audit_detail
    assert "if not await is_admin(c.from_user.id)" in audit_detail
    assert '"token", "secret", "password", "credential", "receipt", "card_number"' in audit_detail
    assert "[redacted]" in audit_detail


def test_public_leaderboard_position_keeps_hidden_users_in_their_rank_slot():
    service = read("app/services/community.py")
    handler = read("app/bot/handlers/community.py")
    position = service.split("async def public_leaderboard_position(", 1)[1].split("async def set_leaderboard_opt_in", 1)[0]
    view = handler.split("async def community_leaderboard(", 1)[1].split("@router.callback_query(F.data == \"community:leaderboard:privacy\")", 1)[0]
    assert "leaderboard_enabled(session)" in position
    assert "leaderboard_opted_in(session, telegram_id)" not in position
    assert "_attendance_count_subquery()" in position
    assert "_leaderboard_xp_subquery()" in position
    assert "panels_expr.desc(), xp_expr.desc()" in position
    assert "func.row_number().over(order_by=ranking_order)" in position
    assert "func.count().over()" in position
    assert "func.lower(User.first_name)" in position and "User.telegram_id" in position
    assert "public_leaderboard_position(session, c.from_user.id)" in view
    assert "جایگاه شما حفظ شده است" in view
    assert "••••••••" in view
    assert "پاسپورت" not in view


def test_review_screen_explains_one_review_per_panel_and_private_visibility():
    user = read("app/bot/handlers/user.py")
    reviews = user.split("async def render_reviews(", 1)[1].split("@router.callback_query(F.data == \"user:reviews\")", 1)[0]
    assert "برای هر پنل فقط یک نظر ثبت می‌شود" in reviews
    assert "فقط برای مدیران نمایش داده می‌شوند" in reviews
