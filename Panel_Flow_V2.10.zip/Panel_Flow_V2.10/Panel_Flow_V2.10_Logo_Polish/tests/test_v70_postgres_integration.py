"""Real PostgreSQL concurrency/invariant tests.

Set PANEL_FLOW_TEST_DATABASE_URL to a disposable PostgreSQL database whose name
contains 'test'. Tests create a random isolated schema and drop only that schema.
They never use the application's DATABASE_URL or Docker Compose production DB.
"""
from __future__ import annotations

import asyncio
import os
import re
import uuid
from contextlib import asynccontextmanager
from datetime import timedelta
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import func, select, text
from sqlalchemy.exc import DBAPIError, IntegrityError
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.db.models import (
    AdminAction, Base, Booking, Event, EventStatus, Payment, PaymentReviewAttempt,
    PaymentStatus, RegistrationStatus, User, WaitlistEntry,
)
from app.services.booking import create_booking
from app.services.event_cancellation import cancel_event_in_transaction
from app.services.payment_review import lock_payment_review_rows, receipt_fingerprint, receipt_review_token
from app.services.waitlist import WAITLIST_INVITATION_TTL, next_waitlist_candidate
from app.time_utils import utc_now_naive
from app.db.migration_utils import split_sql_statements


@asynccontextmanager
async def _isolated_postgres():
    raw = (os.getenv("PANEL_FLOW_TEST_DATABASE_URL") or "").strip()
    if not raw:
        if os.getenv("GITHUB_ACTIONS") == "true":
            pytest.fail("CI must provide PANEL_FLOW_TEST_DATABASE_URL; PostgreSQL integration tests may not be skipped")
        pytest.skip("Set PANEL_FLOW_TEST_DATABASE_URL to a disposable PostgreSQL database to run integration tests")
    url = make_url(raw)
    if url.drivername in {"postgresql", "postgres"}:
        url = url.set(drivername="postgresql+asyncpg")
    database_name = (url.database or "").lower()
    is_explicit_test_database = bool(re.search(r"(?:^|[_-])test(?:$|[_-])", database_name))
    if url.drivername != "postgresql+asyncpg" or not is_explicit_test_database:
        message = "Safety guard: use PostgreSQL/asyncpg and a database name with a separate 'test' segment (e.g. panel_flow_test)"
        if os.getenv("GITHUB_ACTIONS") == "true":
            pytest.fail(message)
        pytest.skip(message)
    schema = "pf_v70_test_" + uuid.uuid4().hex[:12]
    admin_engine = create_async_engine(url, pool_pre_ping=True)
    test_engine = None
    try:
        async with admin_engine.begin() as conn:
            await conn.execute(text(f'CREATE SCHEMA "{schema}"'))
        test_engine = create_async_engine(
            url,
            pool_pre_ping=True,
            connect_args={"server_settings": {"search_path": f"{schema},public"}},
        )
        async with test_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        factory = async_sessionmaker(test_engine, expire_on_commit=False)
        yield factory
    finally:
        if test_engine is not None:
            await test_engine.dispose()
        async with admin_engine.begin() as conn:
            await conn.execute(text(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE'))
        await admin_engine.dispose()


async def _seed_user(session, telegram_id: int, name: str) -> User:
    user = User(telegram_id=telegram_id, first_name=name, last_name="Tester", display_name=f"{name} Tester")
    session.add(user)
    await session.flush()
    return user


async def _seed_event(session, *, capacity: int = 2) -> Event:
    event = Event(
        volume="V70-test", title="PostgreSQL integration test", venue="Disposable test venue",
        capacity=capacity, price_per_person=Decimal("1000"),
        status=EventStatus.PUBLISHED, registration_open=True, waitlist_enabled=True,
    )
    session.add(event)
    await session.flush()
    return event


def test_postgres_v70_migration_preserves_legacy_rows_and_guards_new_writes():
    async def run():
        raw = (os.getenv("PANEL_FLOW_TEST_DATABASE_URL") or "").strip()
        if not raw:
            if os.getenv("GITHUB_ACTIONS") == "true":
                pytest.fail("CI must provide PANEL_FLOW_TEST_DATABASE_URL; PostgreSQL migration tests may not be skipped")
            pytest.skip("Set PANEL_FLOW_TEST_DATABASE_URL to a disposable PostgreSQL database to run integration tests")
        url = make_url(raw)
        if url.drivername in {"postgresql", "postgres"}:
            url = url.set(drivername="postgresql+asyncpg")
        database_name = (url.database or "").lower()
        if url.drivername != "postgresql+asyncpg" or not re.search(r"(?:^|[_-])test(?:$|[_-])", database_name):
            message = "Safety guard: use a PostgreSQL/asyncpg database with a separate 'test' segment"
            if os.getenv("GITHUB_ACTIONS") == "true":
                pytest.fail(message)
            pytest.skip(message)

        schema = "pf_v70_migration_" + uuid.uuid4().hex[:12]
        admin_engine = create_async_engine(url, pool_pre_ping=True)
        scoped_engine = None
        try:
            async with admin_engine.begin() as conn:
                await conn.execute(text(f'CREATE SCHEMA "{schema}"'))
            scoped_engine = create_async_engine(
                url, pool_pre_ping=True,
                connect_args={"server_settings": {"search_path": f"{schema},public"}},
            )
            async with scoped_engine.begin() as conn:
                await conn.exec_driver_sql(
                    "CREATE TABLE events (id SERIAL PRIMARY KEY, capacity INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'published')"
                )
                await conn.exec_driver_sql(
                    "CREATE TABLE bookings (id SERIAL PRIMARY KEY, participant_count INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'confirmed')"
                )
                await conn.exec_driver_sql("INSERT INTO events(capacity) VALUES (-1)")
                await conn.exec_driver_sql("INSERT INTO bookings(participant_count) VALUES (4)")
                migration = (Path(__file__).resolve().parents[1] / "migrations/029_v70_database_invariants.sql").read_text(encoding="utf-8")
                for statement in split_sql_statements(migration):
                    await conn.exec_driver_sql(statement)
                # Existing records are deliberately retained and unrelated status changes still work.
                await conn.exec_driver_sql("UPDATE events SET status='closed' WHERE id=1")
                await conn.exec_driver_sql("UPDATE bookings SET status='cancelled' WHERE id=1")
                result = await conn.execute(text("SELECT capacity FROM events WHERE id=1"))
                assert result.scalar_one() == -1
                result = await conn.execute(text("SELECT participant_count FROM bookings WHERE id=1"))
                assert result.scalar_one() == 4

            async def rejected(statement: str) -> bool:
                try:
                    async with scoped_engine.begin() as conn:
                        await conn.exec_driver_sql(statement)
                except DBAPIError:
                    return True
                return False

            assert await rejected("INSERT INTO events(capacity) VALUES (-2)")
            assert await rejected("INSERT INTO bookings(participant_count) VALUES (4)")
            assert await rejected("UPDATE events SET capacity=-3 WHERE id=1")
            assert await rejected("UPDATE bookings SET participant_count=0 WHERE id=1")
        finally:
            if scoped_engine is not None:
                await scoped_engine.dispose()
            async with admin_engine.begin() as conn:
                await conn.execute(text(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE'))
            await admin_engine.dispose()
    asyncio.run(run())


def test_postgres_concurrent_booking_never_oversubscribes_capacity():
    async def run():
        async with _isolated_postgres() as factory:
            async with factory() as session:
                users = [await _seed_user(session, 700000001, "Alex"), await _seed_user(session, 700000002, "Jamie")]
                event = await _seed_event(session, capacity=2)
                event_id = event.id
                user_ids = [u.id for u in users]
                await session.commit()

            async def attempt(user_id: int, stem: str):
                async with factory() as session:
                    try:
                        booking = await create_booking(
                            session, user_id, event_id,
                            [{"first_name": stem, "last_name": "One"}, {"first_name": stem, "last_name": "Two"}],
                            payment_details_configured=True,
                        )
                        await session.commit()
                        return ("ok", booking.id)
                    except ValueError as exc:
                        await session.rollback()
                        return ("rejected", str(exc))

            results = await asyncio.gather(attempt(user_ids[0], "Alex"), attempt(user_ids[1], "Jamie"))
            assert sum(item[0] == "ok" for item in results) == 1, results
            async with factory() as session:
                rows = (await session.execute(select(Booking).where(Booking.event_id == event_id))).scalars().all()
                seats = sum(int(row.participant_count) for row in rows if row.status in (
                    RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.PENDING_VERIFICATION, RegistrationStatus.CONFIRMED))
                assert len(rows) == 1
                assert seats == 2
    asyncio.run(run())


def test_postgres_concurrent_booking_for_final_single_seat_has_one_winner():
    async def run():
        async with _isolated_postgres() as factory:
            async with factory() as session:
                users = [
                    await _seed_user(session, 700000011, "Morgan"),
                    await _seed_user(session, 700000012, "Jordan"),
                ]
                event = await _seed_event(session, capacity=1)
                event_id = event.id
                user_ids = [user.id for user in users]
                await session.commit()

            async def try_final_seat(user_id: int, name: str):
                async with factory() as session:
                    try:
                        booking = await create_booking(
                            session, user_id, event_id,
                            [{"first_name": name, "last_name": "Seat"}],
                            payment_details_configured=True,
                        )
                        await session.commit()
                        return booking.id
                    except ValueError:
                        await session.rollback()
                        return None

            winners = await asyncio.gather(
                try_final_seat(user_ids[0], "Morgan"),
                try_final_seat(user_ids[1], "Jordan"),
            )
            assert sum(value is not None for value in winners) == 1, winners
            async with factory() as session:
                rows = (await session.execute(
                    select(Booking).where(Booking.event_id == event_id)
                )).scalars().all()
                reserved = sum(
                    int(row.participant_count) for row in rows
                    if row.status in (RegistrationStatus.PENDING_PAYMENT,
                                      RegistrationStatus.PENDING_VERIFICATION,
                                      RegistrationStatus.CONFIRMED)
                )
                assert reserved == 1
    asyncio.run(run())


def test_postgres_check_constraints_reject_invalid_capacity_and_booking_size():
    async def run():
        async with _isolated_postgres() as factory:
            async with factory() as session:
                owner = await _seed_user(session, 700000013, "Constraint")
                bad_event = Event(
                    volume="V70-constraint", title="Invalid capacity", venue="Test",
                    capacity=-1, price_per_person=Decimal("1000"),
                    status=EventStatus.PUBLISHED, registration_open=True,
                )
                session.add(bad_event)
                with pytest.raises(IntegrityError):
                    await session.flush()
                await session.rollback()

            async with factory() as session:
                owner = await _seed_user(session, 700000014, "SeatLimit")
                event = await _seed_event(session, capacity=10)
                session.add(Booking(
                    event_id=event.id, booked_by_user_id=owner.id, participant_count=4,
                    total_amount=Decimal("4000"), status=RegistrationStatus.CONFIRMED,
                ))
                with pytest.raises(IntegrityError):
                    await session.flush()
                await session.rollback()
    asyncio.run(run())


def test_postgres_concurrent_payment_review_allows_only_one_decision():
    async def run():
        async with _isolated_postgres() as factory:
            async with factory() as session:
                owner = await _seed_user(session, 700000003, "Taylor")
                event = await _seed_event(session, capacity=2)
                booking = Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=1,
                    total_amount=Decimal("1000"), status=RegistrationStatus.PENDING_VERIFICATION)
                session.add(booking)
                await session.flush()
                payment = Payment(booking_id=booking.id, amount=Decimal("1000"), status=PaymentStatus.PENDING,
                    receipt_text="test receipt", receipt_uploaded_at=utc_now_naive())
                session.add(payment)
                await session.flush()
                payment_id = payment.id
                token = receipt_review_token(payment)
                fingerprint = receipt_fingerprint(payment)
                await session.commit()

            async def decide(approve: bool):
                async with factory() as session:
                    payment, booking, event = await lock_payment_review_rows(session, payment_id)
                    if (not payment or not booking or not event
                        or payment.status != PaymentStatus.PENDING
                        or booking.status != RegistrationStatus.PENDING_VERIFICATION
                        or receipt_review_token(payment) != token):
                        await session.rollback()
                        return False
                    now = utc_now_naive()
                    payment.status = PaymentStatus.APPROVED if approve else PaymentStatus.REJECTED
                    payment.reviewed_at = now
                    booking.status = RegistrationStatus.CONFIRMED if approve else RegistrationStatus.REJECTED
                    booking.confirmed_at = now if approve else None
                    session.add(PaymentReviewAttempt(booking_id=booking.id, payment_id=payment.id,
                        receipt_fingerprint=fingerprint, decision="approved" if approve else "rejected",
                        reviewer_telegram_id=900000003, attempt_number=1, reviewed_at=now))
                    await session.commit()
                    return True

            results = await asyncio.gather(decide(True), decide(False))
            assert sum(results) == 1, results
            async with factory() as session:
                payment = (await session.execute(select(Payment).where(Payment.id == payment_id))).scalar_one()
                booking = (await session.execute(select(Booking).where(Booking.id == payment.booking_id))).scalar_one()
                attempts = int((await session.execute(select(func.count(PaymentReviewAttempt.id)).where(
                    PaymentReviewAttempt.payment_id == payment_id))).scalar_one())
                assert payment.status in (PaymentStatus.APPROVED, PaymentStatus.REJECTED)
                assert booking.status in (RegistrationStatus.CONFIRMED, RegistrationStatus.REJECTED)
                assert attempts == 1
    asyncio.run(run())


def test_postgres_concurrent_waitlist_claim_does_not_duplicate_capacity_invites():
    async def run():
        async with _isolated_postgres() as factory:
            async with factory() as session:
                event = await _seed_event(session, capacity=1)
                users = [await _seed_user(session, 700000004, "Robin"), await _seed_user(session, 700000005, "Casey")]
                event_id = event.id
                for position, user in enumerate(users, start=1):
                    session.add(WaitlistEntry(event_id=event_id, user_id=user.id, requested_participant_count=1,
                        position=position, status="waiting"))
                await session.commit()

            async def claim():
                async with factory() as session:
                    try:
                        event, entry, user, free = await next_waitlist_candidate(session, event_id)
                        entry.status = "inviting"
                        entry.invitation_expires_at = utc_now_naive() + WAITLIST_INVITATION_TTL
                        await session.commit()
                        return ("claimed", entry.id)
                    except ValueError as exc:
                        await session.rollback()
                        return ("blocked", str(exc))
            results = await asyncio.gather(claim(), claim())
            assert sum(item[0] == "claimed" for item in results) == 1, results
            async with factory() as session:
                invited = int((await session.execute(select(func.count(WaitlistEntry.id)).where(
                    WaitlistEntry.event_id == event_id, WaitlistEntry.status == "inviting"))).scalar_one())
                assert invited == 1
    asyncio.run(run())


def test_postgres_concurrent_cancellation_is_idempotent_and_preserves_payment_history(monkeypatch):
    from app.config import settings
    monkeypatch.setattr(settings, "super_admin_ids", "900000004")
    monkeypatch.setattr(settings, "admin_ids", "")

    async def run():
        async with _isolated_postgres() as factory:
            async with factory() as session:
                owner = await _seed_user(session, 700000006, "Morgan")
                event = await _seed_event(session, capacity=2)
                booking = Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=1,
                    total_amount=Decimal("1000"), status=RegistrationStatus.CONFIRMED, confirmed_at=utc_now_naive())
                session.add(booking)
                await session.flush()
                payment = Payment(booking_id=booking.id, amount=Decimal("1000"), status=PaymentStatus.APPROVED,
                    receipt_text="paid receipt", receipt_uploaded_at=utc_now_naive())
                session.add(payment)
                waiting_user = await _seed_user(session, 700000007, "Jordan")
                session.add(WaitlistEntry(event_id=event.id, user_id=waiting_user.id,
                    requested_participant_count=1, position=1, status="waiting"))
                event_id, booking_id = event.id, booking.id
                await session.commit()

            async def cancel():
                async with factory() as session:
                    try:
                        result = await cancel_event_in_transaction(session, event_id, 900000004)
                        await session.commit()
                        return ("ok", result)
                    except ValueError as exc:
                        await session.rollback()
                        return ("blocked", str(exc))

            results = await asyncio.gather(cancel(), cancel())
            assert sum(item[0] == "ok" for item in results) == 1, results
            async with factory() as session:
                event = (await session.execute(select(Event).where(Event.id == event_id))).scalar_one()
                booking = (await session.execute(select(Booking).where(Booking.id == booking_id))).scalar_one()
                payment = (await session.execute(select(Payment).where(Payment.booking_id == booking_id))).scalar_one()
                wait_status = (await session.execute(select(WaitlistEntry.status).where(WaitlistEntry.event_id == event_id))).scalar_one()
                audit_count = int((await session.execute(select(func.count(AdminAction.id)).where(
                    AdminAction.action == "panel_cancelled", AdminAction.entity_id == event_id))).scalar_one())
                assert event.status == EventStatus.CANCELLED
                assert booking.status == RegistrationStatus.CANCELLED
                assert booking.cancellation_resolution == "action_required"
                assert payment.status == PaymentStatus.APPROVED  # historical outcome is not rewritten
                assert wait_status == "closed"
                assert audit_count == 1
    asyncio.run(run())
