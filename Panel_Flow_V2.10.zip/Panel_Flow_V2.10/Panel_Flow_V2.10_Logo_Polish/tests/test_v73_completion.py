"""Focused regression checks for the V73 completion work."""
from __future__ import annotations

import asyncio
from datetime import timedelta
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.models import Base, UserModerationRecord
from app.services.user_access import has_active_feature_restriction
from app.time_utils import utc_now_naive

ROOT = Path(__file__).resolve().parents[1]


class _AsyncSessionAdapter:
    def __init__(self, sync_session: Session):
        self._session = sync_session

    async def execute(self, statement):
        return self._session.execute(statement)


def test_active_feature_restriction_is_scope_specific_and_expiry_aware():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    try:
        with Session(engine) as sync_session:
            now = utc_now_naive()
            sync_session.add_all([
                UserModerationRecord(
                    target_telegram_id=123456, actor_telegram_id=987654,
                    action="restriction", scope="booking", reason="test active",
                    active=True, expires_at=now + timedelta(hours=3), created_at=now,
                ),
                UserModerationRecord(
                    target_telegram_id=123456, actor_telegram_id=987654,
                    action="restriction", scope="challenges", reason="test expired",
                    active=True, expires_at=now - timedelta(hours=1), created_at=now - timedelta(days=1),
                ),
            ])
            sync_session.commit()
            adapter = _AsyncSessionAdapter(sync_session)
            assert asyncio.run(has_active_feature_restriction(adapter, 123456, "booking")) is True
            assert asyncio.run(has_active_feature_restriction(adapter, 123456, "suggestions")) is False
            assert asyncio.run(has_active_feature_restriction(adapter, 123456, "challenges")) is False
            assert asyncio.run(has_active_feature_restriction(adapter, 123456, "unknown_scope")) is False
    finally:
        engine.dispose()


def test_user_directory_implements_requested_database_filters_and_sorting():
    source = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    assert 'console_account_filter' in source and 'User.telegram_id.in_(suspended_ids)' in source
    assert 'console_participation_filter' in source and 'RegistrationStatus.CONFIRMED' in source
    assert 'console_registration_filter' in source and 'timedelta(days=30)' in source
    assert 'console_xp_min' in source and 'console_xp_max' in source
    assert 'xp_desc' in source and 'xp_asc' in source and 'func.lower' in source
    assert 'parse_telegram_numeric_id(str(search))' in source
    assert '.offset(page * USER_PAGE_SIZE).limit(USER_PAGE_SIZE)' in source


def test_scoped_restrictions_are_checked_at_existing_feature_boundaries():
    booking = (ROOT / "app/services/booking.py").read_text(encoding="utf-8")
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    topics = (ROOT / "app/bot/handlers/topics.py").read_text(encoding="utf-8")
    community = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    assert 'has_active_feature_restriction(session, int(telegram_id), "booking")' in booking
    assert 'has_active_feature_restriction(session, int(message.from_user.id), "suggestions")' in user
    assert 'has_active_feature_restriction(session, int(message.from_user.id), "suggestions")' in topics
    assert 'has_active_feature_restriction(session, int(c.from_user.id), "challenges")' in community
    assert 'has_active_feature_restriction(session, int(message.from_user.id), "challenges")' in community


def test_failed_announcement_retry_never_retries_successful_or_unknown_deliveries():
    source = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    retry = source[source.index("async def unified_announcement_retry_confirm"):source.index('@router.callback_query(F.data.regexp(r"^admin:announce:v72:history:')]
    assert 'AdminAnnouncementDelivery.status == "failed"' in retry
    assert 'delivery.status = "pending"' in retry
    assert 'status == "unknown"' not in retry
    assert 'announcement.status not in {"partial", "completed", "failed"}' in retry
    assert 'announcement_failed_recipients_retry_started' in retry
    assert 'admin:announce:v73:retry_prompt:' in source
    assert 'admin:announce:v73:retry_confirm:' in source


def test_receipt_cancel_button_targets_exact_fsm_booking_and_uses_shared_cancellation_flow():
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert 'def receipt_upload_keyboard(card_number: str | None, booking_id: int)' in keyboard
    assert 'KeyboardButton(text="❌ لغو ارسال رسید")' in keyboard
    assert 'def receipt_cancel_reply_keyboard()' in keyboard
    handler = user[user.index("async def cancel_receipt_button"):user.index('@router.message(Command("cancel"))')]
    assert 'BookingStates.waiting_receipt.state' in handler
    assert 'target_booking_id != active_booking_id' in handler
    assert 'user:payment:cancel_confirm:' in handler
    assert 'user:payment:cancel_back:' in handler
    confirmation = user[user.index('async def _show_receipt_cancel_confirmation'):user.index('@router.callback_query(F.data.regexp(r"^user:payment:cancel_receipt:')]
    assert 'آیا از لغو این پرداخت مطمئن هستید؟' in confirmation
    assert 'secrets.token_hex(4)' in confirmation
    confirm_handler = user[user.index("async def confirm_receipt_cancellation"):user.index("async def back_to_receipt_payment")]
    assert 'await _cancel_receipt_stage_booking(c, state, target_id)' in confirm_handler
    back_handler = user[user.index("async def back_to_receipt_payment"):user.index('@router.message(Command("cancel"))')]
    assert 'await _restore_receipt_payment_prompt(c, state, target_id)' in back_handler
    helper = user[user.index("async def _cancel_receipt_stage_booking"):user.index("async def cancel_receipt_button")]
    assert 'await cancel_booking(session, user.id, int(booking_id))' in helper
    assert 'await reconcile_event_channel_status(bot, event_id)' in helper
    assert 'await notify_waitlist_capacity_available(bot, event_id)' in helper
    assert 'await state.clear()' in helper


def test_admin_profile_exposes_stored_booking_payment_and_community_details():
    source = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    profile_keyboard = source[source.index("def _user_profile_keyboard"):source.index("def _announcement_main_keyboard")]
    booking_view = source[source.index("async def console_user_profile_bookings"):source.index("async def console_user_profile_booking_detail")]
    booking_detail = source[source.index("async def console_user_profile_booking_detail"):source.index("async def console_user_profile_community")]
    community_view = source[source.index("async def console_user_profile_community"):source.index("async def console_role_options")]
    assert "admin:console:profile:bookings:" in profile_keyboard
    assert "admin:console:profile:community:" in profile_keyboard
    assert "selectinload(Booking.event), selectinload(Booking.payment), selectinload(Booking.participants)" in booking_view
    assert 'RegistrationStatus.CANCELLED: "لغوشده"' in booking_view
    assert "Booking.booked_by_user_id == user.id" in booking_view
    assert "receipt_file_name" in booking_detail and "reviewed_by" in booking_detail
    assert "reviewer_telegram_id = int(reviewer.telegram_id) if reviewer else None" in booking_detail
    assert "cancellation_resolution" in booking_detail and "no_show" in booking_detail
    assert "CommunityProfile" in community_view and "AchievementUnlock" in community_view
    assert "ChallengeSubmission" in community_view and "TopicSuggestion" in community_view
    assert "Question" in community_view and "Review" in community_view and "WrappedReport" in community_view
    assert "if not await _is_admin(c.from_user.id)" in booking_view
    assert "if not await _is_admin(c.from_user.id)" in booking_detail
    assert "if not await _is_admin(c.from_user.id)" in community_view


def test_v73_release_migration_is_additive_and_index_is_in_orm_metadata():
    migration = (ROOT / "migrations/031_v73_scoped_moderation_index.sql").read_text(encoding="utf-8").lower()
    model = (ROOT / "app/db/models.py").read_text(encoding="utf-8")
    assert "create index if not exists ix_user_moderation_scope_active_expiry" in migration
    assert "ix_user_moderation_scope_active_expiry" in model
    assert "drop table" not in migration and "truncate" not in migration and "delete from" not in migration
