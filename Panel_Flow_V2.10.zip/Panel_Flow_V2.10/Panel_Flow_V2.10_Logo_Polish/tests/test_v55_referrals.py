"""V55 referral onboarding, reporting, rewards, and command-menu regressions."""
from __future__ import annotations

import asyncio
from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.models import DiscountCode, User
from app.db.migration_utils import split_sql_statements
from app.services.referrals import (
    attribute_referral,
    normalize_referral_code,
    skip_referral_prompt,
)
from app.services.referral_export import build_referral_report_xlsx

ROOT = Path(__file__).resolve().parents[1]


class _AsyncSessionAdapter:
    """Tiny async facade over SQLite's sync Session for exercising referral service rules."""

    def __init__(self, session: Session):
        self.session = session

    async def execute(self, statement):
        return self.session.execute(statement)



def _create_users(engine):
    User.__table__.create(engine)
    session = Session(engine)
    referrer = User(
        telegram_id=123456789,
        telegram_username="sina",
        first_name="Sina",
        last_name="Ziaei",
        display_name="Sina Ziaei",
        phone_number="09120000000",
        referral_prompt_completed=True,
    )
    invitee = User(
        telegram_id=223456789,
        telegram_username="friend",
        first_name="Alex",
        last_name="Friend",
        display_name="Alex Friend",
        phone_number="09121111111",
        referral_prompt_completed=False,
    )
    session.add_all([referrer, invitee])
    session.commit()
    return session, referrer, invitee


def test_referral_code_normalization_accepts_persian_and_arabic_digits():
    assert normalize_referral_code(" ۱۲۳۴۵۶۷۸۹ ") == "123456789"
    assert normalize_referral_code("١٢٣٤٥٦٧٨٩") == "123456789"
    assert normalize_referral_code(None) == ""


def test_referral_attribution_is_one_time_and_stores_internal_referrer_id():
    engine = create_engine("sqlite:///:memory:")
    session, referrer, invitee = _create_users(engine)
    try:
        result = asyncio.run(attribute_referral(
            _AsyncSessionAdapter(session),
            invitee_telegram_id=invitee.telegram_id,
            referral_code=str(referrer.telegram_id),
        ))
        assert result == referrer.id
        session.commit()
        updated = session.execute(select(User).where(User.id == invitee.id)).scalar_one()
        assert updated.referred_by_user_id == referrer.id
        assert updated.referral_prompt_completed is True

        try:
            asyncio.run(attribute_referral(
                _AsyncSessionAdapter(session),
                invitee_telegram_id=invitee.telegram_id,
                referral_code=str(referrer.telegram_id),
            ))
        except ValueError as exc:
            assert str(exc) == "ALREADY_COMPLETED"
        else:
            raise AssertionError("referral attribution must not be repeated")
    finally:
        session.close()
        engine.dispose()


def test_referral_service_rejects_self_referral_and_unknown_codes():
    engine = create_engine("sqlite:///:memory:")
    session, referrer, invitee = _create_users(engine)
    try:
        for code, expected in (
            (str(invitee.telegram_id), "SELF_REFERRAL"),
            ("998877665", "UNKNOWN_REFERRER"),
            ("not-a-number", "INVALID_CODE"),
        ):
            try:
                asyncio.run(attribute_referral(
                    _AsyncSessionAdapter(session),
                    invitee_telegram_id=invitee.telegram_id,
                    referral_code=code,
                ))
            except ValueError as exc:
                assert str(exc) == expected
            else:
                raise AssertionError(f"expected referral code to fail with {expected}")
    finally:
        session.close()
        engine.dispose()


def test_skipping_referral_prompt_is_persisted_without_attribution():
    engine = create_engine("sqlite:///:memory:")
    session, _referrer, invitee = _create_users(engine)
    try:
        asyncio.run(skip_referral_prompt(_AsyncSessionAdapter(session), invitee.telegram_id))
        session.commit()
        updated = session.execute(select(User).where(User.id == invitee.id)).scalar_one()
        assert updated.referral_prompt_completed is True
        assert updated.referred_by_user_id is None
    finally:
        session.close()
        engine.dispose()


def test_referral_excel_has_summary_and_referred_user_sheets_and_literal_text():
    payload = build_referral_report_xlsx(
        [{"name": "=HYPERLINK(\"https://bad.example\")", "telegram_id": 123456789,
          "username": "@sina", "referral_count": 2}],
        [{"referrer_name": "Sina Ziaei", "referrer_telegram_id": 123456789,
          "referred_name": "Alex Friend", "referred_telegram_id": 223456789,
          "username": "@friend", "phone_number": "09121111111", "created_at": None}],
    )
    workbook = load_workbook(BytesIO(payload), data_only=True)
    assert workbook.sheetnames == ["Referral Summary", "Referred Users"]
    summary = workbook["Referral Summary"]
    assert summary.cell(2, 1).value == '=HYPERLINK("https://bad.example")'
    assert summary.cell(2, 2).value == "123456789"
    assert summary.cell(2, 4).value == 2
    details = workbook["Referred Users"]
    assert details.cell(2, 1).value == "Sina Ziaei"
    assert details.cell(2, 3).value == "Alex Friend"
    assert details.cell(2, 6).value == "09121111111"


def test_referral_migration_adds_fields_and_backfills_existing_complete_profiles():
    migration = ROOT / "migrations" / "021_referrals_and_personal_reward_reason.sql"
    sql = migration.read_text(encoding="utf-8")
    statements = split_sql_statements(sql)
    assert len(statements) >= 4
    assert "ADD COLUMN IF NOT EXISTS referred_by_user_id INTEGER" in sql
    assert "ADD COLUMN IF NOT EXISTS referral_prompt_completed BOOLEAN" in sql
    assert "referral_prompt_completed = TRUE" in sql
    assert "ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS reason TEXT" in sql


def test_referral_step_profile_button_admin_report_and_reward_reason_are_wired():
    user_source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    keyboard_source = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    admin_source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    states_source = (ROOT / "app/bot/states.py").read_text(encoding="utf-8")
    main_source = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")

    assert "ProfileStates.waiting_referral_choice" in user_source
    assert "ProfileStates.waiting_referral_code" in user_source
    assert "attribute_referral(" in user_source
    assert 'text="🤝 کد معرفی من"' in keyboard_source
    assert 'callback_data="admin:referrals:export"' in keyboard_source
    assert "build_referral_report_xlsx" in admin_source
    assert "waiting_personal_reason" in states_source
    assert "reason=(str(draft.get(\"reason\")" in admin_source
    assert "علت هدیه" in user_source
    assert "پنل آینده · پیش‌نویس" in user_source
    assert 'BotCommand(command="admin"' not in main_source
    assert '@router.message(Command("admin"))' in admin_source


def test_referral_code_callback_resumes_deep_link_with_the_actual_user_identity():
    user_source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert "pending_start_payload" in user_source
    assert "telegram_user=c.from_user" in user_source
    assert "show_event_details_from_message(" in user_source
    assert "replace_message_id=replace_message_id" in user_source
    assert "_user_is_waitlisted(session, event.id, int(viewer.id))" in user_source


def test_archived_panel_detaches_discount_scopes_and_disables_code_without_eligible_panels():
    source = (ROOT / "app/services/discounts.py").read_text(encoding="utf-8")
    function = source.split("async def detach_event_discount_codes", 1)[1].split("\ndef code_label", 1)[0]
    assert 'code.active = False' in function
    assert 'code.disabled_reason = "No eligible panels remain"' in function
    assert 'code.kind == "personal"' in function


def test_referral_service_rejects_incomplete_referrer_profile():
    engine = create_engine("sqlite:///:memory:")
    session, referrer, invitee = _create_users(engine)
    try:
        referrer.phone_number = None
        session.commit()
        try:
            asyncio.run(attribute_referral(
                _AsyncSessionAdapter(session),
                invitee_telegram_id=invitee.telegram_id,
                referral_code=str(referrer.telegram_id),
            ))
        except ValueError as exc:
            assert str(exc) == "INCOMPLETE_REFERRER"
        else:
            raise AssertionError("incomplete referrer profiles must not be attributed")
    finally:
        session.close()
        engine.dispose()


def test_referral_count_service_counts_only_successfully_attributed_users():
    from app.services.referrals import count_referrals_for_telegram_id

    engine = create_engine("sqlite:///:memory:")
    session, referrer, invitee = _create_users(engine)
    try:
        invitee.referred_by_user_id = referrer.id
        invitee.referral_prompt_completed = True
        session.commit()

        assert asyncio.run(count_referrals_for_telegram_id(
            _AsyncSessionAdapter(session), referrer.telegram_id
        )) == 1
        assert asyncio.run(count_referrals_for_telegram_id(
            _AsyncSessionAdapter(session), 998877665
        )) == 0
    finally:
        session.close()
        engine.dispose()
