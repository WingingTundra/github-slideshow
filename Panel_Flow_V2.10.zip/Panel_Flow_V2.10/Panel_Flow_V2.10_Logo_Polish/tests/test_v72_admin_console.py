"""Source/model QA for V72 features and current V74 release markers."""
from pathlib import Path

from app.db.models import Base, UserRole

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


def test_v72_and_v202_roles_include_the_separate_admin_level():
    assert {role.value for role in UserRole} == {"super_admin", "admin", "host", "participant"}


def test_v72_additive_models_are_registered():
    expected = {
        "admin_user_notes", "user_moderation_records", "admin_private_messages",
        "admin_announcements", "admin_announcement_deliveries",
    }
    assert expected <= set(Base.metadata.tables)
    assert "submission_status" in Base.metadata.tables["events"].c
    assert "submission_feedback" in Base.metadata.tables["events"].c


def test_v72_migration_is_additive_and_tracks_deliveries_idempotently():
    migration = (ROOT / "migrations/030_v72_admin_console_roles_moderation_announcements.sql").read_text(encoding="utf-8").lower()
    assert "alter table events add column if not exists submission_status" in migration
    assert "create table if not exists admin_announcements" in migration
    assert "create table if not exists admin_announcement_deliveries" in migration
    assert "uq_admin_announcement_recipient unique (announcement_id, telegram_id)" in migration
    assert "drop table" not in migration
    assert "truncate" not in migration
    assert "delete from users" not in migration
    assert "delete from bookings" not in migration


def test_v72_router_order_prioritizes_new_specialized_flows():
    main = (APP / "bot/main.py").read_text(encoding="utf-8")
    assert main.index("include_router(admin_console_router)") < main.index("include_router(admin_router)")


def test_v72_role_and_panel_actions_are_revalidated_server_side():
    console = (APP / "bot/handlers/admin_console.py").read_text(encoding="utf-8")
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "async def _can_manage_role_change" in console
    assert "_is_owner(user.telegram_id)" in console
    assert "event.host_id != actor.id" in admin
    assert "submission_status not in {\"draft\", \"rejected\"}" in admin
    assert "async def is_admin" in admin


def test_v72_confirmed_roster_and_show_all_are_distinct_and_admin_only():
    console = (APP / "bot/handlers/admin_console.py").read_text(encoding="utf-8")
    assert 'view="confirmed"' in console
    assert 'view="all"' in console
    assert 'RegistrationStatus.CONFIRMED' in console
    assert 'participants_filter' in console
    assert 'فهرست افراد ثبت‌نام‌شده فقط برای مدیران مجاز است.' in console


def test_v72_announcements_share_persistence_delivery_and_manual_confirmation():
    console = (APP / "bot/handlers/admin_console.py").read_text(encoding="utf-8")
    assert "async def _persist_announcement_preview" in console
    assert "async def _collect_announcement_recipients" in console
    assert "async def _render_announcement_preview" in console
    assert 'callback_data=f"admin:announce:v72:send:{announcement_id}"' in console
    assert 'status == "preview"' in console
    assert 'status="sending"' in console
    assert "admin_announcement_deliveries" not in console  # ORM models, not raw-table duplication.
    assert "schedule" not in console.lower() or "scheduled" in console.lower()  # no scheduler path introduced


def test_v74_release_docs_and_markers_match_migration():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    startup = (APP / "db/init.py").read_text(encoding="utf-8")
    backup = (ROOT / "scripts/backup.sh").read_text(encoding="utf-8")
    assert readme.startswith("# Panel Flow — V2.06")
    assert "030_v72_admin_console_roles_moderation_announcements.sql" in readme
    assert "031_v73_scoped_moderation_index.sql" in readme
    assert "Panel Flow V97 database initialization started" in startup
    assert "release=V97" in backup
