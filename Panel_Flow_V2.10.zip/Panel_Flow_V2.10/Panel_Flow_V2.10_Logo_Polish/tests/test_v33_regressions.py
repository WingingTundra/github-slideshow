from __future__ import annotations

import asyncio
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.models import (
    Base, Booking, DiscountCode, DiscountCodeEvent, DiscountRedemption,
    Event, EventStatus, RegistrationStatus, User, UserRole,
)
from app.services.discounts import purge_inactive_discount_codes

ROOT = Path(__file__).resolve().parents[1]


class AsyncSessionAdapter:
    def __init__(self, sync: Session):
        self.sync = sync

    async def execute(self, statement):
        return self.sync.execute(statement)

    async def get(self, model, ident, **kwargs):
        return self.sync.get(model, ident)

    def add(self, obj):
        self.sync.add(obj)

    async def commit(self):
        self.sync.commit()



def test_purge_inactive_codes_deletes_history_but_preserves_booking_and_active_codes():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    sync = Session(engine)
    adapter = AsyncSessionAdapter(sync)
    try:
        owner = User(telegram_id=33001, display_name="Panel Owner", role=UserRole.PARTICIPANT)
        sync.add(owner)
        sync.flush()
        event = Event(
            volume="V33", title="Purge Test", event_day_label="Saturday",
            event_date_label="12 October 2026", start_time_label="18:00", end_time_label="20:00",
            venue="Test Venue", capacity=8, price_per_person=Decimal("100000"),
            status=EventStatus.PUBLISHED, registration_open=True, archived=False,
        )
        sync.add(event)
        sync.flush()
        inactive = DiscountCode(
            code="OLD20", label="OLD20", kind="public", discount_type="percent",
            discount_value=Decimal("20"), requires_approval=False, active=False,
            max_redemptions=5, usage_policy="once_total", created_by_telegram_id=33000,
            disabled_at=datetime(2026, 9, 1), disabled_reason="Expired manually",
        )
        active = DiscountCode(
            code="KEEP10", label="KEEP10", kind="public", discount_type="percent",
            discount_value=Decimal("10"), requires_approval=False, active=True,
            max_redemptions=5, usage_policy="once_total", created_by_telegram_id=33000,
        )
        sync.add_all([inactive, active])
        sync.flush()
        sync.add_all([
            DiscountCodeEvent(discount_code_id=inactive.id, event_id=event.id),
            DiscountCodeEvent(discount_code_id=active.id, event_id=event.id),
        ])
        booking = Booking(
            event_id=event.id, booked_by_user_id=owner.id, participant_count=1,
            total_amount=Decimal("80000"), contact_phone="+989121234567",
            status=RegistrationStatus.CONFIRMED, created_at=datetime(2026, 9, 2),
            discount_code_id=inactive.id, discount_code_snapshot="OLD20", discount_amount=Decimal("20000"),
        )
        sync.add(booking)
        sync.flush()
        redemption = DiscountRedemption(
            discount_code_id=inactive.id, code_snapshot="OLD20", event_id=event.id,
            event_label_snapshot="V33 — Purge Test", user_telegram_id=33001,
            status="redeemed", participant_count=1, booking_id=booking.id,
            original_total=Decimal("100000"), discount_amount=Decimal("20000"), final_total=Decimal("80000"),
        )
        sync.add(redemption)
        sync.commit()
        inactive_id, active_id, booking_id, redemption_id = inactive.id, active.id, booking.id, redemption.id

        deleted_codes, deleted_redemptions = asyncio.run(purge_inactive_discount_codes(adapter))
        sync.commit()

        assert deleted_codes == 1
        assert deleted_redemptions == 1
        assert sync.get(DiscountCode, inactive_id) is None
        assert sync.get(DiscountCode, active_id) is not None
        assert sync.execute(select(DiscountCodeEvent).where(DiscountCodeEvent.discount_code_id == inactive_id)).scalars().all() == []
        assert sync.execute(select(DiscountCodeEvent).where(DiscountCodeEvent.discount_code_id == active_id)).scalars().all()
        assert sync.get(DiscountRedemption, redemption_id) is None
        kept_booking = sync.get(Booking, booking_id)
        assert kept_booking is not None
        assert kept_booking.status == RegistrationStatus.CONFIRMED
        assert kept_booking.total_amount == Decimal("80000")
        assert kept_booking.discount_amount == Decimal("20000")
        assert kept_booking.discount_code_snapshot == "OLD20"
        assert kept_booking.discount_code_id is None
        assert kept_booking.contact_phone == "+989121234567"

        assert asyncio.run(purge_inactive_discount_codes(adapter)) == (0, 0)
    finally:
        sync.close()
        engine.dispose()


def test_v33_user_copy_and_one_time_phone_flow():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    content = (ROOT / "app/bot/content.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")

    participant_flow = user.split("async def participant_name", 1)[1].split("async def _append_current_non_booker_and_continue", 1)[0]
    assert "نام و نام خانوادگی نفر ۱ (خودتان) را وارد کنید:" not in user
    assert "waiting_booker_phone" not in participant_flow
    assert "booker_phone=user.phone_number" in user
    assert "شمارهٔ تماس خود را وارد کنید.\\n" in content
    assert "<i>شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in content
    assert "phone_number_prompt()" in user
    assert "لازم نیست با شمارهٔ حساب تلگرام شما یکسان باشد." not in user

    code_prompt = user.split("async def booking_discount_enter", 1)[1].split("async def booking_discount_skip", 1)[0]
    assert "کد را دقیقاً همان‌طور که دریافت کرده‌اید وارد کنید." in code_prompt
    assert "PANEL20" not in code_prompt and "GIRLSDAY50" not in code_prompt
    assert "لطفاً تا بررسی درخواست و اعلام نتیجه توسط مدیر منتظر بمانید." in user
    assert "discount_request_user_keyboard," in admin.split("from app.bot.keyboards import (", 1)[1].split(")", 1)[0]


def test_v33_admin_volume_prompt_and_confirmed_inactive_cleanup_are_wired():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    discounts = (ROOT / "app/services/discounts.py").read_text(encoding="utf-8")

    prompt = admin.split("async def create_event_start", 1)[1].split("async def create_volume", 1)[0]
    assert "شماره یا نام Volume را به انگلیسی وارد کنید." in prompt
    assert "مثال: 21، Movie Night یا Nature." in prompt
    assert 'await _creation_prompt(c.message, state, prompt)' in prompt
    assert 'event_creation_token=secrets.token_hex(16)' in prompt
    assert 'callback_data="admin:event:create:cancel"' in admin.split('def admin_event_creation_step_keyboard', 1)[0] or 'admin:event:create:cancel' in admin
    assert 'callback_data="admin:discount:clear-inactive:start"' in admin
    assert 'F.data == "admin:discount:clear-inactive:confirm"' in admin
    assert 'text="🗑 پاک‌سازی همه کدهای غیرفعال"' in admin
    assert "purge_inactive_discount_codes" in admin and "purge_inactive_discount_codes" in discounts
    assert "رزروها، وضعیت پرداخت و مبلغ ثبت‌شدهٔ رزروها حفظ می‌شوند." in admin


def test_v33_discount_approval_keyboard_import_and_profile_order_are_explicit():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    view = admin.split("async def admin_discount_request_view", 1)[1].split("async def _resolve_discount_request", 1)[0]
    approve = admin.split("async def _resolve_discount_request", 1)[1].split('@router.callback_query(F.data.regexp(r"^admin:discount:request:approve:', 1)[0]

    assert "discount_request_user_keyboard," in admin.split("from app.bot.keyboards import (", 1)[1].split(")", 1)[0]
    assert "<b>رزروکننده:</b>" in view
    assert "<b>شناسه تلگرام:</b> <a href=\\\"tg://user?id=" in view
    assert "https://t.me/{safe_username}" in view
    assert "user_keyboard = discount_request_user_keyboard(redemption_id, approved=True)" in approve
    assert "edit_message_text(" in approve and "send_message(" in approve
