from pathlib import Path

import pytest
from pydantic import ValidationError

from app.db.models import Base, DiscussionSeries, DiscussionSeriesEvent

ROOT = Path(__file__).resolve().parents[1]


def test_v206_discussion_series_models_are_ordered_and_tenant_owned():
    assert DiscussionSeries.__tablename__ == "discussion_series"
    assert DiscussionSeriesEvent.__tablename__ == "discussion_series_events"
    assert "host_user_id" in DiscussionSeries.__table__.c
    assert "organization_id" in DiscussionSeries.__table__.c
    constraints = {constraint.name for constraint in DiscussionSeriesEvent.__table__.constraints}
    assert "uq_discussion_series_event" in constraints
    assert "uq_discussion_series_position" in constraints
    assert "ck_discussion_series_position_nonnegative" in constraints
    assert DiscussionSeries.__table__.metadata is Base.metadata


def test_v206_series_migration_is_additive_and_rollback_is_manual_only():
    migration = (ROOT / "migrations/053_v206_discussion_series.sql").read_text(encoding="utf-8")
    rollback = ROOT / "migrations/053_v206_discussion_series_rollback.sql.disabled"
    assert "CREATE TABLE IF NOT EXISTS discussion_series" in migration
    assert "CREATE TABLE IF NOT EXISTS discussion_series_events" in migration
    assert "ON DELETE CASCADE" in migration
    assert "ON DELETE SET NULL" in migration
    assert "DROP TABLE" not in migration.upper()
    assert rollback.exists()
    assert "DROP TABLE" in rollback.read_text(encoding="utf-8").upper()


def test_v206_api_routes_are_registered_once():
    from app.api import api

    paths = api.openapi()["paths"]
    expected = {
        "/api/v1/series",
        "/api/v1/series/{slug}",
        "/api/v1/staff/host/series",
        "/api/v1/staff/host/series/{series_id}",
        "/api/v1/staff/host/events/{event_id}/participants",
        "/api/v1/staff/host/events/{event_id}/attendance",
        "/api/v1/staff/host/events/{event_id}/waitlist",
        "/api/v1/staff/host/events/{event_id}/attendance/qr",
        "/api/v1/staff/host/events/{event_id}/attendance-history",
        "/api/v1/staff/host/events/{event_id}/participants/{participant_id}/attendance",
        "/api/v1/me/attendance",
    }
    assert expected.issubset(paths)
    registrations = [
        (route.path, method)
        for route in api.routes
        if hasattr(route, "methods")
        for method in route.methods or ()
    ]
    assert len(registrations) == len(set(registrations))


def test_v206_series_input_rejects_duplicate_or_too_few_event_ids():
    from app.http_api.website_routes import HostDiscussionSeriesInput

    assert HostDiscussionSeriesInput(title="Philosophy in Practice", event_ids=[1, 2])
    with pytest.raises(ValidationError):
        HostDiscussionSeriesInput(title="A series", event_ids=[1])
    with pytest.raises(ValidationError):
        HostDiscussionSeriesInput(title="A series", event_ids=[1, 1])
    with pytest.raises(ValidationError):
        HostDiscussionSeriesInput(title=" ", event_ids=[1, 2])


def test_v206_host_attendance_routes_are_scoped_and_audited():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    auth = source.split("async def _authorize_host_owned_event", 1)[1].split("@router.get(\"/staff/host/events/{event_id}/participants\")", 1)[0]
    assert 'getattr(user.role, "value", user.role)' in auth
    assert 'event.host_id != user.id' in auth
    assert 'authorize_event_manage(session, user, event, allow_platform_admin=False)' in auth

    toggle = source.split("async def host_toggle_event_attendance", 1)[1].split("@router.post(\"/staff/host/events/{event_id}/attendance/qr\")", 1)[0]
    assert "with_for_update()" in toggle
    assert "attendance_checkin_token_hash = None" in toggle
    assert "attendance_checkin_code_hash = None" in toggle
    assert "PlatformAuditLog" in toggle

    qr = source.split("async def host_create_attendance_qr", 1)[1].split("@router.get(\"/staff/host/events/{event_id}/attendance-history\")", 1)[0]
    assert "await session.rollback()" in qr  # no DB transaction over Telegram network I/O
    assert "target_event_id = int(event.id)" in qr
    assert "await bot.get_me()" in qr
    assert 'start=checkin_{target_event_id}_{token_value}' in qr
    assert "with_for_update()" in qr
    assert "ATTENDANCE_NOT_ENABLED" in qr
    assert 'response.headers["Cache-Control"] = "private, no-store, max-age=0"' in qr
    assert "attendance_qr_rotated" in qr


def test_v206_host_roster_is_private_and_contains_waitlist_and_lifecycle_settings():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    roster = source.split("async def host_event_participants", 1)[1].split("@router.patch(\"/staff/host/events/{event_id}/attendance\")", 1)[0]
    assert "_authorize_host_owned_event(session, user, event_id)" in roster
    assert '"waitlist": waitlist' in roster
    assert '"waitlist_enabled": bool(event.waitlist_enabled)' in roster
    assert '"registration_open": bool(event.registration_open)' in roster
    assert '"attendance_enabled": bool(event.attendance_enabled)' in roster
    assert 'WaitlistEntry.status.in_(("waiting", "invited", "inviting"))' in roster
    assert 'waitlist_offset: int = Query(default=0' in roster
    assert '"waitlist_total": waitlist_total' in roster
    assert '.offset(waitlist_offset).limit(limit)' in roster
    waitlist_toggle = source.split("async def host_toggle_event_waitlist", 1)[1].split("@router.post(\"/staff/host/events/{event_id}/attendance/qr\")", 1)[0]
    assert "with_for_update()" in waitlist_toggle
    assert "event.waitlist_enabled = bool(payload.enabled)" in waitlist_toggle
    assert "host.event_waitlist_enabled" in waitlist_toggle


def test_v206_qr_checkin_is_bound_to_the_confirmed_booker_and_event():
    source = (ROOT / "app/bot/handlers/attendance.py").read_text(encoding="utf-8")
    checkin = source.split("async def _checkin_view", 1)[1].split("async def _show_checkin", 1)[0]
    assert "event.attendance_enabled" in checkin
    assert "checkin_proof_is_valid(event, proof, proof_kind)" in checkin
    security = (ROOT / "app/services/attendance_security.py").read_text(encoding="utf-8")
    assert "secrets.compare_digest(expected, proof_digest(proof))" in security
    assert "Booking.booked_by_user_id == int(user_id)" in checkin
    assert "Booking.status == RegistrationStatus.CONFIRMED" in checkin
    marking = source.split("async def checkin_mark", 1)[1].split("@router.callback_query", 1)[0] if "async def checkin_mark" in source else source
    assert "Booking.booked_by_user_id == user.id" in marking
    assert 'source="qr" if proof_kind == "t" else "code"' in marking


def test_v206_admin_and_host_contact_flows_reuse_existing_preview_send_ledger():
    source = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    auth = source.split("async def _authorized_event_actor", 1)[1].split("async def _setting_value", 1)[0]
    assert "_is_admin(telegram_id)" in auth
    assert "_host_owns_event(session, telegram_id, event_id)" in auth
    menu = source.split("async def panel_announcement_menu", 1)[1].split("async def panel_global_announcement_start", 1)[0]
    assert "_authorized_event_actor" in menu
    assert "_panel_announcement_keyboard(event_id, can_promote)" in menu
    keyboard = source.split("def _panel_announcement_keyboard", 1)[1].split("def _confirmed_statuses", 1)[0]
    assert 'callback_data=f"admin:announce:v72:purposepanel:{event_id}:custom"' in keyboard
    assert "AdminAnnouncement" in source
    assert 'announcement.status != "preview"' in source


def test_v206_member_participation_only_counts_attended_confirmed_participants():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    history = source.split("async def my_verified_attendance", 1)[1].split("@router.", 1)[0]
    assert "AttendanceStatus.ATTENDED" in history
    assert "RegistrationStatus.CONFIRMED" in history
    assert "Booking.booked_by_user_id == user.id" in history


def test_v206_frontend_surfaces_series_qr_waitlist_contact_and_history():
    source = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    assert 'path="/series"' in source
    assert 'path="/series/:slug"' in source
    assert "HostSeriesPanel" in source
    assert "Generate / rotate QR" in source
    assert "Contact registered participants" in source
    assert "Waitlist" in source
    assert "Verified attendance history" in source
    assert "ListOrdered" in source and "QrCode" in source


def test_v206_series_pages_are_in_sitemap_and_private_roster_is_not_public():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    sitemap = source.split("async def seo_sitemap", 1)[1].split("@router.get(\"/seo/validate\")", 1)[0]
    assert "DiscussionSeries.slug" in sitemap
    assert 'entries.extend((f"/series/{slug}", None)' in sitemap
    # The only roster endpoint is under authenticated host staff routes.
    assert '@router.get("/staff/host/events/{event_id}/participants")' in source
    assert '@router.get("/events/{event_id}/participants")' not in source


def test_v206_web_event_creation_exposes_optional_waitlist_setting():
    from app.http_api.website_routes import EventCreateInput

    base = {"volume": "Vol 1", "title": "A real discussion", "day": "Friday",
            "date": "3 Tir", "start_time": "18:00", "capacity": 20,
            "price_per_person": 0, "city": "Mashhad", "venue": "A venue"}
    assert EventCreateInput(**base).waitlist_enabled is True
    assert EventCreateInput(**base, waitlist_enabled=False).waitlist_enabled is False
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    create = source.split("async def staff_create_event", 1)[1].split("@router.", 1)[0]
    assert "waitlist_enabled=bool(payload.waitlist_enabled)" in create
    frontend = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    assert "checked={form.waitlist_enabled}" in frontend
    assert "Enable an optional waitlist" in frontend
    assert "waitlist_offset=${waitlistOffset}" in frontend
    assert "host-list-pagination" in frontend


def test_v206_host_and_admin_contact_links_open_the_selected_panel_flow():
    frontend = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    assert "?start=pfcontact_${eventId}" in frontend
    assert "?start=pfcontact_${event.id}" in frontend
    assert "download={`panelflow-checkin-${eventId}.png`}" in frontend
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert 'payload.startswith("pfcontact_")' in user


def test_v206_waitlist_disable_is_audited_and_checked_before_notifications():
    api_source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    update = api_source.split("async def staff_update_event", 1)[1].split("@router.", 1)[0]
    assert "waitlist_enabled" in update
    admin_source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "host may have paused the waitlist" in admin_source
    service_source = (ROOT / "app/services/waitlist.py").read_text(encoding="utf-8")
    assert "point of delivery" in service_source
    assert "not event.waitlist_enabled" in service_source

def test_v206_admin_event_table_offers_optional_waitlist_control():
    frontend = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    assert "const toggleWaitlist = async (event:any)" in frontend
    assert "Pause waitlist" in frontend
    assert "Enable waitlist" in frontend


def test_v206_series_direct_navigation_is_allowed_by_nginx():
    nginx = (ROOT / "website/nginx.conf").read_text(encoding="utf-8")
    assert "series/?" in nginx
    assert "series/[a-z0-9]+(?:-[a-z0-9]+)*/?" in nginx
    assert "(events|cities|series|organizations|hosts" in nginx
