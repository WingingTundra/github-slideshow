from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_shop_offers_default_inactive_and_revision_bound_confirmations():
    models = (ROOT / "app/db/models.py").read_text()
    handlers = (ROOT / "app/bot/handlers/v77_features.py").read_text()
    assert 'default=False, server_default="false"' in models
    assert "revision: Mapped[int]" in models
    assert "confirm:id:{offer_id}:rev:{revision}" in handlers
    assert "expected_revision is None" in handlers
    assert "offer.revision = int(getattr(offer, \"revision\", 1) or 1) + 1" in handlers

def test_answer_notifications_use_lease_and_recovery():
    models = (ROOT / "app/db/models.py").read_text()
    handlers = (ROOT / "app/bot/handlers/admin.py").read_text()
    migration = (ROOT / "migrations/044_v95_reliability_controls.sql").read_text()
    assert "answer_notification_claimed_at" in models
    assert 'answer_notification_status = "sending"' in handlers
    assert "timedelta(minutes=5)" in handlers
    assert "answer_revision" in migration

def test_xp_pause_does_not_suppress_activity_progression():
    community = (ROOT / "app/bot/handlers/community.py").read_text()
    user = (ROOT / "app/bot/handlers/user.py").read_text()
    assert "profile.challenge_participations = int(profile.challenge_participations or 0) + 1" in community
    assert "profile.correct_answers += 1" in community
    assert "profile.reviews_submitted += 1" in user

def test_settings_changes_are_audited():
    community = (ROOT / "app/bot/handlers/community.py").read_text()
    assert 'action="community_setting_changed"' in community
