from __future__ import annotations

import ast
import logging
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def function_source(text: str, name: str) -> str:
    tree = ast.parse(text)
    node = next(item for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name)
    return ast.get_source_segment(text, node) or ""


def test_user_main_menu_hierarchy_profile_and_suggestions_submenu():
    keyboards = source("app/bot/keyboards.py")
    main = function_source(keyboards, "main_menu")
    assert main.index('text="🏠 پنل‌های پیش‌رو"') < main.index('text="🎟 ثبت‌نام‌های من"')
    assert '[InlineKeyboardButton(text="👤 پروفایل من"' in main
    assert 'text="📄 سؤالات پنل‌ها"' in main
    assert 'text="💡 پیشنهادها", callback_data="user:suggestions"' in main
    assert main.count('text="📝 ثبت نظر"') == 1
    assert main.index('text="📝 ثبت نظر"') < main.index('text="🏆 لیدربورد و چالش‌ها"')
    assert main.count('text="💬 جامعه و دربارهٔ ما"') == 1
    profile = function_source(keyboards, "profile_keyboard")
    assert 'text="📱 تغییر شماره"' in profile and 'text="✏️ تغییر نام"' in profile
    assert 'text="🤝 کد معرفی من"' in profile
    assert 'text="🔙 بازگشت به منوی اصلی"' in profile
    suggestions = function_source(keyboards, "suggestions_keyboard")
    assert 'callback_data="user:submit_question"' in suggestions
    assert 'callback_data="user:topics"' in suggestions
    user = source("app/bot/handlers/user.py")
    assert '@router.callback_query(F.data == "user:suggestions")' in user


def test_past_panels_copy_and_review_action_are_panel_specific_and_eligible():
    v77 = source("app/bot/handlers/v77_features.py")
    assert 'تاریخچهٔ پنل‌های برگزارشده را اینجا ببینید.' in v77
    assert 'در حال حاضر پنل گذشته‌ای برای نمایش وجود ندارد.' in v77
    detail = function_source(v77, "past_panels_detail")
    assert 'callback_data=f"user:review:event:{eid}"' in detail
    assert "RegistrationStatus.CONFIRMED" in detail
    assert "event.feedback_enabled" in detail
    assert "existing_review is None" in detail


def test_entertainment_and_about_hubs_remove_requested_public_actions():
    keys = source("app/bot/keyboards.py")
    entertainment = function_source(keys, "community_menu_keyboard")
    assert entertainment.index('text="🏆 لیدربورد ⁦Panel Flow⁩"') < entertainment.index('text="🎯 چالش‌ها"')
    assert "Quick Fun" not in entertainment
    community = source("app/bot/handlers/community.py")
    home = function_source(community, "render_community_home")
    assert "Quick Fun" not in home
    about_keyboard = function_source(keys, "community_keyboard")
    assert "پشتیبانی انسانی" not in about_keyboard
    assert "پنل‌های پیش‌رو" not in about_keyboard
    assert all(label in about_keyboard for label in ("Telegram Channel", "Telegram Group", "Instagram", "Website"))
    user = source("app/bot/handlers/user.py")
    assert "🔗 لینک‌های رسمی" not in user
    assert "برای دسترسی به کانال، گروه" not in user


def test_panel_creation_prompts_are_new_messages_with_back_cancel_on_retries():
    admin = source("app/bot/handlers/admin.py")
    prompt = function_source(admin, "_creation_prompt")
    retry = function_source(admin, "_creation_retry")
    back = function_source(admin, "_creation_step_back")
    assert "message.answer" in prompt and "edit_message_text" not in prompt
    assert "_creation_prompt" in retry
    assert "questions_input_keyboard" in prompt
    assert "admin_event_creation_step_keyboard" in prompt
    assert "await state.get_data()" in back
    assert "await state.set_state(destination)" in back
    assert '"قیمت کامل ثبت‌نام بدون سفارش اجباری از منوی کافه را به تومان وارد کنید.' in admin
    assert 'برای غیرفعال‌کردن این گزینه، فقط «-» یا «0» بفرستید.' in admin
    assert "disable_create_alternative_price" in admin  # Legacy callback remains harmlessly backward-compatible.
    wizard = admin.split('@router.message(AdminEventStates.alternative_price)', 1)[1].split('@router.message(AdminEventStates.waitlist)', 1)[0]
    assert '"-", "–", "0", "۰"' in wizard
    assert "admin:event:create:back" in admin and "admin:event:create:cancel" in admin
    assert "event_creation_prompt_message_id" in admin
    assert "_validate_creation_callback" in admin


def test_incomplete_signup_button_and_receipt_cancel_have_explicit_confirmation():
    user = source("app/bot/handlers/user.py")
    admin = source("app/bot/handlers/admin.py")
    assert 'text="لغو فرایند"' in admin
    assert "رزروها، پرداخت‌ها، XP و پنل‌های ثبت‌شده حذف نمی‌شوند" in admin
    cancel = function_source(user, "cancel_receipt_button")
    confirm = function_source(user, "confirm_receipt_cancellation")
    back = function_source(user, "back_to_receipt_payment")
    confirmation = function_source(user, "_show_receipt_cancel_confirmation")
    assert "مطمئن هستید؟" in confirmation
    assert "user:payment:cancel_confirm:" in confirmation
    assert "user:payment:cancel_back:" in confirmation
    assert "secrets.token_hex(4)" in confirmation
    assert "_cancel_receipt_stage_booking" in confirm
    assert "_restore_receipt_payment_prompt" in back
    restore = function_source(user, "_restore_receipt_payment_prompt")
    assert "BookingStates.waiting_receipt.state" in restore
    assert "booking.booked_by_user_id != user.id" in restore


def test_admin_card_number_is_full_and_main_sections_are_grouped_in_persian():
    admin = source("app/bot/handlers/admin.py")
    assert "def _full_card" in admin
    settings_text = function_source(admin, "_admin_settings_text")
    assert "_full_card(values.get(\"payment_card_number\", \"\"))" in settings_text
    keys = source("app/bot/keyboards.py")
    menu = function_source(keys, "admin_menu")
    assert menu.index('text="📋 مدیریت پنل‌ها"') < menu.index('text="📣 اطلاع‌رسانی‌ها"')
    assert 'text="📣 اطلاع‌رسانی‌ها"' in menu
    assert 'text="🧾 مشاهدهٔ رسیدها"' in menu
    assert 'text="🎟 کدهای تخفیف"' in menu
    assert 'text="🎟 درخواست‌های تخفیف"' in menu
    assert 'text="🎯 مدیریت چالش‌ها"' in menu
    assert 'text="📥 مرکز رسیدگی"' in menu
    content = function_source(keys, "admin_content_hub_keyboard")
    assert 'تیکت' not in content
    assert "به‌روزرسانی‌های کانال" not in content
    announce = source("app/bot/handlers/admin_console.py")
    announce_keyboard = function_source(announce, "_announcement_main_keyboard")
    assert announce_keyboard.index('text="📣 انتشار معرفی یک پنل در کانال"') < announce_keyboard.index('text="👥 پیام به ثبت‌نام‌شده‌ها"')
    assert 'callback_data="admin:channel_updates"' in announce_keyboard
    assert "تاریخچهٔ کلی" not in announce_keyboard
    assert 'callback_data=f"admin:announce:v89:history:{event_id}:0"' in function_source(announce, "_panel_announcement_keyboard")
    channel_preview = function_source(announce, "panel_channel_announcement_preview")
    channel_send = function_source(announce, "publish_panel_channel_announcement")
    assert "_panel_channel_post_text(event)" in channel_preview
    assert "_channel_post_keyboard(post_id, registration_url)" in channel_preview
    assert "send_message(" in channel_send and "reply_markup=_channel_post_keyboard" in channel_send
    assert "can_post_messages" in channel_send
    assert "_process_unified_announcement(c.bot, announcement_id)" in function_source(announce, "unified_announcement_send")


def test_announcement_history_cleanup_is_panel_scoped_and_dashboard_uses_real_metrics():
    admin = source("app/bot/handlers/admin.py")
    archive = admin.split("async def event_archive_confirm", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:archive:cancel:"))', 1)[0]
    delete = admin.split("async def event_delete_confirm", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:delete:cancel:"))', 1)[0]
    assert "delete(AdminAnnouncement).where(AdminAnnouncement.event_id == eid)" in archive
    assert "delete(AdminAnnouncement).where(AdminAnnouncement.event_id == eid)" in delete
    assert "delete(PanelAnnouncementPost).where(PanelAnnouncementPost.event_id == eid)" in archive
    assert "delete(AnnouncementBroadcast).where(AnnouncementBroadcast.event_id == eid)" in archive
    assert "delete(PanelAnnouncementPost).where(PanelAnnouncementPost.event_id == eid)" in delete
    assert "delete(AnnouncementBroadcast).where(AnnouncementBroadcast.event_id == eid)" in delete
    dashboard = source("app/bot/handlers/admin_features.py")
    assert "زمان آخرین فعالیت کاربران به‌طور قابل اتکا ذخیره نمی‌شود" in dashboard
    assert "تاریخ پنل‌ها فقط متن نمایشی است" in dashboard
    assert "وضعیت نسخه‌های پشتیبان از این سرویس قابل دریافت نیست" in dashboard
    assert "Active Users" not in dashboard
    assert "select(func.count(User.id))" in dashboard


def test_health_filter_suppresses_only_successful_get_health_access_records():
    from app.http_api.health_logging import SuccessfulHealthCheckFilter

    filter_ = SuccessfulHealthCheckFilter()

    def record(args):
        return logging.LogRecord("uvicorn.access", logging.INFO, __file__, 1, '%s', args, None)

    assert filter_.filter(record(("127.0.0.1", "GET", "/health", "1.1", 200))) is False
    assert filter_.filter(record(("127.0.0.1", "GET", "/health?probe=1", "1.1", 204))) is False
    assert filter_.filter(record(("127.0.0.1", "GET", "/health", "1.1", 503))) is True
    assert filter_.filter(record(("127.0.0.1", "POST", "/health", "1.1", 200))) is True
    assert filter_.filter(record(("127.0.0.1", "GET", "/health/db", "1.1", 200))) is True
    assert filter_.filter(record(("127.0.0.1", "GET /health HTTP/1.1", 200))) is False
