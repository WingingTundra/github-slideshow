from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ADMIN = ROOT / "app" / "bot" / "handlers" / "admin.py"


def test_manage_panels_query_excludes_archived_panels_before_limit():
    source = ADMIN.read_text(encoding="utf-8")
    event_list = source.split('async def event_list(', 1)[1].split('@router.callback_query(F.data.startswith("admin:event:view:")', 1)[0]

    assert "await _render_admin_event_list(c, 0)" in event_list
    helper = source.split("async def _render_admin_event_list", 1)[1].split("@router.callback_query(F.data == \"admin:events\")", 1)[0]
    assert "Event.archived.is_(False)" in helper
    assert ".offset(page * EVENT_ADMIN_PAGE_SIZE).limit(EVENT_ADMIN_PAGE_SIZE)" in helper
    assert "admin:events:page:" in helper
    assert "lifecycle = \"✅ برگزارشده\"" in helper


def test_archived_panel_detail_offers_separate_permanent_delete_action():
    source = ADMIN.read_text(encoding="utf-8")
    detail = source.split("async def _render_archived_panel_detail", 1)[1].split('@router.callback_query(F.data.startswith("admin:archive:view:")', 1)[0]

    assert 'text="🗑 حذف کامل پنل و سوابق"' in detail
    assert 'callback_data=f"admin:archive:delete:{eid}"' in detail


def test_archived_delete_is_confirmed_and_requires_panel_still_be_archived():
    source = ADMIN.read_text(encoding="utf-8")
    entry = source.split("async def archived_event_delete(", 1)[1].split('@router.callback_query(F.data.regexp(r"^admin:event:delete:', 1)[0]
    confirmation = source.split("async def archived_event_delete_confirm(", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:delete:confirm:")', 1)[0]
    deletion_screen = source.split("async def event_delete(", 1)[1].split('@router.callback_query(F.data.startswith("admin:archive:delete:confirm:")', 1)[0]

    assert 'if not event or not event.archived:' in entry
    assert 'if not event or not event.archived:' in confirmation
    assert 'admin:archive:delete:confirm:{eid}' in deletion_screen
    assert 'admin:archive:delete:cancel:{eid}' in deletion_screen
    assert "این پنل از قبل آرشیو شده است" in deletion_screen


def test_cancelled_archived_delete_returns_to_archived_panel_detail():
    source = ADMIN.read_text(encoding="utf-8")
    cancel = source.split("async def archived_event_delete_cancel(", 1)[1].split('@router.callback_query(F.data.startswith("admin:archive:file:")', 1)[0]

    assert 'event = await session.get(Event, eid)' in cancel
    assert 'if not event or not event.archived:' in cancel
    assert 'await _render_archived_panel_detail(c, eid)' in cancel


def test_existing_permanent_delete_keeps_confirmed_booking_lifetime_ledger():
    source = ADMIN.read_text(encoding="utf-8")
    deletion = source.split("async def event_delete_confirm(", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:delete:cancel:")', 1)[0]

    assert "await session.delete(event)" in deletion
    assert "await session.commit()" in deletion
    assert "BookingConfirmationLedger" not in deletion
    assert "still_referenced" in deletion


def test_archive_success_opens_dedicated_archived_detail_after_commit():
    source = ADMIN.read_text(encoding="utf-8")
    archive_confirm = source.split("async def event_archive_confirm(", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:archive:cancel:")', 1)[0]

    assert "event.archived = True" in archive_confirm
    assert 'await c.answer("پنل آرشیو شد؛ کدهای وابسته نیز به‌روزرسانی شدند.", show_alert=True)' in archive_confirm
    assert "await _render_archived_panel_detail(c, eid, answer_callback=False)" in archive_confirm
    assert "await render_event(c, eid)" not in archive_confirm
