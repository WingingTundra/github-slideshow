"""Dependency-complete checks for actual aiogram ReplyKeyboardMarkup objects."""
import pytest

pytest.importorskip("aiogram", reason="keyboard runtime checks require aiogram 3.x")

from aiogram.types import InlineKeyboardMarkup, ReplyKeyboardMarkup

from app.bot.keyboards import main_menu, persistent_main_keyboard, profile_phone_keyboard

EXPECTED_ROWS = [
    ["🏠 پنل‌های پیش‌رو"],
    ["🎟 ثبت‌نام‌های من"],
    ["👤 پروفایل من", "📚 پنل‌های گذشته"],
    ["📄 سؤالات پنل‌ها", "💡 پیشنهادها"],
    ["🎮 سرگرمی و چالش‌ها"],
    ["💬 جامعه و دربارهٔ ما"],
]


def test_main_reply_keyboard_runtime_shape_and_persistence_flags():
    markup = persistent_main_keyboard()
    assert isinstance(markup, ReplyKeyboardMarkup)
    assert markup.is_persistent is True
    assert markup.resize_keyboard is True
    assert markup.one_time_keyboard is False
    assert [[button.text for button in row] for row in markup.keyboard] == EXPECTED_ROWS
    assert all(len(row) <= 2 for row in markup.keyboard)


def test_phone_collection_keeps_menu_and_contextual_inline_menu_is_unchanged():
    phone_markup = profile_phone_keyboard()
    assert isinstance(phone_markup, ReplyKeyboardMarkup)
    assert phone_markup.is_persistent is True
    assert phone_markup.keyboard[0][0].request_contact is True
    assert [[button.text for button in row] for row in phone_markup.keyboard[1:]] == EXPECTED_ROWS
    assert isinstance(main_menu(), InlineKeyboardMarkup)
