from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from app.services.admin_panel_display import format_manage_event_text
from app.db.models import EventStatus

ROOT = Path(__file__).resolve().parents[1]


def make_event(**overrides):
    values = dict(
        volume="V21",
        title="The Reality Check",
        description="I. The Blueprint\n■ How do our childhood timelines compare?\n\nII. The Price Tag\n■ When does money stop buying freedom?",
        language="English",
        status=EventStatus.PUBLISHED,
        registration_open=True,
        registration_closed_reason=None,
        archived=False,
        capacity=10,
        event_day_label="پنجشنبه",
        event_date_label="۷ آبان ماه",
        start_time_label="18:30",
        end_time_label="20:00",
        venue="کافه‌بازی فانوس",
        price_per_person=80000,
        price_without_cafe_order=None,
        address="بلوار صیاد شیرازی 26، پلاک 14",
        map_url="https://nshn.ir/example",
        host_name="سینا ضیائی",
        questions_pdf_path="/data/Volume21.pdf",
        questions_file_name="Volume 21.pdf",
        waitlist_enabled=True,
        attendance_enabled=False,
        feedback_enabled=True,
    )
    values.update(overrides)
    return SimpleNamespace(**values)


def test_manage_panel_layout_places_description_before_all_panel_facts():
    text = format_manage_event_text(make_event(), used=7)
    # The new shared formatter adds Unicode direction isolates around each
    # metadata row/value. Strip them for semantic ordering assertions.
    display_text = text.translate({ord(char): None for char in "\u2066\u2067\u2068\u2069"})
    title_index = display_text.index("V21 – The Reality Check")
    description_heading_index = display_text.index("توضیحات پنل")
    description_index = display_text.index("The Blueprint")
    facts_heading_index = display_text.index("اطلاعات پنل")
    language_index = display_text.index("زبان پنل: English")
    seats_index = display_text.index("7/10")
    address_index = display_text.index("بلوار صیاد شیرازی")

    assert title_index < description_heading_index < description_index < facts_heading_index
    assert facts_heading_index < language_index < seats_index < address_index
    assert "_________________________" in display_text
    assert "وضعیت انتشار: Published" in display_text
    assert "وضعیت ثبت‌نام: Open" in display_text
    assert "📄 سؤالات: Volume 21.pdf" in display_text


def test_manage_panel_layout_keeps_metadata_and_truncates_very_long_description_first():
    long_description = "A very long description. " * 500
    event = make_event(description=long_description)
    text = format_manage_event_text(event, used=7)

    # The panel title and useful facts remain present rather than being crowded
    # out by an unusually long user-authored description.
    assert "V21 – The Reality Check" in text
    assert "📋 <b>اطلاعات پنل</b>" in text
    assert "7/10" in text
    assert len(text) < 4000
    assert "…" in text


def test_receipt_decision_refreshes_to_next_pending_receipt_without_manual_reentry():
    source = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    review_source = source.split("async def review(", 1)[1].split("@router.callback_query(F.data.startswith(\"admin:payment:approve:\"))", 1)[0]
    assert "await _show_next_pending_payment(" in review_source
    assert "payment_review_keyboard(" in source and "can_navigate=can_navigate" in source
    assert "selectinload(Payment.booking).selectinload(Booking.event)" in source
    assert "برای این پنل رسید دیگری در انتظار بررسی نیست." in source
    assert "continue_callback" in review_source  # safe fallback if Telegram cannot refresh the message


def test_next_receipt_query_is_live_and_respects_panel_scope():
    source = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    helper = source.split("async def _show_next_pending_payment(", 1)[1].split("async def review(", 1)[0]
    assert "Payment.status == PaymentStatus.PENDING" in helper
    assert "Payment.receipt_file != \"\"" in helper
    assert "Payment.receipt_text != \"\"" in helper
    assert "Booking.status == RegistrationStatus.PENDING_VERIFICATION" in helper
    assert "stmt = stmt.where(Booking.event_id == int(event_scope))" in helper
    assert ".order_by(Payment.created_at, Payment.id)" in helper
