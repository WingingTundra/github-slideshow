from __future__ import annotations

import asyncio
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.models import (
    Base, Booking, Event, EventStatus, Question, RegistrationStatus, User, UserRole,
)
from app.services.booking import admin_cancel_pending_payment, cancel_booking

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


class AsyncSessionAdapter:
    def __init__(self, session: Session):
        self.sync = session

    async def execute(self, statement):
        return self.sync.execute(statement)

    async def get(self, entity, ident, **kwargs):
        return self.sync.get(entity, ident)

    def add(self, obj):
        self.sync.add(obj)

    async def flush(self):
        self.sync.flush()

    async def commit(self):
        self.sync.commit()

    async def rollback(self):
        self.sync.rollback()


def _db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, AsyncSessionAdapter(Session(engine))


def _seed(session, status=RegistrationStatus.PENDING_PAYMENT):
    user = User(telegram_id=771001, display_name="Sina Ziaei", role=UserRole.PARTICIPANT)
    session.add(user)
    session.sync.flush()
    event = Event(
        volume=28, title="V28 Test Panel", event_day_label="Saturday",
        event_date_label="10 October 2026", start_time_label="18:00", end_time_label="20:00",
        venue="Test Venue", capacity=10, price_per_person=Decimal("150000"),
        status=EventStatus.PUBLISHED, registration_open=True,
    )
    session.add(event)
    session.sync.flush()
    booking = Booking(
        event_id=event.id, booked_by_user_id=user.id, participant_count=2,
        total_amount=Decimal("300000"), status=status,
        created_at=datetime(2026, 10, 10, 12, 0),
    )
    session.add(booking)
    session.sync.commit()
    return user, event, booking


def test_admin_can_cancel_only_a_still_pending_unpaid_booking():
    engine, session = _db()
    try:
        _user, event, booking = _seed(session)
        result = asyncio.run(admin_cancel_pending_payment(session, booking.id, event.id))
        assert result.id == booking.id
        assert result.status == RegistrationStatus.CANCELLED
        assert result.expires_at is None
        try:
            asyncio.run(admin_cancel_pending_payment(session, booking.id, event.id))
            assert False, "expected state revalidation to reject the second cancellation"
        except ValueError as exc:
            assert str(exc) == "NOT_PENDING_PAYMENT"
    finally:
        session.sync.close()
        engine.dispose()


def test_receipt_rejected_reservation_can_be_cancelled():
    engine, session = _db()
    try:
        user, _event, booking = _seed(session, RegistrationStatus.REJECTED)
        result = asyncio.run(cancel_booking(session, user.id, booking.id))
        assert result.status == RegistrationStatus.CANCELLED
    finally:
        session.sync.close()
        engine.dispose()


def test_question_answer_fields_persist_in_model():
    engine, session = _db()
    try:
        user = User(telegram_id=771002, display_name="Question Sender")
        session.add(user)
        session.sync.commit()
        question = Question(
            question_text="How do we start?", submitted_by=user.id,
            answer_text="Start with a short introduction.",
            answered_at=datetime(2026, 10, 10, 14, 0),
        )
        session.add(question)
        session.sync.commit()
        persisted = session.sync.execute(select(Question).where(Question.id == question.id)).scalar_one()
        assert persisted.answer_text == "Start with a short introduction."
        assert persisted.answered_at == datetime(2026, 10, 10, 14, 0)
    finally:
        session.sync.close()
        engine.dispose()


def test_v28_admin_ui_places_exports_waitlist_and_pending_under_participants():
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    event_menu = keyboards.split("def admin_event_menu(", 1)[1].split("def final_panel_state_keyboard", 1)[0]
    assert 'text="⚙️ وضعیت نهایی پنل"' in event_menu
    assert 'text="📊 خروجی شرکت‌کنندگان (Excel)"' not in event_menu
    assert 'admin:event:pending:{eid}' in admin
    assert 'admin:event:waitlist:invite:{eid}' in admin
    assert 'admin:event:export:{eid}' in admin
    assert 'text="📋 صف همهٔ پرداخت‌ها"' not in keyboards


def test_v28_archive_browser_answered_questions_and_clear_actions_are_wired():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    assert 'admin:archives:page:' in admin
    assert 'admin:archive:view:' in admin
    assert 'admin:archive:file:' in admin
    archive_confirm = admin.split("async def event_archive_confirm", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:archive:cancel:"))', 1)[0]
    assert "event.questions_pdf_path = None" not in archive_confirm
    assert "admin:questions:clear:confirm" in admin
    assert "admin:reviews:clear:confirm" in admin
    assert "question.answer_text" in user
    assert 'text="📢 Telegram Channel"' in keyboards
    assert 'text="👥 Telegram Group"' in keyboards
    console = (APP / "bot/handlers/admin_console.py").read_text(encoding="utf-8")
    announcement_menu = console.split("def _announcement_main_keyboard", 1)[1].split("def _panel_announcement_keyboard", 1)[0]
    content_menu = keyboards.split("def admin_content_hub_keyboard", 1)[1].split("def admin_reports_hub_keyboard", 1)[0]
    assert 'text="📢 به‌روزرسانی‌های کانال"' in announcement_menu
    assert 'callback_data="admin:channel_updates"' in announcement_menu
    assert 'به‌روزرسانی‌های کانال' not in content_menu


def test_v28_pending_reservation_callbacks_are_not_swallowed_by_broader_routes():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    page = admin.index('F.data.regexp(r"^admin:event:pending:\\d+$")')
    cancel_exact = admin.index('F.data.regexp(r"^admin:event:pending:cancel:\\d+:\\d+$")')
    cancel_confirm = admin.index('F.data.startswith("admin:event:pending:cancel:confirm:")')
    assert page < cancel_exact < cancel_confirm
    # Administrator roster uses natural Persian labels rather than raw database codes.
    assert "def booking_status_label(status: RegistrationStatus)" in admin
    assert "reservation_status = escape(admin_status_display_label(reservation_value))" in admin


def test_v28_exact_requested_onboarding_and_community_labels():
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    content = (APP / "bot/content.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    assert "accepted_name_phone_prompt()" in user
    assert "✅ نام و نام خانوادگی ثبت شد." in content
    assert "شمارهٔ تماس خود را وارد کنید.\\n" in content
    assert "<i>شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in content
    assert r'text="💬 جامعه و دربارهٔ ما"' in keyboards
    assert 'text="📢 Telegram Channel"' in keyboards
    assert 'text="👥 Telegram Group"' in keyboards


def test_v28_final_state_contains_all_three_lifecycle_actions_and_back():
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    submenu = keyboards.split("def final_panel_state_keyboard(", 1)[1].split("def archive_confirm_keyboard", 1)[0]
    assert 'text="📦 آرشیو + بازخورد"' in submenu
    assert 'text="❌ لغو پنل"' in submenu
    assert 'text="🗑 حذف کامل پنل و سوابق"' in submenu
    assert 'text="🔙 بازگشت به مدیریت پنل"' in submenu


def test_v28_permanent_delete_cleans_panel_reviews_but_preserves_lifetime_ledger():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    delete_block = admin.split("async def event_delete_confirm", 1)[1].split('@router.callback_query(F.data.startswith("admin:event:delete:cancel:"))', 1)[0]
    assert "Review.__table__.delete().where(Review.booking_id.in_(booking_ids))" in delete_block
    assert "Review.__table__.delete().where(Review.event_id == eid)" in delete_block
    assert "BookingConfirmationLedger" not in delete_block
    assert "still_referenced" in delete_block and "session.commit()" in delete_block


def test_v28_rejected_receipt_message_offers_both_recovery_actions():
    payment_actions = (APP / "bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    assert "رسید پرداخت رزرو #{bid} رد شد" not in payment_actions
    assert "رسید پرداخت شما برای پنل" in payment_actions
    assert "مبلغ رزرو:" in payment_actions
    assert "می‌توانید رسید دیگری ارسال کنید یا رزرو خود را لغو کنید." in payment_actions
    retry = keyboards.split("def retry_payment_keyboard(", 1)[1].split("def questions_keyboard", 1)[0]
    assert 'text="🔄 ارسال مجدد رسید"' in retry
    assert 'text="❌ لغو کامل رزرو"' in retry
