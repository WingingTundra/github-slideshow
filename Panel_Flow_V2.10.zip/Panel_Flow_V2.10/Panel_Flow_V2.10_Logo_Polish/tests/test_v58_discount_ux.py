from pathlib import Path
from decimal import Decimal

from app.services.discounts import (
    ACTIVE_REDEMPTION_STATUSES,
    code_format_help,
    parse_public_code_definition,
    summarize_redemption_counts,
)

ROOT = Path(__file__).resolve().parents[1]
ADMIN = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
USER = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
KEYBOARDS = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
CONTENT = (ROOT / "app/bot/content.py").read_text(encoding="utf-8")
PAYMENT_ACTIONS = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")


def test_admin_usage_summary_uses_the_same_statuses_as_global_cap_enforcement():
    grouped = [("pending", 2), ("approved", 3), ("redeemed", 4), ("rejected", 5)]
    occupied, redeemed, pending, approved = summarize_redemption_counts(grouped)

    assert ACTIVE_REDEMPTION_STATUSES == ("pending", "approved", "redeemed")
    assert (occupied, redeemed, pending, approved) == (9, 4, 2, 3)


def test_discount_code_format_and_expiry_help_distinguishes_percent_and_fixed_amount():
    percent = parse_public_code_definition("PANEL100")
    fixed = parse_public_code_definition("PANEL100K")
    help_text = code_format_help()

    assert (percent.discount_type, percent.discount_value) == ("percent", Decimal("100"))
    assert (fixed.discount_type, fixed.discount_value) == ("fixed", Decimal("100000"))
    assert "PANEL20" in help_text and "PANEL100" in help_text and "PANEL100K" in help_text
    assert "تاریخ انقضای خودکار ندارند" in help_text
    assert "آرشیو یا حذف همهٔ پنل‌های مشمول" in help_text


def test_panel_picker_has_select_all_current_and_clear_controls_with_page_context():
    assert 'callback_data=f"admin:discount:events:select_all:{page}"' in KEYBOARDS
    assert 'callback_data=f"admin:discount:events:clear:{page}"' in KEYBOARDS
    assert 'admin:discount:events:select_all:' in ADMIN
    assert 'admin:discount:events:clear:' in ADMIN
    assert "Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))" in ADMIN
    assert "انتخاب همهٔ پنل‌های فعلی" in ADMIN
    assert "شامل پنل‌های آینده‌ای که بعداً ساخته می‌شوند نیست" in ADMIN


def test_discount_admin_copy_explains_per_user_and_global_limit_scopes():
    # The buttons are intentionally short; the handler's explanatory copy
    # clarifies the per-user policy before asking for the shared global cap.
    assert 'text="یک‌بار در مجموع"' in KEYBOARDS
    assert 'text="یک‌بار در هر پنل"' in KEYBOARDS
    assert "هر حساب فقط در یکی از پنل‌های انتخاب‌شده" in ADMIN
    assert "هر حساب می‌تواند در هر پنل انتخاب‌شده یک‌بار" in ADMIN
    assert "رزروها/درخواست‌های در انتظار و تأییدشده ظرفیت را اشغال می‌کنند" in ADMIN
    assert "درخواست ردشده نمی‌کند" in ADMIN
    assert "عدد ۲۰ فقط یک مثال است" in ADMIN
    assert "سهمیه اشغال‌شده" in ADMIN
    assert "استفاده نهایی‌شده" in ADMIN
    assert "در انتظار بررسی مدیر" in ADMIN
    assert "تأییدشده، منتظر ادامه کاربر" in ADMIN


def test_admin_uses_clear_code_kind_labels_and_correct_personal_gift_copy():
    assert "کد عادی – بدون تأیید مدیر" in KEYBOARDS
    assert "کد ویژه – با تأیید مدیر" in KEYBOARDS
    assert "این هدیه فقط در پنل‌های فهرست‌شده قابل استفاده است" in ADMIN
    assert "در ثبت‌نام چندنفره فقط هزینهٔ یک نفر را پوشش می‌دهد" in ADMIN
    assert "صندلی را پیشاپیش رزرو نمی‌کند" in ADMIN


def test_rejected_discount_request_explains_same_code_cannot_be_reused_and_regular_price_is_available():
    assert "این حساب پس از رد درخواست نمی‌تواند دوباره از همین کد استفاده کند" in ADMIN
    assert "با قیمت عادی ادامه دهید یا آن را لغو کنید" in ADMIN
    assert "برای درخواست تخفیف دیگر باید از کد دیگری استفاده کنید" in ADMIN


def test_user_help_about_and_missing_question_file_copy_are_polished():
    help_text = CONTENT.split("def user_help_text", 1)[1].split("def about_text", 1)[0]
    about = CONTENT.split("def about_text", 1)[1]
    assert "بعضی وضعیت‌ها تا بررسی مدیر نهایی نمی‌شوند" not in help_text
    assert "Our sessions create space to exchange ideas" in about
    assert "جلسات ما فرصتی برای تبادل ایده‌ها" in about
    assert "پنل‌های منتشرشده را ببینید" not in about
    assert "برای این پنل فایل سؤالاتی منتشر نشده است" in USER
    assert "فایل سؤالات این پنل موقتاً در دسترس نیست" not in PAYMENT_ACTIONS
    assert "questions_pdf_path" in PAYMENT_ACTIONS
    assert "questions_pdf_path" in USER
    assert "storage پیدا نشد" not in PAYMENT_ACTIONS


def test_topic_question_and_feedback_have_distinct_confirmation_messages():
    submit_flow = USER.split("async def submit_question", 1)[1].split('@router.callback_query(F.data == "user:reviews")', 1)[0]
    assert '"question": "✅ پیشنهاد سؤال شما ثبت شد.' in submit_flow
    assert '"topic": "✅ پیشنهاد موضوع شما ثبت شد.' in submit_flow
    assert '"feedback": "✅ بازخورد شما ثبت شد.' in submit_flow
