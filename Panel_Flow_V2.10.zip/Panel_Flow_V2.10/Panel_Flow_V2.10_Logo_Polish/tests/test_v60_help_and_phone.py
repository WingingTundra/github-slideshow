"""V61 regressions for generalized /help copy and phone privacy-note formatting."""
from __future__ import annotations

from pathlib import Path

from app.bot.content import accepted_name_phone_prompt, phone_number_prompt, user_help_text


def test_phone_prompts_use_the_short_privacy_note():
    expected_note = "<i>شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود.</i>"
    accepted = accepted_name_phone_prompt()
    plain = phone_number_prompt()

    assert accepted == (
        "✅ نام و نام خانوادگی ثبت شد.\n\n"
        "شمارهٔ تماس خود را وارد کنید.\n"
        + expected_note
    )
    assert plain == "شمارهٔ تماس خود را وارد کنید.\n" + expected_note
    assert "وارد کنید. (فقط برای موارد ضروری" not in accepted
    assert "وارد کنید. (فقط برای موارد ضروری" not in plain


def test_help_explains_profile_referral_code_and_community_processes():
    help_text = user_help_text()
    assert "کد معرفی" in help_text
    assert "پیگیری وضعیت رزروها و پرداخت‌ها" in help_text
    assert "۱۰ نفر برتر" in help_text
    assert "نمایش نام" in help_text
    assert "چالش‌های فعال" in help_text
    # Keep operational submission limits and internal review/scoring details out of /help.
    assert "حداکثر ۱۰۰۰ نویسه" not in help_text
    assert "فقط یک‌بار ثبت می‌شود" not in help_text
    assert "پاسخ خصوصی است" not in help_text
    assert "پس از بسته‌شدن، پاسخ‌ها بررسی می‌شوند" not in help_text
    assert "امتیازهای نتیجه پس از بررسی ثبت می‌شوند" not in help_text
    assert "مجموع XP" in help_text and "نشان‌ها" in help_text
    assert "Wrapped" in help_text and "پشتیبانی انسانی" in help_text


def test_v61_help_keeps_challenges_general_and_rtl_mixed_labels_consistent():
    help_text = user_help_text()
    assert "چالش‌های فعال" in help_text
    assert "حداکثر ۱۰۰۰ نویسه" not in help_text
    assert "فقط یک‌بار ثبت می‌شود" not in help_text
    assert "قابل ویرایش نیست" not in help_text
    assert "پس از بسته‌شدن، پاسخ‌ها بررسی می‌شوند" not in help_text
    assert "امتیازهای نتیجه پس از بررسی ثبت می‌شوند" not in help_text
    assert "پاسپورت من" in help_text
    assert "معرفی Panel Flow و لینک‌های رسمی" in help_text

    keyboards_source = (Path(__file__).resolve().parents[1] / "app/bot/keyboards.py").read_text(encoding="utf-8")
    passport_button = 'text="🪪 پاسپورت من"'
    about_button = 'text="💬 جامعه و دربارهٔ ما"'
    assert passport_button in keyboards_source
    # The About button is used in both the main menu and the help keyboard.
    assert keyboards_source.count(about_button) >= 2
