from decimal import Decimal
from types import SimpleNamespace

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.config import settings
from app.db.models import AppSetting, Base, Booking, ChannelAnnouncement, Event, EventStatus, RegistrationStatus, User
from app.services import channel_status
from app.services.app_settings import CHANNEL_UPDATE_THRESHOLD, CHANNEL_UPDATES_ENABLED
from app.services.channel_status import reconcile_event_channel_status


class FakeAsyncSession:
    def __init__(self, sync_session):
        self.s = sync_session

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False

    async def execute(self, stmt):
        return self.s.execute(stmt)

    async def get(self, entity, ident, **kwargs):
        return self.s.get(entity, ident)

    def add(self, obj):
        self.s.add(obj)

    async def flush(self):
        self.s.flush()

    async def commit(self):
        self.s.commit()

    async def rollback(self):
        self.s.rollback()


class FakeBot:
    def __init__(self):
        self.next_message_id = 100
        self.sent = []
        self.edited = []

    async def get_me(self):
        return SimpleNamespace(username="panel_flow_bot")

    async def send_message(self, **kwargs):
        message_id = self.next_message_id
        self.next_message_id += 1
        self.sent.append({"message_id": message_id, **kwargs})
        return SimpleNamespace(message_id=message_id)

    async def edit_message_text(self, **kwargs):
        self.edited.append(kwargs)
        return SimpleNamespace(message_id=kwargs["message_id"])


def make_env(monkeypatch, *, enabled=True, threshold=3):
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    sync = Session(engine)
    owner = User(telegram_id=12345, first_name="Test", last_name="User")
    sync.add(owner)
    sync.flush()
    event = Event(
        volume=20,
        title="Volume Test",
        event_day_label="Thursday",
        event_date_label="15 October 2026",
        start_time_label="16:30",
        end_time_label="18:30",
        venue="Test Venue",
        capacity=8,
        price_per_person=Decimal("0"),
        status=EventStatus.PUBLISHED,
        registration_open=True,
        waitlist_enabled=True,
        host_id=owner.id,
        host_name="Host",
    )
    sync.add(event)
    sync.add(AppSetting(key=CHANNEL_UPDATES_ENABLED, value="true" if enabled else "false"))
    sync.add(AppSetting(key=CHANNEL_UPDATE_THRESHOLD, value=str(threshold)))
    sync.commit()
    monkeypatch.setattr(channel_status, "SessionLocal", lambda: FakeAsyncSession(sync))
    monkeypatch.setattr(settings, "panel_flow_channel_id", -100123456789)
    return engine, sync, owner, event


def add_booking(sync, owner, event, count, status=RegistrationStatus.CONFIRMED):
    """Represent seat totals as valid reservations owned by distinct users."""
    remaining = int(count)
    bookings = []
    while remaining > 0:
        seats = min(3, remaining)
        # These are capacity-status tests, not repeat-registration tests. Use a
        # distinct synthetic owner for each booking to respect the 3-seat user cap.
        next_telegram_id = 20000 + sync.query(User).count()
        booker = User(telegram_id=next_telegram_id, first_name="Capacity", last_name="Tester")
        sync.add(booker)
        sync.flush()
        bookings.append(Booking(
            event_id=event.id,
            booked_by_user_id=booker.id,
            participant_count=seats,
            total_amount=Decimal("0"),
            status=status,
        ))
        remaining -= seats
    sync.add_all(bookings)
    sync.commit()
    return bookings


def test_channel_updates_off_create_nothing(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=False, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        assert bot.sent == []
        assert sync.query(ChannelAnnouncement).count() == 0
    finally:
        sync.close(); engine.dispose()


def test_threshold_creates_one_message_and_next_changes_edit_same_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        row = sync.query(ChannelAnnouncement).one()
        assert row.status_message_id == 100
        assert len(bot.sent) == 1
        assert "ظرفیت کل: ۸ نفر" in bot.sent[0]["text"]
        assert "۳ صندلی" not in bot.sent[0]["text"]
        assert "start=event_" + str(event.id) in bot.sent[0]["reply_markup"].inline_keyboard[0][0].url

        add_booking(sync, owner, event, 1)
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert "۲ صندلی" in bot.edited[-1]["text"]
        add_booking(sync, owner, event, 1)
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert [x["message_id"] for x in bot.edited] == [100, 100]
        assert "۱ صندلی" in bot.edited[-1]["text"]
    finally:
        sync.close(); engine.dispose()


def test_full_edits_same_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        event.registration_open = False
        event.registration_closed_reason = "capacity"
        add_booking(sync, owner, event, 3)
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert bot.edited[-1]["message_id"] == 100
        assert "ظرفیت این پنل تکمیل شد" in bot.edited[-1]["text"]
        assert "start=panel_" + str(event.id) in bot.edited[-1]["reply_markup"].inline_keyboard[0][0].url
    finally:
        sync.close(); engine.dispose()


def test_cancellation_or_rejection_keeps_single_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        bookings = add_booking(sync, owner, event, 5)
        bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        for booking in bookings:
            booking.status = RegistrationStatus.CANCELLED
        sync.commit()
        event.registration_open = False
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert len(bot.edited) == 1
        assert bot.edited[-1]["message_id"] == 100
        assert "ثبت‌نام این پنل بسته شد" in bot.edited[-1]["text"]
        assert "start=panel_" + str(event.id) in bot.edited[-1]["reply_markup"].inline_keyboard[0][0].url
    finally:
        sync.close(); engine.dispose()


def test_capacity_increase_edits_existing_status_and_reopens_available_panel(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 8)
        event.registration_open = False
        event.registration_closed_reason = "capacity"
        sync.commit()
        bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        event.capacity = 10
        event.registration_open = True
        event.registration_closed_reason = None
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert len(bot.edited) == 1
        assert "ظرفیت پنل ۲ نفر افزایش یافت" in bot.edited[-1]["text"]
        assert "۲ صندلی" in bot.edited[-1]["text"]
    finally:
        sync.close(); engine.dispose()


def test_restart_uses_persisted_message_id_and_does_not_send_second_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        first_bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(first_bot, event.id))
        second_bot = FakeBot()
        second_bot.next_message_id = 500
        assert asyncio_run(reconcile_event_channel_status(second_bot, event.id)) is True
        assert second_bot.sent == []
        assert second_bot.edited[0]["message_id"] == 100
    finally:
        sync.close(); engine.dispose()


def test_multiple_events_have_independent_messages(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        event2 = Event(
            volume=21,
            title="Second",
            event_day_label="Friday",
            event_date_label="16 October 2026",
            start_time_label="16:30",
            end_time_label="18:30",
            venue="Second Venue",
            capacity=8,
            price_per_person=Decimal("0"),
            status=EventStatus.PUBLISHED,
            registration_open=True,
            waitlist_enabled=True,
            host_id=owner.id,
            host_name="Host",
        )
        sync.add(event2); sync.commit()
        add_booking(sync, owner, event, 5)
        add_booking(sync, owner, event2, 8)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id))
        assert asyncio_run(reconcile_event_channel_status(bot, event2.id))
        assert len(bot.sent) == 2
        rows = {r.event_id: r.status_message_id for r in sync.query(ChannelAnnouncement).all()}
        assert rows[event.id] != rows[event2.id]
        assert str(event.id) in bot.sent[0]["reply_markup"].inline_keyboard[0][0].url
        assert str(event2.id) in bot.sent[1]["reply_markup"].inline_keyboard[0][0].url
    finally:
        sync.close(); engine.dispose()


def asyncio_run(coro):
    import asyncio
    return asyncio.run(coro)


def test_above_threshold_does_not_create_status_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=3)
    try:
        add_booking(sync, owner, event, 4)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        assert bot.sent == []
        assert sync.query(ChannelAnnouncement).count() == 0
    finally:
        sync.close(); engine.dispose()


def test_linking_poster_above_threshold_does_not_create_status_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=3)
    try:
        sync.add(ChannelAnnouncement(
            event_id=event.id,
            channel_id=-100123456789,
            poster_message_id=77,
            status_message_id=None,
            initialized=False,
            last_capacity=event.capacity,
            last_remaining=event.capacity,
        ))
        sync.commit()
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        row = sync.query(ChannelAnnouncement).one()
        assert row.status_message_id is None
        assert bot.sent == []

        add_booking(sync, owner, event, 5)
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        row = sync.query(ChannelAnnouncement).one()
        assert row.status_message_id == 100
        assert len(bot.sent) == 1
        assert bot.sent[0]["reply_parameters"].message_id == 77
    finally:
        sync.close(); engine.dispose()


def test_threshold_to_full_is_all_one_persistent_status_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        add_booking(sync, owner, event, 1)
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        add_booking(sync, owner, event, 1)
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        add_booking(sync, owner, event, 1)
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert [x["message_id"] for x in bot.edited] == [100, 100, 100]
        assert "ظرفیت این پنل تکمیل شد" in bot.edited[-1]["text"]
        assert "start=event_" + str(event.id) in bot.sent[0]["reply_markup"].inline_keyboard[0][0].url
        assert "start=panel_" + str(event.id) in bot.edited[-1]["reply_markup"].inline_keyboard[0][0].url
        assert len(bot.sent) == 1
    finally:
        sync.close(); engine.dispose()


def test_reopening_existing_status_message_recalculates_current_remaining_seats(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        event.registration_open = False
        event.registration_closed_reason = "manual"
        sync.commit()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        event.registration_open = True
        event.registration_closed_reason = None
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert bot.edited[-1]["message_id"] == 100
        assert "ظرفیت کل: ۸ نفر" in bot.edited[-1]["text"]
        assert "۳ صندلی" not in bot.edited[-1]["text"]
    finally:
        sync.close(); engine.dispose()


def test_capacity_increase_before_first_status_does_not_create_above_threshold(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=3)
    try:
        sync.add(ChannelAnnouncement(
            event_id=event.id,
            channel_id=-100123456789,
            poster_message_id=77,
            status_message_id=None,
            initialized=False,
            last_capacity=8,
            last_remaining=8,
        ))
        sync.commit()
        event.capacity = 10
        sync.commit()
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        assert bot.sent == []
        assert sync.query(ChannelAnnouncement).one().status_message_id is None
    finally:
        sync.close(); engine.dispose()


class EditFailingBot(FakeBot):
    async def edit_message_text(self, **kwargs):
        raise RuntimeError("telegram edit temporarily unavailable")


def test_telegram_edit_failure_keeps_persisted_status_message_id_retryable(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        good_bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(good_bot, event.id))
        row = sync.query(ChannelAnnouncement).one()
        assert row.status_message_id == 100
        add_booking(sync, owner, event, 1)
        failing = EditFailingBot()
        assert asyncio_run(reconcile_event_channel_status(failing, event.id)) is False
        sync.refresh(row)
        assert row.status_message_id == 100
        assert row.last_remaining == 3
    finally:
        sync.close(); engine.dispose()




class FailingBot(FakeBot):
    async def send_message(self, **kwargs):
        raise RuntimeError("telegram temporarily unavailable")


def test_telegram_send_failure_does_not_persist_a_fake_status_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FailingBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        assert sync.query(ChannelAnnouncement).count() == 0
    finally:
        sync.close(); engine.dispose()


def test_reconcile_all_retries_archived_panel_after_restart(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        event.archived = True
        event.registration_open = False
        sync.commit()
        bot.edited.clear()
        asyncio_run(channel_status.reconcile_all_channel_statuses(bot))
        assert len(bot.sent) == 1  # restart/reconciliation must edit, not create another message
        assert bot.edited
        assert bot.edited[-1]["message_id"] == 100
        assert "به آرشیو منتقل شده است" in bot.edited[-1]["text"]
    finally:
        sync.close(); engine.dispose()
def test_manual_close_updates_existing_status_message(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        asyncio_run(reconcile_event_channel_status(bot, event.id))
        row = sync.query(ChannelAnnouncement).one()
        row_id = row.status_message_id
        event.registration_open = False
        event.registration_closed_reason = "manual"
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert bot.edited[-1]["message_id"] == row_id
        assert "ثبت‌نام این پنل بسته شد" in bot.edited[-1]["text"]
    finally:
        sync.close(); engine.dispose()


class UnchangedEditBot(FakeBot):
    async def edit_message_text(self, **kwargs):
        raise RuntimeError("Telegram server says - Bad Request: message is not modified")


def test_telegram_message_not_modified_is_a_successful_noop(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        row = sync.query(ChannelAnnouncement).one()
        assert row.status_message_id == 100

        # The periodic task may reconcile unchanged state. Telegram's no-change
        # response should not be treated as a delivery failure or roll back state.
        unchanged_bot = UnchangedEditBot()
        assert asyncio_run(reconcile_event_channel_status(unchanged_bot, event.id)) is True
        sync.refresh(row)
        assert row.status_message_id == 100
        assert row.last_remaining == 3
        assert unchanged_bot.sent == []
    finally:
        sync.close(); engine.dispose()


def test_reenabling_channel_updates_uses_live_remaining_count_not_saved_threshold_or_last_value(monkeypatch):
    # Reproduces the reported 3-vs-4 seats issue: threshold=4 is a trigger, not
    # the remaining-seat count. The current DB state must produce exactly 3.
    engine, sync, owner, event = make_env(monkeypatch, enabled=False, threshold=4)
    try:
        event.capacity = 15
        sync.commit()
        add_booking(sync, owner, event, 12)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        assert bot.sent == []

        sync.query(AppSetting).filter_by(key=CHANNEL_UPDATES_ENABLED).one().value = "true"
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        assert "فقط ۳ صندلی باقی مانده" in bot.sent[0]["text"]
        assert "فقط ۴ صندلی باقی مانده" not in bot.sent[0]["text"]
        row = sync.query(ChannelAnnouncement).one()
        assert row.last_remaining == 3
    finally:
        sync.close(); engine.dispose()


def test_capacity_increase_while_updates_off_reports_new_capacity_and_live_four_seats(monkeypatch):
    from app.services.events import apply_capacity_change

    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=4)
    try:
        event.capacity = 15
        sync.commit()
        add_booking(sync, owner, event, 14)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert "فقط ۱ صندلی باقی مانده" in bot.sent[0]["text"]

        sync.query(AppSetting).filter_by(key=CHANNEL_UPDATES_ENABLED).one().value = "false"
        sync.commit()
        old_capacity = int(event.capacity)
        apply_capacity_change(event, old_capacity, 18, reserved_seats=14)
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False

        sync.query(AppSetting).filter_by(key=CHANNEL_UPDATES_ENABLED).one().value = "true"
        sync.commit()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        text = bot.edited[-1]["text"]
        assert "ظرفیت پنل ۳ نفر افزایش یافت" in text
        assert "فقط ۴ صندلی باقی مانده" in text
        assert "فقط ۱ صندلی باقی مانده" not in text
        row = sync.query(ChannelAnnouncement).one()
        assert row.last_capacity == 18
        assert row.last_remaining == 4
    finally:
        sync.close(); engine.dispose()


def test_reenable_existing_status_post_refreshes_three_seats_not_old_threshold_four(monkeypatch):
    # Exact reported scenario: a status message was created at four seats, updates
    # are turned off, a new reservation takes availability to three, and enabling
    # updates must use the live booking count rather than the stale message value.
    engine, sync, owner, event = make_env(monkeypatch, enabled=True, threshold=4)
    try:
        event.capacity = 15
        sync.commit()
        add_booking(sync, owner, event, 11)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert "فقط ۴ صندلی باقی مانده" in bot.sent[0]["text"]
        row = sync.query(ChannelAnnouncement).one()
        assert row.last_remaining == 4

        sync.query(AppSetting).filter_by(key=CHANNEL_UPDATES_ENABLED).one().value = "false"
        sync.commit()
        add_booking(sync, owner, event, 1)
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is False
        sync.refresh(row)
        assert row.last_remaining == 4  # stale snapshot while updates are off

        sync.query(AppSetting).filter_by(key=CHANNEL_UPDATES_ENABLED).one().value = "true"
        sync.commit()
        assert asyncio_run(channel_status.reconcile_all_channel_statuses(bot)) is None
        assert "فقط ۳ صندلی باقی مانده" in bot.edited[-1]["text"]
        assert "فقط ۴ صندلی باقی مانده" not in bot.edited[-1]["text"]
        sync.refresh(row)
        assert row.last_remaining == 3
    finally:
        sync.close(); engine.dispose()


def test_public_catalogue_and_channel_updates_share_the_authoritative_seat_status_set():
    from pathlib import Path
    from app.services.events import ACTIVE_BOOKING_STATUSES

    user_source = Path("app/bot/handlers/user.py").read_text(encoding="utf-8")
    status_source = Path("app/services/channel_status.py").read_text(encoding="utf-8")
    events_source = Path("app/services/events.py").read_text(encoding="utf-8")
    assert "Booking.status.in_(ACTIVE_BOOKING_STATUSES)" in user_source
    assert "reserved = await seats_used(session, event_id)" in status_source
    assert "Booking.status.in_(ACTIVE_BOOKING_STATUSES)" in events_source
    assert len(ACTIVE_BOOKING_STATUSES) == 3


def test_archived_completed_panel_invites_users_to_review_and_keeps_details_link():
    event = SimpleNamespace(
        id=4321,
        volume=21,
        title="Archived Test Panel",
        archived=True,
        status=EventStatus.COMPLETED,
        feedback_enabled=True,
        capacity=15,
        registration_open=False,
        registration_closed_reason="manual",
    )
    text = channel_status._status_text(event, 0)
    assert "این پنل برگزار شده و به آرشیو منتقل شده است." in text
    assert "اگر برای این پنل ثبت‌نام کرده‌اید" in text
    assert "نظرتان را با ما به اشتراک بگذارید" in text

    markup = asyncio_run(channel_status._keyboard(FakeBot(), event, can_register=False))
    rows = markup.inline_keyboard
    assert rows[0][0].text == "💬 ثبت نظر"
    assert rows[0][0].url == "https://t.me/panel_flow_bot?start=reviews"
    assert rows[1][0].text == "مشاهده پنل Volume 21"
    assert rows[1][0].url.endswith("?start=panel_4321")


def test_archived_panel_without_review_enabled_does_not_make_false_review_promise():
    event = SimpleNamespace(
        id=4322,
        volume=22,
        title="Legacy Archived Panel",
        archived=True,
        status=EventStatus.COMPLETED,
        feedback_enabled=False,
        capacity=15,
        registration_open=False,
        registration_closed_reason="manual",
    )
    text = channel_status._status_text(event, 0)
    assert text == "📦 این پنل برگزار شده و به آرشیو منتقل شده است."
    markup = asyncio_run(channel_status._keyboard(FakeBot(), event, can_register=False))
    assert len(markup.inline_keyboard) == 1
    assert markup.inline_keyboard[0][0].url.endswith("?start=panel_4322")


def test_archiving_edits_existing_connected_status_post_with_review_link(monkeypatch):
    engine, sync, owner, event = make_env(monkeypatch, threshold=3)
    try:
        add_booking(sync, owner, event, 5)
        bot = FakeBot()
        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        original_message_id = sync.query(ChannelAnnouncement).one().status_message_id

        event.status = EventStatus.COMPLETED
        event.registration_open = False
        event.registration_closed_reason = "manual"
        event.archived = True
        event.feedback_enabled = True
        sync.commit()

        assert asyncio_run(reconcile_event_channel_status(bot, event.id)) is True
        assert len(bot.sent) == 1
        updated = bot.edited[-1]
        assert updated["message_id"] == original_message_id
        assert "این پنل برگزار شده و به آرشیو منتقل شده است." in updated["text"]
        assert "خوشحال می‌شویم نظرتان را با ما به اشتراک بگذارید" in updated["text"]
        assert updated["reply_markup"].inline_keyboard[0][0].text == "💬 ثبت نظر"
        assert updated["reply_markup"].inline_keyboard[0][0].url.endswith("?start=reviews")
    finally:
        sync.close(); engine.dispose()
