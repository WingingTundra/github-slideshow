"""Focused V77 safeguards: additive schema, idempotency and pure validation logic."""
from __future__ import annotations

import ast
import json
import re
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlparse

import pytest
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError

from app.db.models import Base

ROOT = Path(__file__).resolve().parents[1]
FEATURE_SOURCE = (ROOT / "app/bot/handlers/v77_features.py").read_text(encoding="utf-8")
MIGRATION_SOURCE = (ROOT / "migrations/033_v77_community_hub.sql").read_text(encoding="utf-8")
V77_TABLES = {
    "archived_panel_content", "quick_fun_activities", "quick_fun_responses",
    "shop_requests", "lucky_draw_campaigns", "lucky_draw_claims", "reward_issues",
}


def _pure_v77_functions():
    """Compile only dependency-light validators without importing the aiogram runtime."""
    tree = ast.parse(FEATURE_SOURCE)
    wanted = {"_safe_url", "_parse_quickfun_payload", "_parse_odds", "_choose_prize"}
    nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in wanted]
    assert {n.name for n in nodes} == wanted
    module = ast.Module(body=nodes, type_ignores=[])
    namespace = {
        "urlparse": urlparse,
        "json": json,
        "DRAW_DEFAULT_ODDS": {15: 60, 25: 25, 50: 12, 100: 3},
        "secrets": SimpleNamespace(randbelow=lambda _upper: 0),
    }
    exec(compile(ast.fix_missing_locations(module), "<v77-pure-functions>", "exec"), namespace)
    return namespace


def test_v77_additive_migration_declares_all_new_persistent_records():
    lowered = MIGRATION_SOURCE.lower()
    for table in V77_TABLES:
        assert f"create table if not exists {table}" in lowered
        assert table in Base.metadata.tables
    # V77 migration intentionally contains no destructive history/table operation.
    assert not re.search(r"\b(drop\s+table|truncate\s+table|delete\s+from)\b", lowered)
    assert "on conflict (key) do nothing" in lowered
    assert "v77_lucky_draw_activation_lock" in lowered
    assert "created_at, updated_at" in lowered


def test_v77_schema_is_constructible_on_fresh_sqlite_metadata():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with engine.connect() as connection:
        names = set(connection.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table'").scalars())
    assert V77_TABLES <= names
    engine.dispose()


def test_quick_fun_user_response_is_unique_per_activity_and_person():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with engine.begin() as connection:
        activity_id = connection.execute(Base.metadata.tables["quick_fun_activities"].insert().values(
            kind="quiz", title="A quiz", prompt="A question", status="published",
            created_by_telegram_id=1, updated_by_telegram_id=1,
        )).inserted_primary_key[0]
        table = Base.metadata.tables["quick_fun_responses"]
        connection.execute(table.insert().values(activity_id=activity_id, telegram_id=77, response_value="0"))
        with pytest.raises(IntegrityError):
            connection.execute(table.insert().values(activity_id=activity_id, telegram_id=77, response_value="1"))
    engine.dispose()


def test_only_one_lucky_draw_campaign_can_be_active():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    table = Base.metadata.tables["lucky_draw_campaigns"]
    with engine.begin() as connection:
        common = dict(label="Campaign", probabilities_json='{"15":60,"25":25,"50":12,"100":3}',
                      created_by_telegram_id=1)
        connection.execute(table.insert().values(**common, active=True))
        connection.execute(table.insert().values(**common, active=False))
        with pytest.raises(IntegrityError):
            connection.execute(table.insert().values(**common, active=True))
    engine.dispose()


def test_shop_cost_and_discount_percent_database_constraints():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    table = Base.metadata.tables["shop_requests"]
    with engine.begin() as connection:
        connection.execute(table.insert().values(telegram_id=9, discount_percent=10, xp_cost=20, status="pending"))
        connection.execute(table.insert().values(telegram_id=10, discount_percent=100, xp_cost=160, status="pending"))
        with pytest.raises(IntegrityError):
            connection.execute(table.insert().values(telegram_id=11, discount_percent=0, xp_cost=20, status="pending"))
        with pytest.raises(IntegrityError):
            connection.execute(table.insert().values(telegram_id=12, discount_percent=101, xp_cost=20, status="pending"))
        with pytest.raises(IntegrityError):
            connection.execute(table.insert().values(telegram_id=13, discount_percent=25, xp_cost=0, status="pending"))
    engine.dispose()


def test_v77_url_validation_accepts_http_https_and_rejects_unsafe_targets():
    functions = _pure_v77_functions()
    validate = functions["_safe_url"]
    assert validate("https://example.org/path") == "https://example.org/path"
    assert validate("http://example.org/resource") == "http://example.org/resource"
    for value in ("javascript:alert(1)", "file:///etc/passwd", "https://user:pass@example.org", "https://example.org:99999", "not a url"):
        with pytest.raises(ValueError):
            validate(value)


def test_quick_fun_parser_validates_quiz_wyr_and_riddle_shapes():
    parse = _pure_v77_functions()["_parse_quickfun_payload"]
    quiz = parse("quiz | Basics | Choose one | A;B | 2 | Explanation")
    assert quiz["kind"] == "quiz" and quiz["correct_option"] == 1
    assert json.loads(quiz["options_json"]) == ["A", "B"]
    wyr = parse("wyr | Choice | Pick one | Left | Right")
    assert wyr["kind"] == "wyr" and wyr["correct_option"] is None
    riddle = parse("riddle | Riddle | What am I? | A shadow | Think of light")
    assert riddle["kind"] == "riddle" and riddle["answer_text"] == "A shadow"
    with pytest.raises(ValueError):
        parse("quiz | Broken | Question | only-one | 2")


def test_lucky_draw_odds_require_all_tiers_and_exactly_100_percent():
    parse = _pure_v77_functions()["_parse_odds"]
    assert parse("15=60,25=25,50=12,100=3") == {15: 60, 25: 25, 50: 12, 100: 3}
    for bad in ("15=50,25=20,50=20,100=5", "15=100,25=0,50=0", "15=-1,25=50,50=50,100=1", "15=60,15=60,25=25,50=12,100=3"):

        with pytest.raises(ValueError):
            parse(bad)


def test_secure_draw_choice_respects_probability_boundaries():
    functions = _pure_v77_functions()
    choose = functions["_choose_prize"]
    odds = {15: 60, 25: 25, 50: 12, 100: 3}
    functions["secrets"].randbelow = lambda _upper: 0
    assert choose(odds) == 15
    functions["secrets"].randbelow = lambda _upper: 60
    assert choose(odds) == 25
    functions["secrets"].randbelow = lambda _upper: 85
    assert choose(odds) == 50
    functions["secrets"].randbelow = lambda _upper: 99
    assert choose(odds) == 100


def test_quick_fun_answer_handler_has_no_xp_or_progression_award_call():
    tree = ast.parse(FEATURE_SOURCE)
    node = next(n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "quick_fun_answer")
    called = {n.func.id for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
    assert not (called & {"award_once", "total_xp", "xp_value", "record_paid_panel_award"})
    assert "XPAward" not in ast.get_source_segment(FEATURE_SOURCE, node)


def test_past_panels_uses_only_completed_and_explicitly_archived_events():
    # Both user and admin listing queries must enforce the lifecycle source of truth.
    assert FEATURE_SOURCE.count("Event.archived.is_(True)") >= 3
    assert FEATURE_SOURCE.count("Event.status == EventStatus.COMPLETED") >= 3
    assert "httpx" not in FEATURE_SOURCE and "requests.get" not in FEATURE_SOURCE
    assert "urlopen" not in FEATURE_SOURCE


def test_admin_feature_handlers_check_admin_identity_before_mutation():
    tree = ast.parse(FEATURE_SOURCE)
    protected = [node for node in tree.body if isinstance(node, ast.AsyncFunctionDef)
                 and (node.name.startswith("admin_") or node.name.startswith("v77_admin"))]
    assert protected
    missing = [node.name for node in protected if "_is_admin" not in ast.get_source_segment(FEATURE_SOURCE, node)]
    assert missing == []


def test_refund_flow_rechecks_accepted_discount_code_before_ledger_credit():
    tree = ast.parse(FEATURE_SOURCE)
    functions = {node.name: node for node in tree.body if isinstance(node, ast.AsyncFunctionDef)}
    helper = ast.get_source_segment(FEATURE_SOURCE, functions["_refund_blocked_by_accepted_code"])
    assert "accepted_at is not None" in helper
    for name in ("admin_reward_refund_start", "admin_reward_refund_save", "admin_reward_refund_confirm"):
        assert "_refund_blocked_by_accepted_code" in ast.get_source_segment(FEATURE_SOURCE, functions[name])


def test_challenge_answer_requires_preview_and_explicit_confirmation():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    assert 'CommunityStates.confirming_challenge_answer' in source
    assert 'callback_data="community:challenge:submit:confirm"' in source
    assert '@router.callback_query(F.data == "community:challenge:submit:confirm")' in source
    # The submit route is numeric-only, so :confirm cannot be parsed as an integer challenge id.
    assert 'F.data.regexp(r"^community:challenge:submit:\\d+$")' in source


def test_reference_answer_is_only_rendered_after_results_are_published():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    assert source.count('if challenge.challenge_type == "knowledge" and challenge.reference_answer:') >= 2
    # Both public rendering entry points explicitly guard this content behind a published state.
    assert source.count('elif challenge.status == "published":') >= 2


def test_challenge_awaiting_category_includes_submitted_open_and_closed_challenges():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    normalized = " ".join(source.split())
    assert 'CommunityChallenge.status.in_(("open", "closed") if category == "awaiting" else ("published",))' in normalized
    assert 'has_active_feature_restriction(session, telegram_id, "challenges")' in source
