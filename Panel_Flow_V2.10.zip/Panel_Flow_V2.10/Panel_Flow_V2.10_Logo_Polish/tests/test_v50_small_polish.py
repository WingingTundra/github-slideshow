from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_panel_catalogue_restores_intro_and_uses_fixed_metadata_lines():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert '"پنل‌ها به‌صورت خلاصه نمایش داده شده‌اند.\\n"' in source
    assert '"برای جزئیات و ثبت‌نام، پنل را انتخاب کنید.\\n"' in source
    assert 'panel_detail_line("روز و تاریخ"' in source
    assert "base_price = int(event.price_per_person or 0)" in source
    assert "alternative_price = int(event.price_without_cafe_order) if event.price_without_cafe_order else 0" in source
    assert 'list_price = "رایگان"' in source
    assert 'f"{_compact_toman(base_price)} + کافه / {_compact_toman(alternative_price)} بدون سفارش"' in source
    assert 'seats_label = public_catalogue_availability_label(' in source
    disclosure = (ROOT / "app/services/seat_disclosure.py").read_text(encoding="utf-8")
    assert 'ظرفیت تکمیل شده است · فهرست انتظار فعال است' in disclosure
    assert 'else f"🪑 {seats_label}"' in source
    assert 'seats_label == "ظرفیت پنل در حال تکمیل است."' in source
    assert 'text += "\\n\\n".join(event_blocks)' in source
    assert "trailing blank paragraph after the last panel" in source


def test_checkout_removes_redundant_initial_reservation_message_and_uses_en_dash():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    checkout = source.split("async def finalize_booking", 1)[1].split('@router.callback_query(F.data == "booking:confirm")', 1)[0]
    assert '"✅ رزرو اولیه ثبت شد.\\n"' not in checkout
    assert 'مرحلهٔ ۳ از ۳ – پرداخت و ارسال رسید' in checkout
    assert 'مرحلهٔ ۳ از ۳ — پرداخت و ارسال رسید' not in checkout


def test_event_and_booking_summary_protect_rtl_lines_and_use_western_participant_indices():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    event_text = source.split("def event_text(", 1)[1].split("async def dispatch_start_payload", 1)[0]
    assert 'panel_detail_line("ساعت", time_value' in event_text
    booking_summary = source.split('lines = "\\n".join(', 1)[1].split('notice = ""', 1)[0]
    assert r'\u200f{i + 1}. \u2066{escape(p[' in booking_summary
    assert r'\u2069"' in booking_summary
    assert "_fa_digits(i + 1)" not in booking_summary
    assert 'مرحلهٔ ۲ از ۳ – بررسی و تأیید' in source


def test_admin_menu_order_labels_and_icons_are_polished():
    source = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    admin = source.split("def admin_menu(", 1)[1].split("def admin_content_hub_keyboard", 1)[0]
    assert admin.index('text="➕ ایجاد پنل جدید"') < admin.index('text="📋 مدیریت پنل‌ها"')
    assert admin.index('text="📋 مدیریت پنل‌ها"') < admin.index('text="📣 اطلاع‌رسانی‌ها"')
    assert 'callback_data="admin:settings:hub"' in admin
    event_menu = source.split("def admin_event_menu(", 1)[1].split("def final_panel_state_keyboard", 1)[0]
    assert 'text="📡 اتصال پست کانال"' in event_menu
    assert 'text="🔔 یادآوری دستی"' in event_menu
    community = source.split("def admin_community_menu", 1)[1]
    assert 'text=("🟢 لیدربورد عمومی: فعال" if leaderboard_enabled else "🔴 لیدربورد عمومی: غیرفعال")' in community
    assert 'Public Leaderboard' not in community


def test_reminder_has_today_sentence_in_preview_and_sent_copy():
    source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    preview = source.split("async def reminder_preview", 1)[1].split('@router.callback_query(F.data == "admin:today_cancel")', 1)[0]
    send = source.split("async def reminder_send", 1)[1].split('@router.callback_query', 1)[0]
    assert "امروز روز برگزاری پنل است!" in preview
    assert "امروز روز برگزاری پنل است!" in send
    assert 'panel_detail_line("زمان", panel_time, icon="⏰")' in preview and 'panel_detail_line("زمان", panel_time, icon="⏰")' in send


def test_community_home_ranking_line_removed_but_help_is_clearer():
    community = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    home = community.split("async def render_community_home(", 1)[1].split('@router.callback_query(F.data == "community:home")', 1)[0]
    assert "Public ranking is based first" not in home
    assert "🏆 <b>لیدربورد و چالش‌ها</b>" in home
    assert "Quick Fun" not in home
    assert "لیدربورد" in home and 'ltr_isolate("XP")' in home and "شاپ" in home
    help_source = (ROOT / "app/bot/content.py").read_text(encoding="utf-8")
    assert "گزارش سالانهٔ Wrapped" in help_source
    assert "اگر تعداد برابر باشد، XP رتبه را مشخص می‌کند" not in help_source


def test_waitlist_queries_use_select_distinct_not_expression_level_distinct():
    source = (ROOT / "app/services/waitlist.py").read_text(encoding="utf-8")
    assert "from sqlalchemy import func, or_, select" in source
    assert "select(distinct(" not in source
    assert source.count("select(WaitlistEntry.event_id).distinct()") == 2


def test_compact_catalogue_prices_preserve_exact_values():
    import ast

    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_compact_toman")
    isolated = ast.Module(body=[function], type_ignores=[])
    namespace = {}
    exec(compile(ast.fix_missing_locations(isolated), str(ROOT / "app/bot/handlers/user.py"), "exec"), namespace)
    format_price = namespace["_compact_toman"]
    assert format_price(100_000) == "100k toman"
    assert format_price(1_500_000) == "1.5m toman"
    assert format_price(1_250_000) == "1.25m toman"
    assert format_price(12_345) == "12,345 toman"
    assert format_price(0) == "0 toman"


def test_panel_detail_description_precedes_logistics_and_details_stay_together():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    event_text = source.split("def event_text(", 1)[1].split("async def dispatch_start_payload", 1)[0]
    assert "description_heading = \"\\n\\n📝 <b>توضیحات</b>\\n\"" in event_text
    assert "text = heading + description_heading + description + details_block" in event_text
    for field in ("event.language", "event.event_day_label", "event.start_time_label", "event.venue", "event.capacity", "event.price_per_person", "event.host_name", "event.address"):
        assert field in event_text
    assert "telegram_html_visible_units(details_block)" in event_text


def test_long_panel_description_is_shortened_before_bottom_logistics():
    import ast
    from html import escape
    from types import SimpleNamespace

    from app.bot.text_limits import DEFAULT_SAFE_TEXT_LIMIT, limit_telegram_html, telegram_html_visible_units
    from app.display_utils import has_end_time_label, volume_label, panel_detail_line, rtl_isolate
    from app.services.pricing import panel_price_label

    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "event_text")
    isolated = ast.Module(body=[function], type_ignores=[])
    namespace = {
        "Event": object,
        "escape": escape,
        "_ltr_display": lambda value: f"\u2066{escape(str(value))}\u2069",
        "has_end_time_label": has_end_time_label,
        "volume_label": volume_label,
        "panel_detail_line": panel_detail_line,
        "rtl_isolate": rtl_isolate,
        "registration_is_open": lambda event: True,
        "limit_telegram_html": limit_telegram_html,
        "telegram_html_visible_units": telegram_html_visible_units,
        "DEFAULT_SAFE_TEXT_LIMIT": DEFAULT_SAFE_TEXT_LIMIT,
        "panel_price_label": panel_price_label,
        "should_disclose_remaining_seats": __import__("app.services.seat_disclosure", fromlist=["should_disclose_remaining_seats"]).should_disclose_remaining_seats,
        "should_show_capacity_filling_message": __import__("app.services.seat_disclosure", fromlist=["should_show_capacity_filling_message"]).should_show_capacity_filling_message,
        "_fa_digits": lambda value: str(value).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")),
    }
    exec(compile(ast.fix_missing_locations(isolated), str(ROOT / "app/bot/handlers/user.py"), "exec"), namespace)
    event = SimpleNamespace(
        volume=6,
        title="How to make love?",
        description=("A long discussion prompt. " * 300),
        language="English",
        event_day_label="پنجشنبه",
        event_date_label="۲۵ مهرماه ۱۴۰۵",
        start_time_label="18:00",
        end_time_label="20:00",
        venue="کافه کتاب فانوس",
        capacity=10,
        price_per_person=70_000,
        price_without_cafe_order=None,
        host_name="سینا ضیائی",
        address="بلوار صیاد شیرازی ۲۲ پلاک ۵۰",
    )
    rendered = namespace["event_text"](event, 0)
    assert rendered.index("How to make love?") < rendered.index("توضیحات")
    assert rendered.index("A long discussion prompt") < rendered.index("زبان پنل")
    assert rendered.index("زبان پنل") < rendered.index("18:00") < rendered.index("کافه کتاب فانوس")
    assert rendered.index("کافه کتاب فانوس") < rendered.index("70,000")
    assert rendered.index("70,000") < rendered.index("میزبان") < rendered.index("ظرفیت")
    assert rendered.index("70,000") < rendered.index("میزبان") < rendered.index("آدرس")
    assert "بلوار صیاد شیرازی ۲۲ پلاک ۵۰" in rendered
    assert telegram_html_visible_units(rendered) <= DEFAULT_SAFE_TEXT_LIMIT
