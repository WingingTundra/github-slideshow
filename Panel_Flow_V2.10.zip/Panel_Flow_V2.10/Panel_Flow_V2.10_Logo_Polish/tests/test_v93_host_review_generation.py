from __future__ import annotations

import re
from pathlib import Path
from types import SimpleNamespace

from sqlalchemy import create_engine

from app.db.models import Base, Event
from app.services.host_submission_review import (
    approval_callback_data,
    bump_submission_revision,
    current_submission_revision,
    rejection_callback_data,
    submission_revision_matches,
)

ROOT = Path(__file__).resolve().parents[1]


def test_submission_revision_increments_monotonically_and_rejects_old_previews():
    event = SimpleNamespace(submission_revision=1)
    first_preview_revision = current_submission_revision(event)
    assert submission_revision_matches(event, first_preview_revision)

    assert bump_submission_revision(event) == 2
    assert current_submission_revision(event) == 2
    assert not submission_revision_matches(event, first_preview_revision)
    assert submission_revision_matches(event, 2)


def test_old_admin_review_preview_is_invalid_after_host_reject_edit_and_resubmit():
    event = SimpleNamespace(submission_status="submitted", submission_revision=7)
    admin_a_opened_revision = current_submission_revision(event)

    # Admin B rejects revision 7; the host edits and resubmits a new generation.
    event.submission_status = "rejected"
    event.submission_status = "draft"
    event.title = "Edited by host"
    event.submission_revision = bump_submission_revision(event)
    event.submission_status = "submitted"

    assert event.submission_revision == 8
    assert not submission_revision_matches(event, admin_a_opened_revision)
    assert submission_revision_matches(event, 8)


def test_submission_revision_normalizes_legacy_objects_and_rejects_invalid_expected_values():
    event = SimpleNamespace()
    assert current_submission_revision(event) == 0
    assert submission_revision_matches(event, 0)
    assert not submission_revision_matches(event, "not-a-number")
    assert bump_submission_revision(event) == 1


def test_host_review_callback_data_is_under_telegram_limit_for_large_ids():
    # IDs/revisions at signed 32-bit maximum are longer than ordinary current values.
    event_id = 2_147_483_647
    revision = 2_147_483_647
    approval = approval_callback_data(event_id, revision)
    rejection = rejection_callback_data(event_id, revision, "0123456789abcdef")

    assert approval == f"hrap:{event_id}:{revision}"
    assert rejection == f"hrrj:{event_id}:{revision}:0123456789abcdef"
    assert len(approval.encode("utf-8")) <= 64
    assert len(rejection.encode("utf-8")) <= 64


def test_host_review_callback_builders_reject_invalid_parameters():
    import pytest

    with pytest.raises(ValueError):
        approval_callback_data(0, 1)
    with pytest.raises(ValueError):
        rejection_callback_data(1, -1, "0123456789abcdef")
    with pytest.raises(ValueError):
        rejection_callback_data(1, 1, "not-a-valid-token")


def test_event_model_includes_submission_revision_and_sqlite_can_create_schema():
    assert "submission_revision" in Event.__table__.columns
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with engine.connect() as conn:
        columns = {row[1] for row in conn.exec_driver_sql("PRAGMA table_info(events)").all()}
    assert "submission_revision" in columns
    engine.dispose()


def test_migration_adds_revision_and_backfills_existing_pending_submissions():
    from app.db.migration_utils import split_sql_statements

    migration = (ROOT / "migrations/041_v93_host_submission_revision.sql").read_text(encoding="utf-8")
    assert "ADD COLUMN IF NOT EXISTS submission_revision INTEGER NOT NULL DEFAULT 0" in migration
    assert "WHERE submission_status = 'submitted' AND submission_revision = 0" in migration
    statements = split_sql_statements(migration)
    assert len(statements) == 2
    assert statements[0].startswith("-- V93:") or statements[0].startswith("ALTER TABLE")


def test_admin_review_previews_and_confirmations_are_revision_bound():
    source = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    assert 'callback_data=approval_callback_data(event_id, submission_revision)' in source
    assert 'F.data.regexp(r"^hrap:\\d+:\\d+$")' in source
    assert 'not submission_revision_matches(event, expected_revision)' in source
    assert 'review_submission_revision=submission_revision' in source
    assert 'callback_data = rejection_callback_data(int(data["review_event_id"]), revision, token)' in source
    assert 'F.data.regexp(r"^hrrj:\\d+:\\d+:[a-f0-9]{16}$")' in source
    assert "admin_review_approve_confirm_legacy" in source
    assert "admin_review_reject_confirm_legacy" in source


def test_every_host_resubmission_and_admin_edit_invalidates_old_pending_review_revision():
    console = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert 'submission_revision=1 if submit else 0' in console
    assert 'bump_submission_revision(event)' in console
    assert admin.count('bump_submission_revision(event)') >= 2  # quick edit and full-form edit
    quick = admin.split("async def quick_edit_confirm(", 1)[1].split("@router.message(AdminEditStates.title)", 1)[0]
    assert 'bump_submission_revision(event)' in quick
    assert 'event.status == EventStatus.DRAFT and event.submission_status == "submitted"' in admin


def test_expired_panel_creation_keyboard_is_intercepted_before_user_fsm_handlers():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    reply_menu = (ROOT / "app/bot/handlers/reply_menu.py").read_text(encoding="utf-8")
    start = admin.index("async def expired_panel_creation_reply_actions")
    end = admin.index("@router.callback_query", start)
    handler = admin[start:end]
    route_start = reply_menu.index("async def panel_creation_reply_keyboard_action")
    route_end = reply_menu.index("REPLY_MENU_ACTIONS =", route_start)
    early_handler = reply_menu[route_start:route_end]
    assert '@router.message(F.text.in_({"⬅️ مرحلهٔ قبل", "❌ لغو ایجاد"}))' in reply_menu
    assert "admin_event_creation_reply_actions" in early_handler
    assert "expired_panel_creation_reply_actions" in early_handler
    assert 'startswith("AdminEventStates:")' in early_handler
    assert "ReplyKeyboardRemove()" in handler
    assert "if current_state:" in handler
    assert "اطلاعات فرایند دیگری، در صورت فعال‌بودن، حفظ شده است" in handler
    assert "await state.clear()" not in handler
    main = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")
    assert main.index("dp.include_router(reply_menu_router)") < main.index("dp.include_router(user_router)")


def test_question_file_mutations_invalidate_pending_host_review_generation():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    mutation_blocks = [
        admin.split("async def event_pdf_replace_skip(", 1)[1].split("@router.callback_query", 1)[0],
        admin.split("async def event_pdf_replace(", 1)[1].split("@router.message(AdminManageStates.waiting_pdf)", 1)[0],
        admin.split("async def event_pdf_replace_wrong(", 1)[1].split("async def _start_edit(", 1)[0],
        admin.split("async def quick_edit_questions_file_remove_commit(", 1)[1].split("@router.callback_query", 1)[0],
    ]
    for block in mutation_blocks:
        assert 'event.status == EventStatus.DRAFT and event.submission_status == "submitted"' in block
        assert "bump_submission_revision(event)" in block
