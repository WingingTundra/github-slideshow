from __future__ import annotations

import asyncio
import ast
import os
import time
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.db.models import EventStatus, PaymentStatus, RegistrationStatus
from app.display_utils import has_end_time_label
from app.services.upload_maintenance import prune_orphan_files

ROOT = Path(__file__).resolve().parents[1]


def test_optional_end_time_recognizes_both_legacy_sentinels():
    assert has_end_time_label("19:00")
    for value in (None, "", "  ", "-", "—", "–", "−"):
        assert not has_end_time_label(value)


def test_payment_review_imports_shared_utc_clock():
    source = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    imported = {
        alias.name
        for node in tree.body if isinstance(node, ast.ImportFrom)
        for alias in node.names
    }
    assert "utc_now_naive" in imported
    assert "now = utc_now_naive()" in source


def test_api_only_selects_published_non_archived_panels_and_can_omit_route():
    source = (ROOT / "app/api.py").read_text(encoding="utf-8")
    assert "if settings.api_enabled:" in source
    public_service = (ROOT / "app/services/public_events.py").read_text(encoding="utf-8")
    assert "Event.status == EventStatus.PUBLISHED" in public_service
    assert "Event.archived.is_(False)" in public_service
    assert '"stored_status"' not in public_service
    assert '"archived":' not in public_service
    assert '"reserved_participants"' not in public_service


def test_database_advisory_lock_precedes_create_all():
    source = (ROOT / "app/db/init.py").read_text(encoding="utf-8")
    lock = source.index("pg_advisory_xact_lock")
    create = source.index("Base.metadata.create_all")
    migrations = source.index("await _run_migrations(conn)")
    assert lock < create < migrations


def test_orphan_cleanup_deletes_only_old_unreferenced_managed_files(tmp_path):
    old_file = tmp_path / "old-orphan.pdf"
    recent_file = tmp_path / "recent-orphan.pdf"
    referenced_file = tmp_path / "referenced-receipt.jpg"
    outside_file = tmp_path.parent / f"outside-{tmp_path.name}.txt"
    for path in (old_file, recent_file, referenced_file, outside_file):
        path.write_text("test", encoding="utf-8")
    old = time.time() - 100 * 24 * 60 * 60
    os.utime(old_file, (old, old))
    os.utime(outside_file, (old, old))

    removed = prune_orphan_files(
        tmp_path,
        {referenced_file.resolve()},
        cutoff_epoch=time.time() - 90 * 24 * 60 * 60,
    )

    assert removed == 1
    assert not old_file.exists()
    assert recent_file.exists()
    assert referenced_file.exists()
    assert outside_file.exists()
    outside_file.unlink()


def test_restart_preserves_queued_telegram_updates():
    source = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")
    assert "delete_webhook(drop_pending_updates=False)" in source
    assert "periodic_orphan_upload_cleanup" in source


def test_compose_requires_a_secret_instead_of_default_database_password():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    example = (ROOT / ".env.example").read_text(encoding="utf-8")
    assert "POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?Set POSTGRES_PASSWORD in .env}" in compose
    assert "POSTGRES_PASSWORD=panel_flow" not in compose
    assert "POSTGRES_PASSWORD=" in example
    assert "UPLOAD_ORPHAN_RETENTION_DAYS=30" in example
    assert "RECEIPT_RETENTION_DAYS=30" in example

class _ScalarResult:
    def __init__(self, value):
        self.value = value

    def scalar_one_or_none(self):
        return self.value

    def scalar_one(self):
        return self.value


class _PaymentReviewSession:
    """Statement-aware mock: assertions do not depend on SQL call ordering."""
    def __init__(self, payment, admin, event):
        self.payment = payment
        self.admin = admin
        self.event = event
        self.committed = False
        self.added = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def execute(self, statement):
        sql = str(statement).lower()
        if "count(" in sql:
            return _ScalarResult(0)
        if "from users" in sql:
            return _ScalarResult(self.admin)
        if "from payments" in sql:
            return _ScalarResult(self.payment)
        raise AssertionError(f"Unexpected query in payment review unit test: {sql}")

    async def get(self, model, identity):
        if getattr(model, "__name__", "") == "Event" and int(identity) == int(self.event.id):
            return self.event
        return None

    def add(self, row):
        self.added.append(row)

    async def flush(self):
        return None

    async def commit(self):
        self.committed = True


@pytest.mark.parametrize("approve", [True, False], ids=["approve-payment", "reject-payment"])
def test_payment_review_executes_approval_and_rejection_paths(monkeypatch, approve):
    pytest.importorskip("aiogram", reason="handler execution tests require project runtime dependencies")
    from app.config import settings
    if not settings.database_url:
        monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://test:test@localhost/test")
    from app.bot.handlers import admin_payment_actions as payment_actions
    from app.services import community
    from app.services.payment_review import receipt_review_token

    event = SimpleNamespace(
        id=3, title="Review test", volume=24, questions_pdf_path=None,
        status=EventStatus.PUBLISHED, archived=False, capacity=10,
    )
    owner = SimpleNamespace(telegram_id=99123)
    booking = SimpleNamespace(
        id=7, event_id=event.id, event=event, booked_by=owner,
        booked_by_user_id=99, status=RegistrationStatus.PENDING_VERIFICATION,
        confirmed_at=None, expires_at=None,
    )
    payment = SimpleNamespace(
        id=12, booking_id=booking.id, booking=booking,
        status=PaymentStatus.PENDING, receipt_file="/data/uploads/receipt.jpg",
        receipt_file_name="receipt.jpg", receipt_text="", amount=Decimal("125000"),
        receipt_uploaded_at=None, reviewed_at=None, reviewed_by=None,
    )
    admin = SimpleNamespace(id=5, role="super_admin")
    session = _PaymentReviewSession(payment, admin, event)

    monkeypatch.setattr(payment_actions, "allowed", AsyncMock(return_value=True))
    monkeypatch.setattr(payment_actions, "SessionLocal", lambda: session)
    monkeypatch.setattr(payment_actions, "lock_payment_review_rows", AsyncMock(return_value=(payment, booking, event)))
    monkeypatch.setattr(payment_actions, "resolve_upload_path", lambda _path: None)
    monkeypatch.setattr(payment_actions, "reconcile_event_channel_status", AsyncMock())
    monkeypatch.setattr(payment_actions, "notify_waitlist_capacity_available", AsyncMock())
    monkeypatch.setattr(payment_actions, "record_confirmed_booking", AsyncMock())
    monkeypatch.setattr(payment_actions, "write_admin_action", AsyncMock())
    monkeypatch.setattr(payment_actions, "seats_used", AsyncMock(return_value=0))
    monkeypatch.setattr(payment_actions, "registration_is_open", lambda _event: True)
    monkeypatch.setattr(community, "record_paid_panel_award", AsyncMock())
    monkeypatch.setattr(community, "unlock_eligible_achievements", AsyncMock())

    send_message = AsyncMock()
    c = SimpleNamespace(
        data=f"admin:payment:{'approve' if approve else 'reject'}:{payment.id}:{receipt_review_token(payment)}",
        from_user=SimpleNamespace(id=555),
        bot=SimpleNamespace(send_message=send_message),
        message=SimpleNamespace(edit_text=AsyncMock()),
        answer=AsyncMock(),
    )

    if approve:
        asyncio.run(payment_actions.review(c, approve))
    else:
        asyncio.run(payment_actions.review(c, approve, reason_category="other", reason_text="Test rejection reason"))

    assert session.committed is True
    assert payment.status == (PaymentStatus.APPROVED if approve else PaymentStatus.REJECTED)
    assert booking.status == (RegistrationStatus.CONFIRMED if approve else RegistrationStatus.REJECTED)
    assert payment.reviewed_by == admin.id
    assert payment.reviewed_at is not None
    assert booking.expires_at is None
    assert any(row.__class__.__name__ == "PaymentReviewAttempt" for row in session.added)
    send_message.assert_awaited()
    c.message.edit_text.assert_awaited_once()
    c.answer.assert_awaited_once()
