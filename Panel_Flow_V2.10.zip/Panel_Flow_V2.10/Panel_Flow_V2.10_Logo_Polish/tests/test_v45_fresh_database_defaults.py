from pathlib import Path

from app.db.models import AppSetting

ROOT = Path(__file__).resolve().parents[1]


def test_app_settings_timestamps_have_database_server_defaults():
    table = AppSetting.__table__
    for column_name in ("created_at", "updated_at"):
        column = table.c[column_name]
        assert column.nullable is False
        assert column.server_default is not None
        assert "CURRENT_TIMESTAMP" in str(column.server_default.arg).upper()


def test_all_app_settings_seed_statements_are_fresh_db_safe():
    migrations = sorted((ROOT / "migrations").glob("*.sql"))
    matching = []
    for path in migrations:
        sql = path.read_text(encoding="utf-8")
        lowered = " ".join(sql.lower().split())
        if "insert into app_settings" not in lowered:
            continue
        matching.append(path.name)
        # Any seed that omits the timestamps would still be safe due to server
        # defaults, but migrations should explicitly supply timestamps too.
        inserts = lowered.split("insert into app_settings")
        for insert in inserts[1:]:
            prefix = insert[:140]
            assert "(key, value, created_at, updated_at)" in prefix, (path.name, prefix)
    assert matching, "Expected app_settings seed migrations to be present"


def test_release_marker_and_preflight_before_migrations():
    source = (ROOT / "app" / "db" / "init.py").read_text(encoding="utf-8")
    assert "Panel Flow V97 database initialization started" in source
    start = source.index("await conn.run_sync(Base.metadata.create_all)")
    preflight = source.index("await _ensure_app_settings_timestamp_defaults(conn)")
    migrations = source.index("await _run_migrations(conn)")
    assert start < preflight < migrations
