from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
from decimal import Decimal
import ast
import importlib.util
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.models import (
    Base, Booking, Event, EventStatus, RegistrationStatus, User, UserRole, WaitlistEntry,
)
from app.time_utils import utc_now_naive
from app.services.waitlist import (
    WAITLIST_INVITATION_TTL,
    WAITLIST_RETRY_COOLDOWN,
    expire_waitlist_invitations_once,
    next_waitlist_candidate,
    record_waitlist_invitation_result,
)

ROOT = Path(__file__).resolve().parents[1]


class FakeAsyncSession:
    def __init__(self, sync_session):
        self.s = sync_session

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if exc_type:
            self.s.rollback()
        self.s.close()
        return False

    async def execute(self, stmt):
        return self.s.execute(stmt)

    async def get(self, entity, ident, **kwargs):
        return self.s.get(entity, ident)

    def add(self, item):
        self.s.add(item)

    async def commit(self):
        self.s.commit()

    async def rollback(self):
        self.s.rollback()


class Factory:
    def __init__(self, engine):
        self.engine = engine

    def __call__(self):
        return FakeAsyncSession(Session(self.engine))




def _stub_aiogram_markup_types(monkeypatch):
    aiogram_module = ModuleType("aiogram")
    types_module = ModuleType("aiogram.types")

    class InlineKeyboardButton:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.text = kwargs.get("text")
            self.callback_data = kwargs.get("callback_data")

    class InlineKeyboardMarkup:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.inline_keyboard = kwargs.get("inline_keyboard", [])

    class CopyTextButton:
        def __init__(self, *, text):
            self.text = text

    types_module.CopyTextButton = CopyTextButton
    types_module.InlineKeyboardButton = InlineKeyboardButton
    types_module.InlineKeyboardMarkup = InlineKeyboardMarkup
    aiogram_module.types = types_module
    monkeypatch.setitem(sys.modules, "aiogram", aiogram_module)
    monkeypatch.setitem(sys.modules, "aiogram.types", types_module)
    return InlineKeyboardMarkup, InlineKeyboardButton


def build_db(*, capacity=3, open_registration=True):
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session = Session(engine)
    event = Event(
        volume="V35", title="Reliability test", event_day_label="Friday",
        event_date_label="16 October", start_time_label="18:00", end_time_label="—",
        venue="Test", capacity=capacity, price_per_person=Decimal("100000"),
        status=EventStatus.PUBLISHED, registration_open=open_registration,
        registration_closed_reason=None, waitlist_enabled=True, archived=False,
    )
    session.add(event)
    users = []
    for telegram_id, name in [(35101, "User One"), (35102, "User Two"), (35103, "User Three"), (35104, "User Four")]:
        first, last = name.split()
        user = User(telegram_id=telegram_id, display_name=name, first_name=first, last_name=last, role=UserRole.PARTICIPANT)
        session.add(user)
        users.append(user)
    session.flush()
    session.commit()
    return engine, session, event, users


def test_waitlist_candidate_excludes_invitation_cooldown_and_keeps_fifo_among_eligible():
    engine, session, event, users = build_db(capacity=2)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        session.add_all([
            WaitlistEntry(event_id=event.id, user_id=users[0].id, requested_participant_count=1, position=1, status="waiting", next_invite_after=now + timedelta(minutes=5)),
            WaitlistEntry(event_id=event.id, user_id=users[1].id, requested_participant_count=2, position=2, status="waiting"),
            WaitlistEntry(event_id=event.id, user_id=users[2].id, requested_participant_count=1, position=3, status="waiting"),
        ])
        session.commit()
        selected_event, entry, user, free = asyncio.run(next_waitlist_candidate(FakeAsyncSession(session), event.id, now=now))
        assert selected_event.id == event.id
        assert entry.position == 2
        assert user.telegram_id == 35102
        assert free == 2
    finally:
        session.close()
        engine.dispose()


def test_invitation_claims_only_within_cumulative_seat_budget(monkeypatch):
    engine, session, event, users = build_db(capacity=3)
    try:
        session.add_all([
            WaitlistEntry(event_id=event.id, user_id=users[0].id, requested_participant_count=2, position=1, status="waiting"),
            WaitlistEntry(event_id=event.id, user_id=users[1].id, requested_participant_count=1, position=2, status="waiting"),
            WaitlistEntry(event_id=event.id, user_id=users[2].id, requested_participant_count=1, position=3, status="waiting"),
        ])
        session.commit()
        factory = Factory(engine)
        import app.db.session as db_session
        monkeypatch.setattr(db_session, "SessionLocal", factory)

        # The production service only needs these two aiogram types to compose the
        # invite keyboard. This test fake keeps the service testable offline.
        _stub_aiogram_markup_types(monkeypatch)

        from app.services.waitlist import notify_waitlist_capacity_available
        bot = SimpleNamespace(
            get_me=AsyncMock(return_value=SimpleNamespace(username="PanelFlowTestBot")),
            send_message=AsyncMock(),
        )
        sent = asyncio.run(notify_waitlist_capacity_available(bot, event.id))
        assert sent == 2
        assert bot.send_message.await_count == 2
        assert all("اکنون نوبت شما برای اقدام رسیده است" in call.args[1] for call in bot.send_message.await_args_list)
        assert all("رزرو یا نگه‌داشتن ظرفیت محسوب نمی‌شود" in call.args[1] for call in bot.send_message.await_args_list)
        session.expire_all()
        rows = session.execute(select(WaitlistEntry).order_by(WaitlistEntry.position)).scalars().all()
        assert [row.status for row in rows] == ["invited", "invited", "waiting"]
        assert rows[0].invitation_expires_at is not None
        assert rows[1].invitation_expires_at is not None
        invited_total = sum(row.requested_participant_count for row in rows if row.status == "invited")
        assert invited_total <= event.capacity
    finally:
        session.close()
        engine.dispose()


def test_failed_invitation_returns_entry_to_queue_tail_with_cooldown():
    engine, session, event, users = build_db(capacity=3)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        first = WaitlistEntry(event_id=event.id, user_id=users[0].id, requested_participant_count=1, position=1, status="inviting", invitation_expires_at=now + WAITLIST_INVITATION_TTL)
        second = WaitlistEntry(event_id=event.id, user_id=users[1].id, requested_participant_count=1, position=2, status="waiting")
        session.add_all([first, second])
        session.commit()
        first_id = first.id
        asyncio.run(record_waitlist_invitation_result(first_id, False, session_factory=Factory(engine), now=now))
        session.expire_all()
        refreshed = session.get(WaitlistEntry, first_id)
        assert refreshed.status == "waiting"
        assert refreshed.invitation_expires_at is None
        assert refreshed.next_invite_after == now + WAITLIST_RETRY_COOLDOWN
        assert refreshed.position == 3
    finally:
        session.close()
        engine.dispose()


def test_expired_invitation_requeues_at_tail_and_other_waiters_get_priority():
    engine, session, event, users = build_db(capacity=1)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        invited = WaitlistEntry(
            event_id=event.id, user_id=users[0].id, requested_participant_count=1,
            position=1, status="invited", invitation_expires_at=now - timedelta(seconds=1),
        )
        waiting = WaitlistEntry(event_id=event.id, user_id=users[1].id, requested_participant_count=1, position=2, status="waiting")
        session.add_all([invited, waiting])
        session.commit()
        event_id = event.id
        invited_id = invited.id

        ready = asyncio.run(expire_waitlist_invitations_once(session_factory=Factory(engine), now=now))
        assert event_id in ready
        session.expire_all()
        recovered = session.get(WaitlistEntry, invited_id)
        assert recovered.status == "waiting"
        assert recovered.position > waiting.position
        assert recovered.invitation_expires_at is None
        assert recovered.next_invite_after == now + WAITLIST_RETRY_COOLDOWN
        candidate_event, candidate, invitee, free = asyncio.run(next_waitlist_candidate(FakeAsyncSession(session), event_id, now=now))
        assert candidate.id == waiting.id
        assert invitee.telegram_id == 35102
        assert free == 1
    finally:
        session.close()
        engine.dispose()


def test_expired_invitation_without_other_waiters_is_not_immediately_resent():
    engine, session, event, users = build_db(capacity=1)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        row = WaitlistEntry(
            event_id=event.id, user_id=users[0].id, requested_participant_count=1,
            position=1, status="invited", invitation_expires_at=now - timedelta(seconds=1),
        )
        session.add(row)
        session.commit()
        event_id = event.id
        ready_now = asyncio.run(expire_waitlist_invitations_once(session_factory=Factory(engine), now=now))
        assert event_id not in ready_now
        ready_after_cooldown = asyncio.run(expire_waitlist_invitations_once(
            session_factory=Factory(engine), now=now + WAITLIST_RETRY_COOLDOWN + timedelta(seconds=1)
        ))
        assert event_id in ready_after_cooldown
    finally:
        session.close()
        engine.dispose()


def test_failed_telegram_delivery_is_requeued_with_a_cooldown(monkeypatch):
    engine, session, event, users = build_db(capacity=1)
    try:
        row = WaitlistEntry(event_id=event.id, user_id=users[0].id, requested_participant_count=1, position=1, status="waiting")
        session.add(row)
        session.commit()
        factory = Factory(engine)
        import app.db.session as db_session
        monkeypatch.setattr(db_session, "SessionLocal", factory)
        _stub_aiogram_markup_types(monkeypatch)
        from app.services.waitlist import notify_waitlist_capacity_available
        bot = SimpleNamespace(
            get_me=AsyncMock(return_value=SimpleNamespace(username="PanelFlowTestBot")),
            send_message=AsyncMock(side_effect=RuntimeError("blocked chat")),
        )
        sent = asyncio.run(notify_waitlist_capacity_available(bot, event.id))
        assert sent == 0
        assert bot.send_message.await_count == 1
        session.expire_all()
        current = session.get(WaitlistEntry, row.id)
        assert current.status == "waiting"
        assert current.invitation_expires_at is None
        assert current.next_invite_after is not None
        assert current.position >= 2
    finally:
        session.close()
        engine.dispose()


def test_expired_invitation_on_cancelled_panel_is_closed_not_requeued():
    engine, session, event, users = build_db(capacity=1)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        event.status = EventStatus.CANCELLED
        event.registration_open = False
        row = WaitlistEntry(
            event_id=event.id, user_id=users[0].id, requested_participant_count=1,
            position=1, status="invited", invitation_expires_at=now - timedelta(seconds=1),
        )
        session.add(row)
        session.commit()
        asyncio.run(expire_waitlist_invitations_once(session_factory=Factory(engine), now=now))
        session.expire_all()
        current = session.get(WaitlistEntry, row.id)
        assert current.status == "closed"
        assert current.invitation_expires_at is None
        assert current.next_invite_after is None
    finally:
        session.close()
        engine.dispose()


def test_main_menu_runtime_labels_have_right_side_icons_and_correct_persian_order(monkeypatch):
    _stub_aiogram_markup_types(monkeypatch)
    module_path = ROOT / "app/bot/keyboards.py"
    spec = importlib.util.spec_from_file_location("panel_flow_v35_keyboard_test", module_path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    menu = module.main_menu()
    buttons = {button.callback_data: button.text for row in menu.inline_keyboard for button in row}
    assert buttons["user:pastpanels"].startswith("📚")
    assert buttons["user:community_about"] == "💬 جامعه و دربارهٔ ما"
    assert "user:community" not in buttons and "user:about" not in buttons
    panel = module.event_buttons(8, can_register=False, waitlist=True, waitlisted=True)
    assert any(button.callback_data == "user:waitlist:leave:8" for row in panel.inline_keyboard for button in row)


def test_admin_manual_waitlist_invite_commits_before_telegram_io():
    source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    start = source.index("async def invite_next_waitlisted_user")
    end = source.index('@router.callback_query(F.data.startswith("admin:event:questions:"))', start)
    block = source[start:end]
    assert block.index("await session.commit()") < block.index("await c.bot.get_me()") < block.index("await c.bot.send_message(")
    assert "record_waitlist_invitation_result(entry_id, True)" in block
    assert "record_waitlist_invitation_result(entry_id, False)" in block


def test_admin_and_user_modules_import_runtime_symbols_at_module_scope():
    admin = ast.parse((ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8"))
    user = ast.parse((ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8"))
    admin_imports = {
        alias.name
        for node in admin.body if isinstance(node, ast.ImportFrom) and node.module == "app.bot.keyboards"
        for alias in node.names
    }
    user_sqlalchemy_exc_imports = {
        alias.name
        for node in user.body if isinstance(node, ast.ImportFrom) and node.module == "sqlalchemy.exc"
        for alias in node.names
    }
    assert "personal_reward_keyboard" in admin_imports
    assert "IntegrityError" in user_sqlalchemy_exc_imports


def test_main_menu_uses_one_combined_community_about_destination():
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert 'text="💬 جامعه و دربارهٔ ما"' in keyboards
    assert 'callback_data="user:community_about"' in keyboards
    assert '"user:community", "user:about", "user:community_about"' in (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")


def test_waitlist_can_be_left_and_receipt_state_is_not_lost_on_start():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    main = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")
    assert 'callback_data=f"user:waitlist:leave:{event_id}"' in keyboards
    assert 'F.data.regexp(r"^user:waitlist:leave:\\d+$")' in user
    leave_block = user.split("async def leave_waitlist", 1)[1].split('@router.callback_query(F.data.startswith("event:waitlist:"))', 1)[0]
    assert 'entry.status = "closed"' in leave_block
    assert "next_invite_after = None" in leave_block
    start = user.split("async def start", 1)[1].split('@router.message(Command("help"))', 1)[0]
    assert "prior_state == BookingStates.waiting_receipt.state" in start
    assert "دستور /start رزرو را لغو نمی‌کند" not in start
    assert "_show_receipt_cancel_confirmation(message, state, booking_id)" in start
    assert "یک فرایند ناتمام دارید" not in start
    assert "periodic_waitlist_maintenance(bot)" in main
    assert "waitlist_task.cancel()" in main


def test_invitation_migration_adds_both_retry_fields_idempotently():
    migration = (ROOT / "migrations/016_waitlist_invitation_expiry.sql").read_text(encoding="utf-8")
    assert "ADD COLUMN IF NOT EXISTS invitation_expires_at TIMESTAMP NULL" in migration
    assert "ADD COLUMN IF NOT EXISTS next_invite_after TIMESTAMP NULL" in migration
    assert "UPDATE waitlist_entries" in migration
    assert "COALESCE(created_at, CURRENT_TIMESTAMP) + INTERVAL '24 hours'" in migration
    assert "ix_waitlist_entries_invitation_expires_at" in migration
    assert "ix_waitlist_entries_next_invite_after" in migration


def test_existing_active_invitation_prevents_spam_for_same_free_seat(monkeypatch):
    """A free seat can have one outstanding invitation, not a new invite each sweep."""
    engine, session, event, users = build_db(capacity=1)
    # Keep the invitation valid regardless of the date on which the test suite runs.
    now = utc_now_naive()
    try:
        active = WaitlistEntry(
            event_id=event.id, user_id=users[0].id, requested_participant_count=1,
            position=1, status="invited", invitation_expires_at=now + WAITLIST_INVITATION_TTL,
        )
        waiting = WaitlistEntry(
            event_id=event.id, user_id=users[1].id, requested_participant_count=1,
            position=2, status="waiting",
        )
        session.add_all([active, waiting])
        session.commit()
        factory = Factory(engine)
        import app.db.session as db_session
        monkeypatch.setattr(db_session, "SessionLocal", factory)
        _stub_aiogram_markup_types(monkeypatch)
        from app.services.waitlist import notify_waitlist_capacity_available
        bot = SimpleNamespace(
            get_me=AsyncMock(return_value=SimpleNamespace(username="PanelFlowTestBot")),
            send_message=AsyncMock(),
        )
        sent = asyncio.run(notify_waitlist_capacity_available(bot, event.id))
        assert sent == 0
        bot.send_message.assert_not_awaited()
        with pytest.raises(ValueError, match="INVITATIONS_ALREADY_SENT"):
            asyncio.run(next_waitlist_candidate(FakeAsyncSession(session), event.id, now=now))
        session.expire_all()
        assert session.get(WaitlistEntry, waiting.id).status == "waiting"
        assert session.get(WaitlistEntry, active.id).status == "invited"
    finally:
        session.close()
        engine.dispose()


def test_outstanding_group_invitation_reduces_only_invitation_budget_not_real_capacity():
    engine, session, event, users = build_db(capacity=3)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        active_group = WaitlistEntry(
            event_id=event.id, user_id=users[0].id, requested_participant_count=2,
            position=1, status="invited", invitation_expires_at=now + WAITLIST_INVITATION_TTL,
        )
        waiting_group = WaitlistEntry(
            event_id=event.id, user_id=users[1].id, requested_participant_count=2,
            position=2, status="waiting",
        )
        waiting_single = WaitlistEntry(
            event_id=event.id, user_id=users[2].id, requested_participant_count=1,
            position=3, status="waiting",
        )
        session.add_all([active_group, waiting_group, waiting_single])
        session.commit()
        selected_event, candidate, _user, actual_free_seats = asyncio.run(
            next_waitlist_candidate(FakeAsyncSession(session), event.id, now=now)
        )
        assert selected_event.id == event.id
        assert candidate.id == waiting_single.id
        # There are still three actual free seats; only one is left in the
        # notification budget after the two-person invitation already sent.
        assert actual_free_seats == 3
    finally:
        session.close()
        engine.dispose()


def test_active_invitation_for_group_too_large_for_current_capacity_does_not_block_single_waiter():
    engine, session, event, users = build_db(capacity=1)
    now = datetime(2026, 10, 12, 12, 0)
    try:
        oversized_invite = WaitlistEntry(
            event_id=event.id, user_id=users[0].id, requested_participant_count=3,
            position=1, status="invited", invitation_expires_at=now + WAITLIST_INVITATION_TTL,
        )
        eligible_waiter = WaitlistEntry(
            event_id=event.id, user_id=users[1].id, requested_participant_count=1,
            position=2, status="waiting",
        )
        session.add_all([oversized_invite, eligible_waiter])
        session.commit()
        _event, candidate, user, free = asyncio.run(
            next_waitlist_candidate(FakeAsyncSession(session), event.id, now=now)
        )
        assert candidate.id == eligible_waiter.id
        assert user.telegram_id == 35102
        assert free == 1
    finally:
        session.close()
        engine.dispose()
