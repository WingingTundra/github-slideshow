from types import SimpleNamespace

from app.services.seat_disclosure import (
    seat_disclosure_threshold,
    should_disclose_remaining_seats,
    should_show_capacity_filling_message,
    public_catalogue_availability_label,
)
from app.db.models import EventStatus
from app.services.channel_status import _status_text


def test_15_seat_panel_discloses_only_at_five_or_fewer_remaining():
    assert seat_disclosure_threshold(15) == 5
    assert not should_disclose_remaining_seats(15, 15)  # empty panel is not labelled "only 15 left"
    assert not should_disclose_remaining_seats(15, 6)
    assert should_disclose_remaining_seats(15, 5)
    assert should_disclose_remaining_seats(15, 1)
    assert not should_disclose_remaining_seats(15, 0)  # full is handled separately


def test_small_capacity_panels_use_a_lower_threshold_without_empty_panel_scarcity():
    assert seat_disclosure_threshold(8) == 2
    assert not should_disclose_remaining_seats(8, 3)
    assert should_disclose_remaining_seats(8, 2)
    assert seat_disclosure_threshold(4) == 1
    assert should_disclose_remaining_seats(4, 1)
    assert seat_disclosure_threshold(2) == 1
    assert should_disclose_remaining_seats(2, 1)
    assert seat_disclosure_threshold(1) == 0
    assert not should_disclose_remaining_seats(1, 1)


def test_capacity_filling_message_starts_at_half_occupancy_and_precedes_exact_count():
    # 15 seats: half-full starts with non-numeric copy; five seats left reveals count.
    assert not should_show_capacity_filling_message(15, 7, 8)
    assert should_show_capacity_filling_message(15, 8, 7)
    assert should_show_capacity_filling_message(15, 9, 6)
    assert not should_show_capacity_filling_message(15, 10, 5)

    # The transition adapts to different panel sizes; large panels still require
    # a genuinely low absolute number before displaying exact remaining seats.
    assert should_show_capacity_filling_message(8, 4, 4)
    assert not should_show_capacity_filling_message(8, 6, 2)
    assert should_show_capacity_filling_message(50, 25, 25)
    assert not should_show_capacity_filling_message(50, 45, 5)


def test_invalid_or_nonpositive_capacity_never_discloses_remaining_seats():
    for capacity in (None, 0, -1, "invalid"):
        assert not should_disclose_remaining_seats(capacity, 1)
    assert not should_disclose_remaining_seats(15, None)


def test_public_channel_status_hides_early_counts_but_discloses_low_availability():
    event = SimpleNamespace(
        archived=False,
        status=EventStatus.PUBLISHED,
        registration_open=True,
        registration_closed_reason=None,
        capacity=15,
    )
    early = _status_text(event, 15)
    assert "ظرفیت کل: ۱۵ نفر" in early
    assert "صندلی باقی مانده" not in early
    low = _status_text(event, 5)
    assert "فقط ۵ صندلی باقی مانده" in low


def test_public_channel_status_never_shows_remaining_when_registration_is_closed():
    event = SimpleNamespace(
        archived=False,
        status=EventStatus.PUBLISHED,
        registration_open=False,
        registration_closed_reason="manual",
        capacity=15,
    )
    text = _status_text(event, 2)
    assert "ثبت‌نام این پنل بسته شد" in text
    assert "۲ صندلی باقی مانده" not in text


def test_capacity_increase_notification_does_not_reveal_early_remaining_count():
    event = SimpleNamespace(
        archived=False,
        status=EventStatus.PUBLISHED,
        registration_open=True,
        registration_closed_reason=None,
        capacity=15,
    )
    text = _status_text(event, 10, capacity_increase_by=5)
    assert "ظرفیت کل اکنون ۱۵ نفر است" in text
    assert "۱۰ صندلی باقی مانده" not in text


def test_full_and_cancelled_channel_statuses_preserve_existing_semantics():
    event = SimpleNamespace(
        archived=False,
        status=EventStatus.PUBLISHED,
        registration_open=False,
        registration_closed_reason="capacity",
        capacity=15,
    )
    assert "ظرفیت این پنل تکمیل شد" in _status_text(event, 0)
    event.status = EventStatus.CANCELLED
    assert "لغو شد" in _status_text(event, 0)


def test_public_catalogue_labels_only_show_remaining_seats_at_low_availability():
    render = public_catalogue_availability_label
    assert render(15, 15, registration_open=True, waitlist_available=False) == "ظرفیت کل: ۱۵ نفر"
    assert render(15, 8, registration_open=True, waitlist_available=False) == "ظرفیت کل: ۱۵ نفر"
    assert render(15, 7, registration_open=True, waitlist_available=False) == "ظرفیت پنل در حال تکمیل است."
    assert render(15, 6, registration_open=True, waitlist_available=False) == "ظرفیت پنل در حال تکمیل است."
    assert render(15, 5, registration_open=True, waitlist_available=False) == "فقط ۵ جای خالی باقی مانده است"
    assert render(15, 1, registration_open=True, waitlist_available=False) == "فقط ۱ جای خالی باقی مانده است"
    assert render(50, 25, registration_open=True, waitlist_available=False) == "ظرفیت پنل در حال تکمیل است."
    assert render(50, 5, registration_open=True, waitlist_available=False) == "فقط ۵ جای خالی باقی مانده است"
    assert render(15, 2, registration_open=False, waitlist_available=False) == "ثبت‌نام بسته است · ظرفیت کل: ۱۵ نفر"
    assert render(15, 0, registration_open=False, waitlist_available=True) == "ظرفیت تکمیل شده است · فهرست انتظار فعال است"
    assert render(15, 0, registration_open=False, waitlist_available=False) == "ظرفیت تکمیل شده است"


def test_public_detail_renderer_does_not_show_signup_counts():
    import ast
    from html import escape
    from types import SimpleNamespace

    from app.bot.text_limits import DEFAULT_SAFE_TEXT_LIMIT, limit_telegram_html, telegram_html_visible_units
    from app.display_utils import has_end_time_label, volume_label, panel_detail_line, rtl_isolate
    from app.services.pricing import panel_price_label

    source = (__import__("pathlib").Path(__file__).resolve().parents[1] / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "event_text")
    isolated = ast.Module(body=[function], type_ignores=[])
    namespace = {
        "Event": object,
        "escape": escape,
        "_ltr_display": lambda value: f"\u2066{escape(str(value))}\u2069",
        "has_end_time_label": has_end_time_label,
        "volume_label": volume_label,
        "panel_detail_line": panel_detail_line,
        "rtl_isolate": rtl_isolate,
        "registration_is_open": lambda event: True,
        "limit_telegram_html": limit_telegram_html,
        "telegram_html_visible_units": telegram_html_visible_units,
        "DEFAULT_SAFE_TEXT_LIMIT": DEFAULT_SAFE_TEXT_LIMIT,
        "panel_price_label": panel_price_label,
        "should_disclose_remaining_seats": should_disclose_remaining_seats,
        "should_show_capacity_filling_message": should_show_capacity_filling_message,
        "_fa_digits": lambda value: str(value).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")),
    }
    exec(compile(ast.fix_missing_locations(isolated), "app/bot/handlers/user.py", "exec"), namespace)
    event = SimpleNamespace(
        volume=1, title="Example", description="", language="English",
        event_day_label="Saturday", event_date_label="1 November", start_time_label="10:00",
        end_time_label="11:00", venue="Venue", capacity=15, price_per_person=0,
        price_without_cafe_order=None, host_name="Host", address="Venue",
    )
    render = namespace["event_text"]
    clean = lambda value: value.translate({ord(ch): None for ch in "\u2066\u2067\u2068\u2069"})
    empty = clean(render(event, 0))
    assert "ظرفیت: ۱۵ نفر" in empty
    assert "۰ / ۱۵" not in empty and "15 / 15" not in empty
    assert "صندلی باقی مانده" not in empty
    half_full = clean(render(event, 8))
    assert "ظرفیت: ۱۵ نفر" in half_full
    assert "ظرفیت پنل در حال تکمیل است." in half_full
    assert half_full.splitlines()[-1] == "ظرفیت پنل در حال تکمیل است."
    assert "فقط ۷ صندلی باقی مانده است" not in half_full
    near_full = clean(render(event, 10))
    assert "ظرفیت: ۱۵ نفر" in near_full
    assert "فقط ۵ جای خالی باقی مانده است" in near_full
    assert "ظرفیت پنل در حال تکمیل است." not in near_full
    assert "۱۰ / ۱۵" not in near_full
    full = clean(render(event, 15))
    assert "ظرفیت پنل تکمیل شده است" in full
    assert "صندلی باقی مانده" not in full
