import zipfile
from datetime import datetime
from decimal import Decimal
from io import BytesIO
from types import SimpleNamespace
import xml.etree.ElementTree as ET

from app.db.models import AttendanceStatus, PaymentStatus, RegistrationStatus
from app.services.excel_export import build_attendee_workbook


NS = {
    "main": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "rel": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "pkgrel": "http://schemas.openxmlformats.org/package/2006/relationships",
}


def _read_shared_strings(book_zip):
    root = ET.fromstring(book_zip.read("xl/sharedStrings.xml"))
    result = []
    for item in root.findall("main:si", NS):
        result.append("".join(node.text or "" for node in item.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
    return result


def _cell_text(book_zip, sheet_path, address, shared_strings):
    root = ET.fromstring(book_zip.read(sheet_path))
    cell = root.find(f".//main:c[@r='{address}']", NS)
    if cell is None:
        return None
    value = cell.find("main:v", NS)
    if cell.attrib.get("t") == "s" and value is not None:
        return shared_strings[int(value.text)]
    inline = cell.find("main:is", NS)
    if inline is not None:
        return "".join(node.text or "" for node in inline.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"))
    return value.text if value is not None else None


def _event():
    return SimpleNamespace(
        id=19,
        volume=19,
        title="Test Panel",
        language="Français",
        event_day_label="Friday",
        event_date_label="9 October 2026",
        start_time_label="18:00",
        end_time_label="20:00",
        venue="Test Venue",
        address="Test Address",
        capacity=12,
        price_per_person=Decimal("250000"),
        host_name="Host Name",
    )


def _user(user_id, name, username, phone=None):
    return SimpleNamespace(
        telegram_id=user_id,
        display_name=name,
        first_name=name.split()[0],
        last_name=" ".join(name.split()[1:]),
        telegram_username=username,
        phone_number=phone,
    )


def _participant(name, attendance=AttendanceStatus.UNMARKED, phone=None):
    return SimpleNamespace(full_name=name, attendance_status=attendance, phone_number=phone)


def _booking(booking_id, status, user, people, contact_phone, payment_status, created_at):
    return SimpleNamespace(
        id=booking_id,
        participant_count=len(people),
        total_amount=Decimal("250000") * len(people),
        status=status,
        booked_by=user,
        participants=people,
        contact_phone=contact_phone,
        payment=SimpleNamespace(status=payment_status) if payment_status else None,
        created_at=created_at,
    )


def test_export_handles_multiple_group_signups_history_and_waitlist():
    booker_one = _user(12345, "Sina Example", "sina_example", "+989151117889")
    booker_two = _user(22345, "Mina Example", "mina_example", "+989121234567")
    old_booker = _user(32345, "Old Example", "old_example")
    bookings = [
        _booking(
            7,
            RegistrationStatus.CONFIRMED,
            booker_one,
            [
                _participant("Ali Ahmadi", AttendanceStatus.ATTENDED),
                _participant("Sara Karimi", AttendanceStatus.UNMARKED),
                _participant("Reza Karimi", AttendanceStatus.UNMARKED),
            ],
            "+989151117889",
            PaymentStatus.APPROVED,
            datetime(2026, 10, 9, 9, 0),
        ),
        _booking(
            8,
            RegistrationStatus.PENDING_VERIFICATION,
            booker_two,
            [_participant("Nima Ahmadi"), _participant("Maryam Ahmadi")],
            "+989121234567",
            PaymentStatus.PENDING,
            datetime(2026, 10, 9, 10, 0),
        ),
        _booking(
            9,
            RegistrationStatus.CANCELLED,
            old_booker,
            [_participant("Old Cancelled Attendee")],
            None,
            PaymentStatus.REJECTED,
            datetime(2026, 10, 9, 11, 0),
        ),
    ]
    waitlist = [
        (SimpleNamespace(position=1, requested_participant_count=2, status="waiting", created_at=datetime(2026, 10, 9, 12, 0)), _user(42345, "Wait List One", "waitlist_one")),
        (SimpleNamespace(position=2, requested_participant_count=1, status="invited", created_at=datetime(2026, 10, 9, 13, 0)), _user(52345, "Wait List Two", None)),
    ]

    payload = build_attendee_workbook(_event(), bookings, waitlist)
    assert payload[:2] == b"PK"

    with zipfile.ZipFile(BytesIO(payload)) as book_zip:
        names = set(book_zip.namelist())
        assert {"xl/worksheets/sheet1.xml", "xl/worksheets/sheet2.xml", "xl/worksheets/sheet3.xml", "xl/worksheets/sheet4.xml", "xl/worksheets/sheet5.xml"}.issubset(names)
        workbook_xml = ET.fromstring(book_zip.read("xl/workbook.xml"))
        sheet_names = [sheet.attrib["name"] for sheet in workbook_xml.findall("main:sheets/main:sheet", NS)]
        assert sheet_names == ["Summary", "Participants", "Confirmed Only", "Booking History", "Waitlist"]
        shared = _read_shared_strings(book_zip)
        assert _cell_text(book_zip, "xl/worksheets/sheet1.xml", "A9", shared) == "زبان پنل"
        assert _cell_text(book_zip, "xl/worksheets/sheet1.xml", "B9", shared) == "Français"

        # The primary roster lists every recorded signup, including cancelled rows.
        # Confirmed Only remains restricted to bookings in the confirmed state.
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "C6", shared) == "Ali Ahmadi"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "C7", shared) == "Sara Karimi"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "C8", shared) == "Reza Karimi"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "C9", shared) == "Nima Ahmadi"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "C10", shared) == "Maryam Ahmadi"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "D6", shared) == "+989151117889"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "D7", shared) == "+989151117889"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "D9", shared) == "+989121234567"
        assert _cell_text(book_zip, "xl/worksheets/sheet3.xml", "C6", shared) == "Ali Ahmadi"
        assert _cell_text(book_zip, "xl/worksheets/sheet3.xml", "C7", shared) == "Sara Karimi"
        assert _cell_text(book_zip, "xl/worksheets/sheet3.xml", "C8", shared) == "Reza Karimi"
        # Pending verification attendees are excluded from the confirmed-only sheet.
        assert _cell_text(book_zip, "xl/worksheets/sheet3.xml", "C9", shared) != "Nima Ahmadi"
        assert _cell_text(book_zip, "xl/worksheets/sheet4.xml", "B7", shared) == "Old Cancelled Attendee"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "C11", shared) == "Old Cancelled Attendee"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "D11", shared) == "—"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "F11", shared) == "cancelled"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "G11", shared) == "rejected"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "I11", shared) == "Old Example"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "J11", shared) == "@old_example"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "K11", shared) == "32345"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "M6", shared) == "250000"
        assert _cell_text(book_zip, "xl/worksheets/sheet2.xml", "N6", shared) == "750000"
        assert _cell_text(book_zip, "xl/worksheets/sheet3.xml", "M6", shared) == "250000"
        assert _cell_text(book_zip, "xl/worksheets/sheet3.xml", "N6", shared) == "750000"
        assert _cell_text(book_zip, "xl/worksheets/sheet5.xml", "B5", shared) == "Wait List One"
        assert _cell_text(book_zip, "xl/worksheets/sheet5.xml", "E5", shared) == "2"
        assert _cell_text(book_zip, "xl/worksheets/sheet5.xml", "F6", shared) == "دعوت‌شده؛ در انتظار ثبت‌نام"
        assert any(path.startswith("xl/tables/table") for path in names)
        assert not any(path.startswith("xl/media/") for path in names), "Export should not fetch/embed Telegram profile photos"

        participants_xml = ET.fromstring(book_zip.read("xl/worksheets/sheet2.xml"))
        hyperlinks = participants_xml.find("main:hyperlinks", NS)
        assert hyperlinks is not None and len(list(hyperlinks)) >= 1


def test_export_handles_no_bookings_and_no_waitlist_without_fake_attendee_rows():
    payload = build_attendee_workbook(_event(), [], [])
    with zipfile.ZipFile(BytesIO(payload)) as book_zip:
        workbook_xml = ET.fromstring(book_zip.read("xl/workbook.xml"))
        sheet_names = [sheet.attrib["name"] for sheet in workbook_xml.findall("main:sheets/main:sheet", NS)]
        assert sheet_names == ["Summary", "Participants", "Confirmed Only", "Booking History", "Waitlist"]
        shared = _read_shared_strings(book_zip)
        assert "هنوز ثبت‌نامی برای این پنل وجود ندارد." in shared
        assert "هنوز رزروی ثبت نشده است." in shared
        assert "در حال حاضر درخواست فعالی در لیست انتظار نیست." in shared
        table_paths = [path for path in book_zip.namelist() if path.startswith("xl/tables/table")]
        assert table_paths == []


def test_export_scales_to_many_multi_person_bookings_without_truncating_rows():
    event = _event()
    bookings = []
    for booking_id in range(1, 121):
        booker = _user(100000 + booking_id, f"Booker {booking_id}", f"booker_{booking_id}")
        people = [
            _participant(f"Attendee {booking_id}-{person_no}")
            for person_no in range(1, 4)
        ]
        bookings.append(
            _booking(
                booking_id,
                RegistrationStatus.CONFIRMED,
                booker,
                people,
                f"+9891511{booking_id:05d}",
                PaymentStatus.APPROVED,
                datetime(2026, 10, 9, 9, 0),
            )
        )

    payload = build_attendee_workbook(event, bookings)
    with zipfile.ZipFile(BytesIO(payload)) as book_zip:
        shared = _read_shared_strings(book_zip)
        assert "Attendee 1-1" in shared
        assert "Attendee 120-3" in shared
        table_paths = [p for p in book_zip.namelist() if p.startswith("xl/tables/table")]
        participant_table = None
        for path in table_paths:
            root = ET.fromstring(book_zip.read(path))
            if root.attrib.get("name") == "PanelFlowParticipants":
                participant_table = root
                break
        assert participant_table is not None
        # Header row plus all 360 individual attendees: no group booking was collapsed
        # and no roster rows were truncated to fit a Telegram message.
        assert participant_table.attrib["ref"] == "A5:N365"
        confirmed_table = None
        for path in table_paths:
            root = ET.fromstring(book_zip.read(path))
            if root.attrib.get("name") == "PanelFlowConfirmedAttendees":
                confirmed_table = root
                break
        assert confirmed_table is not None
        assert confirmed_table.attrib["ref"] == "A5:N365"


def test_export_shows_per_person_share_for_public_and_single_person_discounts():
    public_booker = _user(62345, "Public Booker", "public_booker", "+989151234567")
    restricted_booker = _user(72345, "Restricted Booker", "restricted_booker", "+989151234568")
    public_booking = _booking(71, RegistrationStatus.CONFIRMED, public_booker, [
        _participant("Public Booker"), _participant("Public Friend"), _participant("Public Guest")
    ], "+989151234567", PaymentStatus.APPROVED, datetime(2026, 10, 9, 9, 0))
    public_booking.total_amount = Decimal("240000")
    public_booking.discount_amount = Decimal("60000")
    public_booking.discount_code_kind_snapshot = "public"
    restricted_booking = _booking(72, RegistrationStatus.CONFIRMED, restricted_booker, [
        _participant("Restricted Booker"), _participant("Restricted Friend"), _participant("Restricted Guest")
    ], "+989151234568", PaymentStatus.APPROVED, datetime(2026, 10, 9, 10, 0))
    restricted_booking.total_amount = Decimal("250000")
    restricted_booking.discount_amount = Decimal("50000")
    restricted_booking.discount_code_kind_snapshot = "restricted"
    free_booking = _booking(73, RegistrationStatus.CONFIRMED, _user(82345, "Winner User", "winner_user"), [
        _participant("Winner User")
    ], None, None, datetime(2026, 10, 9, 11, 0))
    free_booking.total_amount = Decimal("0")
    free_booking.discount_amount = Decimal("250000")
    free_booking.discount_code_kind_snapshot = "personal"
    fixed_public_booking = _booking(74, RegistrationStatus.CONFIRMED, _user(92345, "Fixed Booker", "fixed_booker"), [
        _participant("Fixed Booker"), _participant("Fixed Friend"), _participant("Fixed Guest")
    ], None, PaymentStatus.APPROVED, datetime(2026, 10, 9, 12, 0))
    fixed_public_booking.total_amount = Decimal("700000")
    fixed_public_booking.discount_amount = Decimal("50000")
    fixed_public_booking.discount_code_kind_snapshot = "public"

    payload = build_attendee_workbook(
        _event(), [public_booking, restricted_booking, free_booking, fixed_public_booking]
    )
    with zipfile.ZipFile(BytesIO(payload)) as book_zip:
        shared = _read_shared_strings(book_zip)
        participants_sheet = "xl/worksheets/sheet2.xml"
        # Public 20% discount is apportioned to the whole reservation: 80,000 each.
        assert _cell_text(book_zip, participants_sheet, "M6", shared) == "80000"
        assert _cell_text(book_zip, participants_sheet, "M7", shared) == "80000"
        assert _cell_text(book_zip, participants_sheet, "M8", shared) == "80000"
        assert _cell_text(book_zip, participants_sheet, "N6", shared) == "240000"
        # Restricted discounts and personal rewards belong to participant 1 (the booker).
        assert _cell_text(book_zip, participants_sheet, "M9", shared) == "50000"
        assert _cell_text(book_zip, participants_sheet, "M10", shared) == "100000"
        assert _cell_text(book_zip, participants_sheet, "M11", shared) == "100000"
        assert _cell_text(book_zip, participants_sheet, "N9", shared) == "250000"
        assert _cell_text(book_zip, participants_sheet, "M12", shared) == "0"
        assert _cell_text(book_zip, participants_sheet, "N12", shared) == "0"
        # Fixed total discounts preserve the exact booking sum despite integer-toman rounding.
        fixed_shares = [
            int(_cell_text(book_zip, participants_sheet, address, shared))
            for address in ("M13", "M14", "M15")
        ]
        assert fixed_shares == [233334, 233333, 233333]
        assert sum(fixed_shares) == 700000
        assert _cell_text(book_zip, participants_sheet, "N13", shared) == "700000"
