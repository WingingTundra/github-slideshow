"""V46 regressions for community navigation, link-copy UX, and challenge review."""
from __future__ import annotations

import ast
import asyncio
from pathlib import Path
from types import SimpleNamespace

from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session

from app.bot.content import user_help_text
from app.db.models import (
    AchievementUnlock, Base, ChallengeSubmission, CommunityChallenge,
    CommunityProfile, User, UserRole, XPAward,
)
from app.services.community import total_xp

ROOT = Path(__file__).resolve().parents[1]


def _buttons(markup):
    return [button for row in markup.inline_keyboard for button in row]


def test_community_user_navigation_has_four_destinations_and_wrapped_stays_in_passport():
    import pytest
    pytest.importorskip("aiogram")
    from app.bot.keyboards import community_menu_keyboard
    markup = community_menu_keyboard()
    buttons = _buttons(markup)
    assert [button.callback_data for button in buttons] == [
        "community:leaderboard", "community:challenges", "community:passport", "user:home"
    ]
    assert all(len(row) == 1 for row in markup.inline_keyboard)
    assert all(button.callback_data != "community:wrapped" for button in buttons)
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    passport = source.split('async def community_passport', 1)[1].split('async def _render_user_challenges', 1)[0]
    assert 'callback_data="community:wrapped"' in passport
    assert 'callback_data="community:challenges"' not in passport



def test_user_challenges_and_challenge_details_do_not_repeat_passport_navigation():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    challenge_list = source.split("async def _render_user_challenges", 1)[1].split(
        '@router.callback_query(F.data == "community:challenges")', 1
    )[0]
    challenge_detail = source.split("async def challenge_view_callback", 1)[1].split(
        '@router.callback_query(F.data.startswith("community:challenge:submit:"))', 1
    )[0]
    assert 'callback_data="community:passport"' not in challenge_list
    assert 'callback_data="community:passport"' not in challenge_detail
    # Passport remains a top-level destination in the Community & Challenges menu.
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    community_menu = keyboards.split("def community_menu_keyboard", 1)[1].split("def admin_community_menu", 1)[0]
    assert 'callback_data="community:passport"' in community_menu

def test_admin_main_menu_groups_channel_updates_with_announcements_and_access_with_settings():
    import pytest
    pytest.importorskip("aiogram")
    from app.bot.keyboards import admin_menu
    markup = admin_menu()
    rows = [
        {getattr(button, "callback_data", None) for button in row}
        for row in markup.inline_keyboard
    ]
    assert any({"admin:announcements", "admin:channel_updates"} <= row for row in rows)
    assert any({"admin:settings", "admin:users:manage"} <= row for row in rows)
    assert not any({"admin:channel_updates", "admin:users:manage"} <= row for row in rows)


def test_community_admin_menu_adds_review_queue_and_create_is_not_repeated_in_challenge_list():
    import pytest
    pytest.importorskip("aiogram")
    from app.bot.keyboards import admin_community_menu
    markup = admin_community_menu(True)
    callbacks = {button.callback_data for button in _buttons(markup)}
    assert "admin:community:challenge:create" in callbacks
    assert "admin:community:submissions:list:0" in callbacks
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    selector = source.split('async def _render_admin_challenges', 1)[1].split(
        '@router.callback_query(F.data == "admin:community:challenges")', 1
    )[0]
    assert 'callback_data="admin:community:challenge:create"' not in selector


def test_help_is_text_only_and_uses_participated_panels_language():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    handler = next(node for node in tree.body if isinstance(node, ast.AsyncFunctionDef) and node.name == "help_command")
    body = ast.get_source_segment(source, handler)
    assert "reply_markup" not in body
    help_text = user_help_text().lower()
    assert "پنل‌های پیش‌رو" in help_text
    assert "ثبت‌نام‌های من" in help_text
    assert "پیگیری وضعیت رزروها و پرداخت‌ها" in help_text
    assert "بعضی وضعیت‌ها تا بررسی مدیر نهایی نمی‌شوند" not in help_text
    assert "پشتیبانی انسانی" in help_text
    community = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8").lower()
    assert "distinct paid panels" not in community
    assert "paid panels" not in community
    community_service = (ROOT / "app/services/community.py").read_text(encoding="utf-8")
    assert "تعداد پنل‌های شرکت‌شده" in community_service
    assert "Submit Answer" not in community.split("# --------------------------- Administrator community tools", 1)[0]
    leaderboard = community.split('async def community_leaderboard', 1)[1].split(
        '@router.callback_query(F.data == "community:leaderboard:privacy")', 1
    )[0]
    disabled_branch = leaderboard.split('if not await leaderboard_enabled(session):', 1)[1].split(
        'rows = await leaderboard_rows', 1
    )[0]
    assert 'callback_data="community:home"' in disabled_branch
    assert '_back_to_community()' not in disabled_branch


def test_panel_links_are_native_copy_actions_and_registration_copy_is_gated_by_lifecycle():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    render_event = admin.split("async def render_event", 1)[1].split('@router.message(Command("admin"))', 1)[0]
    links = admin.split('async def admin_event_registration_links', 1)[1].split(
        '@router.callback_query(F.data.startswith("admin:"))', 1
    )[0]
    # Manage Panel must not inject extra copy-link buttons; the dedicated link
    # action remains responsible for showing/copying links.
    assert 'copy_text=CopyTextButton(text=details_url)' not in render_event
    assert 'copy_text=CopyTextButton(text=register_url)' not in render_event
    assert 'get_me()' not in render_event
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    event_menu = keyboard.split("def admin_event_menu(", 1)[1].split("def final_panel_state_keyboard", 1)[0]
    assert 'InlineKeyboardButton(text="🔗 لینک ثبت‌نام پنل", callback_data=f"admin:event:links:{event_id}")' in event_menu
    assert 'InlineKeyboardButton(text="📡 اتصال پست کانال", callback_data=f"admin:event:linkpost:{event_id}")' in event_menu
    assert 'InlineKeyboardButton(text="👥 اتصال پست گروه", callback_data=f"admin:event:linkgroup:{event_id}")' in event_menu
    assert 'registration_ready and used < int(event.capacity or 0)' not in render_event
    assert 'if open_for_registration and not is_full:' in links
    assert 'InlineKeyboardButton(text="کپی لینک جزئیات", copy_text=CopyTextButton(text=details_url))' in links
    assert 'InlineKeyboardButton(text="کپی لینک ثبت‌نام", copy_text=CopyTextButton(text=register_url))' in links
    assert 'InlineKeyboardButton(text="🔎 مشاهده جزئیات پنل", url=details_url)' not in links
    assert 'InlineKeyboardButton(text="🎟 شروع ثبت‌نام", url=register_url)' not in links


def test_challenge_links_copy_directly_and_review_controls_are_explicit():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    assert 'copy_text=CopyTextButton(text=url)' in source
    assert 'callback_data=f"admin:community:challenge:publish:preview:{cid}:{page}"' in source
    assert 'callback_data=f"admin:community:challenge:publish:confirm:{cid}:{page}"' in source
    assert 'callback_data=f"admin:community:challenge:finish:{cid}:{page}"' in source
    assert 'callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:incorrect"' in source
    assert 'callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:next"' in source
    assert 'sub.judging_status = "incorrect"' in source
    assert 'Selection order defines placement: first selected is first place, then second, then third.' in source
    assert 'Close any gap left by removing a provisional winner, retaining selection order.' in source
    assert 'در هر صفحه سه پاسخ نمایش داده می‌شود.' in source
    submitter = source.split('async def challenge_submit_answer', 1)[1].split(
        '@router.callback_query(F.data == "community:wrapped")', 1
    )[0]
    assert 'session.get(CommunityChallenge, challenge_id, with_for_update=True)' in submitter
    # The preview stage only reads and summarizes selected placements; awards happen in finalization.
    preview = source.split('async def admin_preview_challenge_results', 1)[1].split(
        'async def _finalize_challenge_review', 1
    )[0]
    assert "award_once" not in preview
    assert 'callback_data=f"admin:community:submissions:{cid}:{page}"' in preview


class _AsyncNested:
    def __init__(self, ctx):
        self.ctx = ctx

    async def __aenter__(self):
        return self.ctx.__enter__()

    async def __aexit__(self, exc_type, exc, tb):
        return self.ctx.__exit__(exc_type, exc, tb)


class _SessionAdapter:
    def __init__(self, raw):
        self.raw = raw

    async def execute(self, *args, **kwargs):
        return self.raw.execute(*args, **kwargs)

    async def scalar(self, *args, **kwargs):
        return self.raw.scalar(*args, **kwargs)

    async def get(self, *args, **kwargs):
        return self.raw.get(*args, **kwargs)

    async def flush(self):
        self.raw.flush()

    async def commit(self):
        self.raw.commit()

    async def rollback(self):
        self.raw.rollback()

    def add(self, row):
        self.raw.add(row)

    def begin_nested(self):
        return _AsyncNested(self.raw.begin_nested())


class _SessionContext:
    def __init__(self, engine):
        self.engine = engine
        self.raw = None

    async def __aenter__(self):
        self.raw = Session(self.engine)
        return _SessionAdapter(self.raw)

    async def __aexit__(self, exc_type, exc, tb):
        if self.raw is not None:
            self.raw.close()


class _SessionFactory:
    def __init__(self, engine):
        self.engine = engine

    def __call__(self):
        return _SessionContext(self.engine)


class _FakeBot:
    async def get_me(self):
        return SimpleNamespace(username="panel_flow_test_bot")

    async def send_message(self, *args, **kwargs):
        return None


class _FakeMessage:
    def __init__(self):
        self.text = None
        self.reply_markup = None

    async def edit_text(self, text, **kwargs):
        self.text = text
        self.reply_markup = kwargs.get("reply_markup")


class _FakeCallback:
    def __init__(self, data="", admin_id=999999):
        self.data = data
        self.from_user = SimpleNamespace(id=admin_id)
        self.bot = _FakeBot()
        self.message = _FakeMessage()
        self.answers = []

    async def answer(self, text=None, **kwargs):
        self.answers.append((text, kwargs))


def test_knowledge_finish_review_sets_unmarked_to_incorrect_and_awards_correct_xp_once(monkeypatch):
    import pytest
    pytest.importorskip("aiogram")
    import app.bot.handlers.community as handlers

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    try:
        with Session(engine) as raw:
            admin = User(telegram_id=999999, first_name="Admin", last_name="User", role=UserRole.SUPER_ADMIN)
            correct_user = User(telegram_id=991001, first_name="Correct", last_name="Member", role=UserRole.PARTICIPANT)
            unmarked_user = User(telegram_id=991002, first_name="Unmarked", last_name="Member", role=UserRole.PARTICIPANT)
            raw.add_all([admin, correct_user, unmarked_user])
            raw.flush()
            challenge = CommunityChallenge(
                title="Knowledge", prompt="Question?", challenge_type="knowledge", reference_answer="private",
                winner_count=1, status="closed", created_by_telegram_id=admin.telegram_id,
            )
            raw.add(challenge)
            raw.flush()
            correct_sub = ChallengeSubmission(challenge_id=challenge.id, telegram_id=correct_user.telegram_id,
                                              answer_text="answer A", judging_status="correct")
            unmarked_sub = ChallengeSubmission(challenge_id=challenge.id, telegram_id=unmarked_user.telegram_id,
                                               answer_text="answer B", judging_status="unmarked")
            raw.add_all([correct_sub, unmarked_sub])
            for user in (correct_user, unmarked_user):
                raw.add(CommunityProfile(telegram_id=user.telegram_id))
                raw.add(XPAward(telegram_id=user.telegram_id, points=2, award_type="challenge_participation",
                                award_key=f"challenge-participation:{challenge.id}:{user.telegram_id}", challenge_id=challenge.id))
            raw.commit()
            cid = challenge.id
            correct_sid, unmarked_sid = correct_sub.id, unmarked_sub.id

        monkeypatch.setattr(handlers, "SessionLocal", _SessionFactory(engine))
        monkeypatch.setattr(handlers, "_is_admin", lambda telegram_id: telegram_id == 999999)
        callback = _FakeCallback(data=f"admin:community:challenge:finish:{cid}:0")
        asyncio.run(handlers.admin_finish_knowledge_review(callback))

        with Session(engine) as raw:
            challenge = raw.get(CommunityChallenge, cid)
            correct_sub = raw.get(ChallengeSubmission, correct_sid)
            unmarked_sub = raw.get(ChallengeSubmission, unmarked_sid)
            assert challenge.status == "published"
            assert correct_sub.judging_status == "correct"
            assert unmarked_sub.judging_status == "incorrect"
            assert raw.scalar(select(func.count()).select_from(XPAward).where(
                XPAward.award_type == "knowledge_correct", XPAward.challenge_id == cid
            )) == 1
            assert asyncio.run(total_xp(_SessionAdapter(raw), 991001)) == 4
            assert asyncio.run(total_xp(_SessionAdapter(raw), 991002)) == 2

        # A stale/double click cannot award correctness XP again after status is finalized.
        callback_again = _FakeCallback(data=f"admin:community:challenge:finish:{cid}:0")
        asyncio.run(handlers.admin_finish_knowledge_review(callback_again))
        with Session(engine) as raw:
            assert raw.scalar(select(func.count()).select_from(XPAward).where(
                XPAward.award_type == "knowledge_correct", XPAward.challenge_id == cid
            )) == 1
    finally:
        engine.dispose()


def test_creative_top_three_review_orders_places_and_awards_xp_only_once(monkeypatch):
    """Exercise the admin creative workflow against a disposable SQLite schema."""
    import pytest
    pytest.importorskip("aiogram")
    import app.bot.handlers.community as handlers

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    try:
        with Session(engine) as raw:
            admin = User(telegram_id=999999, first_name="Admin", last_name="User", role=UserRole.SUPER_ADMIN)
            users = [
                User(telegram_id=992101 + i, first_name=f"Creative{i+1}", last_name="Member", role=UserRole.PARTICIPANT)
                for i in range(3)
            ]
            raw.add_all([admin, *users])
            raw.flush()
            challenge = CommunityChallenge(
                title="Creative challenge", prompt="Create something", challenge_type="creative",
                winner_count=3, status="closed", created_by_telegram_id=admin.telegram_id,
            )
            raw.add(challenge)
            raw.flush()
            submissions = [
                ChallengeSubmission(
                    challenge_id=challenge.id, telegram_id=user.telegram_id,
                    answer_text=f"Creative response {i+1}", judging_status="unmarked",
                )
                for i, user in enumerate(users)
            ]
            raw.add_all(submissions)
            for user in users:
                raw.add(CommunityProfile(telegram_id=user.telegram_id))
                raw.add(XPAward(
                    telegram_id=user.telegram_id, points=2, award_type="challenge_participation",
                    award_key=f"challenge-participation:{challenge.id}:{user.telegram_id}", challenge_id=challenge.id,
                ))
            raw.commit()
            cid = challenge.id
            submission_ids = [row.id for row in submissions]
            telegram_ids = [user.telegram_id for user in users]

        monkeypatch.setattr(handlers, "SessionLocal", _SessionFactory(engine))
        monkeypatch.setattr(handlers, "_is_admin", lambda telegram_id: telegram_id == 999999)

        # Selection order is the placement order: 1st, 2nd, then 3rd.
        for submission_id in submission_ids:
            asyncio.run(handlers.admin_judge_submission(_FakeCallback(
                data=f"admin:community:judge:{cid}:0:{submission_id}:next"
            )))
        with Session(engine) as raw:
            assert [raw.get(ChallengeSubmission, sid).selected_place for sid in submission_ids] == [1, 2, 3]
            assert raw.scalar(select(func.count()).select_from(XPAward).where(
                XPAward.challenge_id == cid, XPAward.award_type.in_(("creative_first", "creative_second", "creative_third"))
            )) == 0

        # Preview is non-mutating: no placement XP until the admin confirms.
        preview = _FakeCallback(data=f"admin:community:challenge:publish:preview:{cid}:0")
        asyncio.run(handlers.admin_preview_challenge_results(preview))
        with Session(engine) as raw:
            assert raw.scalar(select(func.count()).select_from(XPAward).where(
                XPAward.challenge_id == cid, XPAward.award_type.in_(("creative_first", "creative_second", "creative_third"))
            )) == 0

        asyncio.run(handlers.admin_publish_challenge(_FakeCallback(
            data=f"admin:community:challenge:publish:confirm:{cid}:0"
        )))
        with Session(engine) as raw:
            assert raw.get(CommunityChallenge, cid).status == "published"
            expected = (("creative_first", 5), ("creative_second", 3), ("creative_third", 2))
            for telegram_id, (award_type, points) in zip(telegram_ids, expected):
                award = raw.scalar(select(XPAward).where(
                    XPAward.telegram_id == telegram_id, XPAward.challenge_id == cid,
                    XPAward.award_type == award_type,
                ))
                assert award is not None and award.points == points
            assert raw.scalar(select(func.count()).select_from(XPAward).where(
                XPAward.challenge_id == cid, XPAward.award_type.in_(("creative_first", "creative_second", "creative_third"))
            )) == 3

        # A second/stale confirmation cannot award placement XP again.
        asyncio.run(handlers.admin_publish_challenge(_FakeCallback(
            data=f"admin:community:challenge:publish:confirm:{cid}:0"
        )))
        with Session(engine) as raw:
            assert raw.scalar(select(func.count()).select_from(XPAward).where(
                XPAward.challenge_id == cid, XPAward.award_type.in_(("creative_first", "creative_second", "creative_third"))
            )) == 3
    finally:
        engine.dispose()
