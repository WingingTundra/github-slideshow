"""V78 regression coverage for XP ranking, content history and reward recovery."""
from __future__ import annotations

import ast
import re
from pathlib import Path

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.migration_utils import split_sql_statements
from app.db.models import Base, RewardIssue, ShopRequest, XPAward
from app.services.community import _leaderboard_xp_subquery
from app.services.xp_shop import (
    available_shop_xp,
    shop_economy_summary,
    shop_request_status_label,
)

ROOT = Path(__file__).resolve().parents[1]
FEATURES = (ROOT / "app/bot/handlers/v77_features.py").read_text(encoding="utf-8")
COMMUNITY = (ROOT / "app/services/community.py").read_text(encoding="utf-8")
REWARD_NOTIFICATIONS = (ROOT / "app/services/reward_notifications.py").read_text(encoding="utf-8")
MIGRATION = (ROOT / "migrations/034_v78_xp_ranking_and_notification_recovery.sql").read_text(encoding="utf-8")


def _functions(source: str) -> dict[str, ast.AsyncFunctionDef | ast.FunctionDef]:
    tree = ast.parse(source)
    return {node.name: node for node in tree.body if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef))}


def _source(source: str, name: str) -> str:
    node = _functions(source)[name]
    return ast.get_source_segment(source, node) or ""


def test_leaderboard_xp_excludes_shop_debits_and_refunds_but_user_balance_keeps_full_ledger():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        session.add_all([
            XPAward(telegram_id=100, points=10, award_type="paid_panel", award_key="paid:100"),
            XPAward(telegram_id=100, points=-20, award_type="shop_redemption", award_key="shop:100"),
            XPAward(telegram_id=100, points=20, award_type="shop_redemption_refund", award_key="refund:100"),
            XPAward(telegram_id=200, points=70, award_type="shop_redemption", award_key="only-shop:200"),
        ])
        session.commit()
        query = _leaderboard_xp_subquery()
        rows = dict(session.execute(select(query.c.tg, query.c.xp)).all())
        total_balance = session.scalar(select(__import__("sqlalchemy").func.sum(XPAward.points)).where(XPAward.telegram_id == 100))
    assert rows[100] == 10
    assert 200 not in rows  # the outer leaderboard join presents their tie-break XP as zero
    assert total_balance == 10
    assert "_leaderboard_xp_subquery()" in _source(COMMUNITY, "leaderboard_rows")
    assert "_leaderboard_xp_subquery()" in _source(COMMUNITY, "admin_leaderboard_rows")
    assert "shop_redemption" in _source(COMMUNITY, "_leaderboard_xp_subquery")
    engine.dispose()


def test_quick_fun_activity_with_responses_is_immutable_and_can_be_duplicated_as_draft():
    edit = _source(FEATURES, "admin_v77_fun_edit")
    save = _source(FEATURES, "admin_v77_fun_save")
    duplicate = _source(FEATURES, "admin_v77_fun_duplicate")
    view = _source(FEATURES, "admin_v77_fun_view")
    assert "QuickFunResponse.activity_id==aid" in edit
    assert "if responses:" in edit
    assert "response_count" in save and "if response_count:" in save
    assert "QuickFunActivity(" in duplicate and 'status="draft"' in duplicate
    assert '"source_activity_id":aid' in duplicate
    assert "تکثیر به‌صورت پیش‌نویس تازه" in view
    assert "QuickFunResponse" not in duplicate or "response_count" in duplicate


def test_quick_fun_publish_and_deactivate_require_confirm_then_revalidate():
    preview = _source(FEATURES, "admin_v77_fun_set_status")
    apply = _source(FEATURES, "admin_v78_fun_apply_status")
    assert "تأیید انتشار" in preview and "تأیید غیرفعال‌سازی" in preview
    assert "admin:v78:fun:apply" in preview
    assert "item.status=new_status" not in preview
    assert 'with_for_update()' in apply
    assert "item.status=new_status" in apply
    assert "write_admin_action" in apply
    assert "_is_admin" in preview and "_is_admin" in apply


def test_quick_fun_preview_shows_options_and_keeps_answer_key_admin_only():
    preview = _source(FEATURES, "admin_v77_fun_preview")
    assert 'پیش‌نمایش کاربر' in preview
    assert 'کلید پاسخ (فقط مدیر)' in preview
    assert "item.correct_option" in preview and "item.answer_text" in preview
    assert "XP یا پاداش پیشرفت ایجاد نمی‌کنند" in preview


def test_reward_delivery_recovery_has_confirmed_delivered_and_not_delivered_paths():
    resolution = _source(FEATURES, "admin_reward_resolve_preview")
    delivered_preview = _source(FEATURES, "admin_reward_resolve_delivered_preview")
    delivered_confirm = _source(FEATURES, "admin_reward_resolve_delivered_confirm")
    not_delivered = _source(FEATURES, "admin_reward_resolve_confirm")
    assert "تحویل‌شدن تأیید شد" in resolution and "تحویل‌نشدن تأیید شد" in resolution
    assert "تأیید تحویل" in delivered_preview
    assert 'issue.status="delivered"' in delivered_confirm
    assert 'issue.delivery_state="verified_delivered"' in delivered_confirm
    assert "with_for_update()" in delivered_confirm
    assert "req.status=" in delivered_confirm
    assert "write_admin_action" in delivered_confirm and "write_admin_action" in not_delivered
    assert "delivery_failed" in not_delivered


def test_admin_alerts_are_durable_retryable_and_never_fall_back_to_requester():
    assert "authorized_admin_recipients" in REWARD_NOTIFICATIONS
    assert "User.role == UserRole.SUPER_ADMIN" in REWARD_NOTIFICATIONS
    assert "settings.super_admin_id_set" in REWARD_NOTIFICATIONS
    assert "c.from_user.id" not in REWARD_NOTIFICATIONS
    assert 'row.admin_notification_attempts = int(row.admin_notification_attempts or 0) + 1' in REWARD_NOTIFICATIONS
    assert 'row.admin_notification_status = status' in REWARD_NOTIFICATIONS
    assert 'admin:v78:notifications:retry' in FEATURES
    assert re.search(r'alert_states=\("pending",\s*"failed",\s*"not_attempted"\)', FEATURES)
    assert 'admin_notification_status.in_(alert_states)' in FEATURES
    assert 'admin:v78:notifications:retry' in _source(FEATURES, "v77_admin_home")
    assert '"failed"' in _source(FEATURES, "admin_v78_retry_notifications")


def test_admin_home_has_live_work_queue_counts_and_xp_cost_review_is_aggregate_only():
    attention_source = (ROOT / "app/bot/handlers/admin_features.py").read_text(encoding="utf-8")
    home = _source(attention_source, "admin_attention_center")
    economy = _source(FEATURES, "admin_v78_shop_economy")
    assert "pending_shop" in home and "RewardIssue" in home and "delivery_uncertain" in home
    assert "host_alerts" in home and "active_broadcasts" in home
    assert "User.telegram_id" in economy  # used only as join key, not displayed
    # V94 replaced the fixed four-tier affordability summary with a dynamic
    # offer-by-offer report sourced from the XP ledger and current catalogue.
    assert "offers = await list_shop_offers" in economy
    assert "xp_economy_totals(session)" in economy
    assert "affordable=sum" in economy
    assert "شامل شناسه یا موجودی افراد نیست" in economy
    assert "قیمت‌ها خودکار تغییر نمی‌کنند" in economy


def test_shop_status_display_tracks_actual_reward_issue_progression():
    from app.services.xp_shop import shop_request_status_label

    assert shop_request_status_label("awaiting_code", "ready_to_deliver") == "Reward ready · awaiting delivery"
    assert shop_request_status_label("awaiting_code", "delivery_uncertain") == "Delivery status requires Admin review"
    assert shop_request_status_label("awaiting_code", "delivered") == "Delivered"
    assert shop_request_status_label("pending") == "Awaiting review"
    assert shop_request_status_label("refunded") == "XP refunded"
    assert shop_request_status_label("unknown_internal_state") == "Unknown Internal State"
    assert available_shop_xp(30, 40) == 0
    assert available_shop_xp(100, 25) == 75


def test_xp_economy_summary_only_returns_aggregate_counts():
    summary = shop_economy_summary([0, 20, 80, 200], {15: 20, 25: 40, 50: 80, 100: 160})
    assert summary == {
        "registered_users": 4,
        "median_available_xp": 50,
        "affordable_counts": {15: 3, 25: 2, 50: 2, 100: 1},
    }
    assert all(isinstance(k, int) for k in summary["affordable_counts"])
    assert not any("telegram" in str(key).lower() for key in summary)


def test_v78_migration_adds_notification_tracking_without_touching_historical_requests():
    statements = split_sql_statements(MIGRATION)
    assert len(statements) >= 10
    lowered = MIGRATION.lower()
    for table in ("shop_requests", "reward_issues"):
        assert f"alter table {table}" in lowered
        assert "admin_notification_status" in lowered
        assert "admin_notification_attempts" in lowered
        assert f"ix_{table}_admin_notification" in lowered
    assert "default 'not_attempted'" in lowered
    assert "set default 'pending'" in lowered
    assert not re.search(r"\b(drop\s+table|truncate\s+table|delete\s+from)\b", lowered)
    for model in (ShopRequest, RewardIssue):
        assert "admin_notification_status" in model.__table__.columns
        assert "admin_notification_attempts" in model.__table__.columns
        assert "admin_notified_at" in model.__table__.columns
        assert "admin_notification_error" in model.__table__.columns


def test_delivery_and_shop_business_logic_has_a_focused_service_module():
    service = (ROOT / "app/services/xp_shop.py").read_text(encoding="utf-8")
    assert "configured_shop_costs" in service
    assert "reserved_shop_xp" in service
    assert "shop_request_status_label" in service
    assert "shop_economy_summary" in service
    assert "notify_admins" in (ROOT / "app/services/reward_notifications.py").read_text(encoding="utf-8")
