from __future__ import annotations

from pathlib import Path

from app.services.excel_export import build_leaderboard_workbook

ROOT = Path(__file__).resolve().parents[1]


def test_panel_discovery_is_compact_paginated_and_preserves_current_page():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert "EVENT_LIST_PAGE_SIZE = 7" in user
    assert 'F.data.regexp(r"^user:events:page:\\d+$")' in user
    assert 'callback_data=f"user:events:page:{page + 1}"' in user
    assert "used_by_event" in user and "public_catalogue_availability_label" in user
    assert "return_page=return_page" in user
    assert "seven panels" in user and "one full-width button row per panel" in user
    picker = keyboard.split("def available_events_keyboard", 1)[1].split("def duplicate_registration_keyboard", 1)[0]
    assert "rows.append([" in picker
    assert "title = truncate_display_text(event.title or \"پنل\", 25)" in picker
    assert "if len(row) == 2" not in picker


def test_registration_prompts_have_clear_three_stage_progress():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert "مرحلهٔ ۱ از ۳ – تعداد و مشخصات" in source
    assert "مرحلهٔ ۲ از ۳ – بررسی و تأیید" in source
    assert "مرحلهٔ ۳ از ۳ – پرداخت و ارسال رسید" in source


def test_my_registrations_explain_next_action_and_pair_related_buttons():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    handler = source.split('async def render_my_bookings', 1)[1].split('@router.callback_query(F.data.startswith("user:booking:cancel:confirm:"))', 1)[0]
    assert "قدم بعدی: رسید پرداخت را ارسال کنید" in handler
    assert "نیازی به ارسال دوباره نیست" in handler
    assert "رسید اصلاح‌شده را دوباره ارسال کنید یا رزرو را لغو کنید" in handler
    assert "for action_offset in range(0, len(actions), 2):" in handler
    assert "rows.append(actions[action_offset:action_offset + 2])" in handler
    assert "Keep all actions reachable" in handler
    assert "ثبت‌نام شما نهایی شده است." in handler


def test_receipt_and_waitlist_outcomes_are_explicit():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert "پس از بررسی، نتیجه را به شما اطلاع می‌دهیم. تا آن زمان نیازی به ارسال مجدد رسید نیست." in source
    assert "جایگاه فعلی شما:" in source
    assert "active_queue_count + 1" in source
    assert "Keep the stored position increasing for FIFO ordering" in source
    assert "عضویت در لیست انتظار به معنی رزرو قطعی نیست." in source


def test_discount_errors_offer_next_step_and_preserve_registration_draft():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    discounts = (ROOT / "app/services/discounts.py").read_text(encoding="utf-8")
    assert "CODE_INACTIVE" in discounts
    assert "CODE_NOT_FOR_PANEL" in discounts
    assert "CODE_ALREADY_USED" in user and "CODE_UNAVAILABLE" in user
    assert "اطلاعات ثبت‌نام شما حفظ شده است" in user
    assert 'InlineKeyboardButton(text="ادامه بدون کد"' in user


def test_manual_reminder_is_date_neutral_and_preview_counts_confirmed_recipients():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    preview = admin.split('async def reminder_preview', 1)[1].split('@router.callback_query(F.data == "admin:today_cancel")', 1)[0]
    assert "recipient_count" in preview
    assert "تعداد دریافت‌کنندگان فعلی" in preview
    assert "این پیام فقط برای ثبت‌نام‌کنندگان تأییدشده" in preview
    assert "امروز برگزار می‌شود" not in preview
    assert "یادتون نره امروز" not in preview
    send_flow = admin.split('async def reminder_send', 1)[1].split('@router.callback_query', 1)[0]
    assert 'event.status != EventStatus.PUBLISHED or event.archived' in send_flow


def test_achievement_notifications_are_queued_for_one_popup_not_sent_as_chat_messages():
    community = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    helper = community.split("async def _show_pending_achievement_popup", 1)[1].split("async def _challenge_by_id", 1)[0]
    assert "show_alert=True" in helper
    assert "celebrated_at.is_(None)" in helper
    assert "await c.bot.send_message" not in community
    assert "Milestones are left queued" in community
    payment_actions = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    assert "achievement notice" not in payment_actions.lower()
    assert "await c.bot.send_message" in payment_actions  # confirmation/rejection messages remain


def test_submission_dashboard_has_filters_and_progress_metrics():
    community = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    renderer = community.split("async def _render_submission_challenge_list", 1)[1].split(
        '@router.callback_query(F.data.regexp(r"^admin:community:submissions:list:\\d+$"))', 1
    )[0]
    for name in ('"all"', '"knowledge"', '"creative"', '"pending"'):
        assert name in renderer
    assert "submission_stats" in renderer
    assert "reviewed" in renderer
    assert "جایگاه برگزیدگان انتخاب‌شده" in renderer
    assert "admin:community:submissions:list:knowledge:0" in renderer
    assert "admin:community:submissions:list:creative:0" in renderer
    assert "admin:community:submissions:list:pending:0" in renderer


def test_leaderboard_export_is_admin_only_and_workbook_contains_requested_fields():
    community = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    export_handler = community.split('async def admin_export_full_leaderboard', 1)[1].split(
        '@router.callback_query(F.data == "admin:community:leaderboard:toggle")', 1
    )[0]
    assert 'if not await _is_admin(c.from_user.id)' in export_handler
    assert "admin_leaderboard_rows" in export_handler
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:community:leaderboard:export"' in keyboard

    payload = build_leaderboard_workbook([
        {"name": "Alice Example", "panels": 4, "xp": 46, "hidden": False},
        {"name": "Hidden Example", "panels": 2, "xp": 21, "hidden": True},
    ])
    assert payload[:2] == b"PK"
    import openpyxl
    from io import BytesIO
    workbook = openpyxl.load_workbook(BytesIO(payload), read_only=True, data_only=True)
    rows = list(workbook["Leaderboard"].iter_rows(values_only=True))
    assert rows[0] == ("Rank", "Name", "Panels participated in", "XP", "Public visibility")
    assert rows[1] == (1, "Alice Example", 4, 46, "Visible on public leaderboard")
    assert rows[2] == (2, "Hidden Example", 2, 21, "Hidden from public leaderboard")
    workbook.close()
