from decimal import Decimal
import asyncio
from datetime import timedelta
import pytest

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.models import (
    Base, Booking, DiscountCode, DiscountCodeEvent, DiscountRedemption, Event,
    EventStatus, Payment, PaymentStatus, RegistrationStatus, User, UserRole, UserModerationRecord,
)
from app.time_utils import utc_now_naive
from app.services.booking import (
    MAX_ACTIVE_SEATS_PER_USER_PER_PANEL,
    MAX_PARTICIPANTS_PER_BOOKING,
    active_seats_for_owner,
    cancel_booking,
    create_booking,
    expire_old_bookings,
    retry_payment,
)


class FakeAsyncSession:
    def __init__(self, sync_session: Session):
        self.s = sync_session

    async def execute(self, stmt):
        return self.s.execute(stmt)

    async def get(self, entity, ident, **kwargs):
        return self.s.get(entity, ident)

    def add(self, obj):
        self.s.add(obj)

    async def flush(self):
        self.s.flush()

    async def commit(self):
        self.s.commit()

    async def refresh(self, obj):
        self.s.refresh(obj)


def make_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, FakeAsyncSession(Session(engine))


def seed_event(session, *, price=100000, capacity=5, registration_open=True):
    owner = User(telegram_id=9001, first_name="Owner", last_name="User", role=UserRole.PARTICIPANT)
    host = User(telegram_id=9002, first_name="Host", last_name="User", role=UserRole.HOST)
    session.s.add_all([owner, host])
    session.s.flush()
    event = Event(
        volume=20,
        title="Service Test",
        event_day_label="Thursday",
        event_date_label="15 October 2026",
        venue="Test Venue",
        capacity=capacity,
        price_per_person=Decimal(price),
        status=EventStatus.PUBLISHED,
        registration_open=registration_open,
        waitlist_enabled=True,
        host_id=host.id,
        host_name="Host User",
    )
    session.s.add(event)
    session.s.commit()
    session.s.refresh(owner)
    session.s.refresh(event)
    return owner, event


def test_paid_booking_is_not_created_when_payment_details_are_missing():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=100000, capacity=5)
        try:
            asyncio.run(create_booking(
                session, owner.id, event.id,
                [{"first_name": "Ali", "last_name": "Ahmadi"}],
                payment_details_configured=False,
            ))
            assert False, "paid bookings must be blocked without configured payment details"
        except ValueError as exc:
            assert str(exc) == "PAYMENT_CONFIGURATION_MISSING"
        assert session.s.query(Booking).count() == 0
        assert session.s.get(Event, event.id).registration_open is True
    finally:
        session.s.close(); engine.dispose()


def test_zero_cost_booking_remains_available_without_payment_details():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=0, capacity=5)
        booking = asyncio.run(create_booking(
            session, owner.id, event.id,
            [{"first_name": "Ali", "last_name": "Ahmadi"}],
            payment_details_configured=False,
        ))
        assert booking.total_amount == Decimal(0)
        assert booking.status == RegistrationStatus.CONFIRMED
    finally:
        session.s.close(); engine.dispose()


def test_create_booking_closes_registration_exactly_when_capacity_is_reached():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=4)
        booking = asyncio.run(create_booking(session, owner.id, event.id, [
            {"first_name": "Ali", "last_name": "Ahmadi"},
            {"first_name": "Sara", "last_name": "Karimi"},
            {"first_name": "Reza", "last_name": "Karimi"},
        ]))
        assert booking.participant_count == 3
        assert event.registration_open is True
        host = session.s.query(User).filter_by(telegram_id=9002).one()
        second = asyncio.run(create_booking(session, host.id, event.id, [
            {"first_name": "Nima", "last_name": "Ahmadi"},
        ]))
        assert second.participant_count == 1
        assert event.registration_open is False
        try:
            asyncio.run(create_booking(session, 7777, event.id, [{"first_name": "Another", "last_name": "Person"}]))
            assert False, "full event should remain closed"
        except ValueError as exc:
            assert str(exc) == "EVENT_NOT_OPEN"
    finally:
        session.s.close(); engine.dispose()


def test_create_booking_keeps_registration_open_below_capacity():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        asyncio.run(create_booking(session, owner.id, event.id, [
            {"first_name": "Ali", "last_name": "Ahmadi"},
            {"first_name": "Sara", "last_name": "Karimi"},
        ]))
        assert event.registration_open is True
    finally:
        session.s.close(); engine.dispose()


def test_cancellation_frees_capacity_but_does_not_auto_reopen():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=2)
        booking = asyncio.run(create_booking(session, owner.id, event.id, [
            {"first_name": "Ali", "last_name": "Ahmadi"},
            {"first_name": "Sara", "last_name": "Karimi"},
        ]))
        assert event.registration_open is False
        asyncio.run(cancel_booking(session, owner.id, booking.id))
        assert event.registration_open is False
    finally:
        session.s.close(); engine.dispose()


def test_expired_pending_payment_releases_booking_without_reopening_panel():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        booking = Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=1,
            total_amount=100000,
            status=RegistrationStatus.PENDING_PAYMENT,
            expires_at=utc_now_naive() - timedelta(minutes=1),
        )
        session.s.add(booking); session.s.commit()
        asyncio.run(expire_old_bookings(session))
        session.s.commit()
        fresh = session.s.get(Booking, booking.id)
        assert fresh.status == RegistrationStatus.EXPIRED
    finally:
        session.s.close(); engine.dispose()


def test_rejected_payment_retry_closes_when_it_reaches_capacity():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=2)
        booking = Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=2,
            total_amount=200000,
            status=RegistrationStatus.REJECTED,
        )
        payment = Payment(booking=booking, amount=200000, receipt_file="/data/uploads/old.jpg", status=PaymentStatus.REJECTED)
        session.s.add_all([booking, payment]); session.s.commit()
        retried = asyncio.run(retry_payment(session, owner.id, booking.id))
        assert retried.status == RegistrationStatus.PENDING_PAYMENT
        assert event.registration_open is False
    finally:
        session.s.close(); engine.dispose()


def test_booking_persists_participant_phone_numbers():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        booking = asyncio.run(create_booking(session, owner.id, event.id, [
            {"first_name": "Ali", "last_name": "Ahmadi", "phone_number": "+989121234567"},
        ]))
        assert booking.participants[0].phone_number == "+989121234567"
    finally:
        session.s.close(); engine.dispose()


def test_multi_person_booking_keeps_phone_only_for_booker_when_supplied():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        booking = asyncio.run(create_booking(session, owner.id, event.id, [
            {"first_name": "Sina", "last_name": "Example", "phone_number": "+989151117889"},
            {"first_name": "Ali", "last_name": "Example"},
            {"first_name": "Reza", "last_name": "Example"},
        ]))
        assert [p.phone_number for p in booking.participants] == ["+989151117889", None, None]
    finally:
        session.s.close(); engine.dispose()


def test_duplicate_active_booking_is_rejected_by_default_but_allowed_when_explicitly_requested():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        first = asyncio.run(create_booking(session, owner.id, event.id, [
            {"first_name": "Ali", "last_name": "Ahmadi"},
        ]))
        try:
            asyncio.run(create_booking(session, owner.id, event.id, [
                {"first_name": "Sara", "last_name": "Karimi"},
            ]))
            assert False, "duplicate active booking should require explicit opt-in"
        except ValueError as exc:
            assert str(exc) == "DUPLICATE"

        second = asyncio.run(create_booking(
            session, owner.id, event.id, [{"first_name": "Sara", "last_name": "Karimi"}],
            allow_duplicate=True,
        ))
        assert second.id != first.id
        assert second.booked_by_user_id == owner.id
    finally:
        session.s.close(); engine.dispose()


def participant(first, last):
    return {"first_name": first, "last_name": last}


def test_single_booking_is_limited_to_three_participants():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=10)
        with pytest.raises(ValueError, match="MAX_PARTICIPANTS_PER_BOOKING"):
            asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One"), participant("B", "Two"), participant("C", "Three"), participant("D", "Four")]))
    finally:
        session.s.close(); engine.dispose()


def test_user_can_hold_at_most_three_active_seats_across_duplicate_bookings():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=10)
        asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One"), participant("B", "Two")]))
        with pytest.raises(ValueError, match="USER_SEAT_LIMIT"):
            asyncio.run(create_booking(session, owner.id, event.id, [participant("C", "Three"), participant("D", "Four")], allow_duplicate=True))
        second = asyncio.run(create_booking(session, owner.id, event.id, [participant("C", "Three")], allow_duplicate=True))
        assert second.participant_count == 1
        assert asyncio.run(active_seats_for_owner(session, event.id, owner.id)) == 3
        with pytest.raises(ValueError, match="USER_SEAT_LIMIT"):
            asyncio.run(create_booking(session, owner.id, event.id, [participant("D", "Four")], allow_duplicate=True))
    finally:
        session.s.close(); engine.dispose()


def test_user_with_three_active_seats_cannot_add_another_booking():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=10)
        asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One"), participant("B", "Two"), participant("C", "Three")]))
        with pytest.raises(ValueError, match="USER_SEAT_LIMIT"):
            asyncio.run(create_booking(session, owner.id, event.id, [participant("D", "Four")], allow_duplicate=True))
    finally:
        session.s.close(); engine.dispose()


def test_cancelled_and_rejected_bookings_are_not_counted_toward_user_limit():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=10)
        cancelled = Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=3, total_amount=300000, status=RegistrationStatus.CANCELLED)
        rejected = Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=3, total_amount=300000, status=RegistrationStatus.REJECTED)
        session.s.add_all([cancelled, rejected]); session.s.commit()
        assert asyncio.run(active_seats_for_owner(session, event.id, owner.id)) == 0
        booking = asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One"), participant("B", "Two"), participant("C", "Three")]))
        assert booking.participant_count == 3
    finally:
        session.s.close(); engine.dispose()


def test_repeat_registration_requires_explicit_allow_duplicate_and_preserves_capacity_rules():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One")]))
        with pytest.raises(ValueError, match="DUPLICATE"):
            asyncio.run(create_booking(session, owner.id, event.id, [participant("B", "Two")]))
        second = asyncio.run(create_booking(session, owner.id, event.id, [participant("B", "Two")], allow_duplicate=True))
        assert second.id is not None
    finally:
        session.s.close(); engine.dispose()


def test_expired_booking_is_released_before_applying_user_seat_limit():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=10)
        old = Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=3,
            total_amount=300000,
            status=RegistrationStatus.PENDING_PAYMENT,
            expires_at=utc_now_naive() - timedelta(minutes=1),
        )
        session.s.add(old); session.s.commit()
        new = asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One"), participant("B", "Two"), participant("C", "Three")]))
        assert new.participant_count == 3
        assert session.s.get(Booking, old.id).status == RegistrationStatus.EXPIRED
    finally:
        session.s.close(); engine.dispose()


def test_capacity_limit_still_wins_when_panel_has_only_two_seats_left():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        other = session.s.query(User).filter_by(telegram_id=9002).one()
        asyncio.run(create_booking(session, owner.id, event.id, [participant("A", "One"), participant("B", "Two"), participant("C", "Three")]))
        # A different user still has only two panel seats available; three is rejected by capacity.
        with pytest.raises(ValueError, match="FULL"):
            asyncio.run(create_booking(session, other.id, event.id, [participant("D", "Four"), participant("E", "Five"), participant("F", "Six")]))
    finally:
        session.s.close(); engine.dispose()


def test_pending_verification_booking_counts_toward_user_limit():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=10)
        session.s.add(Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=3,
            total_amount=300000,
            status=RegistrationStatus.PENDING_VERIFICATION,
        ))
        session.s.commit()
        with pytest.raises(ValueError, match="USER_SEAT_LIMIT"):
            asyncio.run(create_booking(session, owner.id, event.id, [participant("D", "Four"), participant("E", "Five")], allow_duplicate=True))
    finally:
        session.s.close(); engine.dispose()


def test_user_limit_check_is_serialized_after_panel_row_lock_for_concurrent_safety():
    booking = __import__("pathlib").Path(__file__).resolve().parents[1] / "app/services/booking.py"
    text = booking.read_text(encoding="utf-8")
    event_lock = text.index("event = await _load_event_locked(session, event_id)")
    user_limit = text.index("user_seats = await active_seats_for_owner(session, event_id, user_id)")
    assert event_lock < user_limit
    assert "with_for_update=True" in text[text.index("async def _load_event_locked"):text.index("async def _active_booking_for_owner")]


def test_booking_contact_phone_is_stored_on_booking_not_misattributed_to_participant_or_profile():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        owner.phone_number = "+989111112222"  # an older profile number, not the number entered for this booking
        session.s.commit()
        booking = asyncio.run(create_booking(
            session,
            owner.id,
            event.id,
            [{"first_name": "Ali", "last_name": "Ahmadi"}, {"first_name": "Sara", "last_name": "Karimi"}],
            contact_phone="09151118888",
        ))
        assert booking.contact_phone == "+989151118888"
        assert [participant.phone_number for participant in booking.participants] == [None, None]
        assert owner.phone_number == "+989111112222"
    finally:
        session.s.close(); engine.dispose()


def test_booking_rejects_invalid_contact_phone_at_service_layer():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        with pytest.raises(ValueError, match="INVALID_BOOKER_PHONE"):
            asyncio.run(create_booking(
                session,
                owner.id,
                event.id,
                [{"first_name": "Ali", "last_name": "Ahmadi"}],
                contact_phone="not a phone",
            ))
    finally:
        session.s.close(); engine.dispose()


def test_expire_old_bookings_can_be_scoped_to_one_event_and_reports_capacity_changes():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        other_event = Event(
            volume=21,
            title="Other Event",
            event_day_label="Friday",
            event_date_label="16 October 2026",
            venue="Other Venue",
            capacity=5,
            price_per_person=Decimal("100000"),
            status=EventStatus.PUBLISHED,
            registration_open=True,
            waitlist_enabled=True,
            host_id=session.s.query(User).filter_by(telegram_id=9002).one().id,
            host_name="Host User",
        )
        session.s.add(other_event)
        session.s.commit()
        now_past = utc_now_naive() - timedelta(minutes=1)
        expired_booking = Booking(
            event_id=event.id, booked_by_user_id=owner.id, participant_count=1,
            total_amount=100000, status=RegistrationStatus.PENDING_PAYMENT, expires_at=now_past,
        )
        unrelated_booking = Booking(
            event_id=other_event.id, booked_by_user_id=owner.id, participant_count=1,
            total_amount=100000, status=RegistrationStatus.PENDING_PAYMENT, expires_at=now_past,
        )
        session.s.add_all([expired_booking, unrelated_booking])
        session.s.commit()

        changed_event_ids = asyncio.run(expire_old_bookings(session, event_id=event.id))
        session.s.commit()
        assert changed_event_ids == {event.id}
        assert session.s.get(Booking, expired_booking.id).status == RegistrationStatus.EXPIRED
        assert session.s.get(Booking, unrelated_booking.id).status == RegistrationStatus.PENDING_PAYMENT
    finally:
        session.s.close(); engine.dispose()


def _add_discount(session, event, *, kind, discount_type="percent", value=20, telegram_id=9001,
                  requires_approval=False, max_redemptions=None, usage_policy="once_total"):
    code = DiscountCode(
        code=("TEST" + str(value) if kind != "personal" else None),
        label=("Test reward" if kind == "personal" else "TEST" + str(value)),
        kind=kind, discount_type=discount_type, discount_value=Decimal(value),
        requires_approval=requires_approval, active=True, max_redemptions=max_redemptions,
        usage_policy=usage_policy, recipient_telegram_id=telegram_id if kind == "personal" else None,
        accepted_at=utc_now_naive() if kind == "personal" else None,
        created_by_telegram_id=9999,
    )
    # Seed through the underlying synchronous SQLAlchemy session: FakeAsyncSession
    # intentionally exposes async wrapper methods for application code.
    session.s.add(code)
    session.s.flush()
    session.s.add(DiscountCodeEvent(discount_code_id=code.id, event_id=event.id))
    session.s.commit()
    session.s.refresh(code)
    return code


def test_public_percentage_code_applies_to_entire_group_and_records_redemption():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=100000, capacity=5)
        code = _add_discount(session, event, kind="public", value=20, max_redemptions=4)
        booking = asyncio.run(create_booking(
            session, owner.id, event.id,
            [{"first_name": "A", "last_name": "One"},
             {"first_name": "B", "last_name": "Two"},
             {"first_name": "C", "last_name": "Three"}],
            discount_code_id=code.id,
        ))
        session.s.refresh(booking)
        redemption = session.s.query(DiscountRedemption).filter_by(booking_id=booking.id).one()
        assert booking.total_amount == Decimal("240000")
        assert booking.discount_amount == Decimal("60000")
        assert booking.discount_code_snapshot == "TEST20"
        assert booking.status == RegistrationStatus.PENDING_PAYMENT
        assert redemption.status == "redeemed"
        assert redemption.participant_count == 3
        assert redemption.original_total == Decimal("300000")
        assert redemption.final_total == Decimal("240000")
        assert code.active is True
    finally:
        session.s.close(); engine.dispose()


def test_personal_100_percent_reward_frees_single_booking_but_only_discounts_one_group_admission():
    # Single person: the booking confirms immediately and does not require a receipt.
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=100000, capacity=5)
        code = _add_discount(session, event, kind="personal", value=100, telegram_id=owner.telegram_id)
        booking = asyncio.run(create_booking(
            session, owner.id, event.id, [{"first_name": "Owner", "last_name": "User"}],
            discount_code_id=code.id,
        ))
        assert booking.total_amount == Decimal("0")
        assert booking.discount_amount == Decimal("100000")
        assert booking.status == RegistrationStatus.CONFIRMED
        assert code.active is False
        assert session.s.query(DiscountRedemption).filter_by(booking_id=booking.id).one().status == "redeemed"
        assert session.s.get(User, owner.id).lifetime_confirmed_bookings == 1
    finally:
        session.s.close(); engine.dispose()

    # Group booking: the prize covers exactly one admission; the other two remain payable.
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=100000, capacity=5)
        code = _add_discount(session, event, kind="personal", value=100, telegram_id=owner.telegram_id)
        booking = asyncio.run(create_booking(
            session, owner.id, event.id,
            [{"first_name": "Owner", "last_name": "User"},
             {"first_name": "Friend", "last_name": "One"},
             {"first_name": "Friend", "last_name": "Two"}],
            discount_code_id=code.id,
        ))
        assert booking.total_amount == Decimal("200000")
        assert booking.discount_amount == Decimal("100000")
        assert booking.status == RegistrationStatus.PENDING_PAYMENT
        assert code.active is False
    finally:
        session.s.close(); engine.dispose()


def test_restricted_code_cannot_bypass_approval_and_full_price_fallback_withdraws_atomically():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=100000, capacity=5)
        code = _add_discount(session, event, kind="restricted", value=50, requires_approval=True)
        with pytest.raises(ValueError, match="CODE_NEEDS_APPROVAL"):
            asyncio.run(create_booking(
                session, owner.id, event.id, [{"first_name": "Owner", "last_name": "User"}],
                discount_code_id=code.id,
            ))
        session.s.rollback()

        request = DiscountRedemption(
            discount_code_id=code.id, code_snapshot=code.code, event_id=event.id,
            event_label_snapshot=f"V{event.volume} — {event.title}", user_telegram_id=owner.telegram_id,
            status="approved", draft_json='{"participants":[{"first_name":"Owner","last_name":"User"}]}',
            participant_count=1, original_total=Decimal("100000"), discount_amount=Decimal("50000"),
            final_total=Decimal("50000"), created_at=utc_now_naive(), updated_at=utc_now_naive(),
        )
        session.s.add(request); session.s.commit(); session.s.refresh(request)
        booking = asyncio.run(create_booking(
            session, owner.id, event.id, [{"first_name": "Owner", "last_name": "User"}],
            cancel_discount_redemption_id=request.id,
        ))
        session.s.refresh(request)
        assert booking.total_amount == Decimal("100000")
        assert request.status == "withdrawn"
        assert request.draft_json is None
    finally:
        session.s.close(); engine.dispose()


def test_full_price_fallback_failure_does_not_withdraw_discount_request():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, price=100000, capacity=1)
        code = _add_discount(session, event, kind="restricted", value=50, requires_approval=True)
        request = DiscountRedemption(
            discount_code_id=code.id, code_snapshot=code.code, event_id=event.id,
            event_label_snapshot=f"V{event.volume} — {event.title}", user_telegram_id=owner.telegram_id,
            status="approved", draft_json='{"participants":[{"first_name":"Owner","last_name":"User"}]}',
            participant_count=1, created_at=utc_now_naive(), updated_at=utc_now_naive(),
        )
        session.s.add(request); session.s.commit(); session.s.refresh(request)
        host = session.s.query(User).filter_by(telegram_id=9002).one()
        asyncio.run(create_booking(session, host.id, event.id, [{"first_name": "Host", "last_name": "User"}]))
        try:
            asyncio.run(create_booking(
                session, owner.id, event.id, [{"first_name": "Owner", "last_name": "User"}],
                cancel_discount_redemption_id=request.id,
            ))
            assert False, "A full/closed panel must not accept a full-price fallback booking"
        except ValueError as exc:
            assert str(exc) in {"EVENT_NOT_OPEN", "FULL"}
        session.s.refresh(request)
        assert request.status == "approved"
        assert request.draft_json is not None
    finally:
        session.s.close(); engine.dispose()


def test_active_booking_scope_restriction_prevents_creating_a_temporary_seat_hold():
    engine, session = make_db()
    try:
        owner, event = seed_event(session, capacity=5)
        session.add(UserModerationRecord(
            target_telegram_id=int(owner.telegram_id), actor_telegram_id=987654,
            action="restriction", scope="booking", reason="Repeated disruptive reservations",
            active=True, expires_at=utc_now_naive() + timedelta(days=1),
        ))
        session.s.commit()
        with pytest.raises(ValueError, match="USER_BOOKING_RESTRICTED"):
            asyncio.run(create_booking(session, owner.id, event.id, [
                {"first_name": "Ali", "last_name": "Ahmadi"},
            ]))
        assert session.s.query(Booking).count() == 0
    finally:
        session.s.close(); engine.dispose()
