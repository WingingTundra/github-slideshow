from __future__ import annotations

import hashlib
import os
import shutil
import signal
import subprocess
import tarfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _run_process_group(command, *, env, timeout=30):
    """Run a potentially subprocess-spawning script with a hard group timeout."""
    process = subprocess.Popen(
        command, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate(timeout=5)
        raise subprocess.TimeoutExpired(command, timeout, output=stdout, stderr=stderr)
    return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)


def test_restore_script_preserves_uploads_only_after_success():
    script = (ROOT / "scripts/restore-backup.sh").read_text(encoding="utf-8")
    assert "RESTORE_SUCCESS=0" in script
    assert 'if [ "$RESTORE_SUCCESS" -ne 1 ]; then' in script
    assert 'rm -rf "$RESTORE_UPLOAD_DIR"' in script
    assert script.index('tar -xzf "$RESTORE_DIR/uploads.tar.gz" -C "$RESTORE_UPLOAD_DIR"') < script.index('RESTORE_SUCCESS=1')
    assert script.index('RESTORE_SUCCESS=1') < script.index('trap - EXIT HUP INT TERM')


def _build_fake_encrypted_backup(tmp_path: Path) -> tuple[Path, Path]:
    work = tmp_path / "backup-source"
    uploads = work / "uploads"
    work.mkdir()
    uploads.mkdir()
    (work / "database.dump").write_bytes(b"fake PostgreSQL custom-format dump fixture")
    (uploads / "important-upload.txt").write_text("restored upload survives", encoding="utf-8")
    uploads_tar = work / "uploads.tar.gz"
    with tarfile.open(uploads_tar, "w:gz") as archive:
        archive.add(uploads / "important-upload.txt", arcname="important-upload.txt")
    hashes = []
    for name in ("database.dump", "uploads.tar.gz"):
        digest = hashlib.sha256((work / name).read_bytes()).hexdigest()
        hashes.append(f"{digest}  {name}\n")
    (work / "SHA256SUMS").write_text("".join(hashes), encoding="ascii")
    (work / "MANIFEST.txt").write_text("release=V70\n", encoding="utf-8")
    backup_tar = tmp_path / "fake-encrypted-backup.tar.gz.enc"
    with tarfile.open(backup_tar, "w:gz") as archive:
        for name in ("database.dump", "uploads.tar.gz", "SHA256SUMS", "MANIFEST.txt"):
            archive.add(work / name, arcname=name)
    return backup_tar, uploads / "important-upload.txt"


def _fake_restore_commands(tmp_path: Path) -> Path:
    bindir = tmp_path / "fake-bin"
    bindir.mkdir()
    (bindir / "openssl").write_text(
        "#!/bin/sh\nset -eu\nin=\nout=\nwhile [ $# -gt 0 ]; do\n"
        "  case \"$1\" in -in) in=$2; shift 2;; -out) out=$2; shift 2;; *) shift;; esac\n"
        "done\nif [ -n \"${OPENSSL_DECRYPT_FIXTURE:-}\" ]; then cp \"$OPENSSL_DECRYPT_FIXTURE\" \"$out\"; else cp \"$in\" \"$out\"; fi\n",
        encoding="utf-8",
    )
    (bindir / "psql").write_text(
        "#!/usr/bin/env python3\nimport os,sys\n"
        "if os.environ.get('FAKE_PSQL_NONEMPTY') == '1': print('1'); raise SystemExit(0)\n"
        "q=sys.argv[sys.argv.index('-c')+1]\nprint('0' if \"'v'\" in q else '1')\n",
        encoding="utf-8",
    )
    (bindir / "pg_restore").write_text(
        "#!/bin/sh\nset -eu\nif [ -n \"${PG_RESTORE_MARKER:-}\" ]; then printf called > \"$PG_RESTORE_MARKER\"; fi\nexit 0\n",
        encoding="utf-8",
    )
    for script in bindir.iterdir():
        script.chmod(0o755)
    return bindir


@pytest.mark.skipif(not all(shutil.which(command) for command in ("sh", "tar", "sha256sum")), reason="shell archive tools unavailable")
def test_restore_script_retains_uploads_on_success_and_cleans_partial_restore_on_failure(tmp_path):
    backup, source_upload = _build_fake_encrypted_backup(tmp_path)
    # Exercise the actual current authenticated backup format in the success path. Other
    # restore tests retain legacy-format coverage through the OpenSSL fallback.
    v81_backup = tmp_path / "v81-authenticated-backup.tar.gz.enc"
    crypto_env = os.environ.copy()
    crypto_env["BACKUP_ENCRYPTION_KEY"] = "test-only-fake-key"
    encrypted = subprocess.run([
        "python3", str(ROOT / "scripts/backup_crypto.py"), "encrypt",
        str(backup), str(v81_backup),
    ], env=crypto_env, text=True, capture_output=True, check=False, timeout=30)
    assert encrypted.returncode == 0, encrypted.stdout + encrypted.stderr
    backup = v81_backup
    bindir = _fake_restore_commands(tmp_path)
    restored_dir = tmp_path / "restored-uploads-success"
    restore_work = tmp_path / "restore-work-success"
    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "CONFIRM_DISPOSABLE_RESTORE": "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET",
        "BACKUP_FILE": str(backup),
        "BACKUP_ENCRYPTION_KEY": "test-only-fake-key",
        "RESTORE_DIR": str(restore_work),
        "RESTORE_UPLOAD_DIR": str(restored_dir),
        "RESTORE_DATABASE_URL": "postgresql://fake/empty_test_db",
    })
    result = _run_process_group(["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30)
    assert result.returncode == 0, result.stderr + result.stdout
    assert restored_dir.is_dir()
    assert (restored_dir / source_upload.name).read_bytes() == source_upload.read_bytes()
    assert not restore_work.exists()

    failed_upload_dir = tmp_path / "restored-uploads-failure"
    failed_work = tmp_path / "restore-work-failure"
    env.update({"RESTORE_DIR": str(failed_work), "RESTORE_UPLOAD_DIR": str(failed_upload_dir), "FAKE_PSQL_NONEMPTY": "1"})
    result = _run_process_group(["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30)
    assert result.returncode == 2, result.stderr + result.stdout
    assert not failed_upload_dir.exists()
    assert not failed_work.exists()


def test_stale_upload_leases_and_parts_are_recovered_but_active_leases_survive(tmp_path):
    from app.services.upload_quota import (
        cleanup_stale_upload_artifacts_unlocked,
        managed_upload_bytes,
        reservation_bytes,
    )

    root = tmp_path / "uploads"
    reservation_dir = root / ".quota-reservations"
    reservation_dir.mkdir(parents=True)
    now = 2_000_000_000.0
    stale_id = "stale123"
    stale_reservation = reservation_dir / f"{stale_id}.reserve"
    stale_reservation.write_text("400", encoding="ascii")
    stale_part = root / f".upload-{stale_id}.part"
    stale_part.write_bytes(b"x" * 400)
    os.utime(stale_reservation, (now - 7200, now - 7200))
    os.utime(stale_part, (now - 7200, now - 7200))

    orphan_part = root / ".upload-old-release-part.part"
    orphan_part.write_bytes(b"orphan")
    os.utime(orphan_part, (now - 7200, now - 7200))

    active_id = "active456"
    active_reservation = reservation_dir / f"{active_id}.reserve"
    active_reservation.write_text("500", encoding="ascii")
    os.utime(active_reservation, (now, now))
    active_part = root / f".upload-{active_id}.part"
    active_part.write_bytes(b"y" * 100)
    os.utime(active_part, (now - 7200, now - 7200))
    normal_upload = root / "kept.pdf"
    normal_upload.write_bytes(b"normal")

    removed = cleanup_stale_upload_artifacts_unlocked(root, now=now, stale_after_seconds=3600)
    assert removed >= 2
    assert not stale_reservation.exists()
    assert not stale_part.exists()
    assert not orphan_part.exists()
    assert active_reservation.exists()
    assert active_part.exists()
    assert reservation_bytes(root, now=now) == 500
    assert managed_upload_bytes(root, now=now) == normal_upload.stat().st_size


def test_backup_excludes_transient_quota_state_and_partial_uploads(tmp_path):
    if not all(shutil.which(command) for command in ("tar",)):
        pytest.skip("tar unavailable")
    source = tmp_path / "uploads"
    (source / ".quota-reservations").mkdir(parents=True)
    (source / "real.pdf").write_bytes(b"real")
    (source / ".quota.lock").write_text("", encoding="utf-8")
    (source / ".quota-reservations" / "123.reserve").write_text("100", encoding="ascii")
    (source / ".upload-123.part").write_bytes(b"partial")
    archive_path = tmp_path / "uploads.tar.gz"
    result = subprocess.run([
        "tar", "-C", str(source), "--exclude=./.quota.lock",
        "--exclude=./.quota-reservations", "--exclude=./.upload-*.part",
        "--exclude=*.part", "-czf", str(archive_path), ".",
    ], text=True, capture_output=True, check=False, timeout=30)
    assert result.returncode == 0, result.stderr
    with tarfile.open(archive_path, "r:gz") as archive:
        names = archive.getnames()
    assert any(name.endswith("real.pdf") for name in names)
    assert not any("quota" in name or name.endswith(".part") for name in names)


def test_qr_preflight_and_panel_state_checks_precede_credential_mutation():
    attendance = (ROOT / "app/bot/handlers/attendance.py").read_text(encoding="utf-8")
    handler = attendance.split("async def attendance_qr", 1)[1].split("async def show_checkin_from_message", 1)[0]
    assert handler.index("await c.bot.get_me()") < handler.index("async with SessionLocal()")
    assert handler.index("qrcode.make(link)") < handler.index("async with SessionLocal()")
    assert "event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED)" in handler
    assert "except IntegrityError" in handler
    assert "کد فعلی تغییری نکرد" in handler


def test_storage_snapshot_includes_active_upload_reservations(tmp_path):
    from app.services.upload_quota import upload_storage_usage_bytes

    root = tmp_path / "uploads"
    reservations = root / ".quota-reservations"
    reservations.mkdir(parents=True)
    (root / "already-uploaded.pdf").write_bytes(b"existing-content")
    (root / ".quota.lock").touch()
    lease = reservations / "active.reserve"
    lease.write_text("8192", encoding="ascii")
    # The reservation is current; it should be counted even without counting its
    # in-progress .part file a second time.
    now = 2_000_000_000.0
    os.utime(lease, (now, now))
    (root / ".upload-active.part").write_bytes(b"partial")
    os.utime(root / ".upload-active.part", (now - 7200, now - 7200))

    assert upload_storage_usage_bytes(root, now=now) == len(b"existing-content") + 8192


def test_checkin_choices_are_paginated_and_revalidate_proof_on_each_page():
    attendance = (ROOT / "app/bot/handlers/attendance.py").read_text(encoding="utf-8")
    assert "CHECKIN_PAGE_SIZE = 15" in attendance
    assert "choices[(page - 1) * CHECKIN_PAGE_SIZE:page * CHECKIN_PAGE_SIZE]" in attendance
    assert 'user:checkin:page:' in attendance
    assert "text, markup, error = await _checkin_view(user.id, event_id, proof, proof_kind, page)" in attendance
    # A stale page button must go through the same token/code hash validation and
    # ownership-scoped booking query as the initial QR/code entry.
    view = attendance.split("async def _checkin_view", 1)[1].split("async def _show_checkin", 1)[0]
    assert "checkin_proof_is_valid(event, proof, proof_kind)" in view
    security = (ROOT / "app/services/attendance_security.py").read_text(encoding="utf-8")
    assert "secrets.compare_digest(expected, proof_digest(proof))" in security
    assert "Booking.booked_by_user_id == int(user_id)" in view
    assert "Booking.status == RegistrationStatus.CONFIRMED" in view


def test_dashboard_uses_quota_snapshot_including_active_reservations_off_event_loop():
    dashboard = (ROOT / "app/bot/handlers/admin_features.py").read_text(encoding="utf-8")
    assert "upload_storage_usage_bytes" in dashboard
    assert "await asyncio.to_thread(upload_storage_usage_bytes, root)" in dashboard
    assert "for path in root.rglob" not in dashboard


@pytest.mark.skipif(not all(shutil.which(command) for command in ("sh", "tar", "sha256sum")), reason="shell archive tools unavailable")
def test_restore_rejects_checksum_tampering_before_database_restore(tmp_path):
    backup, _ = _build_fake_encrypted_backup(tmp_path)
    bindir = _fake_restore_commands(tmp_path)
    with tarfile.open(backup, "r:gz") as archive:
        payloads = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    payloads["database.dump"] = b"tampered dump whose digest does not match the manifest"
    corrupted_plaintext = tmp_path / "checksum-mismatch.tar.gz"
    with tarfile.open(corrupted_plaintext, "w:gz") as archive:
        for name, contents in payloads.items():
            member = tarfile.TarInfo(name)
            member.size = len(contents)
            member.mode = 0o600
            archive.addfile(member, __import__("io").BytesIO(contents))
    # Mocked OpenSSL restores this fixture; the input has the framing of an old
    # salted AES-CBC file and is only used to test post-decryption checksums.
    corrupted = tmp_path / "checksum-mismatch.tar.gz.enc"
    corrupted.write_bytes(b"Salted__" + b"12345678" + b"X" * 16)

    restore_work = tmp_path / "restore-work-tampered"
    restored_dir = tmp_path / "restored-uploads-tampered"
    marker = tmp_path / "pg_restore_was_called.txt"
    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "CONFIRM_DISPOSABLE_RESTORE": "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET",
        "BACKUP_FILE": str(corrupted),
        "BACKUP_ENCRYPTION_KEY": "test-only-fake-key",
        "RESTORE_ALLOW_LEGACY_CBC": "YES_I_UNDERSTAND_LEGACY_CBC_IS_UNAUTHENTICATED",
        "OPENSSL_DECRYPT_FIXTURE": str(corrupted_plaintext),
        "RESTORE_DIR": str(restore_work),
        "RESTORE_UPLOAD_DIR": str(restored_dir),
        "RESTORE_DATABASE_URL": "postgresql://fake/empty_test_db",
        "PG_RESTORE_MARKER": str(marker),
    })
    result = _run_process_group(["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30)
    assert result.returncode != 0
    assert "FAILED" in result.stdout or "failed" in result.stdout.lower()
    assert not marker.exists(), "pg_restore must not run when the backup checksum manifest fails"
    assert not restored_dir.exists()
    assert not restore_work.exists()


def test_backup_serializes_runs_and_removes_abandoned_plaintext_work_after_lock():
    backup = (ROOT / "scripts/backup.sh").read_text(encoding="utf-8")
    assert 'exec 9>"$BACKUP_DIR/.backup.lock"' in backup
    assert "flock -n 9" in backup
    lock_pos = backup.index("flock -n 9")
    cleanup_pos = backup.index("-name '.tmp-*'")
    work_pos = backup.index('WORK=$(mktemp -d')
    assert lock_pos < cleanup_pos < work_pos
    assert "-name '.panel-flow-*.tmp' -delete" in backup
    assert "-name '.backup-crypto-*' -delete" in backup
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "util-linux" in dockerfile


def test_backup_script_with_mocked_database_and_crypto_reclaims_abandoned_plaintext(tmp_path):
    if not all(shutil.which(command) for command in ("sh", "tar", "sha256sum", "flock", "find", "python3")):
        pytest.skip("required backup shell tools unavailable")
    bindir = tmp_path / "mock-bin"
    bindir.mkdir()
    (bindir / "pg_dump").write_text(
        "#!/bin/sh\nset -eu\n[ \"${PGPASSWORD:-}\" = 'test-postgres-password' ] || exit 23\nout=\n"
        "while [ $# -gt 0 ]; do case \"$1\" in -f) out=$2; shift 2;; *) shift;; esac; done\n"
        "[ -n \"$out\" ] || exit 24\nsleep \"${PG_DUMP_SLEEP:-0}\"\nprintf 'mock pg dump with data' > \"$out\"\n",
        encoding="utf-8",
    )
    (bindir / "openssl").write_text(
        "#!/bin/sh\nset -eu\nin=\nout=\nwhile [ $# -gt 0 ]; do "
        "case \"$1\" in -in) in=$2; shift 2;; -out) out=$2; shift 2;; *) shift;; esac; done\n"
        "[ -n \"$in\" ] && [ -n \"$out\" ]\ncp \"$in\" \"$out\"\n",
        encoding="utf-8",
    )
    for script in bindir.iterdir():
        script.chmod(0o755)

    backups = tmp_path / "backups"
    uploads = tmp_path / "uploads"
    backups.mkdir()
    uploads.mkdir()
    stale_work = backups / ".tmp-abandoned-after-kill"
    stale_work.mkdir()
    (stale_work / "database.dump").write_text("sensitive unencrypted dump", encoding="utf-8")
    stale_encrypted_temp = backups / ".panel-flow-old.tar.gz.enc.tmp"
    stale_encrypted_temp.write_text("partial archive", encoding="utf-8")
    stale_crypto_temp = backups / ".backup-crypto-old"
    stale_crypto_temp.write_text("partial encrypted output", encoding="utf-8")
    (uploads / "questions.pdf").write_bytes(b"real user file")
    (uploads / ".quota.lock").write_text("", encoding="utf-8")
    (uploads / ".quota-reservations").mkdir()
    (uploads / ".quota-reservations" / "active.reserve").write_text("100", encoding="ascii")
    (uploads / ".upload-active.part").write_bytes(b"partial")

    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "POSTGRES_PASSWORD": "test-postgres-password",
        "POSTGRES_USER": "panel_flow_test",
        "POSTGRES_DB": "panel_flow_test",
        "BACKUP_ENCRYPTION_KEY": "test-only-fake-key",
        "BACKUP_DIR": str(backups),
        "UPLOAD_DIR": str(uploads),
        "BACKUP_RETENTION_DAILY": "7",
        "BACKUP_RETENTION_WEEKLY": "4",
        "BACKUP_RETENTION_MONTHLY": "12",
    })
    import time
    env["PG_DUMP_SLEEP"] = "1"
    first = subprocess.Popen(["sh", str(ROOT / "scripts/backup.sh")], env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    active_workdirs = []
    for _ in range(500):
        active_workdirs = [path for path in backups.glob(".tmp-*") if path != stale_work]
        if active_workdirs and not stale_work.exists() and not stale_encrypted_temp.exists() and not stale_crypto_temp.exists():
            break
        if first.poll() is not None:
            break
        time.sleep(0.01)
    assert active_workdirs, "first backup should reach its protected working phase"
    second = _run_process_group(["sh", str(ROOT / "scripts/backup.sh")], env=env, timeout=30)
    assert second.returncode == 0, second.stderr + second.stdout
    assert "backup_skipped" in second.stderr
    assert active_workdirs[0].exists(), "a competing backup must not delete the active process's plaintext work files"
    try:
        first_stdout, first_stderr = first.communicate(timeout=15)
    except subprocess.TimeoutExpired:
        # The shell launches helpers (including Python crypto subprocesses) that
        # may inherit the captured pipes. Kill the entire isolated process group,
        # not only the shell, or communicate() can block forever waiting for EOF.
        try:
            os.killpg(first.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            first.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            first.kill()
            first.communicate(timeout=5)
        raise
    assert first.returncode == 0, first_stderr + first_stdout
    assert "backup_success" in first_stdout
    assert not stale_work.exists() and not stale_encrypted_temp.exists() and not stale_crypto_temp.exists()
    archives = list(backups.glob("panel-flow-*.tar.gz.enc"))
    assert len(archives) == 1
    decrypted_archive = tmp_path / "verified-backup.tar.gz"
    decrypt_result = subprocess.run([
        "python3", str(ROOT / "scripts/backup_crypto.py"), "decrypt",
        str(archives[0]), str(decrypted_archive),
    ], env=env, text=True, capture_output=True, check=False, timeout=30)
    assert decrypt_result.returncode == 0, decrypt_result.stdout + decrypt_result.stderr
    with tarfile.open(decrypted_archive, "r:gz") as archive:
        outer = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    assert outer["MANIFEST.txt"].decode("utf-8").find("release=V97") >= 0
    assert "database.dump" in outer and "uploads.tar.gz" in outer and "SHA256SUMS" in outer
    with tarfile.open(fileobj=__import__("io").BytesIO(outer["uploads.tar.gz"]), mode="r:gz") as archive:
        names = archive.getnames()
    assert any(name.endswith("questions.pdf") for name in names)
    assert not any("quota" in name or name.endswith(".part") for name in names)


@pytest.mark.skipif(not all(shutil.which(command) for command in ("sh", "python3")), reason="shell/Python tools unavailable")
def test_restore_refuses_overlapping_work_and_upload_directories(tmp_path):
    backup, _ = _build_fake_encrypted_backup(tmp_path)
    bindir = _fake_restore_commands(tmp_path)
    restore_work = tmp_path / "new-restore-root"
    restored_nested = restore_work / "uploads"
    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "CONFIRM_DISPOSABLE_RESTORE": "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET",
        "BACKUP_FILE": str(backup),
        "BACKUP_ENCRYPTION_KEY": "test-only-fake-key",
        "RESTORE_DIR": str(restore_work),
        "RESTORE_UPLOAD_DIR": str(restored_nested),
        "RESTORE_DATABASE_URL": "postgresql://fake/empty_test_db",
    })
    result = _run_process_group(["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30)
    assert result.returncode == 2
    assert "separate, non-overlapping paths" in result.stderr
    assert not restore_work.exists()
