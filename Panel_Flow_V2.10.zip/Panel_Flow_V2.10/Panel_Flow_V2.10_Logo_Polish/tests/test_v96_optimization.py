from __future__ import annotations

import asyncio
from pathlib import Path

from sqlalchemy import create_engine

ROOT = Path(__file__).resolve().parents[1]


def test_bot_settings_and_seed_use_one_batched_query(monkeypatch):
    from app.services import app_settings as service
    from app.db.models import AppSetting

    backing = {
        "community_group_url": AppSetting(key="community_group_url", value="https://t.me/group"),
        "payment_card_number": AppSetting(key="payment_card_number", value="1234567812345670"),
    }
    monkeypatch.setattr(service, "_bot_setting_default", lambda key: f"fallback:{key}")

    async def scenario():
        session = service_test_session(backing)
        await service.seed_bot_settings(session)
        assert session.query_count == 1
        assert session.commit_count == 1
        session.query_count = 0

        values = await service.get_bot_settings(session)
        assert session.query_count == 1
        assert values["community_group_url"] == "https://t.me/group"
        assert values["community_channel_url"] == "fallback:community_channel_url"
        assert values["payment_card_number"] == "1234567812345670"

    asyncio.run(scenario())


def test_channel_update_configuration_is_loaded_in_one_query():
    from app.services.app_settings import get_channel_updates_config
    from app.db.models import AppSetting

    backing = {
        "channel_updates_enabled": AppSetting(key="channel_updates_enabled", value="true"),
        "channel_update_threshold": AppSetting(key="channel_update_threshold", value="5"),
    }

    async def scenario():
        session = service_test_session(backing)
        assert await get_channel_updates_config(session) == (True, 5)
        assert session.query_count == 1

    asyncio.run(scenario())


def service_test_session(backing):
    """In-memory async-shaped adapter that counts logical SQL executions."""
    from app.db.models import AppSetting

    class Result:
        def __init__(self, rows):
            self.rows = rows

        def scalars(self):
            return self

        def all(self):
            return self.rows

        def scalar_one_or_none(self):
            return self.rows[0] if self.rows else None

    class Session:
        def __init__(self):
            self.query_count = 0
            self.commit_count = 0

        async def execute(self, statement):
            self.query_count += 1
            criterion = statement.whereclause
            value = criterion.right.value
            if isinstance(value, (tuple, list, set)):
                return Result([backing[key] for key in value if key in backing])
            row = backing.get(value)
            return Result([row] if row is not None else [])

        def add(self, row):
            backing[row.key] = row

        async def commit(self):
            self.commit_count += 1

    return Session()


def test_referral_count_uses_one_query_and_preserves_missing_referrer_behavior():
    from test_v55_referrals import _AsyncSessionAdapter, _create_users
    from app.services.referrals import count_referrals_for_telegram_id

    engine = create_engine("sqlite:///:memory:")
    session, referrer, invitee = _create_users(engine)

    class CountingAdapter(_AsyncSessionAdapter):
        def __init__(self, db_session):
            super().__init__(db_session)
            self.query_count = 0

        async def execute(self, statement):
            self.query_count += 1
            return await super().execute(statement)

    try:
        invitee.referred_by_user_id = referrer.id
        session.commit()
        adapter = CountingAdapter(session)
        assert asyncio.run(count_referrals_for_telegram_id(adapter, referrer.telegram_id)) == 1
        assert adapter.query_count == 1
        adapter.query_count = 0
        assert asyncio.run(count_referrals_for_telegram_id(adapter, 998877665)) == 0
        assert adapter.query_count == 1
    finally:
        session.close()
        engine.dispose()


def test_compose_forwards_fsm_ttl_to_bot_container_and_documents_support_username():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    env_example = (ROOT / ".env.example").read_text(encoding="utf-8")
    bot_environment = compose.split("  bot:\n", 1)[1].split("  api:\n", 1)[0]
    assert "FSM_STORAGE_TTL_SECONDS: ${FSM_STORAGE_TTL_SECONDS:-604800}" in bot_environment
    assert "SUPPORT_USERNAME=PanelFlowAdmin" in env_example


def test_production_requirements_are_directly_pinned_within_supported_ranges():
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines()
    active = [line.strip() for line in requirements if line.strip() and not line.lstrip().startswith("#")]
    assert len(active) == 11
    assert all(">=" in line and "<" in line for line in active)
    # Pillow is used server-side to validate, strip metadata, resize and WebP-compress public images.
    assert any(line.lower().startswith("pillow>=10.4,<13") for line in active)



def test_xp_economy_report_uses_one_query_without_multiplying_ledger_totals():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session
    from app.db.models import Base, RewardIssue, ShopRequest, XPAward
    from app.services.xp_shop import xp_economy_totals

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)

    class CountingAdapter:
        def __init__(self, sync_session):
            self.session = sync_session
            self.query_count = 0

        async def execute(self, statement):
            self.query_count += 1
            return self.session.execute(statement)

    session = Session(engine)
    try:
        session.add_all([
            XPAward(telegram_id=1, points=20, award_type="challenge", award_key="earned"),
            XPAward(telegram_id=1, points=-10, award_type="shop_redemption", award_key="spent"),
            XPAward(telegram_id=1, points=10, award_type="shop_redemption_refund", award_key="refund"),
            XPAward(telegram_id=1, points=5, award_type="admin_manual_adjustment", award_key="adjustment"),
            ShopRequest(telegram_id=1, discount_percent=20, xp_cost=30, status="pending"),
            RewardIssue(source_type="shop", source_id=1, telegram_id=1, discount_percent=20, status="awaiting_code"),
            RewardIssue(source_type="shop", source_id=2, telegram_id=2, discount_percent=50, status="delivered"),
            RewardIssue(source_type="shop", source_id=3, telegram_id=3, discount_percent=25, status="refunded"),
        ])
        session.commit()
        adapter = CountingAdapter(session)
        result = asyncio.run(xp_economy_totals(adapter))
        assert adapter.query_count == 1
        assert result == {
            "total_earned": 20,
            "total_spent": 10,
            "manual_adjustments": 5,
            "net_xp": 25,
            "reserved_xp": 30,
            "pending_requests": 1,
            "approved_rewards": 2,
            "delivered_rewards": 1,
            "refunded_xp": 10,
        }
    finally:
        session.close()
        engine.dispose()


def test_env_example_covers_application_settings_without_exposing_secrets():
    from app.config import Settings

    example = (ROOT / ".env.example").read_text(encoding="utf-8")
    active_names = {
        line.split("=", 1)[0].strip()
        for line in example.splitlines()
        if line.strip() and not line.lstrip().startswith("#") and "=" in line
    }
    documented_names = {
        line.lstrip()[2:].split("=", 1)[0].strip()
        for line in example.splitlines()
        if line.lstrip().startswith("# ") and "=" in line
    }
    covered = active_names | documented_names
    model_names = {name.upper() for name in Settings.model_fields}
    assert model_names - covered == set()
    assert "BOT_TOKEN=" in example and "POSTGRES_PASSWORD=" in example
    assert "API_TOKEN_SECRET=" in example and "BACKUP_ENCRYPTION_KEY=" in example
    assert not any(token in example for token in ("123456:ABC", "sk-live-", "ghp_"))
