from __future__ import annotations

import asyncio
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.models import (
    Base, DiscountCode, DiscountCodeEvent, DiscountRedemption, Event,
    EventStatus, User, UserRole,
)
from app.display_utils import volume_label
from app.services.discounts import reactivate_inactive_discount_code
from app.bot.validation import normalize_volume_label

ROOT = Path(__file__).resolve().parents[1]


class AsyncSessionAdapter:
    def __init__(self, sync: Session):
        self.sync = sync

    async def execute(self, statement):
        return self.sync.execute(statement)

    async def get(self, model, ident, **kwargs):
        return self.sync.get(model, ident)

    def add(self, obj):
        self.sync.add(obj)

    async def commit(self):
        self.sync.commit()


@pytest.fixture

def db_session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    sync = Session(engine)
    adapter = AsyncSessionAdapter(sync)
    try:
        yield adapter, sync
    finally:
        sync.close()
        engine.dispose()


def _seed_panel(sync: Session, title: str) -> Event:
    event = Event(
        volume="Movie Night", title=title,
        event_day_label="Saturday", event_date_label="12 October 2026",
        start_time_label="18:00", end_time_label="20:00", venue="Test Venue",
        capacity=20, price_per_person=Decimal("100000"), status=EventStatus.PUBLISHED,
        registration_open=True, archived=False,
    )
    sync.add(event)
    sync.flush()
    return event


def test_named_volume_accepts_single_digit_numbers_but_rejects_slash_commands():
    assert normalize_volume_label("21") == "21"
    for number in range(1, 10):
        assert normalize_volume_label(str(number)) == str(number)
    assert normalize_volume_label("0") is None
    assert normalize_volume_label("Movie Night") == "Movie Night"
    assert normalize_volume_label("  By   Nature ") == "By Nature"
    for bad in ("/admin", "/cancel", "/start", "Movie/@", "فیلم", "Movie!", "https://x.com"):
        assert normalize_volume_label(bad) is None
    assert volume_label("21") == "V21"
    assert volume_label("Movie Night") == "Volume Movie Night"


def test_inactive_discount_code_can_be_reconfigured_and_reactivated(db_session):
    adapter, sync = db_session
    first = _seed_panel(sync, "Old Panel")
    second = _seed_panel(sync, "Upcoming Panel")
    code = DiscountCode(
        code="PANEL20", label="PANEL20", kind="public", discount_type="percent",
        discount_value=Decimal("20"), requires_approval=False, active=False,
        max_redemptions=5, usage_policy="once_total", created_by_telegram_id=100,
        created_at=datetime(2026, 1, 1), disabled_at=datetime(2026, 2, 1),
        disabled_reason="No eligible panels remain",
    )
    sync.add(code)
    sync.flush()
    sync.add(DiscountCodeEvent(discount_code_id=code.id, event_id=first.id))
    sync.commit()

    updated, events = asyncio.run(reactivate_inactive_discount_code(
        adapter, code_id=code.id, event_ids=[second.id], max_redemptions=10,
        usage_policy="once_per_panel",
    ))

    sync.refresh(updated)
    links = sync.execute(select(DiscountCodeEvent).where(DiscountCodeEvent.discount_code_id == code.id)).scalars().all()
    assert updated.active is True
    assert updated.disabled_at is None
    assert updated.disabled_reason is None
    assert updated.max_redemptions == 10
    assert updated.usage_policy == "once_per_panel"
    assert [e.id for e in events] == [second.id]
    assert [link.event_id for link in links] == [second.id]


def test_inactive_discount_code_cannot_be_given_a_cap_below_existing_uses(db_session):
    adapter, sync = db_session
    event = _seed_panel(sync, "Used Panel")
    user = User(telegram_id=991102, display_name="Test User", role=UserRole.PARTICIPANT)
    sync.add(user)
    sync.flush()
    code = DiscountCode(
        code="PANEL20", label="PANEL20", kind="public", discount_type="percent",
        discount_value=Decimal("20"), requires_approval=False, active=False,
        max_redemptions=5, usage_policy="once_total", created_by_telegram_id=100,
    )
    sync.add(code)
    sync.flush()
    sync.add(DiscountCodeEvent(discount_code_id=code.id, event_id=event.id))
    sync.add(DiscountRedemption(
        discount_code_id=code.id, code_snapshot=code.code, event_id=event.id,
        event_label_snapshot="Volume Movie Night — Used Panel", user_telegram_id=user.telegram_id,
        status="redeemed", participant_count=1, original_total=Decimal("100000"),
        discount_amount=Decimal("20000"), final_total=Decimal("80000"),
    ))
    sync.add(DiscountRedemption(
        discount_code_id=code.id, code_snapshot=code.code, event_id=event.id,
        event_label_snapshot="Volume Movie Night — Used Panel", user_telegram_id=991103,
        status="approved", participant_count=1, original_total=Decimal("100000"),
        discount_amount=Decimal("20000"), final_total=Decimal("80000"),
    ))
    sync.commit()

    with pytest.raises(ValueError, match="LIMIT_BELOW_USAGE"):
        asyncio.run(reactivate_inactive_discount_code(
            adapter, code_id=code.id, event_ids=[event.id], max_redemptions=1,
            usage_policy="once_total",
        ))
    sync.refresh(code)
    assert code.active is False


def test_v32_admin_ui_and_handler_regressions_are_wired():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    model = (ROOT / "app/db/models.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations/014_v32_volume_labels_and_discount_notifications.sql").read_text(encoding="utf-8")

    menu = keyboard.split("def admin_menu(", 1)[1].split("def admin_content_hub_keyboard", 1)[0]
    content_menu = keyboard.split("def admin_content_hub_keyboard(", 1)[1].split("def admin_reports_hub_keyboard", 1)[0]
    settings_menu = keyboard.split("def admin_settings_hub_keyboard(", 1)[1].split("def admin_settings_cancel_keyboard", 1)[0]
    assert 'callback_data="admin:content:hub"' in menu
    assert 'callback_data="admin:settings:hub"' in menu
    console = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    announcement_menu = console.split("def _announcement_main_keyboard", 1)[1].split("def _panel_announcement_keyboard", 1)[0]
    assert 'text="📢 به‌روزرسانی‌های کانال"' in announcement_menu
    assert 'callback_data="admin:channel_updates"' in announcement_menu
    assert "به‌روزرسانی‌های کانال" not in content_menu
    assert 'text="❓ سؤالات پیشنهادی"' in content_menu
    assert 'callback_data="admin:console:roles"' in settings_menu and 'callback_data="admin:users:manage"' in settings_menu
    event_menu = keyboard.split("def admin_event_menu(", 1)[1].split("def final_panel_state_keyboard", 1)[0]
    reminder_row = event_menu.split('text="📢 اطلاع‌رسانی"', 1)[1].split(']', 1)[0]
    assert 'text="🔔 یادآوری دستی"' in reminder_row

    assert 'panel_detail_line("زمان", panel_time, icon="⏰")' in admin
    assert "discount_code_snapshot" in admin and "کد تخفیف اعمال‌شده" in admin
    assert 'tg://user?id={int(redemption.user_telegram_id)}' in admin
    assert 'F.data.regexp(r"^admin:discount:edit:\\d+$")' in admin
    assert "reactivate_inactive_discount_code" in admin
    assert "تعداد استفاده‌ها/درخواست‌های قبلی" in admin
    assert "await c.bot.edit_message_text(" in admin and "ادامه ثبت‌نام و پرداخت با تخفیف" in admin
    assert "cancel_booking(session, user.id, booking_id)" in user
    assert "Participant" in admin.split("async def event_delete_confirm", 1)[0]
    assert "request_message_id" in model and "request_message_id" in migration


def test_v32_permanent_deletion_and_public_code_edit_are_documented():
    # Keep the release documentation in one canonical place (README.md); the
    # former duplicate PATCH_NOTES.md file was removed from the lean package.
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "inactive" in readme.lower() or "غیرفعال" in readme
    assert "014_v32_volume_labels_and_discount_notifications.sql" in readme or "migration 014" in readme.lower()
