from __future__ import annotations

import base64
import json
from pathlib import Path
from urllib.parse import urlencode

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

import pytest
from pydantic import ValidationError

from app.config import Settings
from app.http_api.security import (
    InvalidAccessToken,
    InvalidTelegramInitData,
    issue_access_token,
    validate_telegram_init_data,
    verify_access_token,
)

ROOT = Path(__file__).resolve().parents[1]


def build_init_data(*, bot_id: int = 123456, telegram_id: int = 7654321, auth_date: int = 1_800_000_000, extra=None):
    private_key = Ed25519PrivateKey.generate()
    params = {
        "auth_date": str(auth_date),
        "query_id": "AAEAAE-test-query",
        "user": json.dumps({"id": telegram_id, "first_name": "Test"}, separators=(",", ":")),
    }
    params.update(extra or {})
    data_check_string = f"{bot_id}:WebAppData\n" + "\n".join(
        f"{key}={value}" for key, value in sorted(params.items())
    )
    signature = private_key.sign(data_check_string.encode("utf-8"))
    params["hash"] = "a" * 64  # Hash is not the trust anchor for third-party validation.
    params["signature"] = base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii")
    public_key = private_key.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw
    ).hex()
    return urlencode(params), public_key, bot_id


def test_telegram_init_data_ed25519_signature_is_checked_and_identity_extracted():
    raw, public_key, bot_id = build_init_data(auth_date=1_800_000_000)
    identity = validate_telegram_init_data(
        raw, bot_id=bot_id, public_key_hex=public_key, now=1_800_000_100
    )
    assert identity.telegram_id == 7654321
    assert identity.auth_date == 1_800_000_000
    assert identity.user_data["first_name"] == "Test"


def test_telegram_init_data_rejects_modified_values_and_expired_payloads():
    raw, public_key, bot_id = build_init_data(auth_date=1_800_000_000)
    tampered = raw.replace("first_name%22%3A%22Test", "first_name%22%3A%22Evil")
    with pytest.raises(InvalidTelegramInitData, match="signature verification failed"):
        validate_telegram_init_data(tampered, bot_id=bot_id, public_key_hex=public_key, now=1_800_000_100)
    with pytest.raises(InvalidTelegramInitData, match="expired"):
        validate_telegram_init_data(raw, bot_id=bot_id, public_key_hex=public_key, max_age_seconds=60, now=1_800_001_000)


def test_telegram_init_data_rejects_duplicate_keys_and_future_timestamps():
    raw, public_key, bot_id = build_init_data(auth_date=1_800_000_000)
    with pytest.raises(InvalidTelegramInitData, match="duplicate"):
        validate_telegram_init_data(raw + "&auth_date=1800000000", bot_id=bot_id, public_key_hex=public_key, now=1_800_000_100)
    future, future_key, future_bot_id = build_init_data(auth_date=1_800_001_000)
    with pytest.raises(InvalidTelegramInitData, match="future"):
        validate_telegram_init_data(future, bot_id=future_bot_id, public_key_hex=future_key, now=1_800_000_100, future_tolerance_seconds=60)


def test_access_token_round_trip_and_tamper_or_expiry_are_rejected():
    secret = "s" * 48
    token, ttl = issue_access_token(user_id=7, telegram_id=123456, secret=secret, ttl_seconds=600, now=1_800_000_000)
    claims = verify_access_token(token, secret=secret, now=1_800_000_100)
    assert ttl == 600
    assert claims["sub"] == 7 and claims["tg"] == 123456
    body, signature = token.split(".")
    tampered = body[:-1] + ("A" if body[-1] != "A" else "B") + "." + signature
    with pytest.raises(InvalidAccessToken):
        verify_access_token(tampered, secret=secret, now=1_800_000_100)
    with pytest.raises(InvalidAccessToken, match="expired"):
        verify_access_token(token, secret=secret, now=1_800_000_601)


def test_api_settings_restrict_cors_and_bound_token_lifetime():
    configured = Settings(_env_file=None, api_cors_origins="https://example.com, http://localhost:3000", api_token_ttl_seconds=900)
    assert configured.api_cors_origin_list == ["https://example.com", "http://localhost:3000"]
    assert configured.api_token_ttl_seconds == 900
    with pytest.raises(ValidationError):
        Settings(_env_file=None, api_cors_origins="*")
    with pytest.raises(ValidationError):
        Settings(_env_file=None, api_cors_origins="https://example.com/app")
    with pytest.raises(ValidationError):
        Settings(_env_file=None, api_token_ttl_seconds=20)


def test_versioned_api_exposes_public_events_and_authenticated_self_routes():
    from app.api import api

    paths = api.openapi()["paths"]
    assert "/api/v1/events" in paths
    assert "/api/v1/auth/telegram" in paths
    assert "/api/v1/me" in paths
    assert "/api/v1/me/bookings" in paths
    assert any(route.path == "/events" and "GET" in route.methods for route in api.routes)  # Backwards compatibility retained but hidden from new-client OpenAPI docs.


def test_receipt_cancel_button_is_secondary_and_enters_confirmation_flow():
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    receipt = keyboards.split("def receipt_upload_keyboard", 1)[1].split("def community_keyboard", 1)[0]
    assert 'text="کپی شماره کارت"' in receipt
    assert 'text="❌ لغو پرداخت"' not in receipt
    assert "def receipt_cancel_reply_keyboard" in keyboards
    assert 'KeyboardButton(text="❌ لغو ارسال رسید")' in keyboards
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert '@router.message(BookingStates.waiting_receipt, F.text == "❌ لغو ارسال رسید")' in user
    assert 'user:payment:cancel_confirm:' in user and 'user:payment:cancel_back:' in user
    assert "انصراف و آزادکردن صندلی" not in keyboards


def test_booking_read_route_is_scoped_to_authenticated_database_user():
    routes = (ROOT / "app/http_api/routes.py").read_text(encoding="utf-8")
    assert 'base_filter = Booking.booked_by_user_id == int(user.id)' in routes
    assert '.where(base_filter)' in routes
    assert 'selectinload(Booking.event)' in routes
    assert 'receipt_file_path' not in routes and 'receipt_content' not in routes


def test_current_docs_describe_single_installation_and_shared_backend_not_multicity():
    readme = (Path(__file__).resolve().parents[1] / "README.md").read_text(encoding="utf-8")
    assert "single installation" in readme.lower() or "one installation" in readme.lower()
    assert "shared backend" in readme.lower() or "shared database" in readme.lower()
    assert "multi-city" not in readme.lower()

def test_authenticated_profile_route_requires_bearer_and_returns_only_resolved_user(monkeypatch):
    from datetime import datetime

    from fastapi.testclient import TestClient

    from app.api import api
    from app.config import settings
    from app.db.models import User, UserRole
    from app.db.session import get_session

    secret = "profile-route-test-secret-" + ("x" * 32)
    monkeypatch.setattr(settings, "api_token_secret", secret)
    user = User(
        id=12,
        telegram_id=134679,
        display_name="Known User",
        first_name="Known",
        last_name="User",
        telegram_username="known_user",
        phone_number="+989121234567",
        role=UserRole.PARTICIPANT,
        created_at=datetime(2025, 1, 2, 3, 4, 5),
    )

    class Result:
        def scalar_one_or_none(self):
            return user

    class FakeSession:
        async def execute(self, statement):
            return Result()

    async def fake_get_session():
        yield FakeSession()

    import app.http_api.dependencies as api_dependencies
    restriction = {"active": False}

    async def fake_active_account_restriction(telegram_id: int) -> bool:
        assert telegram_id == user.telegram_id
        return restriction["active"]

    monkeypatch.setattr(api_dependencies, "active_account_restriction", fake_active_account_restriction)
    previous_overrides = dict(api.dependency_overrides)
    api.dependency_overrides[get_session] = fake_get_session
    try:
        client = TestClient(api)
        missing = client.get("/api/v1/me")
        assert missing.status_code == 401
        access_token, _ = issue_access_token(
            user_id=user.id, telegram_id=user.telegram_id, secret=secret
        )
        response = client.get("/api/v1/me", headers={"Authorization": f"Bearer {access_token}"})
        assert response.status_code == 200
        body = response.json()
        assert body["id"] == 12
        assert body["display_name"] == "Known User"
        assert body["phone_number"] == "+989121234567"
        assert "receipt_file_path" not in body
        # Tokens issued before a block/suspension no longer bypass live access checks.
        restriction["active"] = True
        blocked = client.get("/api/v1/me", headers={"Authorization": f"Bearer {access_token}"})
        assert blocked.status_code == 403
        assert blocked.json()["detail"]["code"] == "ACCOUNT_RESTRICTED"
    finally:
        api.dependency_overrides.clear()
        api.dependency_overrides.update(previous_overrides)
