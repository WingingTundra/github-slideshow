from __future__ import annotations

import ast
from pathlib import Path

from app.bot.content import user_help_text
from app.display_utils import panel_detail_line

ROOT = Path(__file__).resolve().parents[1]


def _source(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def _function(source: str, name: str) -> str:
    tree = ast.parse(source)
    node = next(
        item for item in tree.body
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name
    )
    return ast.get_source_segment(source, node) or ""


def test_help_menu_is_short_and_contains_each_main_destination():
    text = user_help_text()
    assert len(text) < 4096
    for label in (
        "پنل‌های پیش‌رو", "ثبت‌نام‌های من", "پروفایل من", "سؤالات پنل‌ها",
        "ثبت نظر", "پیشنهادها", "جامعه و دربارهٔ ما", "لیدربورد",
        "چالش‌ها", "XP", "Giveaways", "پاسپورت من", "پشتیبانی انسانی",
    ):
        assert label in text
    assert "برای لغو ارسال رسید، از دکمهٔ پایین استفاده کنید" not in text
    assert "اطلاعات قبلی حفظ شده‌اند" not in text


def test_suggestions_menu_has_two_full_width_actions_and_back():
    keys = _source("app/bot/keyboards.py")
    fn = _function(keys, "suggestions_keyboard")
    assert fn.index('text="💡 پیشنهاد موضوع و رأی‌گیری"') < fn.index('text="❓ پیشنهاد سؤال"')
    assert fn.index('text="❓ پیشنهاد سؤال"') < fn.index('text="🔙 بازگشت"')
    assert fn.count("InlineKeyboardButton(text=") == 3
    assert 'callback_data="user:topics"' in fn
    assert 'callback_data="user:submit_question"' in fn
    assert "پیشنهاد موضوع جدید" not in fn


def test_xp_shop_label_uses_persian_shop_and_rtl_isolation():
    keys = _source("app/bot/keyboards.py")
    fn = _function(keys, "community_menu_keyboard")
    assert r'\u2067🛍 ⁦XP⁩ شاپ\u2069' in fn
    assert r'\u2067🎁 ⁦Giveaways⁩\u2069' in fn
    community = _source("app/bot/handlers/community.py")
    assert "rtl_isolate(\"🏆 <b>لیدربورد و چالش‌ها</b>\")" in community
    assert 'ltr_isolate("Panel Flow")' in community


def test_panel_detail_line_is_rtl_with_a_separately_isolated_value():
    line = panel_detail_line("زبان پنل", "English", icon="🌐")
    assert line.startswith("\u2067") and line.endswith("\u2069")
    assert "\u2068English\u2069" in line
    assert "زبان پنل" in line
    for relative in (
        "app/bot/handlers/user.py", "app/bot/handlers/admin.py",
        "app/bot/handlers/admin_console.py", "app/bot/handlers/v77_features.py",
        "app/services/admin_panel_display.py",
    ):
        assert "panel_detail_line" in _source(relative)


def test_receipt_prompt_has_booking_scoped_inline_cancel_without_extra_instruction():
    keys = _source("app/bot/keyboards.py")
    keyboard = _function(keys, "receipt_upload_keyboard")
    assert 'callback_data=f"user:payment:cancel_receipt:{int(booking_id)}"' in keyboard
    assert "کپی شماره کارت" in keyboard
    assert "receipt_cancel_reply_keyboard()" not in keyboard
    user = _source("app/bot/handlers/user.py")
    assert "برای لغو ارسال رسید، از دکمهٔ پایین استفاده کنید" not in user
    assert "_show_receipt_cancel_reply_button" not in user
    assert "user:payment:cancel_receipt:" in user
    assert "edit_existing=True" in _function(user, "cancel_receipt_button")


def test_single_receipt_review_hides_navigation_and_rejects_stale_navigation():
    keys = _source("app/bot/keyboards.py")
    keyboard = _function(keys, "payment_review_keyboard")
    assert "if can_navigate:" in keyboard
    assert 'callback_data=f"admin:payment:prev:' in keyboard
    admin = _source("app/bot/handlers/admin.py")
    show = _function(admin, "_show_payment")
    assert "receipt_count" in show and "can_navigate = int(receipt_count) > 1" in show
    assert "این تنها رسید موجود برای بررسی است" in show
    navigate = _function(admin, "navigate_payment_receipt")
    assert "if len(rows) <= 1:" in navigate
    assert "این تنها رسید موجود است؛ رسید دیگری برای نمایش وجود ندارد." in navigate


def test_cancel_and_start_show_single_discard_prompt_for_ordinary_active_flows():
    user = _source("app/bot/handlers/user.py")
    helper = _function(user, "_show_navigation_discard_prompt")
    assert "یک فرایند ناتمام دارید. ادامه می‌دهید یا آن را لغو می‌کنید؟" in helper
    assert 'callback_data="navigation:discard:continue"' in helper
    assert 'callback_data="navigation:discard:confirm"' in helper
    cancel = _function(user, "cancel_interaction")
    assert "_show_navigation_discard_prompt(message, state, current_state)" in cancel
    start = _function(user, "start")
    assert "_show_navigation_discard_prompt(message, state, prior_state)" in start
    assert "برای ادامه به آخرین پیام ربات برگردید" not in start


def test_additional_signup_summary_is_sent_after_new_participant_name():
    user = _source("app/bot/handlers/user.py")
    append = _function(user, "_append_current_non_booker_and_continue")
    assert "await show_booking_summary(message, state, new_message=True)" in append
    summary = _function(user, "show_booking_summary")
    assert "new_message: bool = False" in summary
    assert "new_message=new_message" in summary
    render = _function(user, "_render_booking_prompt")
    assert "if target_id and not new_message:" in render
    finalize = _function(user, "finalize_booking")
    assert "مرحلهٔ ۳ از ۳ – پرداخت و ارسال رسید" in finalize
