from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_review_deep_link_payload_dispatches_to_existing_personalized_review_list():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    dispatch_start = source.index("async def dispatch_start_payload")
    dispatch_end = source.index('@router.message(CommandStart())', dispatch_start)
    dispatch = source[dispatch_start:dispatch_end]
    assert 'payload.casefold() in {"reviews", "review"}' in dispatch
    assert "await render_reviews(message)" in dispatch


def test_review_deep_link_survives_onboarding():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    start = source.index('@router.message(CommandStart())')
    end = source.index('@router.message(Command("quickmenu"))', start)
    block = source[start:end]
    assert 'payload.casefold() in {"reviews", "review"}' in block
    assert 'pending_start_payload=payload' in block


def test_archive_plus_reviews_activates_review_invite_and_audits_it():
    source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    start = source.index('async def event_archive_confirm(')
    end = source.index('@router.callback_query(F.data.startswith("admin:event:archive:cancel:"))', start)
    block = source[start:end]
    assert 'event.archived = True' in block
    assert 'event.feedback_enabled = True' in block
    assert '"feedback_enabled": True' in block


def test_users_without_reviewable_panels_get_a_friendly_empty_state():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    start = source.index('async def render_reviews(')
    end = source.index('@router.callback_query(F.data == "user:reviews")', start)
    block = source[start:end]
    assert "در حال حاضر پنلی برای ثبت نظر در دسترس شما نیست." in block
    assert "Booking.status == RegistrationStatus.CONFIRMED" in block
    assert "Event.archived.is_(True)" in block
