import asyncio
from pathlib import Path
import ast

import pytest

from app.bot.content import about_text, support_link_html, user_help_text
from app.bot.file_validation import file_content_matches, is_pdf_document, is_text_document, receipt_allowed, receipt_extension
from app.bot.callback_validation import positive_callback_id
from app.bot.command_validation import is_unrouted_telegram_command
from app.bot.validation import (
    is_valid_http_url, normalize_iranian_mobile, normalize_person_name,
    parse_full_name, parse_integer,
)
from app.config import settings
from app.db.models import Base, Booking, Event, EventStatus, Payment, PaymentStatus, RegistrationStatus, User, UserRole
from app.services.booking import cancel_booking, create_booking, user_can_cancel_booking
from app.services.events import seats_used
from sqlalchemy import create_engine
from sqlalchemy.orm import Session


class FakeAsyncSession:
    def __init__(self, sync_session: Session):
        self.s = sync_session
    async def execute(self, stmt):
        return self.s.execute(stmt)
    async def get(self, entity, ident, **kwargs):
        return self.s.get(entity, ident)
    def add(self, obj):
        self.s.add(obj)
    async def commit(self):
        self.s.commit()
    async def refresh(self, obj):
        self.s.refresh(obj)
    async def rollback(self):
        self.s.rollback()


def make_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, FakeAsyncSession(Session(engine))


def seed(session, status, *, owner_id=7001):
    owner = User(telegram_id=owner_id, first_name="Ali", last_name="Owner", role=UserRole.PARTICIPANT)
    session.s.add(owner)
    session.s.flush()
    event = Event(
        volume=1, title="Panel", event_day_label="Thursday", event_date_label="3 Tir 1404",
        start_time_label="16:30", end_time_label="-", venue="Venue", capacity=10,
        price_per_person=100000, status=EventStatus.PUBLISHED, registration_open=True,
    )
    session.s.add(event)
    session.s.flush()
    booking = Booking(event_id=event.id, booked_by_user_id=owner.id, participant_count=1,
                      total_amount=100000, status=status)
    session.s.add(booking)
    session.s.commit()
    return owner, event, booking


def test_name_validation_rejects_commands_links_numeric_and_punctuation():
    for value in ("/start", "/help", "/cancel", "12345", "!!!", "https://example.com"):
        assert normalize_person_name(value) is None
        assert parse_full_name(value) is None


def test_persian_english_compound_hyphenated_and_apostrophe_names_are_valid():
    assert normalize_person_name("  Sara   Jane ") == "Sara Jane"
    assert normalize_person_name("Anne-Marie") == "Anne-Marie"
    assert normalize_person_name("O’Neil") == "O’Neil"
    assert parse_full_name("علی رضایی") == ("علی", "رضایی")
    assert parse_full_name("Mary Jane O'Neil") == ("Mary", "Jane O'Neil")


def test_persian_and_arabic_indic_integers_parse_and_range_is_enforced():
    assert parse_integer("۳") == 3
    assert parse_integer("٣") == 3
    assert parse_integer("-1", minimum=0) is None
    assert parse_integer("abc", minimum=1) is None
    assert parse_integer("4", minimum=1, maximum=3) is None


def test_url_validation_requires_absolute_well_formed_http_or_https():
    for valid in ("https://maps.google.com/?q=mashhad", "http://example.com/maps"):
        assert is_valid_http_url(valid)
    for invalid in ("", "maps.google.com", "ftp://example.com", "https://", "https://bad host", "https://example.com:bad"):
        assert not is_valid_http_url(invalid)


def test_iranian_phone_normalization_accepts_persian_digits_and_rejects_bad_input():
    assert normalize_iranian_mobile("۰۹۱۵۱۱۱۷۸۸۹") == "+989151117889"
    assert normalize_iranian_mobile("0915abc17889") is None


def test_support_configuration_drives_both_username_and_telegram_url(monkeypatch):
    assert settings.support_username == "PanelFlowAdmin"
    assert settings.support_display_username == "@PanelFlowAdmin"
    assert settings.support_url == "https://t.me/PanelFlowAdmin"
    monkeypatch.setattr(settings, "support_username", "PanelFlowHelp")
    assert support_link_html() == '<a href="https://t.me/PanelFlowHelp">@PanelFlowHelp</a>'
    assert "@PanelFlowHelp" in user_help_text()
    assert "https://t.me/PanelFlowHelp" in user_help_text()
    assert "@PanelFlowHelp" not in about_text()
    assert "https://t.me/PanelFlowHelp" not in about_text()


def test_help_handler_is_one_role_neutral_state_preserving_response():
    source = Path("app/bot/handlers/user.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    handler = next(node for node in tree.body if isinstance(node, ast.AsyncFunctionDef) and node.name == "help_command")
    body = ast.get_source_segment(source, handler)
    assert '@router.message(Command("help"))' in source
    assert "message.answer(user_help_text(), disable_web_page_preview=True)" in body
    assert "reply_markup" not in body
    assert "state.clear" not in body and "get_or_create_user" not in body
    text = user_help_text()
    assert "پنل‌های پیش‌رو" in text and "ثبت‌نام‌های من" in text and "پروفایل من" in text
    assert "پشتیبانی انسانی" in text
    assert "پنل‌های پولی" not in text and "distinct" not in text.lower()


@pytest.mark.parametrize("status", [RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.PENDING_VERIFICATION])
def test_owner_can_cancel_pending_reservation(status):
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, status)
        result = asyncio.run(cancel_booking(session, owner.id, booking.id))
        assert result.status == RegistrationStatus.CANCELLED
        assert result.cancelled_at is not None
        assert result.expires_at is None
        assert session.s.get(Booking, booking.id).status == RegistrationStatus.CANCELLED
    finally:
        session.s.close(); engine.dispose()


def test_confirmed_booking_self_cancellation_is_rejected_without_changes():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.CONFIRMED)
        before_status, before_cancelled, before_confirmed = booking.status, booking.cancelled_at, booking.confirmed_at
        with pytest.raises(ValueError, match="CONFIRMED_CANCELLATION_FORBIDDEN"):
            asyncio.run(cancel_booking(session, owner.id, booking.id))
        session.s.rollback()
        fresh = session.s.get(Booking, booking.id)
        assert fresh.status == before_status
        assert fresh.cancelled_at == before_cancelled
        assert fresh.confirmed_at == before_confirmed
        assert event.capacity == 10
    finally:
        session.s.close(); engine.dispose()


def test_other_owner_cannot_cancel_a_booking():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.PENDING_PAYMENT)
        with pytest.raises(ValueError, match="NOT_FOUND"):
            asyncio.run(cancel_booking(session, owner.id + 1, booking.id))
        session.s.rollback()
        assert session.s.get(Booking, booking.id).status == RegistrationStatus.PENDING_PAYMENT
    finally:
        session.s.close(); engine.dispose()


def test_cancelled_expired_initiated_and_waitlisted_bookings_are_not_cancellable():
    for status in (RegistrationStatus.CANCELLED, RegistrationStatus.EXPIRED, RegistrationStatus.INITIATED, RegistrationStatus.WAITLISTED):
        engine, session = make_db()
        try:
            owner, event, booking = seed(session, status)
            with pytest.raises(ValueError, match="NOT_CANCELLABLE"):
                asyncio.run(cancel_booking(session, owner.id, booking.id))
            session.s.rollback()
            assert session.s.get(Booking, booking.id).status == status
        finally:
            session.s.close(); engine.dispose()


def test_rejected_booking_can_be_cancelled_after_receipt_rejection():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.REJECTED)
        result = asyncio.run(cancel_booking(session, owner.id, booking.id))
        assert result.status == RegistrationStatus.CANCELLED
        assert result.cancelled_at is not None
    finally:
        session.s.close(); engine.dispose()


def test_booking_service_rejects_invalid_participant_name_and_phone():
    engine, session = make_db()
    try:
        owner, event, _ = seed(session, RegistrationStatus.CANCELLED)
        with pytest.raises(ValueError, match="PARTICIPANT_NAME_REQUIRED"):
            asyncio.run(create_booking(session, owner.id, event.id, [{"first_name": "/start", "last_name": "User"}]))
        with pytest.raises(ValueError, match="INVALID_PARTICIPANT_PHONE"):
            asyncio.run(create_booking(session, owner.id, event.id, [{"first_name": "Sara", "last_name": "User", "phone_number": "123"}], allow_duplicate=True))
    finally:
        session.s.close(); engine.dispose()


def test_about_copy_contains_the_approved_history_in_both_languages():
    text = about_text()
    for phrase in (
        "Mashhad, Iran", "3 Tir 1404 (June 24, 2025)", "private", "welcoming public community",
        "۳ تیر ۱۴۰۴", "جامعه‌ای عمومی و پذیرا", "مشهد",
    ):
        assert phrase in text
    assert "more than a year" not in text
    assert "بیش از یک سال" not in text


def test_downloaded_document_signature_validation_rejects_fake_extensions(tmp_path):
    pdf = tmp_path / "actual.pdf"
    pdf.write_bytes(b"%PDF-1.7\nrest")
    assert file_content_matches(str(pdf), ".pdf")
    pdf.write_bytes(b"not a pdf")
    assert not file_content_matches(str(pdf), ".pdf")
    png = tmp_path / "actual.png"
    png.write_bytes(b"\x89PNG\r\n\x1a\nrest")
    assert file_content_matches(str(png), ".png")
    txt = tmp_path / "actual.txt"
    txt.write_text("نمونهٔ سوال", encoding="utf-8")
    assert file_content_matches(str(txt), ".txt")
    txt.write_bytes(b"\xff\xfe\x00\x00")
    assert not file_content_matches(str(txt), ".txt")


def test_help_about_support_contact_is_centralized_not_copied_as_a_literal():
    app_source = "\n".join(path.read_text(encoding="utf-8") for path in Path("app").rglob("*.py"))
    assert app_source.count('support_username: str = "PanelFlowAdmin"') == 1
    assert "@PanelFlowAdmin" not in app_source
    assert "t.me/PanelFlowAdmin" not in app_source


def test_admin_host_step_rejects_invalid_name_before_advancing_fsm():
    source = Path("app/bot/handlers/admin.py").read_text(encoding="utf-8")
    start = source.index("async def create_host")
    block = source[start:source.index("async def _show_creation_confirmation", start)]
    assert 'parse_full_name(m.text or "")' in block
    invalid_branch = block.index("if parsed_host is None:")
    state_advance = block.index("await state.set_state(AdminEventStates.questions_pdf)")
    data_update = block.index("await state.update_data(host_name=host_name)")
    assert invalid_branch < data_update < state_advance


def test_callback_identifier_parser_rejects_malformed_and_nonpositive_ids():
    assert positive_callback_id("user:booking:cancel:12") == 12
    for value in (None, "", "user:booking:cancel:", "user:booking:cancel:nope", "user:booking:cancel:0", "user:booking:cancel:-3"):
        assert positive_callback_id(value) is None


def test_pending_verification_cancel_releases_seats_and_preserves_payment_history():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.PENDING_VERIFICATION)
        payment = Payment(
            booking_id=booking.id,
            amount=booking.total_amount,
            status=PaymentStatus.PENDING,
            receipt_file="/archive/receipt.jpg",
            receipt_file_name="receipt.jpg",
            receipt_text=None,
        )
        session.s.add(payment)
        event.registration_open = False
        event.registration_closed_reason = "manual"
        session.s.commit()
        assert asyncio.run(seats_used(session, event.id)) == 1
        result = asyncio.run(cancel_booking(session, owner.id, booking.id))
        assert result.status == RegistrationStatus.CANCELLED
        assert asyncio.run(seats_used(session, event.id)) == 0
        assert session.s.get(Payment, payment.id).receipt_file == "/archive/receipt.jpg"
        assert session.s.get(Payment, payment.id).status == PaymentStatus.PENDING
        assert session.s.get(Event, event.id).registration_open is False
        assert session.s.get(Event, event.id).registration_closed_reason == "manual"
    finally:
        session.s.close(); engine.dispose()


def test_user_cancellation_requires_selection_then_revalidates_selected_booking():
    source = Path("app/bot/handlers/user.py").read_text(encoding="utf-8")
    confirm_start = source.index("async def booking_cancel_confirm(")
    select_start = source.index("async def booking_cancel(")
    end = source.index('@router.callback_query(F.data == "user:questions")', select_start)
    confirm_block = source[confirm_start:select_start]
    select_block = source[select_start:end]
    assert "await cancel_booking(session, user.id, booking_id)" in confirm_block
    assert "await state.clear()" in confirm_block
    assert "await reconcile_event_channel_status(c.bot, booking.event_id)" in confirm_block
    assert "booking_cancel_confirm_keyboard(booking_id)" in select_block
    assert "سایر رزروهای شما تغییری نمی‌کنند" in select_block


def test_legacy_creation_skip_callback_is_safe_and_text_dash_is_the_supported_path():
    source = Path("app/bot/handlers/admin.py").read_text(encoding="utf-8")
    start = source.index("async def create_questions_skip(")
    end = source.index("async def _finish_event_creation", start)
    block = source[start:end]
    assert "فقط علامت «-» را ارسال کنید" in block
    assert "سؤالات پنل را به‌صورت PDF یا TXT" in source
    assert 'raw == "-"' in source or "raw in {"-"" in source


def test_commands_that_fail_router_matching_cannot_become_fsm_values():
    assert is_unrouted_telegram_command("/start")
    assert is_unrouted_telegram_command("/help@another_bot", "panel_flow_bot")
    assert is_unrouted_telegram_command("/START")
    assert is_unrouted_telegram_command("/unknown")
    assert is_unrouted_telegram_command("/admin@another_bot", "panel_flow_bot")
    assert not is_unrouted_telegram_command("ordinary name", "panel_flow_bot")
    assert not is_unrouted_telegram_command("/admin", "panel_flow_bot")
    assert not is_unrouted_telegram_command("/admin@Panel_Flow_Bot", "panel_flow_bot")


def test_rejected_booking_has_existing_payment_retry_path_in_my_bookings():
    source = Path("app/bot/handlers/user.py").read_text(encoding="utf-8")
    start = source.index("async def render_my_bookings(")
    end = source.index("async def booking_cancel(", start)
    block = source[start:end]
    assert "RegistrationStatus.REJECTED" in block
    assert 'callback_data=f"user:payment:retry:{booking.id}"' in block


def test_receipt_file_metadata_accepts_supported_mime_without_filename_and_rejects_mismatches():
    from types import SimpleNamespace

    no_name_pdf = SimpleNamespace(file_name=None, mime_type="application/pdf")
    no_name_png = SimpleNamespace(file_name=None, mime_type="image/png")
    mismatch = SimpleNamespace(file_name="receipt.pdf", mime_type="image/png")
    unsupported = SimpleNamespace(file_name="receipt.exe", mime_type="application/octet-stream")
    assert receipt_allowed(no_name_pdf) and receipt_extension(no_name_pdf) == ".pdf"
    assert receipt_allowed(no_name_png) and receipt_extension(no_name_png) == ".png"
    assert is_pdf_document(no_name_pdf)
    assert not receipt_allowed(mismatch)
    assert receipt_extension(mismatch) is None
    assert not receipt_allowed(unsupported)


def test_question_file_metadata_requires_pdf_or_txt_and_empty_txt_is_rejected(tmp_path):
    from types import SimpleNamespace

    assert is_pdf_document(SimpleNamespace(file_name="q.pdf", mime_type="application/pdf"))
    assert is_text_document(SimpleNamespace(file_name="q.txt", mime_type="text/plain"))
    assert not is_text_document(SimpleNamespace(file_name="q.txt", mime_type="application/pdf"))
    empty = tmp_path / "empty.txt"
    empty.write_bytes(b"")
    assert not file_content_matches(str(empty), ".txt")


def test_confirmed_zero_cost_booking_can_be_cancelled_and_releases_capacity():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.CONFIRMED)
        booking.total_amount = 0
        booking.discount_amount = 100000  # Represents a fully discounted reservation.
        session.s.commit()
        assert asyncio.run(seats_used(session, event.id)) == 1
        result = asyncio.run(cancel_booking(session, owner.id, booking.id))
        assert result.status == RegistrationStatus.CANCELLED
        assert result.cancelled_at is not None
        assert asyncio.run(seats_used(session, event.id)) == 0
        # The historical discount redemption/confirmation data is not rewritten by cancellation.
        assert result.discount_amount == 100000
    finally:
        session.s.close(); engine.dispose()


def test_confirmed_zero_cost_booking_with_positive_payment_record_remains_protected():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.CONFIRMED)
        booking.total_amount = 0
        session.s.add(Payment(booking_id=booking.id, amount=100000, status=PaymentStatus.APPROVED))
        session.s.commit()
        with pytest.raises(ValueError, match="CONFIRMED_CANCELLATION_FORBIDDEN"):
            asyncio.run(cancel_booking(session, owner.id, booking.id))
        session.s.rollback()
        assert session.s.get(Booking, booking.id).status == RegistrationStatus.CONFIRMED
    finally:
        session.s.close(); engine.dispose()


def test_zero_cost_confirmed_booking_with_unresolved_financial_case_is_not_cancellable():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.CONFIRMED)
        booking.total_amount = 0
        booking.cancellation_resolution = "action_required"
        session.s.commit()
        with pytest.raises(ValueError, match="CONFIRMED_CANCELLATION_FORBIDDEN"):
            asyncio.run(cancel_booking(session, owner.id, booking.id))
        session.s.rollback()
        assert session.s.get(Booking, booking.id).status == RegistrationStatus.CONFIRMED
    finally:
        session.s.close(); engine.dispose()


def test_free_confirmed_booking_cancellation_eligibility_matches_published_panel_policy():
    from types import SimpleNamespace

    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.CONFIRMED)
        booking.total_amount = 0
        booking.discount_amount = 100000
        assert user_can_cancel_booking(booking, None, event) is True

        booking.total_amount = 100000
        assert user_can_cancel_booking(booking, None, event) is False
        booking.total_amount = 0
        event.status = EventStatus.COMPLETED
        assert user_can_cancel_booking(booking, None, event) is False
        event.status = EventStatus.PUBLISHED
        event.archived = True
        assert user_can_cancel_booking(booking, None, event) is False
        event.archived = False
        event.status = EventStatus.PUBLISHED
        assert user_can_cancel_booking(booking, SimpleNamespace(amount=1000), event) is False
        booking.cancellation_resolution = "action_required"
        assert user_can_cancel_booking(booking, None, event) is False
    finally:
        session.s.close(); engine.dispose()


def test_zero_cost_confirmed_booking_cannot_be_cancelled_after_panel_completion():
    engine, session = make_db()
    try:
        owner, event, booking = seed(session, RegistrationStatus.CONFIRMED)
        booking.total_amount = 0
        event.status = EventStatus.COMPLETED
        session.s.commit()
        with pytest.raises(ValueError, match="NOT_CANCELLABLE"):
            asyncio.run(cancel_booking(session, owner.id, booking.id))
        session.s.rollback()
        assert session.s.get(Booking, booking.id).status == RegistrationStatus.CONFIRMED
    finally:
        session.s.close(); engine.dispose()
