"""V48 checks for creative submission layout and administrator-only leaderboard."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_creative_review_pairs_winner_action_and_profile_button_on_one_row():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    review = source.split("async def _render_submission_page", 1)[1].split(
        "async def _render_submission_challenge_list", 1
    )[0]
    assert 'rows.append([action_button, InlineKeyboardButton(text=f"👤 پروفایل · #{sub.id}", url=profile_url)])' in review
    assert 'text=f"#{sub.id} انتخاب برگزیدهٔ بعدی"' in review
    assert 'rows.append([InlineKeyboardButton(text=f"پروفایل · #{sub.id}", url=profile_url)])' not in review.split(
        'elif status == "closed" and challenge_type == "creative":', 1
    )[1].split("else:", 1)[0]


def test_admin_leaderboard_is_separate_and_does_not_change_public_leaderboard_filters():
    service = (ROOT / "app/services/community.py").read_text(encoding="utf-8")
    admin_service = service.split("async def admin_leaderboard_rows", 1)[1].split(
        "async def leaderboard_opted_in", 1
    )[0]
    assert "hidden_by_id" in admin_service
    assert '"hidden": hidden_by_id.get' in admin_service
    assert "leaderboard_enabled(session)" not in admin_service

    handler = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    admin_view = handler.split("async def admin_view_full_leaderboard", 1)[1].split(
        '@router.callback_query(F.data == "admin:community:leaderboard:toggle")', 1
    )[0]
    assert "if not await _is_admin(c.from_user.id)" in admin_view
    assert "admin_leaderboard_rows" in admin_view
    assert "پنهان از رتبه‌بندی عمومی" in admin_view
    public_view = handler.split("async def community_leaderboard", 1)[1].split(
        '@router.callback_query(F.data == "community:leaderboard:privacy")', 1
    )[0]
    assert "leaderboard_rows(session, 10)" in public_view


def test_admin_menu_uses_challenge_wording_and_has_full_leaderboard_entry():
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert 'text="🎯 مدیریت چالش‌ها", callback_data="admin:community"' in keyboards
    admin_menu = keyboards.split("def admin_community_menu", 1)[1]
    assert 'callback_data="admin:community:leaderboard:view:0"' in admin_menu
    assert 'text=("🟢 لیدربورد عمومی: فعال" if leaderboard_enabled else "🔴 لیدربورد عمومی: غیرفعال")' in admin_menu
