from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


def test_v29_participant_roster_is_compact_grouped_paginated_and_includes_status_history():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    block = admin.split("async def _render_participants(", 1)[1].split(r'@router.callback_query(F.data.regexp(r"^admin:event:pending:\d+$"))', 1)[0]
    assert 'admin:event:participants_page:{eid}:{page - 1}' in block
    assert 'admin:event:participants_page:{eid}:{page + 1}' in block
    assert "for booking in bookings:" in block
    assert "booking_contact_phone(booking)" in block
    assert "👤 رزروکننده:" in block
    assert "💳 پرداخت: {payment_status} | 🧾 رزرو: {reservation_status}" in block
    assert "↳ {start_no + offset}. {name}" in block
    assert "lifetime_confirmed_bookings" not in block
    assert "booking_status_label(booking.status)" not in block


def test_v29_proposed_question_copy_matches_requested_empty_state_and_drops_extra_sentence():
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    block = user.split("async def render_question_center(", 1)[1].split('@router.callback_query(F.data == "user:submit_question")', 1)[0]
    assert '"اینجا می‌توانید سؤال‌های قبلی خود و پاسخ‌های ثبت‌شده را ببینید."' in block
    assert 'lines.extend(["", "هنوز سؤالی ارسال نکرده‌اید."])' in block
    assert "برای پاسخ‌ها اعلان جداگانه ارسال نمی‌شود." not in block


def test_v29_user_review_flow_does_not_show_submitted_review_content_again():
    user = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
    list_block = user.split("async def render_reviews(", 1)[1].split('@router.callback_query(F.data == "user:reviews")', 1)[0]
    select_block = user.split('@router.callback_query(F.data.startswith("user:review:event:"))', 1)[1].split('@router.callback_query(F.data.startswith("review:rating:"))', 1)[0]
    confirm_block = user.split('@router.callback_query(F.data == "review:confirm")', 1)[1].split('@router.callback_query(F.data == "review:cancel")', 1)[0]
    assert "reviewed_ids" in list_block and "قبلاً ثبت شده" in list_block
    assert "select(Review).where(Review.event_id == event_id, Review.user_id == user.id)" in select_block
    assert "if existing:" in select_block
    assert "فقط برای مدیران نمایش داده می‌شود" in user
    assert 'c.message.edit_text("✅ نظر شما با موفقیت و به‌صورت خصوصی برای مدیران ارسال شد.", reply_markup=main_menu())' in confirm_block
    success_screen = confirm_block.split('await c.message.edit_text("✅ نظر شما با موفقیت و به‌صورت خصوصی برای مدیران ارسال شد."', 1)[1]
    assert "review_text" not in success_screen
    assert "review.text" not in list_block
