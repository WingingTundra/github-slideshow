from __future__ import annotations

import os
import signal
import subprocess
import sys
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.config import Settings

ROOT = Path(__file__).resolve().parents[1]


def _run_process_group(command, *, env, timeout=30):
    """Run shell workflows with descendants bounded by the same timeout."""
    process = subprocess.Popen(
        command, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate(timeout=5)
        raise subprocess.TimeoutExpired(command, timeout, output=stdout, stderr=stderr)
    return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)


def test_database_pool_configuration_rejects_unsafe_values():
    with pytest.raises(ValidationError):
        Settings(_env_file=None, database_pool_size=0)
    with pytest.raises(ValidationError):
        Settings(_env_file=None, database_max_overflow=-1)
    with pytest.raises(ValidationError):
        Settings(_env_file=None, database_lock_pool_timeout_seconds=0)
    with pytest.raises(ValidationError):
        Settings(_env_file=None, database_pool_timeout_seconds=float("inf"))


def test_application_and_advisory_lock_connections_use_distinct_bounded_pools(monkeypatch):
    from app.db import session as db_session
    from app.config import settings

    calls: list[tuple[str, dict]] = []

    class DummyEngine:
        async def dispose(self):
            return None

    def fake_create_async_engine(url, **kwargs):
        calls.append((url, kwargs))
        return DummyEngine()

    monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://test:secret@localhost:5432/pf_test")
    monkeypatch.setattr(settings, "database_pool_size", 7)
    monkeypatch.setattr(settings, "database_max_overflow", 3)
    monkeypatch.setattr(settings, "database_pool_timeout_seconds", 12.0)
    monkeypatch.setattr(settings, "database_lock_pool_size", 4)
    monkeypatch.setattr(settings, "database_lock_max_overflow", 2)
    monkeypatch.setattr(settings, "database_lock_pool_timeout_seconds", 8.0)
    monkeypatch.setattr(db_session, "create_async_engine", fake_create_async_engine)
    monkeypatch.setattr(db_session.engine, "_engine", None)
    monkeypatch.setattr(db_session.engine, "_url", None)
    monkeypatch.setattr(db_session.event_isolation_engine, "_engine", None)
    monkeypatch.setattr(db_session.event_isolation_engine, "_url", None)

    main_engine = db_session.engine._get_engine()
    isolation_engine = db_session.event_isolation_engine._get_engine()

    assert main_engine is not isolation_engine
    assert len(calls) == 2
    assert calls[0][1] == {
        "pool_pre_ping": True, "pool_size": 7, "max_overflow": 3, "pool_timeout": 12.0,
    }
    assert calls[1][1] == {
        "pool_pre_ping": True, "pool_size": 4, "max_overflow": 2, "pool_timeout": 8.0,
    }
    assert "secret" not in repr(calls[0][1])


def _run_crypto(operation: str, source: Path, destination: Path, key: str):
    env = os.environ.copy()
    env["BACKUP_ENCRYPTION_KEY"] = key
    return subprocess.run(
        [sys.executable, str(ROOT / "scripts/backup_crypto.py"), operation, str(source), str(destination)],
        env=env, text=True, capture_output=True, check=False, timeout=30,
    )


def test_authenticated_backup_crypto_roundtrip_and_rejects_tampering(tmp_path):
    original = tmp_path / "source.tar.gz"
    original.write_bytes((b"Panel Flow backup fixture\x00" * 4096) + b"end")
    encrypted = tmp_path / "backup.tar.gz.enc"
    recovered = tmp_path / "recovered.tar.gz"
    key = "test-only-high-entropy-key-material"

    result = _run_crypto("encrypt", original, encrypted, key)
    assert result.returncode == 0, result.stdout + result.stderr
    assert encrypted.read_bytes().startswith(b"PFLOWAE1")
    assert encrypted.read_bytes() != original.read_bytes()

    result = _run_crypto("decrypt", encrypted, recovered, key)
    assert result.returncode == 0, result.stdout + result.stderr
    assert recovered.read_bytes() == original.read_bytes()

    tampered = tmp_path / "tampered.enc"
    damaged = bytearray(encrypted.read_bytes())
    damaged[-1] ^= 0x01
    tampered.write_bytes(damaged)
    rejected_output = tmp_path / "must-not-exist.tar.gz"
    result = _run_crypto("decrypt", tampered, rejected_output, key)
    assert result.returncode != 0
    assert "authentication failed" in result.stderr.lower()
    assert not rejected_output.exists()
    assert not list(tmp_path.glob(".backup-crypto-*"))


def test_backup_crypto_identifies_legacy_ciphertext_without_decrypting_it(tmp_path):
    legacy = tmp_path / "old-openssl-backup.enc"
    legacy.write_bytes(b"Salted__legacy-format-fixture")
    target = tmp_path / "legacy-out.tar.gz"
    result = _run_crypto("decrypt", legacy, target, "test-only-key")
    assert result.returncode == 3
    assert not target.exists()


def test_restore_fails_closed_on_tampered_authenticated_archive_without_legacy_fallback(tmp_path):
    from test_v69_qa_hardening import _fake_restore_commands

    plaintext = tmp_path / "backup.tar.gz"
    plaintext.write_bytes(b"test payload; this fixture is intentionally not a tar archive")
    encrypted = tmp_path / "new-format.enc"
    tampered = tmp_path / "tampered-new-format.enc"
    key = "test-only-high-entropy-key-material"
    result = _run_crypto("encrypt", plaintext, encrypted, key)
    assert result.returncode == 0, result.stdout + result.stderr
    damaged = bytearray(encrypted.read_bytes())
    damaged[-1] ^= 0x80
    tampered.write_bytes(damaged)

    bindir = _fake_restore_commands(tmp_path)
    # If the restore script tries CBC fallback after a V1 authentication failure,
    # this stub leaves a marker so the test can detect the unsafe downgrade.
    marker = tmp_path / "legacy-openssl-was-used"
    (bindir / "openssl").write_text(
        "#!/bin/sh\nprintf called > \"${OPENSSL_MARKER}\"\nexit 99\n", encoding="utf-8"
    )
    (bindir / "openssl").chmod(0o755)
    restore_work = tmp_path / "restore-work-auth-failure"
    restored_uploads = tmp_path / "restore-uploads-auth-failure"
    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "CONFIRM_DISPOSABLE_RESTORE": "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET",
        "BACKUP_FILE": str(tampered),
        "BACKUP_ENCRYPTION_KEY": key,
        "RESTORE_DIR": str(restore_work),
        "RESTORE_UPLOAD_DIR": str(restored_uploads),
        "RESTORE_DATABASE_URL": "postgresql://fake/unused_db",
        "OPENSSL_MARKER": str(marker),
    })
    result = _run_process_group(
        ["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30,
    )
    assert result.returncode != 0
    assert "authentication failed" in result.stderr.lower()
    assert not marker.exists()
    assert not restore_work.exists()
    assert not restored_uploads.exists()


def test_graceful_pool_disposal_is_safe_when_startup_never_created_engines(monkeypatch):
    import asyncio
    from app.db import session as db_session

    monkeypatch.setattr(db_session.engine, "_engine", None)
    monkeypatch.setattr(db_session.event_isolation_engine, "_engine", None)
    asyncio.run(db_session.dispose_database_engines())

def test_modified_authenticated_format_marker_never_downgrades_to_legacy_cbc(tmp_path):
    from test_v69_qa_hardening import _fake_restore_commands

    plaintext = tmp_path / "backup.tar.gz"
    plaintext.write_bytes(b"payload")
    encrypted = tmp_path / "new-format.enc"
    key = "test-only-high-entropy-key-material"
    result = _run_crypto("encrypt", plaintext, encrypted, key)
    assert result.returncode == 0, result.stdout + result.stderr
    damaged = bytearray(encrypted.read_bytes())
    damaged[0] ^= 0x01  # break the format marker; payload/tag are otherwise intact
    unknown = tmp_path / "marker-damaged.enc"
    unknown.write_bytes(damaged)

    bindir = _fake_restore_commands(tmp_path)
    marker = tmp_path / "legacy-openssl-was-used"
    (bindir / "openssl").write_text(
        "#!/bin/sh\nprintf called > \"${OPENSSL_MARKER}\"\nexit 99\n", encoding="utf-8"
    )
    (bindir / "openssl").chmod(0o755)
    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "CONFIRM_DISPOSABLE_RESTORE": "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET",
        "BACKUP_FILE": str(unknown),
        "BACKUP_ENCRYPTION_KEY": key,
        "RESTORE_DIR": str(tmp_path / "restore-work"),
        "RESTORE_UPLOAD_DIR": str(tmp_path / "restore-uploads"),
        "RESTORE_DATABASE_URL": "postgresql://fake/unused_db",
        "OPENSSL_MARKER": str(marker),
    })
    result = _run_process_group(
        ["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30,
    )
    assert result.returncode == 2
    assert "explicit RESTORE_ALLOW_LEGACY_CBC opt-in" in result.stderr
    assert not marker.exists()


def test_legacy_cbc_restore_is_available_with_explicit_operator_opt_in(tmp_path):
    from test_v69_qa_hardening import _build_fake_encrypted_backup, _fake_restore_commands

    plaintext_backup, source_upload = _build_fake_encrypted_backup(tmp_path)
    legacy = tmp_path / "historical-openssl-backup.enc"
    legacy.write_bytes(b"Salted__" + b"12345678" + b"X" * 16)
    bindir = _fake_restore_commands(tmp_path)
    restored_dir = tmp_path / "legacy-restored-uploads"
    restore_work = tmp_path / "legacy-restore-work"
    env = os.environ.copy()
    env.update({
        "PATH": f"{bindir}:{env.get('PATH', '')}",
        "CONFIRM_DISPOSABLE_RESTORE": "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET",
        "BACKUP_FILE": str(legacy),
        "BACKUP_ENCRYPTION_KEY": "test-only-fake-key",
        "RESTORE_ALLOW_LEGACY_CBC": "YES_I_UNDERSTAND_LEGACY_CBC_IS_UNAUTHENTICATED",
        "OPENSSL_DECRYPT_FIXTURE": str(plaintext_backup),
        "RESTORE_DIR": str(restore_work),
        "RESTORE_UPLOAD_DIR": str(restored_dir),
        "RESTORE_DATABASE_URL": "postgresql://fake/empty_test_db",
    })
    result = _run_process_group(
        ["sh", str(ROOT / "scripts/restore-backup.sh")], env=env, timeout=30,
    )
    assert result.returncode == 0, result.stderr + result.stdout
    assert restored_dir.is_dir()
    assert (restored_dir / source_upload.name).read_bytes() == source_upload.read_bytes()
    assert not restore_work.exists()

