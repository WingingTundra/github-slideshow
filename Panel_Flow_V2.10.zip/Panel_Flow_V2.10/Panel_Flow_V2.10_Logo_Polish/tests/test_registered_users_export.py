from datetime import datetime
from io import BytesIO
import zipfile
import xml.etree.ElementTree as ET
from types import SimpleNamespace

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.models import Base, User, UserRole
from app.services.registered_users_export import (
    build_completed_user_profiles_workbook,
    completed_user_profiles_statement,
)

NS = {
    "main": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
}


def _shared_strings(book_zip):
    root = ET.fromstring(book_zip.read("xl/sharedStrings.xml"))
    return [
        "".join(node.text or "" for node in item.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"))
        for item in root.findall("main:si", NS)
    ]


def _cell(book_zip, address, shared):
    root = ET.fromstring(book_zip.read("xl/worksheets/sheet1.xml"))
    cell = root.find(f".//main:c[@r='{address}']", NS)
    if cell is None:
        return None
    value = cell.find("main:v", NS)
    if cell.attrib.get("t") == "s" and value is not None:
        return shared[int(value.text)]
    inline = cell.find("main:is", NS)
    if inline is not None:
        return "".join(node.text or "" for node in inline.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"))
    return value.text if value is not None else None


def test_completed_profile_query_excludes_users_who_did_not_finish_onboarding():
    engine = create_engine("sqlite:///:memory:")
    User.__table__.create(engine)
    with Session(engine) as session:
        complete = User(
            telegram_id=700000001,
            telegram_username="complete_user",
            first_name="سینا",
            last_name="ضیائی",
            display_name="سینا ضیائی",
            phone_number="+989121234567",
            role=UserRole.PARTICIPANT,
            created_at=datetime(2026, 10, 10),
        )
        no_phone = User(
            telegram_id=700000002,
            first_name="Incomplete",
            last_name="Phone",
            phone_number=None,
            role=UserRole.PARTICIPANT,
        )
        blank_first = User(
            telegram_id=700000003,
            first_name="   ",
            last_name="Blank",
            phone_number="+989120000000",
            role=UserRole.PARTICIPANT,
        )
        blank_last = User(
            telegram_id=700000004,
            first_name="Missing",
            last_name="  ",
            phone_number="+989120000001",
            role=UserRole.PARTICIPANT,
        )
        session.add_all([complete, no_phone, blank_first, blank_last])
        session.commit()
        results = session.execute(completed_user_profiles_statement()).scalars().all()
        assert [user.telegram_id for user in results] == [700000001]
    engine.dispose()


def test_users_workbook_contains_only_requested_profile_fields_and_preserves_unicode():
    users = [
        SimpleNamespace(
            first_name="سینا",
            last_name="ضیائی",
            phone_number="+989121234567",
            telegram_username="sina_example",
            telegram_id=318109687,
        ),
        SimpleNamespace(
            first_name="Alex",
            last_name="Example",
            phone_number="+989111112222",
            telegram_username=None,
            telegram_id=123456789,
        ),
    ]
    payload = build_completed_user_profiles_workbook(users)
    assert payload[:2] == b"PK"
    with zipfile.ZipFile(BytesIO(payload)) as book_zip:
        assert book_zip.testzip() is None
        shared = _shared_strings(book_zip)
        workbook = ET.fromstring(book_zip.read("xl/workbook.xml"))
        sheets = [s.attrib["name"] for s in workbook.findall("main:sheets/main:sheet", NS)]
        assert sheets == ["Completed Users"]
        assert _cell(book_zip, "A5", shared) == "1"
        assert _cell(book_zip, "B5", shared) == "سینا ضیائی"
        assert _cell(book_zip, "C5", shared) == "+989121234567"
        assert _cell(book_zip, "D5", shared) == "@sina_example"
        assert _cell(book_zip, "E5", shared) == "318109687"
        assert _cell(book_zip, "D6", shared) == "—"
        assert _cell(book_zip, "E6", shared) == "123456789"
        assert "تعداد پروفایل‌های کامل: 2" in " ".join(shared)


def test_users_workbook_handles_empty_completed_profile_list():
    payload = build_completed_user_profiles_workbook([])
    with zipfile.ZipFile(BytesIO(payload)) as book_zip:
        assert book_zip.testzip() is None
        shared = _shared_strings(book_zip)
        assert "تعداد پروفایل‌های کامل: 0" in " ".join(shared)
        assert "هنوز هیچ پروفایل کاملی ثبت نشده است." in " ".join(shared)


def test_admin_menu_wires_profile_export_to_an_authorized_handler():
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    keyboards = (root / "app/bot/keyboards.py").read_text(encoding="utf-8")
    admin = (root / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:users:export"' in keyboards
    assert '@router.callback_query(F.data == "admin:users:export")' in admin
    handler_start = admin.index("async def export_completed_bot_users")
    handler_end = admin.find("@router.callback_query", handler_start)
    handler_source = admin[handler_start:handler_end]
    assert "if not await is_admin(c.from_user.id)" in handler_source
    assert "completed_user_profiles_statement()" in handler_source
    assert "build_completed_user_profiles_workbook(users)" in handler_source
