from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path
from types import ModuleType

ROOT = Path(__file__).resolve().parents[1]
USER_SOURCE = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
KEYBOARD_SOURCE = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
STATES_SOURCE = (ROOT / "app/bot/states.py").read_text(encoding="utf-8")


def _function_source(source: str, name: str) -> str:
    tree = ast.parse(source)
    node = next(
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
    )
    return ast.get_source_segment(source, node) or ""


def test_follow_on_registration_collects_only_new_attendee_names():
    process_count = _function_source(USER_SOURCE, "_process_booking_count")
    begin_register = _function_source(USER_SOURCE, "begin_register_from_message")
    count_prompt = _function_source(USER_SOURCE, "_booking_count_prompt")
    append_attendee = _function_source(USER_SOURCE, "_append_current_non_booker_and_continue")

    assert "additional_booking = bool(data.get(\"allow_duplicate\"))" in process_count
    assert "participants = [] if additional_booking" in process_count
    assert "current_index = 0 if additional_booking else 1" in process_count
    assert 'if count == 1 and not additional_booking:' in process_count
    assert "نام و نام خانوادگی نفر جدید را یکجا وارد کنید:" in process_count
    assert "نام و نام خانوادگی نفر ۱ از ثبت‌نام جدید را یکجا وارد کنید:" in process_count
    assert "چند نفر جدید را برای پنل {escape(volume_label(event.volume))}" in count_prompt
    assert "چون قبلاً برای این پنل ثبت‌نام کرده‌اید" in count_prompt
    assert "_booking_count_prompt(message, state, event)" in begin_register
    assert "participants.append({" in append_attendee
    assert "if index < count:" in append_attendee


def test_personal_reward_is_not_applied_to_follow_on_booking_of_other_people():
    begin_register = _function_source(USER_SOURCE, "begin_register_from_message")
    summary = _function_source(USER_SOURCE, "show_booking_summary")
    assert "personal_reward = None if allow_duplicate else await accepted_personal_reward" in begin_register
    assert "if not data.get(\"allow_duplicate\")" in summary


def test_stale_confirmation_buttons_only_show_popup_and_do_not_clear_current_state():
    confirm = _function_source(USER_SOURCE, "confirm_booking_callback")
    cancel = _function_source(USER_SOURCE, "cancel_booking_callback")

    assert "_confirmation_lock_for(int(c.from_user.id))" in confirm
    assert 'return await c.answer("ثبت‌نام قبلی دیگر فعال نیست.", show_alert=True)' in confirm
    assert 'return await c.answer("ثبت‌نام قبلی دیگر فعال نیست.", show_alert=True)' in cancel
    # Neither stale-button branch is allowed to clear newer state such as receipt submission.
    assert "state.clear()" not in confirm
    stale_cancel_branch = cancel.split('if await state.get_state() != BookingStates.confirm.state:', 1)[1].split('await state.clear()', 1)[0]
    assert "state.clear()" not in stale_cancel_branch
    assert "await c.message.edit_text(\"ثبت‌نام لغو شد.\", reply_markup=main_menu())" in cancel


def test_confirmation_lock_is_weakly_held_and_serializes_duplicate_taps():
    lock_factory = _function_source(USER_SOURCE, "_confirmation_lock_for")
    assert "WeakValueDictionary" in USER_SOURCE
    assert "asyncio.Lock()" in lock_factory
    assert "async with lock:" in _function_source(USER_SOURCE, "confirm_booking_callback")
    assert "processing_confirmation" not in STATES_SOURCE

    finalize = _function_source(USER_SOURCE, "finalize_booking")
    checkout_state = finalize.index("await state.set_state(BookingStates.waiting_receipt)")
    reconcile = finalize.index("await reconcile_event_channel_status(message.bot, event_id)", checkout_state)
    payment_message = finalize.index("await _render_booking_prompt(", reconcile)
    assert checkout_state < reconcile < payment_message
    assert "مرحلهٔ ۳ از ۳ – پرداخت و ارسال رسید" in finalize


def test_payment_instructions_use_copy_card_keyboard_for_initial_and_retry_flows():
    assert "def payment_card_keyboard(card_number: str | None)" in KEYBOARD_SOURCE
    assert "CopyTextButton(text=value)" in KEYBOARD_SOURCE
    assert 'text="کپی شماره کارت"' in KEYBOARD_SOURCE
    assert USER_SOURCE.count("reply_markup=receipt_upload_keyboard(payment_card_number,") >= 3
    assert "def receipt_upload_keyboard(card_number: str | None, booking_id: int)" in KEYBOARD_SOURCE
    receipt_keyboard = _function_source(KEYBOARD_SOURCE, "receipt_upload_keyboard")
    assert "user:payment:cancel_receipt:" in receipt_keyboard
    assert "def receipt_cancel_reply_keyboard()" in KEYBOARD_SOURCE  # legacy compatibility factory
    assert "_show_receipt_cancel_reply_button" not in USER_SOURCE
    assert "await _payment_details()" in USER_SOURCE
    assert "from aiogram.types import CopyTextButton, InlineKeyboardMarkup, InlineKeyboardButton" in KEYBOARD_SOURCE


def test_payment_card_keyboard_copies_only_configured_card_number(monkeypatch):
    """Exercise keyboard construction without requiring the full aiogram runtime."""
    aiogram_module = ModuleType("aiogram")
    types_module = ModuleType("aiogram.types")
    types_module.__package__ = "aiogram"

    class FakeCopyTextButton:
        def __init__(self, *, text):
            self.text = text

    class FakeInlineKeyboardButton:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class FakeInlineKeyboardMarkup:
        def __init__(self, *, inline_keyboard):
            self.inline_keyboard = inline_keyboard

    types_module.CopyTextButton = FakeCopyTextButton
    types_module.InlineKeyboardButton = FakeInlineKeyboardButton
    types_module.InlineKeyboardMarkup = FakeInlineKeyboardMarkup
    aiogram_module.types = types_module
    monkeypatch.setitem(sys.modules, "aiogram", aiogram_module)
    monkeypatch.setitem(sys.modules, "aiogram.types", types_module)

    prior = sys.modules.pop("app.bot.keyboards", None)
    try:
        module = importlib.import_module("app.bot.keyboards")
        keyboard = module.payment_card_keyboard("  6219861073957911  ")
        assert keyboard is not None
        button = keyboard.inline_keyboard[0][0]
        assert button.text == "کپی شماره کارت"
        assert button.copy_text.text == "6219861073957911"
        assert module.payment_card_keyboard("") is None
        assert module.payment_card_keyboard(None) is None
        assert module.payment_card_keyboard("x" * 257) is None
    finally:
        sys.modules.pop("app.bot.keyboards", None)
        if prior is not None:
            sys.modules["app.bot.keyboards"] = prior


def _load_async_functions(source: str, names: set[str], namespace: dict):
    tree = ast.parse(source)
    selected = []
    for node in tree.body:
        if isinstance(node, ast.AsyncFunctionDef) and node.name in names:
            node.decorator_list = []
            selected.append(node)
    assert {node.name for node in selected} == names
    module = ast.Module(
        body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), *selected],
        type_ignores=[],
    )
    exec(compile(ast.fix_missing_locations(module), "user_handlers_under_test.py", "exec"), namespace)
    return {name: namespace[name] for name in names}


def test_actual_count_handler_uses_profile_for_initial_booking_but_prompts_for_repeat_booking():
    import asyncio
    from types import SimpleNamespace

    class StateName:
        def __init__(self, value):
            self.state = value

    class States:
        waiting_participant_name = StateName("booking:waiting_participant_name")

    class FakeEvent:
        id = 51
        capacity = 10

    class FakeUser:
        id = 501
        telegram_id = 35001
        first_name = "Sina"
        last_name = "Ziaei"
        phone_number = "+989121228888"

    event = FakeEvent()
    owner = FakeUser()

    class Session:
        async def __aenter__(self):
            return self
        async def __aexit__(self, exc_type, exc, tb):
            return False
        async def get(self, model, ident):
            return event if model is FakeEvent else owner if model is FakeUser else None

    class State:
        def __init__(self, data):
            self.data = dict(data)
            self.current_state = "booking:waiting_count"
            self.summary = None
        async def get_data(self):
            return dict(self.data)
        async def update_data(self, **kwargs):
            self.data.update(kwargs)
        async def set_state(self, state):
            self.current_state = state.state if hasattr(state, "state") else state
        async def clear(self):
            self.data.clear()
            self.current_state = None

    class Message:
        from_user = SimpleNamespace(id=35001)
        def __init__(self):
            self.answers = []
        async def answer(self, text, reply_markup=None):
            self.answers.append((text, reply_markup))

    async def always_true(_event): return True
    async def no_op(*_args, **_kwargs): return None
    async def seats_used(*_args, **_kwargs): return 0
    async def active_seats(*_args, **_kwargs): return 1
    async def summary(message, state, *, new_message=False): state.summary = list(state.data["participants"])
    async def render_prompt(message, state, text, reply_markup=None):
        await message.answer(text, reply_markup=reply_markup)

    namespace = {
        "MAX_PARTICIPANTS_PER_BOOKING": 3,
        "MAX_ACTIVE_SEATS_PER_USER_PER_PANEL": 3,
        "SessionLocal": Session,
        "Event": FakeEvent,
        "User": FakeUser,
        "event_is_bookable": always_true,
        "expire_old_bookings": no_op,
        "seats_used": seats_used,
        "active_seats_for_owner": active_seats,
        "show_booking_summary": summary,
        "_render_booking_prompt": render_prompt,
        "BookingStates": States,
        "booking_count_keyboard": lambda maximum: ("count-keyboard", maximum),
        "main_menu": lambda: "main-menu",
    }
    def fa_digits(value):
        return str(value).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))

    namespace["_fa_digits"] = fa_digits
    funcs = _load_async_functions(
        USER_SOURCE,
        {"_process_booking_count", "_append_current_non_booker_and_continue"},
        namespace,
    )

    # A repeat reservation for one new attendee asks for a name and does not
    # silently register the booker as participant one again.
    repeat_state = State({"event_id": 51, "user_id": 501, "max_count": 2, "allow_duplicate": True})
    repeat_message = Message()
    asyncio.run(funcs["_process_booking_count"](1, repeat_message, repeat_state, 35001))
    assert repeat_state.data["participants"] == []
    assert repeat_state.data["current_index"] == 0
    assert repeat_state.data["booker_phone"] == "+989121228888"
    assert repeat_state.current_state == States.waiting_participant_name.state
    assert repeat_message.answers[-1][0].endswith("نام و نام خانوادگی نفر جدید را یکجا وارد کنید:")
    assert repeat_state.summary is None

    # A repeated two-person booking collects the names of both new attendees,
    # not the account holder's name a second time.
    repeat_two_state = State({"event_id": 51, "user_id": 501, "max_count": 2, "allow_duplicate": True})
    repeat_two_message = Message()
    asyncio.run(funcs["_process_booking_count"](2, repeat_two_message, repeat_two_state, 35001))
    assert repeat_two_state.data["participants"] == []
    assert repeat_two_message.answers[-1][0].endswith("نام و نام خانوادگی نفر ۱ از ثبت‌نام جدید را یکجا وارد کنید:")
    asyncio.run(repeat_two_state.update_data(current_first_name="Friend", current_last_name="One"))
    asyncio.run(funcs["_append_current_non_booker_and_continue"](repeat_two_message, repeat_two_state))
    assert repeat_two_state.data["participants"] == [{"first_name": "Friend", "last_name": "One"}]
    assert repeat_two_message.answers[-1][0].endswith("نام و نام خانوادگی نفر ۲ را یکجا وارد کنید:")
    asyncio.run(repeat_two_state.update_data(current_first_name="Friend", current_last_name="Two"))
    asyncio.run(funcs["_append_current_non_booker_and_continue"](repeat_two_message, repeat_two_state))
    assert repeat_two_state.summary == [
        {"first_name": "Friend", "last_name": "One"},
        {"first_name": "Friend", "last_name": "Two"},
    ]

    # An initial single-person booking still reuses the account profile and skips name entry.
    initial_state = State({"event_id": 51, "user_id": 501, "max_count": 3, "allow_duplicate": False})
    initial_message = Message()
    asyncio.run(funcs["_process_booking_count"](1, initial_message, initial_state, 35001))
    assert initial_state.data["participants"] == [{"first_name": "Sina", "last_name": "Ziaei"}]
    assert initial_state.summary == [{"first_name": "Sina", "last_name": "Ziaei"}]


def test_stale_callback_execution_is_popup_only_and_preserves_receipt_state():
    import asyncio
    from types import SimpleNamespace

    class StateName:
        def __init__(self, value): self.state = value
    class States:
        confirm = StateName("booking:confirm")

    class FakeState:
        def __init__(self): self.current = "booking:waiting_receipt"; self.cleared = False
        async def get_state(self): return self.current
        async def clear(self): self.cleared = True; self.current = None

    class FakeMessage:
        def __init__(self): self.sent = []; self.edited = []
        async def answer(self, *args, **kwargs): self.sent.append((args, kwargs))
        async def edit_text(self, *args, **kwargs): self.edited.append((args, kwargs))

    class FakeCallback:
        def __init__(self):
            self.from_user = SimpleNamespace(id=35002)
            self.message = FakeMessage()
            self.answers = []
        async def answer(self, text=None, show_alert=False): self.answers.append((text, show_alert))

    lock_pool = {}
    def lock_for(user_id):
        lock_pool.setdefault(user_id, asyncio.Lock())
        return lock_pool[user_id]

    finalize_calls = []
    async def fake_finalize(message, state, telegram_user):
        finalize_calls.append((message, telegram_user))
        # Yield once to simulate database/network work while a duplicate tap arrives.
        await asyncio.sleep(0)
        state.current = "booking:waiting_receipt"

    namespace = {
        "BookingStates": States,
        "_confirmation_lock_for": lock_for,
        "finalize_booking": fake_finalize,
    }
    funcs = _load_async_functions(USER_SOURCE, {"confirm_booking_callback", "cancel_booking_callback"}, namespace)

    # Concurrent taps must create only one reservation attempt. The second one
    # waits, sees the receipt state, and gets only Telegram's popup.
    active_state = FakeState()
    active_state.current = States.confirm.state
    first_callback = FakeCallback()
    second_callback = FakeCallback()
    async def tap_twice():
        await asyncio.gather(
            funcs["confirm_booking_callback"](first_callback, active_state),
            funcs["confirm_booking_callback"](second_callback, active_state),
        )
    asyncio.run(tap_twice())
    assert len(finalize_calls) == 1
    assert active_state.current == "booking:waiting_receipt"
    assert sum(answer == [(None, False)] for answer in (first_callback.answers, second_callback.answers)) == 1
    assert sum(answer == [("ثبت‌نام قبلی دیگر فعال نیست.", True)] for answer in (first_callback.answers, second_callback.answers)) == 1
    assert first_callback.message.sent == second_callback.message.sent == []

    # Older confirm/cancel buttons must not clear receipt state or add chat messages.
    stale_state = FakeState()
    callback = FakeCallback()
    asyncio.run(funcs["confirm_booking_callback"](callback, stale_state))
    assert callback.answers == [("ثبت‌نام قبلی دیگر فعال نیست.", True)]
    assert callback.message.sent == []
    assert not stale_state.cleared
    assert stale_state.current == "booking:waiting_receipt"

    callback2 = FakeCallback()
    asyncio.run(funcs["cancel_booking_callback"](callback2, stale_state))
    assert callback2.answers == [("ثبت‌نام قبلی دیگر فعال نیست.", True)]
    assert callback2.message.sent == []
    assert callback2.message.edited == []
    assert not stale_state.cleared
