from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from app.db.models import AppSetting
from app.services import app_settings as service
from app.services.app_settings import get_bot_settings, set_setting, validate_admin_setting_value

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize(
    ("key", "raw", "expected"),
    [
        ("community_group_url", "https://t.me/panelflowgroup", "https://t.me/panelflowgroup"),
        ("community_channel_url", "https://telegram.me/panelflow", "https://telegram.me/panelflow"),
        ("community_instagram_url", "https://www.instagram.com/panelflow/", "https://www.instagram.com/panelflow/"),
        ("payment_card_number", "۱۲۳۴۵۶۷۸۱۲۳۴۵۶۷۰", "1234567812345670"),
        ("payment_account_name", "سینا ضیائی", "سینا ضیائی"),
    ],
)
def test_v65_valid_settings_normalize(key, raw, expected):
    assert validate_admin_setting_value(key, raw) == expected


@pytest.mark.parametrize(
    ("key", "raw"),
    [
        ("community_group_url", "http://t.me/example"),
        ("community_group_url", "https://evil.example/group"),
        ("community_group_url", "https://t.me:0/group"),
        ("community_channel_url", "https://t.me/"),
        ("community_instagram_url", "https://instagram.com/"),
        ("payment_card_number", "1234"),
        ("payment_card_number", "1111111111111111"),
        ("payment_card_number", "1234567812345678"),
        ("payment_account_name", "علی"),
        ("payment_account_name", "https://example.com name"),
    ],
)
def test_v65_invalid_settings_are_rejected(key, raw):
    with pytest.raises(ValueError):
        validate_admin_setting_value(key, raw)


class _FakeResult:
    def __init__(self, row):
        self.row = row

    def scalar_one_or_none(self):
        return self.row

    def scalars(self):
        return self

    def all(self):
        if isinstance(self.row, list):
            return self.row
        return [self.row] if self.row is not None else []


class _FakeSettingsSession:
    """Tiny in-memory DB double for exercising settings read/write across sessions."""
    def __init__(self, backing):
        self.backing = backing
        self.added = []
        self.query_count = 0

    async def execute(self, statement):
        self.query_count += 1
        criterion = statement.whereclause
        value = criterion.right.value
        if isinstance(value, (tuple, list, set)):
            return _FakeResult([self.backing[key] for key in value if key in self.backing])
        return _FakeResult(self.backing.get(value))

    def add(self, row):
        self.added.append(row)
        self.backing[row.key] = row

    async def commit(self):
        for row in self.added:
            self.backing[row.key] = row
        self.added.clear()



def test_v65_settings_survive_new_session_and_seed_does_not_overwrite_saved_values(monkeypatch):
    backing = {}
    defaults = {
        "community_group_url": "https://t.me/oldgroup",
        "community_channel_url": "https://t.me/oldchannel",
        "community_instagram_url": "https://www.instagram.com/old/",
        "community_website_url": "",
        "payment_card_number": "1234567812345670",
        "payment_account_name": "Old Cardholder",
    }
    monkeypatch.setattr(service, "_bot_setting_default", lambda key: defaults[key])

    async def scenario():
        first = _FakeSettingsSession(backing)
        await service.seed_bot_settings(first)
        values_before = await get_bot_settings(first)
        assert values_before["payment_card_number"] == "1234567812345670"

        await set_setting(first, "community_group_url", "https://t.me/newgroup")
        await set_setting(first, "payment_card_number", "1234567812345670")
        await first.commit()

        # A fresh session object simulates application restart/read-after-write.
        restarted = _FakeSettingsSession(backing)
        await service.seed_bot_settings(restarted)
        values_after = await get_bot_settings(restarted)
        assert values_after["community_group_url"] == "https://t.me/newgroup"
        assert values_after["community_channel_url"] == "https://t.me/oldchannel"

    asyncio.run(scenario())


def test_v65_admin_settings_menu_and_guarded_callbacks_are_wired():
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    menu = keyboards.split("def admin_menu(", 1)[1].split("def admin_content_hub_keyboard", 1)[0]
    settings_menu = keyboards.split("def admin_settings_keyboard(", 1)[1].split("def admin_settings_hub_keyboard", 1)[0]
    assert 'text="⚙️ تنظیمات و مدیریت بات", callback_data="admin:settings:hub"' in menu
    assert 'text="🌐 لینک وب‌سایت"' in settings_menu
    for key in ("community_group_url", "community_channel_url", "community_instagram_url", "community_website_url"):
        assert key in admin
    assert "_authorize_admin_settings_callback(c)" in admin[admin.index('async def admin_settings_home'):admin.index('async def stale_admin_callback')]
    assert 'chat_type != "private"' in admin[admin.index('async def _authorize_admin_settings_callback'):admin.index('def _admin_settings_text')]
    assert "AdminSettingsStates.confirming_card.state" in admin
    assert "reveal_card" not in settings_menu
    assert "شماره کارت به‌صورت پوشیده نمایش داده می‌شود" not in admin
    assert "admin:settings:cancel" in keyboards
    assert 'details={"setting": "payment_card_details"}' in admin
    # Audit records name only the setting group, never the entered card value.
    assert 'details={"setting": "payment_card_details", "card_number": card_number}' not in admin


def test_v65_user_interfaces_resolve_links_and_payment_details_from_database():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert "community_keyboard(community_values)" in user
    assert "await _payment_details()" in user
    assert "settings.payment_card_number" not in user
    assert "settings.payment_account_name" not in user
    assert 'values.get("community_channel_url")' in keyboards
    assert 'values.get("community_group_url")' in keyboards
    assert 'values.get("community_instagram_url")' in keyboards


def test_v65_migration_is_additive_and_archive_does_not_delete_panel_pdfs():
    migration = (ROOT / "migrations/026_v65_admin_settings.sql").read_text(encoding="utf-8").lower()
    assert "insert into app_settings" in migration
    assert "on conflict (key) do nothing" in migration
    assert "drop table" not in migration and "delete from" not in migration
    maintenance = (ROOT / "app/services/upload_maintenance.py").read_text(encoding="utf-8")
    assert "cleanup_archived_panel_pdfs_once" not in maintenance
    assert "await cleanup_expired_receipts_once" in maintenance  # existing V64 receipt behavior preserved
    docs = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "V65 Admin Settings" in docs


class _DummyState:
    def __init__(self, current=None, data=None):
        self.current = current
        self.data = dict(data or {})

    async def get_state(self):
        return self.current

    async def get_data(self):
        return dict(self.data)

    async def update_data(self, **kwargs):
        self.data.update(kwargs)

    async def set_state(self, state):
        self.current = getattr(state, "state", state)

    async def clear(self):
        self.current = None
        self.data.clear()


class _FakeTarget:
    def __init__(self, chat_type="private"):
        self.chat = type("Chat", (), {"type": chat_type})()
        self.last_text = None
        self.last_markup = None
        self.answers = []

    async def edit_text(self, text, **kwargs):
        self.last_text = text
        self.last_markup = kwargs.get("reply_markup")

    async def answer(self, *args, **kwargs):
        self.answers.append((args, kwargs))


class _FakeCallback:
    def __init__(self, data, message=None, user_id=12345):
        self.data = data
        self.message = message or _FakeTarget()
        self.from_user = type("User", (), {"id": user_id})()
        self.answers = []

    async def answer(self, *args, **kwargs):
        self.answers.append((args, kwargs))


class _FakeSessionContext:
    def __init__(self, backing):
        self.session = _FakeSettingsSession(backing)

    async def __aenter__(self):
        return self.session

    async def __aexit__(self, exc_type, exc, tb):
        return False


class _FakeSessionFactory:
    def __init__(self, backing):
        self.backing = backing

    def __call__(self):
        return _FakeSessionContext(self.backing)


def test_v65_link_confirmation_saves_value_and_cancel_does_not_write(monkeypatch):
    pytest.importorskip("aiogram")
    from app.bot.handlers import admin as admin_handlers
    from app.bot.states import AdminSettingsStates

    backing = {
        "community_group_url": AppSetting(key="community_group_url", value="https://t.me/original"),
        "community_channel_url": AppSetting(key="community_channel_url", value="https://t.me/panelflow"),
        "community_instagram_url": AppSetting(key="community_instagram_url", value="https://www.instagram.com/panelflow/"),
        "payment_card_number": AppSetting(key="payment_card_number", value="1234567812345670"),
        "payment_account_name": AppSetting(key="payment_account_name", value="Sina Ziaei"),
    }
    monkeypatch.setattr(admin_handlers, "SessionLocal", _FakeSessionFactory(backing))
    monkeypatch.setattr(admin_handlers, "_authorize_admin_settings_callback", _allow_admin_settings)
    monkeypatch.setattr(admin_handlers, "write_admin_action", _noop_audit)

    async def scenario():
        draft = _DummyState(
            AdminSettingsStates.confirming_link.state,
            {"settings_field": "community_group_url", "settings_pending_value": "https://t.me/newgroup"},
        )
        c = _FakeCallback("admin:settings:confirm_link")
        await admin_handlers.admin_settings_confirm_link(c, draft)
        assert backing["community_group_url"].value == "https://t.me/newgroup"
        assert draft.current is None
        assert "تنظیمات ربات" in c.message.last_text

        before = backing["community_group_url"].value
        cancel_state = _DummyState(AdminSettingsStates.waiting_link.state, {"settings_field": "community_group_url"})
        cancel_cb = _FakeCallback("admin:settings:cancel")
        await admin_handlers.admin_settings_cancel(cancel_cb, cancel_state)
        assert backing["community_group_url"].value == before
        assert cancel_state.current is None

    asyncio.run(scenario())


def test_v65_card_confirmation_updates_both_fields_atomically_without_auditing_values(monkeypatch):
    pytest.importorskip("aiogram")
    from app.bot.handlers import admin as admin_handlers
    from app.bot.states import AdminSettingsStates

    backing = {
        "community_group_url": AppSetting(key="community_group_url", value="https://t.me/group"),
        "community_channel_url": AppSetting(key="community_channel_url", value="https://t.me/channel"),
        "community_instagram_url": AppSetting(key="community_instagram_url", value="https://www.instagram.com/panelflow/"),
        "payment_card_number": AppSetting(key="payment_card_number", value="1234567812345670"),
        "payment_account_name": AppSetting(key="payment_account_name", value="Old Name"),
    }
    audit = []
    async def capture_audit(session, **kwargs):
        audit.append(kwargs)
    monkeypatch.setattr(admin_handlers, "SessionLocal", _FakeSessionFactory(backing))
    monkeypatch.setattr(admin_handlers, "_authorize_admin_settings_callback", _allow_admin_settings)
    monkeypatch.setattr(admin_handlers, "write_admin_action", capture_audit)

    async def scenario():
        draft = _DummyState(
            AdminSettingsStates.confirming_card.state,
            {"settings_pending_card_number": "1234567812345670", "settings_pending_cardholder_name": "Sina Ziaei"},
        )
        c = _FakeCallback("admin:settings:confirm_card")
        await admin_handlers.admin_settings_confirm_card(c, draft)
        assert backing["payment_card_number"].value == "1234567812345670"
        assert backing["payment_account_name"].value == "Sina Ziaei"
        assert draft.current is None
        assert audit and audit[0]["details"] == {"setting": "payment_card_details"}
        assert "card_number" not in str(audit[0])

    asyncio.run(scenario())


def test_v65_settings_callbacks_reject_non_admin_and_group_chat(monkeypatch):
    pytest.importorskip("aiogram")
    from app.bot.handlers import admin as admin_handlers

    async def scenario():
        c = _FakeCallback("admin:settings:reveal_card", _FakeTarget(chat_type="group"))
        async def yes_admin(_user_id):
            return True
        async def no_admin(_user_id):
            return False
        monkeypatch.setattr(admin_handlers, "is_admin", yes_admin)
        assert await admin_handlers._authorize_admin_settings_callback(c) is False
        assert c.answers and c.answers[-1][1].get("show_alert") is True

        c2 = _FakeCallback("admin:settings:reveal_card", _FakeTarget(chat_type="private"))
        monkeypatch.setattr(admin_handlers, "is_admin", no_admin)
        assert await admin_handlers._authorize_admin_settings_callback(c2) is False
        assert c2.answers and c2.answers[-1][1].get("show_alert") is True

    asyncio.run(scenario())


async def _allow_admin_settings(_callback):
    return True


async def _noop_audit(_session, **_kwargs):
    return None


def test_v65_database_startup_seeds_only_legacy_defaults_and_preserves_nonblank_rows(monkeypatch):
    from app.config import settings as config
    from app.db import init as db_init

    class FakeConnection:
        def __init__(self):
            self.statements = []
        async def execute(self, statement, parameters):
            self.statements.append((str(statement), dict(parameters)))

    monkeypatch.setattr(config, "panel_flow_group_url", "https://t.me/initial-group")
    monkeypatch.setattr(config, "panel_flow_channel_url", "https://t.me/initial-channel")
    monkeypatch.setattr(config, "panel_flow_instagram_url", "https://www.instagram.com/initial/")
    monkeypatch.setattr(config, "payment_card_number", "1234567812345670")
    monkeypatch.setattr(config, "payment_account_name", "Initial Name")
    conn = FakeConnection()
    asyncio.run(db_init._seed_v65_bot_settings(conn))

    assert len(conn.statements) == 5
    assert {params["key"] for _, params in conn.statements} == {
        "community_group_url", "community_channel_url", "community_instagram_url",
        "payment_card_number", "payment_account_name",
    }
    assert all("on conflict (key) do update" in sql.lower() for sql, _ in conn.statements)
    assert all("where btrim(coalesce(app_settings.value, '')) = ''" in sql.lower() for sql, _ in conn.statements)
    assert not any("card" in sql.lower() and params["value"] in sql for sql, params in conn.statements)
