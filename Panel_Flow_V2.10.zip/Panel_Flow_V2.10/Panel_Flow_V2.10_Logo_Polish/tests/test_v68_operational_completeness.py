from __future__ import annotations

from pathlib import Path

from app.db.models import Base, Event, AttendanceStatus

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_attendance_is_optional_per_panel_and_has_auditable_admin_controls():
    event = Base.metadata.tables["events"].columns
    assert "attendance_enabled" in event and event["attendance_enabled"].nullable is False
    assert event["attendance_enabled"].server_default is not None
    assert "attendance_checkin_token_hash" in event and "attendance_checkin_code_hash" in event
    assert "feedback_enabled" in event and event["feedback_enabled"].nullable is False
    migration = read("migrations/028_v68_phase2_operational_completeness.sql").lower()
    assert "default false" in migration
    assert "attendance_audits" in migration and "topic_votes" in migration
    assert "drop table" not in migration and "truncate" not in migration

    attendance = read("app/bot/handlers/attendance.py")
    assert "admin:attendance:toggle:" in attendance
    assert "admin:attendance:roster:" in attendance
    assert "admin:attendance:bulk:confirm:" in attendance
    assert "AttendanceAudit(" in attendance
    assert "qrcode.make(link)" in attendance
    assert "Command(\"checkin\")" in attendance
    assert 'payload.startswith("checkin_")' in read("app/bot/handlers/user.py")
    assert "Booking.booked_by_user_id == user.id" in attendance
    assert "if not event.attendance_enabled" in attendance
    assert AttendanceStatus.UNMARKED.value == "unmarked"


def test_specialized_user_routers_precede_the_stale_user_callback_fallback():
    main = read("app/bot/main.py")
    assert main.index("dp.include_router(attendance_router)") < main.index("dp.include_router(user_router)")
    assert main.index("dp.include_router(topics_user_router)") < main.index("dp.include_router(user_router)")
    keyboards = read("app/bot/keyboards.py")
    assert 'callback_data="user:topics"' in keyboards
    assert 'callback_data=f"admin:attendance:{event_id}"' in keyboards
    assert "📋 حضور و غیاب (اختیاری)" in keyboards


def test_legacy_admin_draft_snapshots_are_retained_but_dormant():
    """The removed resume feature must not cause per-update DB snapshot writes or data loss."""
    service = read("app/services/admin_drafts.py")
    middleware = read("app/bot/middleware.py")
    handlers = read("app/bot/handlers/admin_features.py")
    main = read("app/bot/main.py")
    model = Base.metadata.tables
    assert "AdminDraftSnapshot" in service and "admin_draft_snapshots" in model
    assert "PersistentAdminDraftMiddleware" not in middleware
    assert "persist_admin_draft" not in middleware
    assert "PersistentAdminDraftMiddleware" not in main
    assert "admin:draft:resume" not in handlers and "admin:draft:discard" not in handlers


def test_concurrent_upload_quota_uses_reservations_and_final_atomic_promotion():
    upload = read("app/bot/handlers/admin_utils.py")
    quota = read("app/services/upload_quota.py")
    assert "fcntl.flock" in quota
    assert ".quota-reservations" in quota
    assert "reservation_bytes(root)" in upload
    assert "used + reserved + reserve_bytes > quota" in upload
    assert "used + reserved_other + actual > quota" in upload
    assert "os.replace(temp_path, final_path)" in upload
    assert "_refresh_upload_reservation" in upload
    assert "cleanup_stale_upload_artifacts_unlocked" in quota


def test_v68_settings_are_used_or_removed_and_dashboard_surfaces_storage_pressure():
    config = read("app/config.py")
    compose = read("docker-compose.yml")
    example = read(".env.example")
    dashboard = read("app/bot/handlers/admin_features.py")
    assert "EXPENSIVE_OPERATION_CONCURRENCY" not in config
    assert "EXPENSIVE_OPERATION_CONCURRENCY" not in compose
    assert "UPLOAD_STORAGE_WARNING_PERCENT" in compose and "UPLOAD_STORAGE_CRITICAL_PERCENT" in compose
    assert "upload_storage_warning_percent" in dashboard and "upload_storage_critical_percent" in dashboard
    assert "UPLOAD_STORAGE_WARNING_PERCENT" in example


def test_topic_suggestions_are_moderated_and_votes_are_unique_per_user():
    topics = read("app/bot/handlers/topics.py")
    migration = read("migrations/028_v68_phase2_operational_completeness.sql").lower()
    assert "status=\"pending\"" in topics
    assert "admin:topics:status:" in topics
    assert "uq_topic_votes_topic_user unique(topic_id, user_id)" in migration
    assert 'callback_data="user:topics"' in topics
    assert 'callback_data="admin:topics"' in read("app/bot/keyboards.py")


def test_release_docs_and_version_markers_are_current():
    readme = read("README.md")
    startup = read("app/db/init.py")
    backup = read("scripts/backup.sh")
    assert readme.startswith("# Panel Flow — V2.06")
    assert "028_v68_phase2_operational_completeness.sql" in readme
    assert "Panel Flow V97 database initialization started" in startup
    pg_tests = read("tests/test_v70_postgres_integration.py")
    assert "is_explicit_test_database" in pg_tests and "(?:^|[_-])test(?:$|[_-])" in pg_tests
    assert "release=V97" in backup
    assert "scheduled reminders were not added" in readme.lower()


def test_upload_quota_reservations_reject_one_of_two_concurrent_uploads(tmp_path, monkeypatch):
    """Exercise the actual quota reservation path without Telegram/network access."""
    import asyncio
    import importlib.util
    import sys
    from types import ModuleType

    # admin_utils only needs Bot as a typing import; the fake avoids requiring an
    # installed Telegram client in lightweight QA environments.
    fake_aiogram = ModuleType("aiogram")
    fake_aiogram.Bot = object
    monkeypatch.setitem(sys.modules, "aiogram", fake_aiogram)
    spec = importlib.util.spec_from_file_location(
        "panel_flow_admin_utils_quota_v68", ROOT / "app/bot/handlers/admin_utils.py"
    )
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)

    from app.config import settings
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))
    monkeypatch.setattr(settings, "max_upload_mb", 2)
    monkeypatch.setattr(settings, "max_upload_storage_mb", 1)
    monkeypatch.setattr(settings, "upload_min_free_mb", 0)

    class FakeBot:
        async def download(self, file_id, destination):
            await __import__("asyncio").sleep(0.05)
            Path(destination).write_bytes(bytes([int(file_id)]) * 600_000)

    async def run():
        results = await __import__("asyncio").gather(
            module.download_file(FakeBot(), "1", "one.pdf", file_size=600_000),
            module.download_file(FakeBot(), "2", "two.pdf", file_size=600_000),
            return_exceptions=True,
        )
        successful = [result for result in results if isinstance(result, str)]
        failures = [result for result in results if isinstance(result, BaseException)]
        assert len(successful) == 1, results
        assert len(failures) == 1 and isinstance(failures[0], OSError), results
        files = [path for path in tmp_path.iterdir() if path.is_file() and path.suffix == ".pdf"]
        assert len(files) == 1 and files[0].stat().st_size == 600_000
        assert not list((tmp_path / ".quota-reservations").glob("*.reserve"))

    asyncio.run(run())
