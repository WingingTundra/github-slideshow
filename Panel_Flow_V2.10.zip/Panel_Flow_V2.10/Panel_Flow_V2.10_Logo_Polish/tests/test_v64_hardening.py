from __future__ import annotations
import asyncio
from pathlib import Path

from app.services.rate_limiter import InMemoryLimiter


def test_rate_limiter_burst_then_refill_and_rolling_window():
    now=[0.0]
    limiter=InMemoryLimiter(max_keys=20,clock=lambda:now[0])
    async def scenario():
        results=[]
        for _ in range(5):
            results.append((await limiter.allow(10,'message',ceiling=12,window=12,burst=4,refill=1))[0])
        assert results == [True,True,True,True,False]
        now[0]=1.0
        assert (await limiter.allow(10,'message',ceiling=12,window=12,burst=4,refill=1))[0] is True
    asyncio.run(scenario())


def test_rate_limiter_separates_callbacks_and_bounds_state():
    now=[0.0]
    limiter=InMemoryLimiter(max_keys=8,clock=lambda:now[0])
    async def scenario():
        assert (await limiter.allow(1,'message',ceiling=1,window=12,burst=1,refill=1))[0]
        assert (await limiter.allow(1,'callback',ceiling=1,window=12,burst=1,refill=1))[0]
        for uid in range(2,30):
            await limiter.allow(uid,'message',ceiling=1,window=12,burst=1,refill=1)
        assert len(limiter._state) <= 8
        now[0]=1000
        await limiter.allow(50,'message',ceiling=1,window=12,burst=1,refill=1)
        assert len(limiter._state) <= 8
    asyncio.run(scenario())


def test_v64_archive_timestamp_migration_remains_additive_but_v65_disables_pdf_retention_cleanup():
    root=Path(__file__).resolve().parents[1]
    migration=(root/'migrations/025_v64_archived_pdf_retention.sql').read_text()
    assert 'ADD COLUMN IF NOT EXISTS archived_at TIMESTAMP NULL' in migration
    assert 'WHERE archived = TRUE AND archived_at IS NULL' in migration
    maintenance=(root/'app/services/upload_maintenance.py').read_text()
    assert 'cleanup_archived_panel_pdfs_once' not in maintenance
    assert 'await cleanup_expired_receipts_once' in maintenance
    env=(root/'.env.example').read_text()
    assert 'MAX_UPLOAD_MB=10' in env and 'ARCHIVED_PANEL_FILE_RETENTION_DAYS=' not in env


def test_admin_home_prioritizes_create_and_manage_panels():
    source=(Path(__file__).resolve().parents[1]/'app/bot/keyboards.py').read_text()
    menu=source.split('def admin_menu(',1)[1].split('def admin_user_access_keyboard',1)[0]
    assert menu.index('callback_data="admin:event:create"') < menu.index('callback_data="admin:events"')
    assert menu.index('callback_data="admin:events"') < menu.index('callback_data="admin:announcements"')
