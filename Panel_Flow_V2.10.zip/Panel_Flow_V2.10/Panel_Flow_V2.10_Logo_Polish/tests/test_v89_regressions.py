from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def function_source(text: str, name: str) -> str:
    tree = ast.parse(text)
    node = next(
        item for item in tree.body
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name
    )
    return ast.get_source_segment(text, node) or ""


def test_start_welcome_and_main_keyboard_are_sent_together():
    user = source("app/bot/handlers/user.py")
    start = function_source(user, "start")
    assert "main_menu_welcome_text()" in start
    assert "reply_markup=main_menu()" in start
    assert "edit_reply_markup(reply_markup=main_menu())" not in start
    assert "Send the welcome copy and the main inline keyboard together" in start


def test_v90_removes_support_ticket_feature_but_keeps_panel_reviews():
    models = source("app/db/models.py")
    assert "class SupportTicket(Base)" not in models
    assert "class SupportTicketMessage(Base)" not in models
    assert not (ROOT / "app/bot/handlers/support_tickets.py").exists()
    main = source("app/bot/main.py")
    assert "support_tickets_router" not in main
    keyboards = source("app/bot/keyboards.py")
    user_menu = function_source(keyboards, "main_menu")
    assert 'text="📝 ثبت نظر", callback_data="user:reviews"' in user_menu
    content_hub = function_source(keyboards, "admin_content_hub_keyboard")
    assert "تیکت" not in content_hub
    reply_menu = source("app/bot/handlers/reply_menu.py")
    assert '"📝 ثبت نظر": "reviews"' in reply_menu
    reviews = source("app/bot/handlers/user.py")
    assert '@router.callback_query(F.data == "user:reviews")' in reviews
    migration = source("migrations/040_v90_remove_support_ticket_tables.sql").lower()
    assert "drop table if exists support_ticket_messages" in migration
    assert "drop table if exists support_tickets" in migration


def test_panel_creation_is_idempotent_under_double_confirmation():
    models = source("app/db/models.py")
    event = function_source(models, "__repr__") if "def __repr__" in models else models
    assert "creation_token: Mapped[str | None]" in event
    assert "uq_events_creation_token" in event
    migration = source("migrations/039_v89_event_creation_idempotency.sql")
    assert "CREATE UNIQUE INDEX IF NOT EXISTS uq_events_creation_token" in migration
    admin = source("app/bot/handlers/admin.py")
    finish = function_source(admin, "_finish_event_creation")
    assert "creation_token=creation_token" in finish
    assert "except IntegrityError" in finish
    assert "select(Event).where(Event.creation_token == token)" in finish
    console = source("app/bot/handlers/admin_console.py")
    host_finish = function_source(console, "_finish_host_event_creation")
    assert "creation_token=creation_token" in host_finish
    assert "except IntegrityError" in host_finish
    assert "select(Event).where(Event.creation_token == token)" in host_finish
    assert "secrets.token_hex(16)" in function_source(admin, "_creation_prompt")


def test_creation_token_unique_index_rejects_duplicate_panel_inserts():
    import pytest
    from sqlalchemy import create_engine
    from sqlalchemy.exc import IntegrityError
    from app.db.models import Base, Event

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with engine.begin() as connection:
        values = dict(
            volume="V89", title="Idempotency test", venue="Test venue",
            capacity=10, price_per_person=1000, creation_token="a" * 32,
        )
        connection.execute(Event.__table__.insert().values(**values))
        with pytest.raises(IntegrityError):
            connection.execute(Event.__table__.insert().values(**values))
    engine.dispose()


def test_panel_wizard_callbacks_are_bound_to_current_instance_and_prompt():
    admin = source("app/bot/handlers/admin.py")
    validate = function_source(admin, "_validate_creation_callback")
    assert "event_creation_token" in validate
    assert "event_creation_prompt_message_id" in validate
    assert "clicked_message_id != expected_message_id" in validate
    assert "creator_telegram_id" in validate
    assert "AdminEventStates:" in validate
    for name in ("create_event_step_back", "cancel_event_creation", "save_event_draft", "publish_event"):
        if f"def {name}" in admin:
            body = function_source(admin, name)
            assert "_validate_creation_callback" in body
    host = source("app/bot/handlers/admin_console.py")
    for name in ("host_create_save_draft", "host_create_submit"):
        body = function_source(host, name)
        assert "event_creation_token" in body
        assert "event_creation_prompt_message_id" in body
        assert "creator_telegram_id" in body
    assert "host:event:create:draft" in host and "host:event:create:submit" in host


def test_receipt_context_cannot_be_switched_by_stale_booking_buttons():
    user = source("app/bot/handlers/user.py")
    continue_flow = function_source(user, "continue_receipt_upload")
    retry = function_source(user, "retry_receipt")
    save = function_source(user, "_save_receipt")
    assert "await state.clear()" not in continue_flow
    assert "await state.clear()" not in retry
    assert "active_booking_id" in continue_flow
    assert "active_booking_id" in retry
    assert "if active_booking_id != booking_id" in continue_flow
    assert "if active_booking_id != booking_id" in retry
    assert "BookingStates.waiting_receipt.state" in save
    assert "booking_id" in save and "state.get_data()" in save


def test_channel_announcement_is_a_real_post_with_inline_registration_button():
    admin = source("app/bot/handlers/admin_console.py")
    preview = function_source(admin, "panel_channel_announcement_preview")
    publish = function_source(admin, "publish_panel_channel_announcement")
    keyboard = function_source(admin, "_channel_post_keyboard")
    body = function_source(admin, "_panel_channel_post_text")
    assert "PanelAnnouncementPost" in preview
    assert "_channel_post_keyboard(post_id, registration_url)" in preview
    assert "send_message(" in publish
    assert "reply_markup=_channel_post_keyboard(post_id" in publish
    assert "get_chat_member" in publish and "can_post_messages" in publish
    assert 'url=registration_url' in keyboard
    assert "_registration_url" not in body
    assert 'status != "preview"' in publish  # Duplicate clicks cannot publish twice.
    assert "unknown" in publish and "TelegramNetworkError" in publish


def test_announcement_recovery_resumes_pending_and_never_blindly_resends_sending():
    admin = source("app/bot/handlers/admin_console.py")
    recovery = function_source(admin, "recover_interrupted_announcements")
    worker = function_source(admin, "_process_unified_announcement_locked")
    assert 'PanelAnnouncementPost.status == "sending"' in recovery
    assert 'post.status = "unknown"' in recovery
    assert 'AdminAnnouncement.status.in_(("sending", "partial"))' in recovery
    assert 'AdminAnnouncementDelivery.status == "sending"' in worker
    assert 'delivery.status = "unknown"' in worker
    assert 'AdminAnnouncementDelivery.status == "pending"' in worker
    assert "pg_try_advisory_lock" in function_source(admin, "_process_unified_announcement")


def test_archive_and_permanent_delete_remove_all_panel_announcement_history():
    admin = source("app/bot/handlers/admin.py")
    for handler_name in ("event_archive_confirm", "event_delete_confirm"):
        section = function_source(admin, handler_name)
        assert "delete(AdminAnnouncement)" in section
        assert "delete(PanelAnnouncementPost)" in section
        assert "delete(AnnouncementBroadcast)" in section


def test_attention_center_has_actionable_counts_and_direct_queue_destinations():
    dashboard = source("app/bot/handlers/admin_features.py")
    center = function_source(dashboard, "admin_attention_center")
    for model in (
        "Payment", "DiscountRedemption", "Event", "Question", "TopicSuggestion",
        "Review", "ShopRequest", "RewardIssue", "AdminAnnouncement",
    ):
        assert model in center
    for callback in (
        "admin:pending_payments:page:0", "admin:discount:requests:page:0",
        "admin:console:reviews", "admin:questions", "admin:topics", "admin:reviews",
        "admin:v77:shop:queue:0", "admin:v77:rewards:queue:0",
        "admin:announcements",
    ):
        assert callback in center
    assert "مواردی که برای بررسی یا اقدام مدیر در صف هستند" in center


def test_updated_menus_help_and_copy_are_consistent():
    keyboards = source("app/bot/keyboards.py")
    main = function_source(keyboards, "main_menu")
    assert main.index('text="🏠 پنل‌های پیش‌رو"') < main.index('text="🎟 ثبت‌نام‌های من"')
    assert main.index('text="📄 سؤالات پنل‌ها"') < main.index('text="📚 پنل‌های گذشته"')
    assert 'text="📝 ثبت نظر", callback_data="user:reviews"' in main
    admin_menu = function_source(keyboards, "admin_menu")
    assert admin_menu.index('text="📋 مدیریت پنل‌ها"') < admin_menu.index('text="📣 اطلاع‌رسانی‌ها"')
    assert admin_menu.index('text="🎯 مدیریت چالش‌ها"') < admin_menu.index('text="📊 داشبورد مدیریتی"')
    assert admin_menu.rstrip().endswith('])')
    assert 'text="⚙️ تنظیمات و مدیریت بات"' in admin_menu
    community = function_source(keyboards, "community_menu_keyboard")
    for label in ("لیدربورد ⁦Panel Flow⁩", "Giveaways", "پاسپورت من"):
        assert label in community
    assert 'text="\\u2067🛍 ⁦XP⁩ شاپ\\u2069"' in community
    about = function_source(keyboards, "community_keyboard")
    for label in ("Telegram Channel", "Telegram Group", "Instagram", "Website"):
        assert label in about
    content = source("app/bot/content.py")
    help_text = function_source(content, "user_help_text")
    assert "ثبت نظر و تیکت" not in help_text and "تیکت" not in help_text
    assert "Giveaways" in help_text and "پاسپورت من" in help_text
    user = source("app/bot/handlers/user.py")
    assert "فایل سؤالات این پنل موقتاً در دسترس نیست" not in user
    assert "🔗 لینک‌های رسمی" not in user


def test_v89_migrations_are_additive_and_config_rejects_positive_channel_targets():
    migration_037 = source("migrations/037_v89_support_tickets_and_channel_posts.sql").lower()
    migration_038 = source("migrations/038_v89_support_ticket_attachments.sql").lower()
    cleanup_040 = source("migrations/040_v90_remove_support_ticket_tables.sql").lower()
    assert "create table if not exists panel_announcement_posts" in migration_037
    assert "on delete cascade" in migration_037
    assert "drop table if exists support_ticket_messages" in cleanup_040
    assert "drop table if exists support_tickets" in cleanup_040
    assert "truncate" not in cleanup_040
    config = source("app/config.py")
    assert "def empty_channel_id_is_unconfigured" in config
    assert "parsed >= 0" in config
    assert "negative Telegram channel/group ID" in config


def test_current_release_marker_and_docs_match_the_migrations():
    readme = source("README.md")
    marker = source("app/db/init.py")
    assert readme.startswith("# Panel Flow — V2.06")
    assert "single installation" in readme.lower()
    assert "039_v89_event_creation_idempotency.sql" in readme
    assert "040_v90_remove_support_ticket_tables.sql" in readme
    assert "Panel Flow V97 database initialization started" in marker
    assert Path(ROOT / "V93_CHANGELOG.md").exists()
    assert Path(ROOT / "V93_DEPLOYMENT_NOTES.md").exists()
    assert Path(ROOT / "V93_QA_REPORT.md").exists()


def test_v90_migration_drops_only_ticket_tables_and_preserves_panel_posts():
    import sqlite3
    from app.db.migration_utils import split_sql_statements

    migration = source("migrations/040_v90_remove_support_ticket_tables.sql")
    statements = split_sql_statements(migration)
    assert len(statements) == 2
    connection = sqlite3.connect(":memory:")
    connection.executescript(
        "CREATE TABLE support_tickets (id INTEGER PRIMARY KEY);"
        "CREATE TABLE support_ticket_messages (id INTEGER PRIMARY KEY);"
        "CREATE TABLE panel_announcement_posts (id INTEGER PRIMARY KEY);"
    )
    for statement in statements:
        connection.execute(statement)
    remaining = {row[0] for row in connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    )}
    assert "support_tickets" not in remaining
    assert "support_ticket_messages" not in remaining
    assert "panel_announcement_posts" in remaining
    connection.close()


def test_v90_admin_status_switches_have_clear_green_red_state_labels():
    keyboards = source("app/bot/keyboards.py")
    community = function_source(keyboards, "admin_community_menu")
    channel = function_source(keyboards, "channel_updates_keyboard")
    event = function_source(keyboards, "admin_event_menu")
    assert "🟢 لیدربورد عمومی: فعال" in community
    assert "🔴 لیدربورد عمومی: غیرفعال" in community
    assert "🟢 به‌روزرسانی خودکار کانال: فعال" in channel
    assert "🔴 به‌روزرسانی خودکار کانال: غیرفعال" in channel
    assert "🟢 ثبت‌نام باز است · بستن" in event
    assert "🔴 ثبت‌نام بسته است · بازگشایی" in event
    assert 'callback_data="admin:community:leaderboard:toggle"' in community
    assert 'callback_data="admin:channel_updates:toggle"' in channel
    assert "callback_data=f\"admin:event:{'close' if registration_open else 'reopen'}:{event_id}\"" in event
