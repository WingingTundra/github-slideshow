"""V94 coverage for the configurable rewards catalogue and community controls."""
from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError

from app.db.migration_utils import split_sql_statements
from app.db.models import Base

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = (ROOT / "migrations/042_v94_xp_shop_catalogue_community_controls.sql").read_text(encoding="utf-8")
NOTIFICATION_MIGRATION = (ROOT / "migrations/043_v94_challenge_result_notifications.sql").read_text(encoding="utf-8")
SHOP = (ROOT / "app/bot/handlers/v77_features.py").read_text(encoding="utf-8")
COMMUNITY = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
ADMIN = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
ADMIN_CONSOLE = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
KEYBOARDS = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
USER = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
XP_SERVICE = (ROOT / "app/services/community.py").read_text(encoding="utf-8")


def _function(source: str, name: str) -> str:
    tree = ast.parse(source)
    node = next(item for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name)
    return ast.get_source_segment(source, node) or ""


def test_v94_migrations_are_additive_and_cover_the_new_catalogue_controls():
    lowered = MIGRATION.lower()
    for expected in (
        "create table if not exists xp_shop_offers",
        "alter table shop_requests add column if not exists offer_id",
        "offer_title_snapshot",
        "offer_description_snapshot",
        "create table if not exists referral_verifications",
        "answer_notification_status",
        "xp_shop_enabled', 'false'",
        "community_xp_earning_enabled",
        "question_suggestions_enabled",
        "topic_suggestions_enabled",
        "between 1 and 100",
        "expires_at timestamp null",
    ):
        assert expected in lowered
    assert "('xp_shop_enabled', 'false'" in lowered
    assert "'تخفیف ۱۰۰ درصدی'" in lowered and "100, 160, false, 100" in lowered
    assert "drop constraint if exists ck_shop_request_percent" in lowered
    assert "drop constraint if exists ck_reward_issue_percent" in lowered
    assert not re.search(r"\b(drop\s+table|truncate\s+table|delete\s+from)\b", lowered)
    assert "create table if not exists challenge_result_notifications" in NOTIFICATION_MIGRATION.lower()
    assert "unique (challenge_id, telegram_id)" in NOTIFICATION_MIGRATION.lower()
    assert split_sql_statements(MIGRATION)
    assert split_sql_statements(NOTIFICATION_MIGRATION)


def test_v94_schema_builds_and_dynamic_discount_percentages_are_constrained():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with engine.begin() as connection:
        tables = set(connection.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table'").scalars())
        assert {"xp_shop_offers", "referral_verifications", "challenge_result_notifications"} <= tables
        offers = Base.metadata.tables["xp_shop_offers"]
        offer_id = connection.execute(offers.insert().values(
            title="Special 35%", discount_percent=35, xp_cost=55, active=True,
        )).inserted_primary_key[0]
        assert "expires_at" in offers.c
        requests = Base.metadata.tables["shop_requests"]
        connection.execute(requests.insert().values(
            telegram_id=101, offer_id=offer_id, offer_title_snapshot="Special 35%",
            discount_percent=35, xp_cost=55, status="pending",
        ))
        reward_issues = Base.metadata.tables["reward_issues"]
        connection.execute(reward_issues.insert().values(
            source_type="shop", source_id=1, telegram_id=101, discount_percent=35,
        ))
        for invalid_percent in (0, 101):
            with pytest.raises(IntegrityError):
                connection.execute(offers.insert().values(
                    title="Invalid", discount_percent=invalid_percent, xp_cost=10,
                ))
            with pytest.raises(IntegrityError):
                connection.execute(requests.insert().values(
                    telegram_id=102 + invalid_percent, discount_percent=invalid_percent,
                    xp_cost=10, status="pending",
                ))
            with pytest.raises(IntegrityError):
                connection.execute(reward_issues.insert().values(
                    source_type="shop", source_id=100 + invalid_percent,
                    telegram_id=200 + invalid_percent, discount_percent=invalid_percent,
                ))
        with pytest.raises(IntegrityError):
            connection.execute(offers.insert().values(title="No cost", discount_percent=20, xp_cost=0))
        with pytest.raises(IntegrityError):
            connection.execute(offers.insert().values(title="Bad cap", discount_percent=20, xp_cost=10, usage_limit=0))
    engine.dispose()


def test_global_pause_blocks_new_earned_xp_but_not_manual_adjustments_or_refunds():
    award = _function(XP_SERVICE, "award_once")
    assert "if points > 0" in award
    assert "await xp_earning_enabled(session)" in award
    assert '"admin_manual_adjustment", "shop_redemption_refund"' in award
    assert "points <= 0" not in award  # negative ledger corrections remain permitted


def test_shop_expiry_is_enforced_and_admin_can_set_or_clear_utc_expiry():
    from app.services import xp_shop
    availability = _function((ROOT / "app/services/xp_shop.py").read_text(encoding="utf-8"), "shop_offer_available")
    listing = _function((ROOT / "app/services/xp_shop.py").read_text(encoding="utf-8"), "list_shop_offers")
    assert "offer.expires_at <= utc_now_naive()" in availability
    assert "XPShopOffer.expires_at > now" in listing
    assert "shop_offer_expires" in SHOP
    assert '"expires":' in SHOP and '"expires":"expires_at"' in SHOP
    assert "YYYY-MM-DD HH:MM" in SHOP and "UTC" in SHOP
    assert r"(title|percent|cost|description|limit|expires)" in SHOP


def test_shop_new_request_boundary_revalidates_global_switch_offer_and_capacity():
    confirm = _function(SHOP, "_shop_request_confirm_for_offer")
    assert "await shop_is_enabled(session)" in confirm
    assert "XPShopOffer.id == offer_id" in confirm
    assert "await shop_offer_available(session, offer)" in confirm
    assert "with_for_update()" in confirm
    assert "offer_title_snapshot" in confirm
    render = _function(SHOP, "_render_shop")
    assert "if enabled" in render and "درخواست‌های اخیر" in render
    assert "سوابق امتیاز شما محفوظ" in render


def test_paused_suggestion_intake_hides_only_the_disabled_submit_button():
    keyboard = _function(KEYBOARDS, "suggestions_keyboard")
    render = _function(USER, "render_suggestions_menu")
    assert "if question_enabled" in keyboard and "if topics_enabled" in keyboard
    assert 'callback_data="user:topics"' in keyboard
    assert "question_enabled=question_enabled, topics_enabled=topics_enabled" in render


def test_passport_xp_history_and_community_switches_are_independent():
    history = _function(COMMUNITY, "community_xp_history")
    settings = _function(COMMUNITY, "admin_community_settings")
    assert "XPAward.telegram_id" in history
    assert "reserved_shop_xp" in history and "available_shop_xp" in history
    for key in ('"xp"', '"leaderboard"', '"shop"', '"question"', '"topics"'):
        assert key in settings
    assert "هر کنترل مستقل است" in settings


def test_suggestion_answers_notify_after_commit_and_support_retry():
    delivery = _function(ADMIN, "_deliver_question_answer_notification")
    assert delivery.index("await session.commit()") < delivery.index("await bot.send_message")
    assert 'answer_notification_status = "sent" if delivered else "failed"' in delivery
    assert 'admin:question:notify:' in ADMIN
    assert "_deliver_question_answer_notification(c.bot" in ADMIN


def test_referrals_are_admin_verified_with_audited_manual_stage():
    screen = _function(ADMIN_CONSOLE, "_render_user_referrals")
    toggle = _function(ADMIN_CONSOLE, "console_referral_verify_toggle")
    assert "attended_panel_count" in screen
    assert "ReferralVerification" in screen
    assert "await write_admin_action" in toggle
    assert "referral_manually_verified" in toggle
    assert "referral_manual_verification_revoked" in toggle
    assert "c.data =" not in toggle


def test_challenge_results_notify_submitters_and_allow_failed_delivery_retry():
    finalizer = _function(COMMUNITY, "_finalize_challenge_review")
    delivery = _function(COMMUNITY, "_deliver_challenge_result_notification")
    assert "ChallengeResultNotification(" in finalizer
    assert "await session.commit()" in finalizer
    assert "await _send_challenge_result_notifications(c.bot, cid)" in finalizer
    assert 'callback_data=f"community:challenge:view:{challenge_id}"' in delivery
    assert 'else "failed"' in delivery
    assert "admin:community:challenge:notifications:retry" in COMMUNITY
