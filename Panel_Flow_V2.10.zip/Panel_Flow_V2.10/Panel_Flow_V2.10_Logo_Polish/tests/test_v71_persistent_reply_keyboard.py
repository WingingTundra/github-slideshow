"""Source-level regression checks for the V71 Telegram reply keyboard.

These checks intentionally do not import aiogram, so they remain runnable in
minimal CI environments; the dependency-complete workflow also imports the bot.
"""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _source(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_reply_keyboard_is_native_persistent_and_resizable():
    tree = ast.parse(_source("app/bot/keyboards.py"))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "persistent_main_keyboard")
    source = ast.get_source_segment(_source("app/bot/keyboards.py"), function) or ""
    assert "ReplyKeyboardMarkup" in source
    assert "KeyboardButton" in source
    assert "is_persistent=True" in source
    assert "resize_keyboard=True" in source
    assert "one_time_keyboard=False" in source


def test_all_reply_keyboard_actions_have_handlers_and_match_the_keyboard_labels():
    keys_source = _source("app/bot/keyboards.py")
    router_source = _source("app/bot/handlers/reply_menu.py")
    labels = (
        "🏠 پنل‌های پیش‌رو", "🎟 ثبت‌نام‌های من", "👤 پروفایل من", "📚 پنل‌های گذشته",
        "📄 سؤالات پنل‌ها", "💡 پیشنهادها", "🏆 لیدربورد و چالش‌ها", "💬 جامعه و دربارهٔ ما",
    )
    for label in labels:
        assert f'text="{label}"' in keys_source
        assert f'"{label}":' in router_source
    assert '@router.message(F.text.in_(tuple(REPLY_MENU_ACTIONS)))' in router_source
    for action in (
        "show_events(message)", "render_my_bookings(message)", "render_user_questions(message)",
        "render_suggestions_menu(message)",
        "render_community_home(message)", "render_community_links(message)",
    ):
        assert action in router_source


def test_reply_menu_router_precedes_fsm_handlers_and_feature_routers():
    main = _source("app/bot/main.py")
    reply_position = main.index("dp.include_router(reply_menu_router)")
    user_position = main.index("dp.include_router(user_router)")
    assert reply_position < user_position


def test_menu_navigation_protects_receipt_upload_and_admin_drafts_before_clear():
    source = _source("app/bot/handlers/reply_menu.py")
    receipt_guard = source.index("current_state == BookingStates.waiting_receipt.state")
    admin_guard = source.index("current_state.startswith(_ADMIN_FORM_PREFIXES)")
    assert "if current_state:" in source
    assert source.index("if current_state:") < source.index("# Imports are intentionally lazy")
    assert "await state.clear()" not in source
    assert receipt_guard < source.index("# Imports are intentionally lazy")
    assert admin_guard < source.index("# Imports are intentionally lazy")
    assert "send the receipt" not in source.lower()  # User copy is localized; no accidental English fallback.
    assert "/cancel" in source


def test_reply_keyboard_is_opt_in_and_phone_collection_uses_minimal_contact_keyboard():
    user = _source("app/bot/handlers/user.py")
    keyboards = _source("app/bot/keyboards.py")
    assert '@router.message(Command("quickmenu"))' in user
    assert '@router.message(Command("hidekeyboard"))' in user
    assert "reply_markup=hide_reply_keyboard()" in user
    assert "include_contact=True" in keyboards
    assert "return persistent_main_keyboard(" in keyboards
    assert "از منوی ثابت پایین برای دسترسی سریع" not in user


def test_existing_contextual_inline_menu_is_preserved():
    source = _source("app/bot/keyboards.py")
    start = source.index("def main_menu():")
    end = source.index("def back_menu():", start)
    main_menu_source = source[start:end]
    assert "InlineKeyboardMarkup" in main_menu_source
    assert 'callback_data="user:events"' in main_menu_source
    assert 'callback_data="user:bookings"' in main_menu_source
