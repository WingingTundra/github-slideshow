from pathlib import Path

from app.services.user_access import parse_telegram_numeric_id

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


def test_parse_telegram_numeric_id_accepts_ascii_persian_and_arabic_digits():
    assert parse_telegram_numeric_id("123456789") == 123456789
    assert parse_telegram_numeric_id("۱۲۳۴۵۶۷۸۹") == 123456789
    assert parse_telegram_numeric_id("١٢٣٤٥٦٧٨٩") == 123456789
    assert parse_telegram_numeric_id("  123456789  ") == 123456789


def test_parse_telegram_numeric_id_rejects_non_numeric_invalid_and_overflow_values():
    for raw in (None, "", "@somebody", "-123", "+123", "0", "12.3", "12 34", "9223372036854775808", "12345678901234567890"):
        assert parse_telegram_numeric_id(raw) is None, raw


def test_v30_blocklist_is_persistent_independent_and_migrated():
    model = (APP / "db/models.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations/012_user_blocklist.sql").read_text(encoding="utf-8")
    assert 'class BlockedUser(Base)' in model
    assert '__tablename__ = "blocked_users"' in model
    assert 'telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)' in model
    assert 'blocked_by_telegram_id' in model and 'blocked_at' in model
    assert 'CREATE TABLE IF NOT EXISTS blocked_users' in migration
    assert 'telegram_id BIGINT PRIMARY KEY' in migration
    assert 'REFERENCES users' not in migration


def test_v30_blocking_is_admin_only_confirmed_and_enforced_for_messages_and_callbacks():
    admin = (APP / "bot/handlers/admin.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    main = (APP / "bot/main.py").read_text(encoding="utf-8")
    middleware = (APP / "bot/middleware.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:users:manage"' in keyboards
    assert 'callback_data="admin:users:block"' in keyboards
    assert 'callback_data="admin:users:blocked:page:0"' in keyboards
    assert 'admin_block_user_confirm' in admin and 'pg_insert(BlockedUser)' in admin
    assert '_protected_admin_target(target_id)' in admin
    assert 'admin_unblock_user_confirm' in admin and 'delete(BlockedUser)' in admin
    assert 'dp.message.outer_middleware(access_middleware)' in main
    assert 'dp.callback_query.outer_middleware(access_middleware)' in main
    auth = (APP / "services/authorization.py").read_text(encoding="utf-8")
    assert "inspect_account_access" in middleware
    assert "Fail closed" in middleware
    assert "settings.super_admin_id_set" in auth
    assert "session.get(BlockedUser, tg_id)" in auth
    assert "timedelta(hours=24)" in auth
    assert 'UserModerationRecord.action == "suspension"' in auth


def test_v30_changes_help_copy_only_and_preserves_community_button_label():
    content = (APP / "bot/content.py").read_text(encoding="utf-8")
    keyboards = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
    help_block = content.split('def user_help_text()', 1)[1].split('def about_text()', 1)[0]
    assert '💬 <b>جامعه و دربارهٔ ما</b>' in help_block
    assert '💬 <b>جامعه و دربارهٔ ما</b>' in help_block and 'لینک‌های رسمی' in help_block
    assert 'جامعهٔ پنل فلو' not in help_block
    assert r'text="💬 جامعه و دربارهٔ ما"' in keyboards
