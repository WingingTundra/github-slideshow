from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_admin_callback_id_parser_is_imported_before_read_callback_id_uses_it():
    source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "from app.bot.callback_validation import positive_callback_id" in source
    assert "value = positive_callback_id(c.data)" in source


def test_payment_review_router_precedes_admin_stale_callback_fallback():
    source = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")
    assert source.index("dp.include_router(payment_router)") < source.index("dp.include_router(admin_router)")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert '@router.callback_query(F.data.startswith("admin:"))' in admin


def test_requested_name_phone_copy_and_community_labels_are_present():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    content = (ROOT / "app/bot/content.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    assert "مثال: سینا ضیائی" in user
    assert "مثال: سینا ضیائی یا Sarah Williams" in admin
    assert content.count("شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود.") >= 2
    assert "پیگیری‌های معمول از طریق تلگرام انجام می‌شود." not in content
    assert "accepted_name_phone_prompt()" in user
    assert "لازم نیست با شمارهٔ حساب تلگرام شما یکسان باشد." not in user
    assert 'text="📢 Telegram Channel"' in keyboards
    assert 'text="👥 Telegram Group"' in keyboards
    assert r'text="💬 جامعه و دربارهٔ ما"' in keyboards
    assert 'text="📢 Telegram Channel"' in keyboards
    assert 'text="👥 Telegram Group"' in keyboards


def test_receipt_review_does_not_expire_based_on_receipt_age():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    payment = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    save_receipt = user.split("async def _save_receipt(", 1)[1].split("@router.message(BookingStates.waiting_receipt, F.photo)", 1)[0]
    assert "booking.expires_at = None" in save_receipt
    assert "current_token != token" in payment
    assert "booking.expires_at <" not in payment
    assert "payment.created_at <" not in payment
