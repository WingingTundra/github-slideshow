from datetime import datetime, timezone
from pathlib import Path

from app.db.models import Base, Event, User
from app.time_utils import utc_now_naive


def test_utc_now_naive_returns_current_utc_in_legacy_database_format():
    before = datetime.now(timezone.utc).replace(tzinfo=None)
    now = utc_now_naive()
    after = datetime.now(timezone.utc).replace(tzinfo=None)

    assert now.tzinfo is None  # Current schema uses DateTime(timezone=False).
    assert before <= now <= after


def test_orm_timestamp_defaults_use_the_shared_utc_clock():
    def is_shared_clock(function):
        # SQLAlchemy wraps callable defaults, preserving the original under __wrapped__.
        return getattr(function, "__wrapped__", function) is utc_now_naive

    for model in (User, Event):
        assert is_shared_clock(model.__table__.c.created_at.default.arg)
        assert is_shared_clock(model.__table__.c.updated_at.default.arg)
        assert is_shared_clock(model.__table__.c.updated_at.onupdate.arg)

    for table in Base.metadata.tables.values():
        for column in table.columns:
            if column.name == "created_at" and column.default is not None:
                assert is_shared_clock(column.default.arg), f"{table.name}.{column.name}"


def test_runtime_uses_the_replacement_utc_clock_api():
    app_root = Path(__file__).resolve().parents[1] / "app"
    deprecated_call = "datetime" + "." + "utc" + "now("
    for path in app_root.rglob("*.py"):
        assert deprecated_call not in path.read_text(encoding="utf-8"), str(path)
