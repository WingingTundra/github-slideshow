from __future__ import annotations

from datetime import datetime, timedelta
from html import unescape
from pathlib import Path
import re
from types import SimpleNamespace

import pytest

from app.bot.text_limits import limit_telegram_html
from app.db.models import EventStatus, RegistrationStatus
from app.services.booking import expire_booking_if_due

ROOT = Path(__file__).resolve().parents[1]


def _visible_utf16_units(markup: str) -> int:
    total = 0
    for token in re.findall(r"<[^>]*>|&(?:#[0-9]+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]+);|.", markup, re.DOTALL):
        if token.startswith("<") and token.endswith(">"):
            continue
        value = unescape(token) if token.startswith("&") and token.endswith(";") else token
        total += len(value.encode("utf-16-le")) // 2
    return total


def test_html_limiter_returns_short_messages_unchanged():
    source = "<b>Short</b> &amp; sweet"
    assert limit_telegram_html(source) == source


def test_html_limiter_bounds_emoji_heavy_messages_and_closes_tags():
    source = "<b>" + ("😀" * 2200) + " trailing text</b>"
    result = limit_telegram_html(source, max_units=3800)
    assert _visible_utf16_units(result) <= 3800
    assert result.endswith("</b>")
    assert "…</b>" in result
    assert result.count("<b>") == result.count("</b>") == 1


def test_html_limiter_never_splits_an_html_entity():
    source = "<b>" + ("&amp;" * 4000) + "</b>"
    result = limit_telegram_html(source, max_units=3800)
    assert _visible_utf16_units(result) <= 3800
    assert result.endswith("</b>")
    assert result.count("&amp;") == 3799
    assert "&am…" not in result


@pytest.mark.parametrize(
    ("status", "deadline_offset", "should_expire"),
    [
        (RegistrationStatus.PENDING_PAYMENT, -timedelta(seconds=1), True),
        (RegistrationStatus.PENDING_PAYMENT, timedelta(seconds=1), False),
        (RegistrationStatus.PENDING_PAYMENT, timedelta(0), False),
        (RegistrationStatus.PENDING_VERIFICATION, -timedelta(seconds=1), False),
        (RegistrationStatus.REJECTED, -timedelta(seconds=1), False),
    ],
)
def test_booking_expiry_transition_only_expires_due_pending_payment_holds(status, deadline_offset, should_expire):
    now = datetime(2026, 10, 10, 12, 0, 0)
    booking = SimpleNamespace(
        status=status,
        expires_at=now + deadline_offset,
        cancelled_at=None,
    )
    expired = expire_booking_if_due(booking, now=now)
    assert expired is should_expire
    if should_expire:
        assert booking.status == RegistrationStatus.EXPIRED
        assert booking.cancelled_at == now
    else:
        assert booking.status == status
        assert booking.cancelled_at is None


def test_receipt_handler_checks_deadline_and_event_lifecycle_before_accepting_receipt():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    start = source.index("async def _save_receipt(")
    end = source.index("@router.message(BookingStates.waiting_receipt, F.photo)", start)
    handler = source[start:end]
    assert "expire_booking_if_due(booking, now=utc_now_naive())" in handler
    assert "event.status != EventStatus.PUBLISHED or event.archived" in handler
    assert handler.index("expire_booking_if_due") < handler.index("select(Event)")
    assert handler.index("event.status != EventStatus.PUBLISHED or event.archived") < handler.index("download_file")


def test_payment_approval_is_blocked_for_inactive_panels_but_rejection_remains_available():
    source = (ROOT / "app/bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")
    assert "if approve and (event.status != EventStatus.PUBLISHED or event.archived):" in source
    assert "در صورت نیاز، رسید را رد کنید" in source


def test_long_dynamic_html_screens_use_the_safe_message_limiter():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "return limit_telegram_html(text)" in user
    assert "limit_telegram_html(preview_text)" in admin
    assert "limit_telegram_html(text),\n        reply_markup=payment_review_keyboard" in admin or "reply_markup=payment_review_keyboard(payment.id, current_token, event_id, can_navigate=can_navigate)" in admin
    assert 'return limit_telegram_html("\\n".join(lines))' in admin
    assert "limit_telegram_html(text), reply_markup=kb" in admin


def test_my_bookings_list_uses_database_pagination_before_sending_to_telegram():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    assert "MY_BOOKINGS_PAGE_SIZE = 4" in source
    function = source.split("async def render_my_bookings", 1)[1].split("\n\nasync def ", 1)[0]
    assert ".offset(page * MY_BOOKINGS_PAGE_SIZE).limit(MY_BOOKINGS_PAGE_SIZE)" in function
    assert "select(func.count()).select_from(" in function and "Booking.id" in function
    assert '"\\n\\n".join(chunks)' in function
    # Each result is bounded at SQL level; response clipping is no longer the pagination strategy.
    assert 'limit_telegram_html("\\n\\n".join(chunks))' not in function


def test_admin_command_is_hidden_from_menu_but_command_handler_remains_functional():
    source = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")
    handler_source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "BotCommandScopeChat(chat_id=admin_id)" in source
    public_commands = source.split("public_commands = [", 1)[1].split("]", 1)[0]
    assert 'BotCommand(command="start"' in public_commands
    assert 'BotCommand(command="help"' in public_commands
    assert 'BotCommand(command="cancel"' in public_commands
    assert 'BotCommand(command="admin"' not in source
    assert '@router.message(Command("admin"))' in handler_source
