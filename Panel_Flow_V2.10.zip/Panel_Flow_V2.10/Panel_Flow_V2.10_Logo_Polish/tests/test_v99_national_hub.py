from datetime import date
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.db.models import Base, City, Event, HostSubscription
from app.http_api.website_routes import CityCreateInput, EventCreateInput, HostCreateInput

ROOT = Path(__file__).resolve().parents[1]


def test_v99_adds_city_directory_and_subscription_models_without_replacing_core_tables():
    assert City.__tablename__ == "cities"
    assert HostSubscription.__tablename__ == "host_subscriptions"
    assert "city_id" in Event.__table__.columns
    assert "event_date_iso" in Event.__table__.columns
    assert "events" in Base.metadata.tables and "users" in Base.metadata.tables


def test_v99_migration_is_additive_and_seeds_provincial_capitals_and_existing_hosts():
    sql = (ROOT / "migrations/046_national_city_hub_and_host_subscriptions.sql").read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS cities" in sql
    assert "CREATE TABLE IF NOT EXISTS host_subscriptions" in sql
    assert "ALTER TABLE events ADD COLUMN IF NOT EXISTS city_id" in sql
    assert "ALTER TABLE events ADD COLUMN IF NOT EXISTS event_date_iso" in sql
    assert "Existing host access preserved" in sql
    assert "NOT EXISTS (SELECT 1 FROM host_subscriptions hs WHERE hs.host_user_id=u.id)" in sql
    assert "ON CONFLICT (slug) DO UPDATE" in sql
    assert "DROP TABLE" not in sql.upper()
    assert sum(1 for line in sql.splitlines() if line.startswith("('")) == 31


def test_v99_platform_and_city_routes_are_registered_without_duplicates():
    from app.api import api

    paths = {route.path for route in api.routes if hasattr(route, "path")}
    expected = {
        "/api/v1/cities", "/api/v1/cities/{slug}", "/api/v1/calendar/events",
        "/api/v1/staff/platform/hosts", "/api/v1/staff/platform/hosts/{host_user_id}/subscription",
        "/api/v1/staff/platform/hosts/{host_user_id}/deactivate",
        "/api/v1/staff/platform/cities", "/api/v1/staff/platform/cities/{city_id}",
        "/api/v1/seo/robots.txt", "/api/v1/seo/sitemap.xml", "/api/v1/seo/validate",
    }
    assert expected.issubset(paths)
    registrations = [(route.path, method) for route in api.routes if hasattr(route, "methods") for method in route.methods or ()]
    assert len(registrations) == len(set(registrations))


def test_v99_city_input_enforces_slug_and_iran_coordinates():
    valid = CityCreateInput(slug="kish", name_fa="کیش", name_en="Kish", province_fa="هرمزگان",
                            province_en="Hormozgan", latitude=26.5, longitude=53.9)
    assert valid.slug == "kish"
    with pytest.raises(ValidationError):
        CityCreateInput(slug="Kish Island", name_fa="کیش", name_en="Kish", province_fa="هرمزگان",
                        province_en="Hormozgan", latitude=26.5, longitude=53.9)
    with pytest.raises(ValidationError):
        CityCreateInput(slug="kish", name_fa="کیش", name_en="Kish", province_fa="هرمزگان",
                        province_en="Hormozgan", latitude=51, longitude=53.9)
    from app.http_api.website_routes import CityUpdateInput
    with pytest.raises(ValidationError):
        CityUpdateInput(name_en=None)
    with pytest.raises(ValidationError):
        CityCreateInput(slug="kish", name_fa="   ", name_en="Kish", province_fa="هرمزگان",
                        province_en="Hormozgan", latitude=26.5, longitude=53.9)
    with pytest.raises(ValidationError):
        CityUpdateInput(name_en="   ")


def test_v99_host_subscription_input_is_bounded_and_event_date_is_structured():
    host = HostCreateInput(telegram_id=123456, plan_code="growth", duration_days=90, price_amount=500000)
    assert host.duration_days == 90
    assert host.currency == "TOMAN"
    with pytest.raises(ValidationError):
        HostCreateInput(telegram_id=123456, duration_days=900)
    event = EventCreateInput(volume="Vol. 1", title="A city panel", day="Friday", date="۲۹ آبان ۱۴۰۵",
        date_iso="2026-11-20", start_time="18:00", venue="Studio", city="Tehran", city_id=1,
        capacity=20, price_per_person=100000)
    assert event.date_iso == date(2026, 11, 20)
    assert event.city_id == 1
    with pytest.raises(ValidationError):
        EventCreateInput(volume=" ", title="A city panel", day="Friday", date="۲۹ آبان ۱۴۰۵",
            date_iso="2026-11-20", start_time="18:00", venue="Studio", city="Tehran", city_id=1,
            capacity=20, price_per_person=100000)
    with pytest.raises(ValidationError):
        EventCreateInput(volume="Vol. 1", title="A city panel", day="Friday", date="۲۹ آبان ۱۴۰۵",
            date_iso="2026-11-20", start_time="25:90", venue="Studio", city="Tehran", city_id=1,
            capacity=20, price_per_person=100000)
    from app.http_api.website_routes import EventUpdateInput
    with pytest.raises(ValidationError):
        EventUpdateInput(title=None)
    with pytest.raises(ValidationError):
        EventUpdateInput(status=None)
    with pytest.raises(ValidationError):
        EventUpdateInput(start_time="9:30")


def test_v99_nginx_has_real_static_404s_and_dynamic_public_page_validation():
    nginx = (ROOT / "website/nginx.conf").read_text(encoding="utf-8")
    assert "location = /robots.txt" in nginx and "location = /sitemap.xml" in nginx
    assert "auth_request /_seo_validate" in nginx
    assert "try_files $uri =404" in nginx
    assert "return 404" in nginx
    assert "location ~ ^/events/[1-9][0-9]*/?$" in nginx
    assert "location ~ ^/hosts/[a-z0-9]+(?:-[a-z0-9]+)*/?$" in nginx
    for route in ("/my-organizations", "/become-a-host", "/host-application"):
        assert f"location = {route}" in nginx
    assert "location /workspace/ { try_files /workspace/index.html /index.html; }" in nginx
    assert "location ^~ /workspace/" not in nginx  # Preserve the missing-asset 404 regex for workspace paths.
    assert "hosts/[a-z0-9]+(?:-[a-z0-9]+)*/?" in nginx.split("location @spa", 1)[1]


def test_v99_frontend_keeps_clean_routes_and_adds_city_and_calendar_hubs():
    app = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    assert "BrowserRouter" not in app  # BrowserRouter remains mounted once in main.tsx.
    assert 'path="/cities"' in app and 'path="/cities/:slug"' in app and 'path="/calendar"' in app
    assert "IranCityMap" in app and "PersianCalendar" in app
    assert "setPageMetadata" in app and "noindex,nofollow" in app
    main = (ROOT / "website/src/main.tsx").read_text(encoding="utf-8")
    assert "BrowserRouter" in main


def test_v99_public_site_url_requires_a_clean_https_origin():
    from app.config import Settings

    assert Settings(panel_flow_website_url="https://panelflow.example/").panel_flow_website_url == "https://panelflow.example"
    with pytest.raises(ValidationError):
        Settings(panel_flow_website_url="https://panelflow.example/path")
    with pytest.raises(ValidationError):
        Settings(panel_flow_website_url="http://panelflow.example")


def test_v99_host_event_creation_requires_an_active_subscription():
    import asyncio
    from datetime import timedelta
    from types import SimpleNamespace
    from fastapi import HTTPException
    from app.db.models import UserRole
    from app.http_api.website_routes import _ensure_active_host_subscription
    from app.time_utils import utc_now_naive

    user = SimpleNamespace(id=55, telegram_id=987654321, role=UserRole.HOST)

    class Result:
        def __init__(self, value): self.value = value
        def scalar_one_or_none(self): return self.value

    class Session:
        def __init__(self, value): self.value = value
        async def execute(self, statement): return Result(self.value)

    active = SimpleNamespace(status="active", ends_at=utc_now_naive() + timedelta(days=5))
    asyncio.run(_ensure_active_host_subscription(user, Session(active)))
    inactive = SimpleNamespace(status="suspended", ends_at=utc_now_naive() + timedelta(days=5))
    with pytest.raises(HTTPException) as exc:
        asyncio.run(_ensure_active_host_subscription(user, Session(inactive)))
    assert exc.value.status_code == 403
    assert exc.value.detail["code"] == "HOST_SUBSCRIPTION_INACTIVE"
    expired = SimpleNamespace(status="active", ends_at=utc_now_naive() - timedelta(days=1))
    with pytest.raises(HTTPException):
        asyncio.run(_ensure_active_host_subscription(user, Session(expired)))


def test_v99_host_event_creation_audit_is_admin_only_and_host_drafts_remain_owned():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    create = source.split('async def staff_create_event', 1)[1].split('@router.patch("/staff/events/{event_id}")', 1)[0]
    assert 'await _ensure_active_host_subscription(user, session)' in create
    assert 'host_id=user.id' in create
    assert 'if _is_admin(user):' in create


def test_v99_robots_and_sitemap_are_dynamic_and_valid_xml(monkeypatch):
    import asyncio
    from datetime import datetime
    import xml.etree.ElementTree as ET
    from starlette.requests import Request
    from app.config import settings
    from app.http_api.website_routes import seo_robots, seo_sitemap

    monkeypatch.setattr(settings, "panel_flow_website_url", "")
    request = Request({"type": "http", "method": "GET", "scheme": "https", "server": ("panelflow.test", 443),
                       "client": ("127.0.0.1", 1234), "path": "/", "headers": [(b"host", b"panelflow.test")]})
    robots = asyncio.run(seo_robots(request))
    assert robots.status_code == 200
    assert "Sitemap: https://panelflow.test/sitemap.xml" in robots.body.decode()

    class ScalarRows:
        def __init__(self, rows): self.rows = rows
        def scalars(self): return self
        def all(self): return self.rows
    class RowRows:
        def __init__(self, rows): self.rows = rows
        def all(self): return self.rows
    class Session:
        def __init__(self): self.calls = 0
        async def execute(self, statement):
            self.calls += 1
            if self.calls == 1: return ScalarRows(["tehran"])
            if self.calls == 2: return ScalarRows([])
            if self.calls == 3: return RowRows([])
            if self.calls == 4: return ScalarRows(["host-one"])
            if self.calls == 5: return ScalarRows([])  # no public discussion series
            return RowRows([(12, datetime(2026, 11, 8, 8, 0, 0))])
    sitemap = asyncio.run(seo_sitemap(request, Session()))
    root = ET.fromstring(sitemap.body)
    locations = [node.text for node in root.findall("{http://www.sitemaps.org/schemas/sitemap/0.9}url/{http://www.sitemaps.org/schemas/sitemap/0.9}loc")]
    assert "https://panelflow.test/cities/tehran" in locations
    assert "https://panelflow.test/hosts/host-one" in locations
    assert "https://panelflow.test/events/12" in locations


def test_v99_nginx_validation_endpoint_uses_not_found_semantics_for_missing_pages():
    import asyncio
    from types import SimpleNamespace
    from fastapi import HTTPException
    from starlette.requests import Request
    from app.http_api.website_routes import seo_validate

    class Session:
        async def scalar(self, statement): return None
    request = Request({"type": "http", "method": "GET", "scheme": "https", "server": ("panelflow.test", 443),
                       "client": ("127.0.0.1", 1234), "path": "/", "headers": [(b"host", b"panelflow.test"), (b"x-original-uri", b"/events/999")]})
    with pytest.raises(HTTPException) as exc:
        asyncio.run(seo_validate(request, Session()))
    assert exc.value.status_code == 403  # Nginx auth_request maps this to a real 404.


def test_v99_calendar_api_returns_a_consistent_empty_page_when_no_dates_are_structured():
    import asyncio
    from app.http_api.website_routes import public_calendar_events

    class Rows:
        def scalars(self): return self
        def all(self): return []
    class Session:
        async def scalar(self, statement): return 0
        async def execute(self, statement): return Rows()
    result = asyncio.run(public_calendar_events(limit=1000, offset=0, session=Session()))
    assert result == {"items": [], "total": 0, "limit": 1000, "offset": 0}


def test_v99_inactive_host_edits_do_not_implicitly_activate_subscriptions():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    update = source.split('async def platform_update_host_subscription', 1)[1].split('@router.post("/staff/platform/hosts/{host_user_id}/deactivate")', 1)[0]
    assert 'status="suspended"' in update
    assert 'if "status" in changes' in update
    add = source.split('async def platform_add_host', 1)[1].split('@router.patch("/staff/platform/hosts/{host_user_id}/subscription")', 1)[0]
    assert 'HOST_ALREADY_ACTIVE' in add


def test_v99_admin_city_directory_can_list_disabled_cities_for_reactivation():
    source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    listing = source.split('async def platform_list_cities', 1)[1].split('@router.post("/staff/platform/cities")', 1)[0]
    assert 'select(City).order_by(City.name_en)' in listing
    assert 'City.is_active.is_(True)' not in listing
    app = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    assert "'/staff/platform/cities'" in app


def test_v99_active_host_public_profile_passes_nginx_seo_validation():
    import asyncio
    from starlette.requests import Request
    from app.http_api.website_routes import seo_validate

    class Session:
        async def scalar(self, statement): return 42
    request = Request({"type": "http", "method": "GET", "scheme": "https", "server": ("panelflow.test", 443),
                       "client": ("127.0.0.1", 1234), "path": "/", "headers": [
                           (b"host", b"panelflow.test"), (b"x-original-uri", b"/hosts/host-one") ]})
    assert asyncio.run(seo_validate(request, Session())) == {"ok": True}


def test_v99_prerender_has_private_host_application_shells_and_route_specific_open_graph_urls():
    prerender = (ROOT / "website/scripts/prerender-public.mjs").read_text(encoding="utf-8")
    for path in ("my-organizations", "become-a-host", "host-application"):
        assert f"path: '{path}'" in prerender
    assert "og:url" in prerender
    assert ".replace(/<meta property=\"og:url\"[^>]*\\/?>/g, '')" in prerender
