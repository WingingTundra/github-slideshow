from pathlib import Path

from app.bot.content import about_text, main_menu_welcome_text
from app.bot.validation import normalize_volume_label

ROOT = Path(__file__).resolve().parents[1]


def test_welcome_message_is_exactly_the_requested_two_lines():
    assert main_menu_welcome_text() == (
        "🧩 به Panel Flow خوش آمدید!\n"
        "فضایی برای گفت‌وگو و آشنایی با آدم‌های تازه."
    )


def test_about_heading_uses_puzzle_icon_not_plant_icon():
    about = about_text()
    assert "<b>🧩 ABOUT PANEL FLOW</b>" in about
    assert "<b>🧩 دربارهٔ پنل فلو</b>" in about
    assert "🌿" not in about


def test_single_digit_numeric_volume_is_valid_and_zero_is_not():
    for digit in "123456789":
        assert normalize_volume_label(digit) == digit
    assert normalize_volume_label("0") is None
    assert normalize_volume_label("10") == "10"


def test_volume_still_rejects_commands_and_invalid_text():
    for text in ("/admin", "/cancel", "/start", "Movie/@", "فیلم", "Movie!"):
        assert normalize_volume_label(text) is None


def test_language_prompt_no_longer_has_redundant_cancel_instruction():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    prompt_flow = admin.split("@router.message(AdminEventStates.title)", 1)[1].split(
        "@router.message(AdminEventStates.language)", 1
    )[0]
    assert '"زبان پنل را وارد کنید.\\nمثال: English، فارسی یا Français."' in prompt_flow
    assert "برای لغو فرایند /cancel را ارسال کنید." not in prompt_flow


def test_cancel_in_menu_has_a_short_no_active_process_response_and_correct_menu():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    handler = user.split('@router.message(Command("cancel"))', 1)[1].split(
        '@router.message(UnsupportedTelegramCommand())', 1
    )[0]
    assert "if not current_state:" in handler
    assert "هیچ فرایند فعالی برای لغو وجود ندارد." in handler
    assert "reply_markup=admin_menu()" in handler
    assert "reply_markup=main_menu()" in handler
