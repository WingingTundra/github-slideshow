from pathlib import Path

from app.bot.content import accepted_name_phone_prompt, about_text, user_help_text
from app.display_utils import status_display_label, truncate_display_text, volume_label
from app.services.seat_disclosure import public_catalogue_availability_label

ROOT = Path(__file__).resolve().parents[1]


def test_internal_statuses_are_human_readable_english():
    assert status_display_label("registration_open") == "Registration open"
    assert status_display_label("receipt_approved") == "Receipt approved"
    assert status_display_label("pending_verification") == "Awaiting receipt review"
    assert status_display_label("delivery_uncertain") == "Delivery uncertain"
    # Unknown status codes must still be readable rather than leaking snake_case.
    assert status_display_label("new_internal_state") == "New Internal State"


def test_volume_labels_do_not_repeat_prefixes():
    assert volume_label(21) == "V21"
    assert volume_label("V21") == "V21"
    assert volume_label("Volume 21") == "V21"
    assert volume_label("Movie Night") == "Volume Movie Night"


def test_long_button_text_gets_an_ellipsis_and_prefers_word_boundaries():
    assert truncate_display_text("The Reality Check: How We Live", 24) == "The Reality Check: How…"
    assert truncate_display_text("Short title", 24) == "Short title"


def test_public_catalogue_uses_exact_level_two_copy_and_real_low_seat_count():
    assert public_catalogue_availability_label(15, 7, registration_open=True, waitlist_available=False) == "ظرفیت پنل در حال تکمیل است."
    assert public_catalogue_availability_label(15, 5, registration_open=True, waitlist_available=False) == "فقط ۵ جای خالی باقی مانده است"


def test_privacy_note_is_short_and_help_is_task_oriented():
    assert accepted_name_phone_prompt().count("شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود.") == 1
    help_text = user_help_text()
    assert "برای راهنمایی یا گزارش مشکل" in help_text
    assert "کد معرفی" in help_text
    assert "نیاز واقعی" not in help_text


def test_about_social_buttons_are_localized_and_telegram_id_remains_internal():
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    notifications = (ROOT / "app/bot/admin_notifications.py").read_text(encoding="utf-8")
    for label in ("Telegram Channel", "Telegram Group", "Instagram", "Website"):
        assert label in keyboards
    for old_label in ("📢 کانال تلگرام", "👥 گروه تلگرام", "📷 اینستاگرام", "🌐 وب‌سایت"):
        assert old_label not in keyboards
    assert "Telegram ID:" in notifications


def test_host_notification_history_humanizes_unknown_status_values():
    source = (ROOT / "app/bot/handlers/admin_console.py").read_text(encoding="utf-8")
    assert "labels.get(event.submission_notification_status, admin_status_display_label(event.submission_notification_status))" in source


def test_about_remains_bilingual():
    copy = about_text()
    assert "<b>Who we are</b>" in copy
    assert "<b>ما که هستیم</b>" in copy
    assert "different topics and languages" in copy
