from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def test_v205_member_dashboard_recent_views_reviews_and_audit_routes_are_registered():
    from app.api import api

    paths = {route.path for route in api.routes if hasattr(route, "path")}
    assert "/api/v1/me/activity" in paths
    assert "/api/v1/me/recent-events/{event_id}" in paths
    assert "/api/v1/me/reviews/eligible" in paths
    assert "/api/v1/me/reviews" in paths
    assert "/api/v1/staff/host/reviews" in paths
    assert "/api/v1/staff/audit-logs" in paths
    audit_source = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    audit_block = audit_source.split('@router.get("/staff/audit-logs")', 1)[1].split('@router.get("/staff/topics")', 1)[0]
    assert "select(AdminAction, User)" in audit_block and "AdminAction.action.notin_" in audit_block
    assert "safe_metadata_keys" in audit_block and "log.details" not in audit_block
    assert "/share/events/{event_id}" in paths


def test_v205_event_social_preview_escapes_content_and_rejects_untrusted_host(monkeypatch):
    from app.api import api
    from app.config import settings
    from app.db.models import EventStatus

    event = SimpleNamespace(
        id=23,
        title='A <script>alert("x")</script> panel',
        status=EventStatus.PUBLISHED,
        archived=False,
        cover_image_url="/uploads/panel-cover.webp",
        event_date_label="Friday",
        city="Mashhad",
        venue="Studio One",
        description='A <b>public</b> conversation',
    )
    city = SimpleNamespace(name_en="Mashhad")

    class Result:
        def one_or_none(self):
            return event, city

    class Session:
        async def execute(self, _statement):
            return Result()

    request = SimpleNamespace(
        headers={"host": 'attacker.example\" onload=\"alert(1)', "x-forwarded-proto": "https"},
        url=SimpleNamespace(scheme="http"),
    )
    route = next(route for route in api.routes if getattr(route, "path", None) == "/share/events/{event_id}")
    monkeypatch.setattr(settings, "panel_flow_website_url", "")
    response = asyncio.run(route.endpoint(23, request, Session()))
    body = response.body.decode("utf-8")
    assert response.status_code == 200
    assert 'property="og:url" content="https://localhost/events/23"' in body
    assert 'href="https://localhost/events/23"' in body
    assert 'og:image' in body and 'https://localhost/uploads/panel-cover.webp' in body
    assert "<script>" not in body and "&lt;script&gt;" in body
    assert 'attacker.example" onload=' not in body


def test_v205_configured_public_website_url_is_used_for_social_metadata(monkeypatch):
    from app.api import api
    from app.config import settings
    from app.db.models import EventStatus

    event = SimpleNamespace(id=24, title="Safe event", status=EventStatus.PUBLISHED, archived=False,
        cover_image_url=None, event_date_label="Saturday", city="Tehran", venue="Hall", description=None)
    city = SimpleNamespace(name_en="Tehran")

    class Result:
        def one_or_none(self):
            return event, city

    class Session:
        async def execute(self, _statement):
            return Result()

    request = SimpleNamespace(headers={"host": "internal-api:8000", "x-forwarded-proto": "http"},
        url=SimpleNamespace(scheme="http"))
    route = next(route for route in api.routes if getattr(route, "path", None) == "/share/events/{event_id}")
    monkeypatch.setattr(settings, "panel_flow_website_url", "https://panelflow.example/")
    response = asyncio.run(route.endpoint(24, request, Session()))
    body = response.body.decode("utf-8")
    assert 'href="https://panelflow.example/events/24"' in body
    assert 'https://panelflow.example/panel-flow-share.svg' in body


def test_v205_audit_endpoint_merges_website_and_telegram_history_without_private_details():
    from datetime import datetime, timedelta, timezone
    from app.api import api

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    actor = SimpleNamespace(display_name="Ops Admin", first_name="Ops", telegram_username="ops")
    platform_log = SimpleNamespace(id=11, action="event.updated", target_type="event", target_id="23",
        organization_id=4, actor_user_id=1, created_at=now, metadata_json={"event_id": 23, "secret": "never expose"})
    telegram_log = SimpleNamespace(id=8, action="panel_published", entity_type="event", entity_id=21,
        actor_user_id=1, created_at=now - timedelta(minutes=1), details='{"phone":"private"}')

    class Rows:
        def __init__(self, values): self.values = values
        def all(self): return self.values

    class Session:
        def __init__(self): self.execute_calls = 0
        async def scalar(self, _statement): return 1
        async def execute(self, _statement):
            self.execute_calls += 1
            return Rows([(platform_log, actor)] if self.execute_calls == 1 else [(telegram_log, actor)])

    route = next(route for route in api.routes if getattr(route, "path", None) == "/api/v1/staff/audit-logs")
    result = asyncio.run(route.endpoint(limit=10, offset=0, action=None,
        user=SimpleNamespace(id=1, telegram_id=123, role="super_admin"), session=Session()))
    assert result["total"] == 2 and len(result["items"]) == 2
    assert {row["source"] for row in result["items"]} == {"website", "telegram"}
    assert all("details" not in row and "secret" not in row.get("metadata", {}) for row in result["items"])
    assert result["items"][0]["action"] == "event.updated"


def test_v205_frontend_exposes_member_calendar_share_search_city_and_audit_experiences():
    app = (ROOT / "website/src/App.tsx").read_text(encoding="utf-8")
    styles = (ROOT / "website/src/styles.css").read_text(encoding="utf-8")
    api_client = (ROOT / "website/src/api.ts").read_text(encoding="utf-8")
    assert 'path="/dashboard"' in app
    assert "/me/activity" in app and "/me/recent-events/" in app
    assert "text/calendar" in app and "DTSTART:" in app and "METHOD:PUBLISH" in app
    assert "createEventShareImage" in app and "/share/events/" in app
    for filter_key in ("city_id", "topic", "organization_id", "language", "event_type", "date_from", "date_to", "availability", "sort"):
        assert filter_key in app
    assert "Copy filtered link" in app and "recent-search-row" in app
    assert 'path="/cities/:slug"' in app and "recent_completed_events" in app
    assert "audit-log-list" in app and "/staff/audit-logs" in app
    assert "prefers-reduced-motion:reduce" in styles
    assert "--brand-gradient" in styles and '[data-theme="light"]' in styles
    assert "retryable = response.status" in api_client
    assert "inFlightGetRequests" in api_client and "method !== 'GET'" in api_client
    assert "The service is temporarily unavailable" in api_client


def test_v205_keeps_image_optimization_server_side_without_touching_receipt_files():
    processor = (ROOT / "app/services/image_processing.py").read_text(encoding="utf-8")
    config = (ROOT / "app/config.py").read_text(encoding="utf-8")
    assert "ImageOps.exif_transpose" in processor
    assert "WEBP" in processor and "quality" in processor
    assert "image_max_dimension" in config and "image_webp_quality" in config
    uploads = (ROOT / "app/services/media_uploads.py").read_text(encoding="utf-8")
    assert "optimize_public_image" in uploads and "max_image_upload_mb" in uploads
    organization_uploads = (ROOT / "app/http_api/organization_routes.py").read_text(encoding="utf-8")
    event_uploads = (ROOT / "app/http_api/website_routes.py").read_text(encoding="utf-8")
    assert "store_public_image" in organization_uploads and "store_public_image" in event_uploads
    # Payment receipts use the separate, original-file upload path and retain their MIME/size checks.
    receipt_upload = event_uploads.split("async def upload_booking_receipt", 1)[1].split("async def ", 1)[0]
    assert "receipt_file_name" in receipt_upload and "optimize_public_image" not in receipt_upload


def test_v205_does_not_introduce_installable_pwa_or_new_runtime_dependencies():
    package = __import__("json").loads((ROOT / "website/package.json").read_text(encoding="utf-8"))
    main = (ROOT / "website/src/main.tsx").read_text(encoding="utf-8")
    public_files = list((ROOT / "website/public").glob("*"))
    assert package["version"] == "2.06.0"
    assert "serviceWorker" not in main and "navigator.serviceWorker" not in main
    assert not any(path.name in {"manifest.webmanifest", "manifest.json"} for path in public_files)
    assert package["dependencies"] == {
        "react": "19.3.1", "react-dom": "19.3.1", "react-router-dom": "6.30.6", "lucide-react": "0.468.0"
    }
