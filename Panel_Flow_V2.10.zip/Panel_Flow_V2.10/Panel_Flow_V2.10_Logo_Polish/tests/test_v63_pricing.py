from decimal import Decimal
from pathlib import Path

import pytest

from app.services.pricing import (
    BASE_OPTION,
    WITHOUT_CAFE_ORDER,
    booking_option_label,
    booking_option_detail_label,
    calculate_price_components,
    panel_price_label,
    positive_optional_price,
)
from app.services.discounts import calculate_discount


ROOT = Path(__file__).resolve().parents[1]


def test_base_option_uses_base_price_and_has_no_waiver_component():
    result = calculate_price_components(80_000, 140_000, BASE_OPTION, 1)
    assert result.gross_total == Decimal("80000")
    assert result.discountable_base_total == Decimal("80000")
    assert result.non_discountable_waiver_total == Decimal("0")
    assert result.base_price_snapshot == Decimal("80000")
    assert result.alternative_price_snapshot == Decimal("140000")


def test_alternative_option_separates_discountable_base_and_waiver_for_multiple_attendees():
    result = calculate_price_components(80_000, 140_000, WITHOUT_CAFE_ORDER, 3)
    assert result.gross_total == Decimal("420000")
    assert result.discountable_base_total == Decimal("240000")
    assert result.non_discountable_waiver_total == Decimal("180000")


def test_alternative_option_50_percent_discount_only_reduces_base_component():
    components = calculate_price_components(80_000, 140_000, WITHOUT_CAFE_ORDER, 1)
    discount = calculate_discount(
        components.discountable_base_total, Decimal(80_000), 1,
        "percent", Decimal(50), scope="total",
    )
    assert discount == Decimal("40000")
    assert components.gross_total - discount == Decimal("100000")


def test_alternative_option_100_percent_discount_leaves_waiver_payable():
    components = calculate_price_components(80_000, 140_000, WITHOUT_CAFE_ORDER, 1)
    discount = calculate_discount(
        components.discountable_base_total, Decimal(80_000), 1,
        "percent", Decimal(100), scope="total",
    )
    assert discount == Decimal("80000")
    assert components.gross_total - discount == Decimal("60000")


def test_fixed_discount_cannot_consume_the_waiver_component():
    components = calculate_price_components(80_000, 140_000, WITHOUT_CAFE_ORDER, 1)
    discount = calculate_discount(
        components.discountable_base_total, Decimal(80_000), 1,
        "fixed", Decimal(120_000), scope="total",
    )
    assert discount == Decimal("80000")
    assert components.gross_total - discount == Decimal("60000")


def test_single_person_reward_still_discounts_only_one_base_fee():
    components = calculate_price_components(80_000, 140_000, WITHOUT_CAFE_ORDER, 3)
    discount = calculate_discount(
        components.discountable_base_total, Decimal(80_000), 3,
        "percent", Decimal(100), scope="single",
    )
    assert discount == Decimal("80000")
    assert components.gross_total - discount == Decimal("340000")
    assert components.non_discountable_waiver_total == Decimal("180000")


def test_zero_base_means_entire_booking_is_free_and_ignores_alternative_option():
    result = calculate_price_components(0, 140_000, WITHOUT_CAFE_ORDER, 2)
    assert result.option == BASE_OPTION
    assert result.gross_total == Decimal("0")
    assert result.discountable_base_total == Decimal("0")
    assert result.non_discountable_waiver_total == Decimal("0")
    assert panel_price_label(0, 140_000) == "رایگان"


def test_zero_or_missing_optional_price_disables_the_alternative():
    assert positive_optional_price(None) is None
    assert positive_optional_price(0) is None
    assert positive_optional_price("0") is None
    assert calculate_price_components(80_000, 0, BASE_OPTION, 1).gross_total == Decimal("80000")
    with pytest.raises(ValueError, match="ALTERNATIVE_PRICE_UNAVAILABLE"):
        calculate_price_components(80_000, 0, WITHOUT_CAFE_ORDER, 1)


@pytest.mark.parametrize("alternative", [80_000, 79_999, 0, None])
def test_alternative_option_requires_a_price_higher_than_base(alternative):
    with pytest.raises(ValueError, match="ALTERNATIVE_PRICE_UNAVAILABLE"):
        calculate_price_components(80_000, alternative, WITHOUT_CAFE_ORDER, 1)


def test_invalid_option_and_participant_count_are_rejected():
    with pytest.raises(ValueError, match="INVALID_PRICING_OPTION"):
        calculate_price_components(80_000, 140_000, "unknown", 1)
    with pytest.raises(ValueError, match="INVALID_PARTICIPANT_COUNT"):
        calculate_price_components(80_000, 140_000, BASE_OPTION, 0)


def test_panel_price_copy_hides_unavailable_option_and_shows_two_prices_when_enabled():
    one = panel_price_label(80_000, None)
    two = panel_price_label(80_000, 140_000)
    assert "۸۰" in one or "80" in one
    assert "بدون سفارش از کافه" not in one
    assert "80,000" in two
    assert "140,000" in two
    assert "بدون سفارش اجباری از منوی کافه" in two


def test_booking_option_labels_cover_v63_and_legacy_records():
    assert booking_option_label(BASE_OPTION) == "پایه + سفارش از منوی کافه"
    assert booking_option_label(WITHOUT_CAFE_ORDER) == "بدون سفارش اجباری از منوی کافه"
    assert "پیش از نسخه" in booking_option_label(None)
    assert booking_option_label(None, base_price=0) == "رایگان"


def test_v63_migration_is_additive_and_declares_all_price_fields():
    migration = (ROOT / "migrations" / "024_v63_optional_cafe_pricing.sql").read_text(encoding="utf-8").lower()
    assert "add column if not exists price_without_cafe_order" in migration
    assert "add column if not exists pricing_option" in migration
    assert "add column if not exists base_price_snapshot" in migration
    assert "add column if not exists alternative_price_snapshot" in migration
    assert "drop table" not in migration
    assert "drop column" not in migration


def test_code_keeps_single_panel_usage_policy_question_skipped_and_cap_copy_clear():
    source = (ROOT / "app" / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    assert "if len(selected_ids) == 1:" in source
    assert "حداکثر ۱۰ رزرو در مجموع" in source
    assert "رزرو سه‌نفره هم یک استفاده حساب می‌شود" in source
    assert "یک‌بار در مجموع" in source
    assert "یک‌بار در هر پنل" in source


def test_bot_api_dependency_is_new_enough_for_native_button_styles():
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "aiogram>=3.25" in requirements


def test_admin_receipt_option_line_includes_selected_per_person_price():
    standard = booking_option_detail_label(BASE_OPTION, base_price=80_000, alternative_price=140_000)
    alternative = booking_option_detail_label(WITHOUT_CAFE_ORDER, base_price=80_000, alternative_price=140_000)
    assert "۸۰" in standard or "80,000" in standard
    assert "سفارش از منوی کافه" in standard
    assert "۱۴۰" in alternative or "140,000" in alternative
    assert "بدون سفارش اجباری" in alternative


def test_user_flow_uses_saved_panel_message_and_checks_price_snapshot_before_booking():
    user = (ROOT / "app" / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    booking_service = (ROOT / "app" / "services" / "booking.py").read_text(encoding="utf-8")
    assert "booking_flow_message_id=(" in user
    assert 'expected_base_price=data.get("checkout_base_price")' in user
    assert 'expected_alternative_price=data.get("checkout_alternative_price")' in user
    assert 'if expected_base_price is not None' in booking_service
    assert 'if expected_alternative_price is not None' in booking_service
    assert 'raise ValueError("PRICE_CHANGED")' in booking_service


def test_free_price_option_skips_discount_prompt_and_payment_receipt():
    user = (ROOT / "app" / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    service = (ROOT / "app" / "services" / "booking.py").read_text(encoding="utf-8")
    assert 'if int(event.price_per_person or 0) == 0:' in user
    assert 'discount_prompt_skipped=True' in user
    assert 'if Decimal(event.price_per_person) == 0:' in service
    assert 'status=RegistrationStatus.CONFIRMED if immediate else RegistrationStatus.PENDING_PAYMENT' in service


def test_public_events_api_exposes_alternative_price_additively():
    api = (ROOT / "app" / "api.py").read_text(encoding="utf-8")
    serializer = (ROOT / "app" / "services" / "public_events.py").read_text(encoding="utf-8")
    assert "list_public_event_payloads" in api
    assert '"price_per_person": int(event.price_per_person)' in serializer
    assert '"price_without_cafe_order": (' in serializer
    assert 'if event.price_without_cafe_order is not None else None' in serializer


def test_discount_edit_preserves_old_approval_until_a_replacement_booking_commits():
    user = (ROOT / "app" / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    booking_service = (ROOT / "app" / "services" / "booking.py").read_text(encoding="utf-8")
    assert 'updates["continue_full_price_redemption_id"] = int(data["discount_redemption_id"])' in user
    assert 'old_redemption.status = "withdrawn"' in user
    assert "Withdraw the superseded request only together with a successfully" in booking_service


def test_replacing_an_approved_code_can_pair_with_a_distinct_new_code_atomically():
    booking_service = (ROOT / "app" / "services" / "booking.py").read_text(encoding="utf-8")
    assert "int(discount_redemption_id) == int(cancel_discount_redemption_id)" in booking_service
    assert 'withdrawal_redemption.status = "withdrawn"' in booking_service
