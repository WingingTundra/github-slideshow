from __future__ import annotations

import importlib.util
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_retention_module():
    spec = importlib.util.spec_from_file_location("prune_backups_v67", ROOT / "scripts/prune_backups.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_v67_backup_manifest_uses_relative_paths_and_verifies_before_publish():
    source = (ROOT / "scripts/backup.sh").read_text(encoding="utf-8")
    assert 'PGPASSWORD="$POSTGRES_PASSWORD" pg_dump' in source
    assert "sha256sum database.dump uploads.tar.gz > SHA256SUMS" in source
    assert "sha256sum -c SHA256SUMS" in source
    assert "release=V97" in source
    assert source.index("sha256sum -c SHA256SUMS") < source.index('mv "$ENC_TMP" "$FINAL"')
    assert "prune_backups.py" in source


def test_v67_restore_script_checks_empty_target_and_restores_database_and_uploads():
    source = (ROOT / "scripts/restore-backup.sh").read_text(encoding="utf-8")
    assert 'RESTORE_DATABASE_URL:?Set RESTORE_DATABASE_URL' in source
    assert 'RESTORE_UPLOAD_DIR:?Set RESTORE_UPLOAD_DIR' in source
    assert "sha256sum -c SHA256SUMS" in source
    assert "pg_restore --exit-on-error --no-owner --no-privileges" in source
    assert 'Refusing restore: target database contains' in source
    assert 'tar -xzf "$RESTORE_DIR/uploads.tar.gz" -C "$RESTORE_UPLOAD_DIR"' in source


def test_v67_restore_integration_script_only_uses_named_disposable_containers():
    source = (ROOT / "scripts/test-backup-restore.sh").read_text(encoding="utf-8")
    assert "postgres:17" in source
    assert "RESTORE_DATABASE_URL=\"postgresql://$DB_USER:$DB_PASSWORD@$TARGET:5432/panel_flow_restore_test\"" in source
    assert "panel_flow_source" in source
    assert "panel_flow_restore_test" in source
    assert "phase1_restore_ok" in source
    assert "docker compose exec" not in source


def test_v67_service_environment_is_allowlisted_and_api_healthcheck_is_lightweight():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    assert "env_file: .env" not in compose
    assert "BACKUP_ENCRYPTION_KEY" in compose
    backup = compose.split("  backup:\n", 1)[1].split("\nvolumes:", 1)[0]
    bot = compose.split("  bot:\n", 1)[1].split("\n  api:\n", 1)[0]
    api = compose.split("  api:\n", 1)[1].split("\n  backup:\n", 1)[0]
    assert "BACKUP_ENCRYPTION_KEY" in backup
    assert "BACKUP_ENCRYPTION_KEY" not in bot
    assert "BACKUP_ENCRYPTION_KEY" not in api
    # Website-triggered Telegram notification tasks run in the API process;
    # the existing bot token is an explicit allowlisted secret, never a website build arg.
    assert "BOT_TOKEN: ${BOT_TOKEN:-}" in api
    website = compose.split("  website:\n", 1)[1].split("\nvolumes:", 1)[0]
    assert "BOT_TOKEN" not in website
    assert "PAYMENT_CARD_NUMBER" not in api
    assert "healthcheck:" in api and "/health/ready" in api and "/health/db" not in api
    assert "interval: 60s" in api


def test_v67_cancellation_requires_confirmation_and_tracks_unresolved_financial_cases():
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    keyboard = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    models = (ROOT / "app/db/models.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations/027_v67_cancellation_financial_resolution.sql").read_text(encoding="utf-8").lower()
    assert "admin:event:cancel:confirm:" in admin and "admin:event:cancel:abort:" in admin
    assert "RegistrationStatus.CANCELLED" in admin
    cancellation_service = (ROOT / "app/services/event_cancellation.py").read_text(encoding="utf-8")
    assert 'booking.cancellation_resolution = "action_required"' in cancellation_service
    assert 'booking.cancellation_resolved_at = None' in cancellation_service  # unresolved financial cases remain genuinely unresolved
    assert 'admin:cancellation_cases' in keyboard
    assert 'cancellation_resolution: Mapped[str]' in models
    assert "add column if not exists cancellation_resolution" in migration
    assert "drop table" not in migration and "truncate" not in migration
    assert re.search(r"payment\.status\s*=(?!=)", admin[admin.index("async def event_cancel_confirm"):admin.index("CANCELLATION_CASE_PAGE_SIZE")]) is None


def test_v80_my_bookings_hides_cancelled_history_but_preserves_unresolved_financial_followups():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    block = user.split("async def render_my_bookings", 1)[1].split('@router.callback_query(F.data == "user:bookings")', 1)[0]
    assert "RegistrationStatus.CANCELLED," not in block
    assert "Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED))" in block
    assert 'Booking.cancellation_resolution == "action_required"' in block
    assert "Event.status == EventStatus.CANCELLED" in block
    assert "به معنی انجام بازپرداخت نیست" in block


def test_v67_daily_weekly_monthly_retention_selects_expected_archive_representatives(tmp_path):
    module = _load_retention_module()
    # Three backups on the same day: only the latest should be retained by the daily bucket.
    stamps = [
        "20261024T010000Z", "20261024T020000Z", "20261024T030000Z",
        "20261022T030000Z", "20261017T030000Z", "20261010T030000Z",
        "20260924T030000Z", "20260824T030000Z", "20251024T030000Z",
    ]
    paths = []
    for stamp in stamps:
        path = tmp_path / f"panel-flow-{stamp}.tar.gz.enc"
        path.write_bytes(b"x")
        paths.append(path)
    (tmp_path / "not-a-backup.txt").write_text("keep", encoding="utf-8")
    deleted = module.prune(tmp_path, daily=7, weekly=4, monthly=12,
                           now=datetime(2026, 10, 24, 12, 0, tzinfo=timezone.utc))
    remaining = {p.name for p in tmp_path.glob("panel-flow-*.tar.gz.enc")}
    assert "panel-flow-20261024T030000Z.tar.gz.enc" in remaining
    assert "panel-flow-20261024T020000Z.tar.gz.enc" not in remaining
    assert "panel-flow-20261024T010000Z.tar.gz.enc" not in remaining
    assert "panel-flow-20260924T030000Z.tar.gz.enc" in remaining
    assert "panel-flow-20251024T030000Z.tar.gz.enc" not in remaining
    assert len(deleted) >= 3
    assert (tmp_path / "not-a-backup.txt").exists()
