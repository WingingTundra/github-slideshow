"""Release-level regressions for V59 copy, command routing, and checkout safety."""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
USER = (APP / "bot/handlers/user.py").read_text(encoding="utf-8")
COMMUNITY = (APP / "bot/handlers/community.py").read_text(encoding="utf-8")
CONTENT = (APP / "bot/content.py").read_text(encoding="utf-8")
KEYBOARDS = (APP / "bot/keyboards.py").read_text(encoding="utf-8")
COMMUNITY_SERVICE = (APP / "services/community.py").read_text(encoding="utf-8")
BOOKING_SERVICE = (APP / "services/booking.py").read_text(encoding="utf-8")
PAYMENT_ACTIONS = (APP / "bot/handlers/admin_payment_actions.py").read_text(encoding="utf-8")


def _function_source(source: str, name: str) -> str:
    tree = ast.parse(source)
    node = next(
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
    )
    return ast.get_source_segment(source, node) or ""


def test_onboarding_prompts_are_centralized_and_match_the_approved_copy():
    assert 'return "به Panel Flow خوش آمدید. 🎉\\n\\nلطفاً نام و نام خانوادگی خود را در یک پیام وارد کنید."' in CONTENT
    assert "لطفاً نام و نام خانوادگی‌تان را در یک پیام وارد کنید. مثال: سینا ضیائی یا Sara Williams." in CONTENT
    assert "✅ نام و نام خانوادگی ثبت شد." in CONTENT
    assert "شمارهٔ تماس خود را وارد کنید.\\n" in CONTENT
    assert "<i>شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in CONTENT
    for function_name in ("continue_onboarding", "begin_register_from_message"):
        assert "onboarding_full_name_prompt()" in _function_source(USER, function_name)
    assert "onboarding_full_name_prompt()" in _function_source(COMMUNITY, "show_challenge_from_message")
    assert "phone_number_prompt()" in _function_source(COMMUNITY, "show_challenge_from_message")
    assert "invalid_full_name_prompt()" in _function_source(USER, "save_full_name")
    assert "accepted_name_phone_prompt()" in _function_source(USER, "_continue_profile_after_name")


def test_referral_copy_hides_implementation_details_and_keeps_self_referral_explicit():
    prompt = _function_source(USER, "referral_prompt_yes")
    referral_handler = _function_source(USER, "referral_code_received")
    assert "کد معرف دوستی را که شما را به Panel Flow معرفی کرده وارد کنید" in prompt
    assert "numeric Telegram ID" not in prompt
    assert "این کد معتبر نیست یا هنوز قابل استفاده نیست" in referral_handler
    assert "نمی‌توانید کد معرفی خودتان را وارد کنید." in referral_handler


def test_receipt_waitlist_cancellation_and_rejection_copy_preserve_next_steps():
    assert "✅ رسید شما دریافت شد." in USER
    assert "پس از بررسی، نتیجه را به شما اطلاع می‌دهیم. تا آن زمان نیازی به ارسال مجدد رسید نیست." in USER
    assert "جایگاه فعلی شما:" in USER
    assert "عضویت در لیست انتظار به معنی رزرو قطعی نیست." in USER
    cancel = _function_source(USER, "cancel_interaction")
    assert "✅ مرحلهٔ فعلی لغو شد." in cancel
    assert "رزروهای ثبت‌شده تغییر نکردند." in cancel
    assert "_show_receipt_cancel_confirmation(message, state, booking_id)" in cancel  # /cancel requires the same explicit confirmation.
    receipt_cancel = _function_source(USER, "_cancel_receipt_stage_booking")
    assert "فرایند ثبت‌نام و رزرو #{booking_id} لغو شد" in receipt_cancel
    assert "رسید پرداخت شما برای پنل" in PAYMENT_ACTIONS
    assert "مبلغ رزرو:" in PAYMENT_ACTIONS
    assert "می‌توانید رسید دیگری ارسال کنید یا رزرو خود را لغو کنید." in PAYMENT_ACTIONS


def test_submission_success_text_matches_topic_question_and_feedback():
    submit_flow = _function_source(USER, "submit_question")
    assert '"question": "✅ پیشنهاد سؤال شما ثبت شد.' in submit_flow
    assert '"topic": "✅ پیشنهاد موضوع شما ثبت شد.' in submit_flow
    assert '"feedback": "✅ بازخورد شما ثبت شد.' in submit_flow
    assert "برای پیگیری پاسخ، بعداً به بخش «پیشنهاد سؤال» مراجعه کنید." in submit_flow


def test_help_and_about_use_current_catalogue_labels_and_real_support_link():
    help_text = _function_source(CONTENT, "user_help_text")
    about_text = _function_source(CONTENT, "about_text")
    assert "پنل‌های پیش‌رو" in help_text
    assert "ثبت‌نام‌های من" in help_text
    assert "پیگیری وضعیت رزروها و پرداخت‌ها" in help_text
    assert "فایل‌های منتشرشدهٔ پنل‌هایی که رزرو تأییدشده دارید" in help_text
    assert "همهٔ پنل‌ها فایل سؤال ندارند" in help_text
    assert "پشتیبانی انسانی" in help_text and "support_link_html()" in help_text
    assert "بعضی وضعیت‌ها تا بررسی مدیر نهایی نمی‌شوند" not in help_text
    assert "regular, structured discussion panels" in about_text
    assert "پنل‌های گفت‌وگوی منظم و ساختارمند" in about_text
    assert "پنل‌های منتشرشده" not in about_text


def test_community_user_interface_is_persian_but_challenge_prompts_remain_dynamic():
    menu = KEYBOARDS.split("def community_menu_keyboard", 1)[1].split("def admin_community_menu", 1)[0]
    assert 'text="🏆 لیدربورد ⁦Panel Flow⁩"' in menu
    assert 'text="🎯 چالش‌ها"' in menu
    assert 'text="🪪 پاسپورت من"' in menu
    assert 'text="🔙 منوی اصلی"' in menu
    home = _function_source(COMMUNITY, "render_community_home")
    assert "🏆 <b>لیدربورد و چالش‌ها</b>" in home
    assert "Quick Fun" not in home
    assert "لیدربورد" in home and 'ltr_isolate("XP")' in home and "شاپ" in home
    assert 'text="✍️ ارسال پاسخ"' in COMMUNITY
    assert "🏅 برگزیدگان" in COMMUNITY
    assert "Invalid page." not in COMMUNITY.split("# --------------------------- Administrator community tools", 1)[0]
    assert 'escape(challenge.prompt)' in _function_source(COMMUNITY, "challenge_view_callback")
    wrapped = _function_source(COMMUNITY_SERVICE, "make_wrapped_text")
    assert "تعداد پنل‌های شرکت‌شده" in wrapped
    assert "پاسخ‌های چالش" in wrapped
    assert "از اینکه بخشی از جامعهٔ Panel Flow هستید سپاسگزاریم" in wrapped


def test_admin_command_precedes_fsm_input_and_never_becomes_receipt_or_user_text():
    # This registration order is intentional: the general command catcher is
    # registered before name, booking, receipt, question, review and challenge text handlers.
    command_handler = USER.index("@router.message(UnsupportedTelegramCommand())")
    for state_handler in (
        "@router.message(ProfileStates.waiting_full_name)",
        "@router.message(BookingStates.waiting_count)",
        "@router.message(BookingStates.waiting_receipt, F.photo)",
        "@router.message(QuestionStates.waiting_text)",
        "@router.message(ReviewStates.waiting_comment)",
    ):
        assert command_handler < USER.index(state_handler)
    command_filter = _function_source(USER, "__call__") if False else USER.split("class UnsupportedTelegramCommand", 1)[1].split("async def get_or_create_user", 1)[0]
    assert 'command.casefold() == "admin"' in command_filter
    admin_handler = _function_source(USER, "unsupported_command")
    assert "داشبورد مدیریتی Panel Flow" in admin_handler
    assert "_request_admin_navigation_confirmation" in admin_handler
    assert "reply_markup=admin_menu()" in admin_handler
    admin_source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    navigation_guard = admin_source.split("async def _request_admin_navigation_confirmation", 1)[1].split("\n\n@router.message(Command(\"admin\"))", 1)[0]
    assert "BookingStates.waiting_receipt.state" in navigation_guard
    assert "برای ادامه، رسید را ارسال کنید" in navigation_guard


def test_stale_navigation_buttons_do_not_clear_an_active_user_flow():
    helper = _function_source(USER, "_protect_active_user_flow")
    assert "await state.get_state()" in helper
    assert "برای لغو /cancel را بزنید" in helper
    assert "state.clear()" not in helper
    for name in ("events_callback", "events_page_callback", "open_event", "home"):
        handler = _function_source(USER, name)
        assert "_protect_active_user_flow(c, state)" in handler


def test_checkout_configuration_gate_is_before_booking_insert_and_retry_hold():
    create_booking = BOOKING_SERVICE.split("async def create_booking", 1)[1].split("async def retry_payment", 1)[0]
    assert 'raise ValueError("PAYMENT_CONFIGURATION_MISSING")' in create_booking
    assert create_booking.index('raise ValueError("PAYMENT_CONFIGURATION_MISSING")') < create_booking.index("booking = Booking(")
    finalize = _function_source(USER, "finalize_booking")
    assert "payment_details_configured=bool(payment_card_number and payment_account_name)" in finalize
    assert "PAYMENT_CONFIGURATION_MISSING" in finalize and "_notify_payment_configuration_missing" in finalize
    retry = _function_source(USER, "retry_receipt")
    assert retry.index("not (payment_card_number and payment_account_name)") < retry.index("booking = await retry_payment")
    receipt_upload = _function_source(USER, "continue_receipt_upload")
    assert receipt_upload.index("not (payment_card_number and payment_account_name)") < receipt_upload.index("await state.update_data(booking_id=booking_id)")
    assert '"در تنظیمات ربات"' not in USER


def test_current_release_marker_and_historical_additive_migrations_are_documented():
    marker = (APP / "db/init.py").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    migration_022 = (ROOT / "migrations/022_v62_audit_receipt_history_reward_batches_and_post_links.sql").read_text(encoding="utf-8").lower()
    migration_023 = (ROOT / "migrations/023_v62_resilient_broadcasts.sql").read_text(encoding="utf-8").lower()
    assert "Panel Flow V97 database initialization started" in marker
    assert "# Panel Flow Telegram Bot V97" in readme
    assert "## V94 Highlights (retained)" in readme
    assert "022_v62_audit_receipt_history_reward_batches_and_post_links.sql" in readme
    assert "023_v62_resilient_broadcasts.sql" in readme
    for sql in (migration_022, migration_023):
        assert "drop table" not in sql
        assert "truncate" not in sql
    assert "create table" in migration_022
    assert "create table" in migration_023
