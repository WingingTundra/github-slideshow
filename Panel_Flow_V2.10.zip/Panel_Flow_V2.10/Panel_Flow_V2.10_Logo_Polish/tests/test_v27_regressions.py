from __future__ import annotations

import asyncio
import socket
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.config import settings
from app.db.models import (
    Base,
    Booking,
    BookingConfirmationLedger,
    Event,
    EventStatus,
    RegistrationStatus,
    User,
)
from app.services.booking import create_booking
from app.services.confirmation_ledger import record_confirmed_booking
from app.db import init as db_init


ROOT = Path(__file__).resolve().parents[1]


class AsyncSessionAdapter:
    """Small async-compatible adapter over SQLite for deterministic service tests."""
    def __init__(self, session: Session):
        self.sync = session

    async def execute(self, statement):
        return self.sync.execute(statement)

    async def get(self, entity, ident, **kwargs):
        return self.sync.get(entity, ident)

    def add(self, obj):
        self.sync.add(obj)

    async def flush(self):
        self.sync.flush()

    async def commit(self):
        self.sync.commit()

    async def refresh(self, obj):
        self.sync.refresh(obj)


def _db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, AsyncSessionAdapter(Session(engine))


def _seed(session, *, price=Decimal("100000"), capacity=5):
    user = User(telegram_id=44001, first_name="Sina", last_name="Ziaei")
    host = User(telegram_id=44002, first_name="Host", last_name="User")
    session.add(user)
    session.add(host)
    session.sync.flush()
    event = Event(
        volume=27,
        title="V27 Regression Panel",
        event_day_label="Saturday",
        event_date_label="10 October 2026",
        start_time_label="18:00",
        end_time_label="20:00",
        venue="Test Venue",
        capacity=capacity,
        price_per_person=price,
        status=EventStatus.PUBLISHED,
        registration_open=True,
        waitlist_enabled=True,
        host_id=host.id,
        host_name="Host User",
    )
    session.add(event)
    session.sync.commit()
    return user, event


def test_database_retryable_error_classification_is_narrow():
    temporary_dns = socket.gaierror(socket.EAI_AGAIN, "Temporary failure in name resolution")
    permanent_dns = socket.gaierror(socket.EAI_NONAME, "Name or service not known")
    assert db_init.is_retryable_database_error(temporary_dns)
    assert not db_init.is_retryable_database_error(permanent_dns)
    assert not db_init.is_retryable_database_error(ValueError("password authentication failed"))


def test_database_startup_retries_transient_dns_then_succeeds(monkeypatch):
    monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://tester:secret@db:5432/panel_flow")
    monkeypatch.setattr(settings, "database_startup_max_attempts", 3)
    monkeypatch.setattr(settings, "database_startup_retry_initial_seconds", 0.0)
    monkeypatch.setattr(settings, "database_startup_retry_max_seconds", 0.0)
    attempts = {"count": 0}

    async def initialize_once():
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise socket.gaierror(socket.EAI_AGAIN, "Temporary failure in name resolution")

    async def no_sleep(_delay):
        return None

    monkeypatch.setattr(db_init, "_init_db_once", initialize_once)
    monkeypatch.setattr(db_init.asyncio, "sleep", no_sleep)
    asyncio.run(db_init.init_db())
    assert attempts["count"] == 2


def test_database_startup_retry_exhaustion_is_bounded_and_actionable(monkeypatch):
    monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://tester:secret@db:5432/panel_flow")
    monkeypatch.setattr(settings, "database_startup_max_attempts", 3)
    monkeypatch.setattr(settings, "database_startup_retry_initial_seconds", 0.0)
    monkeypatch.setattr(settings, "database_startup_retry_max_seconds", 0.0)
    attempts = {"count": 0}

    async def fail_every_time():
        attempts["count"] += 1
        raise socket.gaierror(socket.EAI_AGAIN, "Temporary failure in name resolution")

    async def no_sleep(_delay):
        return None

    monkeypatch.setattr(db_init, "_init_db_once", fail_every_time)
    monkeypatch.setattr(db_init.asyncio, "sleep", no_sleep)
    with pytest.raises(RuntimeError, match="bounded retries"):
        asyncio.run(db_init.init_db())
    assert attempts["count"] == 3


def test_database_startup_does_not_retry_non_retryable_configuration_error(monkeypatch):
    monkeypatch.setattr(settings, "database_url", "postgresql+asyncpg://tester:secret@db:5432/panel_flow")
    monkeypatch.setattr(settings, "database_startup_max_attempts", 5)
    attempts = {"count": 0}

    async def fail_configuration():
        attempts["count"] += 1
        raise ValueError("invalid database configuration")

    monkeypatch.setattr(db_init, "_init_db_once", fail_configuration)
    with pytest.raises(RuntimeError, match="non-retryable"):
        asyncio.run(db_init.init_db())
    assert attempts["count"] == 1


def test_missing_database_url_fails_before_connection_attempt(monkeypatch):
    monkeypatch.setattr(settings, "database_url", "")
    attempts = {"count": 0}

    async def should_not_run():
        attempts["count"] += 1

    monkeypatch.setattr(db_init, "_init_db_once", should_not_run)
    with pytest.raises(RuntimeError, match="DATABASE_URL"):
        asyncio.run(db_init.init_db())
    assert attempts["count"] == 0



def test_lazy_database_exports_fail_clearly_when_configuration_is_missing(monkeypatch):
    from app.db.session import SessionLocal, engine as lazy_engine

    monkeypatch.setattr(settings, "database_url", "")
    with pytest.raises(RuntimeError, match="DATABASE_URL"):
        lazy_engine.begin()
    with pytest.raises(RuntimeError, match="DATABASE_URL"):
        SessionLocal()

def test_lifetime_confirmation_ledger_increments_once_and_survives_booking_deletion():
    engine, session = _db()
    try:
        user, event = _seed(session)
        booking = Booking(
            event_id=event.id,
            booked_by_user_id=user.id,
            participant_count=1,
            total_amount=Decimal("100000"),
            status=RegistrationStatus.PENDING_PAYMENT,
        )
        session.add(booking)
        session.sync.flush()
        booking.status = RegistrationStatus.CONFIRMED
        assert asyncio.run(record_confirmed_booking(session, booking)) is True
        assert asyncio.run(record_confirmed_booking(session, booking)) is False
        session.sync.commit()
        session.sync.refresh(user)
        assert user.lifetime_confirmed_bookings == 1
        assert session.sync.scalar(select(BookingConfirmationLedger).where(
            BookingConfirmationLedger.booking_id == booking.id
        )) is not None

        booking_id = booking.id
        session.sync.delete(booking)
        session.sync.commit()
        session.sync.refresh(user)
        assert user.lifetime_confirmed_bookings == 1
        assert session.sync.scalar(select(BookingConfirmationLedger).where(
            BookingConfirmationLedger.booking_id == booking_id
        )) is not None
    finally:
        session.sync.close()
        engine.dispose()


def test_free_booking_confirmation_uses_the_same_lifetime_ledger():
    engine, session = _db()
    try:
        user, event = _seed(session, price=Decimal("0"), capacity=2)
        booking = asyncio.run(create_booking(
            session,
            user.id,
            event.id,
            [{"first_name": "Sina", "last_name": "Ziaei"}],
        ))
        assert booking.status == RegistrationStatus.CONFIRMED
        session.sync.refresh(user)
        assert user.lifetime_confirmed_bookings == 1
        assert session.sync.scalar(select(BookingConfirmationLedger).where(
            BookingConfirmationLedger.booking_id == booking.id
        )) is not None
    finally:
        session.sync.close()
        engine.dispose()


def test_v27_migration_and_user_workflows_contain_expected_lifecycle_guards():
    migration = (ROOT / "migrations/010_lifecycle_waitlist_and_confirmation_ledger.sql").read_text(encoding="utf-8")
    user_source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    admin_source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "ADD COLUMN IF NOT EXISTS lifetime_confirmed_bookings" in migration
    assert "UNIQUE (booking_id)" in migration
    assert "uq_waitlist_active_event_user" in migration
    assert "Event.archived.is_(False)" in user_source
    assert "Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED))" in user_source
    assert "expire_old_bookings" in admin_source
    assert "پنل‌های آرشیوشده" in admin_source


def test_requested_copy_and_receipt_navigation_are_exact_and_scoped():
    user_source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    content_source = (ROOT / "app/bot/content.py").read_text(encoding="utf-8")
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    assert "شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in content_source
    assert "شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in content_source
    assert "phone_number_prompt()" in user_source
    assert "لازم نیست با شمارهٔ حساب تلگرام شما یکسان باشد." not in user_source
    assert r"\n\n" in user_source
    assert r'text="💬 جامعه و دربارهٔ ما"' in keyboards
    assert 'text="📢 Telegram Channel"' in keyboards
    assert 'text="👥 Telegram Group"' in keyboards
    assert 'callback_data=f"admin:payment:next:{payment_id}:{scope}"' in keyboards
    assert 'F.data.startswith("admin:payment:next:")' in admin
    assert 'callback_data=f"user:booking:cancel:confirm:{booking_id}"' in keyboards


def test_all_migrations_split_into_executable_statements():
    from app.db.migration_utils import split_sql_statements

    migrations = sorted((ROOT / "migrations").glob("*.sql"))
    assert len(migrations) >= 10
    for migration in migrations:
        statements = split_sql_statements(migration.read_text(encoding="utf-8"))
        assert statements, f"empty migration: {migration.name}"
        assert all(statement.strip() for statement in statements)
    v27 = split_sql_statements((ROOT / "migrations/010_lifecycle_waitlist_and_confirmation_ledger.sql").read_text(encoding="utf-8"))
    assert any("booking_confirmation_ledger" in statement for statement in v27)
