"""V80 regressions for attendance ranking, durable FSM, and public challenge access."""
from __future__ import annotations

import ast
from pathlib import Path

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.db.models import (
    AttendanceStatus, Base, Booking, Event, EventStatus, Participant,
    RegistrationStatus, User, UserRole,
)
from app.services.community import _attendance_count_subquery

ROOT = Path(__file__).resolve().parents[1]


def _completed_event(title: str, status: EventStatus = EventStatus.COMPLETED) -> Event:
    return Event(
        volume=title, title=title, venue="Test venue", capacity=20,
        price_per_person=0, status=status, registration_open=False,
    )


def _user(telegram_id: int) -> User:
    return User(
        telegram_id=telegram_id, first_name=f"Test{telegram_id}", last_name="Member",
        role=UserRole.PARTICIPANT,
    )


def _booking(user: User, event: Event, *, status=RegistrationStatus.CONFIRMED,
             registrant_attends: bool | None = True, attendance=AttendanceStatus.UNMARKED,
             participant_user_id: int | None = None) -> Booking:
    booking = Booking(
        event=event, booked_by=user, participant_count=1, total_amount=0,
        status=status, registrant_attends=registrant_attends,
    )
    booking.participants.append(Participant(
        full_name=f"{user.first_name} attendee", attendance_status=attendance,
        user_telegram_id=participant_user_id,
    ))
    return booking


def test_attendance_subquery_uses_completed_confirmed_booking_and_absence_override():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        # Free confirmed registrant counts without any paid_panel XP award.
        free = _user(1001)
        free.bookings.append(_booking(free, _completed_event("free"), registrant_attends=True,
                                      participant_user_id=1001))
        # Fully discounted/free in terms of total_amount is also eligible.
        discounted = _user(1002)
        discounted.bookings.append(_booking(discounted, _completed_event("discounted"),
                                            registrant_attends=True, participant_user_id=1002))
        # Explicitly absent account-holder does not count.
        absent = _user(1003)
        absent.bookings.append(_booking(absent, _completed_event("absent"), registrant_attends=True,
                                        attendance=AttendanceStatus.NO_SHOW, participant_user_id=1003))
        # Pending booking does not count, even on a completed event.
        pending = _user(1004)
        pending.bookings.append(_booking(pending, _completed_event("pending"),
                                         status=RegistrationStatus.PENDING_VERIFICATION,
                                         registrant_attends=True, participant_user_id=1004))
        # Published but not completed panels do not count.
        upcoming = _user(1005)
        upcoming.bookings.append(_booking(upcoming, _completed_event("upcoming", EventStatus.PUBLISHED),
                                          registrant_attends=True, participant_user_id=1005))
        # New guest-only booking must not credit the booking account.
        guest_only = _user(1006)
        guest_only.bookings.append(_booking(guest_only, _completed_event("guest-only"),
                                            registrant_attends=False, participant_user_id=None))
        # Legacy NULL field means presumed-present; no historical identity is fabricated.
        legacy = _user(1007)
        legacy.bookings.append(_booking(legacy, _completed_event("legacy"),
                                        registrant_attends=None, participant_user_id=None))
        # Reverting an explicit absence to UNMARKED restores the presumed-present default.
        reverted = _user(1008)
        reverted.bookings.append(_booking(reverted, _completed_event("reverted"),
            registrant_attends=True, attendance=AttendanceStatus.UNMARKED, participant_user_id=1008))
        # A canceled panel, rejected registration, and waitlist-only row never count.
        cancelled_panel = _user(1009)
        cancelled_panel.bookings.append(_booking(cancelled_panel,
            _completed_event("cancelled-panel", EventStatus.CANCELLED), registrant_attends=True,
            participant_user_id=1009))
        rejected = _user(1010)
        rejected.bookings.append(_booking(rejected, _completed_event("rejected"),
            status=RegistrationStatus.REJECTED, registrant_attends=True, participant_user_id=1010))
        waiting = _user(1011)
        waiting.bookings.append(_booking(waiting, _completed_event("waiting"),
            status=RegistrationStatus.WAITLISTED, registrant_attends=True, participant_user_id=1011))
        session.add_all([free, discounted, absent, pending, upcoming, guest_only, legacy,
                         reverted, cancelled_panel, rejected, waiting])
        session.commit()
        aggregate = _attendance_count_subquery()
        actual = dict(session.execute(select(aggregate.c.tg, aggregate.c.panels)).all())
    assert actual == {1001: 1, 1002: 1, 1007: 1, 1008: 1}
    engine.dispose()


def test_attendance_ranking_deduplicates_same_panel_and_counts_distinct_panels():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        user = _user(2001)
        event = _completed_event("same panel")
        other_event = _completed_event("other panel")
        user.bookings.extend([
            _booking(user, event, registrant_attends=True, participant_user_id=2001),
            _booking(user, event, registrant_attends=True, participant_user_id=2001),
            _booking(user, other_event, registrant_attends=True, participant_user_id=2001),
        ])
        session.add(user)
        session.commit()
        aggregate = _attendance_count_subquery()
        actual = session.scalar(select(aggregate.c.panels).where(aggregate.c.tg == 2001))
    assert actual == 2
    engine.dispose()


def test_fsm_storage_is_persistent_bounded_and_serialized_per_storage_key():
    source = (ROOT / "app/bot/persistent_storage.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations/036_v80_persistent_fsm_and_attendance_ranking.sql").read_text(encoding="utf-8")
    main = (ROOT / "app/bot/main.py").read_text(encoding="utf-8")
    assert "class PostgresFSMStorage(BaseStorage)" in source
    assert "on_conflict_do_nothing" in source and "with_for_update" in source
    assert "expires_at <= utc_now_naive()" in source
    assert "pg_advisory_xact_lock" in source
    assert "event_isolation = PostgresEventIsolation()" in main
    assert "Dispatcher(storage=fsm_storage, events_isolation=event_isolation)" in main
    assert "event_isolation_engine.begin()" in source
    assert "CREATE TABLE IF NOT EXISTS fsm_conversations" in migration
    assert "ADD COLUMN IF NOT EXISTS registrant_attends BOOLEAN NULL" in migration
    assert "ADD COLUMN IF NOT EXISTS user_telegram_id BIGINT NULL" in migration


def test_public_challenge_paths_only_render_public_lifecycle_states():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    assert 'challenge.status not in {"open", "closed", "published"}' in source
    assert 'challenge.status not in {"open", "closed", "published"} or not challenge.prompt' in source
    user_view = source.split('async def challenge_view_callback', 1)[1].split('\n\n@router.', 1)[0]
    assert 'challenge.status not in {"open", "closed", "published"}' in user_view
    link = source.split('async def admin_challenge_link', 1)[1].split('\n\n@router.', 1)[0]
    assert 'challenge.status not in {"open", "closed", "published"}' in link


def test_achievement_acknowledges_only_rendered_unlock_record_ids():
    source = (ROOT / "app/bot/handlers/community.py").read_text(encoding="utf-8")
    function = source.split('async def _show_pending_achievement_popup', 1)[1].split('\n\nasync def ', 1)[0]
    assert 'visible = pending[:4]' in function
    assert 'visible_ids' in function
    assert 'AchievementUnlock.id.in_(pending_ids)' in function
    assert 'set(row.title for row in pending)' not in function


def test_authorization_is_canonical_uncached_and_rechecks_restrictions():
    auth = (ROOT / "app/services/authorization.py").read_text(encoding="utf-8")
    middleware = (ROOT / "app/bot/middleware.py").read_text(encoding="utf-8")
    wrappers = [
        ROOT / "app/bot/handlers/admin.py",
        ROOT / "app/bot/handlers/community.py",
        ROOT / "app/bot/handlers/attendance.py",
        ROOT / "app/bot/handlers/topics.py",
        ROOT / "app/bot/handlers/admin_console.py",
        ROOT / "app/bot/handlers/admin_features.py",
        ROOT / "app/bot/handlers/admin_payment_actions.py",
        ROOT / "app/bot/handlers/v77_features.py",
    ]
    assert "User.role == UserRole.SUPER_ADMIN" in auth
    assert "BlockedUser.telegram_id" in auth and 'UserModerationRecord.action == "suspension"' in auth
    assert "inspect_account_access" in middleware
    assert "return await handler(event, data)" in middleware
    for path in wrappers:
        assert "services.authorization" in path.read_text(encoding="utf-8"), path.name


def test_registration_upsert_and_migration_are_additive():
    source = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    onboarding = (ROOT / "app/services/community.py").read_text(encoding="utf-8")
    migration = (ROOT / "migrations/036_v80_persistent_fsm_and_attendance_ranking.sql").read_text(encoding="utf-8")
    create_user = source.split('async def get_or_create_user', 1)[1].split('\n\nasync def ', 1)[0]
    assert "pg_insert(User)" in create_user and "on_conflict_do_update" in create_user
    assert "pg_insert(CommunityProfile)" in onboarding and "on_conflict_do_nothing" in onboarding
    assert "DROP TABLE" not in migration and "DELETE FROM" not in migration


def test_needs_attention_dashboard_links_to_existing_queues_and_protects_fsm():
    dashboard = (ROOT / "app/bot/handlers/admin_features.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    dependencies = (ROOT / "app/http_api/dependencies.py").read_text(encoding="utf-8")
    assert "_request_admin_navigation_confirmation(c, state)" in dashboard
    for callback in ("admin:pending_payments:page:0", "admin:cancellation_cases",
                     "admin:console:reviews", "admin:console:host-notifications:page:0",
                     "admin:events", "admin:v77:rewards:queue:0",
                     "admin:v78:notifications:retry"):
        assert callback in dashboard
    assert "active_account_restriction(user.telegram_id)" in dependencies
    assert "def _request_admin_navigation_confirmation" in admin
