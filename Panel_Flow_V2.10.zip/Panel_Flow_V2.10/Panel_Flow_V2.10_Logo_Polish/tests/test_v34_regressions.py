from pathlib import Path

from app.db.migration_utils import split_sql_statements
from app.db.models import Booking


ROOT = Path(__file__).resolve().parents[1]


def test_register_callbacks_use_clicking_user_and_reuse_profile_identity():
    user = (ROOT / "app/bot/handlers/user.py").read_text(encoding="utf-8")
    keyboards = (ROOT / "app/bot/keyboards.py").read_text(encoding="utf-8")

    assert "telegram_user=None" in user
    assert "identity = telegram_user or message.from_user" in user
    assert user.count("telegram_user=c.from_user") == 3
    assert 'callback_data=f"booking:count:{count}"' in keyboards
    assert 'participants = [] if additional_booking' in user
    assert 'participants = [] if additional_booking else [{' in user
    assert '"first_name": owner.first_name' in user and '"last_name": owner.last_name' in user
    assert "if count == 1 and not additional_booking:\n        await show_booking_summary(message, state)" in user
    assert 'نام و نام خانوادگی نفر ۲ را یکجا وارد کنید:' in user
    assert "booking_count_keyboard(max_count)" in user


def test_workbook_tracks_discount_kind_after_code_cleanup():
    model_columns = Booking.__table__.columns
    assert "discount_code_kind_snapshot" in model_columns
    booking_service = (ROOT / "app/services/booking.py").read_text(encoding="utf-8")
    export_service = (ROOT / "app/services/excel_export.py").read_text(encoding="utf-8")
    assert "discount_code_kind_snapshot=discount_code.kind if discount_code else None" in booking_service
    assert "مبلغ نهایی هر نفر (تومان)" in export_service
    assert "مبلغ نهایی کل رزرو (تومان)" in export_service
    assert 'kind in {"restricted", "personal"}' in export_service


def test_v34_discount_snapshot_migration_is_safe_and_parseable():
    migration_path = ROOT / "migrations/015_booking_discount_kind_snapshot.sql"
    sql = migration_path.read_text(encoding="utf-8")
    statements = split_sql_statements(sql)
    assert len(statements) == 1
    assert "ADD COLUMN IF NOT EXISTS discount_code_kind_snapshot VARCHAR(20)" in statements[0]
