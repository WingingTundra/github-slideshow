"""V81 regression checks for submission-time authorization of persistent admin FSMs."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _function_source(source: str, function_name: str) -> str:
    marker = f"async def {function_name}("
    assert marker in source, f"missing function {function_name}"
    body = source.split(marker, 1)[1]
    return body.split("\n\nasync def ", 1)[0].split("\n\n@router.", 1)[0]


def test_sensitive_admin_fsm_submissions_revalidate_current_role_before_mutation():
    source = (ROOT / "app/bot/handlers/admin.py").read_text(encoding="utf-8")
    cases = {
        "channel_updates_threshold_save": "set_setting(session, CHANNEL_UPDATE_THRESHOLD",
        "event_pdf_replace": "event.questions_pdf_path = path",
        "event_pdf_replace_wrong": "event.questions_pdf_path = None",
    }
    for name, mutation in cases.items():
        body = _function_source(source, name)
        guard = "not await is_admin(m.from_user.id)"
        assert guard in body, f"{name} must re-check the live Admin role"
        assert body.index(guard) < body.index(mutation), f"{name} mutates before authorization"
        assert "await state.clear()" in body.split(guard, 1)[1][:180], f"{name} should clear stale FSM"
