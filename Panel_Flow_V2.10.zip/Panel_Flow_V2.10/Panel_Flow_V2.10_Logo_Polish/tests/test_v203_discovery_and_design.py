from pathlib import Path
import pytest
from pydantic import ValidationError
from app.db.models import Event, EventNotificationDelivery, UserDiscoveryPreference, UserOrganizationFollow, UserTopicFollow
from app.http_api.website_routes import DISCOVERY_TOPICS, DiscoveryPreferencesInput, EventCreateInput, EventUpdateInput, _recommendation_score

ROOT = Path(__file__).resolve().parents[1]

def test_v203_follow_and_notification_models_are_registered():
    assert UserTopicFollow.__tablename__ == 'user_topic_follows'
    assert UserOrganizationFollow.__tablename__ == 'user_organization_follows'
    assert UserDiscoveryPreference.__tablename__ == 'user_discovery_preferences'
    assert str(UserDiscoveryPreference.__table__.c.notify_followed_topics.server_default.arg).lower() == 'false'
    assert str(UserDiscoveryPreference.__table__.c.notify_followed_organizations.server_default.arg).lower() == 'false'
    assert EventNotificationDelivery.__tablename__ == 'event_notification_deliveries'
    assert any(c.name == 'uq_event_notification_delivery' for c in EventNotificationDelivery.__table__.constraints)

def test_v203_migration_is_additive_and_rollback_is_not_auto_applied():
    folder = ROOT / 'migrations'
    body = (folder / '050_v203_discovery_following_panel_content.sql').read_text(encoding='utf-8')
    assert 'ADD COLUMN IF NOT EXISTS topic_tags' in body
    assert 'CREATE TABLE IF NOT EXISTS user_topic_follows' in body
    assert 'CREATE TABLE IF NOT EXISTS user_organization_follows' in body
    assert 'CREATE TABLE IF NOT EXISTS event_notification_deliveries' in body
    assert 'DROP TABLE' not in body.upper()
    assert (folder / '050_v203_discovery_following_panel_content_rollback.sql.disabled').exists()
    assert not list(folder.glob('050*rollback.sql'))

def test_v203_event_content_validation_and_taxonomy():
    base = dict(volume='Vol. 2', title='A thoughtful panel', day='Friday', date='TBD', start_time='18:00', venue='Studio', city='Mashhad', capacity=12, price_per_person=0)
    event = EventCreateInput(**base, topic_tags=['philosophy', 'philosophy', 'psychology'], agenda_items=['Opening remarks'], discussion_questions=['What makes a good discussion?'])
    assert event.topic_tags == ['philosophy', 'psychology']
    assert event.agenda_items == ['Opening remarks']
    with pytest.raises(ValidationError): EventCreateInput(**base, topic_tags=['made-up-topic'])
    with pytest.raises(ValidationError): EventCreateInput(**base, agenda_items=['x' * 201])
    with pytest.raises(ValidationError): EventCreateInput(**base, discussion_questions=['no'])
    assert {key for key, _, _ in DISCOVERY_TOPICS} == {'philosophy','psychology','technology','science','literature','economics','art','education','politics','business','culture','history'}

def test_v203_partial_preference_patch_does_not_reset_notification_choices():
    assert DiscoveryPreferencesInput(preferred_language=' English ').model_dump(exclude_unset=True) == {'preferred_language': 'English'}
    assert EventUpdateInput(agenda_items=[' Revised agenda ']).agenda_items == ['Revised agenda']
    with pytest.raises(ValidationError): EventUpdateInput(topic_tags=None)

def test_v203_recommendation_scoring_is_explainable_and_weighted():
    event = Event(title='A philosophy event', topic_tags=['philosophy','psychology'], organization_id=8, city_id=3, language='English', event_type='online')
    score, reasons = _recommendation_score(event, topic_keys={'philosophy'}, organization_ids={8}, city_id=3, language='English', event_format='online', attended_organization_ids={8}, saved_topic_keys=set())
    assert score == 19
    assert reasons == ['topic','organization','city','language','format','attendance']

def test_v203_legacy_notification_import_is_compatible():
    from app.services.follow_notifications import send_new_panel_follow_notifications
    from app.services.event_notifications import send_new_panel_follow_notifications as canonical
    assert send_new_panel_follow_notifications is canonical

def test_v203_api_and_global_theme_are_registered():
    from app.api import api
    paths = set(api.openapi()['paths'])
    assert {'/api/v1/discovery/topics','/api/v1/me/follows','/api/v1/me/follows/topics/{topic_key}','/api/v1/me/follows/organizations/{organization_id}','/api/v1/me/discovery/preferences','/api/v1/me/recommendations','/api/v1/events/{event_id}/related'} <= paths
    app_tsx = (ROOT / 'website/src/App.tsx').read_text(encoding='utf-8')
    css = (ROOT / 'website/src/styles.css').read_text(encoding='utf-8')
    assert 'pf_theme' in app_tsx and 'setTheme' in app_tsx
    assert '[data-theme="light"]' in css and '.map-city-topics' in css
    assert 'prefers-reduced-motion:reduce' in css

def test_v203_notifications_cover_website_and_telegram_admin_workflows():
    routes = (ROOT / 'app/http_api/website_routes.py').read_text(encoding='utf-8')
    admin = (ROOT / 'app/bot/handlers/admin.py').read_text(encoding='utf-8')
    service = (ROOT / 'app/services/event_notifications.py').read_text(encoding='utf-8')
    # V2.08 replaced fire-and-forget event notifications with an outbox row
    # committed atomically alongside event publication/changes.
    assert 'enqueue_event_notification' in routes
    assert 'event_type="panel.published"' in routes
    assert 'event_type="panel.changed"' in routes
    assert 'enqueue_notification_outbox' in admin
    assert 'asyncio.create_task(send_new_panel_follow_notifications' not in admin
    assert 'asyncio.create_task(send_registered_event_change_notifications' not in admin
    assert 'periodic_registration_reminders' in service
    assert 'notification_key' in service and 'uq_event_notification_delivery' in (ROOT / 'app/db/models.py').read_text(encoding='utf-8')


def test_v203_saved_panel_state_is_shared_and_date_filter_is_strict():
    app_tsx = (ROOT / 'website/src/App.tsx').read_text(encoding='utf-8')
    assert 'SavedEventsContext.Provider' in app_tsx
    assert "useRequest<ApiPage<EventData>>('/me/saved-events', Boolean(user && token))" in app_tsx
    # V2.05 moved discovery filters to the backend so shared URLs and date
    # filtering use one authoritative query rather than client-side filtering.
    assert "['date_from',dateFrom]" in app_tsx
    public_events = (ROOT / 'app/services/public_events.py').read_text(encoding='utf-8')
    assert 'Event.event_date_iso >= date_from' in public_events
    card_body = app_tsx.split('function EventCard(', 1)[1].split('\nfunction Discover(', 1)[0]
    assert "api<ApiPage<EventData>>('/me/saved-events'" not in card_body
