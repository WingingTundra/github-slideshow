import asyncio
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.bot.content import about_text, user_help_text
from app.db.models import Base, Booking, Event, EventStatus, RegistrationStatus, User, UserRole, WaitlistEntry
from app.services.booking import create_booking
from app.services.waitlist import next_waitlist_candidate

ROOT = Path(__file__).resolve().parents[1]


class FakeAsyncSession:
    def __init__(self, sync_session):
        self.s = sync_session

    async def execute(self, stmt):
        return self.s.execute(stmt)

    async def get(self, entity, ident, **kwargs):
        return self.s.get(entity, ident)

    def add(self, obj):
        self.s.add(obj)

    async def commit(self):
        self.s.commit()

    async def refresh(self, obj):
        self.s.refresh(obj)

    async def rollback(self):
        self.s.rollback()


def _db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine, FakeAsyncSession(Session(engine))


def _user(session, tg_id, name):
    row = User(
        telegram_id=tg_id,
        display_name=name,
        first_name=name.split()[0],
        last_name=" ".join(name.split()[1:]),
        role=UserRole.PARTICIPANT,
    )
    session.add(row)
    session.s.flush()
    return row


def _event(session, *, capacity=5, open_registration=True):
    event = Event(
        volume=31,
        title="Final polish test",
        event_day_label="Thursday",
        event_date_label="15 October 2026",
        start_time_label="16:30",
        end_time_label="-",
        venue="Test venue",
        capacity=capacity,
        price_per_person=Decimal("100000"),
        status=EventStatus.PUBLISHED,
        registration_open=open_registration,
        waitlist_enabled=True,
    )
    session.add(event)
    session.s.flush()
    return event


def test_waitlist_invitation_selects_next_request_that_fits_available_seats():
    engine, session = _db()
    try:
        owner = _user(session, 11001, "Booker One")
        group_waiter = _user(session, 11002, "Sina Ahmadi")
        solo_waiter = _user(session, 11003, "Sara Karimi")
        other_booker = _user(session, 11004, "Other Booker")
        event = _event(session, capacity=5)
        session.add(Booking(
            event_id=event.id,
            booked_by_user_id=owner.id,
            participant_count=3,
            total_amount=Decimal("300000"),
            status=RegistrationStatus.CONFIRMED,
        ))
        session.add(Booking(
            event_id=event.id,
            booked_by_user_id=other_booker.id,
            participant_count=1,
            total_amount=Decimal("100000"),
            status=RegistrationStatus.CONFIRMED,
        ))
        session.add(WaitlistEntry(event_id=event.id, user_id=group_waiter.id, requested_participant_count=3, position=1, status="waiting", created_at=datetime(2026, 10, 1)))
        session.add(WaitlistEntry(event_id=event.id, user_id=solo_waiter.id, requested_participant_count=1, position=2, status="waiting", created_at=datetime(2026, 10, 2)))
        session.s.commit()
        candidate_event, entry, invitee, free_seats = asyncio.run(next_waitlist_candidate(session, event.id))
        assert candidate_event.id == event.id
        assert entry.user_id == solo_waiter.id
        assert invitee.telegram_id == 11003
        assert free_seats == 1
    finally:
        session.s.close()
        engine.dispose()


def test_waitlist_invitation_does_not_override_manual_registration_closure():
    engine, session = _db()
    try:
        user = _user(session, 12001, "Sina Ahmadi")
        event = _event(session, capacity=5, open_registration=False)
        event.registration_closed_reason = "manual"
        session.add(WaitlistEntry(event_id=event.id, user_id=user.id, requested_participant_count=1, position=1, status="waiting"))
        session.s.commit()
        with pytest.raises(ValueError, match="REGISTRATION_CLOSED"):
            asyncio.run(next_waitlist_candidate(session, event.id))
    finally:
        session.s.close()
        engine.dispose()


def test_registering_after_waitlist_invite_removes_request_from_active_queue():
    engine, session = _db()
    try:
        user = _user(session, 13001, "Sina Ahmadi")
        event = _event(session, capacity=5)
        entry = WaitlistEntry(event_id=event.id, user_id=user.id, requested_participant_count=1, position=1, status="invited")
        session.add(entry)
        session.s.commit()
        booking = asyncio.run(create_booking(
            session, user.id, event.id,
            [{"first_name": "Sina", "last_name": "Ahmadi"}],
            contact_phone="09151117889",
        ))
        assert booking.status == RegistrationStatus.PENDING_PAYMENT
        assert session.s.get(WaitlistEntry, entry.id).status == "registered"
    finally:
        session.s.close()
        engine.dispose()


def test_user_facing_copy_is_less_cluttered_and_phone_purpose_is_clear():
    help_text = user_help_text()
    about = about_text()
    user_source = (ROOT / "app" / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    content_source = (ROOT / "app" / "bot" / "content.py").read_text(encoding="utf-8")
    admin_source = (ROOT / "app" / "bot" / "handlers" / "admin.py").read_text(encoding="utf-8")
    assert "@PanelFlowAdmin" not in about
    assert "پشتیبانی انسانی" in help_text
    assert "مثال: سینا ضیائی" in user_source
    assert "مثال: علی رضایی" not in user_source
    assert "شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in content_source
    assert "شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود." in content_source
    assert "accepted_name_phone_prompt()" in user_source
    assert "لازم نیست با شمارهٔ حساب تلگرام شما یکسان باشد." not in user_source
    assert "برای راهنمایی بیشتر" not in user_source
    assert "Telegram ID لازم نیست" not in admin_source
    assert "تفسیر یا اعتبارسنجی نمی‌کند" not in admin_source
    assert "سوالی/فایلی" not in admin_source
    assert "admin:event:waitlist:invite:" in admin_source
    assert "pending_start_payload=payload" in user_source


def test_confirmed_cancellation_alert_contains_no_support_contact_or_duplicate_send():
    source = (ROOT / "app" / "bot" / "handlers" / "user.py").read_text(encoding="utf-8")
    block = source.split('if reason == "CONFIRMED_CANCELLATION_FORBIDDEN":', 1)[1].split("return await c.answer(msg", 1)[0]
    assert "این رزرو تأیید شده است و امکان لغو آن از طریق ربات وجود ندارد." in block
    assert "پشتیبانی" not in block
    assert "c.message.answer" not in block


def test_periodic_expiry_job_is_started_and_stopped_with_bot():
    source = (ROOT / "app" / "bot" / "main.py").read_text(encoding="utf-8")
    assert "asyncio.create_task(periodic_booking_expiry(bot))" in source
    assert "expiry_task.cancel()" in source
    maintenance = (ROOT / "app" / "services" / "reservation_maintenance.py").read_text(encoding="utf-8")
    assert "await session.commit()" in maintenance
    assert "reconcile_event_channel_status" in maintenance


class _ContextSession:
    def __init__(self, events):
        self.events = events

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def commit(self):
        self.events.append("commit")

    async def rollback(self):
        self.events.append("rollback")


class _SessionFactory:
    def __init__(self, events):
        self.events = events

    def __call__(self):
        return _ContextSession(self.events)


def test_expiry_sweep_commits_before_reconciling_affected_panels(monkeypatch):
    import app.services.reservation_maintenance as maintenance

    operations = []

    async def fake_expire(session):
        operations.append("expire")
        return {22, 5}

    async def fake_reconcile(bot, event_id):
        operations.append(("reconcile", event_id))

    monkeypatch.setattr(maintenance, "expire_old_bookings", fake_expire)
    expired = asyncio.run(maintenance.expire_bookings_once(
        bot=object(),
        session_factory=lambda: _SessionFactory(operations)(),
        reconcile_func=fake_reconcile,
    ))
    assert expired == {5, 22}
    assert operations == ["expire", "commit", ("reconcile", 5), ("reconcile", 22)]
