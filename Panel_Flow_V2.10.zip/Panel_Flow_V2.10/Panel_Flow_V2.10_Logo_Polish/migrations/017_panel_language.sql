-- Store the language used by each panel. Historical rows remain NULL until an admin edits them.
ALTER TABLE events ADD COLUMN IF NOT EXISTS language VARCHAR(80) NULL;
