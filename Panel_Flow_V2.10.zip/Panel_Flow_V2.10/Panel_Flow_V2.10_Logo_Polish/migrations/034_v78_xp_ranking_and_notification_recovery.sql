-- V78 reliability polish: retryable admin alert state and safe historical defaults.
-- Existing records are deliberately marked not_attempted (not pending) so a release
-- does not send a burst of notifications for old requests/issues during migration.
ALTER TABLE shop_requests
    ADD COLUMN IF NOT EXISTS admin_notification_status VARCHAR(20) NOT NULL DEFAULT 'not_attempted';
ALTER TABLE shop_requests
    ADD COLUMN IF NOT EXISTS admin_notification_attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE shop_requests
    ADD COLUMN IF NOT EXISTS admin_notified_at TIMESTAMP NULL;
ALTER TABLE shop_requests
    ADD COLUMN IF NOT EXISTS admin_notification_error VARCHAR(255) NULL;
ALTER TABLE shop_requests ALTER COLUMN admin_notification_status SET DEFAULT 'pending';

ALTER TABLE reward_issues
    ADD COLUMN IF NOT EXISTS admin_notification_status VARCHAR(20) NOT NULL DEFAULT 'not_attempted';
ALTER TABLE reward_issues
    ADD COLUMN IF NOT EXISTS admin_notification_attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE reward_issues
    ADD COLUMN IF NOT EXISTS admin_notified_at TIMESTAMP NULL;
ALTER TABLE reward_issues
    ADD COLUMN IF NOT EXISTS admin_notification_error VARCHAR(255) NULL;
ALTER TABLE reward_issues ALTER COLUMN admin_notification_status SET DEFAULT 'pending';

CREATE INDEX IF NOT EXISTS ix_shop_requests_admin_notification
    ON shop_requests (admin_notification_status, created_at);
CREATE INDEX IF NOT EXISTS ix_reward_issues_admin_notification
    ON reward_issues (admin_notification_status, created_at);
