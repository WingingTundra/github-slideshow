-- V90: remove the unused support-ticket feature; public reviews remain unchanged.
DROP TABLE IF EXISTS support_ticket_messages;
DROP TABLE IF EXISTS support_tickets;
