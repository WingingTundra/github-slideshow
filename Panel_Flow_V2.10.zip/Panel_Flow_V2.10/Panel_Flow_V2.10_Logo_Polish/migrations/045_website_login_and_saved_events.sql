CREATE TABLE IF NOT EXISTS website_login_challenges (
    id SERIAL PRIMARY KEY,
    token_hash VARCHAR(64) NOT NULL UNIQUE,
    user_id INTEGER NULL REFERENCES users(id) ON DELETE CASCADE,
    telegram_id BIGINT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    authenticated_at TIMESTAMP NULL,
    consumed_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_website_login_challenges_status_expiry
    ON website_login_challenges (status, expires_at);
CREATE TABLE IF NOT EXISTS website_saved_events (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_website_saved_event_user_event UNIQUE (user_id, event_id)
);
CREATE INDEX IF NOT EXISTS ix_website_saved_events_user_id ON website_saved_events (user_id);
CREATE INDEX IF NOT EXISTS ix_website_saved_events_event_id ON website_saved_events (event_id);
