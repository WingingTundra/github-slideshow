-- V2.01: close V2.00 tenant-integrity and city-discoverability gaps.
-- Additive, idempotent and safe for existing rows. Existing published events are
-- assigned to the first-party Panel Flow brand rather than left ownerless.

ALTER TABLE cities ADD COLUMN IF NOT EXISTS description_fa TEXT;
ALTER TABLE cities ADD COLUMN IF NOT EXISTS description_en TEXT;
ALTER TABLE cities ALTER COLUMN is_active SET DEFAULT FALSE;
-- A city only appears publicly after an administrator explicitly enables it.
-- Mashhad remains the sole initially visible founding city.
UPDATE cities SET is_active = (slug = 'mashhad');
UPDATE cities SET is_founding_city = (slug = 'mashhad');

CREATE TABLE IF NOT EXISTS organization_cities (
  organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  city_id INTEGER NOT NULL REFERENCES cities(id) ON DELETE RESTRICT,
  PRIMARY KEY (organization_id, city_id)
);

CREATE TABLE IF NOT EXISTS organization_verifications (
  id SERIAL PRIMARY KEY,
  organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','suspended')),
  official_name VARCHAR(255),
  registration_number_ciphertext BYTEA,
  national_legal_id_ciphertext BYTEA,
  registered_address TEXT,
  representative_name VARCHAR(255),
  rejection_reason TEXT,
  requested_information TEXT,
  submitted_at TIMESTAMP,
  reviewed_at TIMESTAMP,
  reviewed_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_organization_verifications_status ON organization_verifications(status, submitted_at);
ALTER TABLE host_verifications ADD COLUMN IF NOT EXISTS national_id_fingerprint VARCHAR(64);
CREATE UNIQUE INDEX IF NOT EXISTS uq_host_verification_national_fingerprint
  ON host_verifications(national_id_fingerprint) WHERE national_id_fingerprint IS NOT NULL;

-- One canonical Panel Flow brand is attached to the protected founding org.
INSERT INTO brands(organization_id, slug, name, description, status)
SELECT id, 'panel-flow', 'Panel Flow', 'The first-party founding brand of the Panel Flow national platform.', 'approved'
FROM organizations WHERE is_platform_founder = TRUE
ON CONFLICT (organization_id, slug) DO UPDATE SET status = 'approved';

-- Backfill historical Panel Flow events to the founding organization and brand.
-- This preserves published content while moving ownership into the new model.
UPDATE events e
SET organization_id = o.id, brand_id = b.id
FROM organizations o
JOIN brands b ON b.organization_id = o.id AND b.slug = 'panel-flow'
WHERE o.is_platform_founder = TRUE AND (e.organization_id IS NULL OR e.brand_id IS NULL);

-- Repair pre-existing mismatched tenant attribution before installing the
-- composite foreign key. Prefer a brand owned by the event's organization;
-- if that organization has no brand, preserve the event by attaching it to
-- the protected first-party organization/brand instead of allowing a cross-tenant link.
UPDATE events e
SET organization_id = CASE
      WHEN EXISTS (SELECT 1 FROM brands own_brand WHERE own_brand.organization_id = e.organization_id)
      THEN e.organization_id ELSE founder.id END,
    brand_id = COALESCE(
      (SELECT own_brand.id FROM brands own_brand
       WHERE own_brand.organization_id = e.organization_id
       ORDER BY (own_brand.status = 'approved') DESC, own_brand.id LIMIT 1),
      founder_brand.id)
FROM organizations founder
JOIN brands founder_brand ON founder_brand.organization_id = founder.id AND founder_brand.slug = 'panel-flow'
WHERE founder.is_platform_founder = TRUE
  AND NOT EXISTS (SELECT 1 FROM brands current_brand
                  WHERE current_brand.id = e.brand_id AND current_brand.organization_id = e.organization_id);

-- Drop legacy FKs that depend on BIGINT columns before narrowing them to the SERIAL/INTEGER PK type.
-- PostgreSQL rejects ALTER COLUMN TYPE while a dependent foreign key is attached.
DO $$ DECLARE c RECORD; BEGIN
  FOR c IN
    SELECT DISTINCT con.conname FROM pg_constraint con
    JOIN pg_attribute a ON a.attrelid = con.conrelid AND a.attnum = ANY(con.conkey)
    WHERE con.conrelid = 'brand_host_assignments'::regclass AND con.contype = 'f'
      AND a.attname IN ('brand_id', 'membership_id')
  LOOP EXECUTE format('ALTER TABLE brand_host_assignments DROP CONSTRAINT %I', c.conname); END LOOP;
END $$;
DO $$ DECLARE c RECORD; BEGIN
  FOR c IN
    SELECT DISTINCT con.conname FROM pg_constraint con
    JOIN pg_attribute a ON a.attrelid = con.conrelid AND a.attnum = ANY(con.conkey)
    WHERE con.conrelid = 'events'::regclass AND con.contype = 'f' AND a.attname = 'brand_id'
  LOOP EXECUTE format('ALTER TABLE events DROP CONSTRAINT %I', c.conname); END LOOP;
END $$;

-- Tenant-scoped brand assignments must carry the same organization ID on both sides.
ALTER TABLE brand_host_assignments ALTER COLUMN brand_id TYPE INTEGER USING brand_id::INTEGER;
ALTER TABLE brand_host_assignments ALTER COLUMN membership_id TYPE INTEGER USING membership_id::INTEGER;
ALTER TABLE brand_host_assignments ADD COLUMN IF NOT EXISTS organization_id INTEGER;
UPDATE brand_host_assignments a SET organization_id = b.organization_id
FROM brands b WHERE b.id = a.brand_id AND a.organization_id IS NULL;
DELETE FROM brand_host_assignments a
WHERE NOT EXISTS (SELECT 1 FROM brands b JOIN organization_memberships m
  ON m.id = a.membership_id AND m.organization_id = b.organization_id
  WHERE b.id = a.brand_id);
ALTER TABLE brand_host_assignments ALTER COLUMN organization_id SET NOT NULL;

-- PostgreSQL needs a unique referenced key for tenant-aware composite foreign keys.
CREATE UNIQUE INDEX IF NOT EXISTS uq_brands_organization_id_id ON brands(organization_id, id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_memberships_organization_id_id ON organization_memberships(organization_id, id);
DO $$ BEGIN
  ALTER TABLE brand_host_assignments ADD CONSTRAINT fk_brand_assignment_brand_tenant
    FOREIGN KEY (organization_id, brand_id) REFERENCES brands(organization_id, id) ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE brand_host_assignments ADD CONSTRAINT fk_brand_assignment_membership_tenant
    FOREIGN KEY (organization_id, membership_id) REFERENCES organization_memberships(organization_id, id) ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- A panel's brand and organization must always be the same tenant.
ALTER TABLE events ALTER COLUMN brand_id TYPE INTEGER USING brand_id::INTEGER;
DO $$ BEGIN
  ALTER TABLE events ADD CONSTRAINT fk_events_brand_organization
    FOREIGN KEY (organization_id, brand_id) REFERENCES brands(organization_id, id) ON DELETE RESTRICT;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

INSERT INTO organization_cities(organization_id, city_id)
SELECT o.id, o.founding_city_id FROM organizations o
WHERE o.is_platform_founder = TRUE AND o.founding_city_id IS NOT NULL
ON CONFLICT DO NOTHING;

CREATE INDEX IF NOT EXISTS ix_events_organization_status ON events(organization_id, status, archived);
CREATE INDEX IF NOT EXISTS ix_org_city_city ON organization_cities(city_id, organization_id);

DO $$ BEGIN
  ALTER TABLE events ADD CONSTRAINT ck_events_organization_brand_pair
    CHECK ((organization_id IS NULL AND brand_id IS NULL) OR (organization_id IS NOT NULL AND brand_id IS NOT NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
