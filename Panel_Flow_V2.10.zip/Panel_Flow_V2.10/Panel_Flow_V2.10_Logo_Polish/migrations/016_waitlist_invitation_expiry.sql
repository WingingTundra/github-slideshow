-- V35: bounded waitlist invitations and retry cooldowns; existing queue entries are preserved.
ALTER TABLE waitlist_entries
    ADD COLUMN IF NOT EXISTS invitation_expires_at TIMESTAMP NULL;

ALTER TABLE waitlist_entries
    ADD COLUMN IF NOT EXISTS next_invite_after TIMESTAMP NULL;

-- Backfill legacy invited/inviting rows created before invitation expiry existed.
-- Old invitations immediately become eligible for recovery on the first sweep.
UPDATE waitlist_entries
SET invitation_expires_at = COALESCE(created_at, CURRENT_TIMESTAMP) + INTERVAL '24 hours'
WHERE status IN ('invited', 'inviting')
  AND invitation_expires_at IS NULL;

-- Match SQLAlchemy's default index names from the current model to avoid duplicate indexes.
CREATE INDEX IF NOT EXISTS ix_waitlist_entries_invitation_expires_at
    ON waitlist_entries(invitation_expires_at);

CREATE INDEX IF NOT EXISTS ix_waitlist_entries_next_invite_after
    ON waitlist_entries(next_invite_after);
