-- V68 Phase 2: optional attendance/check-in, per-panel feedback, recoverable admin drafts, topic voting.
ALTER TABLE events ADD COLUMN IF NOT EXISTS attendance_enabled BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE events ADD COLUMN IF NOT EXISTS attendance_checkin_token_hash VARCHAR(64);
ALTER TABLE events ADD COLUMN IF NOT EXISTS attendance_checkin_code_hash VARCHAR(64);
ALTER TABLE events ADD COLUMN IF NOT EXISTS feedback_enabled BOOLEAN NOT NULL DEFAULT FALSE;
CREATE UNIQUE INDEX IF NOT EXISTS uq_events_attendance_checkin_code_hash
    ON events (attendance_checkin_code_hash) WHERE attendance_checkin_code_hash IS NOT NULL;

-- Preserve existing behavior for archived completed panels that were already reviewable.
UPDATE events SET feedback_enabled = TRUE
WHERE archived = TRUE AND LOWER(status::text) = 'completed' AND feedback_enabled = FALSE;

CREATE TABLE IF NOT EXISTS attendance_audits (
    id SERIAL PRIMARY KEY,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    participant_id INTEGER NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
    actor_telegram_id BIGINT NOT NULL,
    old_status VARCHAR(20) NOT NULL,
    new_status VARCHAR(20) NOT NULL,
    source VARCHAR(20) NOT NULL DEFAULT 'admin',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_attendance_audits_event_time ON attendance_audits(event_id, created_at);
CREATE INDEX IF NOT EXISTS ix_attendance_audits_actor_telegram_id ON attendance_audits(actor_telegram_id);

CREATE TABLE IF NOT EXISTS admin_draft_snapshots (
    admin_telegram_id BIGINT PRIMARY KEY,
    state_name VARCHAR(160) NOT NULL,
    data_json TEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS topic_suggestions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    moderator_telegram_id BIGINT,
    moderation_note TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    moderated_at TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_topic_suggestions_status_created ON topic_suggestions(status, created_at);

CREATE TABLE IF NOT EXISTS topic_votes (
    id SERIAL PRIMARY KEY,
    topic_id INTEGER NOT NULL REFERENCES topic_suggestions(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_topic_votes_topic_user UNIQUE(topic_id, user_id)
);
CREATE INDEX IF NOT EXISTS ix_topic_votes_topic_id ON topic_votes(topic_id);
CREATE INDEX IF NOT EXISTS ix_topic_votes_user_id ON topic_votes(user_id);
