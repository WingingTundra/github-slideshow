-- V62 additive schema: keep every existing record and use the legacy chat-id column
-- as a generalized target chat ID for either Telegram channels or groups.
ALTER TABLE channel_announcements ADD COLUMN IF NOT EXISTS destination_type VARCHAR(20) NOT NULL DEFAULT 'channel';
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_bot BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS panel_post_link_sessions (
    token VARCHAR(32) PRIMARY KEY,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    admin_telegram_id BIGINT NOT NULL,
    destination_type VARCHAR(20) NOT NULL DEFAULT 'group',
    pending_chat_id BIGINT NULL,
    pending_message_id BIGINT NULL,
    expires_at TIMESTAMP NOT NULL,
    consumed_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_panel_post_link_sessions_event_id ON panel_post_link_sessions(event_id);
CREATE INDEX IF NOT EXISTS ix_panel_post_link_sessions_admin_telegram_id ON panel_post_link_sessions(admin_telegram_id);
CREATE INDEX IF NOT EXISTS ix_panel_post_link_sessions_expires_at ON panel_post_link_sessions(expires_at);

CREATE TABLE IF NOT EXISTS payment_review_attempts (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    payment_id INTEGER NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
    receipt_fingerprint VARCHAR(64) NOT NULL,
    decision VARCHAR(20) NOT NULL,
    reason_category VARCHAR(40) NULL,
    reason_text TEXT NULL,
    reviewer_telegram_id BIGINT NOT NULL,
    attempt_number INTEGER NOT NULL,
    reviewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_payment_review_receipt_version UNIQUE (payment_id, receipt_fingerprint)
);
CREATE INDEX IF NOT EXISTS ix_payment_review_attempts_booking_time ON payment_review_attempts(booking_id, reviewed_at);

CREATE TABLE IF NOT EXISTS reward_batches (
    id SERIAL PRIMARY KEY,
    batch_key VARCHAR(64) NOT NULL UNIQUE,
    created_by_telegram_id BIGINT NOT NULL,
    config_json TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'preview',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_reward_batches_created_by_telegram_id ON reward_batches(created_by_telegram_id);
CREATE INDEX IF NOT EXISTS ix_reward_batches_status ON reward_batches(status);

CREATE TABLE IF NOT EXISTS reward_batch_recipients (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER NOT NULL REFERENCES reward_batches(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL,
    creation_status VARCHAR(30) NOT NULL DEFAULT 'pending',
    delivery_status VARCHAR(30) NOT NULL DEFAULT 'not_attempted',
    outcome_reason VARCHAR(255) NULL,
    reward_code_id INTEGER NULL REFERENCES discount_codes(id) ON DELETE SET NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_reward_batch_telegram_id UNIQUE (batch_id, telegram_id)
);
CREATE INDEX IF NOT EXISTS ix_reward_batch_recipient_outcome ON reward_batch_recipients(batch_id, creation_status, delivery_status);
