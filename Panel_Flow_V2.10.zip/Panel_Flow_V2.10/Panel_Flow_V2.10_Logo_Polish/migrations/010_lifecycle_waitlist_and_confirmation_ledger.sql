-- V27 lifecycle support, active waitlist uniqueness, and durable lifetime confirmation totals.
-- Keep booking_id intentionally free of a foreign key so the aggregate ledger survives
-- eligible cleanup of individual booking rows.
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS lifetime_confirmed_bookings INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS booking_confirmation_ledger (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    booking_id INTEGER NOT NULL,
    confirmed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_confirmation_ledger_booking UNIQUE (booking_id)
);
CREATE INDEX IF NOT EXISTS ix_confirmation_ledger_user_id
    ON booking_confirmation_ledger(user_id);

-- Seed the ledger from current historical rows and never lower an already persisted total.
INSERT INTO booking_confirmation_ledger(user_id, booking_id, confirmed_at)
SELECT b.booked_by_user_id, b.id, COALESCE(b.confirmed_at, b.created_at, CURRENT_TIMESTAMP)
FROM bookings b
WHERE b.status::text IN ('CONFIRMED', 'confirmed')
ON CONFLICT (booking_id) DO NOTHING;

UPDATE users u
SET lifetime_confirmed_bookings = GREATEST(
    COALESCE(u.lifetime_confirmed_bookings, 0),
    (SELECT COUNT(*)::INTEGER FROM bookings b
     WHERE b.booked_by_user_id = u.id AND b.status::text IN ('CONFIRMED', 'confirmed')),
    (SELECT COUNT(*)::INTEGER FROM booking_confirmation_ledger l WHERE l.user_id = u.id)
);

-- Repair legacy duplicate active waitlist rows before enforcing uniqueness.
WITH ranked AS (
    SELECT id,
           ROW_NUMBER() OVER (PARTITION BY event_id, user_id ORDER BY created_at, id) AS rn
    FROM waitlist_entries
    WHERE status IN ('waiting', 'invited', 'inviting')
)
UPDATE waitlist_entries w
SET status = 'closed'
FROM ranked r
WHERE w.id = r.id AND r.rn > 1;

CREATE UNIQUE INDEX IF NOT EXISTS uq_waitlist_active_event_user
    ON waitlist_entries(event_id, user_id)
    WHERE status IN ('waiting', 'invited', 'inviting');

CREATE INDEX IF NOT EXISTS ix_bookings_user_status_event
    ON bookings(booked_by_user_id, status, event_id);
CREATE INDEX IF NOT EXISTS ix_bookings_event_status
    ON bookings(event_id, status);
CREATE INDEX IF NOT EXISTS ix_questions_event_id
    ON questions(event_id);
