-- Allow payment proof to be submitted as copied/pasted text as well as a file.
ALTER TABLE payments ADD COLUMN IF NOT EXISTS receipt_text TEXT;
