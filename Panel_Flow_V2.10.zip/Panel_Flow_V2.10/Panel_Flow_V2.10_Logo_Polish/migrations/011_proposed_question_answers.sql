-- V28: private replies to proposed questions. Users see replies when they reopen
-- the proposal section; no outbound notification is sent when an answer is saved.
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_text TEXT;
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answered_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS ix_questions_submitter_created
    ON questions(submitted_by, created_at DESC);
