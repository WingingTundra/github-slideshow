-- V32: allow named English volume labels and update discount requests in-place.
ALTER TABLE events ALTER COLUMN volume DROP DEFAULT;
ALTER TABLE events ALTER COLUMN volume TYPE VARCHAR(80) USING volume::text;
ALTER TABLE discount_redemptions ADD COLUMN IF NOT EXISTS request_message_id BIGINT NULL;
