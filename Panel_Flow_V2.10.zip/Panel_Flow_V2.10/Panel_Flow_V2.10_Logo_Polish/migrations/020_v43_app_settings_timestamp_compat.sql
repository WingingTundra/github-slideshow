-- V43 compatibility migration for installations whose app_settings table predates
-- server-side timestamp defaults. Older schemas may require created_at and updated_at
-- while not providing defaults, so every seed/upsert below must supply them explicitly.
CREATE TABLE IF NOT EXISTS app_settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Repair installations where the columns exist but lack defaults or contain NULLs.
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS created_at TIMESTAMP;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP;
UPDATE app_settings SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL;
UPDATE app_settings SET updated_at = CURRENT_TIMESTAMP WHERE updated_at IS NULL;
ALTER TABLE app_settings ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE app_settings ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE app_settings ALTER COLUMN created_at SET NOT NULL;
ALTER TABLE app_settings ALTER COLUMN updated_at SET NOT NULL;

-- Guarantee the community lock row exists, including on databases whose earlier
-- migration history says V40/V41 was applied but whose physical settings rows drifted.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('community_challenge_publish_lock', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;

-- Retain the privacy-safe V41/V43 default exactly once at migration time. Administrators
-- can still enable the public leaderboard manually after the migration has completed.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('community_public_leaderboard_enabled', 'false', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO UPDATE SET value = 'false', updated_at = CURRENT_TIMESTAMP;
