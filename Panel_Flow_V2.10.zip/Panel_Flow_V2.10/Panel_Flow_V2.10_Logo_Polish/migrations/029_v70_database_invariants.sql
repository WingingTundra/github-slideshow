-- V70: enforce capacity and single-booking seat bounds at the database boundary.
-- Existing deployments may contain legacy bookings larger than three. A NOT VALID
-- CHECK would still reject unrelated UPDATEs to such rows, so upgrades use targeted
-- triggers: every insert is checked, and UPDATEs are checked when the protected
-- column itself is changed. Existing history is preserved and unrelated status/payment
-- transitions continue to work. Fresh databases additionally get model CHECK constraints.
-- No active-booking unique index is added because repeat registration is an
-- explicit supported flow; aggregate personal/event seat limits remain transactional.

CREATE OR REPLACE FUNCTION panel_flow_guard_event_capacity()
RETURNS trigger
LANGUAGE plpgsql
AS $capacity_guard$
BEGIN
    IF NEW.capacity IS NULL OR NEW.capacity < 0 THEN
        RAISE EXCEPTION 'events.capacity must be greater than or equal to zero'
            USING ERRCODE = '23514', CONSTRAINT = 'ck_events_capacity_nonnegative';
    END IF;
    RETURN NEW;
END;
$capacity_guard$;

DROP TRIGGER IF EXISTS trg_panel_flow_guard_event_capacity ON events;
CREATE TRIGGER trg_panel_flow_guard_event_capacity
BEFORE INSERT OR UPDATE OF capacity ON events
FOR EACH ROW EXECUTE FUNCTION panel_flow_guard_event_capacity();

CREATE OR REPLACE FUNCTION panel_flow_guard_booking_participant_count()
RETURNS trigger
LANGUAGE plpgsql
AS $participant_guard$
BEGIN
    IF NEW.participant_count IS NULL OR NEW.participant_count NOT BETWEEN 1 AND 3 THEN
        RAISE EXCEPTION 'bookings.participant_count must be between one and three'
            USING ERRCODE = '23514', CONSTRAINT = 'ck_bookings_participant_count_range';
    END IF;
    RETURN NEW;
END;
$participant_guard$;

DROP TRIGGER IF EXISTS trg_panel_flow_guard_booking_participant_count ON bookings;
CREATE TRIGGER trg_panel_flow_guard_booking_participant_count
BEFORE INSERT OR UPDATE OF participant_count ON bookings
FOR EACH ROW EXECUTE FUNCTION panel_flow_guard_booking_participant_count();

