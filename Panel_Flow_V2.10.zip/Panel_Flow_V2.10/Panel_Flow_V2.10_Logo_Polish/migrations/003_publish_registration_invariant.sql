-- Publish invariant documentation / compatibility marker.
-- The application now owns the invariant: publishing always opens registration.
-- Do not reopen intentionally closed published panels here; application callbacks
-- control later close/reopen actions.
SELECT 1;
