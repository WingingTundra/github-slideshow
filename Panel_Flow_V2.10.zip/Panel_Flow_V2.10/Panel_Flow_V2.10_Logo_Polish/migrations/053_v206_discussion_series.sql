-- V2.06: host-managed discussion series.
-- Existing event rows and registrations are unchanged. Deleting a series does not
-- delete its panels; event membership rows cascade only with the series/event.
CREATE TABLE IF NOT EXISTS discussion_series (
    id SERIAL PRIMARY KEY,
    host_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    organization_id INTEGER NULL REFERENCES organizations(id) ON DELETE SET NULL,
    slug VARCHAR(120) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'published',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_discussion_series_slug UNIQUE (slug),
    CONSTRAINT ck_discussion_series_status CHECK (status IN ('published', 'archived'))
);
CREATE INDEX IF NOT EXISTS ix_discussion_series_host_status
    ON discussion_series(host_user_id, status);

CREATE TABLE IF NOT EXISTS discussion_series_events (
    id SERIAL PRIMARY KEY,
    series_id INTEGER NOT NULL REFERENCES discussion_series(id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_discussion_series_event UNIQUE (series_id, event_id),
    CONSTRAINT uq_discussion_series_position UNIQUE (series_id, position),
    CONSTRAINT ck_discussion_series_position_nonnegative CHECK (position >= 0)
);
CREATE INDEX IF NOT EXISTS ix_discussion_series_events_event
    ON discussion_series_events(event_id);
