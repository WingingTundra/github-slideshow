-- V2.07: durable side-effect queue and targeted query indexes.
CREATE TABLE IF NOT EXISTS notification_outbox (
    id BIGSERIAL PRIMARY KEY,
    dedupe_key VARCHAR(180) NOT NULL UNIQUE,
    event_type VARCHAR(80) NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','sent','failed')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    available_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    locked_at TIMESTAMP NULL,
    sent_at TIMESTAMP NULL,
    last_error VARCHAR(240) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_notification_outbox_claim ON notification_outbox(status, available_at, id);
CREATE INDEX IF NOT EXISTS ix_bookings_event_status_created ON bookings(event_id, status, created_at, id);
CREATE INDEX IF NOT EXISTS ix_events_public_discovery ON events(status, archived, is_postponed, event_date_iso, id);
CREATE INDEX IF NOT EXISTS ix_event_notification_retry ON event_notification_deliveries(status, next_attempt_at, id);
