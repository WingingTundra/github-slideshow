-- Panel Flow V40 community features. Idempotent for existing deployments.
CREATE TABLE IF NOT EXISTS community_challenges (
    id SERIAL PRIMARY KEY,
    title VARCHAR(180),
    prompt TEXT,
    challenge_type VARCHAR(20) NOT NULL DEFAULT 'knowledge',
    reference_answer TEXT,
    winner_count INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'open',
    published_sequence INTEGER UNIQUE,
    created_by_telegram_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP,
    results_finalized_at TIMESTAMP,
    cleared_at TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_community_challenges_status ON community_challenges(status);
CREATE INDEX IF NOT EXISTS ix_community_challenges_status_sequence ON community_challenges(status, published_sequence);

CREATE TABLE IF NOT EXISTS challenge_submissions (
    id SERIAL PRIMARY KEY,
    challenge_id INTEGER NOT NULL REFERENCES community_challenges(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL,
    answer_text TEXT,
    judging_status VARCHAR(20) NOT NULL DEFAULT 'unmarked',
    selected_place INTEGER,
    submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_challenge_submission_user UNIQUE(challenge_id, telegram_id)
);
CREATE INDEX IF NOT EXISTS ix_challenge_submissions_challenge ON challenge_submissions(challenge_id, id);

CREATE TABLE IF NOT EXISTS xp_awards (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL,
    points INTEGER NOT NULL,
    award_type VARCHAR(50) NOT NULL,
    award_key VARCHAR(220) NOT NULL UNIQUE,
    event_id INTEGER,
    challenge_id INTEGER,
    source_id VARCHAR(160),
    note VARCHAR(300),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_xp_awards_user_created ON xp_awards(telegram_id, created_at);
CREATE INDEX IF NOT EXISTS ix_xp_awards_type_event_user ON xp_awards(award_type, event_id, telegram_id);

CREATE TABLE IF NOT EXISTS community_profiles (
    telegram_id BIGINT PRIMARY KEY,
    challenge_participations INTEGER NOT NULL DEFAULT 0,
    correct_answers INTEGER NOT NULL DEFAULT 0,
    creative_first INTEGER NOT NULL DEFAULT 0,
    creative_second INTEGER NOT NULL DEFAULT 0,
    creative_third INTEGER NOT NULL DEFAULT 0,
    reviews_submitted INTEGER NOT NULL DEFAULT 0,
    recognized_contributions INTEGER NOT NULL DEFAULT 0,
    current_streak INTEGER NOT NULL DEFAULT 0,
    best_streak INTEGER NOT NULL DEFAULT 0,
    last_finalized_sequence INTEGER NOT NULL DEFAULT 0,
    onboarding_sequence INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS achievement_unlocks (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL,
    achievement_key VARCHAR(80) NOT NULL,
    title VARCHAR(120) NOT NULL,
    unlocked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    celebrated_at TIMESTAMP,
    CONSTRAINT uq_achievement_user_key UNIQUE(telegram_id, achievement_key)
);
CREATE TABLE IF NOT EXISTS wrapped_reports (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL,
    report_year INTEGER NOT NULL,
    report_text TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'generated',
    generated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delivered_at TIMESTAMP,
    last_error VARCHAR(300),
    CONSTRAINT uq_wrapped_user_year UNIQUE(telegram_id, report_year)
);

-- Explicit default setting survives deployment restarts and is easy to inspect.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('community_public_leaderboard_enabled', 'true', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;

-- Persistent lock row serializes published-sequence allocation among multiple workers.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('community_challenge_publish_lock', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;

-- Existing bot accounts were already onboarded before V40; they start at sequence zero
-- so the first post-migration finalized challenge correctly advances/resets streaks.
INSERT INTO community_profiles(telegram_id, onboarding_sequence, last_finalized_sequence)
SELECT u.telegram_id, 0, 0 FROM users u
ON CONFLICT (telegram_id) DO NOTHING;

-- Backfill historic, positively paid and approved confirmed bookings exactly once per user/event.
-- The durable XP ledger does not depend on booking rows remaining forever.
INSERT INTO xp_awards(telegram_id, points, award_type, award_key, event_id, source_id, note, created_at)
SELECT q.telegram_id, 10, 'paid_panel',
       'paid-panel:' || q.telegram_id::text || ':' || q.event_id::text,
       q.event_id, q.booking_id::text, 'V40 historical paid-panel backfill', q.awarded_at
FROM (
    SELECT DISTINCT ON (u.telegram_id, b.event_id)
           u.telegram_id, b.event_id, b.id AS booking_id,
           COALESCE(p.reviewed_at, b.confirmed_at, b.created_at, CURRENT_TIMESTAMP) AS awarded_at
    FROM bookings b
    JOIN users u ON u.id = b.booked_by_user_id
    JOIN payments p ON p.booking_id = b.id
    WHERE b.status::text IN ('CONFIRMED', 'confirmed')
      AND p.status::text IN ('APPROVED', 'approved')
      AND p.amount > 0
    ORDER BY u.telegram_id, b.event_id, b.id
) q
ON CONFLICT (award_key) DO NOTHING;
