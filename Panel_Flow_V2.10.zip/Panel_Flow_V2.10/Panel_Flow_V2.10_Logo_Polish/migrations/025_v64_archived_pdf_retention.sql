-- Additive archive timestamp. Legacy archived rows get a full retention grace period from release time.
ALTER TABLE events ADD COLUMN IF NOT EXISTS archived_at TIMESTAMP NULL;
UPDATE events SET archived_at = CURRENT_TIMESTAMP WHERE archived = TRUE AND archived_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_events_archived_at ON events (archived_at);
