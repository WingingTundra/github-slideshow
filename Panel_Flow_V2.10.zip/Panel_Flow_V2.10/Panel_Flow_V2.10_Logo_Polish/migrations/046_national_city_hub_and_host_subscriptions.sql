CREATE TABLE IF NOT EXISTS cities (
    id SERIAL PRIMARY KEY,
    slug VARCHAR(80) NOT NULL UNIQUE,
    name_fa VARCHAR(120) NOT NULL,
    name_en VARCHAR(120) NOT NULL,
    province_fa VARCHAR(120) NOT NULL,
    province_en VARCHAR(120) NOT NULL,
    latitude NUMERIC(9,6) NOT NULL,
    longitude NUMERIC(9,6) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_cities_latitude_iran_bounds CHECK (latitude BETWEEN 24 AND 40),
    CONSTRAINT ck_cities_longitude_iran_bounds CHECK (longitude BETWEEN 43 AND 64)
);
CREATE INDEX IF NOT EXISTS ix_cities_slug ON cities(slug);

INSERT INTO cities (slug,name_fa,name_en,province_fa,province_en,latitude,longitude) VALUES
('tehran','تهران','Tehran','تهران','Tehran',35.689200,51.389000),
('mashhad','مشهد','Mashhad','خراسان رضوی','Razavi Khorasan',36.297200,59.606700),
('isfahan','اصفهان','Isfahan','اصفهان','Isfahan',32.654600,51.668000),
('shiraz','شیراز','Shiraz','فارس','Fars',29.591800,52.583700),
('tabriz','تبریز','Tabriz','آذربایجان شرقی','East Azerbaijan',38.096200,46.273800),
('karaj','کرج','Karaj','البرز','Alborz',35.840000,50.939100),
('ahvaz','اهواز','Ahvaz','خوزستان','Khuzestan',31.318300,48.670600),
('qom','قم','Qom','قم','Qom',34.639900,50.875900),
('kermanshah','کرمانشاه','Kermanshah','کرمانشاه','Kermanshah',34.314200,47.065000),
('urmia','ارومیه','Urmia','آذربایجان غربی','West Azerbaijan',37.552700,45.076100),
('rasht','رشت','Rasht','گیلان','Gilan',37.280800,49.583200),
('zahedan','زاهدان','Zahedan','سیستان و بلوچستان','Sistan and Baluchestan',29.496300,60.862900),
('kerman','کرمان','Kerman','کرمان','Kerman',30.283900,57.083400),
('yazd','یزد','Yazd','یزد','Yazd',31.897400,54.356900),
('ardabil','اردبیل','Ardabil','اردبیل','Ardabil',38.249800,48.293300),
('bandar-abbas','بندرعباس','Bandar Abbas','هرمزگان','Hormozgan',27.186500,56.280800),
('arak','اراک','Arak','مرکزی','Markazi',34.091700,49.689200),
('hamedan','همدان','Hamedan','همدان','Hamadan',34.799200,48.515000),
('sanandaj','سنندج','Sanandaj','کردستان','Kurdistan',35.314900,46.998800),
('gorgan','گرگان','Gorgan','گلستان','Golestan',36.845600,54.439300),
('sari','ساری','Sari','مازندران','Mazandaran',36.563300,53.060100),
('bushehr','بوشهر','Bushehr','بوشهر','Bushehr',28.923400,50.820300),
('birjand','بیرجند','Birjand','خراسان جنوبی','South Khorasan',32.866300,59.221100),
('bojnurd','بجنورد','Bojnurd','خراسان شمالی','North Khorasan',37.474700,57.329000),
('semnan','سمنان','Semnan','سمنان','Semnan',35.576900,53.395000),
('shahrekord','شهرکرد','Shahrekord','چهارمحال و بختیاری','Chaharmahal and Bakhtiari',32.325600,50.864400),
('yasuj','یاسوج','Yasuj','کهگیلویه و بویراحمد','Kohgiluyeh and Boyer-Ahmad',30.668200,51.587900),
('qazvin','قزوین','Qazvin','قزوین','Qazvin',36.268800,50.004100),
('zanjan','زنجان','Zanjan','زنجان','Zanjan',36.673600,48.478700),
('ilam','ایلام','Ilam','ایلام','Ilam',33.637400,46.422700),
('khorramabad','خرم‌آباد','Khorramabad','لرستان','Lorestan',33.487800,48.355800)
ON CONFLICT (slug) DO UPDATE SET
    name_fa=EXCLUDED.name_fa, name_en=EXCLUDED.name_en,
    province_fa=EXCLUDED.province_fa, province_en=EXCLUDED.province_en,
    latitude=EXCLUDED.latitude, longitude=EXCLUDED.longitude;

ALTER TABLE events ADD COLUMN IF NOT EXISTS city_id INTEGER REFERENCES cities(id) ON DELETE SET NULL;
ALTER TABLE events ADD COLUMN IF NOT EXISTS event_date_iso DATE;
CREATE INDEX IF NOT EXISTS ix_events_city_id ON events(city_id);
CREATE INDEX IF NOT EXISTS ix_events_event_date_iso ON events(event_date_iso);

UPDATE events e SET city_id=c.id
FROM cities c
WHERE e.city_id IS NULL
  AND lower(trim(e.city)) IN (lower(c.name_en), lower(c.name_fa));

CREATE TABLE IF NOT EXISTS host_subscriptions (
    id SERIAL PRIMARY KEY,
    host_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_code VARCHAR(40) NOT NULL DEFAULT 'starter',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    starts_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ends_at TIMESTAMP NULL,
    price_amount BIGINT NOT NULL DEFAULT 0,
    currency VARCHAR(12) NOT NULL DEFAULT 'IRR',
    notes VARCHAR(500) NULL,
    created_by_user_id INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_host_subscriptions_status CHECK (status IN ('active','trial','suspended','cancelled')),
    CONSTRAINT ck_host_subscriptions_plan CHECK (plan_code IN ('starter','growth','pro','custom','legacy')),
    CONSTRAINT ck_host_subscriptions_price_nonnegative CHECK (price_amount >= 0)
);
CREATE INDEX IF NOT EXISTS ix_host_subscriptions_host_user_id ON host_subscriptions(host_user_id);
CREATE INDEX IF NOT EXISTS ix_host_subscriptions_status ON host_subscriptions(status);
CREATE INDEX IF NOT EXISTS ix_host_subscriptions_host_status_end ON host_subscriptions(host_user_id,status,ends_at);

-- Preserve access for existing hosts. New hosts receive an explicit subscription
-- through the super-admin workspace before they can create new panels.
INSERT INTO host_subscriptions(host_user_id,plan_code,status,starts_at,ends_at,price_amount,currency,notes)
SELECT u.id,'legacy','active',CURRENT_TIMESTAMP,NULL,0,'IRR','Existing host access preserved during V99 migration'
FROM users u
WHERE CAST(u.role AS TEXT)='host'
  AND NOT EXISTS (SELECT 1 FROM host_subscriptions hs WHERE hs.host_user_id=u.id);
