-- V80: durable FSM conversations and attendance-based community participation.
-- Existing bookings/participants are left NULL where historical attendee mapping is
-- ambiguous. NULL registrant_attends preserves the documented presumed-present default
-- for legacy confirmed bookings on completed panels; new guest-only bookings store false.
CREATE TABLE IF NOT EXISTS fsm_conversations (
    storage_key VARCHAR(500) PRIMARY KEY,
    state VARCHAR(255) NULL,
    data JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_fsm_conversations_expires_at
    ON fsm_conversations (expires_at);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS registrant_attends BOOLEAN NULL;
ALTER TABLE participants ADD COLUMN IF NOT EXISTS user_telegram_id BIGINT NULL;
CREATE INDEX IF NOT EXISTS ix_participants_user_telegram_id
    ON participants (user_telegram_id);
CREATE INDEX IF NOT EXISTS ix_bookings_event_status_owner
    ON bookings (event_id, status, booked_by_user_id);
