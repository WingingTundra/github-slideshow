-- V41 compatibility migration.
-- V40's create_all() can create this column for new databases, but cannot add it
-- to an existing V39/V40 questions table. Keep this migration idempotent.
ALTER TABLE questions ADD COLUMN IF NOT EXISTS category VARCHAR(100);

-- Ensure the settings store exists even on installations where an older manual
-- schema operation left migration history ahead of the physical schema.
CREATE TABLE IF NOT EXISTS app_settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Public ranking is privacy-sensitive. V40 seeded this setting as true by default,
-- so explicitly turn it off during the V41 upgrade. An admin can enable it again
-- using the persistent Community Management setting.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('community_public_leaderboard_enabled', 'false', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO UPDATE SET value = 'false', updated_at = CURRENT_TIMESTAMP;
