-- V89: durable support conversations and per-panel channel publication history.
CREATE TABLE IF NOT EXISTS support_tickets (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject VARCHAR(160) NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'open',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_support_tickets_status_updated ON support_tickets(status, updated_at);
CREATE INDEX IF NOT EXISTS ix_support_tickets_user_created ON support_tickets(user_id, created_at);

CREATE TABLE IF NOT EXISTS support_ticket_messages (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    sender_telegram_id BIGINT NOT NULL,
    sender_role VARCHAR(16) NOT NULL,
    message_text TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_support_ticket_messages_ticket_created ON support_ticket_messages(ticket_id, created_at);

CREATE TABLE IF NOT EXISTS panel_announcement_posts (
    id SERIAL PRIMARY KEY,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    actor_telegram_id BIGINT NOT NULL,
    chat_id VARCHAR(255) NOT NULL,
    message_text TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'preview',
    telegram_message_id BIGINT NULL,
    last_error VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_panel_announcement_posts_event_created ON panel_announcement_posts(event_id, created_at);
CREATE INDEX IF NOT EXISTS ix_panel_announcement_posts_status_created ON panel_announcement_posts(status, created_at);
