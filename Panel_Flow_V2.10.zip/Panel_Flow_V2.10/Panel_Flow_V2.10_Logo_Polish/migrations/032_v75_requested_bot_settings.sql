-- V75: apply the operator-provided public links/cardholder once to the persistent
-- settings table. Do not touch payment_card_number: its full value is already
-- configured separately and the release only requires masking it in the admin UI.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES
  ('community_group_url', 'https://t.me/+KKqbMvF-vI81Zjg0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('community_channel_url', 'https://t.me/PanelFlowFestival', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('community_instagram_url', 'https://www.instagram.com/panelflowfestival?rpxt=YjhrbzY5b2N3enFl', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('payment_account_name', 'سیدسینا ضیائیی', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO UPDATE
SET value = EXCLUDED.value,
    updated_at = CURRENT_TIMESTAMP;

-- The website slot is intentionally blank until it is configured later. If a
-- website URL has already been set, preserve it.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('community_website_url', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;
