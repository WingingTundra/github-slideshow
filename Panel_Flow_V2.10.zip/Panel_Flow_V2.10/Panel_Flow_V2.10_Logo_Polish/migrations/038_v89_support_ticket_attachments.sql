-- V89: allow users and administrators to attach screenshots/files to support tickets.
ALTER TABLE support_ticket_messages ADD COLUMN IF NOT EXISTS file_id VARCHAR(512) NULL;
ALTER TABLE support_ticket_messages ADD COLUMN IF NOT EXISTS file_type VARCHAR(16) NULL;
ALTER TABLE support_ticket_messages ADD COLUMN IF NOT EXISTS file_name VARCHAR(255) NULL;
