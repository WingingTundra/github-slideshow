-- Durable broadcast delivery and recovery; preserves existing user and panel data.
CREATE TABLE IF NOT EXISTS announcement_broadcasts (
    id SERIAL PRIMARY KEY,
    idempotency_key VARCHAR(64) NOT NULL UNIQUE,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    created_by_telegram_id BIGINT NOT NULL,
    message_text TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'processing',
    total_recipient_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_announcement_broadcasts_event_id ON announcement_broadcasts(event_id);
CREATE INDEX IF NOT EXISTS ix_announcement_broadcasts_created_by_telegram_id ON announcement_broadcasts(created_by_telegram_id);
CREATE INDEX IF NOT EXISTS ix_announcement_broadcasts_status ON announcement_broadcasts(status);

CREATE TABLE IF NOT EXISTS announcement_deliveries (
    id SERIAL PRIMARY KEY,
    broadcast_id INTEGER NOT NULL REFERENCES announcement_broadcasts(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error VARCHAR(255) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_announcement_delivery_recipient UNIQUE (broadcast_id, telegram_id)
);
CREATE INDEX IF NOT EXISTS ix_announcement_delivery_status ON announcement_deliveries(broadcast_id, status);
