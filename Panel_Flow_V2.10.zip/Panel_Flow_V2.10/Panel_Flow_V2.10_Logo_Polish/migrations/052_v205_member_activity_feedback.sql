-- V2.05: personal activity history and structured post-panel feedback.
-- Additive: existing reviews remain valid and new activity history starts empty.
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS discussion_quality INTEGER;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS moderator_rating INTEGER;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS topic_relevance INTEGER;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS would_attend_again BOOLEAN;

CREATE TABLE IF NOT EXISTS website_recent_event_views (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_id BIGINT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    view_count INTEGER NOT NULL DEFAULT 1 CHECK (view_count >= 1),
    last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_website_recent_view_user_event UNIQUE(user_id, event_id)
);
CREATE INDEX IF NOT EXISTS ix_website_recent_views_user_viewed
    ON website_recent_event_views(user_id, last_viewed_at DESC);

ALTER TABLE reviews ADD CONSTRAINT ck_reviews_discussion_quality_range
    CHECK (discussion_quality IS NULL OR discussion_quality BETWEEN 1 AND 5);
ALTER TABLE reviews ADD CONSTRAINT ck_reviews_moderator_rating_range
    CHECK (moderator_rating IS NULL OR moderator_rating BETWEEN 1 AND 5);
ALTER TABLE reviews ADD CONSTRAINT ck_reviews_topic_relevance_range
    CHECK (topic_relevance IS NULL OR topic_relevance BETWEEN 1 AND 5);
