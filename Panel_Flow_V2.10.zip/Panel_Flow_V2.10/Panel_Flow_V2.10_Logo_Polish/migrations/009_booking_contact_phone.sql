-- Store the contact number collected for each booking separately from attendee names
-- and from the booker's editable Telegram account profile.
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS contact_phone VARCHAR(50);

-- Historical versions stored the booking contact on the first participant row.
-- Backfill that value once, without changing any existing account profile or payment data.
UPDATE bookings AS b
SET contact_phone = p.phone_number
FROM participants AS p
WHERE b.contact_phone IS NULL
  AND p.id = (
      SELECT p2.id
      FROM participants AS p2
      WHERE p2.booking_id = b.id
      ORDER BY p2.id
      LIMIT 1
  )
  AND p.phone_number IS NOT NULL;
