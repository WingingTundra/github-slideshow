-- V67 tracks financial follow-up created by event cancellations without rewriting payment history.
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS cancellation_resolution VARCHAR(40) NOT NULL DEFAULT 'not_required';
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS cancellation_resolution_note TEXT;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS cancellation_resolved_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS ix_bookings_cancellation_resolution ON bookings (cancellation_resolution);
UPDATE bookings SET cancellation_resolution = 'not_required' WHERE cancellation_resolution IS NULL OR BTRIM(cancellation_resolution) = '';
