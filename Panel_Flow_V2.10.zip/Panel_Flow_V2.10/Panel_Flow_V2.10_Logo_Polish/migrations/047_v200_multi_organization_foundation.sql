-- V2.00: additive national multi-organization foundation.
-- Existing users/events/bookings remain the canonical member and booking records.
CREATE TABLE IF NOT EXISTS organizations (
 id SERIAL PRIMARY KEY, slug VARCHAR(100) NOT NULL UNIQUE, name VARCHAR(200) NOT NULL,
 description TEXT, logo_url VARCHAR(1000), status VARCHAR(20) NOT NULL DEFAULT 'pending'
   CHECK (status IN ('pending','approved','rejected','suspended')),
 is_platform_founder BOOLEAN NOT NULL DEFAULT FALSE, founding_city_id INTEGER REFERENCES cities(id) ON DELETE SET NULL,
 created_by_user_id INTEGER REFERENCES users(id) ON DELETE RESTRICT,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_single_founder_organization ON organizations(is_platform_founder) WHERE is_platform_founder;
CREATE TABLE IF NOT EXISTS organization_memberships (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role VARCHAR(32) NOT NULL CHECK (role IN ('owner','admin','host','moderator','finance')),
 status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','suspended')),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, approved_at TIMESTAMP,
 UNIQUE(organization_id,user_id)
);
CREATE INDEX IF NOT EXISTS ix_org_members_user_status ON organization_memberships(user_id,status);
CREATE TABLE IF NOT EXISTS brands (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
 slug VARCHAR(100) NOT NULL, name VARCHAR(200) NOT NULL, description TEXT, logo_url VARCHAR(1000),
 status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','suspended')),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(organization_id,slug)
);
CREATE TABLE IF NOT EXISTS brand_host_assignments (
 brand_id BIGINT NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
 membership_id BIGINT NOT NULL REFERENCES organization_memberships(id) ON DELETE CASCADE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(brand_id,membership_id)
);
CREATE TABLE IF NOT EXISTS organization_cities (
 organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
 city_id INTEGER NOT NULL REFERENCES cities(id) ON DELETE RESTRICT,
 PRIMARY KEY(organization_id,city_id)
);
CREATE TABLE IF NOT EXISTS host_verifications (
 id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','suspended')),
 legal_name VARCHAR(255), national_id_ciphertext BYTEA, date_of_birth DATE, verified_mobile VARCHAR(50),
 email VARCHAR(255), residence_city_id INTEGER REFERENCES cities(id) ON DELETE SET NULL,
 biography TEXT, hosting_experience TEXT, rejection_reason TEXT, requested_information TEXT,
 submitted_at TIMESTAMP, reviewed_at TIMESTAMP, reviewed_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_host_verification_status ON host_verifications(status,submitted_at);
CREATE TABLE IF NOT EXISTS subscription_plans (
 id SERIAL PRIMARY KEY, code VARCHAR(40) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL,
 price_amount BIGINT NOT NULL DEFAULT 0 CHECK(price_amount>=0), currency VARCHAR(12) NOT NULL DEFAULT 'IRR',
 duration_days INTEGER NOT NULL CHECK(duration_days BETWEEN 1 AND 3650),
 max_brands INTEGER NOT NULL DEFAULT 1 CHECK(max_brands>0), max_hosts INTEGER NOT NULL DEFAULT 2 CHECK(max_hosts>0),
 features JSONB NOT NULL DEFAULT '{}'::jsonb, is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS organization_subscriptions (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
 plan_id BIGINT REFERENCES subscription_plans(id) ON DELETE SET NULL, status VARCHAR(20) NOT NULL DEFAULT 'trial'
 CHECK(status IN ('trial','active','expired','suspended','cancelled')),
 starts_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ends_at TIMESTAMP,
 price_amount BIGINT NOT NULL DEFAULT 0 CHECK(price_amount>=0), currency VARCHAR(12) NOT NULL DEFAULT 'IRR',
 notes VARCHAR(1000), created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_org_subscriptions_org_status ON organization_subscriptions(organization_id,status,ends_at);
CREATE TABLE IF NOT EXISTS platform_audit_logs (
 id SERIAL PRIMARY KEY, actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 organization_id INTEGER REFERENCES organizations(id) ON DELETE SET NULL,
 action VARCHAR(100) NOT NULL, target_type VARCHAR(60), target_id VARCHAR(100),
 reason TEXT, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_platform_audit_org_created ON platform_audit_logs(organization_id,created_at DESC);
-- Seed the first-party organization only when a user exists to own its creation record.
INSERT INTO organizations(slug,name,description,status,is_platform_founder,founding_city_id,created_by_user_id)
SELECT 'panel-flow','Panel Flow','The founding organization of the national Panel Flow platform.',
 'approved',TRUE,c.id,NULL FROM cities c
WHERE c.slug='mashhad' AND NOT EXISTS (SELECT 1 FROM organizations WHERE is_platform_founder=TRUE);
-- Event ownership and modality are additive; legacy events remain readable.
ALTER TABLE events ADD COLUMN IF NOT EXISTS organization_id INTEGER REFERENCES organizations(id) ON DELETE SET NULL;
ALTER TABLE events ADD COLUMN IF NOT EXISTS brand_id BIGINT REFERENCES brands(id) ON DELETE SET NULL;
ALTER TABLE events ADD COLUMN IF NOT EXISTS event_type VARCHAR(16) NOT NULL DEFAULT 'physical'
 CHECK(event_type IN ('physical','online','hybrid'));
ALTER TABLE events ADD COLUMN IF NOT EXISTS meeting_platform VARCHAR(40);
ALTER TABLE events ADD COLUMN IF NOT EXISTS meeting_link TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS meeting_link_released_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS ix_events_org_brand ON events(organization_id,brand_id);
CREATE INDEX IF NOT EXISTS ix_events_type_status ON events(event_type,status);
-- Protect the founding-city designation at the data layer.
ALTER TABLE cities ADD COLUMN IF NOT EXISTS is_founding_city BOOLEAN NOT NULL DEFAULT FALSE;
UPDATE cities SET is_founding_city=TRUE WHERE slug='mashhad';
