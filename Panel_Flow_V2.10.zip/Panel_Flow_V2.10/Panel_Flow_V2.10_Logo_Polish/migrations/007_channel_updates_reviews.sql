-- Channel status tracking, persistent admin configuration, lifecycle closure reason,
-- and private post-event review metadata.

ALTER TABLE events ADD COLUMN IF NOT EXISTS registration_closed_reason VARCHAR(30);

-- Backfill the closure reason conservatively: a full published panel was closed by
-- the capacity rule; a non-full closed panel is treated as an explicit admin close.
UPDATE events e
SET registration_closed_reason = CASE
    WHEN e.registration_open = FALSE
         AND e.status::text = 'PUBLISHED'
         AND e.archived = FALSE
         AND e.capacity <= (
             SELECT COALESCE(SUM(b.participant_count), 0)
             FROM bookings b
             WHERE b.event_id = e.id
               AND b.status::text IN ('PENDING_PAYMENT', 'PENDING_VERIFICATION', 'CONFIRMED')
         )
        THEN 'capacity'
    WHEN e.registration_open = FALSE AND e.status::text = 'PUBLISHED' THEN 'manual'
    ELSE NULL
END
WHERE e.registration_closed_reason IS NULL;

CREATE TABLE IF NOT EXISTS app_settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('channel_updates_enabled', 'false', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;

INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES ('channel_update_threshold', '3', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;

CREATE TABLE IF NOT EXISTS channel_announcements (
    id SERIAL PRIMARY KEY,
    event_id INTEGER NOT NULL UNIQUE REFERENCES events(id),
    channel_id BIGINT NOT NULL,
    poster_message_id BIGINT,
    status_message_id BIGINT,
    initialized BOOLEAN NOT NULL DEFAULT FALSE,
    last_capacity INTEGER,
    last_remaining INTEGER,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_channel_announcements_event_id ON channel_announcements(event_id);

ALTER TABLE reviews ADD COLUMN IF NOT EXISTS reviewer_telegram_id BIGINT;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS booking_id INTEGER REFERENCES bookings(id);
ALTER TABLE reviews ALTER COLUMN rating DROP NOT NULL;

UPDATE reviews r
SET reviewer_telegram_id = u.telegram_id
FROM users u
WHERE r.user_id = u.id
  AND r.reviewer_telegram_id IS NULL;

-- Legacy review rows without a panel are retained for history but are naturally
-- excluded from the new per-panel uniqueness rule because PostgreSQL allows NULLs.
DO $$
DECLARE
    dup RECORD;
BEGIN
    FOR dup IN
        SELECT MIN(id) AS keep_id, event_id, user_id
        FROM reviews
        WHERE event_id IS NOT NULL
        GROUP BY event_id, user_id
        HAVING COUNT(*) > 1
    LOOP
        DELETE FROM reviews
        WHERE event_id = dup.event_id
          AND user_id = dup.user_id
          AND id <> dup.keep_id;
    END LOOP;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_reviews_event_user
    ON reviews(event_id, user_id)
    WHERE event_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS ix_reviews_event_id_created_at
    ON reviews(event_id, created_at DESC);
