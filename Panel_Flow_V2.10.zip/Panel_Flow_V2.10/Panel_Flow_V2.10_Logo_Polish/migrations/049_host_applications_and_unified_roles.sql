-- V2.02: additive unified host application, review history, notification and public profile support.
-- Existing users, bookings, events, payments, host verifications and Telegram records are untouched.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'userrole') THEN
    ALTER TYPE userrole ADD VALUE IF NOT EXISTS 'ADMIN';
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS host_applications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(40) NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','submitted','under_review','more_information_required','approved','rejected','withdrawn')),
  legal_name VARCHAR(255), national_id_ciphertext BYTEA, national_id_fingerprint VARCHAR(64),
  date_of_birth DATE, verified_mobile VARCHAR(50), email VARCHAR(255),
  residence_city_id INTEGER REFERENCES cities(id) ON DELETE SET NULL,
  english_proficiency VARCHAR(60), english_certification VARCHAR(255),
  relevant_experience TEXT, hosting_background TEXT, motivation TEXT, portfolio_url VARCHAR(1000),
  preferred_city_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
  preferred_topics JSONB NOT NULL DEFAULT '[]'::jsonb,
  preferred_formats JSONB NOT NULL DEFAULT '[]'::jsonb,
  availability TEXT, public_display_name VARCHAR(255), public_bio TEXT,
  public_languages JSONB NOT NULL DEFAULT '[]'::jsonb,
  applicant_response TEXT, requested_information TEXT, rejection_reason TEXT, internal_notes TEXT,
  interview_at TIMESTAMP, interview_location VARCHAR(500), interview_notes TEXT,
  submitted_at TIMESTAMP, reviewed_at TIMESTAMP,
  reviewed_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  withdrawn_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_host_applications_user UNIQUE(user_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_host_applications_national_fingerprint
  ON host_applications(national_id_fingerprint) WHERE national_id_fingerprint IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_host_applications_status_submitted
  ON host_applications(status, submitted_at DESC);
CREATE INDEX IF NOT EXISTS ix_host_applications_city_status
  ON host_applications(residence_city_id, status);

CREATE TABLE IF NOT EXISTS host_application_history (
  id SERIAL PRIMARY KEY,
  application_id INTEGER NOT NULL REFERENCES host_applications(id) ON DELETE CASCADE,
  actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(60) NOT NULL,
  from_status VARCHAR(40), to_status VARCHAR(40), note TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_host_application_history_app_created
  ON host_application_history(application_id, created_at DESC);

CREATE TABLE IF NOT EXISTS host_application_notifications (
  id SERIAL PRIMARY KEY,
  application_id INTEGER NOT NULL REFERENCES host_applications(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(180) NOT NULL, message TEXT NOT NULL,
  read_at TIMESTAMP, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_host_application_notifications_user_created
  ON host_application_notifications(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS host_public_profiles (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  slug VARCHAR(120) NOT NULL UNIQUE,
  display_name VARCHAR(255) NOT NULL,
  bio TEXT,
  languages JSONB NOT NULL DEFAULT '[]'::jsonb,
  topics JSONB NOT NULL DEFAULT '[]'::jsonb,
  city_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_host_public_profiles_user UNIQUE(user_id)
);
CREATE INDEX IF NOT EXISTS ix_host_public_profiles_active ON host_public_profiles(is_active, display_name);
