-- Preserve the discount's business scope on the booking so exports remain accurate
-- even after an inactive discount code is permanently purged.
ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS discount_code_kind_snapshot VARCHAR(20);
