-- v10 publication-flow repair.
--
-- v9 split publication from participant visibility using a legacy boolean
-- (`registration_open`). That allowed a published panel to carry stale FALSE
-- data and become invisible/unbookable. From this migration onward, the
-- canonical state is:
--   PUBLISHED + registration_closed_at IS NULL => registration-ready (subject
--   to event date/deadline at runtime)
-- while registration_open remains a synchronized compatibility field.

ALTER TABLE events ADD COLUMN IF NOT EXISTS published_at TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS registration_closed_at TIMESTAMP;

-- Backfill publication timestamps for historical published rows.
UPDATE events
SET published_at = COALESCE(published_at, updated_at, created_at)
WHERE status::text = 'PUBLISHED';

-- Repair the exact inconsistency complained about in v9: every non-archived
-- published panel is public/open after this migration. An admin can still
-- explicitly close it afterward; that close is stored in registration_closed_at
-- and therefore cannot be confused with publication itself.
UPDATE events
SET registration_open = TRUE,
    registration_closed_at = NULL
WHERE status::text = 'PUBLISHED'
  AND archived_at IS NULL;

-- Drafts are never registration-ready.
UPDATE events
SET registration_open = FALSE,
    registration_closed_at = NULL
WHERE status::text = 'DRAFT';
