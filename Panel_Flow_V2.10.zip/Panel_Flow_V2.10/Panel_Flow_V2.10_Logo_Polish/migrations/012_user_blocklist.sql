-- Persistent user access blocklist. Telegram IDs are stored independently of
-- the users table so admins can pre-emptively block a user who has not started
-- the bot, and blocked status is retained if the user's profile is cleaned up.
CREATE TABLE IF NOT EXISTS blocked_users (
    telegram_id BIGINT PRIMARY KEY,
    blocked_by_telegram_id BIGINT NOT NULL,
    blocked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_blocked_users_blocked_at
    ON blocked_users(blocked_at DESC);

-- Persist message-notice throttling so repeated spam does not cause a reply
-- for every update, including across restarts or multiple app workers.
ALTER TABLE blocked_users
    ADD COLUMN IF NOT EXISTS last_notice_at TIMESTAMP NULL;
