-- V79: durable tracking for host approval/rejection notifications.
-- Existing event and booking history is preserved; old events do not trigger a notification burst.
ALTER TABLE events
    ADD COLUMN IF NOT EXISTS submission_notification_status VARCHAR(20) NOT NULL DEFAULT 'not_attempted';
ALTER TABLE events
    ADD COLUMN IF NOT EXISTS submission_notification_attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE events
    ADD COLUMN IF NOT EXISTS submission_notified_at TIMESTAMP NULL;
ALTER TABLE events
    ADD COLUMN IF NOT EXISTS submission_notification_error VARCHAR(255) NULL;

CREATE INDEX IF NOT EXISTS ix_events_submission_notification
    ON events (submission_notification_status, updated_at);
