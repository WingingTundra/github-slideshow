-- V2.03: discovery taxonomy, private follow relationships, panel content and notification preferences.
-- Additive only; existing events and accounts retain their current behaviour.
ALTER TABLE events ADD COLUMN IF NOT EXISTS topic_tags JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE events ADD COLUMN IF NOT EXISTS agenda_items JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE events ADD COLUMN IF NOT EXISTS discussion_questions JSONB NOT NULL DEFAULT '[]'::jsonb;

CREATE TABLE IF NOT EXISTS user_topic_follows (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    topic_key VARCHAR(50) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_user_topic_follow UNIQUE (user_id, topic_key)
);
CREATE INDEX IF NOT EXISTS ix_user_topic_follows_user_id ON user_topic_follows(user_id);
CREATE INDEX IF NOT EXISTS ix_user_topic_follows_topic_key ON user_topic_follows(topic_key);

CREATE TABLE IF NOT EXISTS user_organization_follows (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    organization_id BIGINT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_user_organization_follow UNIQUE (user_id, organization_id)
);
CREATE INDEX IF NOT EXISTS ix_user_organization_follows_user_id ON user_organization_follows(user_id);
CREATE INDEX IF NOT EXISTS ix_user_organization_follows_organization_id ON user_organization_follows(organization_id);

CREATE TABLE IF NOT EXISTS user_discovery_preferences (
    user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    preferred_city_id BIGINT REFERENCES cities(id) ON DELETE SET NULL,
    preferred_language VARCHAR(80),
    preferred_format VARCHAR(16),
    notify_followed_topics BOOLEAN NOT NULL DEFAULT FALSE,
    notify_followed_organizations BOOLEAN NOT NULL DEFAULT FALSE,
    notify_panel_changes BOOLEAN NOT NULL DEFAULT TRUE,
    notify_registration_reminders BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_user_discovery_preferred_format CHECK (preferred_format IS NULL OR preferred_format IN ('physical','online','hybrid'))
);

CREATE TABLE IF NOT EXISTS event_notification_deliveries (
    id BIGSERIAL PRIMARY KEY,
    event_id BIGINT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    notification_key VARCHAR(100) NOT NULL,
    notification_type VARCHAR(40) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    reason VARCHAR(80),
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error VARCHAR(120),
    sent_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_event_notification_delivery UNIQUE (event_id, user_id, notification_key),
    CONSTRAINT ck_event_notification_delivery_status CHECK (status IN ('pending','sent','failed','skipped'))
);
CREATE INDEX IF NOT EXISTS ix_event_notification_deliveries_event_id ON event_notification_deliveries(event_id);
CREATE INDEX IF NOT EXISTS ix_event_notification_deliveries_user_id ON event_notification_deliveries(user_id);
CREATE INDEX IF NOT EXISTS ix_event_notification_deliveries_type_status ON event_notification_deliveries(notification_type, status);
