-- One-time onboarding referrals and explanatory text for personal rewards.
ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by_user_id INTEGER NULL REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_prompt_completed BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS ix_users_referred_by_user_id ON users(referred_by_user_id);

-- Existing completed profiles predate the referral prompt and should not be
-- interrupted by an onboarding step introduced in a later release.
UPDATE users
SET referral_prompt_completed = TRUE
WHERE first_name IS NOT NULL
  AND BTRIM(first_name) <> ''
  AND last_name IS NOT NULL
  AND BTRIM(last_name) <> ''
  AND phone_number IS NOT NULL
  AND BTRIM(phone_number) <> '';

ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS reason TEXT NULL;
