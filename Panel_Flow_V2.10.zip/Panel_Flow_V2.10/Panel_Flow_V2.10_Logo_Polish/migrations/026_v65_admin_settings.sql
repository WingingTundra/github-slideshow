-- V65 persistent admin-editable links and payment configuration.
-- Existing non-empty rows take precedence; blank/missing rows are seeded from env at startup.
INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES
  ('community_group_url', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('community_channel_url', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('community_instagram_url', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('payment_card_number', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('payment_account_name', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;
