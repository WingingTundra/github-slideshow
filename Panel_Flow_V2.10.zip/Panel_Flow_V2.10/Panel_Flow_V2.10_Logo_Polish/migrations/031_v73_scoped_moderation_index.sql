-- V73: index the scope-aware restriction checks without changing any existing records.
CREATE INDEX IF NOT EXISTS ix_user_moderation_scope_active_expiry
    ON user_moderation_records(target_telegram_id, action, scope, active, expires_at);
