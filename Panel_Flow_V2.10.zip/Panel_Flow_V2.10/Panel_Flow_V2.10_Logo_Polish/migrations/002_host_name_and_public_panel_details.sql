-- Allow free-text panel hosts; Telegram identity is no longer required for a host.
ALTER TABLE events ADD COLUMN IF NOT EXISTS host_name VARCHAR(255);
ALTER TABLE events ALTER COLUMN host_id DROP NOT NULL;

-- Preserve the host name for events created under the old Telegram-ID workflow.
UPDATE events e
SET host_name = COALESCE(
    NULLIF(TRIM(e.host_name), ''),
    NULLIF(TRIM(u.display_name), ''),
    NULLIF(TRIM(CONCAT_WS(' ', u.first_name, u.last_name)), ''),
    NULLIF(TRIM(u.telegram_username), ''),
    'میزبان'
)
FROM users u
WHERE e.host_id = u.id
  AND (e.host_name IS NULL OR TRIM(e.host_name) = '');

-- Repair panels created under the old publish flow: future published panels should be bookable.
UPDATE events
SET registration_open = TRUE
WHERE status::text = 'PUBLISHED'
  AND archived_at IS NULL
  AND registration_open = FALSE;
