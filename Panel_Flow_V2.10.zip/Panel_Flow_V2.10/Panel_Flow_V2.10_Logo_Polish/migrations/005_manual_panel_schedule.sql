-- Replace all event scheduling timestamps with admin-entered display text.
-- The application no longer parses, compares, or uses calendar/time values for
-- registration. Publication/closure is controlled manually, with only one
-- automatic rule: reaching capacity closes registration.

ALTER TABLE events ADD COLUMN IF NOT EXISTS event_day_label VARCHAR(100);
ALTER TABLE events ADD COLUMN IF NOT EXISTS event_date_label VARCHAR(255);
ALTER TABLE events ADD COLUMN IF NOT EXISTS archived BOOLEAN NOT NULL DEFAULT FALSE;

-- The previous v10 schema used these timestamp columns. Add them temporarily
-- on older databases only if they are missing so this migration can be safely
-- applied to both v9/v10 databases and fresh installations.
ALTER TABLE events ADD COLUMN IF NOT EXISTS event_date TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS end_time TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS registration_deadline TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS published_at TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS registration_closed_at TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS archived_at TIMESTAMP;

-- One-time preservation of existing human-readable schedule information.
UPDATE events
SET event_day_label = COALESCE(NULLIF(TRIM(event_day_label), ''), to_char(event_date, 'FMDay')),
    event_date_label = COALESCE(NULLIF(TRIM(event_date_label), ''), to_char(event_date, 'YYYY-MM-DD'))
WHERE event_date IS NOT NULL;

UPDATE events
SET event_day_label = COALESCE(NULLIF(TRIM(event_day_label), ''), '—'),
    event_date_label = COALESCE(NULLIF(TRIM(event_date_label), ''), '—');

UPDATE events
SET archived = TRUE
WHERE archived_at IS NOT NULL;

-- Repair already-full published panels once during the upgrade.
UPDATE events e
SET registration_open = FALSE
WHERE status::text = 'PUBLISHED'
  AND archived = FALSE
  AND capacity <= (
      SELECT COALESCE(SUM(b.participant_count), 0)
      FROM bookings b
      WHERE b.event_id = e.id
        AND b.status::text IN ('PENDING_PAYMENT', 'PENDING_VERIFICATION', 'CONFIRMED')
  );

-- The timestamp columns below are no longer part of the panel model. Their
-- removal ensures no later application path can accidentally use them.
ALTER TABLE events DROP COLUMN IF EXISTS event_date;
ALTER TABLE events DROP COLUMN IF EXISTS end_time;
ALTER TABLE events DROP COLUMN IF EXISTS registration_deadline;
ALTER TABLE events DROP COLUMN IF EXISTS published_at;
ALTER TABLE events DROP COLUMN IF EXISTS registration_closed_at;
ALTER TABLE events DROP COLUMN IF EXISTS archived_at;

ALTER TABLE events ALTER COLUMN event_day_label SET NOT NULL;
ALTER TABLE events ALTER COLUMN event_date_label SET NOT NULL;
