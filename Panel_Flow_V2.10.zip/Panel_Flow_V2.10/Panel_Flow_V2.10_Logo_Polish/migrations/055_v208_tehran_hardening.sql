-- V2.08: Tehran timezone contract, stronger QR credentials, review eligibility,
-- responsive media variants and query/pagination indexes.
ALTER TABLE events ADD COLUMN IF NOT EXISTS attendance_checkin_session_id VARCHAR(32) NULL;
ALTER TABLE events ADD COLUMN IF NOT EXISTS attendance_checkin_token_expires_at TIMESTAMP NULL;
ALTER TABLE events ADD COLUMN IF NOT EXISTS attendance_checkin_code_expires_at TIMESTAMP NULL;
ALTER TABLE events ADD COLUMN IF NOT EXISTS feedback_attendance_required BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE events ADD COLUMN IF NOT EXISTS cover_image_thumb_url VARCHAR(1000) NULL;

-- Completed panels that already existed before the attendance identity rollout
-- are grandfathered. Their historical attendance rows often cannot be tied
-- reliably to a Telegram account-holder; all events completed after rollout
-- retain the default attendance gate.
UPDATE events SET feedback_attendance_required = FALSE
WHERE LOWER(status::text) = 'completed';

-- Existing shared attendance credentials get a short migration grace window;
-- newly generated tokens/codes always receive explicit expiry timestamps.
UPDATE events SET attendance_checkin_token_expires_at = CURRENT_TIMESTAMP + INTERVAL '12 hours'
WHERE attendance_checkin_token_hash IS NOT NULL AND attendance_checkin_token_expires_at IS NULL;
UPDATE events SET attendance_checkin_code_expires_at = CURRENT_TIMESTAMP + INTERVAL '12 hours'
WHERE attendance_checkin_code_hash IS NOT NULL AND attendance_checkin_code_expires_at IS NULL;

CREATE INDEX IF NOT EXISTS ix_participants_booking_attendance_user
    ON participants(booking_id, attendance_status, user_telegram_id);
CREATE INDEX IF NOT EXISTS ix_bookings_user_status_created
    ON bookings(booked_by_user_id, status, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS ix_waitlist_event_status_position
    ON waitlist_entries(event_id, status, position, created_at, id);
CREATE INDEX IF NOT EXISTS ix_discussion_series_public_updated
    ON discussion_series(status, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS ix_reviews_event_user
    ON reviews(event_id, user_id);
CREATE INDEX IF NOT EXISTS ix_attendance_audits_event_cursor
    ON attendance_audits(event_id, created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_events_public_newest_cursor
    ON events(status, archived, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS ix_events_public_city_newest
    ON events(city_id, status, archived, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS ix_bookings_event_status_created
    ON bookings(event_id, status, created_at DESC, id DESC) INCLUDE (participant_count);
