-- Safe, idempotent upgrade from the previous Panel Flow prototype.
-- Never drops tables or user/event/booking/payment rows.
ALTER TABLE events ADD COLUMN IF NOT EXISTS registration_deadline TIMESTAMP;
ALTER TABLE events ADD COLUMN IF NOT EXISTS questions_file_name VARCHAR(255);
ALTER TABLE events ADD COLUMN IF NOT EXISTS archived_at TIMESTAMP;
ALTER TABLE participants ADD COLUMN IF NOT EXISTS first_name VARCHAR(100);
ALTER TABLE participants ADD COLUMN IF NOT EXISTS last_name VARCHAR(100);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS receipt_file_name VARCHAR(255);
ALTER TABLE participants ALTER COLUMN phone_number DROP NOT NULL;

DO $$
DECLARE
    c RECORD;
BEGIN
    FOR c IN
        SELECT conname
        FROM pg_constraint
        WHERE conrelid = 'bookings'::regclass
          AND contype = 'u'
          AND pg_get_constraintdef(oid) LIKE '%(event_id, booked_by_user_id)%'
    LOOP
        EXECUTE format('ALTER TABLE bookings DROP CONSTRAINT IF EXISTS %I', c.conname);
    END LOOP;
END $$;
