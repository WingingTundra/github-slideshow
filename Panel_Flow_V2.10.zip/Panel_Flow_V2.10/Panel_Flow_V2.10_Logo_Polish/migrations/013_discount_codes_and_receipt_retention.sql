-- Discount codes/rewards are explicitly scoped to existing draft/published panels.
-- Pending restricted-code requests persist checkout details but never reserve seats.
CREATE TABLE IF NOT EXISTS discount_codes (
    id SERIAL PRIMARY KEY,
    code VARCHAR(64) UNIQUE NULL,
    label VARCHAR(255) NOT NULL DEFAULT '',
    kind VARCHAR(20) NOT NULL CHECK (kind IN ('public', 'restricted', 'personal')),
    discount_type VARCHAR(20) NOT NULL CHECK (discount_type IN ('percent', 'fixed')),
    discount_value NUMERIC(12,0) NOT NULL CHECK (discount_value > 0),
    requires_approval BOOLEAN NOT NULL DEFAULT FALSE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    max_redemptions INTEGER NULL CHECK (max_redemptions IS NULL OR max_redemptions > 0),
    usage_policy VARCHAR(30) NOT NULL DEFAULT 'once_total' CHECK (usage_policy IN ('once_total', 'once_per_panel')),
    recipient_telegram_id BIGINT NULL,
    accepted_at TIMESTAMP NULL,
    created_by_telegram_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    disabled_at TIMESTAMP NULL,
    disabled_reason VARCHAR(255) NULL
);
CREATE INDEX IF NOT EXISTS ix_discount_codes_kind ON discount_codes(kind);
CREATE INDEX IF NOT EXISTS ix_discount_codes_active ON discount_codes(active);
CREATE INDEX IF NOT EXISTS ix_discount_codes_recipient_telegram_id ON discount_codes(recipient_telegram_id);

CREATE TABLE IF NOT EXISTS discount_code_events (
    id SERIAL PRIMARY KEY,
    discount_code_id INTEGER NOT NULL REFERENCES discount_codes(id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_discount_code_event UNIQUE (discount_code_id, event_id)
);
CREATE INDEX IF NOT EXISTS ix_discount_code_events_event ON discount_code_events(event_id);

CREATE TABLE IF NOT EXISTS discount_redemptions (
    id SERIAL PRIMARY KEY,
    discount_code_id INTEGER NULL REFERENCES discount_codes(id) ON DELETE SET NULL,
    code_snapshot VARCHAR(64) NOT NULL DEFAULT '',
    event_id INTEGER NULL REFERENCES events(id) ON DELETE SET NULL,
    event_label_snapshot VARCHAR(400) NOT NULL DEFAULT '',
    user_telegram_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    draft_json TEXT NULL,
    contact_phone VARCHAR(50) NULL,
    participant_count INTEGER NOT NULL DEFAULT 1,
    allow_duplicate BOOLEAN NOT NULL DEFAULT FALSE,
    booking_id INTEGER NULL REFERENCES bookings(id) ON DELETE SET NULL,
    original_total NUMERIC(12,0) NULL,
    discount_amount NUMERIC(12,0) NULL,
    final_total NUMERIC(12,0) NULL,
    reviewed_by_telegram_id BIGINT NULL,
    reviewed_at TIMESTAMP NULL,
    redeemed_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_discount_redemption_status CHECK (status IN ('pending', 'approved', 'rejected', 'withdrawn', 'redeemed', 'cancelled'))
);
CREATE INDEX IF NOT EXISTS ix_discount_redemptions_code_user_status ON discount_redemptions(discount_code_id, user_telegram_id, status);
CREATE INDEX IF NOT EXISTS ix_discount_redemptions_status_created ON discount_redemptions(status, created_at);
CREATE INDEX IF NOT EXISTS ix_discount_redemptions_user_telegram_id ON discount_redemptions(user_telegram_id);
CREATE INDEX IF NOT EXISTS ix_discount_redemptions_booking_id ON discount_redemptions(booking_id);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS discount_code_id INTEGER NULL REFERENCES discount_codes(id) ON DELETE SET NULL;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS discount_code_snapshot VARCHAR(64) NULL;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS discount_amount NUMERIC(12,0) NOT NULL DEFAULT 0;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS receipt_uploaded_at TIMESTAMP NULL;
UPDATE payments SET receipt_uploaded_at = created_at WHERE receipt_uploaded_at IS NULL AND (receipt_file IS NOT NULL OR receipt_text IS NOT NULL OR receipt_file_name IS NOT NULL);
CREATE INDEX IF NOT EXISTS ix_payments_receipt_uploaded_at ON payments(receipt_uploaded_at);
