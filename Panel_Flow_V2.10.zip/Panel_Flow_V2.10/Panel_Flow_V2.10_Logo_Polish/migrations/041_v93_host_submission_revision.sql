-- V93: bind host approval/rejection confirmations to an exact submission generation.
ALTER TABLE events
    ADD COLUMN IF NOT EXISTS submission_revision INTEGER NOT NULL DEFAULT 0;

-- Existing pending submissions become generation 1. Legacy confirmation buttons
-- do not contain a generation and are rejected by the V93 handlers.
UPDATE events
SET submission_revision = 1
WHERE submission_status = 'submitted' AND submission_revision = 0;
