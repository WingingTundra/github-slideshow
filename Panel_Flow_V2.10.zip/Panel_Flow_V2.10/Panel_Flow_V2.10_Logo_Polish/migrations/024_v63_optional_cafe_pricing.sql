-- V63: optional no-mandatory-cafe-order price and booking-level price snapshots.
-- Additive: existing events/bookings are not rewritten and historic snapshots stay NULL.
ALTER TABLE events
    ADD COLUMN IF NOT EXISTS price_without_cafe_order NUMERIC(12, 0);

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS pricing_option VARCHAR(32);

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS base_price_snapshot NUMERIC(12, 0);

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS alternative_price_snapshot NUMERIC(12, 0);
