-- V77 additive Community & About archive, Quick Fun, XP shop and free draw records.
-- SQLAlchemy create_all may create these tables immediately before this migration;
-- IF NOT EXISTS makes this migration safe in both fresh and upgraded installs.
CREATE TABLE IF NOT EXISTS archived_panel_content (
  id SERIAL PRIMARY KEY,
  event_id INTEGER NOT NULL UNIQUE REFERENCES events(id) ON DELETE CASCADE,
  recap TEXT NULL,
  highlights TEXT NULL,
  tags_json TEXT NOT NULL DEFAULT '[]',
  links_json TEXT NOT NULL DEFAULT '[]',
  updated_by_telegram_id BIGINT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_archived_panel_content_event_id ON archived_panel_content(event_id);

CREATE TABLE IF NOT EXISTS quick_fun_activities (
  id SERIAL PRIMARY KEY,
  kind VARCHAR(20) NOT NULL,
  title VARCHAR(180) NOT NULL,
  prompt TEXT NOT NULL,
  options_json TEXT NOT NULL DEFAULT '[]',
  correct_option INTEGER NULL,
  answer_text TEXT NULL,
  explanation TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  created_by_telegram_id BIGINT NOT NULL,
  updated_by_telegram_id BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_quick_fun_status_kind ON quick_fun_activities(status, kind, created_at);
CREATE INDEX IF NOT EXISTS ix_quick_fun_activities_status ON quick_fun_activities(status);

CREATE TABLE IF NOT EXISTS quick_fun_responses (
  id SERIAL PRIMARY KEY,
  activity_id INTEGER NOT NULL REFERENCES quick_fun_activities(id) ON DELETE CASCADE,
  telegram_id BIGINT NOT NULL,
  response_value VARCHAR(100) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_quick_fun_response_user UNIQUE(activity_id, telegram_id)
);
CREATE INDEX IF NOT EXISTS ix_quick_fun_response_activity_value ON quick_fun_responses(activity_id, response_value);

CREATE TABLE IF NOT EXISTS shop_requests (
  id SERIAL PRIMARY KEY,
  telegram_id BIGINT NOT NULL,
  discount_percent INTEGER NOT NULL CHECK (discount_percent IN (15,25,50,100)),
  xp_cost INTEGER NOT NULL CHECK (xp_cost > 0),
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  reviewed_by_telegram_id BIGINT NULL,
  reviewed_at TIMESTAMP NULL,
  denial_reason TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_shop_requests_status_created ON shop_requests(status, created_at);
CREATE INDEX IF NOT EXISTS ix_shop_requests_user_status ON shop_requests(telegram_id, status);
CREATE INDEX IF NOT EXISTS ix_shop_requests_telegram_id ON shop_requests(telegram_id);

CREATE TABLE IF NOT EXISTS lucky_draw_campaigns (
  id SERIAL PRIMARY KEY,
  label VARCHAR(180) NOT NULL,
  probabilities_json TEXT NOT NULL,
  config_version INTEGER NOT NULL DEFAULT 1,
  active BOOLEAN NOT NULL DEFAULT FALSE,
  created_by_telegram_id BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  activated_at TIMESTAMP NULL,
  deactivated_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_lucky_draw_campaign_active ON lucky_draw_campaigns(active, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_lucky_draw_single_active ON lucky_draw_campaigns(active) WHERE active IS TRUE;

CREATE TABLE IF NOT EXISTS lucky_draw_claims (
  id SERIAL PRIMARY KEY,
  campaign_id INTEGER NOT NULL REFERENCES lucky_draw_campaigns(id) ON DELETE RESTRICT,
  telegram_id BIGINT NOT NULL,
  discount_percent INTEGER NOT NULL CHECK (discount_percent IN (15,25,50,100)),
  odds_snapshot_json TEXT NOT NULL,
  config_version INTEGER NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_lucky_draw_claim_user_campaign UNIQUE(campaign_id, telegram_id)
);
CREATE INDEX IF NOT EXISTS ix_lucky_draw_claim_campaign_created ON lucky_draw_claims(campaign_id, created_at);

CREATE TABLE IF NOT EXISTS reward_issues (
  id SERIAL PRIMARY KEY,
  source_type VARCHAR(20) NOT NULL,
  source_id INTEGER NOT NULL,
  telegram_id BIGINT NOT NULL,
  discount_percent INTEGER NOT NULL CHECK (discount_percent IN (15,25,50,100)),
  status VARCHAR(30) NOT NULL DEFAULT 'awaiting_code',
  discount_code_id INTEGER NULL REFERENCES discount_codes(id) ON DELETE SET NULL,
  assigned_by_telegram_id BIGINT NULL,
  assigned_at TIMESTAMP NULL,
  delivery_state VARCHAR(30) NOT NULL DEFAULT 'not_attempted',
  delivered_at TIMESTAMP NULL,
  delivery_error VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_reward_issue_source UNIQUE(source_type, source_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_reward_issue_discount_code_id ON reward_issues(discount_code_id) WHERE discount_code_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_reward_issues_status_created ON reward_issues(status, created_at);
CREATE INDEX IF NOT EXISTS ix_reward_issues_user_created ON reward_issues(telegram_id, created_at);
CREATE INDEX IF NOT EXISTS ix_reward_issues_telegram_id ON reward_issues(telegram_id);

-- A single persisted row serializes concurrent campaign activation/deactivation.
INSERT INTO app_settings (key, value, created_at, updated_at) VALUES ('v77_lucky_draw_activation_lock', '1', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
