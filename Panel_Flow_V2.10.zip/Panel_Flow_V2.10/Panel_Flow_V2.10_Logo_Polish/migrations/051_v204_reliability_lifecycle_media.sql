-- V2.04: notification retry scheduling, event lifecycle/content media, idempotent
-- website booking retries, and private negative recommendation feedback.
-- All changes are additive and existing rows retain their current meaning.

ALTER TABLE events ADD COLUMN IF NOT EXISTS cover_image_url VARCHAR(1000);
ALTER TABLE events ADD COLUMN IF NOT EXISTS is_postponed BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE events ADD COLUMN IF NOT EXISTS postponement_note VARCHAR(2000);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS client_request_id VARCHAR(64);
CREATE UNIQUE INDEX IF NOT EXISTS uq_bookings_web_client_request
    ON bookings(event_id, booked_by_user_id, client_request_id)
    WHERE client_request_id IS NOT NULL;

ALTER TABLE event_notification_deliveries ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMP;
ALTER TABLE event_notification_deliveries ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
CREATE INDEX IF NOT EXISTS ix_event_notification_deliveries_next_attempt
    ON event_notification_deliveries(status, next_attempt_at);

CREATE TABLE IF NOT EXISTS recommendation_feedback (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_id BIGINT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    feedback VARCHAR(24) NOT NULL DEFAULT 'not_interested',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_recommendation_feedback_user_event UNIQUE (user_id, event_id),
    CONSTRAINT ck_recommendation_feedback_kind CHECK (feedback IN ('not_interested'))
);
CREATE INDEX IF NOT EXISTS ix_recommendation_feedback_user_feedback
    ON recommendation_feedback(user_id, feedback);

-- User-controlled quiet hours and optional promotional notification digests.
ALTER TABLE user_discovery_preferences ADD COLUMN IF NOT EXISTS digest_frequency VARCHAR(12) NOT NULL DEFAULT 'immediate';
ALTER TABLE user_discovery_preferences ADD COLUMN IF NOT EXISTS quiet_hours_start VARCHAR(5);
ALTER TABLE user_discovery_preferences ADD COLUMN IF NOT EXISTS quiet_hours_end VARCHAR(5);
ALTER TABLE event_notification_deliveries ADD COLUMN IF NOT EXISTS digest_message TEXT;
ALTER TABLE event_notification_deliveries ADD COLUMN IF NOT EXISTS digest_due_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS ix_event_notification_deliveries_digest_due ON event_notification_deliveries(digest_due_at);
