-- V72: additive schema for Telegram-native admin console, host review and unified manual announcements.
-- Existing rows and historical lifecycle states are preserved.
ALTER TABLE events ADD COLUMN IF NOT EXISTS submission_status VARCHAR(24) NOT NULL DEFAULT 'draft';
ALTER TABLE events ADD COLUMN IF NOT EXISTS submission_feedback TEXT NULL;
UPDATE events SET submission_status = CASE WHEN status::text = 'PUBLISHED' OR status::text = 'published' THEN 'approved' ELSE 'draft' END
WHERE submission_status = 'draft' AND (status::text = 'PUBLISHED' OR status::text = 'published');
CREATE INDEX IF NOT EXISTS ix_events_submission_status ON events(submission_status);

CREATE TABLE IF NOT EXISTS admin_user_notes (
    id SERIAL PRIMARY KEY,
    target_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    actor_telegram_id BIGINT NOT NULL,
    note_text TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_admin_user_notes_target_created ON admin_user_notes(target_user_id, created_at);

CREATE TABLE IF NOT EXISTS user_moderation_records (
    id SERIAL PRIMARY KEY,
    target_telegram_id BIGINT NOT NULL,
    actor_telegram_id BIGINT NOT NULL,
    action VARCHAR(32) NOT NULL,
    scope VARCHAR(40) NOT NULL DEFAULT 'account',
    reason TEXT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_user_moderation_target_created ON user_moderation_records(target_telegram_id, created_at);
CREATE INDEX IF NOT EXISTS ix_user_moderation_active_expiry ON user_moderation_records(target_telegram_id, active, expires_at);

CREATE TABLE IF NOT EXISTS admin_private_messages (
    id SERIAL PRIMARY KEY,
    actor_telegram_id BIGINT NOT NULL,
    target_telegram_id BIGINT NOT NULL,
    message_text TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    error_summary VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_admin_private_messages_target_created ON admin_private_messages(target_telegram_id, created_at);

CREATE TABLE IF NOT EXISTS admin_announcements (
    id SERIAL PRIMARY KEY,
    idempotency_key VARCHAR(64) NOT NULL CONSTRAINT uq_admin_announcements_idempotency UNIQUE,
    announcement_type VARCHAR(32) NOT NULL,
    purpose VARCHAR(40) NOT NULL,
    event_id INTEGER NULL REFERENCES events(id) ON DELETE SET NULL,
    actor_telegram_id BIGINT NOT NULL,
    audience_policy VARCHAR(60) NOT NULL,
    message_text TEXT NOT NULL,
    message_meta_json TEXT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'preview',
    recipient_count INTEGER NOT NULL DEFAULT 0,
    sent_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    skipped_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS ix_admin_announcements_created ON admin_announcements(created_at);
CREATE INDEX IF NOT EXISTS ix_admin_announcements_event_created ON admin_announcements(event_id, created_at);
CREATE INDEX IF NOT EXISTS ix_admin_announcements_status ON admin_announcements(status);
CREATE INDEX IF NOT EXISTS ix_admin_announcements_actor_telegram_id ON admin_announcements(actor_telegram_id);

CREATE TABLE IF NOT EXISTS admin_announcement_deliveries (
    id SERIAL PRIMARY KEY,
    announcement_id INTEGER NOT NULL REFERENCES admin_announcements(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error VARCHAR(255) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_admin_announcement_recipient UNIQUE (announcement_id, telegram_id)
);
CREATE INDEX IF NOT EXISTS ix_admin_announcement_delivery_status ON admin_announcement_deliveries(announcement_id, status);
