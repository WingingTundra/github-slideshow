-- Restore manual, presentation-only panel start/end times.
-- These values are never parsed, compared, or used for scheduling logic.

ALTER TABLE events ADD COLUMN IF NOT EXISTS start_time_label VARCHAR(5) NOT NULL DEFAULT '—';
ALTER TABLE events ADD COLUMN IF NOT EXISTS end_time_label VARCHAR(5) NOT NULL DEFAULT '—';

UPDATE events
SET start_time_label = COALESCE(NULLIF(TRIM(start_time_label), ''), '—'),
    end_time_label = COALESCE(NULLIF(TRIM(end_time_label), ''), '—');
