-- V94 follow-up: durable delivery tracking for published challenge results.
-- Results and XP remain committed even if Telegram notification delivery fails.
CREATE TABLE IF NOT EXISTS challenge_result_notifications (
    id SERIAL PRIMARY KEY,
    challenge_id INTEGER NOT NULL REFERENCES community_challenges(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL,
    challenge_title_snapshot VARCHAR(180) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    sent_at TIMESTAMP NULL,
    last_error VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_challenge_result_notification_recipient UNIQUE (challenge_id, telegram_id),
    CONSTRAINT ck_challenge_result_notification_status CHECK (status IN ('pending', 'sending', 'sent', 'failed')),
    CONSTRAINT ck_challenge_result_notification_attempts CHECK (attempts >= 0)
);
CREATE INDEX IF NOT EXISTS ix_challenge_result_notifications_status_created
    ON challenge_result_notifications(status, created_at);
