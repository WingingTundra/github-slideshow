-- V89: one final wizard confirmation can create at most one event, even on rapid/double callbacks.
ALTER TABLE events ADD COLUMN IF NOT EXISTS creation_token VARCHAR(32) NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_events_creation_token
    ON events (creation_token)
    WHERE creation_token IS NOT NULL;
