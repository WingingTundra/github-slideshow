-- V94: configurable XP Shop catalogue, referral verification and independent community controls.
-- Additive: historical requests, reward issues, XP ledger rows and referral attribution remain intact.

CREATE TABLE IF NOT EXISTS xp_shop_offers (
    id SERIAL PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    description TEXT NULL,
    discount_percent INTEGER NOT NULL CHECK (discount_percent BETWEEN 1 AND 100),
    xp_cost INTEGER NOT NULL CHECK (xp_cost BETWEEN 1 AND 1000000),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    usage_limit INTEGER NULL CHECK (usage_limit IS NULL OR usage_limit > 0),
    expires_at TIMESTAMP NULL,
    sort_order INTEGER NOT NULL DEFAULT 100,
    created_by_telegram_id BIGINT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_xp_shop_offers_active_sort ON xp_shop_offers(active, sort_order, id);

ALTER TABLE shop_requests DROP CONSTRAINT IF EXISTS ck_shop_request_percent;
ALTER TABLE shop_requests ADD CONSTRAINT ck_shop_request_percent CHECK (discount_percent BETWEEN 1 AND 100);
ALTER TABLE shop_requests ADD COLUMN IF NOT EXISTS offer_id INTEGER NULL REFERENCES xp_shop_offers(id) ON DELETE SET NULL;
ALTER TABLE shop_requests ADD COLUMN IF NOT EXISTS offer_title_snapshot VARCHAR(120) NULL;
ALTER TABLE shop_requests ADD COLUMN IF NOT EXISTS offer_description_snapshot TEXT NULL;
CREATE INDEX IF NOT EXISTS ix_shop_requests_offer_id ON shop_requests(offer_id);

ALTER TABLE reward_issues DROP CONSTRAINT IF EXISTS ck_reward_issue_percent;
ALTER TABLE reward_issues ADD CONSTRAINT ck_reward_issue_percent CHECK (discount_percent BETWEEN 1 AND 100);

CREATE TABLE IF NOT EXISTS referral_verifications (
    invitee_user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    verified_by_telegram_id BIGINT NULL,
    verified_at TIMESTAMP NULL,
    note VARCHAR(500) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_referral_verifications_verified_at ON referral_verifications(verified, verified_at);

ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_notification_status VARCHAR(20) NOT NULL DEFAULT 'not_attempted';
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_notification_attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_notified_at TIMESTAMP NULL;
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_notification_error VARCHAR(255) NULL;

INSERT INTO app_settings(key, value, created_at, updated_at)
VALUES
    ('xp_shop_enabled', 'false', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('community_xp_earning_enabled', 'true', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('question_suggestions_enabled', 'true', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('topic_suggestions_enabled', 'true', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (key) DO NOTHING;

-- Preserve V93's four offers as editable catalogue entries. Carry forward any legacy
-- per-tier prices configured through v77_my_shop_costs when that JSON setting exists.
INSERT INTO xp_shop_offers(title, description, discount_percent, xp_cost, active, sort_order)
VALUES
    ('تخفیف ۱۵ درصدی', 'تخفیف شخصی برای ثبت‌نام در پنل‌های واجد شرایط', 15, 20, TRUE, 15),
    ('تخفیف ۲۵ درصدی', 'تخفیف شخصی برای ثبت‌نام در پنل‌های واجد شرایط', 25, 40, TRUE, 25),
    ('تخفیف ۵۰ درصدی', 'تخفیف شخصی برای ثبت‌نام در پنل‌های واجد شرایط', 50, 80, TRUE, 50),
    ('تخفیف ۱۰۰ درصدی', 'پاداش ویژه؛ دامنهٔ استفاده باید هنگام تخصیص بررسی شود', 100, 160, FALSE, 100)
ON CONFLICT DO NOTHING;

UPDATE xp_shop_offers AS offer
SET xp_cost = COALESCE(
    NULLIF((setting.value::jsonb ->> offer.discount_percent::text), '')::integer,
    offer.xp_cost
),
updated_at = CURRENT_TIMESTAMP
FROM app_settings AS setting
WHERE setting.key = 'v77_my_shop_costs'
  AND setting.value LIKE '{%';
