-- V95 reliability hardening. Safe additive changes; preserves all historical records.
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_notification_claimed_at TIMESTAMP NULL;
ALTER TABLE questions ADD COLUMN IF NOT EXISTS answer_revision INTEGER NOT NULL DEFAULT 1;
ALTER TABLE xp_shop_offers ADD COLUMN IF NOT EXISTS revision INTEGER NOT NULL DEFAULT 1;
-- Newly created offers are inactive by default in application code. Preserve existing offer states.
CREATE INDEX IF NOT EXISTS ix_questions_answer_notification_recovery
    ON questions (answer_notification_status, answer_notification_claimed_at);
