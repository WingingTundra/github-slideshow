# Google AI Studio — Panel Flow review brief

You are reviewing the existing Panel Flow codebase. Treat this repository as a production-oriented application that must be improved incrementally, not replaced with a simplified demonstration.

## Review objectives

1. Inspect the complete existing architecture before proposing changes: Telegram/Aiogram handlers and FSM, FastAPI routes, service layer, SQLAlchemy models, ordered migrations, React/TypeScript website, API client, build/deployment configuration, and tests.
2. Identify concrete bugs, security gaps, reliability risks, performance bottlenecks, accessibility issues, and maintainability problems. For each finding, cite the exact file and relevant function/component or route, explain impact, and distinguish confirmed defects from hypotheses.
3. Prioritize improvements that benefit older Android devices and users on slow or unstable internet: smaller initial bundles, route/component lazy loading, efficient API calls, bounded caching, cancellation of stale requests, image sizing/variants, pagination, and low-cost rendering.
4. Review the user experience as a Persian-first, RTL-capable bilingual platform. Preserve correct Persian typography, bidirectional text handling, mobile layouts, accessible controls, and all currently implemented features.
5. Review backend authorization and business rules at both service and database levels. Pay particular attention to booking/payment transitions, seat capacity, waitlists, attendance, review eligibility, host/admin permissions, notification idempotency, and lifecycle transitions.
6. Audit operational safety: migrations, backup/restore, deployment ordering, health checks, logging, secret handling, and recovery from partial failures.

## Non-negotiable constraints

- **Do not rewrite or replace the project architecture.** Preserve working features, routes, user data, API contracts, Telegram callback/FSM behavior, and deployment compatibility.
- **Do not remove features to make the project smaller or easier to explain.** Any proposed removal must identify the affected feature and justify it explicitly; default to retaining it.
- The canonical website/platform timezone is **`Asia/Tehran`** everywhere: website calendar, event-related date boundaries, notifications, quiet hours, scheduled jobs, API presentation, and exports. PostgreSQL operational timestamps currently follow a naive-UTC storage convention; do not change this convention casually.
- Host-entered panel date/day/time labels are presentation text. Do not infer a scheduled instant from them, auto-close registration from those labels, or reject a panel simply because its display date is in the past.
- Keep applied migrations immutable. Propose additive migrations for schema changes and explain data backfill, rollback compatibility, and deployment order.
- Keep business rules in backend services and database constraints. UI-only restrictions are insufficient.
- Preserve Persian-first content and the existing English/bilingual behavior.
- Do not claim tests, builds, database migrations, load tests, or device checks passed unless you can actually run them and report the exact result.

## Expected review format

Start with a concise architecture map. Then provide findings grouped by severity (critical, high, medium, low), each with file/function references, impact, and a practical backward-compatible fix. Separate confirmed issues from recommendations. Include a test plan and identify checks that require a real PostgreSQL instance, Telegram bot, Docker runtime, or physical devices.

Do not edit files or generate a replacement implementation during the initial review. First return findings and a prioritized implementation plan. Wait for a separate explicit request before changing source code.

## Current visual brand reference

The V2.10 website uses the refined Panel Flow navy/red wave logo. Review `BRAND_GUIDE.md` and `website/public/brand/` before proposing visual changes. The wave has smoothed Bézier contours, the circular emblem uses mathematically concentric arcs, and icon exports share consistent geometry and uniform scaling. Preserve these proportions, light/dark variants, responsive header behavior, Persian RTL layout, and the `Asia/Tehran` platform timezone contract.
