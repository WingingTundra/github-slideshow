#!/usr/bin/env python3
"""Authenticated, streaming encryption for Panel Flow backup archives.

V1 uses AES-256-GCM with a random salt/nonce and PBKDF2-HMAC-SHA256. Decryption
returns exit code 3 only when the input is not this format, allowing the restore
script to fall back to historical OpenSSL AES-CBC archives. A V1 authentication
failure is fatal and must never fall back to the legacy decryptor.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import secrets
import sys
import tempfile
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

MAGIC = b"PFLOWAE1"  # 8 bytes; format/version marker
SALT_BYTES = 16
NONCE_BYTES = 12
TAG_BYTES = 16
HEADER_BYTES = len(MAGIC) + SALT_BYTES + NONCE_BYTES
PBKDF2_ITERATIONS = 600_000
CHUNK_BYTES = 1024 * 1024
NOT_THIS_FORMAT = 3


class BackupCryptoError(Exception):
    """A malformed or unauthenticated backup archive."""


def _key(salt: bytes) -> bytes:
    password = os.environ.get("BACKUP_ENCRYPTION_KEY", "")
    if not password:
        raise BackupCryptoError("BACKUP_ENCRYPTION_KEY is required")
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS, dklen=32
    )


def _atomic_output(destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".backup-crypto-", dir=str(destination.parent))
    os.fchmod(fd, 0o600)
    return fd, Path(temp_name)


def encrypt(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise BackupCryptoError("input backup archive does not exist")
    salt = secrets.token_bytes(SALT_BYTES)
    nonce = secrets.token_bytes(NONCE_BYTES)
    header = MAGIC + salt + nonce
    encryptor = Cipher(algorithms.AES(_key(salt)), modes.GCM(nonce)).encryptor()
    encryptor.authenticate_additional_data(header)
    fd, temporary = _atomic_output(destination)
    try:
        with source.open("rb") as incoming, os.fdopen(fd, "wb") as outgoing:
            outgoing.write(header)
            while chunk := incoming.read(CHUNK_BYTES):
                encrypted = encryptor.update(chunk)
                if encrypted:
                    outgoing.write(encrypted)
            final = encryptor.finalize()
            if final:
                outgoing.write(final)
            outgoing.write(encryptor.tag)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        os.replace(temporary, destination)
        os.chmod(destination, 0o600)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def decrypt(source: Path, destination: Path) -> int:
    if not source.is_file():
        raise BackupCryptoError("encrypted backup archive does not exist")
    with source.open("rb") as incoming:
        prefix = incoming.read(len(MAGIC))
        if prefix != MAGIC:
            return NOT_THIS_FORMAT
        incoming.seek(0, os.SEEK_END)
        total_bytes = incoming.tell()
        if total_bytes < HEADER_BYTES + TAG_BYTES:
            raise BackupCryptoError("authenticated backup archive is truncated")
        incoming.seek(0)
        header = incoming.read(HEADER_BYTES)
        salt = header[len(MAGIC):len(MAGIC) + SALT_BYTES]
        nonce = header[len(MAGIC) + SALT_BYTES:HEADER_BYTES]
        incoming.seek(total_bytes - TAG_BYTES)
        tag = incoming.read(TAG_BYTES)
        body_bytes = total_bytes - HEADER_BYTES - TAG_BYTES
        incoming.seek(HEADER_BYTES)

        decryptor = Cipher(algorithms.AES(_key(salt)), modes.GCM(nonce, tag)).decryptor()
        decryptor.authenticate_additional_data(header)
        fd, temporary = _atomic_output(destination)
        remaining = body_bytes
        try:
            # Do not publish plaintext until finalize() verifies the GCM tag.
            with os.fdopen(fd, "wb") as outgoing:
                while remaining:
                    chunk = incoming.read(min(CHUNK_BYTES, remaining))
                    if not chunk:
                        raise BackupCryptoError("authenticated backup archive is truncated")
                    remaining -= len(chunk)
                    plaintext = decryptor.update(chunk)
                    if plaintext:
                        outgoing.write(plaintext)
                final = decryptor.finalize()
                if final:
                    outgoing.write(final)
                outgoing.flush()
                os.fsync(outgoing.fileno())
            os.replace(temporary, destination)
            os.chmod(destination, 0o600)
        except InvalidTag as exc:
            temporary.unlink(missing_ok=True)
            raise BackupCryptoError("backup authentication failed: wrong key or tampered archive") from exc
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("encrypt", "decrypt"))
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.operation == "encrypt":
            encrypt(args.source, args.destination)
            return 0
        return decrypt(args.source, args.destination)
    except (BackupCryptoError, OSError, ValueError) as exc:
        print(f"backup_crypto_failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
