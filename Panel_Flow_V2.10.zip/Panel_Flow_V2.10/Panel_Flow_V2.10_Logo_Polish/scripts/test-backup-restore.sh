#!/bin/sh
# End-to-end backup/recovery proof using two disposable PostgreSQL 17 containers.
# This never connects to a configured or production Compose database.
set -eu
command -v docker >/dev/null 2>&1 || { echo 'Docker is required for this integration test.' >&2; exit 2; }
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SUFFIX="$$-$(date +%s)"
NETWORK="pf-v70-restore-net-$SUFFIX"
SOURCE="pf-v70-restore-source-$SUFFIX"
TARGET="pf-v70-restore-target-$SUFFIX"
IMAGE="pf-v70-restore-test:$SUFFIX"
TMP=$(mktemp -d)
chmod 777 "$TMP"
mkdir -p "$TMP/backups" "$TMP/uploads"
chmod 777 "$TMP/backups" "$TMP/uploads"
DB_USER=panel_restore_test
DB_PASSWORD=$(openssl rand -hex 24)
KEY=$(openssl rand -hex 32)
cleanup() {
  docker rm -f "$SOURCE" "$TARGET" >/dev/null 2>&1 || true
  docker network rm "$NETWORK" >/dev/null 2>&1 || true
  docker image rm "$IMAGE" >/dev/null 2>&1 || true
  rm -rf "$TMP"
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

docker build -t "$IMAGE" "$ROOT"
docker network create "$NETWORK" >/dev/null
docker run -d --name "$SOURCE" --network "$NETWORK" \
  -e POSTGRES_DB=panel_flow_source -e POSTGRES_USER="$DB_USER" -e POSTGRES_PASSWORD="$DB_PASSWORD" postgres:17 >/dev/null
docker run -d --name "$TARGET" --network "$NETWORK" \
  -e POSTGRES_DB=panel_flow_restore_test -e POSTGRES_USER="$DB_USER" -e POSTGRES_PASSWORD="$DB_PASSWORD" postgres:17 >/dev/null
wait_ready() {
  container=$1; database=$2
  i=0
  while [ "$i" -lt 60 ]; do
    if docker exec "$container" pg_isready -U "$DB_USER" -d "$database" >/dev/null 2>&1; then return 0; fi
    i=$((i + 1)); sleep 1
  done
  echo "PostgreSQL container $container did not become ready" >&2
  return 1
}
wait_ready "$SOURCE" panel_flow_source
wait_ready "$TARGET" panel_flow_restore_test

docker exec -e PGPASSWORD="$DB_PASSWORD" "$SOURCE" psql -v ON_ERROR_STOP=1 -U "$DB_USER" -d panel_flow_source \
  -c 'CREATE TABLE public.v70_restore_probe (id integer PRIMARY KEY, payload text NOT NULL); INSERT INTO public.v70_restore_probe VALUES (1, '\''phase1_restore_ok'\'');' >/dev/null
printf 'Panel Flow V70 upload restore fixture\n' > "$TMP/uploads/v70-restore-probe.txt"

# Run the exact packaged backup script against the isolated source DB.
docker run --rm --user "$(id -u):$(id -g)" --network "$NETWORK" \
  -e PGHOST="$SOURCE" -e POSTGRES_DB=panel_flow_source -e POSTGRES_USER="$DB_USER" -e POSTGRES_PASSWORD="$DB_PASSWORD" \
  -e BACKUP_ENCRYPTION_KEY="$KEY" -e BACKUP_RETENTION_DAILY=7 -e BACKUP_RETENTION_WEEKLY=4 -e BACKUP_RETENTION_MONTHLY=12 \
  -e BACKUP_DIR=/backups -e UPLOAD_DIR=/data/uploads \
  -v "$TMP/backups:/backups" -v "$TMP/uploads:/data/uploads:ro" "$IMAGE" /app/scripts/backup.sh
ARCHIVE=$(find "$TMP/backups" -maxdepth 1 -type f -name 'panel-flow-*.tar.gz.enc' | sort | tail -n 1)
[ -n "$ARCHIVE" ] && [ -f "$ARCHIVE" ] || { echo 'No encrypted backup was produced' >&2; exit 1; }

# Run the actual decrypt/checksum/pg_restore/upload-restore path against a second isolated empty DB.
docker run --rm --user "$(id -u):$(id -g)" --network "$NETWORK" \
  -e CONFIRM_DISPOSABLE_RESTORE=YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET \
  -e BACKUP_FILE="/test/backups/$(basename "$ARCHIVE")" -e BACKUP_ENCRYPTION_KEY="$KEY" \
  -e RESTORE_DIR=/test/restore-work -e RESTORE_UPLOAD_DIR=/test/restored-uploads \
  -e RESTORE_DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@$TARGET:5432/panel_flow_restore_test" \
  -v "$TMP:/test" "$IMAGE" /app/scripts/restore-backup.sh

RESTORED=$(docker exec -e PGPASSWORD="$DB_PASSWORD" "$TARGET" psql -v ON_ERROR_STOP=1 -U "$DB_USER" -d panel_flow_restore_test -X -A -t -c 'SELECT payload FROM public.v70_restore_probe WHERE id=1')
[ "$RESTORED" = "phase1_restore_ok" ] || { echo "Database payload mismatch after restore: $RESTORED" >&2; exit 1; }
cmp "$TMP/uploads/v70-restore-probe.txt" "$TMP/restored-uploads/v70-restore-probe.txt"
echo 'PASS: encrypted backup created; manifest/checksums verified after extraction; database restored into a separate disposable PostgreSQL 17 database; upload fixture restored byte-for-byte.'
