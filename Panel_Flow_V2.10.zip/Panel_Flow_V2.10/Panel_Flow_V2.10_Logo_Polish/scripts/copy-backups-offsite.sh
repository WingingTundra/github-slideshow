#!/bin/sh
# Copy already-encrypted Panel Flow backups to a separately configured rclone remote.
# Intended for a host-side scheduled job or a dedicated one-shot utility container.
# Never deletes local/remote archives and never uploads plaintext work files.
set -eu
umask 077

: "${BACKUP_REMOTE_TARGET:?Set BACKUP_REMOTE_TARGET to an rclone destination, e.g. remote:panel-flow-backups}"
BACKUP_DIR="${BACKUP_DIR:-/backups}"
RCLONE_BIN="${RCLONE_BIN:-rclone}"
command -v "$RCLONE_BIN" >/dev/null 2>&1 || {
  echo 'offsite_copy_failed: rclone is not installed or not in PATH' >&2
  exit 2
}
[ -d "$BACKUP_DIR" ] || {
  echo "offsite_copy_failed: backup directory does not exist: $BACKUP_DIR" >&2
  exit 1
}

found=0
copied=0
failed=0
for archive in "$BACKUP_DIR"/panel-flow-*.tar.gz.enc; do
  [ -f "$archive" ] || continue
  found=1
  remote_path="${BACKUP_REMOTE_TARGET%/}/$(basename "$archive")"
  local_size=$(wc -c < "$archive" | tr -d '[:space:]')
  if ! "$RCLONE_BIN" copyto "$archive" "$remote_path"; then
    echo "offsite_copy_failed: remote upload failed for $(basename "$archive")" >&2
    failed=1
    continue
  fi
  if ! remote_json=$("$RCLONE_BIN" lsjson --stat "$remote_path" 2>/dev/null); then
    echo "offsite_copy_failed: could not verify remote archive $(basename "$archive")" >&2
    failed=1
    continue
  fi
  if ! remote_size=$(printf '%s' "$remote_json" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(int(d.get("Size", -1)))' 2>/dev/null); then
    echo "offsite_copy_failed: invalid remote metadata for $(basename "$archive")" >&2
    failed=1
    continue
  fi
  if [ "$local_size" != "$remote_size" ]; then
    echo "offsite_copy_failed: size mismatch for $(basename "$archive") (local=$local_size remote=$remote_size)" >&2
    failed=1
    continue
  fi
  copied=$((copied + 1))
  printf 'offsite_copy_verified file=%s bytes=%s\n' "$(basename "$archive")" "$local_size"
done

if [ "$found" -eq 0 ]; then
  echo "offsite_copy_failed: no encrypted archives found in $BACKUP_DIR" >&2
  exit 1
fi
if [ "$failed" -ne 0 ]; then
  echo "offsite_copy_partial_failure copied=$copied" >&2
  exit 1
fi
printf 'offsite_copy_success verified=%s target=%s\n' "$copied" "$BACKUP_REMOTE_TARGET"
