#!/bin/sh
set -eu
umask 077
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "${CONFIRM_DISPOSABLE_RESTORE:-}" != "YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET" ]; then
  echo 'Refusing restore: set CONFIRM_DISPOSABLE_RESTORE=YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET and use a disposable target.' >&2; exit 2
fi
: "${BACKUP_FILE:?Set BACKUP_FILE to an encrypted backup file}"
: "${BACKUP_ENCRYPTION_KEY:?Set backup decryption key from secret storage}"
: "${RESTORE_DIR:?Set RESTORE_DIR to a new temporary directory}"
: "${RESTORE_DATABASE_URL:?Set RESTORE_DATABASE_URL to an EMPTY DISPOSABLE PostgreSQL database}"
: "${RESTORE_UPLOAD_DIR:?Set RESTORE_UPLOAD_DIR to a new directory for recovered uploads}"
[ -f "$BACKUP_FILE" ] || { echo 'BACKUP_FILE does not exist or is not a regular file' >&2; exit 2; }
# Normalize paths before checking containment. If the temporary work directory is
# equal to/inside the upload target (or vice versa), successful cleanup could erase
# restored files. realpath also resolves existing symlinked parent directories.
RESTORE_DIR=$(python3 -c 'import os,sys; print(os.path.realpath(sys.argv[1]))' "$RESTORE_DIR")
RESTORE_UPLOAD_DIR=$(python3 -c 'import os,sys; print(os.path.realpath(sys.argv[1]))' "$RESTORE_UPLOAD_DIR")
case "$RESTORE_UPLOAD_DIR/" in
  "$RESTORE_DIR/"*) echo 'RESTORE_DIR and RESTORE_UPLOAD_DIR must be separate, non-overlapping paths' >&2; exit 2 ;;
esac
case "$RESTORE_DIR/" in
  "$RESTORE_UPLOAD_DIR/"*) echo 'RESTORE_DIR and RESTORE_UPLOAD_DIR must be separate, non-overlapping paths' >&2; exit 2 ;;
esac
[ ! -e "$RESTORE_DIR" ] || { echo 'RESTORE_DIR must not already exist'; exit 2; }
[ ! -e "$RESTORE_UPLOAD_DIR" ] || { echo 'RESTORE_UPLOAD_DIR must not already exist'; exit 2; }
command -v pg_restore >/dev/null 2>&1 || { echo 'pg_restore is required for database recovery' >&2; exit 2; }
command -v psql >/dev/null 2>&1 || { echo 'psql is required for database recovery verification' >&2; exit 2; }
mkdir -m 700 -p "$RESTORE_DIR" "$RESTORE_UPLOAD_DIR"
# Always remove decrypted dumps/manifests. Remove a partial upload restore only
# on failure; a successfully recovered uploads directory must survive the script.
RESTORE_SUCCESS=0
cleanup_restore() {
  rm -rf "$RESTORE_DIR"
  if [ "$RESTORE_SUCCESS" -ne 1 ]; then
    rm -rf "$RESTORE_UPLOAD_DIR"
  fi
}
trap cleanup_restore EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
# Prefer the authenticated V1 format. Only a file without its format marker may
# use legacy CBC decryption; an authentication failure must fail closed.
if python3 "$SCRIPT_DIR/backup_crypto.py" decrypt "$BACKUP_FILE" "$RESTORE_DIR/backup.tar.gz"; then
  :
else
  CRYPTO_STATUS=$?
  if [ "$CRYPTO_STATUS" -eq 3 ]; then
    # Legacy CBC is unauthenticated. Never downgrade automatically when an
    # authenticated-format marker is damaged or an unknown file is supplied.
    [ "${RESTORE_ALLOW_LEGACY_CBC:-}" = "YES_I_UNDERSTAND_LEGACY_CBC_IS_UNAUTHENTICATED" ] || {
      echo 'Unrecognized backup format. Legacy CBC restore requires explicit RESTORE_ALLOW_LEGACY_CBC opt-in.' >&2
      exit 2
    }
    # OpenSSL enc with salt writes a Salted__ header followed by an 8-byte salt
    # and a block-aligned AES-CBC body. Reject arbitrary/altered files before
    # invoking the legacy decryptor.
    python3 - "$BACKUP_FILE" <<'PYLEGACY'
import os, sys
path = sys.argv[1]
with open(path, "rb") as stream:
    prefix = stream.read(8)
size = os.path.getsize(path)
if prefix != b"Salted__" or size < 32 or (size - 16) % 16 != 0:
    print("Refusing legacy restore: file is not a structurally valid OpenSSL salted AES-CBC archive", file=sys.stderr)
    raise SystemExit(2)
PYLEGACY
    openssl enc -d -aes-256-cbc -pbkdf2 -in "$BACKUP_FILE" -out "$RESTORE_DIR/backup.tar.gz" -pass env:BACKUP_ENCRYPTION_KEY
  else
    exit "$CRYPTO_STATUS"
  fi
fi
tar -xzf "$RESTORE_DIR/backup.tar.gz" -C "$RESTORE_DIR"
(cd "$RESTORE_DIR" && sha256sum -c SHA256SUMS)
tar -tzf "$RESTORE_DIR/uploads.tar.gz" >/dev/null
# Refuse non-empty targets to avoid overwriting data even if the operator confirms by mistake.
OBJECT_COUNT=$(psql "$RESTORE_DATABASE_URL" -X -A -t -v ON_ERROR_STOP=1 -c \
  "SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname NOT IN ('pg_catalog','information_schema') AND c.relkind IN ('r','p','v','m','S','f') AND n.nspname <> 'pg_toast' AND n.nspname NOT LIKE 'pg_temp_%'")
case "$OBJECT_COUNT" in
  ''|*[!0-9]*) echo 'Could not determine whether disposable PostgreSQL target is empty' >&2; exit 1 ;;
esac
[ "$OBJECT_COUNT" -eq 0 ] || { echo "Refusing restore: target database contains $OBJECT_COUNT table/view/sequence objects" >&2; exit 2; }
pg_restore --exit-on-error --no-owner --no-privileges --dbname "$RESTORE_DATABASE_URL" "$RESTORE_DIR/database.dump"
tar -xzf "$RESTORE_DIR/uploads.tar.gz" -C "$RESTORE_UPLOAD_DIR"
RESTORED_TABLES=$(psql "$RESTORE_DATABASE_URL" -X -A -t -v ON_ERROR_STOP=1 -c \
  "SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname NOT IN ('pg_catalog','information_schema') AND c.relkind IN ('r','p') AND n.nspname <> 'pg_toast' AND n.nspname NOT LIKE 'pg_temp_%'")
case "$RESTORED_TABLES" in
  ''|*[!0-9]*) echo 'Could not verify restored database tables' >&2; exit 1 ;;
esac
[ "$RESTORED_TABLES" -gt 0 ] || { echo 'Restore verification failed: no user tables were restored' >&2; exit 1; }
RESTORE_SUCCESS=1
printf 'restore_success database_tables=%s uploads_dir=%s\n' "$RESTORED_TABLES" "$RESTORE_UPLOAD_DIR"
# Keep only the recovered uploads directory; decrypted database dumps are temporary.
rm -rf "$RESTORE_DIR"
trap - EXIT HUP INT TERM
echo 'Verified database and uploads restored. The target must remain disposable until independently checked; this script never targets a configured production service by default.'
