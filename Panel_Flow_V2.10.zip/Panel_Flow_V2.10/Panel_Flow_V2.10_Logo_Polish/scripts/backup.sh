#!/bin/sh
set -eu
umask 077
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${POSTGRES_PASSWORD:?POSTGRES_PASSWORD is required}"
: "${BACKUP_ENCRYPTION_KEY:?BACKUP_ENCRYPTION_KEY is required; keep it outside the backup volume}"
BACKUP_DIR="${BACKUP_DIR:-/backups}"
UPLOAD_DIR="${UPLOAD_DIR:-/data/uploads}"
BACKUP_RETENTION_DAILY="${BACKUP_RETENTION_DAILY:-7}"
BACKUP_RETENTION_WEEKLY="${BACKUP_RETENTION_WEEKLY:-4}"
BACKUP_RETENTION_MONTHLY="${BACKUP_RETENTION_MONTHLY:-12}"
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
# Serialize backups sharing this volume. Besides avoiding same-second archive name
# collisions, the lock makes it safe to reclaim plaintext work files left by SIGKILL.
exec 9>"$BACKUP_DIR/.backup.lock"
if ! flock -n 9; then
  echo 'backup_skipped: another backup process holds the lock' >&2
  exit 0
fi
# The work directory contains an unencrypted database dump. EXIT traps cannot run
# after SIGKILL/power loss, so delete abandoned work only after taking the lock.
find "$BACKUP_DIR" -mindepth 1 -maxdepth 1 -type d -name '.tmp-*' -exec rm -rf -- {} +
find "$BACKUP_DIR" -mindepth 1 -maxdepth 1 -type f -name '.panel-flow-*.tmp' -delete
find "$BACKUP_DIR" -mindepth 1 -maxdepth 1 -type f -name '.backup-crypto-*' -delete
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
WORK=$(mktemp -d "$BACKUP_DIR/.tmp-${STAMP}.XXXXXX")
ENC_TMP="$BACKUP_DIR/.panel-flow-${STAMP}.tar.gz.enc.tmp"
cleanup() { rm -rf "$WORK"; rm -f "$ENC_TMP"; }
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
# Pass the database password through libpq's supported environment variable.
PGPASSWORD="$POSTGRES_PASSWORD" pg_dump \
  -h "${PGHOST:-db}" -U "${POSTGRES_USER:-panel_flow}" \
  -d "${POSTGRES_DB:-panel_flow}" -Fc -f "$WORK/database.dump"
[ -s "$WORK/database.dump" ] || { echo 'backup_failed: pg_dump produced an empty database dump' >&2; exit 1; }
mkdir -p "$UPLOAD_DIR"
# Transient quota locks/reservations are process state, not user uploads. Do not
# carry them into recovery or they can temporarily consume the restored quota.
tar -C "$UPLOAD_DIR" \
  --exclude='./.quota.lock' \
  --exclude='./.quota-reservations' \
  --exclude='./.upload-*.part' \
  --exclude='*.part' \
  -czf "$WORK/uploads.tar.gz" .
# Relative paths make SHA256SUMS portable after the archive is extracted elsewhere.
(cd "$WORK" && sha256sum database.dump uploads.tar.gz > SHA256SUMS)
printf 'created_utc=%s\nrelease=V99\ncompatibility_release=V97\n' "$STAMP" > "$WORK/MANIFEST.txt"
tar -C "$WORK" -czf "$WORK/backup.tar.gz" database.dump uploads.tar.gz SHA256SUMS MANIFEST.txt
# New archives use authenticated AES-GCM. The restore path continues to support
# legacy OpenSSL AES-CBC archives so retained backups do not become unreadable.
python3 "$SCRIPT_DIR/backup_crypto.py" encrypt "$WORK/backup.tar.gz" "$ENC_TMP"
# Verify authentication, container integrity, and file checksums before publishing.
python3 "$SCRIPT_DIR/backup_crypto.py" decrypt "$ENC_TMP" "$WORK/verify.tar.gz"
tar -tzf "$WORK/verify.tar.gz" >/dev/null
mkdir "$WORK/verified"
tar -xzf "$WORK/verify.tar.gz" -C "$WORK/verified"
(cd "$WORK/verified" && sha256sum -c SHA256SUMS)
FINAL="$BACKUP_DIR/panel-flow-${STAMP}.tar.gz.enc"
mv "$ENC_TMP" "$FINAL"
# Keep the latest backup plus latest archive per day/week/month, according to policy.
python3 "$SCRIPT_DIR/prune_backups.py" "$BACKUP_DIR" \
  "$BACKUP_RETENTION_DAILY" "$BACKUP_RETENTION_WEEKLY" "$BACKUP_RETENTION_MONTHLY"
printf 'backup_success timestamp=%s file=%s\n' "$STAMP" "$(basename "$FINAL")"
