#!/usr/bin/env python3
"""Apply daily/weekly/monthly retention to encrypted Panel Flow backup archives."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import re
import sys

PATTERN = re.compile(r"^panel-flow-(\d{8}T\d{6}Z)\.tar\.gz\.enc$")


def parse_nonnegative(raw: str, name: str, *, minimum: int = 0) -> int:
    try:
        value = int(raw)
    except ValueError as exc:
        raise SystemExit(f"{name} must be an integer") from exc
    if value < minimum:
        raise SystemExit(f"{name} must be >= {minimum}")
    return value


def prune(directory: Path, daily: int, weekly: int, monthly: int, now: datetime | None = None) -> list[Path]:
    if daily < 1:
        raise ValueError("daily retention must be at least 1 to avoid deleting all recent backups")
    now = now or datetime.now(timezone.utc)
    entries: list[tuple[datetime, Path]] = []
    for path in directory.iterdir():
        match = PATTERN.match(path.name)
        if not match or not path.is_file():
            continue
        try:
            stamp = datetime.strptime(match.group(1), "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        entries.append((stamp, path))
    entries.sort(reverse=True)
    if not entries:
        return []
    keep: set[Path] = {entries[0][1]}  # Never delete the newest available backup.
    daily_latest: dict[tuple[int, int, int], Path] = {}
    weekly_latest: dict[tuple[int, int], Path] = {}
    monthly_latest: dict[tuple[int, int], Path] = {}
    current_date = now.date()
    current_iso = current_date.isocalendar()
    for stamp, path in entries:
        age_days = (current_date - stamp.date()).days
        if daily and 0 <= age_days < daily:
            daily_latest.setdefault((stamp.year, stamp.month, stamp.day), path)
        iso = stamp.date().isocalendar()
        current_week_start = current_date.fromordinal(current_date.toordinal() - current_date.isoweekday() + 1)
        stamp_date = stamp.date()
        stamp_week_start = stamp_date.fromordinal(stamp_date.toordinal() - stamp_date.isoweekday() + 1)
        week_age = (current_week_start - stamp_week_start).days // 7
        if weekly and 0 <= week_age < weekly:
            weekly_latest.setdefault((iso.year, iso.week), path)
        month_age = (now.year - stamp.year) * 12 + now.month - stamp.month
        if monthly and 0 <= month_age < monthly:
            monthly_latest.setdefault((stamp.year, stamp.month), path)
    keep.update(daily_latest.values())
    keep.update(weekly_latest.values())
    keep.update(monthly_latest.values())
    deleted = []
    for _, path in entries:
        if path not in keep:
            path.unlink()
            deleted.append(path)
    return deleted


def main(argv: list[str]) -> int:
    if len(argv) != 5:
        print("usage: prune_backups.py BACKUP_DIR DAILY_COUNT WEEKLY_COUNT MONTHLY_COUNT", file=sys.stderr)
        return 2
    directory = Path(argv[1])
    daily = parse_nonnegative(argv[2], "daily retention", minimum=1)
    weekly = parse_nonnegative(argv[3], "weekly retention")
    monthly = parse_nonnegative(argv[4], "monthly retention")
    deleted = prune(directory, daily, weekly, monthly)
    print(f"backup_retention deleted={len(deleted)} kept={sum(1 for p in directory.iterdir() if PATTERN.match(p.name) and p.is_file())}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
