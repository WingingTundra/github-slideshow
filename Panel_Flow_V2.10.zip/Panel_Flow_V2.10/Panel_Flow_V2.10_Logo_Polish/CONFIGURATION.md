# Panel Flow configuration reference

This document describes the environment variables consumed by the application, Docker Compose, or the operational scripts in this repository. The safe starting template is `.env.example`. Do not put real credentials in documentation or commit a populated `.env` file.

## Required for a normal Docker Compose deployment

| Variable | Default | Applies to | Purpose |
|---|---|---|---|
| `BOT_TOKEN` | Empty | Bot | Telegram bot token. Required to run the bot. |
| `POSTGRES_PASSWORD` | Required, no default | Database, bot, API, backup | PostgreSQL password. Compose refuses to start without it. Use a unique high-entropy value. |
| `SUPER_ADMIN_IDS` | Empty | Bot | Comma-separated Telegram IDs granted full owner/super-admin access. Configure at least one trusted owner. |

`DATABASE_URL` is constructed by Compose for the bot and API using the fixed Compose database identity and `POSTGRES_PASSWORD`. When running a process outside Compose, set `DATABASE_URL` to a SQLAlchemy async PostgreSQL URL such as `postgresql+asyncpg://user:password@host:5432/database`.

## Bot and community settings

| Variable | Default | Purpose |
|---|---:|---|
| `ADMIN_IDS` | Empty | Backwards-compatible additional full-admin Telegram IDs; combined with `SUPER_ADMIN_IDS`. |
| `PANEL_FLOW_CHANNEL_URL` | `https://t.me/PanelFlowFestival` | Public channel link. |
| `PANEL_FLOW_CHANNEL_ID` | Empty | Optional negative numeric channel/supergroup ID used for automated status-post reconciliation. Bot must have publish permissions. |
| `PANEL_FLOW_GROUP_URL` | `https://t.me/+KKqbMvF-vI81Zjg0` | Community group link. |
| `PANEL_FLOW_INSTAGRAM_URL` | Existing Panel Flow URL in `.env.example` | Instagram link used as the first-run fallback for the persisted setting. |
| `PANEL_FLOW_WEBSITE_URL` | Empty | Website link used as the first-run fallback for the persisted setting. |
| `PAYMENT_CARD_NUMBER` | Empty | First-run fallback payment card setting; the database setting takes precedence after setup. |
| `PAYMENT_ACCOUNT_NAME` | Existing Persian account name in `.env.example` | First-run fallback account-holder setting. |
| `SUPPORT_USERNAME` | `PanelFlowAdmin` | Official Telegram support username, without `@`. |
| `RESERVATION_TIMEOUT_MINUTES` | `45` | Duration of temporary pending-payment reservation holds. |
| `FSM_STORAGE_TTL_SECONDS` | `604800` | Persistent PostgreSQL FSM inactivity expiry, bounded by application validation to 300–2,592,000 seconds. Compose forwards this value to the bot. |

Panel date, day and time labels are presentation text and are not parsed into operational scheduling values. Reservation expiry and internal operational timestamps use UTC.

## Database startup and connection pools

| Variable | Default | Purpose |
|---|---:|---|
| `DATABASE_STARTUP_MAX_ATTEMPTS` | `5` | Maximum startup retries for transient database DNS/network errors. |
| `DATABASE_STARTUP_RETRY_INITIAL_SECONDS` | `1.0` | Initial delay between retries. |
| `DATABASE_STARTUP_RETRY_MAX_SECONDS` | `8.0` | Maximum retry delay. |
| `DATABASE_POOL_SIZE` | `5` | Main SQLAlchemy pool size per process. |
| `DATABASE_MAX_OVERFLOW` | `10` | Temporary overflow connections for the main pool. |
| `DATABASE_POOL_TIMEOUT_SECONDS` | `30` | Maximum wait for a main-pool connection. |
| `DATABASE_LOCK_POOL_SIZE` | `5` | Separate pool for cross-process FSM advisory-lock operations. |
| `DATABASE_LOCK_MAX_OVERFLOW` | `5` | Temporary overflow for the advisory-lock pool. |
| `DATABASE_LOCK_POOL_TIMEOUT_SECONDS` | `30` | Maximum wait for an advisory-lock pool connection. |

Budget the combined main and lock pools across every bot/API replica against PostgreSQL `max_connections`, allowing capacity for migrations, administration and maintenance.

## Upload storage and retention

| Variable | Default | Purpose |
|---|---:|---|
| `UPLOAD_DIR` | `/data/uploads` | Persistent upload directory inside the application container. |
| `MAX_UPLOAD_MB` | `10` | Maximum individual upload size in MB. |
| `MAX_UPLOAD_STORAGE_MB` | `0` | Aggregate managed upload quota in MB; `0` disables the hard quota. |
| `UPLOAD_STORAGE_WARNING_PERCENT` | `80` | Storage-usage warning threshold. |
| `UPLOAD_STORAGE_CRITICAL_PERCENT` | `92` | Critical storage-usage threshold. |
| `UPLOAD_MIN_FREE_MB` | `256` | Minimum filesystem free space required before accepting uploads. |
| `RECEIPT_RETENTION_DAYS` | `30` | Retention for receipt file content; payment/review history remains in the database. |
| `UPLOAD_ORPHAN_RETENTION_DAYS` | `30` | Retention before orphaned/superseded upload files are purged. |

## Rate limiting

These per-process limits apply independently in each bot process. Multiple replicas require a shared rate-limit backend for globally coordinated limits.

| Variable | Default | Purpose |
|---|---:|---|
| `RATE_LIMIT_MESSAGES` | `12` | Message allowance per window. |
| `RATE_LIMIT_MESSAGE_WINDOW_SECONDS` | `12` | Message rate-limit window. |
| `RATE_LIMIT_MESSAGE_BURST` | `4` | Short message burst allowance. |
| `RATE_LIMIT_CALLBACKS` | `30` | Callback-query allowance per window. |
| `RATE_LIMIT_CALLBACK_WINDOW_SECONDS` | `12` | Callback rate-limit window. |
| `RATE_LIMIT_CALLBACK_BURST` | `8` | Short callback burst allowance. |
| `RATE_LIMIT_NOTICE_COOLDOWN_SECONDS` | `30` | Minimum interval between rate-limit notices to one user. |
| `RATE_LIMIT_ADMIN_MULTIPLIER` | `3` | Multiplier for authorized administrator allowances. |

## HTTP API and future website/Mini App

| Variable | Default | Applies to | Purpose |
|---|---:|---|---|
| `API_ENABLED` | `true` | API and bot config | Enables the API application. |
| `API_TOKEN_SECRET` | Empty | API | Dedicated secret for signed API bearer tokens. Configure a unique value of at least 32 bytes; do not reuse `BOT_TOKEN`. |
| `API_TOKEN_TTL_SECONDS` | `1800` | API | API access-token lifetime, 60–86,400 seconds. |
| `TELEGRAM_INIT_DATA_MAX_AGE_SECONDS` | `900` | API | Maximum accepted age of Telegram Mini App `initData`, 60–86,400 seconds. |
| `TELEGRAM_BOT_ID` | Empty | API | Positive numeric bot ID (digits before the colon in `BOT_TOKEN`); not a secret. |
| `API_CORS_ORIGINS` | Empty | API | Comma-separated exact HTTPS browser origins. HTTP is accepted only for localhost development; wildcard origins are rejected. |
| `API_BIND_HOST` | `127.0.0.1` | Host Compose port binding | Host interface for API exposure. Keep local-only unless a reverse proxy and firewall are configured. |
| `API_PORT` | `8000` | API container | Internal Uvicorn port. |
| `API_HOST_PORT` | `8000` | Host Compose port binding | Host-side port mapped to `API_PORT`. |

Compose sets `API_HOST=0.0.0.0` inside the API container so the process can receive traffic through the container network; the host-side exposure remains controlled separately by `API_BIND_HOST`.

## Encrypted backups and off-site copy

| Variable | Default | Applies to | Purpose |
|---|---:|---|---|
| `BACKUP_ENCRYPTION_KEY` | Required by backup service | Backup/restore | High-entropy encryption secret. Store separately from backup archives and keep a tested recovery copy. |
| `BACKUP_RETENTION_DAILY` | `7` | Backup service | Number of daily archives retained. |
| `BACKUP_RETENTION_WEEKLY` | `4` | Backup service | Number of weekly archives retained. |
| `BACKUP_RETENTION_MONTHLY` | `12` | Backup service | Number of monthly archives retained. |
| `BACKUP_REMOTE_TARGET` | Empty | Host-side off-site script | Optional `rclone` destination such as `remote:panel-flow-backups`; not passed into the Compose project. |
| `RCLONE_BIN` | `rclone` | Host-side off-site script | Optional executable name/path for rclone. |
| `BACKUP_DIR` | `/backups` in Compose | Backup and off-site scripts | Directory containing encrypted archives. Compose sets this internally for the backup service. |
| `PGHOST` | `db` in Compose | Backup script | PostgreSQL host for `pg_dump`; Compose sets this internally. |
| `POSTGRES_DB` | `panel_flow` in Compose | Database and backup | PostgreSQL database name; current Compose file sets this internally. |
| `POSTGRES_USER` | `panel_flow` in Compose | Database and backup | PostgreSQL role; current Compose file sets this internally. |

### Manual restore-only variables

These are intentionally not included as active entries in `.env.example` because a restore must be explicitly targeted at a disposable database and fresh upload directory.

| Variable | Requirement | Purpose |
|---|---|---|
| `CONFIRM_DISPOSABLE_RESTORE` | Must equal `YES_I_AM_RESTORING_TO_A_DISPOSABLE_TARGET` | Explicit safety acknowledgement; restore refuses to run without it. |
| `BACKUP_FILE` | Required | Path to one encrypted archive. |
| `RESTORE_DIR` | Required, must not exist | Fresh temporary directory for decrypted archive content. |
| `RESTORE_DATABASE_URL` | Required, must identify an empty disposable PostgreSQL DB | Target connection string for restore and verification. |
| `RESTORE_UPLOAD_DIR` | Required, must not exist | Fresh destination for restored uploads, separate from `RESTORE_DIR`. |
| `RESTORE_ALLOW_LEGACY_CBC` | Optional explicit opt-in | Must equal `YES_I_UNDERSTAND_LEGACY_CBC_IS_UNAUTHENTICATED` to permit restoring a structurally valid legacy unauthenticated CBC archive. New authenticated archives do not need it. |

The restore script also uses `BACKUP_ENCRYPTION_KEY` from secret storage. Never point the restore script at production unless following a separately reviewed disaster-recovery procedure.

## Configuration precedence and safety

- In Docker Compose, the host `.env` file supplies Compose substitutions; only explicitly listed container environment variables reach each service. The Pydantic application does not receive the host `.env` file as a mounted file.
- Persisted admin-managed settings in PostgreSQL take precedence over their corresponding first-run environment fallbacks.
- Keep `.env`, tokens, database passwords, API signing secrets, backup keys and rclone credentials out of source control and ZIP releases.
- `.env.example` is a template, not a production configuration. Review the defaults and generate fresh secrets before deployment.
