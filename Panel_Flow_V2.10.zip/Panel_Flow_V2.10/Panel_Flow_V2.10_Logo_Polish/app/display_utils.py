"""Formatting helpers for presentation-only panel labels."""
from __future__ import annotations


def rtl_isolate(value) -> str:
    """Keep a complete display fragment in a right-to-left paragraph.

    Telegram clients can otherwise switch a Persian line to LTR when it contains
    Latin words, URLs, numbers, or mixed Persian/English panel metadata.
    """
    return f"\u2067{value}\u2069"


def auto_isolate(value) -> str:
    """Isolate a value while allowing Unicode to select its natural direction."""
    return f"\u2068{value}\u2069"


def ltr_isolate(value) -> str:
    """Keep Latin labels and mixed English tokens in a left-to-right run."""
    return f"\u2066{value}\u2069"


def panel_detail_line(label: str, value, *, icon: str = "") -> str:
    """Render one consistently RTL panel-fact row with an isolated dynamic value."""
    prefix = f"{icon} " if icon else ""
    return rtl_isolate(f"{prefix}{label}: {auto_isolate(value)}")


def has_end_time_label(value: str | None) -> bool:
    """Whether an optional end-time label contains a displayable value.

    Older records use a hyphen, while migration 006 used an em dash. Treat both
    markers (and blank/None values) as absent so every presentation stays consistent.
    """
    if value is None:
        return False
    text = str(value).strip()
    return bool(text) and text not in {"-", "—", "–", "−"}


def volume_label(value) -> str:
    """Format numeric panel volumes consistently as V21 or Volume Movie Night.

    Accept raw numbers and already-prefixed V21 / Volume 21 forms without
    producing repeated prefixes in public, admin, and export views.
    """
    text = str(value if value is not None else "").strip()
    if not text:
        return "Volume"
    if text.casefold().startswith("volume "):
        text = text[7:].strip()
    if text.isdigit():
        return f"V{text}"
    if len(text) > 1 and text[0].casefold() == "v" and text[1:].isdigit():
        return f"V{text[1:]}"
    return f"Volume {text}"


def truncate_display_text(value, max_chars: int, *, suffix: str = "…") -> str:
    """Trim a visible label without silently cutting it off mid-sentence.

    Prefer a word boundary when doing so keeps at least two thirds of the
    available prefix; otherwise retain a readable partial word plus ellipsis.
    This is for short buttons/list labels, not for stored values or full messages.
    """
    text = " ".join(str(value or "").split())
    limit = max(0, int(max_chars))
    if limit == 0:
        return ""
    if len(text) <= limit:
        return text
    marker = str(suffix or "…")
    if len(marker) >= limit:
        return marker[:limit]
    prefix_limit = limit - len(marker)
    prefix = text[:prefix_limit]
    boundary = prefix.rfind(" ")
    if boundary >= max(1, int(prefix_limit * 0.65)):
        prefix = prefix[:boundary]
    return prefix.rstrip() + marker


# Stable English labels for internal workflow states that are surfaced in the
# Telegram UI. Keep database values unchanged; this is presentation-only.
_STATUS_LABELS = {
    "draft": "Draft",
    "published": "Published",
    "registration_open": "Registration open",
    "initiated": "In progress",
    "open": "Open",
    "closed": "Closed",
    "full": "Full",
    "completed": "Completed",
    "archived": "Archived",
    "cancelled": "Cancelled",
    "pending": "Pending",
    "pending_payment": "Awaiting payment",
    "pending_verification": "Awaiting receipt review",
    "confirmed": "Confirmed",
    "rejected": "Rejected",
    "expired": "Expired",
    "declined": "Declined",
    "planned": "Planned",
    "scheduled": "Scheduled",
    "awaiting_review": "Awaiting review",
    "in_progress": "In progress",
    "queued": "Queued",
    "action_required": "Action required",
    "resolved": "Resolved",
    "manual": "Manual",

    "waitlisted": "Waitlisted",
    "registered": "Registered",
    "waiting": "Waiting",
    "invited": "Invited",
    "inviting": "Invitation in progress",
    "approved": "Approved",
    "submitted": "Submitted for review",
    "receipt_approved": "Receipt approved",
    "receipt_rejected": "Receipt rejected",
    "not_attempted": "Not attempted",
    "not_applicable": "Not applicable",
    "sending": "Sending",
    "sent": "Sent",
    "failed": "Failed",
    "unknown": "Unknown",
    "partial": "Partially completed",
    "preview": "Ready for review",
    "processing": "Processing",
    "skipped": "Skipped",
    "awaiting_code": "Awaiting code assignment",
    "ready_to_deliver": "Ready to deliver",
    "delivery_uncertain": "Delivery uncertain",
    "delivery_failed": "Delivery failed",
    "delivered": "Delivered",
    "manually_delivered": "Marked as delivered manually",
    "refunded": "Refunded",
    "denied": "Denied",
    "withdrawn": "Withdrawn",
    "redeemed": "Redeemed",
    "inactive": "Inactive",
    "active": "Active",
    "unmarked": "Not marked",
    "attended": "Attended",
    "no_show": "No-show",
    "suspension": "Suspension",
    "event": "Panel",
    "shop": "Shop",
    "lucky_draw": "Lucky Draw",
    "text": "Text",
    "image": "Image",
    "knowledge": "Knowledge",
    "creative": "Creative",
    "not_required": "Not required",
    "missing": "Missing",
    "awaiting_receipt_review": "Awaiting receipt review",
}


def status_display_label(value, *, labels: dict[str, str] | None = None) -> str:
    """Return a concise, readable English label for an internal status value.

    Enums and strings are accepted. Unknown values are humanized instead of
    exposing snake_case identifiers verbatim. Optional context-specific labels
    may override the common vocabulary without changing stored state.
    """
    raw = getattr(value, "value", value)
    text = str(raw or "").strip()
    if not text:
        return "Unknown"
    key = text.casefold().replace("-", "_").replace(" ", "_")
    mapping = dict(_STATUS_LABELS)
    if labels:
        mapping.update({str(k).casefold(): str(v) for k, v in labels.items()})
    if key in mapping:
        return mapping[key]
    words = key.split("_")
    small_words = {"a", "an", "and", "for", "in", "of", "on", "the", "to", "via", "with"}
    return " ".join(word if index and word in small_words else word[:1].upper() + word[1:] for index, word in enumerate(words))


_ADMIN_STATUS_LABELS = {
    "draft": "پیش‌نویس", "published": "منتشرشده", "registration_open": "ثبت‌نام باز است",
    "initiated": "در حال تکمیل", "open": "باز", "closed": "بسته", "full": "ظرفیت تکمیل",
    "completed": "تکمیل‌شده", "archived": "آرشیوشده", "cancelled": "لغوشده",
    "pending": "در انتظار بررسی", "pending_payment": "در انتظار پرداخت",
    "pending_verification": "در انتظار بررسی رسید", "confirmed": "تأییدشده",
    "rejected": "ردشده", "expired": "منقضی‌شده", "declined": "ردشده",
    "planned": "برنامه‌ریزی‌شده", "scheduled": "زمان‌بندی‌شده",
    "awaiting_review": "در انتظار بررسی", "in_progress": "در حال انجام",
    "queued": "در صف", "action_required": "نیازمند اقدام", "resolved": "رسیدگی‌شده",
    "manual": "دستی", "waitlisted": "در صف انتظار", "registered": "ثبت‌نام‌شده",
    "waiting": "در انتظار", "invited": "دعوت‌شده", "inviting": "در حال ارسال دعوت",
    "approved": "تأییدشده", "submitted": "ارسال‌شده برای بررسی",
    "receipt_approved": "رسید تأییدشده", "receipt_rejected": "رسید ردشده",
    "not_attempted": "اقدامی انجام نشده", "not_applicable": "نامرتبط",
    "sending": "در حال ارسال", "sent": "ارسال‌شده", "failed": "ناموفق",
    "unknown": "نامشخص", "partial": "تکمیل‌شده به‌صورت جزئی",
    "preview": "آمادهٔ بررسی", "processing": "در حال پردازش", "skipped": "ردشده",
    "awaiting_code": "در انتظار تخصیص کد", "ready_to_deliver": "آمادهٔ تحویل",
    "delivery_uncertain": "وضعیت تحویل نامشخص", "delivery_failed": "تحویل ناموفق",
    "delivered": "تحویل‌شده", "manually_delivered": "تحویل دستی ثبت‌شده",
    "refunded": "مستردشده", "denied": "غیرمجاز", "withdrawn": "پس‌گرفته‌شده",
    "redeemed": "استفاده‌شده", "inactive": "غیرفعال", "active": "فعال",
    "unmarked": "ثبت‌نشده", "attended": "حاضر", "no_show": "غایب",
    "suspension": "تعلیق", "event": "پنل", "shop": "فروشگاه",
    "lucky_draw": "قرعه‌کشی", "text": "متن", "image": "تصویر",
    "knowledge": "دانشی", "creative": "خلاقانه", "not_required": "نیازی نیست",
    "missing": "موجود نیست", "awaiting_receipt_review": "در انتظار بررسی رسید",
    "receipt_review": "بررسی رسید", "no_payment_record": "رکورد پرداختی وجود ندارد",
    "quiz": "آزمون", "wyr": "دو راهی", "riddle": "معما",
    "knowledge_correct": "پاسخ درست", "creative_first": "رتبهٔ اول خلاقانه",
    "creative_second": "رتبهٔ دوم خلاقانه", "creative_third": "رتبهٔ سوم خلاقانه",
    "paid_panel": "مشارکت در پنل", "challenge_participation": "مشارکت در چالش",
    "archived_review": "ثبت نظر برای پنل گذشته", "recognized_contribution": "مشارکت ارزشمند",
    "external_competition": "رقابت بیرونی", "personal": "شخصی",
    "public": "عمومی", "system": "سامانه", "owner": "مالک",
    "super_admin": "مدیر کل", "admin": "مدیر", "host": "میزبان",
    "participant": "شرکت‌کننده", "moderator": "ناظر",
    "receipt_review_pending": "در انتظار بررسی رسید", "no_payment": "بدون پرداخت",
}


def admin_status_display_label(value, *, labels: dict[str, str] | None = None) -> str:
    """Return a Persian label for an internal status in administrator screens."""
    raw = getattr(value, "value", value)
    text = str(raw or "").strip()
    if not text:
        return "نامشخص"
    key = text.casefold().replace("-", "_").replace(" ", "_")
    mapping = dict(_ADMIN_STATUS_LABELS)
    if labels:
        mapping.update({str(k).casefold(): str(v) for k, v in labels.items()})
    if key in mapping:
        return mapping[key]
    return text.replace("_", " ")
