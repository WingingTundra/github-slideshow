"""Bounded per-process anti-flood middleware (single bot instance)."""
from __future__ import annotations
import asyncio, logging, time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable
from app.config import settings

log = logging.getLogger(__name__)

@dataclass
class _Bucket:
    events: deque[float] = field(default_factory=deque)
    tokens: float = 0.0
    updated: float = 0.0
    last_notice: float = 0.0
    touched: float = 0.0

class InMemoryLimiter:
    """Atomic async rolling-window + token-bucket limiter, bounded by max_keys."""
    def __init__(self, *, max_keys: int = 20000, clock=time.monotonic):
        self.max_keys=max_keys; self.clock=clock; self._state: dict[tuple[int,str],_Bucket]={}; self._lock=asyncio.Lock()

    async def allow(self, user_id: int, kind: str, *, ceiling: int, window: float, burst: int, refill: float, multiplier: int=1) -> tuple[bool,bool]:
        now=self.clock(); key=(user_id,kind)
        ceiling=max(1,ceiling*max(1,multiplier)); burst=max(1,burst*max(1,multiplier))
        async with self._lock:
            bucket=self._state.get(key)
            if bucket is None:
                if len(self._state)>=self.max_keys:
                    stale=[k for k,v in self._state.items() if now-v.touched > max(window*2, 60)]
                    for k in stale: self._state.pop(k,None)
                    if len(self._state)>=self.max_keys:
                        oldest=min(self._state, key=lambda k:self._state[k].touched); self._state.pop(oldest,None)
                bucket=_Bucket(tokens=float(max(1,burst)), updated=now, touched=now); self._state[key]=bucket
            elapsed=max(0.0,now-bucket.updated); bucket.tokens=min(float(max(1,burst)),bucket.tokens+elapsed*refill); bucket.updated=now; bucket.touched=now
            while bucket.events and bucket.events[0] <= now-window: bucket.events.popleft()
            ok=len(bucket.events)<ceiling and bucket.tokens>=1.0
            if ok:
                bucket.events.append(now); bucket.tokens-=1.0
            notice=False
            if not ok and now-bucket.last_notice >= max(1,settings.rate_limit_notice_cooldown_seconds):
                bucket.last_notice=now; notice=True
            # Periodic bounded-state pruning without requiring a background task.
            if len(self._state)%128==0:
                stale=[k for k,v in self._state.items() if now-v.touched > 600]
                for k in stale: self._state.pop(k,None)
            return ok,notice

limiter=InMemoryLimiter()

