"""Quota-aware public image upload handling with server-side WebP optimization."""
from __future__ import annotations

import asyncio
import hashlib
import os
import re
import shutil
import uuid
from pathlib import Path

from fastapi import UploadFile

from app.config import settings
from app.services.image_processing import optimize_public_image
from app.services.upload_quota import managed_upload_bytes, upload_quota_lock

PREFIX_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,70}$")


def _save_atomic(root: Path, filename: str, data: bytes) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    target = root / filename
    temp = root / f".upload-{uuid.uuid4().hex}.part"
    try:
        with temp.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)
    return target


async def store_public_image(upload: UploadFile, *, prefix: str) -> dict[str, int | str]:
    if not PREFIX_RE.fullmatch(prefix):
        raise ValueError("IMAGE_PREFIX_INVALID")
    max_bytes = int(settings.max_image_upload_mb) * 1024 * 1024
    raw = await upload.read(max_bytes + 1)
    await upload.close()
    if len(raw) > max_bytes:
        raise ValueError("IMAGE_TOO_LARGE")
    optimized = await asyncio.to_thread(
        optimize_public_image, raw,
        max_dimension=int(settings.image_max_dimension),
        quality=int(settings.image_webp_quality),
    )
    thumbnail = await asyncio.to_thread(
        optimize_public_image, raw,
        max_dimension=min(640, int(settings.image_max_dimension)),
        quality=min(76, int(settings.image_webp_quality)),
    )
    root = Path(settings.upload_dir).resolve()
    public_root = root / "public_media"
    digest = hashlib.sha256(optimized).hexdigest()[:20]
    filename = f"{prefix}-{digest}.webp"
    thumb_filename = f"{prefix}-{digest}-thumb.webp"
    root.mkdir(parents=True, exist_ok=True)
    with upload_quota_lock(root):
        target = public_root / filename
        thumb_target = public_root / thumb_filename
        full_exists = target.exists() and target.is_file() and not target.is_symlink()
        thumb_exists = thumb_target.exists() and thumb_target.is_file() and not thumb_target.is_symlink()
        if int(settings.max_upload_storage_mb) > 0:
            occupied = managed_upload_bytes(root)
            limit = int(settings.max_upload_storage_mb) * 1024 * 1024
            required = (0 if full_exists else len(optimized)) + (0 if thumb_exists else len(thumbnail))
            if occupied + required > limit:
                raise ValueError("UPLOAD_STORAGE_QUOTA_EXCEEDED")
        free_bytes = shutil.disk_usage(root).free
        required = (0 if full_exists else len(optimized)) + (0 if thumb_exists else len(thumbnail))
        if free_bytes - required < int(settings.upload_min_free_mb) * 1024 * 1024:
            raise ValueError("UPLOAD_STORAGE_LOW")
        if not full_exists:
            _save_atomic(public_root, filename, optimized)
        if not thumb_exists:
            _save_atomic(public_root, thumb_filename, thumbnail)
        stored_bytes = target.stat().st_size
        thumb_stored_bytes = thumb_target.stat().st_size
    return {
        "url": f"/api/v1/media/{filename}",
        "thumbnail_url": f"/api/v1/media/{filename}?variant=thumb",
        "original_bytes": len(raw), "stored_bytes": stored_bytes,
        "thumbnail_stored_bytes": thumb_stored_bytes,
    }
