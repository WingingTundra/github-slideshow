"""Public-facing seat availability disclosure policy.

Public UI hides signup counts until availability reaches a meaningful milestone:
first a non-numeric Persian message at 50% occupancy, then an exact seat count
when remaining capacity is genuinely low. This is presentation-only: booking
services continue to enforce authoritative live capacity independently.
"""

MAX_PUBLIC_LOW_AVAILABILITY_SEATS = 5


def seat_disclosure_threshold(capacity: int | None) -> int:
    """Return the remaining-seat threshold for public scarcity copy.

    A 15-seat panel discloses availability at five seats remaining. Smaller
    panels use a lower threshold (about one third of capacity), and a one-seat
    panel never shows a misleading "only one seat left" warning while empty.
    """
    try:
        total = int(capacity or 0)
    except (TypeError, ValueError):
        total = 0
    if total <= 1:
        return 0
    return min(MAX_PUBLIC_LOW_AVAILABILITY_SEATS, max(1, total // 3))


def should_disclose_remaining_seats(capacity: int | None, remaining: int | None) -> bool:
    """Whether public UI may show the exact number of seats still available."""
    try:
        total = int(capacity or 0)
        available = int(remaining or 0)
    except (TypeError, ValueError):
        return False
    threshold = seat_disclosure_threshold(total)
    return total > 1 and 0 < available <= threshold


def should_show_capacity_filling_message(
    capacity: int | None,
    used: int | None,
    remaining: int | None,
) -> bool:
    """Show a non-numeric message at >=50% occupancy, before exact scarcity.

    Exact remaining-seat disclosure takes precedence, as does the full-capacity
    state. Tiny panels may move directly from normal availability to exact low
    availability because an intermediate message would have no useful interval.
    """
    try:
        total = int(capacity or 0)
        occupied = max(0, int(used or 0))
        available = max(0, int(remaining or 0))
    except (TypeError, ValueError):
        return False
    if total <= 1 or available <= 0 or occupied <= 0:
        return False
    if should_disclose_remaining_seats(total, available):
        return False
    # Integer-safe ceiling of 50%: odd capacities cross the threshold only
    # once half or more of the seats are actually occupied.
    return occupied >= (total + 1) // 2


def public_catalogue_availability_label(
    capacity: int | None,
    remaining: int | None,
    *,
    registration_open: bool,
    waitlist_available: bool,
) -> str:
    """Render the public panel-card label using the same two-level policy."""
    try:
        total = max(0, int(capacity or 0))
        available = max(0, int(remaining or 0))
    except (TypeError, ValueError):
        total, available = 0, 0
    fa_digits = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
    total_fa = str(total).translate(fa_digits)
    available_fa = str(available).translate(fa_digits)
    if available <= 0:
        return "ظرفیت تکمیل شده است · فهرست انتظار فعال است" if waitlist_available else "ظرفیت تکمیل شده است"
    if not registration_open:
        return f"ثبت‌نام بسته است · ظرفیت کل: {total_fa} نفر"
    if should_disclose_remaining_seats(total, available):
        return f"فقط {available_fa} جای خالی باقی مانده است"
    if should_show_capacity_filling_message(total, total - available, available):
        return "ظرفیت پنل در حال تکمیل است."
    return f"ظرفیت کل: {total_fa} نفر"
