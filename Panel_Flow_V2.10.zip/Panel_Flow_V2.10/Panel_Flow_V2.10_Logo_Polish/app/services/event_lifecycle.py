"""Central event transition policy. Keep registration controls orthogonal to lifecycle."""
from __future__ import annotations
from app.db.models import Event, EventStatus
from app.time_utils import utc_now_naive

_ALLOWED = {
    EventStatus.DRAFT: {EventStatus.PUBLISHED, EventStatus.CANCELLED},
    EventStatus.PUBLISHED: {EventStatus.COMPLETED, EventStatus.CANCELLED},
    EventStatus.COMPLETED: set(),
    EventStatus.CANCELLED: set(),
}


def transition_event(event: Event, target: EventStatus, *, reason: str | None = None) -> None:
    current = EventStatus(event.status)
    target = EventStatus(target)
    if target == current:
        return
    if target not in _ALLOWED[current]:
        raise ValueError(f"Invalid event lifecycle transition: {current.value} -> {target.value}")
    if target == EventStatus.PUBLISHED and event.archived:
        raise ValueError("An archived event cannot be published")
    event.status = target
    if target in {EventStatus.COMPLETED, EventStatus.CANCELLED}:
        event.registration_open = False
        event.registration_closed_reason = "lifecycle"
        event.waitlist_enabled = False
    if target in {EventStatus.COMPLETED, EventStatus.CANCELLED}:
        event.is_postponed = False
        event.postponement_note = None
    if reason and target == EventStatus.CANCELLED:
        event.postponement_note = reason[:2000]



def postpone_event(event: Event, *, note: str | None = None) -> None:
    """Pause a published event without changing its lifecycle status."""
    if EventStatus(event.status) != EventStatus.PUBLISHED:
        raise ValueError("Only published events can be postponed")
    event.is_postponed = True
    event.registration_open = False
    event.registration_closed_reason = "postponed"
    event.postponement_note = note[:2000] if note else None


def resume_postponed_event(event: Event, *, reopen_registration: bool = False) -> None:
    """Clear a postponement; reopening registration remains an explicit choice."""
    if EventStatus(event.status) != EventStatus.PUBLISHED or not event.is_postponed:
        raise ValueError("Only a postponed published event can be resumed")
    event.is_postponed = False
    event.postponement_note = None
    event.registration_closed_reason = "manual"
    event.registration_open = bool(reopen_registration)


def archive_completed_event(event: Event) -> None:
    """Archive only completed events and keep archive/feedback state consistent."""
    if EventStatus(event.status) != EventStatus.COMPLETED:
        raise ValueError("Only completed events can be archived")
    event.archived = True
    event.archived_at = event.archived_at or utc_now_naive()
    event.registration_open = False
    event.waitlist_enabled = False
