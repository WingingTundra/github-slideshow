"""Durable, administrator-reconcilable Host review notification delivery."""
from __future__ import annotations

import logging
from html import escape

from sqlalchemy import select

from app.db.models import Event, EventStatus, User
from app.db.session import SessionLocal
from app.time_utils import utc_now_naive

logger = logging.getLogger(__name__)


async def notify_host_submission_review(bot, event_id: int) -> str:
    """Attempt one Host review notification; never blindly retry an uncertain send.

    Returns sent, failed, not_applicable, not_ready, already_sent, or uncertain.
    State is persisted before sending so a process crash remains visible.
    """
    async with SessionLocal() as session:
        event = (await session.execute(
            select(Event).where(Event.id == int(event_id)).with_for_update()
        )).scalar_one_or_none()
        if event is None or event.submission_status not in {"approved", "rejected"}:
            return "not_ready"
        if event.submission_notification_status == "sent":
            return "already_sent"
        if event.submission_notification_status == "sending":
            return "uncertain"
        if not event.host_id:
            event.submission_notification_status = "not_applicable"
            event.submission_notification_error = None
            await session.commit()
            return "not_applicable"
        host = await session.get(User, int(event.host_id))
        if not host or not host.telegram_id:
            event.submission_notification_status = "failed"
            event.submission_notification_attempts = int(event.submission_notification_attempts or 0) + 1
            event.submission_notification_error = "host_telegram_account_unavailable"
            await session.commit()
            return "failed"
        telegram_id = int(host.telegram_id)
        title = str(event.title or "پنل")
        status = str(event.submission_status)
        feedback = str(event.submission_feedback or "")
        event.submission_notification_status = "sending"
        event.submission_notification_attempts = int(event.submission_notification_attempts or 0) + 1
        event.submission_notification_error = None
        await session.commit()

    if status == "approved":
        body = f"✅ پیش‌نویس پنل «{escape(title)}» تأیید شد. اکنون می‌توانید طبق روال مدیریت، آن را برای کاربران منتشر کنید."
    else:
        body = (
            f"⚠️ پیش‌نویس پنل «{escape(title)}» نیاز به اصلاح دارد.\n"
            f"بازخورد مدیر: {escape(feedback)}\n"
            "برای ویرایش و ارسال دوباره، از /host اقدام کنید."
        )
    try:
        await bot.send_message(telegram_id, body)
    except Exception as exc:
        logger.info("Host submission notification did not confirm delivery for event_id=%s (%s)", int(event_id), type(exc).__name__)
        # Transport/server timeouts may happen after Telegram accepted the send.
        # Keep them in the reconcile-only state rather than blindly allowing retry.
        ambiguous = type(exc).__name__ in {
            "TelegramNetworkError", "TelegramServerError", "TimeoutError", "ConnectionError", "OSError"
        }
        async with SessionLocal() as session:
            event = (await session.execute(
                select(Event).where(Event.id == int(event_id)).with_for_update()
            )).scalar_one_or_none()
            if event and event.submission_notification_status == "sending":
                event.submission_notification_status = "sending" if ambiguous else "failed"
                prefix = "delivery_uncertain:" if ambiguous else "delivery_failed:"
                event.submission_notification_error = f"{prefix}{type(exc).__name__}"[:255]
                await session.commit()
        return "uncertain" if ambiguous else "failed"

    async with SessionLocal() as session:
        event = (await session.execute(
            select(Event).where(Event.id == int(event_id)).with_for_update()
        )).scalar_one_or_none()
        if event and event.submission_notification_status == "sending":
            event.submission_notification_status = "sent"
            event.submission_notified_at = utc_now_naive()
            event.submission_notification_error = None
            await session.commit()
    return "sent"
