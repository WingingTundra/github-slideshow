"""Central organization tenant authorization for event operations."""
from __future__ import annotations
from datetime import datetime
from fastapi import HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from app.config import settings
from app.db.models import (Brand, BrandHostAssignment, Event, HostVerification,
    Organization, OrganizationMembership, OrganizationSubscription, SubscriptionPlan, User)
from app.time_utils import utc_now_naive


def is_platform_admin(user: User) -> bool:
    return int(user.telegram_id) in settings.super_admin_id_set or str(getattr(user.role, "value", user.role)) in {"admin", "super_admin"}


async def active_membership(session: AsyncSession, user: User, organization_id: int,
                            roles: set[str] | None = None) -> OrganizationMembership:
    membership = (await session.execute(select(OrganizationMembership).where(
        OrganizationMembership.organization_id == organization_id,
        OrganizationMembership.user_id == user.id,
        OrganizationMembership.status == "approved",
    ))).scalar_one_or_none()
    if membership is None or (roles and membership.role not in roles):
        raise HTTPException(403, detail={"code": "ORGANIZATION_ACCESS_DENIED"})
    organization = await session.get(Organization, organization_id)
    if organization is None or organization.status != "approved":
        raise HTTPException(403, detail={"code": "ORGANIZATION_NOT_ACTIVE"})
    return membership


async def require_verified_host(session: AsyncSession, user: User) -> HostVerification:
    verification = (await session.execute(select(HostVerification).where(HostVerification.user_id == user.id)
        .order_by(HostVerification.updated_at.desc(), HostVerification.id.desc()).limit(1))).scalar_one_or_none()
    if verification is None or verification.status != "approved":
        raise HTTPException(403, detail={"code": "HOST_VERIFICATION_REQUIRED", "message": "ابتدا باید احراز هویت میزبان شما تأیید شود."})
    return verification


async def active_organization_subscription(session: AsyncSession, organization_id: int) -> tuple[OrganizationSubscription, SubscriptionPlan | None]:
    subscription = (await session.execute(select(OrganizationSubscription).where(
        OrganizationSubscription.organization_id == organization_id)
        .order_by(OrganizationSubscription.created_at.desc(), OrganizationSubscription.id.desc()).limit(1))).scalar_one_or_none()
    now = utc_now_naive()
    if subscription is None or subscription.status not in {"active", "trial"} or subscription.starts_at > now or (subscription.ends_at and subscription.ends_at <= now):
        raise HTTPException(403, detail={"code": "ORGANIZATION_SUBSCRIPTION_INACTIVE", "message": "اشتراک سازمان فعال نیست."})
    plan = await session.get(SubscriptionPlan, subscription.plan_id) if subscription.plan_id else None
    if plan is None or not plan.is_active:
        raise HTTPException(403, detail={"code": "ORGANIZATION_PLAN_UNAVAILABLE", "message": "طرح اشتراک سازمان فعال یا معتبر نیست."})
    return subscription, plan


async def authorize_brand(session: AsyncSession, user: User, organization_id: int, brand_id: int,
                           *, allow_platform_admin: bool = True) -> tuple[Organization, Brand, OrganizationMembership | None]:
    organization = await session.get(Organization, organization_id)
    brand = await session.get(Brand, brand_id)
    if organization is None or organization.status != "approved" or brand is None or brand.organization_id != organization_id or brand.status != "approved":
        raise HTTPException(422, detail={"code": "APPROVED_ORGANIZATION_BRAND_REQUIRED"})
    if allow_platform_admin and is_platform_admin(user):
        return organization, brand, None
    membership = await active_membership(session, user, organization_id, {"owner", "admin", "host"})
    await require_verified_host(session, user)
    await active_organization_subscription(session, organization_id)
    if membership.role == "host":
        assigned = await session.scalar(select(BrandHostAssignment.brand_id).where(
            BrandHostAssignment.organization_id == organization_id,
            BrandHostAssignment.brand_id == brand_id,
            BrandHostAssignment.membership_id == membership.id))
        if assigned is None:
            raise HTTPException(403, detail={"code": "BRAND_ASSIGNMENT_REQUIRED"})
    return organization, brand, membership


async def authorize_event_manage(session: AsyncSession, user: User, event: Event,
                                 *, allow_platform_admin: bool = True) -> OrganizationMembership | None:
    if allow_platform_admin and is_platform_admin(user):
        return None
    if event.organization_id is None or event.brand_id is None:
        raise HTTPException(403, detail={"code": "LEGACY_EVENT_REQUIRES_PLATFORM_ADMIN"})
    organization, brand, membership = await authorize_brand(session, user, event.organization_id, event.brand_id, allow_platform_admin=False)
    if membership is None:
        return None
    if membership.role == "host":
        if event.host_id != user.id:
            raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    elif membership.role not in {"owner", "admin"}:
        raise HTTPException(403, detail={"code": "EVENT_MANAGEMENT_PERMISSION_REQUIRED"})
    return membership


async def list_accessible_organization_ids(session: AsyncSession, user: User) -> list[int]:
    return [int(x) for x in (await session.execute(select(OrganizationMembership.organization_id).join(
        Organization, Organization.id == OrganizationMembership.organization_id).where(
        OrganizationMembership.user_id == user.id, OrganizationMembership.status == "approved",
        Organization.status == "approved", OrganizationMembership.role.in_(("owner", "admin", "host"))))).scalars().all()]
