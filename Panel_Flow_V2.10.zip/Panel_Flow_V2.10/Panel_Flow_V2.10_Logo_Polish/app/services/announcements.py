from __future__ import annotations

import asyncio
from dataclasses import dataclass

from aiogram import Bot
from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
    TelegramServerError,
)
from aiogram.types import InlineKeyboardMarkup


@dataclass(frozen=True)
class SendResult:
    status: str  # sent, failed, or unknown (Telegram may have accepted a timed-out send)
    attempts: int
    error: str | None = None


async def send_announcement_to_user(
    bot: Bot,
    telegram_id: int,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    *,
    max_attempts: int = 4,
    delay_seconds: float = 0.05,
) -> SendResult:
    """Send with bounded retries, honoring Telegram RetryAfter and avoiding blind retries on uncertainty."""
    attempts = 0
    while attempts < max(1, int(max_attempts)):
        attempts += 1
        try:
            await bot.send_message(
                int(telegram_id), text, reply_markup=reply_markup,
                disable_web_page_preview=True,
            )
            return SendResult("sent", attempts)
        except TelegramRetryAfter as exc:
            if attempts >= max_attempts:
                return SendResult("failed", attempts, f"rate_limited: retry_after={exc.retry_after}")
            # Telegram explicitly instructs the client to wait this long before retrying.
            await asyncio.sleep(max(0.0, float(exc.retry_after)) + 0.1)
        except (TelegramNetworkError, TelegramServerError, TimeoutError, OSError) as exc:
            # A timeout/server error may occur after Telegram accepted the message. Marking
            # the final result unknown prevents a later resume from sending duplicates.
            if attempts >= max_attempts:
                return SendResult("unknown", attempts, f"delivery_uncertain: {type(exc).__name__}")
            await asyncio.sleep(min(2.0, delay_seconds * (2 ** (attempts - 1))))
        except (TelegramForbiddenError, TelegramBadRequest) as exc:
            return SendResult("failed", attempts, f"permanent: {type(exc).__name__}: {str(exc)[:160]}")
        except TelegramAPIError as exc:
            # Unclassified Telegram API errors are treated as permanent rather than retried forever.
            return SendResult("failed", attempts, f"telegram_api: {type(exc).__name__}: {str(exc)[:160]}")
        except Exception as exc:
            # Libraries/adapters can surface socket exceptions outside aiogram's wrappers.
            name = type(exc).__name__.casefold()
            if any(token in name for token in ("timeout", "connection", "network", "server")):
                if attempts >= max_attempts:
                    return SendResult("unknown", attempts, f"delivery_uncertain: {type(exc).__name__}")
                await asyncio.sleep(min(2.0, delay_seconds * (2 ** (attempts - 1))))
                continue
            return SendResult("failed", attempts, f"send_error: {type(exc).__name__}: {str(exc)[:160]}")
    return SendResult("unknown", attempts, "retry_limit_reached")


async def broadcast(
    bot: Bot,
    users,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    delay_seconds: float = 0.05,
) -> tuple[int, int]:
    """Compatibility wrapper for older workflows that expect (sent, failed) counts."""
    sent = failed = 0
    for user in users:
        result = await send_announcement_to_user(
            bot, int(user.telegram_id), text, reply_markup, delay_seconds=delay_seconds,
        )
        if result.status == "sent":
            sent += 1
        else:
            # The legacy tuple has no 'unknown' bucket, so it is counted as not confirmed sent.
            failed += 1
        if delay_seconds:
            await asyncio.sleep(delay_seconds)
    return sent, failed
