"""Domain helpers for admin-managed discounts and recipient-bound rewards.

Codes are event-scoped and have no automatic expiry timestamps. Their eligibility
ends when an admin disables them or their selected panels are archived/deleted.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import Iterable

from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import (
    Booking,
    DiscountCode,
    DiscountCodeEvent,
    DiscountRedemption,
    Event,
    EventStatus,
)
from app.time_utils import utc_now_naive

ACTIVE_REDEMPTION_STATUSES = ("pending", "approved", "redeemed")
USER_USED_STATUSES = ("pending", "approved", "rejected", "redeemed")


def summarize_redemption_counts(status_counts) -> tuple[int, int, int, int]:
    """Summarize grouped redemption counts as (occupied, redeemed, pending, approved).

    The occupied count intentionally matches ACTIVE_REDEMPTION_STATUSES used by
    validation/cap enforcement. Rejected requests do not consume the global cap.
    """
    counts = {str(status): int(count) for status, count in status_counts}
    redeemed = counts.get("redeemed", 0)
    pending = counts.get("pending", 0)
    approved = counts.get("approved", 0)
    occupied = sum(counts.get(status, 0) for status in ACTIVE_REDEMPTION_STATUSES)
    return occupied, redeemed, pending, approved


@dataclass(frozen=True)
class DiscountDefinition:
    canonical_code: str
    discount_type: str
    discount_value: Decimal


def normalize_code(raw: str | None) -> str:
    text = (raw or "").strip().upper()
    # Allow users typing Persian/Arabic digits while displaying canonical Latin codes.
    text = text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    return re.sub(r"\s+", "", text)


def parse_public_code_definition(raw: str | None) -> DiscountDefinition:
    """Parse the agreed readable format: WORD20 = 20%; WORD100K = 100,000 toman."""
    code = normalize_code(raw)
    match = re.fullmatch(r"([A-Z]{2,30})(\d{1,7})(K?)", code)
    if not match:
        raise ValueError("FORMAT")
    prefix, number_text, suffix = match.groups()
    number = int(number_text)
    if suffix == "K":
        value = Decimal(number * 1000)
        if number <= 0 or value > Decimal("1000000000"):
            raise ValueError("VALUE")
        return DiscountDefinition(f"{prefix}{number}K", "fixed", value)
    if not 1 <= number <= 100:
        raise ValueError("VALUE")
    return DiscountDefinition(f"{prefix}{number}", "percent", Decimal(number))


def parse_personal_discount_value(raw: str | None) -> tuple[str, Decimal]:
    """Parse a personal reward amount such as 80% or 100K (toman)."""
    text = (raw or "").strip().upper().replace("٪", "%")
    text = text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    text = re.sub(r"\s+", "", text)
    percent = re.fullmatch(r"(\d{1,3})%", text)
    if percent:
        value = int(percent.group(1))
        if not 1 <= value <= 100:
            raise ValueError("VALUE")
        return "percent", Decimal(value)
    fixed = re.fullmatch(r"(\d{1,7})K", text)
    if fixed:
        value = int(fixed.group(1)) * 1000
        if value <= 0 or value > 1_000_000_000:
            raise ValueError("VALUE")
        return "fixed", Decimal(value)
    raise ValueError("FORMAT")


def calculate_discount(total: Decimal | int, per_person: Decimal | int, count: int,
                        discount_type: str, discount_value: Decimal | int,
                        *, scope: str) -> Decimal:
    """Calculate an integral-toman discount; scope is 'total' or 'single'."""
    total_d = max(Decimal(0), Decimal(total))
    price_d = max(Decimal(0), Decimal(per_person))
    value = Decimal(discount_value)
    base = total_d if scope == "total" else min(price_d, total_d)
    if discount_type == "percent":
        amount = (base * value / Decimal(100)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    elif discount_type == "fixed":
        amount = value
    else:
        raise ValueError("INVALID_DISCOUNT_TYPE")
    return min(max(Decimal(0), amount), base)


async def eligible_public_codes_exist(session: AsyncSession, event_id: int, telegram_id: int | None = None) -> bool:
    """Whether this user has at least one applicable public code worth prompting for."""
    codes = (await session.execute(
        select(DiscountCode).join(
            DiscountCodeEvent, DiscountCodeEvent.discount_code_id == DiscountCode.id
        ).where(
            DiscountCodeEvent.event_id == event_id,
            DiscountCode.active.is_(True),
            DiscountCode.kind.in_(("public", "restricted")),
        ).order_by(DiscountCode.id)
    )).scalars().all()
    for code in codes:
        if code.max_redemptions is not None:
            used = int((await session.execute(select(func.count(DiscountRedemption.id)).where(
                DiscountRedemption.discount_code_id == code.id,
                DiscountRedemption.status.in_(ACTIVE_REDEMPTION_STATUSES),
            ))).scalar_one())
            if used >= int(code.max_redemptions):
                continue
        if telegram_id is not None:
            used_query = select(DiscountRedemption.id).where(
                DiscountRedemption.discount_code_id == code.id,
                DiscountRedemption.user_telegram_id == telegram_id,
                DiscountRedemption.status.in_(USER_USED_STATUSES),
            )
            if code.usage_policy == "once_per_panel":
                used_query = used_query.where(DiscountRedemption.event_id == event_id)
            if (await session.execute(used_query.limit(1))).scalar_one_or_none() is not None:
                continue
        return True
    return False


async def accepted_personal_reward(session: AsyncSession, telegram_id: int, event_id: int) -> DiscountCode | None:
    """Return the recipient's accepted and unused personal reward for this panel, if any."""
    stmt = select(DiscountCode).join(
        DiscountCodeEvent, DiscountCodeEvent.discount_code_id == DiscountCode.id
    ).where(
        DiscountCodeEvent.event_id == event_id,
        DiscountCode.kind == "personal",
        DiscountCode.active.is_(True),
        DiscountCode.recipient_telegram_id == telegram_id,
        DiscountCode.accepted_at.is_not(None),
    ).order_by(DiscountCode.created_at.desc())
    codes = (await session.execute(stmt)).scalars().all()
    for code in codes:
        used = int((await session.execute(select(func.count(DiscountRedemption.id)).where(
            DiscountRedemption.discount_code_id == code.id,
            DiscountRedemption.user_telegram_id == telegram_id,
            DiscountRedemption.status.in_(ACTIVE_REDEMPTION_STATUSES),
        ))).scalar_one())
        if used == 0:
            return code
    return None


async def validate_code_for_user(
    session: AsyncSession, *, raw_code: str, telegram_id: int, event_id: int
) -> DiscountCode:
    code_text = normalize_code(raw_code)
    code = (await session.execute(
        select(DiscountCode).where(DiscountCode.code == code_text).with_for_update()
        .execution_options(populate_existing=True)
    )).scalar_one_or_none()
    if not code:
        raise ValueError("CODE_INVALID")
    if not code.active:
        raise ValueError("CODE_INACTIVE")
    if code.kind not in ("public", "restricted"):
        raise ValueError("CODE_NOT_APPLICABLE")
    eligible = (await session.execute(select(DiscountCodeEvent.id).where(
        DiscountCodeEvent.discount_code_id == code.id,
        DiscountCodeEvent.event_id == event_id,
    ))).scalar_one_or_none()
    if eligible is None:
        raise ValueError("CODE_NOT_FOR_PANEL")
    if code.max_redemptions is not None:
        used = int((await session.execute(select(func.count(DiscountRedemption.id)).where(
            DiscountRedemption.discount_code_id == code.id,
            DiscountRedemption.status.in_(ACTIVE_REDEMPTION_STATUSES),
        ))).scalar_one())
        if used >= code.max_redemptions:
            raise ValueError("CODE_UNAVAILABLE")
    user_query = select(DiscountRedemption.id).where(
        DiscountRedemption.discount_code_id == code.id,
        DiscountRedemption.user_telegram_id == telegram_id,
        DiscountRedemption.status.in_(USER_USED_STATUSES),
    )
    if code.usage_policy == "once_per_panel":
        user_query = user_query.where(DiscountRedemption.event_id == event_id)
    if (await session.execute(user_query.limit(1))).scalar_one_or_none() is not None:
        raise ValueError("CODE_ALREADY_USED")
    return code


async def reactivate_inactive_discount_code(
    session: AsyncSession,
    *,
    code_id: int,
    event_ids: Iterable[int],
    max_redemptions: int | None,
    usage_policy: str,
    commit: bool = True,
) -> tuple[DiscountCode, list[Event]]:
    """Edit scope/usage settings and reactivate an inactive public or restricted code.

    Redemption history is retained. A new global cap cannot be set below the
    number of pending, approved, or redeemed uses already consuming capacity.
    The caller controls the surrounding transaction lifecycle and notifications.
    """
    selected_ids = sorted({int(value) for value in event_ids})
    if not selected_ids:
        raise ValueError("NO_EVENTS")
    if max_redemptions is not None and not 1 <= int(max_redemptions) <= 1_000_000:
        raise ValueError("INVALID_MAX_REDEMPTIONS")
    code = await session.get(DiscountCode, int(code_id), with_for_update=True)
    if not code or code.active or code.kind not in ("public", "restricted"):
        raise ValueError("NOT_EDITABLE")
    events = (await session.execute(select(Event).where(
        Event.id.in_(selected_ids),
        Event.archived.is_(False),
        Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED)),
    ))).scalars().all()
    if {int(event.id) for event in events} != set(selected_ids):
        raise ValueError("INVALID_EVENTS")
    used = int((await session.execute(select(func.count(DiscountRedemption.id)).where(
        DiscountRedemption.discount_code_id == code_id,
        DiscountRedemption.status.in_(ACTIVE_REDEMPTION_STATUSES),
    ))).scalar_one())
    if max_redemptions is not None and int(max_redemptions) < used:
        raise ValueError("LIMIT_BELOW_USAGE")
    if usage_policy not in ("once_total", "once_per_panel"):
        raise ValueError("INVALID_USAGE_POLICY")

    await session.execute(delete(DiscountCodeEvent).where(DiscountCodeEvent.discount_code_id == code_id))
    for event_id in selected_ids:
        session.add(DiscountCodeEvent(discount_code_id=code_id, event_id=event_id))
    code.max_redemptions = int(max_redemptions) if max_redemptions is not None else None
    code.usage_policy = usage_policy
    code.active = True
    code.disabled_at = None
    code.disabled_reason = None
    code.requires_approval = code.kind == "restricted"
    if commit:
        await session.commit()
    events_by_id = {int(event.id): event for event in events}
    return code, [events_by_id[event_id] for event_id in selected_ids]


async def detach_event_discount_codes(session: AsyncSession, event_id: int) -> dict[str, list[int]]:
    """Detach an archived/deleted panel from promotions and close requests targeting it.

    Returns telegram IDs that should be notified after the caller commits.
    """
    links = (await session.execute(select(DiscountCodeEvent).where(
        DiscountCodeEvent.event_id == event_id
    ).with_for_update())).scalars().all()
    code_ids = {int(link.discount_code_id) for link in links}
    for link in links:
        await session.delete(link)

    pending_rows = (await session.execute(select(DiscountRedemption).where(
        DiscountRedemption.event_id == event_id,
        DiscountRedemption.status.in_(("pending", "approved")),
    ).with_for_update())).scalars().all()
    notify_users: set[int] = set()
    for redemption in pending_rows:
        notify_users.add(int(redemption.user_telegram_id))
        redemption.status = "cancelled"
        redemption.draft_json = None
        redemption.contact_phone = None
        redemption.updated_at = utc_now_naive()

    codes_disabled: list[int] = []
    for code_id in code_ids:
        remaining = int((await session.execute(select(func.count(DiscountCodeEvent.id)).where(
            DiscountCodeEvent.discount_code_id == code_id,
            DiscountCodeEvent.event_id != event_id,
        ))).scalar_one())
        if remaining == 0:
            code = await session.get(DiscountCode, code_id, with_for_update=True)
            if code and code.active:
                code.active = False
                code.disabled_at = utc_now_naive()
                code.disabled_reason = "No eligible panels remain"
                codes_disabled.append(code_id)
    # Notify personal reward recipients when their last eligible panel is removed.
    for code_id in codes_disabled:
        code = await session.get(DiscountCode, code_id)
        if code and code.kind == "personal" and code.recipient_telegram_id:
            notify_users.add(int(code.recipient_telegram_id))
    return {"telegram_ids": sorted(notify_users), "disabled_code_ids": codes_disabled}


def code_label(code: DiscountCode) -> str:
    if code.kind == "personal":
        return code.label or "هدیه شخصی"
    return code.code or code.label or f"کد #{code.id}"


def discount_display(code: DiscountCode) -> str:
    if code.discount_type == "percent":
        return f"{int(code.discount_value)}٪"
    return f"{int(code.discount_value):,} تومان"


def code_format_help() -> str:
    return (
        "فرمت کد: یک واژهٔ انگلیسی + عدد انتهایی.\n"
        "مثال: <code>PANEL20</code> یعنی ۲۰٪ تخفیف؛ <code>PANEL100</code> یعنی ۱۰۰٪ تخفیف.\n"
        "برای مبلغ ثابت، پسوند K استفاده کنید: <code>PANEL100K</code> یعنی ۱۰۰٬۰۰۰ تومان؛ وجود K یعنی مبلغ ثابت، نه درصد.\n"
        "کدها تاریخ انقضای خودکار ندارند و تا زمان غیرفعال‌شدن دستی قابل استفاده‌اند، مشروط بر اینکه دست‌کم یک پنل واجد شرایط باقی مانده باشد. "
        "با آرشیو یا حذف همهٔ پنل‌های مشمول، کد دیگر قابل استفاده نخواهد بود."
    )


async def purge_inactive_discount_codes(session: AsyncSession) -> tuple[int, int]:
    """Permanently remove every inactive code and its redemption history.

    Existing bookings keep their final amount, discount snapshot, status, and payment
    outcome; only their FK to a deleted code is cleared. This is intentionally a
    destructive, admin-confirmed cleanup operation and never touches active codes.
    The caller owns commit/rollback and any user notifications.
    """
    inactive_ids = (await session.execute(
        select(DiscountCode.id).where(DiscountCode.active.is_(False)).with_for_update()
    )).scalars().all()
    inactive_ids = [int(value) for value in inactive_ids]
    if not inactive_ids:
        return 0, 0

    # Preserve financial and reservation history, while detaching its FK to the
    # code that is being removed. Snapshot fields remain available for reporting.
    await session.execute(
        update(Booking)
        .where(Booking.discount_code_id.in_(inactive_ids))
        .values(discount_code_id=None)
    )
    redemptions_result = await session.execute(
        delete(DiscountRedemption).where(DiscountRedemption.discount_code_id.in_(inactive_ids))
    )
    await session.execute(
        delete(DiscountCodeEvent).where(DiscountCodeEvent.discount_code_id.in_(inactive_ids))
    )
    codes_result = await session.execute(
        delete(DiscountCode).where(
            DiscountCode.id.in_(inactive_ids),
            DiscountCode.active.is_(False),
        )
    )
    return int(codes_result.rowcount or 0), int(redemptions_result.rowcount or 0)
