"""Transactional outbox primitives for durable, idempotent side effects.

Call enqueue_notification_outbox(session, ...) inside the same SQLAlchemy
transaction as the domain change. A worker can claim rows with SKIP LOCKED.
"""
from __future__ import annotations

from datetime import timedelta
import logging
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import NotificationOutbox
from app.time_utils import utc_now_naive

logger = logging.getLogger(__name__)


async def enqueue_notification_outbox(
    session: AsyncSession, *, dedupe_key: str, event_type: str, payload: dict,
) -> NotificationOutbox:
    if not dedupe_key or len(dedupe_key) > 180:
        raise ValueError("dedupe_key must contain 1–180 characters")
    if not event_type or len(event_type) > 80:
        raise ValueError("event_type must contain 1–80 characters")
    row = NotificationOutbox(
        dedupe_key=dedupe_key,
        event_type=event_type,
        payload=payload or {},
        status="pending",
        available_at=utc_now_naive(),
    )
    session.add(row)
    await session.flush()
    return row


async def enqueue_event_notification(
    session: AsyncSession, *, event_id: int, event_type: str, change_key: str | None = None,
) -> NotificationOutbox:
    """Enqueue a panel notification in the caller's domain transaction."""
    event_id = int(event_id)
    if event_type == "panel.published":
        return await enqueue_notification_outbox(
            session, dedupe_key=f"panel.published:{event_id}",
            event_type=event_type, payload={"event_id": event_id},
        )
    if event_type == "panel.changed":
        if not change_key or len(change_key) > 100:
            raise ValueError("change_key is required for panel.changed")
        return await enqueue_notification_outbox(
            session, dedupe_key=f"panel.changed:{event_id}:{change_key}",
            event_type=event_type, payload={"event_id": event_id, "change_key": change_key},
        )
    raise ValueError(f"Unsupported event notification type: {event_type}")


async def claim_outbox_batch(session: AsyncSession, *, limit: int = 50) -> list[NotificationOutbox]:
    now = utc_now_naive()
    rows = list((await session.scalars(
        select(NotificationOutbox)
        .where(
            or_(
                (NotificationOutbox.status == "pending") & (NotificationOutbox.available_at <= now),
                (NotificationOutbox.status == "processing") & (NotificationOutbox.locked_at <= now - timedelta(minutes=10)),
            )
        )
        .order_by(NotificationOutbox.id)
        .limit(max(1, min(int(limit), 200)))
        .with_for_update(skip_locked=True)
    )).all())
    for row in rows:
        row.status = "processing"
        row.locked_at = now
        row.attempts += 1
    await session.flush()
    return rows


async def mark_outbox_sent(session: AsyncSession, row: NotificationOutbox) -> None:
    row.status = "sent"
    row.sent_at = utc_now_naive()
    row.locked_at = None
    row.last_error = None
    await session.flush()


async def mark_outbox_failed(session: AsyncSession, row: NotificationOutbox, error: BaseException) -> None:
    row.status = "failed" if row.attempts >= 8 else "pending"
    row.locked_at = None
    row.last_error = f"{type(error).__name__}: {error}"[:240]
    row.available_at = utc_now_naive() + timedelta(minutes=min(360, 2 ** min(row.attempts, 8)))
    await session.flush()


async def process_notification_outbox_once(*, limit: int = 30) -> int:
    """Dispatch supported durable notification jobs; unknown types fail closed."""
    from app.db.session import SessionLocal
    async with SessionLocal() as session:
        rows = await claim_outbox_batch(session, limit=limit)
        claimed = [(row.id, row.event_type, dict(row.payload or {}), row.attempts) for row in rows]
        await session.commit()
    completed = 0
    for row_id, event_type, payload, attempts in claimed:
        try:
            event_id = int(payload["event_id"])
            from app.config import settings
            if not (settings.bot_token or "").strip():
                raise RuntimeError("BOT_TOKEN is not configured; outbox job will be retried")
            if event_type == "panel.published":
                from app.services.event_notifications import send_new_panel_follow_notifications
                await send_new_panel_follow_notifications(event_id)
            elif event_type == "panel.changed":
                from app.services.event_notifications import send_registered_event_change_notifications
                await send_registered_event_change_notifications(event_id, str(payload["change_key"]))
            else:
                raise ValueError(f"Unsupported outbox event type: {event_type}")
            async with SessionLocal() as session:
                row = await session.get(NotificationOutbox, row_id, with_for_update=True)
                if row is not None and row.status == "processing":
                    await mark_outbox_sent(session, row)
                    await session.commit()
            completed += 1
        except Exception as exc:
            logger.exception("Outbox delivery failed (row_id=%s, type=%s)", row_id, event_type)
            async with SessionLocal() as session:
                row = await session.get(NotificationOutbox, row_id, with_for_update=True)
                if row is not None and row.status == "processing":
                    await mark_outbox_failed(session, row, exc)
                    await session.commit()
    return completed
