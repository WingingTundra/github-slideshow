"""Idempotent Telegram notifications for Panel Flow website discovery and bookings.

The delivery ledger is shared by new-panel, event-change and 24-hour reminder
messages. Existing booking-confirmation and waitlist-invitation flows remain the
transactional source of truth and are intentionally not duplicated here.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

from sqlalchemy import and_, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.db.models import (
    Booking, Event, EventNotificationDelivery, EventStatus, RegistrationStatus,
    Organization, User, UserDiscoveryPreference, UserOrganizationFollow, UserTopicFollow,
)
from app.db.session import SessionLocal
from app.time_utils import PLATFORM_TIMEZONE, utc_now_naive

logger = logging.getLogger(__name__)
MAX_NOTIFICATION_ATTEMPTS = 5
RETRY_DELAYS_MINUTES = {1: 5, 2: 30, 3: 120, 4: 360}
IRAN_TZ = PLATFORM_TIMEZONE
ACTIVE_REGISTERED_STATUSES = (
    RegistrationStatus.PENDING_PAYMENT,
    RegistrationStatus.PENDING_VERIFICATION,
    RegistrationStatus.CONFIRMED,
)


def _bot_token() -> str:
    return (settings.bot_token or "").strip()


def _event_url(event_id: int) -> str | None:
    origin = (settings.panel_flow_website_url or "").strip().rstrip("/")
    return f"{origin}/events/{int(event_id)}" if origin else None


def _as_utc_naive(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value
    return value.astimezone(ZoneInfo("UTC")).replace(tzinfo=None)


def _defer_for_quiet_hours(preference, due_at: datetime) -> datetime | None:
    """Return a later UTC-naive due time when a promotional send falls in quiet hours."""
    start_raw = getattr(preference, "quiet_hours_start", None) if preference is not None else None
    end_raw = getattr(preference, "quiet_hours_end", None) if preference is not None else None
    if not start_raw or not end_raw:
        return None
    try:
        start = time.fromisoformat(str(start_raw))
        end = time.fromisoformat(str(end_raw))
    except ValueError:
        return None
    if start == end:
        return None
    local_due = _as_utc_naive(due_at).replace(tzinfo=ZoneInfo("UTC")).astimezone(IRAN_TZ)
    local_clock = local_due.timetz().replace(tzinfo=None)
    if start < end:
        active = start <= local_clock < end
        end_day = local_due.date()
    else:
        active = local_clock >= start or local_clock < end
        end_day = local_due.date() + timedelta(days=1) if local_clock >= start else local_due.date()
    if not active:
        return None
    release = datetime.combine(end_day, end, tzinfo=IRAN_TZ)
    return release.astimezone(ZoneInfo("UTC")).replace(tzinfo=None)


def _digest_due_at(frequency: str, now: datetime) -> datetime:
    """Daily (20:00) and weekly (Friday 20:00) digest schedule in Tehran time."""
    current_local = _as_utc_naive(now).replace(tzinfo=ZoneInfo("UTC")).astimezone(IRAN_TZ)
    target_time = time(20, 0)
    target_day = current_local.date()
    if frequency == "weekly":
        days_until_friday = (4 - current_local.weekday()) % 7
        target_day = current_local.date() + timedelta(days=days_until_friday)
        if days_until_friday == 0 and current_local.time().replace(tzinfo=None) >= target_time:
            target_day += timedelta(days=7)
    elif current_local.time().replace(tzinfo=None) >= target_time:
        target_day += timedelta(days=1)
    target = datetime.combine(target_day, target_time, tzinfo=IRAN_TZ)
    return target.astimezone(ZoneInfo("UTC")).replace(tzinfo=None)


async def _queue_promotional_digest(session_factory, *, event_id: int, user_id: int,
                                    notification_key: str, reason: str | None,
                                    message: str, due_at: datetime, now: datetime) -> bool:
    async with session_factory() as session:
        existing = await session.scalar(select(EventNotificationDelivery.id).where(
            EventNotificationDelivery.event_id == int(event_id),
            EventNotificationDelivery.user_id == int(user_id),
            EventNotificationDelivery.notification_key == notification_key,
        ))
        if existing is not None:
            return False
        row = EventNotificationDelivery(
            event_id=int(event_id), user_id=int(user_id), notification_key=notification_key,
            notification_type="notification_digest", status="pending", reason=reason,
            attempts=0, digest_message=message[:1200], digest_due_at=due_at,
            updated_at=now,
        )
        session.add(row)
        try:
            await session.commit()
            return True
        except IntegrityError:
            await session.rollback()
            return False


async def _claim_delivery(
    event_id: int,
    user_id: int,
    notification_key: str,
    notification_type: str,
    reason: str | None = None,
) -> int | None:
    """Claim one recipient delivery; a durable ledger prevents concurrent duplicates.

    Failed deliveries use bounded exponential backoff (5m, 30m, 2h, 6h).
    Stale pending claims are recoverable after 15 minutes; sent rows are immutable.
    """
    now = utc_now_naive()
    async with SessionLocal() as session:
        row = await session.scalar(select(EventNotificationDelivery).where(
            EventNotificationDelivery.event_id == int(event_id),
            EventNotificationDelivery.user_id == int(user_id),
            EventNotificationDelivery.notification_key == notification_key,
        ).with_for_update())
        if row is not None:
            if row.digest_due_at is not None:
                return None
            if row.status == "sent" or int(row.attempts or 0) >= MAX_NOTIFICATION_ATTEMPTS:
                return None
            if row.status == "failed" and row.next_attempt_at and row.next_attempt_at > now:
                return None
            last_update = row.updated_at or row.created_at
            if row.status == "pending" and last_update and now - last_update < timedelta(minutes=15):
                return None
            row.status = "pending"
            row.notification_type = notification_type
            row.reason = reason
            row.last_error = None
            row.next_attempt_at = None
            row.attempts = int(row.attempts or 0) + 1
            row.updated_at = now
        else:
            row = EventNotificationDelivery(
                event_id=int(event_id), user_id=int(user_id), notification_key=notification_key,
                notification_type=notification_type, status="pending", reason=reason, attempts=1,
                updated_at=now,
            )
            session.add(row)
        try:
            await session.commit()
        except IntegrityError:
            await session.rollback()
            return None
        await session.refresh(row)
        return int(row.id)


async def _finish_delivery(delivery_id: int, *, sent: bool, error: str | None = None) -> None:
    now = utc_now_naive()
    async with SessionLocal() as session:
        row = await session.get(EventNotificationDelivery, int(delivery_id), with_for_update=True)
        if row is None:
            return
        row.status = "sent" if sent else "failed"
        row.sent_at = now if sent else None
        row.last_error = None if sent else (error or "DELIVERY_FAILED")[:120]
        row.updated_at = now
        attempt = int(row.attempts or 0)
        delay = RETRY_DELAYS_MINUTES.get(attempt)
        row.next_attempt_at = None if sent or delay is None else now + timedelta(minutes=delay)
        await session.commit()


async def _send_once(bot, *, event_id: int, user: User, notification_key: str,
                     notification_type: str, message: str, reason: str | None = None) -> bool:
    delivery_id = await _claim_delivery(
        event_id, int(user.id), notification_key, notification_type, reason
    )
    if delivery_id is None:
        return False
    try:
        await bot.send_message(int(user.telegram_id), message, disable_web_page_preview=True)
    except Exception as exc:  # a failed notification must never fail the panel workflow
        await _finish_delivery(delivery_id, sent=False, error=type(exc).__name__)
        logger.info("Panel notification failed (event_id=%s user_id=%s type=%s)",
                    event_id, user.id, notification_type)
        return False
    await _finish_delivery(delivery_id, sent=True)
    return True


async def send_new_panel_follow_notifications(event_id: int) -> int:
    """Notify users who follow any topic or organization on a newly published panel."""
    token = _bot_token()
    if not token:
        logger.info("Skipping followed-panel notifications for event_id=%s: BOT_TOKEN is not configured", event_id)
        return 0
    from aiogram import Bot

    bot = Bot(token=token)
    sent = 0
    try:
        async with SessionLocal() as session:
            event = await session.scalar(select(Event).where(
                Event.id == int(event_id), Event.status == EventStatus.PUBLISHED,
                Event.archived.is_(False), Event.is_postponed.is_(False),
            ))
            if event is None:
                return 0
            topic_keys = [str(value) for value in (event.topic_tags or [])]
            topic_user_ids = set((await session.execute(
                select(UserTopicFollow.user_id).where(UserTopicFollow.topic_key.in_(topic_keys))
            )).scalars().all()) if topic_keys else set()
            organization_user_ids = set((await session.execute(
                select(UserOrganizationFollow.user_id).where(
                    UserOrganizationFollow.organization_id == event.organization_id
                )
            )).scalars().all()) if event.organization_id else set()
            followed_user_ids = topic_user_ids | organization_user_ids
            if not followed_user_ids:
                return 0
            users = (await session.execute(select(User).where(User.id.in_(followed_user_ids)))).scalars().all()
            preferences = (await session.execute(select(UserDiscoveryPreference).where(
                UserDiscoveryPreference.user_id.in_(followed_user_ids)
            ))).scalars().all()
            pref_by_user = {int(pref.user_id): pref for pref in preferences}
            organization = await session.get(Organization, event.organization_id) if event.organization_id else None
            title, city, day, start_time = event.title, event.city, event.event_date_label, event.start_time_label
            event_url = _event_url(event.id)
        for user in users:
            uid = int(user.id)
            pref = pref_by_user.get(uid)
            via_topic = uid in topic_user_ids and bool(pref and pref.notify_followed_topics)
            via_org = uid in organization_user_ids and bool(pref and pref.notify_followed_organizations)
            if not (via_topic or via_org):
                continue
            reason = "موضوع‌ها و سازمان‌های دنبال‌شده" if via_topic and via_org else (
                "موضوع دنبال‌شده" if via_topic else (organization.name if organization else "سازمان دنبال‌شده")
            )
            message = f"پنل تازه‌ای بر اساس علایق شما منتشر شد.\n\n{title}\n{city} · {day} · {start_time}\nدلیل پیشنهاد: {reason}"
            if event_url:
                message += f"\n{event_url}"
            delivery_now = utc_now_naive()
            digest_frequency = str(getattr(pref, "digest_frequency", "immediate") or "immediate")
            due_at = _digest_due_at(digest_frequency, delivery_now) if digest_frequency in {"daily", "weekly"} else delivery_now
            quiet_release = _defer_for_quiet_hours(pref, due_at)
            if quiet_release is not None:
                due_at = quiet_release
            if digest_frequency in {"daily", "weekly"} or quiet_release is not None:
                queued = await _queue_promotional_digest(
                    SessionLocal, event_id=event_id, user_id=uid,
                    notification_key="published-follow-v1", reason=reason,
                    message=f"• {title} — {city} · {day} · {start_time}" + (f"\n{event_url}" if event_url else ""),
                    due_at=due_at, now=delivery_now,
                )
                sent += int(queued)
                continue
            sent += int(await _send_once(
                bot, event_id=event_id, user=user, notification_key="published-follow-v1",
                notification_type="new_followed_panel", message=message, reason=reason,
            ))
    except Exception:
        logger.exception("Followed-panel notification task failed for event_id=%s", event_id)
    finally:
        await bot.session.close()
    return sent


async def send_registered_event_change_notifications(event_id: int, change_key: str) -> int:
    """Notify active booking owners after a published panel's public details change."""
    token = _bot_token()
    if not token:
        logger.info("Skipping event-change notifications for event_id=%s: BOT_TOKEN is not configured", event_id)
        return 0
    from aiogram import Bot

    bot = Bot(token=token)
    sent = 0
    try:
        async with SessionLocal() as session:
            event = await session.scalar(select(Event).where(
                Event.id == int(event_id), Event.archived.is_(False),
                Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED, EventStatus.CANCELLED]),
            ))
            if event is None:
                return 0
            user_ids = set((await session.execute(select(Booking.booked_by_user_id).where(
                Booking.event_id == event.id, Booking.status.in_(ACTIVE_REGISTERED_STATUSES)
            ).distinct())).scalars().all())
            if not user_ids:
                return 0
            users = (await session.execute(select(User).where(User.id.in_(user_ids)))).scalars().all()
            preferences = (await session.execute(select(UserDiscoveryPreference).where(
                UserDiscoveryPreference.user_id.in_(user_ids)
            ))).scalars().all()
            pref_by_user = {int(pref.user_id): pref for pref in preferences}
            status = event.status
            postponed = bool(getattr(event, "is_postponed", False))
            postponement_note = (getattr(event, "postponement_note", None) or "").strip()
            title, city, day, start_time = event.title, event.city, event.event_date_label, event.start_time_label
            event_url = _event_url(event.id)
        for user in users:
            pref = pref_by_user.get(int(user.id))
            if pref is not None and not pref.notify_panel_changes:
                continue
            if status == EventStatus.CANCELLED:
                lead = "اطلاعیه مهم: پنلی که برای آن ثبت‌نام کرده‌اید لغو شده است."
            elif status == EventStatus.COMPLETED:
                lead = "وضعیت پنلی که برای آن ثبت‌نام کرده‌اید به پایان‌یافته تغییر کرده است."
            elif postponed:
                lead = "اطلاعیه مهم: پنلی که برای آن ثبت‌نام کرده‌اید به تعویق افتاده است؛ ثبت‌نام جدید تا اعلام زمان‌بندی تازه بسته خواهد بود."
            else:
                lead = "جزئیات پنلی که برای آن ثبت‌نام کرده‌اید به‌روزرسانی شده است."
            message = f"{lead}\n\n{title}\n{city} · {day} · {start_time}"
            if postponed and postponement_note:
                message += f"\nتوضیح برگزارکننده: {postponement_note}"
            if event_url:
                message += f"\nمشاهده جزئیات: {event_url}"
            sent += int(await _send_once(
                bot, event_id=event_id, user=user, notification_key=change_key,
                notification_type="registered_panel_changed", message=message,
            ))
    except Exception:
        logger.exception("Registered panel update notification failed for event_id=%s", event_id)
    finally:
        await bot.session.close()
    return sent


async def send_registration_reminders_once(*, bot, now: datetime | None = None,
                                           session_factory=None) -> int:
    """Send one 24-hour reminder to confirmed booking owners in Iran local time.

    A one-hour eligibility window is used so a 15-minute maintenance loop can
    recover from short restarts. Invalid or absent display times are skipped.
    """
    session_factory = session_factory or SessionLocal
    current = now or datetime.now(IRAN_TZ)
    if current.tzinfo is None:
        current = current.replace(tzinfo=IRAN_TZ)
    else:
        current = current.astimezone(IRAN_TZ)
    today = current.date()
    try:
        async with session_factory() as session:
            events = (await session.execute(select(Event).where(
                Event.status == EventStatus.PUBLISHED, Event.archived.is_(False),
                Event.event_date_iso >= today,
                Event.event_date_iso <= today + timedelta(days=1),
            ))).scalars().all()
            event_rows: list[tuple[Event, list[User], dict[int, UserDiscoveryPreference]]] = []
            for event in events:
                try:
                    parsed_time = time.fromisoformat(str(event.start_time_label or ""))
                except ValueError:
                    continue
                event_start = datetime.combine(event.event_date_iso, parsed_time, tzinfo=IRAN_TZ)
                remaining = event_start - current
                if not (timedelta(hours=23, minutes=30) <= remaining <= timedelta(hours=24, minutes=30)):
                    continue
                user_ids = set((await session.execute(select(Booking.booked_by_user_id).where(
                    Booking.event_id == event.id, Booking.status == RegistrationStatus.CONFIRMED
                ).distinct())).scalars().all())
                if not user_ids:
                    continue
                users = (await session.execute(select(User).where(User.id.in_(user_ids)))).scalars().all()
                preferences = (await session.execute(select(UserDiscoveryPreference).where(
                    UserDiscoveryPreference.user_id.in_(user_ids)
                ))).scalars().all()
                pref_map = {int(pref.user_id): pref for pref in preferences}
                event_rows.append((event, users, pref_map))
        sent = 0
        for event, users, pref_map in event_rows:
            event_url = _event_url(event.id)
            for user in users:
                pref = pref_map.get(int(user.id))
                if pref is not None and not pref.notify_registration_reminders:
                    continue
                message = (
                    f"یادآوری پنل فلو: فردا پنل شما برگزار می‌شود.\n\n"
                    f"{event.title}\n{event.city} · {event.event_date_label} · {event.start_time_label}\n"
                    "برای دیدن جزئیات و آماده‌شدن برای گفت‌وگو، صفحه پنل را ببینید."
                )
                if event_url:
                    message += f"\n{event_url}"
                sent += int(await _send_once(
                    bot, event_id=event.id, user=user, notification_key="reminder-24h-v1",
                    notification_type="registration_reminder_24h", message=message,
                ))
        return sent
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("24-hour panel reminder sweep failed")
        return 0


async def dispatch_notification_digests_once(*, now: datetime | None = None, session_factory=None) -> int:
    """Deliver due optional followed-panel digests with the same durable retry ledger."""
    session_factory = session_factory or SessionLocal
    token = _bot_token()
    if not token:
        return 0
    current = _as_utc_naive(now or utc_now_naive())
    cutoff = current - timedelta(minutes=15)
    due_filter = or_(
        and_(EventNotificationDelivery.status == "pending", EventNotificationDelivery.digest_due_at.is_not(None), EventNotificationDelivery.digest_due_at <= current),
        and_(EventNotificationDelivery.status == "failed", EventNotificationDelivery.next_attempt_at.is_not(None), EventNotificationDelivery.next_attempt_at <= current),
        and_(EventNotificationDelivery.status == "pending", EventNotificationDelivery.digest_due_at.is_(None), EventNotificationDelivery.updated_at <= cutoff),
    )
    async with session_factory() as session:
        user_ids = (await session.execute(select(EventNotificationDelivery.user_id).where(
            EventNotificationDelivery.notification_type == "notification_digest",
            EventNotificationDelivery.attempts < MAX_NOTIFICATION_ATTEMPTS,
            due_filter,
        ).distinct().limit(200))).scalars().all()
    if not user_ids:
        return 0
    from aiogram import Bot
    bot = Bot(token=token)
    delivered = 0
    try:
        for user_id in sorted({int(value) for value in user_ids}):
            async with session_factory() as session:
                rows = (await session.execute(select(EventNotificationDelivery).where(
                    EventNotificationDelivery.user_id == user_id,
                    EventNotificationDelivery.notification_type == "notification_digest",
                    EventNotificationDelivery.attempts < MAX_NOTIFICATION_ATTEMPTS,
                    due_filter,
                ).order_by(EventNotificationDelivery.created_at.asc()).limit(30).with_for_update(skip_locked=True))).scalars().all()
                if not rows:
                    continue
                preference = await session.get(UserDiscoveryPreference, user_id)
                followed_topics = set((await session.execute(select(UserTopicFollow.topic_key).where(
                    UserTopicFollow.user_id == user_id
                ))).scalars().all())
                followed_organizations = set((await session.execute(select(UserOrganizationFollow.organization_id).where(
                    UserOrganizationFollow.user_id == user_id
                ))).scalars().all())
                event_ids = {int(row.event_id) for row in rows}
                event_map = {int(event.id): event for event in (await session.execute(select(Event).where(
                    Event.id.in_(event_ids)
                ))).scalars().all()} if event_ids else {}
                row_items = []
                for row in rows:
                    event = event_map.get(int(row.event_id))
                    topic_match = bool(event and set(event.topic_tags or []) & followed_topics)
                    organization_match = bool(event and event.organization_id in followed_organizations)
                    consent_is_current = bool(
                        preference and event and event.status == EventStatus.PUBLISHED
                        and not event.archived and not bool(getattr(event, "is_postponed", False))
                        and ((topic_match and preference.notify_followed_topics)
                             or (organization_match and preference.notify_followed_organizations))
                    )
                    if not consent_is_current:
                        row.status = "skipped"
                        row.digest_due_at = None
                        row.next_attempt_at = None
                        row.updated_at = current
                        continue
                    quiet_release = _defer_for_quiet_hours(preference, current)
                    if quiet_release is not None:
                        row.status = "pending"
                        row.digest_due_at = quiet_release
                        row.updated_at = current
                        continue
                    message_text = str(row.digest_message or "").strip()
                    if not message_text:
                        row.status = "skipped"
                        row.updated_at = current
                        continue
                    row.status = "pending"
                    row.attempts = int(row.attempts or 0) + 1
                    row.updated_at = current
                    row.next_attempt_at = None
                    row.digest_due_at = None
                    row_items.append((int(row.id), message_text, int(row.attempts)))
                await session.commit()
            if not row_items:
                continue
            # Split on actual Telegram message length; never mark entries delivered
            # when their title/link was truncated out of a digest.
            heading = "🔔 خلاصه پنل‌های تازه بر اساس علایق شما"
            chunks: list[list[tuple[int, str, int]]] = []
            current_chunk: list[tuple[int, str, int]] = []
            for item in row_items:
                candidate = current_chunk + [item]
                candidate_text = heading + "\n\n" + "\n\n".join(part[1] for part in candidate)
                if current_chunk and len(candidate_text) > 3800:
                    chunks.append(current_chunk)
                    current_chunk = [item]
                else:
                    current_chunk = candidate
            if current_chunk:
                chunks.append(current_chunk)
            try:
                recipient = None
                async with session_factory() as session:
                    recipient = await session.get(User, user_id)
                if recipient is None:
                    raise RuntimeError("DIGEST_RECIPIENT_NOT_FOUND")
            except Exception as exc:
                chunks_failed = chunks
                for failed_chunk in chunks_failed:
                    async with session_factory() as session:
                        for row_id, _message_text, attempt in failed_chunk:
                            row = await session.get(EventNotificationDelivery, row_id, with_for_update=True)
                            if row is None:
                                continue
                            row.status = "failed"
                            row.last_error = type(exc).__name__[:120]
                            delay = RETRY_DELAYS_MINUTES.get(attempt)
                            row.next_attempt_at = current + timedelta(minutes=delay) if delay else None
                            row.updated_at = current
                        await session.commit()
                continue
            for chunk_index, chunk in enumerate(chunks):
                message = heading + "\n\n" + "\n\n".join(item[1] for item in chunk)
                try:
                    await bot.send_message(int(recipient.telegram_id), message, disable_web_page_preview=True)
                except Exception as exc:
                    logger.info("Panel notification digest failed (user_id=%s)", user_id)
                    # Retry this and all unsent chunks. Earlier successful chunks
                    # are already marked sent and will not be duplicated.
                    for failed_chunk in chunks[chunk_index:]:
                        async with session_factory() as session:
                            for row_id, _message_text, attempt in failed_chunk:
                                row = await session.get(EventNotificationDelivery, row_id, with_for_update=True)
                                if row is None:
                                    continue
                                row.status = "failed"
                                row.last_error = type(exc).__name__[:120]
                                delay = RETRY_DELAYS_MINUTES.get(attempt)
                                row.next_attempt_at = current + timedelta(minutes=delay) if delay else None
                                row.updated_at = current
                            await session.commit()
                    break
                async with session_factory() as session:
                    for row_id, _message_text, _attempt in chunk:
                        row = await session.get(EventNotificationDelivery, row_id, with_for_update=True)
                        if row is None:
                            continue
                        row.status = "sent"
                        row.sent_at = current
                        row.last_error = None
                        row.next_attempt_at = None
                        row.updated_at = current
                    await session.commit()
                delivered += len(chunk)
    finally:
        await bot.session.close()
    return delivered


async def retry_failed_notifications_once(*, now: datetime | None = None, session_factory=None) -> int:
    """Re-run due followed-panel and registered-panel change notifications.

    The existing per-recipient delivery ledger remains authoritative, so each
    replay only attempts missing recipients and never duplicates a sent message.
    """
    session_factory = session_factory or SessionLocal
    current = now or utc_now_naive()
    if current.tzinfo is not None:
        current = current.astimezone(ZoneInfo("UTC")).replace(tzinfo=None)
    cutoff = current - timedelta(minutes=15)
    async with session_factory() as session:
        due_rows = (await session.execute(select(
            EventNotificationDelivery.event_id,
            EventNotificationDelivery.notification_type,
            EventNotificationDelivery.notification_key,
        ).where(
            EventNotificationDelivery.notification_type != "notification_digest",
            EventNotificationDelivery.attempts < MAX_NOTIFICATION_ATTEMPTS,
            ((EventNotificationDelivery.status == "failed") &
             (EventNotificationDelivery.next_attempt_at.is_not(None)) &
             (EventNotificationDelivery.next_attempt_at <= current)) |
            ((EventNotificationDelivery.status == "pending") &
             (EventNotificationDelivery.updated_at <= cutoff)),
        ).distinct().limit(100))).all()
    jobs = {(int(event_id), str(kind), str(key)) for event_id, kind, key in due_rows}
    completed = 0
    for event_id, kind, key in sorted(jobs):
        try:
            if kind == "new_followed_panel":
                completed += await send_new_panel_follow_notifications(event_id)
            elif kind == "registered_panel_changed":
                completed += await send_registered_event_change_notifications(event_id, key)
            # Transactional 24-hour reminders already retry through their own
            # eligibility sweep; they are deliberately not sent by this worker.
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Failed notification retry sweep for event_id=%s type=%s", event_id, kind)
    return completed


async def periodic_notification_retries(interval_seconds: int = 300) -> None:
    """Run the durable notification retry sweep every five minutes."""
    while True:
        try:
            completed = await retry_failed_notifications_once()
            digest_count = await dispatch_notification_digests_once()
            from app.services.notification_outbox import process_notification_outbox_once
            outbox_count = await process_notification_outbox_once()
            if completed or digest_count or outbox_count:
                logger.info("Retried %s notifications, delivered %s digest items and processed %s outbox jobs", completed, digest_count, outbox_count)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic panel notification retry sweep failed")
        await asyncio.sleep(max(60, int(interval_seconds)))


async def periodic_registration_reminders(bot, interval_seconds: int = 900) -> None:
    """Run the idempotent 24-hour reminder sweep every fifteen minutes."""
    while True:
        try:
            sent = await send_registration_reminders_once(bot=bot)
            if sent:
                logger.info("Sent %s registration reminders", sent)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic registration reminder sweep failed")
        await asyncio.sleep(max(60, int(interval_seconds)))
