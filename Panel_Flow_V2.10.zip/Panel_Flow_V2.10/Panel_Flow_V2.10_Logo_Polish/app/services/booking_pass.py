"""Signed, read-only reservation-verification links for registration passes."""
from __future__ import annotations

import hashlib
import hmac
import re

from app.config import settings

SIGNATURE_HEX_LENGTH = 24  # 96-bit truncated HMAC; fits Telegram's 64-char start payload.
_SIGNATURE_RE = re.compile(rf"^[0-9a-f]{{{SIGNATURE_HEX_LENGTH}}}$")


def _signing_key() -> bytes:
    # Prefer the separately configurable application signing secret. BOT_TOKEN is
    # a stable fallback for existing deployments that have not set that secret.
    value = str(settings.api_token_secret or settings.bot_token or "").strip()
    if not value:
        raise RuntimeError("BOOKING_PASS_SIGNING_KEY_UNCONFIGURED")
    return value.encode("utf-8")


def booking_pass_signature(booking_id: int) -> str:
    booking_id = int(booking_id)
    if booking_id <= 0:
        raise ValueError("INVALID_BOOKING_ID")
    digest = hmac.new(_signing_key(), f"panel-flow:booking-pass:v1:{booking_id}".encode(), hashlib.sha256).hexdigest()
    return digest[:SIGNATURE_HEX_LENGTH]


def booking_pass_payload(booking_id: int) -> str:
    payload = f"bookingverify_{int(booking_id)}_{booking_pass_signature(int(booking_id))}"
    if len(payload) > 64:
        raise ValueError("BOOKING_PASS_PAYLOAD_TOO_LONG")
    return payload


def verify_booking_pass_signature(booking_id: int, signature: str) -> bool:
    try:
        if int(booking_id) <= 0 or not _SIGNATURE_RE.fullmatch(str(signature or "")):
            return False
        expected = booking_pass_signature(int(booking_id))
    except (TypeError, ValueError, RuntimeError):
        return False
    return hmac.compare_digest(expected, str(signature))
