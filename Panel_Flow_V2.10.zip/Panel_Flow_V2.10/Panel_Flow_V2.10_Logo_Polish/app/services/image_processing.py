"""Safe, bounded processing for public website images.

Only public profile/event imagery is converted. Receipts, PDFs and other evidence
files intentionally continue through their existing lossless validation/storage flow.
"""
from __future__ import annotations

from io import BytesIO

from PIL import Image, ImageOps, UnidentifiedImageError


ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
MAX_PIXELS = 40_000_000


def optimize_public_image(data: bytes, *, max_dimension: int = 2200, quality: int = 82) -> bytes:
    if not data:
        raise ValueError("IMAGE_EMPTY")
    try:
        with Image.open(BytesIO(data)) as source:
            if source.format not in ALLOWED_FORMATS:
                raise ValueError("IMAGE_FORMAT_NOT_ALLOWED")
            if getattr(source, "n_frames", 1) != 1:
                raise ValueError("ANIMATED_IMAGE_NOT_ALLOWED")
            width, height = source.size
            if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
                raise ValueError("IMAGE_DIMENSIONS_NOT_ALLOWED")
            source.verify()
        with Image.open(BytesIO(data)) as source:
            image = ImageOps.exif_transpose(source)
            image.thumbnail((int(max_dimension), int(max_dimension)), Image.Resampling.LANCZOS)
            # Rebuild a clean pixel-only image to drop EXIF, GPS, comments and profiles.
            if "A" in image.getbands():
                cleaned = image.convert("RGBA")
            else:
                cleaned = image.convert("RGB")
            output = BytesIO()
            cleaned.save(output, format="WEBP", quality=int(quality), method=5, optimize=True)
            result = output.getvalue()
            if not result:
                raise ValueError("IMAGE_PROCESSING_FAILED")
            return result
    except ValueError:
        raise
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError("IMAGE_INVALID_OR_UNSAFE") from exc
