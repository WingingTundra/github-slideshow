"""Bounded recipient-list parsing for administrator personal-reward batches."""
from __future__ import annotations

import csv
import io
from dataclasses import dataclass

from app.services.user_access import parse_telegram_numeric_id

MAX_BULK_TEXT_CHARS = 20_000
MAX_BULK_FILE_BYTES = 100_000
MAX_BULK_ROWS = 500
CSV_HEADERS = {
    "id", "telegram_id", "telegram id", "user_id", "user id", "telegram numeric id",
    "شناسه", "شناسه تلگرام", "شناسهٔ تلگرام", "آیدی", "آیدی تلگرام",
}
_DIGIT_TRANSLATION = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"
)


@dataclass
class ParsedRecipientList:
    ids: list[int]
    duplicates: list[dict]
    invalid: list[dict]
    submitted_entries: int


def _entry_id(raw: str):
    return parse_telegram_numeric_id((raw or "").translate(_DIGIT_TRANSLATION))


def parse_manual_recipients(raw: str) -> ParsedRecipientList:
    if raw is None or len(raw) > MAX_BULK_TEXT_CHARS:
        raise ValueError("INPUT_TOO_LARGE")
    tokens: list[tuple[str, str]] = []
    for line_no, line in enumerate(raw.splitlines(), start=1):
        # Blank lines are harmless formatting; empty fields inside a comma-separated
        # list are reported as invalid entries instead of silently disappearing.
        if not line.strip():
            continue
        parts = line.split(",")
        for part_no, token in enumerate(parts, start=1):
            value = token.strip()
            if not value and len(parts) == 1:
                continue
            tokens.append((f"خط {line_no}" + (f"، مورد {part_no}" if len(parts) > 1 else ""), value))
            if len(tokens) > MAX_BULK_ROWS:
                raise ValueError("TOO_MANY_ROWS")
    return _classify(tokens)


def parse_uploaded_recipients(content: bytes, suffix: str) -> ParsedRecipientList:
    if len(content) > MAX_BULK_FILE_BYTES:
        raise ValueError("FILE_TOO_LARGE")
    if suffix.lower() not in {".txt", ".csv"}:
        raise ValueError("UNSUPPORTED_FILE")
    try:
        decoded = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("INVALID_ENCODING") from exc
    if "\x00" in decoded:
        raise ValueError("INVALID_TEXT")
    tokens: list[tuple[str, str]] = []
    if suffix.lower() == ".txt":
        if len(decoded) > MAX_BULK_TEXT_CHARS:
            raise ValueError("INPUT_TOO_LARGE")
        for line_no, line in enumerate(decoded.splitlines(), start=1):
            value = line.strip()
            if not value:
                continue
            # Treat comma-separated values in TXT identically to manual paste.
            parts = value.split(",")
            for part_no, part in enumerate(parts, start=1):
                item = part.strip()
                if not item and len(parts) == 1:
                    continue
                tokens.append((f"سطر {line_no}" + (f"، مورد {part_no}" if len(parts) > 1 else ""), item))
                if len(tokens) > MAX_BULK_ROWS:
                    raise ValueError("TOO_MANY_ROWS")
    else:
        try:
            rows = list(csv.reader(io.StringIO(decoded)))
        except csv.Error as exc:
            raise ValueError("INVALID_CSV") from exc
        if len(rows) > MAX_BULK_ROWS + 1:
            raise ValueError("TOO_MANY_ROWS")
        for row_no, row in enumerate(rows, start=1):
            if not row or not any((col or "").strip() for col in row):
                continue
            first = (row[0] or "").strip()
            if row_no == 1 and first.casefold() in CSV_HEADERS:
                continue
            tokens.append((f"سطر {row_no}", first))
            if len(tokens) > MAX_BULK_ROWS:
                raise ValueError("TOO_MANY_ROWS")
    return _classify(tokens)


def _classify(tokens: list[tuple[str, str]]) -> ParsedRecipientList:
    ids: list[int] = []
    seen: set[int] = set()
    duplicates: list[dict] = []
    invalid: list[dict] = []
    for label, raw in tokens:
        value = _entry_id(raw)
        if value is None:
            invalid.append({"entry": label, "value": raw[:80], "reason": "شناسه باید فقط عدد مثبت تلگرام باشد"})
        elif value in seen:
            duplicates.append({"entry": label, "telegram_id": value})
        else:
            seen.add(value)
            ids.append(value)
    return ParsedRecipientList(ids=ids, duplicates=duplicates, invalid=invalid, submitted_entries=len(tokens))
