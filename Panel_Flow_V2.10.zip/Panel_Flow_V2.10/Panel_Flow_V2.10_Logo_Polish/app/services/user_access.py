"""Shared user-access moderation helpers."""
from __future__ import annotations

import re

from sqlalchemy import or_, select

from app.db.models import BlockedUser, UserModerationRecord
from app.time_utils import utc_now_naive


TELEGRAM_ID_MAX = (2**63) - 1
_DIGIT_TRANSLATION = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
    "01234567890123456789",
)


def parse_telegram_numeric_id(raw: str | None) -> int | None:
    """Parse a positive Telegram numeric ID, accepting Persian/Arabic digits.

    Usernames and signed/non-numeric values are deliberately not accepted: the
    admin UI must target a stable numeric Telegram identity.
    """
    if raw is None:
        return None
    value = raw.strip().translate(_DIGIT_TRANSLATION)
    if not re.fullmatch(r"[0-9]{1,19}", value):
        return None
    parsed = int(value)
    if parsed <= 0 or parsed > TELEGRAM_ID_MAX:
        return None
    return parsed


async def is_telegram_id_blocked(session, telegram_id: int) -> bool:
    """Return whether the stable Telegram ID is in the persistent blocklist."""
    return await session.get(BlockedUser, int(telegram_id)) is not None


FEATURE_RESTRICTION_SCOPES = {"booking", "suggestions", "challenges"}


async def has_active_feature_restriction(session, telegram_id: int, scope: str) -> bool:
    """Return whether a non-expired, active feature-specific restriction exists.

    This is deliberately separate from the global BlockedUser/account-suspension
    system: a booking restriction must not prevent a user from viewing their profile,
    receiving notices, or using unrelated community features.
    """
    scope = str(scope or "").strip().lower()
    if scope not in FEATURE_RESTRICTION_SCOPES:
        return False
    now = utc_now_naive()
    found = (await session.execute(select(UserModerationRecord.id).where(
        UserModerationRecord.target_telegram_id == int(telegram_id),
        UserModerationRecord.action == "restriction",
        UserModerationRecord.scope == scope,
        UserModerationRecord.active.is_(True),
        or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
    ).limit(1))).scalar_one_or_none()
    return found is not None
