from __future__ import annotations

from html import escape
from pathlib import Path

from app.db.models import Event
from app.display_utils import has_end_time_label, volume_label, rtl_isolate, panel_detail_line
from app.services.events import display_status, registration_is_open
from app.services.pricing import panel_price_label
from app.bot.text_limits import limit_telegram_html


def format_manage_event_text(event: Event, used: int) -> str:
    """Consistent panel-management layout: title and description first, facts after."""
    status = display_status(event, used)
    # These are admin-facing workflow states: short, consistent English labels
    # are more scannable than raw enum values or a mixture of translations.
    status_labels = {
        "draft": "Draft",
        "published": "Published",
        "registration_open": "Published",
        "closed": "Published",
        "full": "Full",
        "completed": "Completed",
        "archived": "Archived",
        "cancelled": "Cancelled",
    }
    # Reserve enough room for the panel facts below even when the description
    # is unusually long. The overall limiter remains a final Telegram-safe guard.
    description = limit_telegram_html(escape(event.description or "توضیحی ثبت نشده است."), max_units=2000)
    lines = [
        f"<b>{volume_label(event.volume)} – {escape(event.title)}</b>",
        "_________________________",
        "📝 <b>توضیحات پنل</b>",
        description,
        "_________________________",
        "📋 <b>اطلاعات پنل</b>",
    ]
    if event.language:
        lines.append(panel_detail_line("زبان پنل", escape(event.language), icon="🌐"))
    lines.extend([
        panel_detail_line("وضعیت انتشار", status_labels.get(status.value, status.value.replace('_', ' ').title())),
        panel_detail_line("وضعیت ثبت‌نام", 'Open' if registration_is_open(event) else 'Closed'),
        panel_detail_line("روز و تاریخ", f"{escape(event.event_day_label)} – {escape(event.event_date_label)}", icon="📅"),
        panel_detail_line("ساعت", escape(event.start_time_label) + (f"–{escape(event.end_time_label)}" if has_end_time_label(event.end_time_label) else ""), icon="⏰"),
        panel_detail_line("مکان", escape(event.venue), icon="📍"),
        panel_detail_line("ظرفیت رزروشده", f"{used}/{event.capacity}", icon="👥"),
        panel_detail_line("هزینه", escape(panel_price_label(event.price_per_person, event.price_without_cafe_order)), icon="💰"),
    ])
    extra_lines = []
    if event.address:
        extra_lines.append(panel_detail_line("آدرس", escape(event.address), icon="📌"))
    if event.map_url:
        extra_lines.append(panel_detail_line("لینک موقعیت", escape(event.map_url), icon="🔗"))
    if event.host_name:
        extra_lines.append(panel_detail_line("میزبان", escape(event.host_name), icon="👤"))
    if event.questions_pdf_path:
        extra_lines.append(panel_detail_line("سؤالات", escape(event.questions_file_name or Path(event.questions_pdf_path).name), icon="📄"))
    if event.archived:
        extra_lines.append(rtl_isolate("📦 آرشیو شده است."))
    extra_lines.extend([
        panel_detail_line("حضور و غیاب", 'فعال' if getattr(event, 'attendance_enabled', False) else 'اختیاری / خاموش', icon="📋"),
        panel_detail_line("بازخورد پس از پنل", 'فعال' if getattr(event, 'feedback_enabled', False) else 'خاموش', icon="💬"),
    ])
    if extra_lines:
        lines.extend(["_________________________", "📌 <b>جزئیات تکمیلی</b>", *extra_lines])
    return limit_telegram_html("\n".join(lines))

