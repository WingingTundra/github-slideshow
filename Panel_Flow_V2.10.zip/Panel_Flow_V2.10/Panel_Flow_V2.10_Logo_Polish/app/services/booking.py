from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.display_utils import volume_label
from app.db.models import (
    Booking, DiscountCode, DiscountCodeEvent, DiscountRedemption, Event, Participant, Payment,
    RegistrationStatus, User, WaitlistEntry,
)
from app.services.events import ACTIVE_BOOKING_STATUSES, registration_is_open, seats_used
from app.services.confirmation_ledger import record_confirmed_booking
from app.services.discounts import ACTIVE_REDEMPTION_STATUSES, USER_USED_STATUSES, calculate_discount
from app.time_utils import utc_now_naive
from app.services.pricing import BASE_OPTION, calculate_price_components
from app.services.user_access import has_active_feature_restriction
from app.bot.validation import normalize_iranian_mobile, normalize_person_name


MAX_PARTICIPANTS_PER_BOOKING = 3
MAX_ACTIVE_SEATS_PER_USER_PER_PANEL = 3


def expire_booking_if_due(booking: Booking, *, now=None) -> bool:
    """Expire one pending-payment booking if its payment hold has elapsed.

    This shared transition is used both by the periodic sweep and by receipt
    submission, so a delayed background task cannot extend a reservation hold.
    """
    current_time = now or utc_now_naive()
    if (
        booking.status != RegistrationStatus.PENDING_PAYMENT
        or booking.expires_at is None
        or booking.expires_at >= current_time
    ):
        return False
    booking.status = RegistrationStatus.EXPIRED
    booking.cancelled_at = current_time
    return True


def booking_contact_phone(booking: Booking) -> str | None:
    """Return the contact number saved for this booking, including legacy fallback.

    Prior versions stored the number requested during booking on the first participant
    record. New bookings use Booking.contact_phone, separate from User.phone_number.
    """
    phone = getattr(booking, "contact_phone", None)
    if phone:
        return str(phone)
    participants = list(getattr(booking, "participants", []) or [])
    if participants and getattr(participants[0], "phone_number", None):
        return str(participants[0].phone_number)
    booker = getattr(booking, "booked_by", None)
    profile_phone = getattr(booker, "phone_number", None) if booker else None
    return str(profile_phone) if profile_phone else None


async def expire_old_bookings(
    session: AsyncSession,
    *,
    event_id: int | None = None,
    user_id: int | None = None,
) -> set[int]:
    """Mark expired payment holds and return the affected event IDs.

    Optional filters let user/admin views refresh the rows they are about to show
    without changing unrelated panels. Row locks serialize expiry against receipt
    submission and other booking-state changes.
    """
    now = utc_now_naive()
    stmt = select(Booking).where(
        Booking.expires_at.is_not(None),
        Booking.expires_at < now,
        Booking.status == RegistrationStatus.PENDING_PAYMENT,
    )
    if event_id is not None:
        stmt = stmt.where(Booking.event_id == event_id)
    if user_id is not None:
        stmt = stmt.where(Booking.booked_by_user_id == user_id)
    result = await session.execute(stmt.with_for_update())
    affected_event_ids: set[int] = set()
    for booking in result.scalars().all():
        if expire_booking_if_due(booking, now=now):
            affected_event_ids.add(int(booking.event_id))
    return affected_event_ids


async def _load_event_locked(session: AsyncSession, event_id: int) -> Event | None:
    # Keep the established get(..., with_for_update=True) path and then force a
    # refreshed locking SELECT so an event already present in the identity map
    # cannot cause the service to skip the database row lock.
    event = await session.get(Event, event_id, with_for_update=True)
    if event is None:
        return None
    result = await session.execute(
        select(Event).where(Event.id == event_id).with_for_update().execution_options(populate_existing=True)
    )
    return result.scalar_one_or_none()


async def _active_booking_for_owner(session: AsyncSession, event_id: int, user_id: int) -> Booking | None:
    result = await session.execute(
        select(Booking).where(
            Booking.event_id == event_id,
            Booking.booked_by_user_id == user_id,
            Booking.status.in_(ACTIVE_BOOKING_STATUSES),
        ).order_by(Booking.created_at.desc())
    )
    return result.scalars().first()


async def active_seats_for_owner(session: AsyncSession, event_id: int, user_id: int) -> int:
    result = await session.execute(
        select(func.coalesce(func.sum(Booking.participant_count), 0)).where(
            Booking.event_id == event_id,
            Booking.booked_by_user_id == user_id,
            Booking.status.in_(ACTIVE_BOOKING_STATUSES),
        )
    )
    return int(result.scalar_one())


async def create_booking(
    session: AsyncSession,
    user_id: int,
    event_id: int,
    participants: list[dict[str, str] | str],
    *,
    allow_duplicate: bool = False,
    contact_phone: str | None = None,
    discount_code_id: int | None = None,
    discount_redemption_id: int | None = None,
    cancel_discount_redemption_id: int | None = None,
    pricing_option: str | None = None,
    expected_base_price=None,
    expected_alternative_price=None,
    payment_details_configured: bool = True,
    client_request_id: str | None = None,
) -> Booking:
    telegram_id = (await session.execute(select(User.telegram_id).where(User.id == int(user_id)))).scalar_one_or_none()
    if telegram_id is not None and await has_active_feature_restriction(session, int(telegram_id), "booking"):
        raise ValueError("USER_BOOKING_RESTRICTED")

    if not participants:
        raise ValueError("NO_PARTICIPANTS")
    if len(participants) > MAX_PARTICIPANTS_PER_BOOKING:
        raise ValueError("MAX_PARTICIPANTS_PER_BOOKING")

    normalized_contact_phone = None
    if contact_phone:
        normalized_contact_phone = normalize_iranian_mobile(contact_phone)
        if normalized_contact_phone is None:
            raise ValueError("INVALID_BOOKER_PHONE")

    await expire_old_bookings(session)
    event = await _load_event_locked(session, event_id)
    if not event:
        raise ValueError("EVENT_NOT_OPEN")
    request_key = (str(client_request_id).strip() if client_request_id else None)
    if request_key:
        if len(request_key) > 64:
            raise ValueError("INVALID_IDEMPOTENCY_KEY")
        prior = (await session.execute(select(Booking).where(
            Booking.event_id == int(event_id),
            Booking.booked_by_user_id == int(user_id),
            Booking.client_request_id == request_key,
        ).with_for_update())).scalar_one_or_none()
        if prior is not None:
            return prior
    if not registration_is_open(event):
        raise ValueError("EVENT_NOT_OPEN")
    if expected_base_price is not None and Decimal(str(event.price_per_person)) != Decimal(str(expected_base_price)):
        raise ValueError("PRICE_CHANGED")
    current_alternative = getattr(event, "price_without_cafe_order", None)
    if expected_alternative_price is not None:
        expected_alt = Decimal(str(expected_alternative_price)) if expected_alternative_price not in (None, "") else None
        current_alt = Decimal(str(current_alternative)) if current_alternative is not None else None
        if expected_alt != current_alt:
            raise ValueError("PRICE_CHANGED")
    now = utc_now_naive()
    count = len(participants)

    if not allow_duplicate and await _active_booking_for_owner(session, event_id, user_id):
        raise ValueError("DUPLICATE")
    if count > event.capacity:
        raise ValueError("TOO_MANY")
    user_seats = await active_seats_for_owner(session, event_id, user_id)
    if user_seats + count > MAX_ACTIVE_SEATS_PER_USER_PER_PANEL:
        raise ValueError("USER_SEAT_LIMIT")
    used = await seats_used(session, event_id)
    if used + count > event.capacity:
        raise ValueError("FULL")

    # Free panels bypass discount codes entirely; the whole panel is free by product rule.
    if Decimal(event.price_per_person) == 0:
        discount_code_id = None
        discount_redemption_id = None
        # Keep cancel_discount_redemption_id intact: if the participant is
        # proceeding without a previously approved restricted code, that old
        # request must still be withdrawn atomically with this free booking.
    price_components = calculate_price_components(
        event.price_per_person,
        getattr(event, "price_without_cafe_order", None),
        pricing_option or BASE_OPTION,
        count,
    )
    original_total = price_components.gross_total
    discountable_total = price_components.discountable_base_total
    discount_amount = Decimal(0)
    discount_code: DiscountCode | None = None
    redemption: DiscountRedemption | None = None
    owner = await session.get(User, user_id)
    withdrawal_redemption: DiscountRedemption | None = None
    if cancel_discount_redemption_id is not None:
        # A participant may replace an already-approved restricted discount
        # with a different eligible code during pre-confirmation editing. Keep
        # the old redemption and the new booking in one transaction so the old
        # quota is released only if the replacement booking succeeds. Never
        # redeem and withdraw the same request in a single booking.
        if (
            discount_redemption_id is not None
            and int(discount_redemption_id) == int(cancel_discount_redemption_id)
        ):
            raise ValueError("DISCOUNT_REQUEST_NOT_APPROVED")
        withdrawal_redemption = (await session.execute(
            select(DiscountRedemption).where(
                DiscountRedemption.id == cancel_discount_redemption_id
            ).with_for_update().execution_options(populate_existing=True)
        )).scalar_one_or_none()
        if (
            not withdrawal_redemption or owner is None
            or withdrawal_redemption.user_telegram_id != owner.telegram_id
            or withdrawal_redemption.event_id != event_id
            or withdrawal_redemption.status not in ("pending", "approved", "rejected")
        ):
            raise ValueError("DISCOUNT_REQUEST_NOT_APPROVED")

    if discount_code_id is not None:
        # Serializing on the code row ensures a limited code cannot be oversubscribed
        # by concurrent callbacks. Re-check every eligibility condition at commit time.
        discount_code = (await session.execute(
            select(DiscountCode).where(DiscountCode.id == discount_code_id)
            .with_for_update().execution_options(populate_existing=True)
        )).scalar_one_or_none()
        if not discount_code or not discount_code.active:
            raise ValueError("CODE_INVALID")
        linked = (await session.execute(select(DiscountCodeEvent.id).where(
            DiscountCodeEvent.discount_code_id == discount_code.id,
            DiscountCodeEvent.event_id == event_id,
        ))).scalar_one_or_none()
        if linked is None:
            raise ValueError("CODE_INVALID")
        if owner is None:
            raise ValueError("USER_NOT_FOUND")

        if discount_redemption_id is not None:
            redemption = (await session.execute(
                select(DiscountRedemption).where(DiscountRedemption.id == discount_redemption_id)
                .with_for_update().execution_options(populate_existing=True)
            )).scalar_one_or_none()
            if (
                not redemption
                or redemption.status != "approved"
                or redemption.discount_code_id != discount_code.id
                or redemption.event_id != event_id
                or redemption.user_telegram_id != owner.telegram_id
            ):
                raise ValueError("DISCOUNT_REQUEST_NOT_APPROVED")
        elif discount_code.kind == "restricted" or discount_code.requires_approval:
            raise ValueError("CODE_NEEDS_APPROVAL")

        if discount_code.kind == "personal":
            if (
                discount_code.recipient_telegram_id != owner.telegram_id
                or discount_code.accepted_at is None
            ):
                raise ValueError("PERSONAL_REWARD_NOT_ACCEPTED")
            discount_scope = "single"
        elif discount_code.kind == "public" and not discount_code.requires_approval:
            if discount_redemption_id is not None:
                raise ValueError("DISCOUNT_REQUEST_NOT_APPROVED")
            discount_scope = "total"
        elif discount_code.kind == "restricted" and discount_redemption_id is not None:
            discount_scope = "single"
        else:
            raise ValueError("CODE_INVALID")

        # A code's configured global limit counts pending approvals as reserved code
        # uses, but none of those requests reserve a seat. Ignore the current approved
        # request while converting it into the actual redemption.
        limit_query = select(func.count(DiscountRedemption.id)).where(
            DiscountRedemption.discount_code_id == discount_code.id,
            DiscountRedemption.status.in_(ACTIVE_REDEMPTION_STATUSES),
        )
        if redemption is not None:
            limit_query = limit_query.where(DiscountRedemption.id != redemption.id)
        current_uses = int((await session.execute(limit_query)).scalar_one())
        if discount_code.max_redemptions is not None and current_uses >= discount_code.max_redemptions:
            raise ValueError("CODE_UNAVAILABLE")

        used_query = select(DiscountRedemption.id).where(
            DiscountRedemption.discount_code_id == discount_code.id,
            DiscountRedemption.user_telegram_id == owner.telegram_id,
            DiscountRedemption.status.in_(USER_USED_STATUSES),
        )
        if redemption is not None:
            used_query = used_query.where(DiscountRedemption.id != redemption.id)
        if discount_code.usage_policy == "once_per_panel":
            used_query = used_query.where(DiscountRedemption.event_id == event_id)
        if (await session.execute(used_query.limit(1))).scalar_one_or_none() is not None:
            raise ValueError("CODE_ALREADY_USED")

        discount_amount = calculate_discount(
            discountable_total, Decimal(event.price_per_person), count,
            discount_code.discount_type, discount_code.discount_value,
            scope=discount_scope,
        )

    final_total = max(Decimal(0), original_total - discount_amount)
    # Fail before creating a booking/seat hold when a paid checkout cannot show
    # valid payment instructions. Zero-cost registrations remain available.
    if final_total > 0 and not payment_details_configured:
        raise ValueError("PAYMENT_CONFIGURATION_MISSING")
    immediate = final_total == 0
    booking = Booking(
        event_id=event_id,
        booked_by_user_id=user_id,
        client_request_id=request_key,
        participant_count=count,
        total_amount=final_total,
        contact_phone=normalized_contact_phone,
        registrant_attends=(not bool(allow_duplicate)),
        status=RegistrationStatus.CONFIRMED if immediate else RegistrationStatus.PENDING_PAYMENT,
        expires_at=None if immediate else now + timedelta(minutes=settings.reservation_timeout_minutes),
        confirmed_at=now if immediate else None,
        discount_code_id=discount_code.id if discount_code else None,
        discount_code_snapshot=(discount_code.code or discount_code.label) if discount_code else None,
        discount_code_kind_snapshot=discount_code.kind if discount_code else None,
        discount_amount=discount_amount,
        pricing_option=price_components.option,
        base_price_snapshot=price_components.base_price_snapshot,
        alternative_price_snapshot=price_components.alternative_price_snapshot,
    )

    normalized: list[Participant] = []
    for index, item in enumerate(participants):
        if isinstance(item, str):
            bits = item.split(maxsplit=1)
            first = bits[0] if bits else ""
            last = bits[1] if len(bits) == 2 else ""
            phone = ""
        else:
            first = str(item.get("first_name", "")).strip()
            last = str(item.get("last_name", "")).strip()
            phone = str(item.get("phone_number", "")).strip()
        first = normalize_person_name(first, min_length=1, max_length=100) or ""
        last = normalize_person_name(last, min_length=1, max_length=100) or ""
        if not first or not last:
            raise ValueError("PARTICIPANT_NAME_REQUIRED")
        if phone:
            phone = normalize_iranian_mobile(phone) or ""
            if not phone:
                raise ValueError("INVALID_PARTICIPANT_PHONE")
        # Initial booking attendee #1 reuses the account holder's saved profile;
        # additional bookings are guest-only and must not award the booker attendance.
        attendee_telegram_id = int(owner.telegram_id) if index == 0 and not allow_duplicate and owner else None
        normalized.append(Participant(
            first_name=first, last_name=last, full_name=f"{first} {last}",
            phone_number=phone or None, user_telegram_id=attendee_telegram_id,
        ))

    booking.participants = normalized
    session.add(booking)
    flush = getattr(session, "flush", None)
    if flush is not None:
        await flush()
    if immediate:
        await record_confirmed_booking(session, booking, confirmed_at=now)

    if discount_code is not None:
        if redemption is None:
            redemption = DiscountRedemption(
                discount_code_id=discount_code.id,
                code_snapshot=discount_code.code or discount_code.label or "هدیه شخصی",
                event_id=event.id,
                event_label_snapshot=f"{volume_label(event.volume)} — {event.title}",
                user_telegram_id=int(owner.telegram_id),
                status="redeemed",
                participant_count=count,
                booking_id=booking.id,
                original_total=original_total,
                discount_amount=discount_amount,
                final_total=final_total,
                redeemed_at=now,
                created_at=now,
                updated_at=now,
            )
            session.add(redemption)
        else:
            redemption.status = "redeemed"
            redemption.booking_id = booking.id
            redemption.original_total = original_total
            redemption.discount_amount = discount_amount
            redemption.final_total = final_total
            redemption.redeemed_at = now
            redemption.draft_json = None
            redemption.contact_phone = None
            redemption.updated_at = now
        redemption.participant_count = count
        # Personal rewards are one-use and are consumed by this reservation.
        if discount_code.kind == "personal":
            discount_code.active = False
            discount_code.disabled_at = now
            discount_code.disabled_reason = "Personal reward redeemed"

    await session.execute(
        update(WaitlistEntry)
        .where(
            WaitlistEntry.event_id == event_id,
            WaitlistEntry.user_id == user_id,
            WaitlistEntry.status.in_(["waiting", "invited", "inviting"]),
        )
        .values(status="registered", invitation_expires_at=None, next_invite_after=None)
    )

    if withdrawal_redemption is not None:
        # Withdraw the superseded request only together with a successfully
        # created replacement booking (with or without a different discount).
        # If validation or seat allocation fails, the original remains recoverable.
        withdrawal_redemption.status = "withdrawn"
        withdrawal_redemption.draft_json = None
        withdrawal_redemption.contact_phone = None
        withdrawal_redemption.updated_at = now

    if used + count >= event.capacity:
        event.registration_open = False
        event.registration_closed_reason = "capacity"

    await session.commit()
    return booking


async def retry_payment(session: AsyncSession, user_id: int, booking_id: int) -> Booking:
    await expire_old_bookings(session)
    booking = await session.get(Booking, booking_id, with_for_update=True)
    if not booking or booking.booked_by_user_id != user_id:
        raise ValueError("NOT_FOUND")
    if booking.status != RegistrationStatus.REJECTED:
        raise ValueError("NOT_RETRYABLE")

    event = await _load_event_locked(session, booking.event_id)
    if not event or not registration_is_open(event):
        raise ValueError("EVENT_NOT_OPEN")
    now = utc_now_naive()

    used = await seats_used(session, event.id)
    # The rejected booking itself is not in ACTIVE_BOOKING_STATUSES, so its seats are free.
    if used + booking.participant_count > event.capacity:
        raise ValueError("FULL")
    if booking.participant_count > MAX_PARTICIPANTS_PER_BOOKING:
        raise ValueError("MAX_PARTICIPANTS_PER_BOOKING")
    user_seats = await active_seats_for_owner(session, event.id, user_id)
    if user_seats + booking.participant_count > MAX_ACTIVE_SEATS_PER_USER_PER_PANEL:
        raise ValueError("USER_SEAT_LIMIT")

    payment = (
        await session.execute(select(Payment).where(Payment.booking_id == booking.id))
    ).scalar_one_or_none()
    if payment:
        payment.status = "pending"
        payment.receipt_file = None
        payment.receipt_file_name = None
        payment.receipt_text = None
        payment.receipt_uploaded_at = None
        payment.reviewed_at = None
        payment.reviewed_by = None
    else:
        session.add(Payment(booking_id=booking.id, amount=booking.total_amount, status="pending"))

    booking.status = RegistrationStatus.PENDING_PAYMENT
    booking.expires_at = now + timedelta(minutes=settings.reservation_timeout_minutes)
    booking.cancelled_at = None
    if used + booking.participant_count >= event.capacity:
        event.registration_open = False
        event.registration_closed_reason = "capacity"
    await session.commit()
    return booking


def user_can_cancel_booking(booking: Booking, payment: Payment | None, event: Event | None = None) -> bool:
    """Whether a participant may initiate self-cancellation from the UI.

    Pending/unverified/rejected reservations retain their existing cancellation
    policy. A confirmed reservation is self-cancellable only when it is genuinely
    zero-cost, has no unresolved financial case, and has no positive-amount payment
    record. The mutation service repeats these checks under database locks.
    """
    if booking.status in (
        RegistrationStatus.PENDING_PAYMENT,
        RegistrationStatus.PENDING_VERIFICATION,
        RegistrationStatus.REJECTED,
    ):
        return True
    if booking.status != RegistrationStatus.CONFIRMED:
        return False
    # A confirmed zero-cost booking may be self-cancelled only while its panel is
    # actively published. Keep list visibility and the mutation-service rule aligned.
    if event is None or getattr(event.status, "value", event.status) != "published" or bool(event.archived):
        return False
    if Decimal(str(booking.total_amount or 0)) != 0:
        return False
    if getattr(booking, "cancellation_resolution", "not_required") == "action_required":
        return False
    if payment is not None and Decimal(str(payment.amount or 0)) > 0:
        return False
    return True


async def cancel_booking(session: AsyncSession, user_id: int, booking_id: int) -> Booking:
    # Lock and refresh the current row so a stale identity-map instance cannot
    # allow cancellation to race a just-completed payment approval.
    result = await session.execute(
        select(Booking).where(Booking.id == booking_id).with_for_update().execution_options(populate_existing=True)
    )
    booking = result.scalar_one_or_none()
    if not booking or booking.booked_by_user_id != user_id:
        raise ValueError("NOT_FOUND")
    is_confirmed_free = (
        booking.status == RegistrationStatus.CONFIRMED
        and Decimal(str(booking.total_amount or 0)) == 0
        and getattr(booking, "cancellation_resolution", "not_required") != "action_required"
    )
    if booking.status == RegistrationStatus.CONFIRMED and not is_confirmed_free:
        raise ValueError("CONFIRMED_CANCELLATION_FORBIDDEN")
    if booking.status not in (
        RegistrationStatus.PENDING_PAYMENT,
        RegistrationStatus.PENDING_VERIFICATION,
        RegistrationStatus.REJECTED,
    ) and not is_confirmed_free:
        raise ValueError("NOT_CANCELLABLE")

    # Serialize against payment review using the same booking -> event -> payment
    # lock order. A zero booking paired with a positive payment row is inconsistent
    # financial data, so do not let self-service cancellation hide that discrepancy.
    event_result = await session.execute(
        select(Event).where(Event.id == booking.event_id).with_for_update().execution_options(populate_existing=True)
    )
    event = event_result.scalar_one_or_none()
    if event is None:
        raise ValueError("NOT_FOUND")
    if is_confirmed_free and (getattr(event.status, "value", event.status) != "published" or bool(event.archived)):
        raise ValueError("NOT_CANCELLABLE")
    if is_confirmed_free:
        payment = (await session.execute(
            select(Payment).where(Payment.booking_id == booking.id).with_for_update()
            .execution_options(populate_existing=True)
        )).scalar_one_or_none()
        if payment is not None and Decimal(str(payment.amount or 0)) > 0:
            raise ValueError("CONFIRMED_CANCELLATION_FORBIDDEN")
    booking.status = RegistrationStatus.CANCELLED
    booking.cancelled_at = utc_now_naive()
    booking.expires_at = None
    try:
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    return booking


async def admin_cancel_pending_payment(
    session: AsyncSession,
    booking_id: int,
    event_id: int,
    *,
    commit: bool = True,
) -> Booking:
    """Cancel exactly one still-pending unpaid booking under row locks.

    A receipt submission or another admin can change the state between the list
    and confirmation; rechecking the booking under lock avoids cancelling a
    reservation that has since moved to receipt review or confirmation.
    """
    result = await session.execute(
        select(Booking).where(Booking.id == booking_id).with_for_update().execution_options(populate_existing=True)
    )
    booking = result.scalar_one_or_none()
    if not booking or int(booking.event_id) != int(event_id):
        raise ValueError("NOT_FOUND")
    if booking.status != RegistrationStatus.PENDING_PAYMENT:
        raise ValueError("NOT_PENDING_PAYMENT")

    event_result = await session.execute(
        select(Event).where(Event.id == event_id).with_for_update().execution_options(populate_existing=True)
    )
    event = event_result.scalar_one_or_none()
    if not event:
        raise ValueError("NOT_FOUND")

    # A submission path locks the same booking first and changes its status to
    # PENDING_VERIFICATION; that state therefore cannot be silently cancelled.
    booking.status = RegistrationStatus.CANCELLED
    booking.cancelled_at = utc_now_naive()
    booking.expires_at = None
    if commit:
        try:
            await session.commit()
        except Exception:
            await session.rollback()
            raise
    return booking
