"""Small, framework-independent attendance proof validation helpers."""
from __future__ import annotations

import hashlib
import secrets
from datetime import datetime

from app.time_utils import utc_now_naive


def proof_digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def checkin_proof_is_valid(event, proof: str, proof_kind: str, *, now: datetime | None = None) -> bool:
    """Validate current event proof, expiry, and short callback nonce.

    New QR tokens are 96-bit bearer secrets; callback buttons carry a separate
    64-bit event nonce instead of copying the bearer secret into Telegram payloads.
    Legacy proofs remain accepted only until their migration expiry.
    """
    current = now or utc_now_naive()
    if proof_kind not in {"token", "code"}:
        return False
    expiry = (event.attendance_checkin_token_expires_at if proof_kind == "token"
              else event.attendance_checkin_code_expires_at)
    if expiry is None or expiry <= current:
        return False
    session_id = getattr(event, "attendance_checkin_session_id", None)
    if len(proof) == 16 and session_id:
        return secrets.compare_digest(session_id, proof)
    expected = (event.attendance_checkin_token_hash if proof_kind == "token"
                else event.attendance_checkin_code_hash)
    return bool(expected and secrets.compare_digest(expected, proof_digest(proof)))
