"""Admin-only Excel export for referral counts and individual referral attribution."""
from __future__ import annotations

from datetime import datetime
from io import BytesIO
from typing import Iterable, Mapping, Any

import xlsxwriter


def _text(value: Any) -> str:
    return "—" if value is None or value == "" else str(value)


def build_referral_report_xlsx(
    summary_rows: Iterable[Mapping[str, Any]],
    detail_rows: Iterable[Mapping[str, Any]],
) -> bytes:
    """Create a two-sheet workbook, writing all user-controlled fields as literal text."""
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output, {"in_memory": True})
    header = workbook.add_format({"bold": True, "bg_color": "#DCE6F1", "border": 1})
    integer = workbook.add_format({"num_format": "0"})
    date_fmt = workbook.add_format({"num_format": "yyyy-mm-dd hh:mm"})

    summary = workbook.add_worksheet("Referral Summary")
    summary_headers = ["Referrer Name", "Telegram ID / Referral Code", "Username", "Total Referrals"]
    for col, value in enumerate(summary_headers):
        summary.write_string(0, col, value, header)
    for row_idx, item in enumerate(summary_rows, start=1):
        summary.write_string(row_idx, 0, _text(item.get("name")))
        summary.write_string(row_idx, 1, _text(item.get("telegram_id")))
        summary.write_string(row_idx, 2, _text(item.get("username")))
        summary.write_number(row_idx, 3, int(item.get("referral_count") or 0), integer)
    summary.freeze_panes(1, 0)
    summary.autofilter(0, 0, max(1, row_idx if 'row_idx' in locals() else 0), len(summary_headers) - 1)
    summary.set_column(0, 0, 28)
    summary.set_column(1, 1, 25)
    summary.set_column(2, 2, 24)
    summary.set_column(3, 3, 18)

    details = workbook.add_worksheet("Referred Users")
    detail_headers = [
        "Referrer Name", "Referrer Telegram ID", "Referred User Name",
        "Referred Telegram ID", "Username", "Phone Number", "Signup Date",
        "Ever Confirmed Booking (lifetime)", "Lifetime Confirmed Bookings", "Currently Confirmed Bookings",
        "Distinct Confirmed Panels (currently recorded)", "Distinct Panels Attended", "Ever Attended a Panel",
    ]
    for col, value in enumerate(detail_headers):
        details.write_string(0, col, value, header)
    detail_count = 0
    for row_idx, item in enumerate(detail_rows, start=1):
        detail_count = row_idx
        for col, key in enumerate(("referrer_name", "referrer_telegram_id", "referred_name", "referred_telegram_id", "username", "phone_number")):
            details.write_string(row_idx, col, _text(item.get(key)))
        signed_up = item.get("created_at")
        if isinstance(signed_up, datetime):
            if signed_up.tzinfo is not None:
                signed_up = signed_up.replace(tzinfo=None)
            details.write_datetime(row_idx, 6, signed_up, date_fmt)
        else:
            details.write_string(row_idx, 6, _text(signed_up))
        details.write_string(row_idx, 7, _text(item.get("ever_confirmed_booking", "No")))
        details.write_number(row_idx, 8, int(item.get("lifetime_confirmed_bookings") or 0), integer)
        details.write_number(row_idx, 9, int(item.get("confirmed_bookings") or 0), integer)
        details.write_number(row_idx, 10, int(item.get("confirmed_panels") or 0), integer)
        details.write_number(row_idx, 11, int(item.get("panels_attended") or 0), integer)
        details.write_string(row_idx, 12, _text(item.get("ever_attended_panel", "No")))
    details.freeze_panes(1, 0)
    details.autofilter(0, 0, max(1, detail_count), len(detail_headers) - 1)
    details.set_column(0, 0, 28)
    details.set_column(1, 1, 24)
    details.set_column(2, 2, 28)
    details.set_column(3, 3, 24)
    details.set_column(4, 4, 24)
    details.set_column(5, 5, 20)
    details.set_column(6, 6, 22)
    details.set_column(7, 7, 22)
    details.set_column(8, 11, 25)
    details.set_column(12, 12, 22)
    workbook.close()
    return output.getvalue()
