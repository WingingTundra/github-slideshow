from __future__ import annotations

import logging

from sqlalchemy import or_, select

from app.config import settings
from app.db.models import ChannelAnnouncement, Event, EventStatus
from app.services.app_settings import get_channel_updates_config
from app.services.events import registration_is_open, seats_used
from app.services.seat_disclosure import should_disclose_remaining_seats
from app.time_utils import utc_now_naive
SessionLocal = None


def _session_factory():
    global SessionLocal
    if SessionLocal is None:
        from app.db.session import SessionLocal as factory
        SessionLocal = factory
    return SessionLocal()

logger = logging.getLogger(__name__)


def _fa_number(value: int) -> str:
    return str(value).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _channel_id_fallback() -> int | None:
    return settings.panel_flow_channel_id


async def _deep_link(bot, event_id: int, *, can_register: bool) -> str:
    """Link open panels straight into sign-up; closed/full panels to their details."""
    me = await bot.get_me()
    if not me.username:
        raise RuntimeError("BOT_USERNAME_UNAVAILABLE")
    payload = "event" if can_register else "panel"
    return f"https://t.me/{me.username}?start={payload}_{event_id}"


async def _review_deep_link(bot) -> str:
    """Open the existing review list, personalized to the current Telegram user."""
    me = await bot.get_me()
    if not me.username:
        raise RuntimeError("BOT_USERNAME_UNAVAILABLE")
    return f"https://t.me/{me.username}?start=reviews"


async def _keyboard(bot, event: Event, can_register: bool):
    label = f"ثبت‌نام در Volume {event.volume}" if can_register else f"مشاهده پنل Volume {event.volume}"
    url = await _deep_link(bot, event.id, can_register=can_register)
    archived_reviewable = bool(
        getattr(event, "archived", False)
        and event.status == EventStatus.COMPLETED
        and getattr(event, "feedback_enabled", False)
    )
    try:
        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
        if archived_reviewable:
            review_url = await _review_deep_link(bot)
            # Make review the primary post-archive action while retaining the
            # original panel-details link for people who want the panel info.
            return InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="💬 ثبت نظر", url=review_url)],
                [InlineKeyboardButton(text=label, url=url)],
            ])
        return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=label, url=url)]])
    except ImportError:
        # Keeps the service unit-testable without aiogram installed; production
        # uses aiogram's native markup.
        class _Button:
            def __init__(self, text, url):
                self.text, self.url = text, url
        class _Markup:
            def __init__(self, inline_keyboard):
                self.inline_keyboard = inline_keyboard
        if archived_reviewable:
            review_url = await _review_deep_link(bot)
            return _Markup([
                [_Button("💬 ثبت نظر", review_url)],
                [_Button(label, url)],
            ])
        return _Markup([[_Button(label, url)]])


def _status_text(event: Event, remaining: int, *, capacity_increase_by: int = 0) -> str:
    """Render public channel/group status without exposing early signup counts."""
    capacity = max(0, int(event.capacity or 0))
    available = max(0, int(remaining or 0))
    low_availability = should_disclose_remaining_seats(capacity, available)
    if event.archived:
        if event.status == EventStatus.COMPLETED and getattr(event, "feedback_enabled", False):
            return (
                "📦 این پنل برگزار شده و به آرشیو منتقل شده است.\n\n"
                "💬 اگر برای این پنل ثبت‌نام کرده‌اید، خوشحال می‌شویم نظرتان را با ما به اشتراک بگذارید."
            )
        return "📦 این پنل برگزار شده و به آرشیو منتقل شده است."
    if event.status == EventStatus.CANCELLED:
        return "🔴 این پنل لغو شد."
    if event.status == EventStatus.COMPLETED:
        return "✅ این پنل برگزار شده است."

    if capacity_increase_by > 0:
        increase = _fa_number(capacity_increase_by)
        total = _fa_number(capacity)
        if not registration_is_open(event):
            return f"🎉 ظرفیت پنل {increase} نفر افزایش یافت. ظرفیت کل اکنون {total} نفر است؛ ثبت‌نام همچنان بسته است."
        if available <= 0:
            return f"🎉 ظرفیت پنل {increase} نفر افزایش یافت؛ ظرفیت این پنل اکنون تکمیل شده است."
        if low_availability:
            return f"🎉 ظرفیت پنل {increase} نفر افزایش یافت. اکنون فقط {_fa_number(available)} صندلی باقی مانده است."
        return f"🎉 ظرفیت پنل {increase} نفر افزایش یافت. ظرفیت کل اکنون {total} نفر است."

    if available <= 0:
        return "🔴 ظرفیت این پنل تکمیل شد."
    if not registration_is_open(event):
        return "🔴 ثبت‌نام این پنل بسته شد."
    if low_availability:
        return f"🔔 فقط {_fa_number(available)} صندلی باقی مانده است."
    return f"🟢 ثبت‌نام این پنل باز است. ظرفیت کل: {_fa_number(capacity)} نفر."


async def reconcile_event_channel_status(bot, event_id: int) -> bool:
    """Synchronize one event's single persisted status message with DB state.

    PostgreSQL event-row locking serializes concurrent reconciliations for the same
    panel. Telegram failures are deliberately not persisted as success.
    """
    async with _session_factory() as session:
        event = await session.get(Event, event_id, with_for_update=True)
        if not event:
            return False
        enabled, threshold = await get_channel_updates_config(session)
        row = (await session.execute(
            select(ChannelAnnouncement).where(ChannelAnnouncement.event_id == event_id).with_for_update()
        )).scalar_one_or_none()

        # Once a status message exists, keep maintaining it while updates are ON.
        # Before initialization, only published/non-archived panels can initialize,
        # and only after the configured seat threshold has been reached.
        # `threshold` is only the trigger for creating the first status post.
        # Always calculate the displayed remaining count from current capacity
        # and authoritative active booking rows; never reuse `last_remaining`.
        reserved = await seats_used(session, event_id)
        remaining = max(0, int(event.capacity) - reserved)
        if not enabled:
            return False
        if row is None:
            if event.status != EventStatus.PUBLISHED or event.archived or remaining > threshold:
                return False
            channel_id = _channel_id_fallback()
            if channel_id is None:
                logger.warning("Channel updates enabled but PANEL_FLOW_CHANNEL_ID is not configured for event %s", event_id)
                return False
            row = ChannelAnnouncement(
                event_id=event.id,
                channel_id=channel_id,
                poster_message_id=None,
                status_message_id=None,
                initialized=False,
                last_capacity=int(event.capacity),
                last_remaining=remaining,
            )
            session.add(row)
            await session.flush()

        # A persisted poster association is not itself a status-message trigger.
        # The first automatic status message may only be created once the current
        # database remaining-seat count is at or below the configured threshold.
        if row.status_message_id is None and (
            event.status != EventStatus.PUBLISHED
            or event.archived
            or remaining > threshold
        ):
            return False

        channel_id = int(row.channel_id or _channel_id_fallback() or 0)
        if not channel_id:
            logger.warning("No channel configured for event %s", event_id)
            return False

        capacity_increase_by = 0
        if row.status_message_id is not None and row.last_capacity is not None and int(event.capacity) > int(row.last_capacity):
            capacity_increase_by = int(event.capacity) - int(row.last_capacity)

        can_register = registration_is_open(event) and remaining > 0
        text = _status_text(event, remaining, capacity_increase_by=capacity_increase_by)
        markup = await _keyboard(bot, event, can_register)

        try:
            if row.status_message_id:
                try:
                    await bot.edit_message_text(
                        chat_id=channel_id,
                        message_id=int(row.status_message_id),
                        text=text,
                        reply_markup=markup,
                        disable_web_page_preview=True,
                    )
                except Exception as exc:
                    # Telegram responds with this BadRequest when periodic
                    # reconciliation finds the message already has the desired
                    # text and keyboard. Treat it as a successful no-op, but
                    # continue retrying every other Telegram failure normally.
                    if "message is not modified" not in str(exc).lower():
                        raise
            else:
                try:
                    from aiogram.types import ReplyParameters
                except ImportError:
                    class ReplyParameters:
                        def __init__(self, message_id, allow_sending_without_reply=True):
                            self.message_id = message_id
                            self.allow_sending_without_reply = allow_sending_without_reply
                reply_parameters = None
                if row.poster_message_id:
                    reply_parameters = ReplyParameters(message_id=int(row.poster_message_id), allow_sending_without_reply=True)
                try:
                    sent = await bot.send_message(
                        chat_id=channel_id,
                        text=text,
                        reply_markup=markup,
                        disable_web_page_preview=True,
                        reply_parameters=reply_parameters,
                    )
                except Exception:
                    # The poster may have been deleted or reply metadata may be unusable;
                    # a standalone status post is still preferable to losing the update.
                    if reply_parameters is None:
                        raise
                    sent = await bot.send_message(
                        chat_id=channel_id,
                        text=text,
                        reply_markup=markup,
                        disable_web_page_preview=True,
                    )
                row.status_message_id = int(sent.message_id)
                row.initialized = True
        except Exception:
            logger.exception("Failed to reconcile channel status for event %s", event_id)
            await session.rollback()
            return False

        row.initialized = bool(row.status_message_id)
        row.last_capacity = int(event.capacity)
        row.last_remaining = remaining
        await session.commit()
        return True


async def validate_post_destination(bot, chat_id: int, destination_type: str) -> str:
    """Validate a channel/group identity and bot permissions before changing storage."""
    try:
        chat = await bot.get_chat(int(chat_id))
        chat_type = str(getattr(getattr(chat, "type", None), "value", getattr(chat, "type", ""))).lower()
        me = await bot.get_me()
        member = await bot.get_chat_member(int(chat_id), int(me.id))
    except Exception as exc:
        raise ValueError("TARGET_CHAT_INACCESSIBLE") from exc
    member_status = str(getattr(getattr(member, "status", None), "value", getattr(member, "status", ""))).lower()
    if destination_type == "channel":
        if chat_type != "channel":
            raise ValueError("TARGET_NOT_CHANNEL")
        if member_status != "administrator":
            raise ValueError("BOT_NEEDS_CHANNEL_ADMIN")
        can_post = getattr(member, "can_post_messages", True)
        if can_post is False:
            raise ValueError("BOT_CANNOT_POST_TO_CHANNEL")
    elif destination_type == "group":
        if chat_type not in {"group", "supergroup"}:
            raise ValueError("TARGET_NOT_GROUP")
        if member_status in {"left", "kicked", "banned"}:
            raise ValueError("BOT_NOT_IN_GROUP")
        can_send = getattr(member, "can_send_messages", True)
        if member_status == "restricted" and can_send is False:
            raise ValueError("BOT_CANNOT_SEND_TO_GROUP")
    else:
        raise ValueError("UNSUPPORTED_DESTINATION")
    return str(getattr(chat, "title", None) or getattr(chat, "username", None) or int(chat_id))


async def connect_event_post(
    bot, event_id: int, chat_id: int, poster_message_id: int, destination_type: str,
    *, actor_telegram_id: int | None = None,
) -> dict:
    """Create a fresh status reply then atomically switch the panel's stored target.

    The old link remains untouched unless the target permissions and Telegram send
    both succeed. Cleanup of an old status message is best-effort after commit.
    """
    if int(poster_message_id) <= 0 or int(chat_id) == 0:
        raise ValueError("INVALID_POST_REFERENCE")
    chat_title = await validate_post_destination(bot, int(chat_id), destination_type)
    sent = None
    old_chat_id = old_status_message_id = None
    async with _session_factory() as session:
        event = await session.get(Event, int(event_id), with_for_update=True)
        if event is None:
            raise ValueError("EVENT_NOT_FOUND")
        row = (await session.execute(
            select(ChannelAnnouncement).where(ChannelAnnouncement.event_id == int(event_id)).with_for_update()
        )).scalar_one_or_none()
        if row is not None:
            old_chat_id = int(row.channel_id)
            old_status_message_id = int(row.status_message_id) if row.status_message_id else None
        enabled, _threshold = await get_channel_updates_config(session)
        reserved = await seats_used(session, int(event_id))
        remaining = max(0, int(event.capacity) - reserved)
        markup = await _keyboard(bot, event, registration_is_open(event) and remaining > 0)
        text = _status_text(event, remaining)
        try:
            try:
                from aiogram.types import ReplyParameters
            except ImportError:
                class ReplyParameters:
                    def __init__(self, message_id, allow_sending_without_reply=False):
                        self.message_id = message_id
                        self.allow_sending_without_reply = allow_sending_without_reply
            sent = await bot.send_message(
                chat_id=int(chat_id), text=text, reply_markup=markup,
                disable_web_page_preview=True,
                reply_parameters=ReplyParameters(message_id=int(poster_message_id), allow_sending_without_reply=False),
            )
        except Exception as exc:
            await session.rollback()
            raise ValueError("TARGET_POST_REPLY_FAILED") from exc

        if row is None:
            row = ChannelAnnouncement(event_id=int(event_id), channel_id=int(chat_id))
            session.add(row)
        row.channel_id = int(chat_id)
        row.destination_type = destination_type
        row.poster_message_id = int(poster_message_id)
        row.status_message_id = int(sent.message_id)
        row.initialized = True
        row.last_capacity = int(event.capacity)
        row.last_remaining = remaining
        row.updated_at = utc_now_naive()
        try:
            if actor_telegram_id is not None:
                from app.services.admin_audit import write_admin_action
                await write_admin_action(
                    session, actor_telegram_id=int(actor_telegram_id), action="panel_post_linked",
                    entity_type="event", entity_id=int(event_id),
                    details={
                        "destination_type": str(destination_type), "target_chat_id": int(chat_id),
                        "poster_message_id": int(poster_message_id), "status_message_id": int(sent.message_id),
                        "replaced_existing_link": old_status_message_id is not None,
                    },
                )
            await session.commit()
        except Exception:
            await session.rollback()
            try:
                await bot.delete_message(chat_id=int(chat_id), message_id=int(sent.message_id))
            except Exception:
                logger.warning("Failed to clean up an uncommitted status message for event_id=%s", event_id)
            raise
    cleanup_succeeded = True
    if old_chat_id is not None and old_status_message_id is not None:
        try:
            await bot.delete_message(chat_id=old_chat_id, message_id=old_status_message_id)
        except Exception:
            cleanup_succeeded = False
            logger.warning(
                "Could not delete replaced status message for event_id=%s old_chat_id=%s old_message_id=%s",
                event_id, old_chat_id, old_status_message_id,
            )
    return {"chat_title": chat_title, "status_message_id": int(sent.message_id), "old_cleanup_succeeded": cleanup_succeeded}


async def reconcile_all_channel_statuses(bot) -> None:
    async with _session_factory() as session:
        enabled, _ = await get_channel_updates_config(session)
        if not enabled:
            return
        event_ids = list((await session.execute(
            select(Event.id)
            .where(or_(
                Event.status.in_([EventStatus.PUBLISHED, EventStatus.CANCELLED, EventStatus.COMPLETED]),
                Event.archived.is_(True),
            ))
            .order_by(Event.id.asc())
        )).scalars())
    for event_id in event_ids:
        await reconcile_event_channel_status(bot, int(event_id))


async def periodic_channel_reconciliation(bot: Bot, interval_seconds: int = 60) -> None:
    import asyncio

    while True:
        try:
            await reconcile_all_channel_statuses(bot)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic channel reconciliation failed")
        await asyncio.sleep(interval_seconds)
