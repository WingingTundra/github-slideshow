"""Canonical, uncached server-side authorization for Telegram actors.

Configured owners remain protected even if legacy database records are stale. Database
assigned Admins are re-read on every check and must not be blocked or actively suspended.
No role or restriction cache is used, so revocation takes effect immediately.
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import or_, select

from app.config import settings
from app.db.models import BlockedUser, User, UserModerationRecord, UserRole
from app.db.session import SessionLocal
from app.time_utils import utc_now_naive


async def is_admin_telegram_id(telegram_id: int) -> bool:
    tg_id = int(telegram_id)
    if tg_id <= 0:
        return False
    # The environment allow-list defines protected owners and takes precedence over
    # stale DB restriction rows, by design.
    if tg_id in settings.super_admin_id_set:
        return True
    now = utc_now_naive()
    blocked = select(BlockedUser.telegram_id).where(BlockedUser.telegram_id == tg_id).exists()
    suspended = select(UserModerationRecord.id).where(
        UserModerationRecord.target_telegram_id == tg_id,
        UserModerationRecord.action == "suspension",
        UserModerationRecord.scope == "account",
        UserModerationRecord.active.is_(True),
        or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
    ).exists()
    async with SessionLocal() as session:
        result = await session.scalar(select(User.id).where(
            User.telegram_id == tg_id,
            User.role == UserRole.SUPER_ADMIN,
            ~blocked,
            ~suspended,
        ).limit(1))
        return result is not None


async def is_host_telegram_id(telegram_id: int) -> bool:
    tg_id = int(telegram_id)
    if tg_id <= 0 or tg_id in settings.super_admin_id_set:
        return False
    now = utc_now_naive()
    blocked = select(BlockedUser.telegram_id).where(BlockedUser.telegram_id == tg_id).exists()
    suspended = select(UserModerationRecord.id).where(
        UserModerationRecord.target_telegram_id == tg_id,
        UserModerationRecord.action == "suspension",
        UserModerationRecord.scope == "account",
        UserModerationRecord.active.is_(True),
        or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
    ).exists()
    async with SessionLocal() as session:
        result = await session.scalar(select(User.id).where(
            User.telegram_id == tg_id,
            User.role == UserRole.HOST,
            ~blocked,
            ~suspended,
        ).limit(1))
        return result is not None


async def inspect_account_access(
    telegram_id: int, *, record_block_notice: bool = False,
) -> tuple[bool, bool]:
    """Return ``(restricted, should_send_block_notice)`` using the one access policy.

    Owner allow-list entries retain the established protected-owner bypass. For an
    explicitly blocked account, the optional notice write is committed atomically so
    repeated messages cannot cause a reply storm. Account suspension is enforced even
    if there is no separate BlockedUser row.
    """
    tg_id = int(telegram_id)
    if tg_id <= 0 or tg_id in settings.super_admin_id_set:
        return False, False
    now = utc_now_naive()
    should_send_notice = False
    async with SessionLocal() as session:
        blocked_record = await session.get(BlockedUser, tg_id)
        active_suspension = await session.scalar(select(UserModerationRecord.id).where(
            UserModerationRecord.target_telegram_id == tg_id,
            UserModerationRecord.action == "suspension",
            UserModerationRecord.scope == "account",
            UserModerationRecord.active.is_(True),
            or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
        ).limit(1))
        restricted = blocked_record is not None or active_suspension is not None
        if blocked_record is not None and record_block_notice:
            last_notice = blocked_record.last_notice_at
            if last_notice is None or last_notice <= now - timedelta(hours=24):
                blocked_record.last_notice_at = now
                await session.commit()
                should_send_notice = True
        return restricted, should_send_notice


async def active_account_restriction(telegram_id: int) -> bool:
    """Return whether a non-owner actor is currently blocked/suspended."""
    restricted, _ = await inspect_account_access(telegram_id)
    return restricted
