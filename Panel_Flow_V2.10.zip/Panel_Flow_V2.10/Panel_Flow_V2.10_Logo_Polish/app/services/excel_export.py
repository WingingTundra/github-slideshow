from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from io import BytesIO
from typing import Iterable

import xlsxwriter

from app.display_utils import has_end_time_label, volume_label
from app.services.booking import booking_contact_phone
from app.services.events import ACTIVE_BOOKING_STATUSES


STATUS_LABELS = {
    "initiated": "In progress",
    "pending_payment": "Awaiting payment",
    "pending_verification": "Awaiting receipt review",
    "confirmed": "Confirmed",
    "rejected": "Receipt rejected",
    "cancelled": "Cancelled",
    "expired": "Payment window expired",
    "waitlisted": "Waitlisted",
}
PAYMENT_LABELS = {
    "pending": "Pending",
    "approved": "Approved",
    "rejected": "Receipt rejected",
    "not_required": "Not required",
}
ATTENDANCE_LABELS = {
    "unmarked": "Not marked",
    "attended": "Attended",
    "no_show": "No-show",
}


def _value(value) -> str | None:
    if value is None:
        return None
    return str(getattr(value, "value", value))


def _label(value, labels: dict[str, str], fallback: str = "—") -> str:
    raw = _value(value)
    if not raw:
        return fallback
    return labels.get(raw, raw.replace("_", " ").title())


def _booker_name(booker) -> str:
    if booker is None:
        return "—"
    return (
        getattr(booker, "display_name", None)
        or " ".join(x for x in [getattr(booker, "first_name", None), getattr(booker, "last_name", None)] if x)
        or str(getattr(booker, "telegram_id", "—"))
    )


def _telegram_username(booker) -> str | None:
    username = getattr(booker, "telegram_username", None) if booker else None
    return str(username).lstrip("@") if username else None


def _booking_contact_phone(booking) -> str:
    return booking_contact_phone(booking) or "—"


def _created_at(value) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    # The application stores naive timestamps as UTC.
    return value


def _booking_status(booking) -> str:
    return _value(getattr(booking, "status", None)) or "unknown"


def _payment_status(booking) -> str:
    payment = getattr(booking, "payment", None)
    if payment is None:
        return "not_required"
    return _value(getattr(payment, "status", None)) or "unknown"


def _spread_amount(total: int, count: int) -> list[int]:
    """Split a reservation amount into integer-toman shares without losing remainders."""
    count = max(1, int(count))
    total = max(0, int(total))
    quotient, remainder = divmod(total, count)
    return [quotient + (1 if index < remainder else 0) for index in range(count)]


def _participant_amount_shares(booking, participant_count: int, discount_code_kinds: dict[int, str] | None = None) -> list[int]:
    """Return each attendee's final price share, preserving the booking total.

    General public codes discount the reservation total, so their final total is
    shared across attendees. Restricted codes and personal rewards discount the
    booker (participant 1) only. For old records without a saved scope, use an
    even allocation unless the linked code row still provides its type.
    """
    count = max(1, int(participant_count))
    final_total = max(0, int(getattr(booking, "total_amount", 0) or 0))
    discount = max(0, int(getattr(booking, "discount_amount", 0) or 0))
    kind = getattr(booking, "discount_code_kind_snapshot", None)
    if not kind and discount_code_kinds:
        code_id = getattr(booking, "discount_code_id", None)
        if code_id is not None:
            kind = discount_code_kinds.get(int(code_id))
    if kind in {"restricted", "personal"} and discount > 0:
        original_shares = _spread_amount(final_total + discount, count)
        # The single-person discount belongs to the account holder, who is now
        # always the first participant in a booking. Valid service-created rows
        # cap the discount to that person's price; preserve totals defensively.
        if discount <= original_shares[0]:
            original_shares[0] -= discount
            return original_shares
    return _spread_amount(final_total, count)


def _write_text(sheet, row: int, col: int, value, fmt=None) -> None:
    """Write text literally so user-controlled names/titles are never interpreted as formulas."""
    text = "—" if value is None or value == "" else str(value)
    sheet.write_string(row, col, text, fmt)


def _write_username(sheet, row: int, col: int, booker, text_fmt, link_fmt) -> None:
    username = _telegram_username(booker)
    if username:
        sheet.write_url(row, col, f"https://t.me/{username}", link_fmt, string=f"@{username}")
    else:
        _write_text(sheet, row, col, "—", text_fmt)


def build_attendee_workbook(
    event, bookings: Iterable, waitlist_entries: Iterable = (), *, discount_code_kinds: dict[int, str] | None = None
) -> bytes:
    """Create a workbook for all signups, confirmed attendees, booking history and waitlist.

    The Participants sheet has one row per person for every booking status (including
    cancelled/expired entries), with phone and Telegram identity from the reserver.
    The separate Confirmed Only sheet remains limited to currently confirmed bookings.
    The function intentionally performs no Telegram API requests, so export speed and
    success do not depend on profile-photo availability or external API latency.
    ``waitlist_entries`` accepts (WaitlistEntry, User | None) row pairs.
    """
    bookings = list(bookings)
    waitlist_entries = list(waitlist_entries)
    active_bookings = [b for b in bookings if _booking_status(b) in {_value(s) for s in ACTIVE_BOOKING_STATUSES}]
    confirmed_bookings = [b for b in bookings if _booking_status(b) == "confirmed"]

    active_people = [
        (booking, idx, participant)
        for booking in active_bookings
        for idx, participant in enumerate(list(getattr(booking, "participants", []) or []), start=1)
    ]
    # The admin's primary roster must show every recorded signup and its current
    # status, including rejected, expired, and cancelled reservations. The separate
    # Confirmed Only sheet remains restricted to confirmed registrations.
    all_people = [
        (booking, idx, participant)
        for booking in bookings
        for idx, participant in enumerate(list(getattr(booking, "participants", []) or []), start=1)
    ]
    reserved_seats = sum(int(getattr(b, "participant_count", 0) or 0) for b in active_bookings)
    confirmed_people = [
        participant
        for booking in confirmed_bookings
        for participant in list(getattr(booking, "participants", []) or [])
    ]
    waitlisted_seats = sum(
        int(getattr(entry, "requested_participant_count", 0) or 0)
        for entry, _user in waitlist_entries
    )
    confirmed_only_people = [
        (booking, idx, participant)
        for booking in confirmed_bookings
        for idx, participant in enumerate(list(getattr(booking, "participants", []) or []), start=1)
    ]
    confirmed_seats = sum(int(getattr(b, "participant_count", 0) or 0) for b in confirmed_bookings)

    output = BytesIO()
    workbook = xlsxwriter.Workbook(
        output,
        {
            "in_memory": True,
            "strings_to_formulas": False,
            "strings_to_urls": False,
        },
    )
    workbook.set_properties(
        {
            "title": f"PANEL FLOW — خروجی ثبت‌نام — {volume_label(event.volume)}",
            "subject": "Attendee list, booking history, and waitlist",
            "author": "PANEL FLOW",
            "company": "PANEL FLOW",
            "comments": "Generated by the PANEL FLOW Telegram Bot.",
        }
    )

    title_fmt = workbook.add_format(
        {
            "bold": True,
            "font_size": 18,
            "font_color": "#FFFFFF",
            "bg_color": "#1F4E78",
            "align": "center",
            "valign": "vcenter",
        }
    )
    subtitle_fmt = workbook.add_format(
        {"font_size": 10, "font_color": "#666666", "italic": True, "valign": "vcenter", "text_wrap": True}
    )
    label_fmt = workbook.add_format(
        {"bold": True, "font_color": "#1F2937", "bg_color": "#EAF2F8", "border": 1, "border_color": "#D1D5DB", "valign": "vcenter", "text_wrap": True}
    )
    value_fmt = workbook.add_format(
        {"border": 1, "border_color": "#D1D5DB", "valign": "vcenter", "text_wrap": True}
    )
    section_fmt = workbook.add_format(
        {"bold": True, "font_size": 12, "font_color": "#FFFFFF", "bg_color": "#5B9BD5", "align": "right", "valign": "vcenter"}
    )
    note_fmt = workbook.add_format(
        {"font_size": 9, "font_color": "#4B5563", "bg_color": "#F8FAFC", "border": 1, "border_color": "#E5E7EB", "text_wrap": True, "valign": "top"}
    )
    table_header_fmt = workbook.add_format(
        {"bold": True, "font_color": "#FFFFFF", "bg_color": "#4472C4", "border": 1, "border_color": "#D1D5DB", "align": "center", "valign": "vcenter", "text_wrap": True}
    )
    text_fmt = workbook.add_format({"valign": "vcenter", "text_wrap": True})
    phone_fmt = workbook.add_format({"num_format": "@", "valign": "vcenter", "text_wrap": True})
    link_fmt = workbook.add_format({"font_color": "#0563C1", "underline": 1, "valign": "vcenter"})
    integer_fmt = workbook.add_format({"num_format": "#,##0", "valign": "vcenter"})
    stat_label_fmt = workbook.add_format(
        {"bold": True, "bg_color": "#F3F4F6", "border": 1, "border_color": "#D1D5DB", "text_wrap": True}
    )
    stat_value_fmt = workbook.add_format(
        {"bold": True, "align": "center", "border": 1, "border_color": "#D1D5DB", "num_format": "#,##0"}
    )
    currency_fmt = workbook.add_format(
        {"bold": True, "border": 1, "border_color": "#D1D5DB", "num_format": '#,##0 "تومان"', "valign": "vcenter"}
    )
    date_fmt = workbook.add_format({"num_format": "yyyy-mm-dd hh:mm", "valign": "vcenter"})

    # ---------- Summary ----------
    summary = workbook.add_worksheet("Summary")
    summary.hide_gridlines(2)
    summary.right_to_left()
    summary.set_tab_color("#1F4E78")
    summary.set_column("A:A", 25)
    summary.set_column("B:B", 38)
    summary.set_column("C:C", 25)
    summary.set_column("D:D", 20)
    summary.set_column("E:E", 25)
    summary.set_column("F:F", 36)
    summary.set_column("G:H", 16)
    summary.set_row(0, 32)
    summary.merge_range("A1:H1", f"پنل فلو — خروجی ثبت‌نام — {volume_label(event.volume)}", title_fmt)

    summary.write("A3", "پنل", label_fmt)
    _write_text(summary, 2, 1, f"{volume_label(event.volume)} — {event.title}", value_fmt)
    summary.write("A4", "روز و تاریخ", label_fmt)
    _write_text(summary, 3, 1, f"{event.event_day_label} — {event.event_date_label}", value_fmt)
    summary.write("A5", "ساعت", label_fmt)
    time_text = str(event.start_time_label or "—")
    if has_end_time_label(getattr(event, "end_time_label", None)):
        time_text = f"{time_text}–{event.end_time_label}"
    _write_text(summary, 4, 1, time_text, value_fmt)
    summary.write("A6", "محل برگزاری", label_fmt)
    _write_text(summary, 5, 1, getattr(event, "venue", None), value_fmt)
    summary.write("A7", "نشانی", label_fmt)
    _write_text(summary, 6, 1, getattr(event, "address", None) or getattr(event, "venue", None), value_fmt)
    summary.write("A8", "ظرفیت کل", label_fmt)
    summary.write_number("B8", int(event.capacity), stat_value_fmt)
    summary.write("A9", "زبان پنل", label_fmt)
    _write_text(summary, 8, 1, getattr(event, "language", None), value_fmt)

    summary.write("C3", "صندلی‌های رزروشده", label_fmt)
    summary.write_number("D3", reserved_seats, stat_value_fmt)
    summary.write("C4", "صندلی‌های باقی‌مانده", label_fmt)
    summary.write_number("D4", max(0, int(event.capacity) - reserved_seats), stat_value_fmt)
    summary.write("C5", "رزروهای فعال", label_fmt)
    summary.write_number("D5", len(active_bookings), stat_value_fmt)
    summary.write("C6", "همهٔ رزروها", label_fmt)
    summary.write_number("D6", len(bookings), stat_value_fmt)
    summary.write("C7", "درخواست‌های انتظار/دعوت", label_fmt)
    summary.write_number("D7", len(waitlist_entries), stat_value_fmt)
    summary.write("C8", "صندلی‌های درخواستی انتظار/دعوت", label_fmt)
    summary.write_number("D8", waitlisted_seats, stat_value_fmt)
    summary.write("E3", "هزینه هر نفر", label_fmt)
    summary.write_number("F3", int(event.price_per_person), currency_fmt)
    summary.write("E4", "میزبان", label_fmt)
    _write_text(summary, 3, 5, getattr(event, "host_name", None), value_fmt)
    summary.write("E5", "افراد در فهرست فعال", label_fmt)
    summary.write_number("F5", len(active_people), stat_value_fmt)
    summary.write("E6", "تطابق فهرست و ظرفیت", label_fmt)
    roster_matches = len(active_people) == reserved_seats
    _write_text(summary, 5, 5, "مطابق" if roster_matches else f"نیازمند بررسی: {len(active_people)} ردیف / {reserved_seats} صندلی", value_fmt)

    summary.merge_range("A10:H10", "خلاصه وضعیت‌ها", section_fmt)
    booking_status_counts = Counter(_booking_status(b) for b in bookings)
    payment_status_counts = Counter(_payment_status(b) for b in bookings)
    attendance_counts = Counter(_value(p.attendance_status) or "unmarked" for p in confirmed_people)

    summary.write_row("A11", ["وضعیت رزرو", "تعداد"], stat_label_fmt)
    summary.write_row("C11", ["وضعیت پرداخت", "تعداد"], stat_label_fmt)
    summary.write_row("E11", ["وضعیت حضور (رزروهای تأییدشده)", "تعداد"], stat_label_fmt)

    status_items = list(STATUS_LABELS.items())
    payment_items = list(PAYMENT_LABELS.items())
    attendance_items = list(ATTENDANCE_LABELS.items())
    max_rows = max(len(status_items), len(payment_items), len(attendance_items))
    for offset in range(max_rows):
        row_idx = 11 + offset
        if offset < len(status_items):
            key, label = status_items[offset]
            _write_text(summary, row_idx, 0, label, text_fmt)
            summary.write_number(row_idx, 1, booking_status_counts.get(key, 0), integer_fmt)
        if offset < len(payment_items):
            key, label = payment_items[offset]
            _write_text(summary, row_idx, 2, label, text_fmt)
            summary.write_number(row_idx, 3, payment_status_counts.get(key, 0), integer_fmt)
        if offset < len(attendance_items):
            key, label = attendance_items[offset]
            _write_text(summary, row_idx, 4, label, text_fmt)
            summary.write_number(row_idx, 5, attendance_counts.get(key, 0), integer_fmt)

    summary.merge_range(
        "A22:H24",
        "راهنما: برگهٔ «شرکت‌کنندگان» همهٔ رزروهای فعال را نشان می‌دهد؛ برای فهرست نهایی حاضرین، از برگهٔ «فقط تأییدشده‌ها» استفاده کنید. هر شرکت‌کننده یک ردیف جدا دارد؛ افراد یک رزرو، شناسه و شماره تماس مشترک ثبت‌کننده را خواهند داشت. برگهٔ «سوابق رزرو» همهٔ وضعیت‌ها، از جمله لغوشده و منقضی‌شده را برای پیگیری نگه می‌دارد. شماره تماس ثبت‌کننده از اطلاعات همان رزرو گرفته می‌شود، نه لزوماً شماره ذخیره‌شده در پروفایل تلگرام. برگهٔ «لیست انتظار» درخواست‌های در انتظار و دعوت‌شده را جداگانه نشان می‌دهد.",
        note_fmt,
    )
    summary.write("A26", "زمان تهیه (UTC)", subtitle_fmt)
    generated = datetime.now(timezone.utc).replace(tzinfo=None)
    summary.write_datetime("B26", generated, date_fmt)
    summary.set_landscape()
    summary.fit_to_pages(1, 1)
    summary.set_margins(left=0.25, right=0.25, top=0.5, bottom=0.5)

    # ---------- Full registration roster: one row per person, every status ----------
    participants_ws = workbook.add_worksheet("Participants")
    participants_ws.hide_gridlines(2)
    participants_ws.right_to_left()
    participants_ws.set_tab_color("#5B9BD5")
    participants_ws.set_row(0, 32)
    participants_ws.merge_range("A1:N1", f"فهرست ثبت‌نام‌ها و ثبت‌کنندگان — {volume_label(event.volume)} — {event.title}", title_fmt)
    participants_ws.merge_range(
        "A2:N2",
        "هر ردیف یک شرکت‌کننده است و همهٔ وضعیت‌های رزرو را شامل می‌شود. ستون مبلغ نهایی هر نفر، قیمت مؤثر پس از تخفیف را نشان می‌دهد؛ مبلغ نهایی کل رزرو، مبلغ کل ثبت‌نام گروهی است. وضعیت پرداخت مشخص می‌کند مبلغ تأیید شده است یا هنوز در انتظار پرداخت/بررسی است. شماره تماس، شمارهٔ فرد ثبت‌کنندهٔ رزرو است.",
        subtitle_fmt,
    )
    participants_ws.write("A3", "صندلی‌های رزروشده", label_fmt)
    participants_ws.write_number("B3", reserved_seats, stat_value_fmt)
    participants_ws.write("D3", "ظرفیت", label_fmt)
    participants_ws.write_number("E3", int(event.capacity), stat_value_fmt)
    participants_ws.write("G3", "باقی‌مانده", label_fmt)
    participants_ws.write_number("H3", max(0, int(event.capacity) - reserved_seats), stat_value_fmt)
    participants_ws.write("J3", "همه افراد ثبت‌شده", label_fmt)
    participants_ws.write_number("K3", len(all_people), stat_value_fmt)

    participant_headers = [
        "ردیف",
        "نفر در رزرو",
        "نام و نام خانوادگی شرکت‌کننده",
        "تلفن تماس ثبت‌کننده",
        "شناسه رزرو",
        "وضعیت رزرو",
        "وضعیت پرداخت",
        "وضعیت حضور",
        "نام ثبت‌کننده رزرو",
        "نام کاربری تلگرام",
        "شناسه تلگرام ثبت‌کننده",
        "زمان ثبت رزرو (UTC)",
        "مبلغ نهایی هر نفر (تومان)",
        "مبلغ نهایی کل رزرو (تومان)",
    ]
    start_row = 4  # Excel row 5; rows 1-4 are title, note and KPIs.
    participants_ws.write_row(start_row, 0, participant_headers, table_header_fmt)
    participants_ws.set_row(start_row, 36)
    widths = [9, 12, 30, 23, 13, 22, 20, 16, 25, 22, 22, 22, 24, 24]
    for col, width in enumerate(widths):
        participants_ws.set_column(col, col, width)

    current_row = start_row + 1
    shares_by_booking: dict[int, list[int]] = {}
    for booking in bookings:
        booking_key = int(getattr(booking, "id", 0) or id(booking))
        attendee_count = len(list(getattr(booking, "participants", []) or [])) or int(getattr(booking, "participant_count", 1) or 1)
        shares_by_booking[booking_key] = _participant_amount_shares(booking, attendee_count, discount_code_kinds)
    for global_no, (booking, seat_no, participant) in enumerate(all_people, start=1):
        booker = getattr(booking, "booked_by", None)
        created_at = _created_at(getattr(booking, "created_at", None))
        participants_ws.write_number(current_row, 0, global_no, integer_fmt)
        participants_ws.write_number(current_row, 1, seat_no, integer_fmt)
        _write_text(participants_ws, current_row, 2, getattr(participant, "full_name", None), text_fmt)
        _write_text(participants_ws, current_row, 3, _booking_contact_phone(booking), phone_fmt)
        if getattr(booking, "id", None) is not None:
            participants_ws.write_number(current_row, 4, int(booking.id), integer_fmt)
        else:
            _write_text(participants_ws, current_row, 4, "—", text_fmt)
        # Keep raw current states (e.g. ``approved`` / ``cancelled``) so admins
        # can recognize and filter the exact system value without translation ambiguity.
        _write_text(participants_ws, current_row, 5, _booking_status(booking), text_fmt)
        _write_text(participants_ws, current_row, 6, _payment_status(booking), text_fmt)
        _write_text(participants_ws, current_row, 7, _label(getattr(participant, "attendance_status", None), ATTENDANCE_LABELS), text_fmt)
        _write_text(participants_ws, current_row, 8, _booker_name(booker), text_fmt)
        _write_username(participants_ws, current_row, 9, booker, text_fmt, link_fmt)
        if booker and getattr(booker, "telegram_id", None) is not None:
            participants_ws.write_number(current_row, 10, int(booker.telegram_id), integer_fmt)
        else:
            _write_text(participants_ws, current_row, 10, "—", text_fmt)
        if created_at:
            participants_ws.write_datetime(current_row, 11, created_at, date_fmt)
        else:
            _write_text(participants_ws, current_row, 11, "—", text_fmt)
        booking_key = int(getattr(booking, "id", 0) or id(booking))
        shares = shares_by_booking.get(booking_key, [])
        share = shares[seat_no - 1] if 0 < seat_no <= len(shares) else None
        if share is not None:
            participants_ws.write_number(current_row, 12, share, currency_fmt)
        else:
            _write_text(participants_ws, current_row, 12, "—", text_fmt)
        participants_ws.write_number(current_row, 13, int(getattr(booking, "total_amount", 0) or 0), currency_fmt)
        current_row += 1

    if all_people:
        participants_ws.add_table(
            start_row, 0, current_row - 1, len(participant_headers) - 1,
            {
                "name": "PanelFlowParticipants",
                "style": "Table Style Medium 2",
                "columns": [{"header": h} for h in participant_headers],
                "autofilter": True,
            },
        )
    else:
        participants_ws.merge_range(start_row + 1, 0, start_row + 1, len(participant_headers) - 1, "هنوز ثبت‌نامی برای این پنل وجود ندارد.", note_fmt)
    participants_ws.freeze_panes(start_row + 1, 1)
    participants_ws.set_landscape()
    participants_ws.fit_to_pages(1, 0)
    participants_ws.set_margins(left=0.25, right=0.25, top=0.5, bottom=0.5)
    participants_ws.repeat_rows(start_row, start_row)

    # ---------- Confirmed-only attendee roster for check-in / final sharing ----------
    confirmed_ws = workbook.add_worksheet("Confirmed Only")
    confirmed_ws.hide_gridlines(2)
    confirmed_ws.right_to_left()
    confirmed_ws.set_tab_color("#70AD47")
    confirmed_ws.set_row(0, 32)
    confirmed_ws.merge_range("A1:N1", f"فهرست نهایی شرکت‌کنندگان — {volume_label(event.volume)} — {event.title}", title_fmt)
    confirmed_ws.merge_range(
        "A2:N2",
        "این برگه فقط رزروهای تأییدشده را نشان می‌دهد. هر ردیف یک شرکت‌کننده است؛ مبلغ نهایی هر نفر پس از تخفیف و مبلغ نهایی کل رزرو درج شده‌اند.",
        subtitle_fmt,
    )
    confirmed_ws.write("A3", "صندلی‌های تأییدشده", label_fmt)
    confirmed_ws.write_number("B3", confirmed_seats, stat_value_fmt)
    confirmed_ws.write("D3", "ظرفیت", label_fmt)
    confirmed_ws.write_number("E3", int(event.capacity), stat_value_fmt)
    confirmed_ws.write("G3", "افراد تأییدشده", label_fmt)
    confirmed_ws.write_number("H3", len(confirmed_only_people), stat_value_fmt)
    confirmed_ws.write("J3", "رزروهای تأییدشده", label_fmt)
    confirmed_ws.write_number("K3", len(confirmed_bookings), stat_value_fmt)
    confirmed_ws.write_row(start_row, 0, participant_headers, table_header_fmt)
    confirmed_ws.set_row(start_row, 36)
    for col, width in enumerate(widths):
        confirmed_ws.set_column(col, col, width)

    confirmed_row = start_row + 1
    for global_no, (booking, seat_no, participant) in enumerate(confirmed_only_people, start=1):
        booker = getattr(booking, "booked_by", None)
        created_at = _created_at(getattr(booking, "created_at", None))
        confirmed_ws.write_number(confirmed_row, 0, global_no, integer_fmt)
        confirmed_ws.write_number(confirmed_row, 1, seat_no, integer_fmt)
        _write_text(confirmed_ws, confirmed_row, 2, getattr(participant, "full_name", None), text_fmt)
        _write_text(confirmed_ws, confirmed_row, 3, _booking_contact_phone(booking), phone_fmt)
        if getattr(booking, "id", None) is not None:
            confirmed_ws.write_number(confirmed_row, 4, int(booking.id), integer_fmt)
        else:
            _write_text(confirmed_ws, confirmed_row, 4, "—", text_fmt)
        _write_text(confirmed_ws, confirmed_row, 5, _label(getattr(booking, "status", None), STATUS_LABELS), text_fmt)
        _write_text(confirmed_ws, confirmed_row, 6, _label(_payment_status(booking), PAYMENT_LABELS), text_fmt)
        _write_text(confirmed_ws, confirmed_row, 7, _label(getattr(participant, "attendance_status", None), ATTENDANCE_LABELS), text_fmt)
        _write_text(confirmed_ws, confirmed_row, 8, _booker_name(booker), text_fmt)
        _write_username(confirmed_ws, confirmed_row, 9, booker, text_fmt, link_fmt)
        if booker and getattr(booker, "telegram_id", None) is not None:
            confirmed_ws.write_number(confirmed_row, 10, int(booker.telegram_id), integer_fmt)
        else:
            _write_text(confirmed_ws, confirmed_row, 10, "—", text_fmt)
        if created_at:
            confirmed_ws.write_datetime(confirmed_row, 11, created_at, date_fmt)
        else:
            _write_text(confirmed_ws, confirmed_row, 11, "—", text_fmt)
        booking_key = int(getattr(booking, "id", 0) or id(booking))
        shares = shares_by_booking.get(booking_key, [])
        share = shares[seat_no - 1] if 0 < seat_no <= len(shares) else None
        if share is not None:
            confirmed_ws.write_number(confirmed_row, 12, share, currency_fmt)
        else:
            _write_text(confirmed_ws, confirmed_row, 12, "—", text_fmt)
        confirmed_ws.write_number(confirmed_row, 13, int(getattr(booking, "total_amount", 0) or 0), currency_fmt)
        confirmed_row += 1

    if confirmed_only_people:
        confirmed_ws.add_table(
            start_row, 0, confirmed_row - 1, len(participant_headers) - 1,
            {
                "name": "PanelFlowConfirmedAttendees",
                "style": "Table Style Medium 4",
                "columns": [{"header": h} for h in participant_headers],
                "autofilter": True,
            },
        )
    else:
        confirmed_ws.merge_range(start_row + 1, 0, start_row + 1, len(participant_headers) - 1, "هنوز رزرو تأییدشده‌ای وجود ندارد.", note_fmt)
    confirmed_ws.freeze_panes(start_row + 1, 1)
    confirmed_ws.set_landscape()
    confirmed_ws.fit_to_pages(1, 0)
    confirmed_ws.set_margins(left=0.25, right=0.25, top=0.5, bottom=0.5)
    confirmed_ws.repeat_rows(start_row, start_row)

    # ---------- Booking-level history: each booking appears exactly once ----------
    history_ws = workbook.add_worksheet("Booking History")
    history_ws.hide_gridlines(2)
    history_ws.right_to_left()
    history_ws.set_tab_color("#A5A5A5")
    history_ws.set_row(0, 32)
    history_ws.merge_range("A1:K1", f"سوابق رزرو — {volume_label(event.volume)} — {event.title}", title_fmt)
    history_ws.merge_range("A2:K2", "همهٔ رزروها، از جمله رزروهای ردشده، لغوشده یا منقضی‌شده، در این برگه برای سابقه و پیگیری حفظ می‌شوند.", subtitle_fmt)
    history_headers = [
        "شناسه رزرو",
        "نام شرکت‌کنندگان",
        "تعداد نفرات",
        "وضعیت رزرو",
        "وضعیت پرداخت",
        "مبلغ کل (تومان)",
        "تلفن تماس رزرو",
        "نام ثبت‌کننده",
        "نام کاربری تلگرام",
        "شناسه تلگرام ثبت‌کننده",
        "زمان ثبت رزرو (UTC)",
    ]
    history_start = 3
    history_ws.write_row(history_start, 0, history_headers, table_header_fmt)
    history_ws.set_row(history_start, 36)
    history_widths = [13, 38, 12, 22, 20, 20, 23, 25, 22, 22, 22]
    for col, width in enumerate(history_widths):
        history_ws.set_column(col, col, width)
    row = history_start + 1
    for booking in bookings:
        booker = getattr(booking, "booked_by", None)
        participant_names = "\n".join(
            str(getattr(p, "full_name", "—") or "—") for p in list(getattr(booking, "participants", []) or [])
        ) or "—"
        created_at = _created_at(getattr(booking, "created_at", None))
        if getattr(booking, "id", None) is not None:
            history_ws.write_number(row, 0, int(booking.id), integer_fmt)
        else:
            _write_text(history_ws, row, 0, "—", text_fmt)
        _write_text(history_ws, row, 1, participant_names, text_fmt)
        if getattr(booking, "participant_count", None) is not None:
            history_ws.write_number(row, 2, int(booking.participant_count), integer_fmt)
        else:
            _write_text(history_ws, row, 2, "—", text_fmt)
        _write_text(history_ws, row, 3, _label(getattr(booking, "status", None), STATUS_LABELS), text_fmt)
        _write_text(history_ws, row, 4, _label(_payment_status(booking), PAYMENT_LABELS), text_fmt)
        history_ws.write_number(row, 5, int(getattr(booking, "total_amount", 0) or 0), currency_fmt)
        _write_text(history_ws, row, 6, _booking_contact_phone(booking), phone_fmt)
        _write_text(history_ws, row, 7, _booker_name(booker), text_fmt)
        _write_username(history_ws, row, 8, booker, text_fmt, link_fmt)
        if booker and getattr(booker, "telegram_id", None) is not None:
            history_ws.write_number(row, 9, int(booker.telegram_id), integer_fmt)
        else:
            _write_text(history_ws, row, 9, "—", text_fmt)
        if created_at:
            history_ws.write_datetime(row, 10, created_at, date_fmt)
        else:
            _write_text(history_ws, row, 10, "—", text_fmt)
        history_ws.set_row(row, 32)
        row += 1

    if bookings:
        history_ws.add_table(
            history_start, 0, row - 1, len(history_headers) - 1,
            {
                "name": "PanelFlowBookingHistory",
                "style": "Table Style Medium 4",
                "columns": [{"header": h} for h in history_headers],
                "autofilter": True,
            },
        )
    else:
        history_ws.merge_range(history_start + 1, 0, history_start + 1, len(history_headers) - 1, "هنوز رزروی ثبت نشده است.", note_fmt)
    history_ws.freeze_panes(history_start + 1, 1)
    history_ws.set_landscape()
    history_ws.fit_to_pages(1, 0)
    history_ws.set_margins(left=0.25, right=0.25, top=0.5, bottom=0.5)
    history_ws.repeat_rows(history_start, history_start)

    # ---------- Waitlist ----------
    waitlist_ws = workbook.add_worksheet("Waitlist")
    waitlist_ws.hide_gridlines(2)
    waitlist_ws.right_to_left()
    waitlist_ws.set_tab_color("#ED7D31")
    waitlist_ws.set_row(0, 32)
    waitlist_ws.merge_range("A1:H1", f"لیست انتظار — {volume_label(event.volume)} — {event.title}", title_fmt)
    waitlist_ws.merge_range("A2:H2", "درخواست‌های در انتظار و دعوت‌شده در این برگه نمایش داده می‌شوند؛ دعوت به‌معنای رزرو یا نگه‌داشتن ظرفیت نیست.", subtitle_fmt)
    waitlist_headers = [
        "موقعیت در صف",
        "نام کاربر",
        "نام کاربری تلگرام",
        "شناسه تلگرام",
        "تعداد صندلی درخواستی",
        "وضعیت",
        "زمان درخواست (UTC)",
    ]
    waitlist_start = 3
    waitlist_ws.write_row(waitlist_start, 0, waitlist_headers, table_header_fmt)
    waitlist_ws.set_row(waitlist_start, 36)
    for col, width in enumerate([14, 28, 23, 20, 21, 18, 22]):
        waitlist_ws.set_column(col, col, width)
    row = waitlist_start + 1
    for entry, user in sorted(
        waitlist_entries,
        key=lambda pair: (
            int(getattr(pair[0], "position", 0) or 0),
            _created_at(getattr(pair[0], "created_at", None)) or datetime.min,
        ),
    ):
        created_at = _created_at(getattr(entry, "created_at", None))
        if getattr(entry, "position", None) is not None:
            waitlist_ws.write_number(row, 0, int(entry.position), integer_fmt)
        else:
            _write_text(waitlist_ws, row, 0, "—", text_fmt)
        _write_text(waitlist_ws, row, 1, _booker_name(user), text_fmt)
        _write_username(waitlist_ws, row, 2, user, text_fmt, link_fmt)
        if user and getattr(user, "telegram_id", None) is not None:
            waitlist_ws.write_number(row, 3, int(user.telegram_id), integer_fmt)
        else:
            _write_text(waitlist_ws, row, 3, "—", text_fmt)
        if getattr(entry, "requested_participant_count", None) is not None:
            waitlist_ws.write_number(row, 4, int(entry.requested_participant_count), integer_fmt)
        else:
            _write_text(waitlist_ws, row, 4, "—", text_fmt)
        _write_text(waitlist_ws, row, 5, _label(getattr(entry, "status", None), {"waiting": "در انتظار دعوت", "invited": "دعوت‌شده؛ در انتظار ثبت‌نام", "inviting": "در حال ارسال دعوت"}), text_fmt)
        if created_at:
            waitlist_ws.write_datetime(row, 6, created_at, date_fmt)
        else:
            _write_text(waitlist_ws, row, 6, "—", text_fmt)
        row += 1
    if waitlist_entries:
        waitlist_ws.add_table(
            waitlist_start, 0, row - 1, len(waitlist_headers) - 1,
            {
                "name": "PanelFlowWaitlist",
                "style": "Table Style Medium 3",
                "columns": [{"header": h} for h in waitlist_headers],
                "autofilter": True,
            },
        )
    else:
        waitlist_ws.merge_range(waitlist_start + 1, 0, waitlist_start + 1, len(waitlist_headers) - 1, "در حال حاضر درخواست فعالی در لیست انتظار نیست.", note_fmt)
    waitlist_ws.freeze_panes(waitlist_start + 1, 1)
    waitlist_ws.set_landscape()
    waitlist_ws.fit_to_pages(1, 0)
    waitlist_ws.set_margins(left=0.25, right=0.25, top=0.5, bottom=0.5)
    waitlist_ws.repeat_rows(waitlist_start, waitlist_start)

    workbook.close()
    output.seek(0)
    return output.getvalue()


def build_leaderboard_workbook(records: Iterable[dict]) -> bytes:
    """Build an admin-only full leaderboard workbook; values are written as literal text."""
    records = list(records)
    output = BytesIO()
    workbook = xlsxwriter.Workbook(
        output,
        {"in_memory": True, "strings_to_formulas": False, "strings_to_urls": False},
    )
    workbook.set_properties({
        "title": "PANEL FLOW — Community Leaderboard",
        "subject": "Administrator leaderboard export",
        "author": "PANEL FLOW",
        "company": "PANEL FLOW",
        "comments": "Private administrator export. Contains profiles hidden from the public leaderboard.",
    })
    sheet = workbook.add_worksheet("Leaderboard")
    sheet.freeze_panes(1, 0)
    sheet.autofilter(0, 0, max(0, len(records)), 4)
    title_fmt = workbook.add_format({
        "bold": True, "font_color": "#FFFFFF", "bg_color": "#1F4E78",
        "align": "center", "valign": "vcenter", "text_wrap": True,
    })
    integer_fmt = workbook.add_format({"num_format": "#,##0", "valign": "vcenter"})
    text_fmt = workbook.add_format({"valign": "vcenter", "text_wrap": True})
    headers = ["Rank", "Name", "Panels participated in", "XP", "Public visibility"]
    for col, header in enumerate(headers):
        sheet.write_string(0, col, header, title_fmt)
    for rank, record in enumerate(records, start=1):
        row = rank
        sheet.write_number(row, 0, rank, integer_fmt)
        # Explicit string writes prevent names from being interpreted as formulas.
        sheet.write_string(row, 1, str(record.get("name") or "Unknown user"), text_fmt)
        sheet.write_number(row, 2, max(0, int(record.get("panels") or 0)), integer_fmt)
        sheet.write_number(row, 3, int(record.get("xp") or 0), integer_fmt)
        visibility = "Hidden from public leaderboard" if record.get("hidden") else "Visible on public leaderboard"
        sheet.write_string(row, 4, visibility, text_fmt)
    sheet.set_column(0, 0, 10)
    sheet.set_column(1, 1, 32)
    sheet.set_column(2, 2, 25)
    sheet.set_column(3, 3, 12)
    sheet.set_column(4, 4, 32)
    sheet.set_row(0, 28)
    workbook.close()
    return output.getvalue()
