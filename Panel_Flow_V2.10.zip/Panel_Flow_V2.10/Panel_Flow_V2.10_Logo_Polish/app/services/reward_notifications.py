"""Reliable administrator alerts for persistent Shop/reward work queues.

The database queue is authoritative. Telegram notifications are best-effort hints;
failed alerts remain queryable and can be retried from the admin console.
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select

from app.config import settings
from app.db.models import RewardIssue, ShopRequest, User, UserRole
from app.db.session import SessionLocal
from app.time_utils import utc_now_naive

logger = logging.getLogger(__name__)


async def authorized_admin_recipients() -> set[int]:
    """Combine configured admins with persisted full-admin users; never fall back to a requester."""
    recipients = {int(x) for x in settings.super_admin_id_set if int(x) > 0}
    try:
        async with SessionLocal() as session:
            rows = (await session.execute(
                select(User.telegram_id).where(User.role == UserRole.SUPER_ADMIN)
            )).scalars().all()
        recipients.update(int(x) for x in rows if int(x) > 0)
    except Exception as exc:
        # Configured admins remain usable if the database is temporarily unavailable.
        logger.warning("Could not resolve persisted admin recipients: %s", type(exc).__name__)
    return recipients


async def notify_admins(
    bot: Any,
    model_cls: type[ShopRequest] | type[RewardIssue],
    entity_id: int,
    message: str,
    reply_markup: Any = None,
) -> dict[str, Any]:
    """Send an alert to all known full admins and durably record outcome/attempt count.

    A partial send is considered notified if at least one admin received the alert,
    avoiding repeated duplicate notifications to admins who already received it. The
    failure types are retained for diagnosis. If nobody received it, status is retryable.
    """
    recipients = await authorized_admin_recipients()
    sent = 0
    errors: list[str] = []
    for telegram_id in sorted(recipients):
        try:
            await bot.send_message(telegram_id, message, reply_markup=reply_markup)
            sent += 1
        except Exception as exc:  # notification must not roll back the durable request
            errors.append(f"{type(exc).__name__}")
            logger.info(
                "Admin notification failed for %s #%s (recipient omitted): %s",
                model_cls.__name__, int(entity_id), type(exc).__name__,
            )

    status = "sent" if sent > 0 else "failed"
    if not recipients:
        error_text = "no_authorized_admin_recipients"
    elif errors:
        # Do not persist recipient IDs or the message body in notification diagnostics.
        error_text = ("partial_delivery; " if sent else "delivery_failed; ") + ",".join(errors[:8])
    else:
        error_text = None

    try:
        async with SessionLocal() as session:
            row = await session.get(model_cls, int(entity_id), with_for_update=True)
            if row is not None:
                row.admin_notification_attempts = int(row.admin_notification_attempts or 0) + 1
                row.admin_notification_status = status
                row.admin_notification_error = error_text[:255] if error_text else None
                if sent:
                    row.admin_notified_at = utc_now_naive()
                await session.commit()
    except Exception as exc:
        # The durable request already exists. If this status write fails, its pending
        # marker will remain retryable when the database is healthy again.
        logger.error("Could not persist admin notification outcome for %s #%s: %s",
                     model_cls.__name__, int(entity_id), type(exc).__name__)

    return {"status": status, "sent": sent, "recipients": len(recipients), "error": error_text}
