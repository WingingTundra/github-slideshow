"""Persistent, idempotent community scoring, privacy and challenge operations."""
from __future__ import annotations

from datetime import datetime
from html import escape
import logging

from sqlalchemy import case, func, or_, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import (
    AchievementUnlock, AppSetting, AttendanceStatus, Booking, ChallengeSubmission, CommunityChallenge,
    CommunityProfile, Event, EventStatus, Participant, Payment, PaymentStatus, RegistrationStatus, User,
    WrappedReport, XPAward,
)
from app.services.app_settings import get_setting, set_setting
from app.services.referrals import count_referrals_for_telegram_id
from app.time_utils import utc_now_naive

logger = logging.getLogger(__name__)

LEADERBOARD_ENABLED_KEY = "community_public_leaderboard_enabled"
XP_EARNING_ENABLED_KEY = "community_xp_earning_enabled"
XP_DEFAULTS = {
    "paid_panel": 10,
    "challenge_participation": 2,
    "knowledge_correct": 2,
    "creative_first": 5,
    "creative_second": 3,
    "creative_third": 2,
    "archived_review": 2,
    "recognized_contribution": 3,
    "external_competition": 6,
}


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on", "enabled"}


async def leaderboard_enabled(session: AsyncSession) -> bool:
    return _bool(await get_setting(session, LEADERBOARD_ENABLED_KEY), False)


async def set_leaderboard_enabled(session: AsyncSession, enabled: bool) -> None:
    await set_setting(session, LEADERBOARD_ENABLED_KEY, "true" if enabled else "false")


async def xp_earning_enabled(session: AsyncSession) -> bool:
    return _bool(await get_setting(session, XP_EARNING_ENABLED_KEY), True)


async def set_xp_earning_enabled(session: AsyncSession, enabled: bool) -> None:
    await set_setting(session, XP_EARNING_ENABLED_KEY, "true" if enabled else "false")


async def xp_value(session: AsyncSession, key: str) -> int:
    default = XP_DEFAULTS.get(key, 0)
    try:
        value = int(await get_setting(session, f"community_xp_{key}", str(default)) or default)
        return max(0, min(value, 10000))
    except (TypeError, ValueError):
        return default


async def award_once(
    session: AsyncSession,
    *,
    telegram_id: int,
    points: int,
    award_type: str,
    award_key: str,
    event_id: int | None = None,
    challenge_id: int | None = None,
    source_id: str | None = None,
    note: str | None = None,
) -> bool:
    """Insert one award under a savepoint; uniqueness makes concurrent retries safe."""
    if int(telegram_id) <= 0 or not award_key or len(award_key) > 220:
        raise ValueError("Invalid community award identity")
    # A global pause blocks new earned XP only. Shop debits/refunds and explicit
    # administrator ledger corrections use their own controlled write paths.
    if points > 0 and award_type not in {"admin_manual_adjustment", "shop_redemption_refund"}:
        if not await xp_earning_enabled(session):
            return False
    try:
        async with session.begin_nested():
            session.add(XPAward(
                telegram_id=int(telegram_id), points=int(points), award_type=award_type,
                award_key=award_key, event_id=event_id, challenge_id=challenge_id,
                source_id=source_id, note=(note or "")[:300] or None,
            ))
            await session.flush()
        return True
    except IntegrityError:
        return False


async def record_paid_panel_award(session: AsyncSession, booking: Booking, payment: Payment) -> bool:
    """Award +XP only for a confirmed booking with a positive approved payment."""
    if payment.status != PaymentStatus.APPROVED or int(payment.amount or 0) <= 0:
        return False
    if booking.status != RegistrationStatus.CONFIRMED:
        return False
    owner = await session.get(User, booking.booked_by_user_id)
    if owner is None:
        return False
    existing = (await session.execute(select(XPAward.id).where(
        XPAward.award_key == f"paid-panel:{owner.telegram_id}:{booking.event_id}"
    ))).scalar_one_or_none()
    if existing is not None:
        return False
    return await award_once(
        session, telegram_id=owner.telegram_id, points=await xp_value(session, "paid_panel"),
        award_type="paid_panel", award_key=f"paid-panel:{owner.telegram_id}:{booking.event_id}",
        event_id=int(booking.event_id), source_id=str(booking.id), note="Approved panel participation award",
    )


async def reverse_paid_panel_award(session: AsyncSession, telegram_id: int, event_id: int, reason: str = "refund/reversal") -> bool:
    """Record an append-only refund reversal; callers should use this on actual refunds only."""
    original = (await session.execute(select(XPAward).where(
        XPAward.award_key == f"paid-panel:{int(telegram_id)}:{int(event_id)}",
        XPAward.award_type == "paid_panel",
    ))).scalar_one_or_none()
    if original is None:
        return False
    return await award_once(
        session, telegram_id=int(telegram_id), points=-int(original.points),
        award_type="paid_panel_reversal", award_key=f"paid-panel-reversal:{int(telegram_id)}:{int(event_id)}",
        event_id=int(event_id), note=reason,
    )


async def record_user_onboarding(session: AsyncSession, telegram_id: int) -> CommunityProfile:
    """Initialize community state once; concurrent first starts do not race on PK."""
    telegram_id = int(telegram_id)
    profile = await session.get(CommunityProfile, telegram_id)
    if profile is not None:
        return profile
    published_seq = int(await session.scalar(select(func.max(CommunityChallenge.published_sequence)).where(
        CommunityChallenge.published_sequence.is_not(None)
    )) or 0)
    stmt = pg_insert(CommunityProfile).values(
        telegram_id=telegram_id,
        onboarding_sequence=published_seq,
        last_finalized_sequence=published_seq,
    ).on_conflict_do_nothing(index_elements=[CommunityProfile.telegram_id])
    await session.execute(stmt)
    await session.flush()
    # Re-read after the upsert: another concurrent request may have created it first.
    return await session.get(CommunityProfile, telegram_id)


async def get_or_create_profile(session: AsyncSession, telegram_id: int) -> CommunityProfile:
    return await record_user_onboarding(session, telegram_id)


async def total_xp(session: AsyncSession, telegram_id: int) -> int:
    value = await session.scalar(select(func.coalesce(func.sum(XPAward.points), 0)).where(
        XPAward.telegram_id == int(telegram_id)
    ))
    return int(value or 0)


async def paid_panel_count(session: AsyncSession, telegram_id: int) -> int:
    net = select(
        XPAward.event_id.label("event_id"),
        func.sum(case((XPAward.award_type == "paid_panel", 1),
                      (XPAward.award_type == "paid_panel_reversal", -1), else_=0)).label("net"),
    ).where(XPAward.telegram_id == int(telegram_id),
            XPAward.award_type.in_(("paid_panel", "paid_panel_reversal")),
            XPAward.event_id.is_not(None)).group_by(XPAward.event_id).subquery()
    return int(await session.scalar(select(func.count()).select_from(net).where(net.c.net > 0)) or 0)


async def attended_panel_count(session: AsyncSession, telegram_id: int) -> int:
    """Count distinct panels attended using authoritative bookings and attendance.

    Confirmed bookings on completed panels are presumed attended unless an explicit
    NO_SHOW is linked to the account-holder participant. Legacy NULL registrant_attends
    values retain the presumed-present default. New guest-only bookings are explicitly
    false and do not award attendance to the booking account.
    """
    absent = select(Participant.id).where(
        Participant.booking_id == Booking.id,
        Participant.user_telegram_id == User.telegram_id,
        Participant.attendance_status == AttendanceStatus.NO_SHOW,
    ).exists()
    qualified = select(User.telegram_id.label("tg"), Event.id.label("event_id")).join(
        Booking, Booking.booked_by_user_id == User.id,
    ).join(Event, Event.id == Booking.event_id).where(
        Booking.status == RegistrationStatus.CONFIRMED,
        Event.status == EventStatus.COMPLETED,
        or_(Booking.registrant_attends.is_(True), Booking.registrant_attends.is_(None)),
        ~absent,
        User.telegram_id == int(telegram_id),
    ).distinct().subquery()
    return int(await session.scalar(select(func.count()).select_from(qualified)) or 0)


def _attendance_count_subquery():
    """Per-account distinct completed panels; explicit absences override defaults."""
    absent = select(Participant.id).where(
        Participant.booking_id == Booking.id,
        Participant.user_telegram_id == User.telegram_id,
        Participant.attendance_status == AttendanceStatus.NO_SHOW,
    ).exists()
    qualified = select(
        User.telegram_id.label("tg"), Event.id.label("event_id"),
    ).join(Booking, Booking.booked_by_user_id == User.id).join(
        Event, Event.id == Booking.event_id,
    ).where(
        Booking.status == RegistrationStatus.CONFIRMED,
        Event.status == EventStatus.COMPLETED,
        or_(Booking.registrant_attends.is_(True), Booking.registrant_attends.is_(None)),
        ~absent,
    ).distinct().subquery()
    return select(
        qualified.c.tg.label("tg"),
        func.count(qualified.c.event_id).label("panels"),
    ).group_by(qualified.c.tg).subquery()


async def user_community_stats(session: AsyncSession, telegram_id: int) -> dict:
    profile = await get_or_create_profile(session, telegram_id)
    xp = await total_xp(session, telegram_id)
    panels = await attended_panel_count(session, telegram_id)
    badges = (await session.execute(select(AchievementUnlock).where(
        AchievementUnlock.telegram_id == int(telegram_id)
    ).order_by(AchievementUnlock.unlocked_at))).scalars().all()
    challenges = int(profile.challenge_participations or 0)
    referrals = await count_referrals_for_telegram_id(session, telegram_id)
    return {
        "xp": xp, "attended_panels": panels, "paid_panels": panels,
        "challenge_participations": challenges,
        "referrals": referrals,
        "correct_answers": int(profile.correct_answers or 0),
        "creative_first": int(profile.creative_first or 0),
        "creative_second": int(profile.creative_second or 0),
        "creative_third": int(profile.creative_third or 0),
        "reviews": int(profile.reviews_submitted or 0),
        "recognized": int(profile.recognized_contributions or 0),
        "current_streak": int(profile.current_streak or 0),
        "best_streak": int(profile.best_streak or 0),
        "badges": badges,
    }


PANEL_MILESTONES = ((1, "newcomer", "Newcomer"), (5, "regular", "Regular"), (60, "community_veteran", "Community Veteran"))
CHALLENGE_MILESTONES = ((3, "curious_mind", "Curious Mind"), (10, "quiz_regular", "Quiz Regular"),
                        (25, "challenge_veteran", "Challenge Veteran"), (50, "grandmaster", "Grandmaster"))
STREAK_MILESTONES = ((3, "three_in_a_row", "Three in a Row"), (5, "five_in_a_row", "Five in a Row"),
                     (10, "unstoppable", "Unstoppable"))


async def unlock_eligible_achievements(session: AsyncSession, telegram_id: int) -> list[AchievementUnlock]:
    profile = await get_or_create_profile(session, telegram_id)
    panels = await attended_panel_count(session, telegram_id)
    targets = [(key, title) for threshold, key, title in PANEL_MILESTONES if panels >= threshold]
    targets += [(key, title) for threshold, key, title in CHALLENGE_MILESTONES
                if int(profile.challenge_participations or 0) >= threshold]
    targets += [(key, title) for threshold, key, title in STREAK_MILESTONES
                if int(profile.best_streak or 0) >= threshold]
    existing = set((await session.execute(select(AchievementUnlock.achievement_key).where(
        AchievementUnlock.telegram_id == int(telegram_id)
    ))).scalars().all())
    added = []
    for key, title in targets:
        if key in existing:
            continue
        row = AchievementUnlock(telegram_id=int(telegram_id), achievement_key=key, title=title)
        try:
            async with session.begin_nested():
                session.add(row)
                await session.flush()
            added.append(row)
        except IntegrityError:
            pass
    return added


def _leaderboard_xp_subquery():
    """XP used only as the existing leaderboard tie-breaker.

    Shop redemption debits and refunds remain in the user's spendable XP ledger, but
    are accounting movements rather than achievement/participation and must never move
    someone up or down the public or admin leaderboard. Other earned-XP categories keep
    their historical tie-breaker treatment.
    """
    return select(
        XPAward.telegram_id.label("tg"),
        func.coalesce(func.sum(XPAward.points), 0).label("xp"),
    ).where(
        XPAward.award_type.not_in(("shop_redemption", "shop_redemption_refund"))
    ).group_by(XPAward.telegram_id).subquery()


async def leaderboard_rows(session: AsyncSession, limit: int = 10) -> list[dict]:
    """Return the public top ranks, masking opted-out names without removing their slots."""
    if not await leaderboard_enabled(session):
        return []
    limit = max(1, min(10, int(limit)))
    xp_q = _leaderboard_xp_subquery()
    panels_q = _attendance_count_subquery()
    opt_out_prefix = "community_leaderboard_opt_in:"
    setting_rows = (await session.execute(select(AppSetting.key, AppSetting.value).where(
        AppSetting.key.like(opt_out_prefix + "%")
    ))).all()
    hidden_ids: set[int] = set()
    for key, value in setting_rows:
        suffix = str(key)[len(opt_out_prefix):]
        if suffix.isdigit() and not _bool(value, True):
            hidden_ids.add(int(suffix))

    xp_value_expr = func.coalesce(xp_q.c.xp, 0)
    panel_value_expr = func.coalesce(panels_q.c.panels, 0)
    stmt = (
        select(
            User.telegram_id, User.first_name, User.last_name,
            panel_value_expr.label("panels"), xp_value_expr.label("xp"),
        )
        .outerjoin(panels_q, panels_q.c.tg == User.telegram_id)
        .outerjoin(xp_q, xp_q.c.tg == User.telegram_id)
        .where(
            User.first_name.is_not(None), User.last_name.is_not(None),
            func.trim(User.first_name) != "", func.trim(User.last_name) != "",
            (panel_value_expr > 0) | (xp_value_expr > 0),
        )
        .order_by(
            panel_value_expr.desc(), xp_value_expr.desc(),
            func.lower(User.first_name), func.lower(User.last_name), User.telegram_id,
        )
        .limit(limit)
    )
    result = []
    for row in (await session.execute(stmt)).all():
        telegram_id = int(row.telegram_id)
        hidden = telegram_id in hidden_ids
        # A hidden participant retains the same row and rank; only their name is masked.
        result.append({
            "name": "••••••••" if hidden else " ".join((row.first_name.strip(), row.last_name.strip())),
            "panels": int(row.panels or 0),
            "xp": int(row.xp or 0),
        })
    return result


async def admin_leaderboard_rows(
    session: AsyncSession, *, limit: int = 11, offset: int = 0,
) -> list[dict]:
    """Return the unfiltered ranking for administrators, including public-privacy status.

    Unlike ``leaderboard_rows``, this function intentionally ignores both the global
    public-leaderboard toggle and each user's opt-out preference. Its caller must enforce
    administrator authorization before displaying its results.
    """
    # Larger values are used by the admin-only workbook export. Interactive
    # leaderboard pages still request only page_size + 1 records.
    limit = max(1, min(1000, int(limit)))
    offset = max(0, int(offset))
    xp_q = _leaderboard_xp_subquery()
    panels_q = _attendance_count_subquery()

    opt_out_prefix = "community_leaderboard_opt_in:"
    setting_rows = (await session.execute(select(AppSetting.key, AppSetting.value).where(
        AppSetting.key.like(opt_out_prefix + "%")
    ))).all()
    hidden_by_id: dict[int, bool] = {}
    for key, value in setting_rows:
        suffix = str(key)[len(opt_out_prefix):]
        if suffix.isdigit():
            hidden_by_id[int(suffix)] = not _bool(value, True)

    xp_value_expr = func.coalesce(xp_q.c.xp, 0)
    panel_value_expr = func.coalesce(panels_q.c.panels, 0)
    stmt = (
        select(
            User.telegram_id, User.first_name, User.last_name, User.display_name, User.telegram_username,
            panel_value_expr.label("panels"), xp_value_expr.label("xp"),
        )
        .outerjoin(panels_q, panels_q.c.tg == User.telegram_id)
        .outerjoin(xp_q, xp_q.c.tg == User.telegram_id)
        .where((panel_value_expr > 0) | (xp_value_expr > 0))
        .order_by(
            panel_value_expr.desc(), xp_value_expr.desc(),
            func.lower(func.coalesce(User.first_name, User.display_name, User.telegram_username, "")),
            func.lower(func.coalesce(User.last_name, "")), User.telegram_id,
        )
        .offset(offset)
        .limit(limit)
    )

    result = []
    for row in (await session.execute(stmt)).all():
        name = " ".join(part.strip() for part in (row.first_name, row.last_name) if part and part.strip())
        if not name:
            name = (row.display_name or "").strip()
        if not name and row.telegram_username:
            name = "@" + str(row.telegram_username).lstrip("@")
        if not name:
            name = f"Telegram user {int(row.telegram_id)}"
        result.append({
            "telegram_id": int(row.telegram_id),
            "name": name,
            "panels": int(row.panels or 0),
            "xp": int(row.xp or 0),
            "hidden": hidden_by_id.get(int(row.telegram_id), False),
        })
    return result


async def leaderboard_opted_in(session: AsyncSession, telegram_id: int) -> bool:
    return _bool(await get_setting(session, f"community_leaderboard_opt_in:{int(telegram_id)}", "true"), True)


async def public_leaderboard_position(session: AsyncSession, telegram_id: int) -> dict | None:
    """Return the caller's rank among all eligible participants, including masked users."""
    telegram_id = int(telegram_id)
    if not await leaderboard_enabled(session):
        return None

    xp_q = _leaderboard_xp_subquery()
    panels_q = _attendance_count_subquery()
    panels_expr = func.coalesce(panels_q.c.panels, 0)
    xp_expr = func.coalesce(xp_q.c.xp, 0)
    ranking_order = (
        panels_expr.desc(), xp_expr.desc(), func.lower(User.first_name),
        func.lower(User.last_name), User.telegram_id,
    )
    stmt = select(
        User.telegram_id.label("telegram_id"),
        func.row_number().over(order_by=ranking_order).label("position"),
        func.count().over().label("total"),
    ).outerjoin(panels_q, panels_q.c.tg == User.telegram_id).outerjoin(
        xp_q, xp_q.c.tg == User.telegram_id
    ).where(
        User.first_name.is_not(None), User.last_name.is_not(None),
        func.trim(User.first_name) != "", func.trim(User.last_name) != "",
        (panels_expr > 0) | (xp_expr > 0),
    )
    ranked = stmt.subquery()
    row = (await session.execute(select(ranked.c.position, ranked.c.total).where(
        ranked.c.telegram_id == telegram_id
    ))).one_or_none()
    if row is None:
        return None
    return {"position": int(row.position), "total": int(row.total)}


async def set_leaderboard_opt_in(session: AsyncSession, telegram_id: int, enabled: bool) -> None:
    await set_setting(session, f"community_leaderboard_opt_in:{int(telegram_id)}", "true" if enabled else "false")


async def challenge_results_summary(session: AsyncSession, challenge: CommunityChallenge) -> str:
    winner_lines = []
    if challenge.challenge_type == "creative":
        winners = (await session.execute(select(ChallengeSubmission, User).outerjoin(
            User, User.telegram_id == ChallengeSubmission.telegram_id
        ).where(ChallengeSubmission.challenge_id == challenge.id,
                ChallengeSubmission.selected_place.is_not(None)).order_by(ChallengeSubmission.selected_place))).all()
        for submission, user in winners:
            name = " ".join(x for x in (user.first_name, user.last_name) if x) if user else "Member"
            winner_lines.append(f"{['🥇','🥈','🥉'][int(submission.selected_place)-1]} {escape(name or 'Member')}")
    if winner_lines:
        return "🏅 <b>Winners</b>\n" + "\n".join(winner_lines)
    return "نتایج این چالش منتشر شده است. برای مشاهده نتیجه شخصی، Passport را باز کنید."


async def make_wrapped_text(session: AsyncSession, telegram_id: int, year: int) -> str:
    start = datetime(year, 1, 1)
    end = datetime(year + 1, 1, 1)
    all_time = await total_xp(session, telegram_id)
    period_xp = int(await session.scalar(select(func.coalesce(func.sum(XPAward.points), 0)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    # Count distinct events whose original paid award was recorded in the selected year,
    # but exclude any award later reversed. Raw bookings/submissions may be purged, so
    # durable ledger keys, not mutable operational rows, are the reporting source.
    net_event_awards = select(
        XPAward.event_id.label("event_id"),
        func.sum(case((XPAward.award_type == "paid_panel", 1),
                      (XPAward.award_type == "paid_panel_reversal", -1), else_=0)).label("net"),
    ).where(XPAward.telegram_id == int(telegram_id),
            XPAward.award_type.in_(("paid_panel", "paid_panel_reversal")),
            XPAward.event_id.is_not(None)).group_by(XPAward.event_id).having(
                func.sum(case((XPAward.award_type == "paid_panel", 1),
                              (XPAward.award_type == "paid_panel_reversal", -1), else_=0)) > 0
            ).subquery()
    period_panels = int(await session.scalar(select(func.count(func.distinct(XPAward.event_id))).join(
        net_event_awards, net_event_awards.c.event_id == XPAward.event_id
    ).where(XPAward.telegram_id == int(telegram_id), XPAward.award_type == "paid_panel",
            XPAward.created_at >= start, XPAward.created_at < end)) or 0)
    profile = await get_or_create_profile(session, telegram_id)
    submissions = int(await session.scalar(select(func.count(XPAward.id)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type == "challenge_participation",
        XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    correct_period = int(await session.scalar(select(func.count(XPAward.id)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type == "knowledge_correct",
        XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    placements = int(await session.scalar(select(func.count(XPAward.id)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type.in_(("creative_first", "creative_second", "creative_third")),
        XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    external_wins = int(await session.scalar(select(func.count(XPAward.id)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type == "external_competition",
        XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    period_reviews = int(await session.scalar(select(func.count(XPAward.id)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type == "archived_review",
        XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    period_recognized = int(await session.scalar(select(func.count(XPAward.id)).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type == "recognized_contribution",
        XPAward.created_at >= start, XPAward.created_at < end
    )) or 0)
    achievements = (await session.execute(select(AchievementUnlock.title).where(
        AchievementUnlock.telegram_id == int(telegram_id),
        AchievementUnlock.unlocked_at >= start, AchievementUnlock.unlocked_at < end,
    ).order_by(AchievementUnlock.unlocked_at))).scalars().all()
    achievement_text = ", ".join(escape(title) for title in achievements) or "—"
    event_languages = (await session.execute(select(Event.language, func.count(func.distinct(XPAward.event_id))).join(
        XPAward, XPAward.event_id == Event.id
    ).join(net_event_awards, net_event_awards.c.event_id == XPAward.event_id).where(
        XPAward.telegram_id == int(telegram_id), XPAward.award_type == "paid_panel",
        XPAward.created_at >= start, XPAward.created_at < end, Event.language.is_not(None)
    ).group_by(Event.language).order_by(func.count(func.distinct(XPAward.event_id)).desc()).limit(3))).all()
    language_text = ", ".join(f"{lang} ({count})" for lang, count in event_languages) or "—"
    return (
        f"🎉 <b>مرور سالانهٔ Panel Flow (Wrapped) {year}</b>\n\n"
        f"🎟 تعداد پنل‌های شرکت‌شده: <b>{period_panels}</b>\n"
        f"✨ امتیاز XP کسب‌شده در {year}: <b>{period_xp}</b>\n"
        f"🌟 مجموع XP تا امروز: <b>{all_time}</b>\n"
        f"🧠 پاسخ‌های چالش: <b>{submissions}</b> · پاسخ‌های درست: <b>{correct_period}</b>\n"
        f"🏅 رتبه‌های خلاقانه: <b>{placements}</b> · بردهای مسابقه: <b>{external_wins}</b>\n"
        f"📝 نظرها: <b>{period_reviews}</b> · مشارکت‌های تقدیرشده: <b>{period_recognized}</b>\n"
        f"🔥 پیوستگی فعلی/بهترین پیوستگی: <b>{profile.current_streak}/{profile.best_streak}</b>\n"
        f"🌟 نشان‌های دریافت‌شده: <b>{achievement_text}</b>\n"
        f"🌐 زبان پنل‌ها: <b>{escape(language_text)}</b>\n\n"
        "از اینکه بخشی از جامعهٔ Panel Flow هستید سپاسگزاریم؛ هر گفت‌وگو و مشارکت شما ارزشمند است!"
    )
