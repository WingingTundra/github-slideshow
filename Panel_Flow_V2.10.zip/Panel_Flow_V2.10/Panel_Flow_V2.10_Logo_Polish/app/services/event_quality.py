"""Non-blocking publishing guidance for event hosts; never changes public data."""
from __future__ import annotations


def evaluate_event_quality(event) -> dict:
    checks = [
        ("description", bool((getattr(event, "description", None) or "").strip()) and len((event.description or "").strip()) >= 80),
        ("date", bool(getattr(event, "event_date_iso", None))),
        ("topic", bool(getattr(event, "topic_tags", None))),
        ("agenda", bool(getattr(event, "agenda_items", None))),
        ("questions", bool(getattr(event, "discussion_questions", None))),
        ("cover", bool(getattr(event, "cover_image_url", None))),
        ("organization", bool(getattr(event, "organization_id", None) and getattr(event, "brand_id", None))),
    ]
    complete = [key for key, ok in checks if ok]
    missing = [key for key, ok in checks if not ok]
    return {
        "score": round(100 * len(complete) / len(checks)),
        "completed": complete,
        "missing": missing,
        "ready": len(missing) <= 2,
    }
