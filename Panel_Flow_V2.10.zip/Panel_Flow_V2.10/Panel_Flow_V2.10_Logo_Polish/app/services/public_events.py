from __future__ import annotations

from sqlalchemy import String, and_, cast, case, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Booking, Brand, City, Event, EventStatus, Organization
from app.display_utils import has_end_time_label
from app.services.events import ACTIVE_BOOKING_STATUSES, display_status, registration_is_open, waitlist_is_available


def public_event_payload(event: Event, used: int, *, include_extended: bool = True) -> dict:
    """Serialize only intentionally public event fields shared by API clients."""
    payload = {
        "id": int(event.id),
        "volume": event.volume,
        "title": event.title,
        "day": event.event_day_label,
        "date": event.event_date_label,
        "start_time": event.start_time_label,
        "end_time": event.end_time_label if has_end_time_label(event.end_time_label) else None,
        "venue": event.venue,
        "address": event.address,
        "map_url": event.map_url,
        "capacity": int(event.capacity),
        "price_per_person": int(event.price_per_person),
        "price_without_cafe_order": (
            int(event.price_without_cafe_order) if event.price_without_cafe_order is not None else None
        ),
        "status": display_status(event, used).value,
        "registration_open": registration_is_open(event),
        "is_postponed": bool(getattr(event, "is_postponed", False)),
        "postponement_note": getattr(event, "postponement_note", None),
        "cover_image_url": getattr(event, "cover_image_url", None),
        "cover_image_thumb_url": getattr(event, "cover_image_thumb_url", None),
        "waitlist_enabled": bool(getattr(event, "waitlist_enabled", False)),
        # Modality and provider are public event attributes; meeting_link is
        # intentionally never serialized here and is only returned to eligible
        # confirmed booking owners after organizer release.
        "event_type": event.event_type or "physical",
        "meeting_platform": event.meeting_platform if event.event_type in {"online", "hybrid"} else None,
    }
    if include_extended:
        payload.update({
            "language": event.language,
            "description": event.description,
            "city": event.city,
            "city_id": int(event.city_id) if event.city_id is not None else None,
            "date_iso": event.event_date_iso.isoformat() if event.event_date_iso else None,
            "organization_id": int(getattr(event, "organization_id", None)) if getattr(event, "organization_id", None) is not None else None,
            "brand_id": int(getattr(event, "brand_id", None)) if getattr(event, "brand_id", None) is not None else None,
            "topic_tags": list(getattr(event, "topic_tags", None) or []),
            "agenda_items": list(getattr(event, "agenda_items", None) or []),
            "discussion_questions": list(getattr(event, "discussion_questions", None) or []),
            "host_name": getattr(event, "host_name", None),
        })
    return payload


async def list_public_event_payloads(
    session: AsyncSession,
    *,
    limit: int | None = None,
    offset: int = 0,
    include_extended: bool = True,
    city_id: int | None = None,
    query: str | None = None,
    topic: str | None = None,
    organization_id: int | None = None,
    language: str | None = None,
    event_type: str | None = None,
    date_from=None,
    date_to=None,
    availability: str | None = None,
    sort: str = "newest",
    cursor: tuple | None = None,
    include_cursor_metadata: bool = False,
) -> tuple[list[dict], int]:
    """Read published, non-archived events with aggregate usage (never attendee IDs)."""
    base_filter = [Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)]
    # Public discovery only exposes events whose city has been explicitly enabled.
    # Legacy city-less rows are hidden once the national city directory is active.
    base_filter.append(Event.city_id.in_(select(City.id).where(City.is_active.is_(True))))
    if city_id is not None:
        base_filter.append(Event.city_id == city_id)
    if organization_id is not None:
        base_filter.append(Event.organization_id == organization_id)
    if language:
        base_filter.append(Event.language.ilike(language.strip()))
    if event_type:
        base_filter.append(Event.event_type == event_type)
    if date_from is not None:
        base_filter.append(Event.event_date_iso >= date_from)
    if date_to is not None:
        base_filter.append(Event.event_date_iso <= date_to)
    if topic:
        # Casting JSON to text keeps this compatible with both JSONB/PostgreSQL
        # and SQLite tests while matching an exact quoted taxonomy key.
        safe_topic = str(topic).strip().replace("%", "\\%").replace("_", "\\_")
        base_filter.append(cast(Event.topic_tags, String).ilike(f'%"{safe_topic}"%'))
    if query and query.strip():
        term = f"%{query.strip()}%"
        base_filter.append(or_(
            Event.title.ilike(term), Event.description.ilike(term),
            Event.venue.ilike(term), Event.city.ilike(term), Event.host_name.ilike(term),
        ))

    # A single correlated aggregate drives availability filtering; returned
    # capacity labels are fetched in one grouped query for the page (no N+1).
    used_expression = select(func.coalesce(func.sum(Booking.participant_count), 0)).where(
        Booking.event_id == Event.id, Booking.status.in_(ACTIVE_BOOKING_STATUSES)
    ).scalar_subquery()
    if availability == "open":
        base_filter.extend((Event.registration_open.is_(True), Event.is_postponed.is_(False), used_expression < Event.capacity))
    elif availability == "waitlist":
        base_filter.extend((Event.waitlist_enabled.is_(True), Event.is_postponed.is_(False), used_expression >= Event.capacity))
    total = int((await session.execute(select(func.count(Event.id)).where(*base_filter))).scalar_one())
    stmt = select(Event).where(*base_filter)
    if cursor is not None:
        if sort != "newest":
            raise ValueError("KEYSET_CURSOR_REQUIRES_NEWEST_SORT")
        cursor_updated_at, cursor_id = cursor
        stmt = stmt.where(or_(Event.updated_at < cursor_updated_at,
                              and_(Event.updated_at == cursor_updated_at, Event.id < int(cursor_id))))
    if sort == "price":
        stmt = stmt.order_by(Event.price_per_person.asc(), Event.event_date_iso.asc().nullslast(), Event.id.desc())
    elif sort == "title":
        stmt = stmt.order_by(Event.title.asc(), Event.id.desc())
    elif sort == "upcoming":
        stmt = stmt.order_by(Event.event_date_iso.asc().nullslast(), Event.id.desc())
    elif sort == "relevance" and query and query.strip():
        term = f"%{query.strip()}%"
        stmt = stmt.order_by(case((Event.title.ilike(term), 0), else_=1), Event.updated_at.desc(), Event.id.desc())
    else:
        stmt = stmt.order_by(Event.updated_at.desc(), Event.id.desc())
    if offset:
        stmt = stmt.offset(offset)
    if limit is not None:
        stmt = stmt.limit(limit)
    events = (await session.execute(stmt)).scalars().all()
    event_ids = [int(event.id) for event in events]
    usage_rows = (await session.execute(
        select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_(event_ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES))
        .group_by(Booking.event_id)
    )).all() if event_ids else []
    usage = {int(event_id): int(count) for event_id, count in usage_rows}
    organization_ids = {int(e.organization_id) for e in events if e.organization_id is not None}
    brand_ids = {int(e.brand_id) for e in events if e.brand_id is not None}
    organizations = (await session.execute(select(Organization).where(
        Organization.id.in_(organization_ids), Organization.status == "approved"))).scalars().all() if organization_ids else []
    brands = (await session.execute(select(Brand).where(
        Brand.id.in_(brand_ids), Brand.status == "approved"))).scalars().all() if brand_ids else []
    organization_map = {int(o.id): o for o in organizations}
    brand_map = {int(b.id): b for b in brands}
    payloads = []
    for event in events:
        payload = public_event_payload(event, usage.get(int(event.id), 0), include_extended=include_extended)
        if include_extended:
            organization = organization_map.get(int(event.organization_id)) if event.organization_id is not None else None
            brand = brand_map.get(int(event.brand_id)) if event.brand_id is not None else None
            payload["organization"] = ({"id": organization.id, "slug": organization.slug, "name": organization.name,
                "is_platform_founder": organization.is_platform_founder} if organization else None)
            payload["brand"] = ({"id": brand.id, "slug": brand.slug, "name": brand.name} if brand else None)
        payloads.append(payload)
    if include_cursor_metadata and events and limit is not None and len(events) == int(limit):
        last_event = events[-1]
        payloads[-1]["_pagination_cursor"] = {
            "updated_at": last_event.updated_at.isoformat(), "id": int(last_event.id),
        }
    return payloads, total
