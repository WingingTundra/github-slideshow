"""Cross-process upload quota locking, reservations, and stale-temp recovery."""
from __future__ import annotations

import fcntl
import time
from contextlib import contextmanager
from pathlib import Path


RESERVATION_STALE_SECONDS = 60 * 60


@contextmanager
def upload_quota_lock(root: Path):
    """Serialize quota decisions across processes sharing the upload volume."""
    root = Path(root)
    lock_path = root / ".quota.lock"
    with lock_path.open("a+") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _reservation_path(root: Path, upload_id: str) -> Path:
    return root / ".quota-reservations" / f"{upload_id}.reserve"


def _part_path(root: Path, upload_id: str) -> Path:
    return root / f".upload-{upload_id}.part"


def cleanup_stale_upload_artifacts_unlocked(
    root: Path,
    *,
    now: float | None = None,
    stale_after_seconds: int = RESERVATION_STALE_SECONDS,
) -> int:
    """Remove crashed-upload debris; caller must hold ``upload_quota_lock``.

    Fresh reservation files are leases for active downloads. ``download_file``
    refreshes their timestamps while a download is in progress. Once a lease is
    stale, its matching temporary upload can be removed safely. Unmatched stale
    temporary files from previous releases are also reclaimed.
    """
    root = Path(root)
    if not root.exists() or not root.is_dir():
        return 0
    now = time.time() if now is None else float(now)
    stale_after_seconds = max(60, int(stale_after_seconds))
    reservation_dir = root / ".quota-reservations"
    removed = 0

    if reservation_dir.exists() and reservation_dir.is_dir() and not reservation_dir.is_symlink():
        for reservation in reservation_dir.glob("*.reserve"):
            try:
                if reservation.is_symlink() or not reservation.is_file():
                    continue
                if now - reservation.stat().st_mtime <= stale_after_seconds:
                    continue
                upload_id = reservation.name.removesuffix(".reserve")
                # Only delete the temp associated with this stale lease.
                _part_path(root, upload_id).unlink(missing_ok=True)
                reservation.unlink(missing_ok=True)
                removed += 1
            except OSError:
                continue

    # Recover stale .part files, including artifacts created by older releases
    # where reservation IDs were not tied to temporary file IDs.
    for part in root.glob(".upload-*.part"):
        try:
            if part.is_symlink() or not part.is_file():
                continue
            if now - part.stat().st_mtime <= stale_after_seconds:
                continue
            upload_id = part.name.removeprefix(".upload-").removesuffix(".part")
            reservation = _reservation_path(root, upload_id)
            if reservation.is_file() and not reservation.is_symlink():
                try:
                    if now - reservation.stat().st_mtime <= stale_after_seconds:
                        continue
                except OSError:
                    pass
            part.unlink(missing_ok=True)
            removed += 1
        except OSError:
            continue
    return removed


def cleanup_stale_upload_artifacts(
    root: Path,
    *,
    now: float | None = None,
    stale_after_seconds: int = RESERVATION_STALE_SECONDS,
) -> int:
    """Locked wrapper used by the daily maintenance job."""
    root = Path(root)
    if not root.exists() or not root.is_dir():
        return 0
    with upload_quota_lock(root):
        return cleanup_stale_upload_artifacts_unlocked(
            root, now=now, stale_after_seconds=stale_after_seconds
        )


def managed_upload_bytes(root: Path, *, now: float | None = None) -> int:
    """Count managed files, excluding active .part files covered by fresh leases."""
    root = Path(root)
    now = time.time() if now is None else float(now)
    reservation_dir = root / ".quota-reservations"
    total = 0
    for path in root.rglob("*"):
        try:
            if path.is_symlink() or not path.is_file():
                continue
            if path == root / ".quota.lock" or reservation_dir == path.parent or reservation_dir in path.parents:
                continue
            if path.name.startswith(".upload-") and path.name.endswith(".part"):
                upload_id = path.name.removeprefix(".upload-").removesuffix(".part")
                reservation = _reservation_path(root, upload_id)
                try:
                    if reservation.is_file() and not reservation.is_symlink() and now - reservation.stat().st_mtime <= RESERVATION_STALE_SECONDS:
                        # The full reserved size is counted separately below.
                        continue
                except OSError:
                    pass
            total += path.stat().st_size
        except OSError:
            continue
    return total


def reservation_bytes(
    root: Path,
    *,
    exclude: Path | None = None,
    now: float | None = None,
) -> int:
    """Sum fresh reservation leases; stale leases should be cleaned first."""
    folder = Path(root) / ".quota-reservations"
    folder.mkdir(mode=0o700, exist_ok=True)
    now = time.time() if now is None else float(now)
    total = 0
    for path in folder.iterdir():
        try:
            if path.is_symlink() or not path.is_file() or (exclude is not None and path == exclude):
                continue
            if now - path.stat().st_mtime > RESERVATION_STALE_SECONDS:
                continue
            total += max(0, int(path.read_text(encoding="ascii").strip() or "0"))
        except (OSError, ValueError):
            continue
    return total

def upload_storage_usage_bytes(root: Path, *, now: float | None = None) -> int:
    """Return quota-occupied bytes, including active reservations, consistently.

    The same cross-process lock used by upload creation/publication protects the
    snapshot so an administrator dashboard does not under-report active uploads.
    Stale crash artifacts are reclaimed before measuring.
    """
    root = Path(root)
    if not root.exists() or not root.is_dir():
        return 0
    with upload_quota_lock(root):
        cleanup_stale_upload_artifacts_unlocked(root, now=now)
        return managed_upload_bytes(root, now=now) + reservation_bytes(root, now=now)

