"""Shared Panel Flow panel-pricing rules for V63.

The alternative price is the complete per-person total for participating without
being required to order from the cafe menu. Ordinary discounts apply only to the
base participation component, never to the difference between the two prices.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

BASE_OPTION = "base"
WITHOUT_CAFE_ORDER = "without_cafe_order"


@dataclass(frozen=True)
class PriceComponents:
    option: str
    gross_total: Decimal
    discountable_base_total: Decimal
    non_discountable_waiver_total: Decimal
    base_price_snapshot: Decimal
    alternative_price_snapshot: Decimal | None


def positive_optional_price(value) -> Decimal | None:
    """Normalize an optional alternative price; NULL/zero means unavailable."""
    if value is None:
        return None
    amount = Decimal(str(value))
    if amount <= 0:
        return None
    return amount


def calculate_price_components(base_price, alternative_price, option: str | None, count: int) -> PriceComponents:
    """Calculate gross/discountable totals and immutable price snapshots."""
    base = Decimal(str(base_price))
    alternative = positive_optional_price(alternative_price)
    if base < 0:
        raise ValueError("INVALID_BASE_PRICE")
    if count < 1:
        raise ValueError("INVALID_PARTICIPANT_COUNT")
    if base == 0:
        # Product rule: a zero base price means the whole panel is free. There is
        # no separately paid cafe-waiver option on a free panel.
        return PriceComponents(BASE_OPTION, Decimal(0), Decimal(0), Decimal(0), base, alternative)
    selected = option or BASE_OPTION
    if selected == WITHOUT_CAFE_ORDER:
        if alternative is None or alternative <= base:
            raise ValueError("ALTERNATIVE_PRICE_UNAVAILABLE")
        gross = alternative * count
        discountable = base * count
        waiver = (alternative - base) * count
        return PriceComponents(selected, gross, discountable, waiver, base, alternative)
    if selected != BASE_OPTION:
        raise ValueError("INVALID_PRICING_OPTION")
    gross = base * count
    return PriceComponents(BASE_OPTION, gross, gross, Decimal(0), base, alternative)


def panel_price_label(base_price, alternative_price) -> str:
    """Concise Persian price copy for panel descriptions."""
    base = Decimal(str(base_price))
    alternative = positive_optional_price(alternative_price)
    if base == 0:
        return "رایگان"
    if alternative is not None and alternative > base:
        return f"{int(base):,} تومان + سفارش از منوی کافه (یا {int(alternative):,} تومان بدون سفارش اجباری از منوی کافه)"
    return f"{int(base):,} تومان"


def booking_option_label(option: str | None, *, base_price=None, alternative_price=None) -> str:
    """Human-readable pricing choice for admin review and checkout summaries."""
    if base_price is not None and Decimal(str(base_price)) == 0:
        return "رایگان"
    if option == WITHOUT_CAFE_ORDER:
        return "بدون سفارش اجباری از منوی کافه"
    if option == BASE_OPTION:
        return "پایه + سفارش از منوی کافه"
    return "ثبت‌نام پیش از نسخهٔ ۶۳ (گزینه ثبت نشده)"


def booking_option_detail_label(option: str | None, *, base_price=None, alternative_price=None) -> str:
    """Admin-facing pricing choice with the original per-person price snapshot."""
    if base_price is None:
        return booking_option_label(option, base_price=base_price, alternative_price=alternative_price)
    base = Decimal(str(base_price))
    if base == 0:
        return "رایگان"
    if option == WITHOUT_CAFE_ORDER:
        alternative = positive_optional_price(alternative_price)
        if alternative is not None and alternative > base:
            return f"بدون سفارش اجباری از منوی کافه ({int(alternative):,} تومان برای هر نفر)"
        return "بدون سفارش اجباری از منوی کافه (قیمت ثبت‌شده نامعتبر است)"
    if option == BASE_OPTION:
        alternative = positive_optional_price(alternative_price)
        if alternative is not None and alternative > base:
            return f"پایه + سفارش از منوی کافه ({int(base):,} تومان برای هر نفر + سفارش کافه)"
        return f"{int(base):,} تومان برای هر نفر"
    return booking_option_label(option, base_price=base_price, alternative_price=alternative_price)
