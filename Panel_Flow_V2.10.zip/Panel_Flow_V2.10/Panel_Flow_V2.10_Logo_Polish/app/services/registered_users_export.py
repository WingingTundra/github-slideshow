"""Admin export for users who completed the bot's initial profile onboarding.

A completed profile is defined by non-blank first name, last name, and phone number.
Rows intentionally represent user accounts, not bookings or individual participants.
"""

from __future__ import annotations

from io import BytesIO
from typing import Iterable

import xlsxwriter
from sqlalchemy import func, select

from app.db.models import User


def completed_user_profiles_statement():
    """Select only users who supplied first name, last name, and a phone number.

    Trim checks exclude whitespace-only legacy values. Username is optional and does
    not determine onboarding completion. Blocked users are included because they
    may still be part of the account's historical bot-user count.
    """
    return (
        select(User)
        .where(
            User.first_name.is_not(None),
            func.trim(User.first_name) != "",
            User.last_name.is_not(None),
            func.trim(User.last_name) != "",
            User.phone_number.is_not(None),
            func.trim(User.phone_number) != "",
        )
        .order_by(User.created_at.desc(), User.id.desc())
    )


def build_completed_user_profiles_workbook(users: Iterable[User]) -> bytes:
    """Build a polished in-memory .xlsx workbook with one row per completed profile."""
    user_rows = list(users)
    output = BytesIO()
    workbook = xlsxwriter.Workbook(
        output,
        {
            "in_memory": True,
            "strings_to_formulas": False,
            "strings_to_urls": False,
        },
    )
    workbook.set_properties(
        {
            "title": "Panel Flow — Completed Bot User Profiles",
            "subject": "Users who completed first-name, last-name, and phone onboarding",
            "author": "PANEL FLOW",
            "company": "PANEL FLOW",
            "comments": "Generated on demand by the Panel Flow Telegram Bot.",
        }
    )

    sheet = workbook.add_worksheet("Completed Users")
    sheet.right_to_left()
    sheet.hide_gridlines(2)
    sheet.freeze_panes(4, 0)
    sheet.set_tab_color("#1F4E78")
    sheet.set_column("A:A", 7)
    sheet.set_column("B:B", 30)
    sheet.set_column("C:C", 21)
    sheet.set_column("D:D", 25)
    sheet.set_column("E:E", 19)

    title_fmt = workbook.add_format(
        {
            "bold": True,
            "font_size": 16,
            "font_color": "#FFFFFF",
            "bg_color": "#1F4E78",
            "align": "center",
            "valign": "vcenter",
        }
    )
    note_fmt = workbook.add_format(
        {
            "font_color": "#4B5563",
            "italic": True,
            "text_wrap": True,
            "valign": "vcenter",
        }
    )
    header_fmt = workbook.add_format(
        {
            "bold": True,
            "font_color": "#FFFFFF",
            "bg_color": "#4472C4",
            "border": 1,
            "border_color": "#D1D5DB",
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
        }
    )
    cell_fmt = workbook.add_format(
        {"border": 1, "border_color": "#E5E7EB", "valign": "vcenter", "text_wrap": True}
    )
    id_fmt = workbook.add_format(
        {
            "border": 1,
            "border_color": "#E5E7EB",
            "valign": "vcenter",
            "num_format": "@",
        }
    )
    headers = [
        "ردیف",
        "نام و نام خانوادگی",
        "شماره موبایل",
        "نام کاربری تلگرام",
        "شناسه عددی تلگرام",
    ]

    sheet.merge_range(0, 0, 0, len(headers) - 1, "فهرست کاربران تکمیل‌کننده ثبت‌نام اولیه ربات Panel Flow", title_fmt)
    sheet.set_row(0, 30)
    sheet.merge_range(
        1,
        0,
        1,
        len(headers) - 1,
        f"تعداد پروفایل‌های کامل: {len(user_rows):,} | فقط کاربرانی که نام، نام خانوادگی و شماره موبایل دارند در این فایل آمده‌اند.",
        note_fmt,
    )
    sheet.set_row(1, 28)

    header_row = 3
    for col, header in enumerate(headers):
        sheet.write_string(header_row, col, header, header_fmt)

    for index, user in enumerate(user_rows, start=1):
        first_name = str(getattr(user, "first_name", None) or "").strip()
        last_name = str(getattr(user, "last_name", None) or "").strip()
        full_name = f"{first_name} {last_name}".strip()
        phone = str(getattr(user, "phone_number", None) or "").strip()
        username = str(getattr(user, "telegram_username", None) or "").strip()
        if username:
            username = username.lstrip("@")
            username_value = f"@{username}" if username else "—"
        else:
            username_value = "—"
        telegram_id = str(getattr(user, "telegram_id", "") or "").strip()

        row = header_row + index
        # Explicit string writes preserve Persian text, phone-number plus signs,
        # numeric IDs, and prevent user-controlled values from becoming formulas.
        sheet.write_string(row, 0, str(index), id_fmt)
        sheet.write_string(row, 1, full_name, cell_fmt)
        sheet.write_string(row, 2, phone, id_fmt)
        sheet.write_string(row, 3, username_value, cell_fmt)
        sheet.write_string(row, 4, telegram_id, id_fmt)
        sheet.set_row(row, 22)

    if user_rows:
        first_data_row = header_row
        last_data_row = header_row + len(user_rows)
        sheet.add_table(
            first_data_row,
            0,
            last_data_row,
            len(headers) - 1,
            {
                "name": "CompletedBotUsers",
                "style": "Table Style Medium 2",
                "columns": [{"header": name} for name in headers],
                "autofilter": True,
            },
        )
    else:
        sheet.write_string(header_row + 1, 1, "هنوز هیچ پروفایل کاملی ثبت نشده است.", cell_fmt)

    workbook.close()
    return output.getvalue()
