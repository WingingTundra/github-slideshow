"""Helpers for revision-bound host-submission review actions."""
from __future__ import annotations

import re

TELEGRAM_CALLBACK_DATA_MAX_BYTES = 64
_REJECTION_TOKEN_RE = re.compile(r"^[a-f0-9]{16}$")


def current_submission_revision(event) -> int:
    """Return a normalized revision for both ORM objects and lightweight test doubles."""
    return max(0, int(getattr(event, "submission_revision", 0) or 0))


def bump_submission_revision(event) -> int:
    """Advance and return the generation after a submission or pending-review edit."""
    revision = current_submission_revision(event) + 1
    event.submission_revision = revision
    return revision


def submission_revision_matches(event, expected_revision: int) -> bool:
    try:
        expected = int(expected_revision)
    except (TypeError, ValueError):
        return False
    return current_submission_revision(event) == expected


def approval_callback_data(event_id: int, revision: int) -> str:
    value = f"hrap:{int(event_id)}:{int(revision)}"
    if int(event_id) <= 0 or int(revision) < 0 or len(value.encode("utf-8")) > TELEGRAM_CALLBACK_DATA_MAX_BYTES:
        raise ValueError("Invalid or oversized host approval callback data")
    return value


def rejection_callback_data(event_id: int, revision: int, token: str) -> str:
    if int(event_id) <= 0 or int(revision) < 0 or not _REJECTION_TOKEN_RE.fullmatch(str(token)):
        raise ValueError("Invalid host rejection callback parameters")
    value = f"hrrj:{int(event_id)}:{int(revision)}:{token}"
    if len(value.encode("utf-8")) > TELEGRAM_CALLBACK_DATA_MAX_BYTES:
        raise ValueError("Host rejection callback data exceeds Telegram's limit")
    return value
