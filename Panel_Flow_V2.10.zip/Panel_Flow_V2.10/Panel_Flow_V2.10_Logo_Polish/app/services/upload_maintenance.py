"""Retention and conservative cleanup for receipt and orphan upload files."""
from __future__ import annotations

from app.display_utils import volume_label

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sqlalchemy import select, or_, and_
from sqlalchemy.orm import selectinload

from app.config import settings
from app.db.models import Booking, Brand, Event, Organization, Payment, PaymentStatus, RegistrationStatus, User
from app.time_utils import utc_now_naive
from app.services.upload_quota import cleanup_stale_upload_artifacts

logger = logging.getLogger(__name__)


def _managed_path(stored_path: str | None, root: Path) -> Path | None:
    if not stored_path:
        return None
    raw_value = str(stored_path).strip()
    # Public image URLs point into the dedicated public_media subdirectory.
    media_prefix = "/api/v1/media/"
    if raw_value.startswith(media_prefix):
        filename = raw_value[len(media_prefix):]
        if not filename or Path(filename).name != filename:
            return None
        candidate = root / "public_media" / filename
    else:
        raw = Path(raw_value)
        candidate = raw if raw.is_absolute() else root / raw.name
    try:
        if candidate.is_symlink():
            return None
        resolved = candidate.resolve()
        if resolved != root and root not in resolved.parents:
            return None
        return resolved
    except OSError:
        return None


def prune_orphan_files(root: Path, referenced_paths: set[Path], *, cutoff_epoch: float) -> int:
    """Delete regular, unreferenced files under the managed upload tree only."""
    root = root.resolve()
    if not root.exists() or not root.is_dir():
        return 0
    removed = 0
    for path in root.rglob("*"):
        try:
            if path.is_symlink() or not path.is_file():
                continue
            if path.name == ".quota.lock" or ".quota-reservations" in path.parts or (path.name.startswith(".upload-") and path.name.endswith(".part")):
                continue
            resolved = path.resolve()
            if resolved == root or root not in resolved.parents or resolved in referenced_paths:
                continue
            if path.stat().st_mtime >= cutoff_epoch:
                continue
            path.unlink()
            removed += 1
        except FileNotFoundError:
            continue
        except OSError:
            logger.exception("Could not remove orphan upload %s", path)
    return removed


async def cleanup_expired_receipts_once(*, session_factory=None, now: datetime | None = None, bot=None) -> int:
    """Delete stored receipt content after the retention window, preserving payment outcomes.

    The database update is committed before files are unlinked. This function clears
    receipt paths, names, and text only; booking/payment status, amount, and review
    decision are retained. Row locks and rechecking of file references make it safe
    against a receipt being replaced while cleanup is running.
    """
    if session_factory is None:
        from app.db.session import SessionLocal
        session_factory = SessionLocal

    current = now or utc_now_naive()
    if current.tzinfo is not None:
        current = current.astimezone(timezone.utc).replace(tzinfo=None)
    retention_days = max(1, int(settings.receipt_retention_days))
    cutoff = current - timedelta(days=retention_days)
    root = Path(settings.upload_dir).resolve()
    paths_to_delete: set[Path] = set()
    cleaned_rows = 0
    stale_unreviewed_booking_ids: list[int] = []

    async with session_factory() as session:
        rows = (await session.execute(
            select(Payment).options(selectinload(Payment.booking))
            .where(
                Payment.receipt_uploaded_at.is_not(None),
                Payment.receipt_uploaded_at <= cutoff,
                or_(
                    Payment.receipt_file.is_not(None),
                    Payment.receipt_file_name.is_not(None),
                    Payment.receipt_text.is_not(None),
                    # Recovery path: if an earlier run cleared receipt payload but
                    # crashed before releasing a pending-verification seat, keep
                    # matching the row until the booking transition is committed.
                    and_(
                        Payment.status == PaymentStatus.PENDING,
                        Payment.booking.has(Booking.status == RegistrationStatus.PENDING_VERIFICATION),
                    ),
                ),
            )
            .with_for_update(skip_locked=True)
        )).scalars().all()
        for payment in rows:
            # An unreviewed receipt older than retention must no longer hold a seat
            # forever. First clear the old receipt payload; a second short transaction
            # releases only bookings whose receipt has not been replaced in the meantime.
            booking = payment.booking
            if (
                booking is not None
                and payment.status == PaymentStatus.PENDING
                and booking.status == RegistrationStatus.PENDING_VERIFICATION
                and payment.receipt_uploaded_at is not None
                and payment.receipt_uploaded_at <= cutoff
            ):
                stale_unreviewed_booking_ids.append(int(booking.id))
            has_payload = bool(payment.receipt_file or payment.receipt_file_name or payment.receipt_text)
            if not has_payload:
                # It is still a stale pending-verification row; keep it in the
                # release-candidate list so a later run can recover from interruption.
                continue
            # Capture path, then remove the DB reference so it is no longer exposed.
            managed = _managed_path(payment.receipt_file, root)
            if managed is not None:
                paths_to_delete.add(managed)
            payment.receipt_file = None
            payment.receipt_file_name = None
            payment.receipt_text = None
            cleaned_rows += 1
        if cleaned_rows:
            await session.commit()
        else:
            await session.rollback()

    # A file could have been reused by an event upload or a replacement row; never
    # unlink any path that remains referenced after the transaction.
    if paths_to_delete:
        async with session_factory() as session:
            event_paths = (await session.execute(
                select(Event.questions_pdf_path, Event.cover_image_url)
            )).all()
            organization_paths = (await session.execute(select(Organization.logo_url))).scalars().all()
            brand_paths = (await session.execute(select(Brand.logo_url))).scalars().all()
            receipt_paths = (await session.execute(
                select(Payment.receipt_file).where(Payment.receipt_file.is_not(None))
            )).scalars().all()
        media_and_event_paths = [raw for row in event_paths for raw in row if raw]
        referenced = {
            managed for raw in [*media_and_event_paths, *organization_paths, *brand_paths, *receipt_paths]
            if (managed := _managed_path(raw, root)) is not None
        }
        for path in paths_to_delete - referenced:
            try:
                await asyncio.to_thread(path.unlink, missing_ok=True)
            except OSError:
                logger.exception("Could not delete expired receipt file %s", path)

    released_bookings: list[dict[str, object]] = []
    for booking_id in stale_unreviewed_booking_ids:
        try:
            async with session_factory() as session:
                booking = await session.get(Booking, booking_id, with_for_update=True)
                if not booking or booking.status != RegistrationStatus.PENDING_VERIFICATION:
                    await session.rollback()
                    continue
                # Match the established lock order: booking -> event -> payment.
                event = await session.get(Event, int(booking.event_id), with_for_update=True)
                payment = (await session.execute(
                    select(Payment).where(Payment.booking_id == booking_id).with_for_update()
                )).scalar_one_or_none()
                if (
                    not event or not payment
                    or payment.status != PaymentStatus.PENDING
                    or payment.receipt_uploaded_at is None
                    or payment.receipt_uploaded_at > cutoff
                    or payment.receipt_file or payment.receipt_text or payment.receipt_file_name
                ):
                    # A replacement receipt or an admin decision won the race. Do not
                    # expire the updated reservation.
                    await session.rollback()
                    continue
                owner = await session.get(User, int(booking.booked_by_user_id))
                booking.status = RegistrationStatus.REJECTED
                booking.cancelled_at = current
                booking.expires_at = None
                payment.status = PaymentStatus.REJECTED
                payment.reviewed_at = current
                payment.reviewed_by = None
                released_notice = {
                    "booking_id": int(booking.id),
                    "event_id": int(event.id),
                    "event_label": f"{volume_label(event.volume)} — {event.title}",
                    "user_telegram_id": int(owner.telegram_id) if owner else None,
                }
                await session.commit()
                # Only announce/reconcile after the state transition actually commits.
                released_bookings.append(released_notice)
        except Exception:
            logger.exception("Could not release reservation after receipt retention; booking_id=%s", booking_id)

    # Once the DB transition is committed, notifications and waitlist/channel updates
    # are best-effort side effects. They must never roll back the released seat.
    if bot is not None and released_bookings:
        from app.bot.keyboards import retry_payment_keyboard
        from app.services.channel_status import reconcile_event_channel_status
        from app.services.waitlist import notify_waitlist_capacity_available
        for item in released_bookings:
            telegram_id = item.get("user_telegram_id")
            if telegram_id:
                try:
                    retention_fa = str(retention_days).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))
                    await bot.send_message(
                        int(telegram_id),
                        f"⏳ رسید این رزرو بیش از {retention_fa} روز در انتظار بررسی بود و فایل آن طبق سیاست نگهداری حذف شد. "
                        "برای جلوگیری از نگه‌داشتن صندلی بدون رسید قابل بررسی، رزرو از حالت انتظار خارج شده است. "
                        "اگر ثبت‌نام پنل هنوز باز و ظرفیت موجود باشد، از «ثبت‌نام‌های من» می‌توانید دوباره اقدام کنید.",
                        reply_markup=retry_payment_keyboard(int(item["booking_id"])),
                    )
                except Exception:
                    logger.info("Could not notify user after stale receipt cleanup; booking_id=%s", item["booking_id"], exc_info=True)
            try:
                await reconcile_event_channel_status(bot, int(item["event_id"]))
            except Exception:
                logger.exception("Could not reconcile channel after stale receipt cleanup; event_id=%s", item["event_id"])
            try:
                await notify_waitlist_capacity_available(bot, int(item["event_id"]))
            except Exception:
                logger.exception("Could not notify waitlist after stale receipt cleanup; event_id=%s", item["event_id"])

    if cleaned_rows:
        logger.info(
            "Purged stored receipt content for %d payment(s) older than %d days; payment history retained; stale unreviewed seats released=%d",
            cleaned_rows, retention_days, len(released_bookings),
        )
    return cleaned_rows


async def cleanup_orphan_uploads_once(*, session_factory=None, now: datetime | None = None, bot=None) -> int:
    """Apply receipt retention, then delete any old unreferenced managed uploads."""
    if session_factory is None:
        from app.db.session import SessionLocal
        session_factory = SessionLocal

    expired_receipts = await cleanup_expired_receipts_once(session_factory=session_factory, now=now, bot=bot)
    root = Path(settings.upload_dir).resolve()
    # Reclaim interrupted download artifacts and expired quota leases separately
    # from ordinary orphan retention; temporary files must not linger for 30 days.
    stale_upload_artifacts = await asyncio.to_thread(cleanup_stale_upload_artifacts, root)
    async with session_factory() as session:
        event_rows = (await session.execute(select(Event.questions_pdf_path, Event.cover_image_url))).all()
        organization_paths = (await session.execute(select(Organization.logo_url))).scalars().all()
        brand_paths = (await session.execute(select(Brand.logo_url))).scalars().all()
        receipt_paths = (await session.execute(select(Payment.receipt_file).where(Payment.receipt_file.is_not(None)))).scalars().all()
    event_paths = [raw for row in event_rows for raw in row if raw]
    referenced = {
        managed for raw in [*event_paths, *organization_paths, *brand_paths, *receipt_paths]
        if (managed := _managed_path(raw, root)) is not None
    }
    instant = now or datetime.now(timezone.utc)
    retention_days = max(1, int(settings.upload_orphan_retention_days))
    cutoff = instant.timestamp() - retention_days * 24 * 60 * 60
    orphan_count = await asyncio.to_thread(prune_orphan_files, root, referenced, cutoff_epoch=cutoff)
    if orphan_count:
        logger.info("Removed %d orphan upload(s) older than %d days", orphan_count, retention_days)
    return expired_receipts + orphan_count + stale_upload_artifacts


async def periodic_orphan_upload_cleanup(interval_seconds: int = 24 * 60 * 60, *, bot=None) -> None:
    """Run receipt retention and orphan cleanup daily; failures never stop the bot."""
    while True:
        try:
            await cleanup_orphan_uploads_once(bot=bot)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic upload cleanup failed")
        await asyncio.sleep(interval_seconds)
