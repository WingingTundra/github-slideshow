"""Admin-only, formula-safe workbook for booking/payment reconciliation."""
from __future__ import annotations

from datetime import timezone
from io import BytesIO
from typing import Iterable

import xlsxwriter


BOOKING_LABELS = {
    "initiated": "In progress",
    "pending_payment": "Awaiting payment",
    "pending_verification": "Awaiting receipt review",
    "confirmed": "Confirmed",
    "rejected": "Receipt rejected",
    "cancelled": "Cancelled",
    "expired": "Payment window expired",
    "waitlisted": "Waitlisted",
}
PAYMENT_LABELS = {
    "pending": "Pending",
    "approved": "Approved",
    "rejected": "Receipt rejected",
    "not_required": "Not required",
}
RESOLUTION_LABELS = {
    "not_required": "Not required",
    "action_required": "Financial follow-up required",
    "refunded": "Refund completed",
    "credited": "Compensation credit recorded",
    "transferred": "Transferred to another panel",
    "other": "Other resolution",
}


def _raw(value) -> str:
    return str(getattr(value, "value", value) or "")


def _timestamp(value) -> str:
    if value is None:
        return "—"
    if getattr(value, "tzinfo", None) is not None:
        value = value.astimezone(timezone.utc).replace(tzinfo=None)
    return value.strftime("%Y-%m-%d %H:%M:%S UTC")


def _text(sheet, row: int, col: int, value, fmt=None) -> None:
    text = "—" if value is None or value == "" else str(value)
    sheet.write_string(row, col, text, fmt)


def build_financial_reconciliation_workbook(event, bookings: Iterable, reviewed_by_telegram_ids: dict[int, int] | None = None) -> bytes:
    """Return a workbook with booking-level ledger plus non-destructive status summary.

    This is a reconciliation aid, not proof that money moved: approved payments and
    cancellation resolutions reflect bot records and should be checked against the
    actual bank/payment provider before closing accounts.
    """
    bookings = list(bookings)
    reviewed_by_telegram_ids = reviewed_by_telegram_ids or {}
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output, {
        "in_memory": True, "strings_to_formulas": False, "strings_to_urls": False,
    })
    workbook.set_properties({
        "title": "PANEL FLOW — Financial Reconciliation",
        "subject": "Private administrator booking/payment reconciliation",
        "author": "PANEL FLOW",
    })
    title_fmt = workbook.add_format({"bold": True, "font_size": 15, "font_color": "#FFFFFF", "bg_color": "#17365D", "align": "right"})
    header_fmt = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#4472C4", "text_wrap": True, "align": "center", "valign": "vcenter"})
    label_fmt = workbook.add_format({"bold": True, "bg_color": "#D9EAF7", "align": "right"})
    money_fmt = workbook.add_format({"num_format": "#,##0", "align": "right"})
    text_fmt = workbook.add_format({"text_wrap": True, "valign": "top"})

    summary = workbook.add_worksheet("Summary")
    summary.hide_gridlines(2)
    summary.right_to_left()
    summary.set_column("A:A", 35)
    summary.set_column("B:B", 30)
    summary.merge_range("A1:B1", f"تطبیق مالی — {getattr(event, 'volume', '')} — {getattr(event, 'title', '')}", title_fmt)
    summary.write("A3", "شاخص", header_fmt)
    summary.write("B3", "مقدار", header_fmt)
    summary_rows: list[tuple[str, object, bool]] = [
        ("تعداد کل رزروها", len(bookings), False),
        ("رزروهای تأییدشده", sum(_raw(b.status) == "confirmed" for b in bookings), False),
        ("رزروهای لغوشده", sum(_raw(b.status) == "cancelled" for b in bookings), False),
        ("پرونده‌های مالی باز", sum(_raw(getattr(b, "cancellation_resolution", None)) == "action_required" for b in bookings), False),
        ("مبلغ اسمی رزروها (تومان)", sum(max(0, int(getattr(b, "total_amount", 0) or 0)) for b in bookings), True),
    ]
    for status, label in [*PAYMENT_LABELS.items(), ("missing", "رکورد پرداخت یافت نشد")]:
        matching = [b for b in bookings if (_raw(getattr(b, "payment", None).status) if getattr(b, "payment", None) is not None else ("not_required" if int(getattr(b, "total_amount", 0) or 0) == 0 else "missing")) == status]
        if not matching:
            continue
        summary_rows.append((f"تعداد — {label}", len(matching), False))
        summary_rows.append((f"مبلغ — {label} (تومان)", sum(max(0, int(getattr(b, "total_amount", 0) or 0)) for b in matching), True))
    for idx, (label, value, is_money) in enumerate(summary_rows, start=3):
        summary.write_string(idx, 0, label, label_fmt)
        if is_money:
            summary.write_number(idx, 1, int(value), money_fmt)
        else:
            summary.write_number(idx, 1, int(value))
    note_row = len(summary_rows) + 5
    summary.merge_range(note_row, 0, note_row + 1, 1, "این فایل گزارش سامانه است و به‌تنهایی اثبات‌کننده جابه‌جایی واقعی وجه نیست. وضعیت بانکی/درگاه و هر بازپرداخت را جداگانه تطبیق دهید.", text_fmt)
    summary.freeze_panes(3, 0)

    ledger = workbook.add_worksheet("Transactions")
    ledger.hide_gridlines(2)
    ledger.right_to_left()
    headers = [
        "شناسه رزرو", "نام رزروکننده", "نام کاربری تلگرام", "Telegram ID", "تعداد نفرات",
        "وضعیت رزرو", "وضعیت پرداخت", "مبلغ رزرو (تومان)", "تخفیف (تومان)",
        "نام فایل رسید", "شناسه تلگرام مدیر بررسی‌کننده", "وضعیت پرونده مالی",
        "توضیح پرونده مالی", "زمان ایجاد رزرو (UTC)", "زمان ارسال رسید (UTC)", "زمان بررسی پرداخت (UTC)",
    ]
    ledger.set_row(0, 36)
    ledger.write_row(0, 0, headers, header_fmt)
    widths = [13, 26, 22, 18, 13, 22, 20, 20, 16, 28, 24, 24, 42, 23, 23, 23]
    for col, width in enumerate(widths):
        ledger.set_column(col, col, width)
    for row, booking in enumerate(bookings, start=1):
        owner = getattr(booking, "booked_by", None)
        payment = getattr(booking, "payment", None)
        owner_name = getattr(owner, "display_name", None) or " ".join(part for part in [getattr(owner, "first_name", None), getattr(owner, "last_name", None)] if part) or "—"
        username = getattr(owner, "telegram_username", None) or "—"
        payment_status = _raw(payment.status) if payment is not None else ("not_required" if int(getattr(booking, "total_amount", 0) or 0) == 0 else "missing")
        payment_label = PAYMENT_LABELS.get(payment_status, "رکورد پرداخت یافت نشد" if payment_status == "missing" else payment_status)
        booking_label = BOOKING_LABELS.get(_raw(booking.status), _raw(booking.status) or "—")
        resolution = _raw(getattr(booking, "cancellation_resolution", None)) or "not_required"
        values = [
            int(booking.id), owner_name, username, int(owner.telegram_id) if owner and getattr(owner, "telegram_id", None) is not None else "—",
            int(getattr(booking, "participant_count", 0) or 0), booking_label, payment_label,
            max(0, int(getattr(booking, "total_amount", 0) or 0)), max(0, int(getattr(booking, "discount_amount", 0) or 0)),
            getattr(payment, "receipt_file_name", None) if payment is not None else "—",
            reviewed_by_telegram_ids.get(int(payment.reviewed_by)) if payment is not None and getattr(payment, "reviewed_by", None) is not None else "—",
            RESOLUTION_LABELS.get(resolution, resolution), getattr(booking, "cancellation_resolution_note", None) or "—",
            _timestamp(getattr(booking, "created_at", None)), _timestamp(getattr(payment, "receipt_uploaded_at", None)) if payment is not None else "—",
            _timestamp(getattr(payment, "reviewed_at", None)) if payment is not None else "—",
        ]
        for col, value in enumerate(values):
            if col in {0, 3, 4, 7, 8, 10} and isinstance(value, int):
                fmt = money_fmt if col in {7, 8} else None
                ledger.write_number(row, col, value, fmt)
            else:
                _text(ledger, row, col, value, text_fmt)
        ledger.set_row(row, 30)
    if bookings:
        ledger.autofilter(0, 0, len(bookings), len(headers) - 1)
    ledger.freeze_panes(1, 2)
    ledger.set_landscape()
    ledger.fit_to_pages(1, 0)
    workbook.close()
    return output.getvalue()
