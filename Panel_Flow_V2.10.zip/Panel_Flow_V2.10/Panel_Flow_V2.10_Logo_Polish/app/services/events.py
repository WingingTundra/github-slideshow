from __future__ import annotations

from enum import Enum

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Booking, Event, EventStatus, RegistrationStatus

ACTIVE_BOOKING_STATUSES = (
    RegistrationStatus.PENDING_PAYMENT,
    RegistrationStatus.PENDING_VERIFICATION,
    RegistrationStatus.CONFIRMED,
)


class DisplayEventStatus(str, Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    OPEN = "registration_open"
    CLOSED = "closed"
    POSTPONED = "postponed"
    FULL = "full"
    COMPLETED = "completed"
    ARCHIVED = "archived"
    CANCELLED = "cancelled"


def publish_event(event: Event) -> None:
    """Publish a panel and open registration immediately.

    Panel dates are presentation-only text. The application never parses them and
    never opens/closes registration because of the supplied day/date text.
    """
    # Publishing is a draft -> published transition, not an alternative way to
    # reopen a manually closed panel or undo a completed/cancelled lifecycle state.
    if event.archived or event.status != EventStatus.DRAFT:
        raise ValueError("EVENT_NOT_PUBLISHABLE")
    from app.services.event_lifecycle import transition_event
    try:
        transition_event(event, EventStatus.PUBLISHED)
    except ValueError as exc:
        raise ValueError("EVENT_NOT_PUBLISHABLE") from exc
    event.registration_open = True
    event.registration_closed_reason = None


def registration_is_open(event: Event) -> bool:
    """Single source of truth for whether a published panel accepts sign-ups."""
    return bool(
        event
        and event.status == EventStatus.PUBLISHED
        and not event.archived
        and not bool(getattr(event, "is_postponed", False))
        and event.registration_open
    )


def waitlist_is_available(event: Event, used: int) -> bool:
    """The waitlist remains available when a published panel is full.

    A full panel is automatically registration-closed, so tying this condition to
    registration_is_open() would make the waitlist button unreachable.
    """
    return bool(
        event
        and event.status == EventStatus.PUBLISHED
        and not event.archived
        and not bool(getattr(event, "is_postponed", False))
        and event.waitlist_enabled
        and int(used) >= int(event.capacity)
    )



def participant_events_statement():
    """All published, non-archived panels; registration availability is shown per panel."""
    return select(Event).where(
        Event.status == EventStatus.PUBLISHED,
        Event.archived.is_(False),
    ).order_by(Event.id.desc())


def announcement_events_statement():
    """Manually announce any published, non-archived panel regardless of registration state."""
    return select(Event).where(
        Event.status == EventStatus.PUBLISHED,
        Event.archived.is_(False),
    ).order_by(Event.id.desc())


async def seats_used(session: AsyncSession, event_id: int) -> int:
    result = await session.execute(
        select(func.coalesce(func.sum(Booking.participant_count), 0)).where(
            Booking.event_id == event_id,
            Booking.status.in_(ACTIVE_BOOKING_STATUSES),
        )
    )
    return int(result.scalar_one())


def display_status(event: Event, used: int = 0) -> DisplayEventStatus:
    if event.archived:
        return DisplayEventStatus.ARCHIVED
    if event.status == EventStatus.CANCELLED:
        return DisplayEventStatus.CANCELLED
    if event.status == EventStatus.DRAFT:
        return DisplayEventStatus.DRAFT
    if event.status == EventStatus.COMPLETED:
        return DisplayEventStatus.COMPLETED
    if bool(getattr(event, "is_postponed", False)):
        return DisplayEventStatus.POSTPONED
    if used >= event.capacity:
        return DisplayEventStatus.FULL
    if not registration_is_open(event):
        return DisplayEventStatus.CLOSED
    return DisplayEventStatus.OPEN


def apply_capacity_change(event: Event, old_capacity: int, new_capacity: int, reserved_seats: int) -> None:
    """Apply an admin capacity edit without allowing impossible seat state.

    A panel closed automatically by capacity reopens when its capacity is increased
    above the currently reserved seats. A manually closed panel remains closed.
    """
    if new_capacity <= 0:
        raise ValueError("INVALID_CAPACITY")
    if new_capacity < reserved_seats:
        raise ValueError("CAPACITY_BELOW_RESERVED")
    event.capacity = new_capacity
    if reserved_seats >= new_capacity:
        event.registration_open = False
        event.registration_closed_reason = "capacity"
    elif (new_capacity > old_capacity and event.registration_closed_reason == "capacity"
          and not bool(getattr(event, "is_postponed", False))):
        event.registration_open = True
        event.registration_closed_reason = None



async def participant_events_query(session: AsyncSession):
    return await session.execute(participant_events_statement())
