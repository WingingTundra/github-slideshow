"""Periodic maintenance for expiring payment holds and channel status."""
from __future__ import annotations

import asyncio
import logging

from app.services.booking import expire_old_bookings

logger = logging.getLogger(__name__)


async def expire_bookings_once(*, bot=None, session_factory=None, reconcile_func=None) -> set[int]:
    """Expire due pending-payment holds, commit first, then reconcile affected panels.

    The session factory and reconciler are injectable to keep the operation testable
    without a live Telegram bot or PostgreSQL service.
    """
    if session_factory is None:
        from app.db.session import SessionLocal
        session_factory = SessionLocal

    async with session_factory() as session:
        try:
            affected_event_ids = await expire_old_bookings(session)
            await session.commit()
        except Exception:
            await session.rollback()
            raise

    if bot is not None and affected_event_ids:
        if reconcile_func is None:
            from app.services.channel_status import reconcile_event_channel_status
            reconcile_func = reconcile_event_channel_status
        for event_id in sorted(affected_event_ids):
            try:
                await reconcile_func(bot, event_id)
            except Exception:
                logger.exception("Failed to reconcile channel status after reservation expiry for event_id=%s", event_id)
            try:
                from app.services.waitlist import notify_waitlist_capacity_available
                await notify_waitlist_capacity_available(bot, event_id)
            except Exception:
                logger.exception("Failed to notify waitlist after reservation expiry for event_id=%s", event_id)
    return affected_event_ids


async def periodic_booking_expiry(bot, interval_seconds: int = 60) -> None:
    """Run a safe reservation-expiry sweep throughout the bot's lifetime."""
    while True:
        try:
            await expire_bookings_once(bot=bot)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic reservation-expiry sweep failed")
        await asyncio.sleep(interval_seconds)
