"""Referral attribution rules for first-time Panel Flow onboarding."""
from __future__ import annotations

import re
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import User

_DIGIT_TRANSLATION = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")



async def count_referrals_for_telegram_id(session: AsyncSession, telegram_id: int) -> int:
    """Count successfully attributed users for a referrer, using internal user IDs."""
    referrer_id = select(User.id).where(
        User.telegram_id == int(telegram_id)
    ).scalar_subquery()
    total = (await session.execute(
        select(func.count(User.id)).where(User.referred_by_user_id == referrer_id)
    )).scalar_one()
    return int(total or 0)

def normalize_referral_code(raw: str | None) -> str:
    """Referral codes are numeric Telegram IDs; accept Persian/Arabic numerals too."""
    return (raw or "").strip().translate(_DIGIT_TRANSLATION)


async def resolve_referrer(session: AsyncSession, *, referral_code: str, invitee: User) -> User:
    """Validate a code and return a completed, different user who owns it."""
    normalized = normalize_referral_code(referral_code)
    if not re.fullmatch(r"[0-9]{1,19}", normalized):
        raise ValueError("INVALID_CODE")
    telegram_id = int(normalized)
    if telegram_id <= 0 or telegram_id > (2**63 - 1):
        raise ValueError("INVALID_CODE")
    if telegram_id == int(invitee.telegram_id):
        raise ValueError("SELF_REFERRAL")
    referrer = (await session.execute(
        select(User).where(User.telegram_id == telegram_id).with_for_update()
    )).scalar_one_or_none()
    if not referrer:
        raise ValueError("UNKNOWN_REFERRER")
    if not (str(referrer.first_name or "").strip()
            and str(referrer.last_name or "").strip()
            and str(referrer.phone_number or "").strip()):
        raise ValueError("INCOMPLETE_REFERRER")
    if int(referrer.id) == int(invitee.id):
        raise ValueError("SELF_REFERRAL")
    return referrer


async def attribute_referral(session: AsyncSession, *, invitee_telegram_id: int, referral_code: str) -> int:
    """Atomically attribute an invitee once, returning the referrer's internal user ID.

    The caller owns the transaction and must commit after this succeeds.
    Deterministic lock ordering prevents AB-BA deadlocks between mutual referrals.
    """
    normalized = normalize_referral_code(referral_code)
    if not re.fullmatch(r"[0-9]{1,19}", normalized):
        raise ValueError("INVALID_CODE")
    referrer_telegram_id = int(normalized)
    if referrer_telegram_id <= 0 or referrer_telegram_id > (2**63 - 1):
        raise ValueError("INVALID_CODE")
    if referrer_telegram_id == int(invitee_telegram_id):
        raise ValueError("SELF_REFERRAL")

    # Lock rows in deterministic sorted order to prevent deadlocks:
    first_id, second_id = sorted([int(invitee_telegram_id), referrer_telegram_id])
    user_rows = (await session.execute(
        select(User).where(User.telegram_id.in_([first_id, second_id]))
        .order_by(User.telegram_id.asc())
        .with_for_update()
        .execution_options(populate_existing=True)
    )).scalars().all()
    users_by_tg = {u.telegram_id: u for u in user_rows}

    invitee = users_by_tg.get(int(invitee_telegram_id))
    if not invitee:
        raise ValueError("INVITEE_NOT_FOUND")
    if invitee.referral_prompt_completed:
        raise ValueError("ALREADY_COMPLETED")
    if invitee.referred_by_user_id is not None:
        raise ValueError("ALREADY_REFERRED")

    referrer = users_by_tg.get(referrer_telegram_id)
    if not referrer:
        raise ValueError("UNKNOWN_REFERRER")
    if not (str(referrer.first_name or "").strip()
            and str(referrer.last_name or "").strip()
            and str(referrer.phone_number or "").strip()):
        raise ValueError("INCOMPLETE_REFERRER")
    if int(referrer.id) == int(invitee.id):
        raise ValueError("SELF_REFERRAL")

    invitee.referred_by_user_id = int(referrer.id)
    invitee.referral_prompt_completed = True
    return int(referrer.id)


async def skip_referral_prompt(session: AsyncSession, telegram_id: int) -> None:
    """Mark the optional first-signup referral step complete without attribution."""
    invitee = (await session.execute(
        select(User).where(User.telegram_id == int(telegram_id)).with_for_update()
    )).scalar_one_or_none()
    if not invitee:
        raise ValueError("INVITEE_NOT_FOUND")
    invitee.referral_prompt_completed = True
