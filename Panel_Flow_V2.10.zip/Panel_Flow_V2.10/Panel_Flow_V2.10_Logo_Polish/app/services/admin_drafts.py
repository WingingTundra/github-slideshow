"""Persistence helpers for recoverable administrative event wizards."""
from __future__ import annotations

import json
from sqlalchemy import delete
from app.db.models import AdminDraftSnapshot
from app.db.session import SessionLocal

RECOVERABLE_STATE_PREFIXES = ("AdminEventStates:", "AdminEditStates:")


def is_recoverable_admin_state(state_name: str | None) -> bool:
    return bool(state_name and state_name.startswith(RECOVERABLE_STATE_PREFIXES))


async def persist_admin_draft(telegram_id: int, state_name: str, data: dict) -> None:
    if not is_recoverable_admin_state(state_name):
        return
    serialized = json.dumps(data or {}, ensure_ascii=False, separators=(",", ":"), default=str)
    async with SessionLocal() as session:
        row = await session.get(AdminDraftSnapshot, int(telegram_id))
        if row is None:
            row = AdminDraftSnapshot(admin_telegram_id=int(telegram_id), state_name=state_name, data_json=serialized)
            session.add(row)
        else:
            row.state_name = state_name
            row.data_json = serialized
        await session.commit()


async def get_admin_draft(telegram_id: int) -> dict | None:
    async with SessionLocal() as session:
        row = await session.get(AdminDraftSnapshot, int(telegram_id))
        if row is None or not is_recoverable_admin_state(row.state_name):
            return None
        # Return detached data only, rather than a live ORM row.
        return {"state_name": row.state_name, "data": json.loads(row.data_json or "{}"), "updated_at": row.updated_at}


async def clear_admin_draft(telegram_id: int) -> None:
    async with SessionLocal() as session:
        await session.execute(delete(AdminDraftSnapshot).where(AdminDraftSnapshot.admin_telegram_id == int(telegram_id)))
        await session.commit()
