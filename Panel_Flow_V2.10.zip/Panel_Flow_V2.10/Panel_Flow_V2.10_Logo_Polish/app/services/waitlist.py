"""Service helpers for administrator-controlled waitlist invitations."""
from __future__ import annotations

from datetime import datetime, timedelta
import logging

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Event, EventStatus, User, WaitlistEntry
from app.display_utils import volume_label
from app.services.events import registration_is_open, seats_used
from app.time_utils import utc_now_naive

logger = logging.getLogger(__name__)

# Invitations are informational, not seat holds. Give the user a day to act; if
# they do not, return them to the end of the queue with a short retry cooldown.
WAITLIST_INVITATION_TTL = timedelta(hours=24)
WAITLIST_RETRY_COOLDOWN = timedelta(minutes=30)
ACTIVE_WAITLIST_STATUSES = ("waiting", "invited", "inviting")


def _eligible_after(entry: WaitlistEntry, now: datetime) -> bool:
    return entry.next_invite_after is None or entry.next_invite_after <= now


async def _remaining_invitation_budget(
    session: AsyncSession, event_id: int, free_seats: int, now: datetime
) -> int:
    """Return seats left in the *notification* budget, not the real capacity.

    Outstanding requests only count if their group currently fits by itself. A
    stale invitation for a group larger than the remaining capacity must not
    block invitations to smaller eligible groups. Active invitations are
    considered conservatively in aggregate so repeated triggers cannot message
    an unbounded number of people for the same seats.
    """
    if free_seats <= 0:
        return 0
    result = await session.execute(
        select(WaitlistEntry.requested_participant_count)
        .where(
            WaitlistEntry.event_id == int(event_id),
            WaitlistEntry.status.in_(("invited", "inviting")),
            WaitlistEntry.invitation_expires_at.is_not(None),
            WaitlistEntry.invitation_expires_at > now,
        )
        .order_by(WaitlistEntry.position.asc(), WaitlistEntry.created_at.asc(), WaitlistEntry.id.asc())
    )
    outstanding = 0
    for raw_count in result.scalars().all():
        requested = int(raw_count or 0)
        if 1 <= requested <= free_seats:
            outstanding += requested
    return max(0, int(free_seats) - outstanding)


async def next_waitlist_candidate(session: AsyncSession, event_id: int, *, now: datetime | None = None):
    """Return (event, entry, user, free_seats) for the oldest eligible request that fits.

    The event row is locked first to serialize manual invitation claims. A requested
    group larger than the available capacity is skipped so available seats can still
    be offered to smaller eligible requests. Cooldown entries stay queued but are
    temporarily ineligible for another notification.
    """
    current = now or utc_now_naive()
    event_result = await session.execute(
        select(Event)
        .where(Event.id == event_id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    event = event_result.scalar_one_or_none()
    if event is None:
        raise ValueError("EVENT_NOT_FOUND")
    if event.archived or event.status != EventStatus.PUBLISHED or not event.waitlist_enabled or bool(getattr(event, "is_postponed", False)):
        raise ValueError("WAITLIST_UNAVAILABLE")

    used = await seats_used(session, event.id)
    free_seats = max(0, int(event.capacity) - used)
    if free_seats <= 0:
        raise ValueError("NO_CAPACITY")
    if event.registration_closed_reason == "capacity" and not event.registration_open:
        event.registration_open = True
        event.registration_closed_reason = None
    if not registration_is_open(event):
        raise ValueError("REGISTRATION_CLOSED")

    # Invitations do not reserve seats, but they do consume the notification
    # budget. Without this guard, repeated maintenance runs could invite an
    # unbounded number of people for the same still-empty seat. Actual bookings
    # continue to compete normally; capacity is rechecked by the booking service.
    invitation_budget = await _remaining_invitation_budget(session, event.id, free_seats, current)
    if invitation_budget <= 0:
        raise ValueError("INVITATIONS_ALREADY_SENT")

    result = await session.execute(
        select(WaitlistEntry)
        .where(
            WaitlistEntry.event_id == event.id,
            WaitlistEntry.status == "waiting",
            or_(WaitlistEntry.next_invite_after.is_(None), WaitlistEntry.next_invite_after <= current),
        )
        .order_by(WaitlistEntry.position.asc(), WaitlistEntry.created_at.asc(), WaitlistEntry.id.asc())
        .with_for_update(skip_locked=True)
    )
    entries = result.scalars().all()
    for entry in entries:
        requested = int(entry.requested_participant_count or 0)
        if requested < 1 or requested > invitation_budget:
            continue
        user = await session.get(User, entry.user_id)
        if user is not None:
            return event, entry, user, free_seats

    raise ValueError("NO_ELIGIBLE_WAITLIST")


async def record_waitlist_invitation_result(
    entry_id: int,
    delivered: bool,
    *,
    session_factory=None,
    now: datetime | None = None,
) -> None:
    """Finish a committed invitation attempt without holding a transaction over Telegram I/O."""
    if session_factory is None:
        from app.db.session import SessionLocal
        session_factory = SessionLocal
    current = now or utc_now_naive()
    async with session_factory() as session:
        entry = await session.get(WaitlistEntry, int(entry_id), with_for_update=True)
        # A user/admin may have left/closed the queue entry while Telegram I/O was
        # in flight. Do not overwrite that newer state.
        if not entry or entry.status != "inviting":
            await session.rollback()
            return
        if delivered:
            entry.status = "invited"
            entry.invitation_expires_at = entry.invitation_expires_at or (current + WAITLIST_INVITATION_TTL)
            entry.next_invite_after = None
        else:
            entry.status = "waiting"
            entry.invitation_expires_at = None
            entry.next_invite_after = current + WAITLIST_RETRY_COOLDOWN
            maximum = int((await session.execute(
                select(func.coalesce(func.max(WaitlistEntry.position), 0)).where(
                    WaitlistEntry.event_id == entry.event_id,
                    WaitlistEntry.status.in_(ACTIVE_WAITLIST_STATUSES),
                )
            )).scalar_one())
            entry.position = maximum + 1
        await session.commit()


async def notify_waitlist_capacity_available(bot, event_id: int) -> int:
    """Send FIFO-ordered invitations within the currently available seat budget.

    Only candidates whose group size fits the remaining invitation budget are
    selected, and that budget is decremented after every claim. The claims are
    committed before Telegram I/O. Invitations do not reserve seats; the booking
    service remains authoritative and rechecks capacity transactionally.
    """
    from app.db.session import SessionLocal
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    selected: list[tuple[int, int, datetime]] = []
    current = utc_now_naive()
    async with SessionLocal() as session:
        event = (await session.execute(
            select(Event).where(Event.id == event_id).with_for_update().execution_options(populate_existing=True)
        )).scalar_one_or_none()
        if event is None or event.archived or event.status != EventStatus.PUBLISHED or bool(getattr(event, "is_postponed", False)):
            return 0
        used = await seats_used(session, event.id)
        free_seats = max(0, int(event.capacity) - used)
        if free_seats <= 0:
            return 0

        # Only the automatic full-capacity closure may be reopened by freed/new
        # capacity. Manual closures remain in force.
        if event.registration_closed_reason == "capacity" and not event.registration_open:
            event.registration_open = True
            event.registration_closed_reason = None
        if not event.waitlist_enabled or not registration_is_open(event):
            await session.commit()
            return 0

        entries = (await session.execute(
            select(WaitlistEntry)
            .where(
                WaitlistEntry.event_id == event.id,
                WaitlistEntry.status == "waiting",
                or_(WaitlistEntry.next_invite_after.is_(None), WaitlistEntry.next_invite_after <= current),
            )
            .order_by(WaitlistEntry.position.asc(), WaitlistEntry.created_at.asc(), WaitlistEntry.id.asc())
            .with_for_update(skip_locked=True)
        )).scalars().all()
        # Active invitations count against the notification budget only; they do
        # not decrement real capacity or reserve seats in the booking service.
        invite_budget = await _remaining_invitation_budget(session, event.id, free_seats, current)
        for entry in entries:
            requested = int(entry.requested_participant_count or 0)
            if requested < 1 or requested > invite_budget:
                continue
            expiry = current + WAITLIST_INVITATION_TTL
            entry.status = "inviting"
            entry.invitation_expires_at = expiry
            entry.next_invite_after = None
            selected.append((int(entry.id), requested, expiry))
            invite_budget -= requested
            if invite_budget == 0:
                break

        title = event.title
        volume = event.volume
        actual_event_id = event.id
        await session.commit()

    if not selected:
        return 0

    try:
        bot_info = await bot.get_me()
        if not bot_info.username:
            raise RuntimeError("BOT_USERNAME_UNAVAILABLE")
        invite_url = f"https://t.me/{bot_info.username}?start=event_{actual_event_id}"
    except Exception:
        logger.exception("Could not prepare waitlist invitations for event_id=%s", actual_event_id)
        for entry_id, _requested, _expiry in selected:
            try:
                await record_waitlist_invitation_result(entry_id, False)
            except Exception:
                logger.exception("Could not reset invitation claim after setup failure; entry_id=%s", entry_id)
        return 0

    from html import escape
    sent = 0
    for entry_id, requested, _expiry in selected:
        async with SessionLocal() as session:
            entry = await session.get(WaitlistEntry, entry_id, with_for_update=True)
            event = await session.get(Event, actual_event_id)
            user = await session.get(User, entry.user_id) if entry else None
            if not entry or not user or entry.status != "inviting":
                await session.rollback()
                continue
            # A host may pause the queue after a notification claim was committed
            # but before this Telegram send. Re-check current event policy at the
            # point of delivery and preserve the queued request without messaging.
            if (not event or event.archived or event.status != EventStatus.PUBLISHED
                or not event.waitlist_enabled or bool(getattr(event, "is_postponed", False))):
                # A paused/disabled queue is preserved for a later explicit resume;
                # a cancelled, completed or archived panel permanently closes it.
                entry.status = "waiting" if event and event.status == EventStatus.PUBLISHED and not event.archived else "closed"
                entry.invitation_expires_at = None
                entry.next_invite_after = None
                await session.commit()
                continue
            telegram_id = int(user.telegram_id)
            await session.commit()
        try:
            await bot.send_message(
                telegram_id,
                f"📨 برای پنل <b>{volume_label(volume)} — {escape(title)}</b> ظرفیت خالی شده است.\n\n"
                f"درخواست شما برای {requested} نفر در لیست انتظار ثبت شده بود. اکنون نوبت شما برای اقدام رسیده است؛ تا ۲۴ ساعت آینده برای ثبت‌نام اقدام کنید.\n\n"
                "این پیام رزرو یا نگه‌داشتن ظرفیت محسوب نمی‌شود؛ ظرفیت هنگام ثبت‌نام دوباره بررسی خواهد شد.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="🎟 ادامهٔ ثبت‌نام", url=invite_url)
                ]]),
                disable_web_page_preview=True,
            )
            delivered = True
            sent += 1
        except Exception:
            logger.exception("Waitlist invitation delivery failed for event_id=%s entry_id=%s", actual_event_id, entry_id)
            delivered = False
        try:
            await record_waitlist_invitation_result(entry_id, delivered)
        except Exception:
            logger.exception("Could not record waitlist invitation result for entry_id=%s", entry_id)
    return sent


async def expire_waitlist_invitations_once(*, session_factory=None, now: datetime | None = None) -> set[int]:
    """Expire old invitation claims and return events ready for the next invite sweep.

    An unused invite goes back to the queue's tail and is temporarily cooled down,
    giving other eligible users priority. Expired invitations for cancelled,
    archived, or waitlist-disabled panels are closed instead of resurrected.
    """
    if session_factory is None:
        from app.db.session import SessionLocal
        session_factory = SessionLocal
    current = now or utc_now_naive()
    ready_event_ids: set[int] = set()

    async with session_factory() as session:
        expired_event_ids = set((await session.execute(
            select(WaitlistEntry.event_id).distinct().where(
                WaitlistEntry.status.in_(("invited", "inviting")),
                WaitlistEntry.invitation_expires_at.is_not(None),
                WaitlistEntry.invitation_expires_at <= current,
            )
        )).scalars().all())
        for event_id in sorted(int(value) for value in expired_event_ids):
            event = (await session.execute(
                select(Event).where(Event.id == event_id).with_for_update()
            )).scalar_one_or_none()
            expired_entries = (await session.execute(
                select(WaitlistEntry).where(
                    WaitlistEntry.event_id == event_id,
                    WaitlistEntry.status.in_(("invited", "inviting")),
                    WaitlistEntry.invitation_expires_at.is_not(None),
                    WaitlistEntry.invitation_expires_at <= current,
                ).order_by(WaitlistEntry.position.asc(), WaitlistEntry.id.asc()).with_for_update(skip_locked=True)
            )).scalars().all()
            if not expired_entries:
                continue
            is_usable = bool(
                event and event.status == EventStatus.PUBLISHED and not event.archived
            )
            max_position = int((await session.execute(
                select(func.coalesce(func.max(WaitlistEntry.position), 0)).where(
                    WaitlistEntry.event_id == event_id,
                    WaitlistEntry.status.in_(ACTIVE_WAITLIST_STATUSES),
                )
            )).scalar_one())
            for entry in expired_entries:
                if not is_usable:
                    entry.status = "closed"
                    entry.invitation_expires_at = None
                    entry.next_invite_after = None
                else:
                    max_position += 1
                    entry.status = "waiting"
                    entry.position = max_position
                    entry.invitation_expires_at = None
                    entry.next_invite_after = current + WAITLIST_RETRY_COOLDOWN
        await session.commit()

    # Find all event queues that have cooled down and currently have capacity. This
    # makes recovery automatic even if no new cancellation/capacity edit occurs.
    async with session_factory() as session:
        candidate_event_ids = set((await session.execute(
            select(WaitlistEntry.event_id).distinct()
            .join(Event, Event.id == WaitlistEntry.event_id)
            .where(
                WaitlistEntry.status == "waiting",
                or_(WaitlistEntry.next_invite_after.is_(None), WaitlistEntry.next_invite_after <= current),
                Event.status == EventStatus.PUBLISHED,
                Event.archived.is_(False),
                Event.waitlist_enabled.is_(True),
                Event.is_postponed.is_(False),
            )
        )).scalars().all())
        for event_id in sorted(int(value) for value in candidate_event_ids):
            event = (await session.execute(
                select(Event).where(Event.id == event_id).with_for_update().execution_options(populate_existing=True)
            )).scalar_one_or_none()
            if (not event or event.archived or event.status != EventStatus.PUBLISHED
                or not event.waitlist_enabled or bool(getattr(event, "is_postponed", False))):
                continue
            used = await seats_used(session, event.id)
            if used >= int(event.capacity):
                continue
            if event.registration_closed_reason == "capacity" and not event.registration_open:
                event.registration_open = True
                event.registration_closed_reason = None
            if registration_is_open(event):
                ready_event_ids.add(int(event.id))
        await session.commit()
    return ready_event_ids


async def periodic_waitlist_maintenance(bot, interval_seconds: int = 60) -> None:
    """Recover stale invitations and send newly eligible FIFO invitations periodically."""
    import asyncio

    while True:
        try:
            ready_event_ids = await expire_waitlist_invitations_once()
            for event_id in sorted(ready_event_ids):
                try:
                    await notify_waitlist_capacity_available(bot, event_id)
                except Exception:
                    logger.exception("Waitlist maintenance notification failed for event_id=%s", event_id)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic waitlist maintenance failed")
        await asyncio.sleep(max(10, int(interval_seconds)))
