"""Small transactional writer for high-value administrator audit events."""
from __future__ import annotations

import json
from datetime import timezone
from typing import Any

from sqlalchemy import select

from app.config import settings
from app.db.models import AdminAction, User, UserRole
from app.time_utils import utc_now_naive


async def write_admin_action(
    session,
    *,
    actor_telegram_id: int,
    action: str,
    entity_type: str,
    entity_id: int | None = None,
    details: dict[str, Any] | str | None = None,
) -> AdminAction:
    """Add an audit row to the caller's transaction; caller owns commit/rollback."""
    actor_telegram_id = int(actor_telegram_id)
    actor = (await session.execute(
        select(User).where(User.telegram_id == actor_telegram_id).with_for_update()
    )).scalar_one_or_none()
    is_protected_owner = actor_telegram_id in settings.super_admin_id_set
    if actor is None:
        if not is_protected_owner:
            raise PermissionError("AUDIT_ACTOR_NOT_ADMIN")
        actor = User(telegram_id=actor_telegram_id, role=UserRole.SUPER_ADMIN)
        session.add(actor)
        await session.flush()
    elif is_protected_owner:
        # The configured owner allow-list remains authoritative; repair a stale role.
        if actor.role != UserRole.SUPER_ADMIN:
            actor.role = UserRole.SUPER_ADMIN
    elif actor.role != UserRole.SUPER_ADMIN:
        raise PermissionError("AUDIT_ACTOR_NOT_ADMIN")
    if isinstance(details, dict):
        safe_details = json.dumps(details, ensure_ascii=False, default=str, separators=(",", ":"))[:4000]
    else:
        safe_details = (str(details)[:4000] if details is not None else None)
    row = AdminAction(
        actor_user_id=int(actor.id), action=str(action)[:100],
        entity_type=str(entity_type)[:100], entity_id=int(entity_id) if entity_id is not None else None,
        details=safe_details, created_at=utc_now_naive(),
    )
    session.add(row)
    await session.flush()
    return row


def format_admin_action_log(
    *,
    actor_telegram_id: int,
    action: str,
    entity_type: str,
    entity_id: int | None,
    details: str | None,
    created_at,
) -> str:
    """Format one bounded, HTML-safe audit entry for the admin-only Telegram UI."""
    from html import escape

    moment = created_at
    if moment is None:
        timestamp = "زمان نامشخص"
    else:
        if getattr(moment, "tzinfo", None) is not None:
            moment = moment.astimezone(timezone.utc).replace(tzinfo=None)
        timestamp = moment.strftime("%Y-%m-%d %H:%M UTC")
    compact_details = " ".join(str(details or "").split())[:220]
    entity_label = escape(str(entity_type or "—")[:80])
    entity_reference = f" #{int(entity_id)}" if entity_id is not None else ""
    parts = [
        f"🕒 <code>{escape(timestamp)}</code>",
        f"مدیر: <a href=\"tg://user?id={int(actor_telegram_id)}\">{int(actor_telegram_id)}</a>",
        f"اقدام: <b>{escape(str(action or '—')[:100])}</b>",
        f"مورد: {entity_label}{entity_reference}",
    ]
    if compact_details:
        parts.append(f"جزئیات: {escape(compact_details)}")
    return "\n".join(parts)
