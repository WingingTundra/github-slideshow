"""Idempotent lifetime counters for bookings entering the confirmed state."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Booking, BookingConfirmationLedger, User
from app.time_utils import utc_now_naive


async def record_confirmed_booking(
    session: AsyncSession,
    booking: Booking,
    *,
    confirmed_at: datetime | None = None,
) -> bool:
    """Increment a user's lifetime total once for this booking, inside caller transaction.

    The caller must call this only when a booking genuinely transitions into CONFIRMED
    and should hold a row lock on the booking when changing an existing reservation.
    The unique ledger constraint is the durable idempotency boundary.
    """
    if not booking.id:
        await session.flush()
    # Serialize counter changes for one stable user ID. The ledger lookup happens
    # after this lock so a concurrent retry for the same booking observes the
    # first transaction's committed ledger row rather than attempting a duplicate
    # increment. Refresh avoids adding to an out-of-date identity-map value.
    owner = (await session.execute(
        select(User)
        .where(User.id == booking.booked_by_user_id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )).scalar_one_or_none()
    if owner is None:
        raise RuntimeError("Booking owner missing while recording confirmation")

    existing = (await session.execute(
        select(BookingConfirmationLedger).where(BookingConfirmationLedger.booking_id == booking.id)
    )).scalar_one_or_none()
    if existing is not None:
        return False

    when = confirmed_at or booking.confirmed_at or utc_now_naive()
    session.add(BookingConfirmationLedger(
        user_id=booking.booked_by_user_id,
        booking_id=booking.id,
        confirmed_at=when,
    ))
    owner.lifetime_confirmed_bookings = int(owner.lifetime_confirmed_bookings or 0) + 1
    # Flush within the same transaction so ledger uniqueness errors are not mistaken
    # for a successful confirmation/counter increment.
    await session.flush()
    return True
