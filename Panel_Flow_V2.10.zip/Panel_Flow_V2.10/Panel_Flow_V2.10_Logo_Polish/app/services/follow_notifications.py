"""Backward-compatible import path for followed-panel notifications.

The V2.03 delivery ledger consolidates all discovery and booking reminders in
:mod:`app.services.event_notifications`; keep this module as a stable shim for
older internal imports and integrations.
"""
from app.services.event_notifications import send_new_panel_follow_notifications

__all__ = ["send_new_panel_follow_notifications"]
