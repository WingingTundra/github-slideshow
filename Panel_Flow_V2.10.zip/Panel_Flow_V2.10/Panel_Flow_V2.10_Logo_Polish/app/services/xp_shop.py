"""Focused, reusable XP Shop read-side rules.

The XPAward ledger remains the source of truth. Shop reservations are pending requests,
not debits, and delivery presentation is derived from the reward-issuance record.
"""
from __future__ import annotations

import json
from statistics import median
from typing import Iterable, Any

from sqlalchemy import func, or_, select

from app.db.models import AppSetting, RewardIssue, ShopRequest
from app.services.app_settings import get_setting
from app.display_utils import status_display_label
from app.time_utils import utc_now_naive

SHOP_DEFAULT_COSTS = {15: 20, 25: 40, 50: 80, 100: 160}


async def configured_shop_costs(session) -> dict[int, int]:
    raw = await get_setting(session, "v77_my_shop_costs")
    try:
        parsed = json.loads(raw) if raw else {}
        if not isinstance(parsed, dict):
            raise ValueError
        costs = {p: int(parsed.get(str(p), SHOP_DEFAULT_COSTS[p])) for p in SHOP_DEFAULT_COSTS}
        if any(value < 1 or value > 1_000_000 for value in costs.values()):
            raise ValueError
        return costs
    except (TypeError, ValueError, json.JSONDecodeError):
        return dict(SHOP_DEFAULT_COSTS)


async def reserved_shop_xp(session, telegram_id: int, *, exclude_request_id: int | None = None) -> int:
    stmt = select(func.coalesce(func.sum(ShopRequest.xp_cost), 0)).where(
        ShopRequest.telegram_id == int(telegram_id), ShopRequest.status == "pending"
    )
    if exclude_request_id is not None:
        stmt = stmt.where(ShopRequest.id != int(exclude_request_id))
    return int(await session.scalar(stmt) or 0)


def available_shop_xp(ledger_balance: int, reserved: int) -> int:
    """Return non-negative spendable XP after pending requests are reserved."""
    return max(0, int(ledger_balance) - int(reserved))


def shop_request_status_label(request_status: str, reward_status: str | None = None) -> str:
    """Present the actual reward issue stage, not only the older ShopRequest stage."""
    if reward_status:
        reward_labels = {
            "awaiting_code": "Approved · preparing reward",
            "ready_to_deliver": "Reward ready · awaiting delivery",
            "sending": "Delivery in progress",
            "delivery_uncertain": "Delivery status requires Admin review",
            "delivery_failed": "Delivery failed · Admin action required",
            "delivered": "Delivered",
            "refunded": "XP refunded",
        }
        if reward_status in reward_labels:
            return reward_labels[reward_status]
    request_labels = {
        "pending": "Awaiting review",
        "awaiting_code": "Approved · preparing reward",
        "denied": "Rejected",
        "cancelled": "Cancelled",
        "refunded": "XP refunded",
        "delivered": "Delivered",
    }
    return request_labels.get(str(request_status), status_display_label(request_status))


def shop_economy_summary(available_balances: Iterable[int], costs: dict[int, int]) -> dict[str, Any]:
    """Aggregate-only snapshot for tuning costs; never returns user-level data."""
    balances = [max(0, int(value)) for value in available_balances]
    total = len(balances)
    return {
        "registered_users": total,
        "median_available_xp": int(median(balances)) if balances else 0,
        "affordable_counts": {
            percent: sum(1 for balance in balances if balance >= int(costs[percent]))
            for percent in (15, 25, 50, 100)
        },
    }

# V94 configurable catalogue. The legacy cost reader above remains for old admin
# callbacks and historical compatibility; new requests use immutable offer snapshots.
SHOP_ENABLED_KEY = "xp_shop_enabled"


def parse_setting_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "enabled"}


async def shop_is_enabled(session) -> bool:
    return parse_setting_bool(await get_setting(session, SHOP_ENABLED_KEY), False)


async def set_shop_enabled(session, enabled: bool) -> None:
    from app.services.app_settings import set_setting
    await set_setting(session, SHOP_ENABLED_KEY, "true" if enabled else "false")


async def list_shop_offers(session, *, active_only: bool = False):
    from app.db.models import XPShopOffer
    stmt = select(XPShopOffer).order_by(XPShopOffer.sort_order.asc(), XPShopOffer.id.asc())
    if active_only:
        now = utc_now_naive()
        stmt = stmt.where(
            XPShopOffer.active.is_(True),
            or_(XPShopOffer.expires_at.is_(None), XPShopOffer.expires_at > now),
        )
    return list((await session.execute(stmt)).scalars().all())


async def shop_offer_usage(session, offer_id: int) -> int:
    """Count current/resolved redemptions against a usage cap; pending requests reserve a slot."""
    from app.db.models import ShopRequest
    return int(await session.scalar(select(func.count(ShopRequest.id)).where(
        ShopRequest.offer_id == int(offer_id),
        ShopRequest.status.not_in(("denied", "cancelled", "refunded")),
    )) or 0)


async def shop_offer_available(session, offer) -> bool:
    if not offer or not bool(offer.active):
        return False
    if offer.expires_at is not None and offer.expires_at <= utc_now_naive():
        return False
    if offer.usage_limit is None:
        return True
    return await shop_offer_usage(session, int(offer.id)) < int(offer.usage_limit)


async def shop_offer_by_id(session, offer_id: int, *, active_only: bool = False):
    from app.db.models import XPShopOffer
    stmt = select(XPShopOffer).where(XPShopOffer.id == int(offer_id))
    if active_only:
        stmt = stmt.where(XPShopOffer.active.is_(True))
    return (await session.execute(stmt)).scalar_one_or_none()


async def xp_economy_totals(session) -> dict[str, int]:
    """Aggregate XP ledger and workflow totals in one database round trip.

    Independent scalar subqueries avoid joining request/reward tables directly to
    the ledger, which would multiply rows and inflate financial totals.
    """
    from app.db.models import RewardIssue, ShopRequest, XPAward
    from sqlalchemy import case

    ledger = select(
        func.coalesce(func.sum(case((
            (XPAward.points > 0)
            & XPAward.award_type.not_in(("shop_redemption_refund", "admin_manual_adjustment")),
            XPAward.points,
        ), else_=0)), 0).label("earned"),
        func.coalesce(func.sum(case((
            (XPAward.award_type == "shop_redemption") & (XPAward.points < 0),
            -XPAward.points,
        ), else_=0)), 0).label("spent"),
        func.coalesce(func.sum(case((
            XPAward.award_type == "admin_manual_adjustment",
            func.abs(XPAward.points),
        ), else_=0)), 0).label("manual_adjustments"),
        func.coalesce(func.sum(XPAward.points), 0).label("net"),
    ).select_from(XPAward).subquery("xp_ledger_totals")

    reserved = select(func.coalesce(func.sum(ShopRequest.xp_cost), 0)).where(
        ShopRequest.status == "pending"
    ).scalar_subquery()
    pending_requests = select(func.count(ShopRequest.id)).where(
        ShopRequest.status == "pending"
    ).scalar_subquery()
    approved = select(func.count(RewardIssue.id)).where(
        RewardIssue.source_type == "shop", RewardIssue.status != "refunded"
    ).scalar_subquery()
    delivered = select(func.count(RewardIssue.id)).where(
        RewardIssue.source_type == "shop", RewardIssue.status == "delivered"
    ).scalar_subquery()
    refunded_xp = select(func.coalesce(func.sum(XPAward.points), 0)).where(
        XPAward.award_type == "shop_redemption_refund", XPAward.points > 0
    ).scalar_subquery()

    totals = (await session.execute(select(
        ledger.c.earned,
        ledger.c.spent,
        ledger.c.manual_adjustments,
        ledger.c.net,
        reserved.label("reserved_xp"),
        pending_requests.label("pending_requests"),
        approved.label("approved_rewards"),
        delivered.label("delivered_rewards"),
        refunded_xp.label("refunded_xp"),
    ).select_from(ledger))).one()

    return {
        "total_earned": int(totals.earned or 0),
        "total_spent": int(totals.spent or 0),
        "manual_adjustments": int(totals.manual_adjustments or 0),
        "net_xp": int(totals.net or 0),
        "reserved_xp": int(totals.reserved_xp or 0),
        "pending_requests": int(totals.pending_requests or 0),
        "approved_rewards": int(totals.approved_rewards or 0),
        "delivered_rewards": int(totals.delivered_rewards or 0),
        "refunded_xp": int(totals.refunded_xp or 0),
    }
