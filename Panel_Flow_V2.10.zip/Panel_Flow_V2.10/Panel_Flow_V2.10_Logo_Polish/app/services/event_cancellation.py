"""Transactional panel-cancellation operation shared by the Telegram handler and PostgreSQL tests."""
from __future__ import annotations

from sqlalchemy import select, update
from sqlalchemy.orm import selectinload

from app.db.models import (
    Booking, Event, EventStatus, PaymentStatus, RegistrationStatus,
    User, WaitlistEntry,
)
from app.services.admin_audit import write_admin_action
from app.time_utils import utc_now_naive
from app.display_utils import volume_label
from app.services.event_lifecycle import transition_event

ACTIVE_CANCELLATION_STATUSES = (
    RegistrationStatus.INITIATED, RegistrationStatus.PENDING_PAYMENT,
    RegistrationStatus.PENDING_VERIFICATION, RegistrationStatus.CONFIRMED,
    RegistrationStatus.REJECTED, RegistrationStatus.WAITLISTED,
)


async def cancel_event_in_transaction(session, event_id: int, actor_telegram_id: int) -> dict:
    """Lock, cancel, and record follow-up for one event. Caller commits the transaction."""
    event = (await session.execute(
        select(Event).where(Event.id == int(event_id)).with_for_update()
        .execution_options(populate_existing=True)
    )).scalar_one_or_none()
    if not event:
        raise ValueError("EVENT_NOT_FOUND")
    if event.archived:
        raise ValueError("EVENT_ARCHIVED")
    if event.status == EventStatus.CANCELLED:
        raise ValueError("EVENT_ALREADY_CANCELLED")

    bookings = (await session.execute(
        select(Booking).where(Booking.event_id == int(event_id), Booking.status.in_(ACTIVE_CANCELLATION_STATUSES))
        .options(selectinload(Booking.payment), selectinload(Booking.booked_by))
        .with_for_update().execution_options(populate_existing=True)
    )).scalars().all()
    wait_rows = (await session.execute(
        select(User.telegram_id).join(WaitlistEntry, WaitlistEntry.user_id == User.id)
        .where(WaitlistEntry.event_id == int(event_id), WaitlistEntry.status.in_(("waiting", "invited", "inviting")))
        .distinct()
    )).scalars().all()
    waiting_recipients = {int(value) for value in wait_rows}
    booking_recipients: set[int] = set()
    financial_recipients: set[int] = set()
    financial_booking_ids: list[int] = []
    now = utc_now_naive()
    for booking in bookings:
        if booking.booked_by and booking.booked_by.telegram_id is not None:
            booking_recipients.add(int(booking.booked_by.telegram_id))
        payment = booking.payment
        has_receipt = bool(payment and (payment.receipt_uploaded_at or payment.receipt_file or payment.receipt_text))
        requires_financial_review = bool(
            booking.status in (RegistrationStatus.CONFIRMED, RegistrationStatus.PENDING_VERIFICATION)
            or (payment and payment.status == PaymentStatus.APPROVED)
            or has_receipt
        )
        if requires_financial_review:
            booking.cancellation_resolution = "action_required"
            booking.cancellation_resolution_note = None
            booking.cancellation_resolved_at = None
            financial_booking_ids.append(int(booking.id))
            if booking.booked_by and booking.booked_by.telegram_id is not None:
                financial_recipients.add(int(booking.booked_by.telegram_id))
        else:
            booking.cancellation_resolution = "not_required"
            booking.cancellation_resolution_note = None
            booking.cancellation_resolved_at = now
        booking.status = RegistrationStatus.CANCELLED
        booking.cancelled_at = now
        booking.expires_at = None

    transition_event(event, EventStatus.CANCELLED, reason="لغو توسط مدیریت")
    await session.execute(update(WaitlistEntry).where(
        WaitlistEntry.event_id == int(event_id),
        WaitlistEntry.status.in_(("waiting", "invited", "inviting")),
    ).values(status="closed"))
    panel_label = f"{volume_label(event.volume)} — {event.title}"
    await write_admin_action(
        session, actor_telegram_id=int(actor_telegram_id), action="panel_cancelled", entity_type="event", entity_id=int(event_id),
        details={"affected_booking_users": len(booking_recipients), "cancelled_bookings": len(bookings),
                 "affected_waitlist_users": len(waiting_recipients), "unresolved_financial_cases": len(financial_booking_ids)},
    )
    return {
        "event_id": int(event_id), "panel_label": panel_label,
        "booking_recipients": booking_recipients, "waiting_recipients": waiting_recipients,
        "financial_recipients": financial_recipients, "unresolved_count": len(financial_booking_ids),
        "cancelled_booking_count": len(bookings),
    }
