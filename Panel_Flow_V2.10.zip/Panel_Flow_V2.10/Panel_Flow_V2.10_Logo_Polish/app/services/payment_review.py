"""Receipt identity tokens and immutable review-attempt fingerprints."""
from __future__ import annotations

import hashlib


def receipt_fingerprint(payment) -> str:
    values = (
        getattr(payment, "receipt_file", None) or "",
        getattr(payment, "receipt_file_name", None) or "",
        getattr(payment, "receipt_text", None) or "",
        getattr(payment, "receipt_uploaded_at", None).isoformat() if getattr(payment, "receipt_uploaded_at", None) else "",
    )
    return hashlib.sha256("\n".join(str(value) for value in values).encode("utf-8")).hexdigest()


def receipt_review_token(payment) -> str:
    return receipt_fingerprint(payment)[:12]


async def lock_payment_review_rows(session, payment_id: int):
    """Acquire payment-review locks in booking -> event -> payment order.

    This is the shared transactional locking path used by the Telegram reviewer
    and real-PostgreSQL race-condition tests. Receipt/status validation remains
    with the caller because it also depends on the submitted review token.
    """
    from sqlalchemy import select
    from sqlalchemy.orm import selectinload
    from app.db.models import Booking, Event, Payment

    booking_id = (await session.execute(select(Payment.booking_id).where(Payment.id == int(payment_id)))).scalar_one_or_none()
    if booking_id is None:
        return None, None, None
    booking = (await session.execute(select(Booking).where(Booking.id == booking_id).with_for_update()
        .execution_options(populate_existing=True))).scalar_one_or_none()
    if booking is None:
        return None, None, None
    event = (await session.execute(select(Event).where(Event.id == booking.event_id).with_for_update()
        .execution_options(populate_existing=True))).scalar_one_or_none()
    if event is None:
        return None, booking, None
    payment = (await session.execute(
        select(Payment).options(
            selectinload(Payment.booking).selectinload(Booking.event),
            selectinload(Payment.booking).selectinload(Booking.booked_by),
            selectinload(Payment.booking).selectinload(Booking.participants),
        ).where(Payment.id == int(payment_id)).with_for_update().execution_options(populate_existing=True)
    )).scalar_one_or_none()
    return payment, booking, event
