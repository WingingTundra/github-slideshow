from __future__ import annotations

from collections.abc import Iterable

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings as runtime_config
from app.db.models import AppSetting

CHANNEL_UPDATES_ENABLED = "channel_updates_enabled"
CHANNEL_UPDATE_THRESHOLD = "channel_update_threshold"
DEFAULT_CHANNEL_UPDATES_ENABLED = False
DEFAULT_CHANNEL_UPDATE_THRESHOLD = 3


def _parse_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _parse_positive_int(value: str | None, default: int) -> int:
    try:
        number = int((value or "").strip())
        return number if number > 0 else default
    except (TypeError, ValueError):
        return default


async def get_setting(session: AsyncSession, key: str, default: str | None = None) -> str | None:
    row = (await session.execute(select(AppSetting).where(AppSetting.key == key))).scalar_one_or_none()
    return row.value if row else default


async def get_settings(session: AsyncSession, keys: Iterable[str]) -> dict[str, str]:
    """Fetch a group of persistent settings in one database round trip.

    The result contains only rows that exist; callers retain responsibility for
    applying their established defaults and environment fallbacks.
    """
    requested = tuple(dict.fromkeys(str(key) for key in keys))
    if not requested:
        return {}
    rows = (await session.execute(
        select(AppSetting).where(AppSetting.key.in_(requested))
    )).scalars().all()
    return {str(row.key): str(row.value or "") for row in rows}


async def set_setting(session: AsyncSession, key: str, value: str) -> None:
    row = (await session.execute(select(AppSetting).where(AppSetting.key == key))).scalar_one_or_none()
    if row is None:
        row = AppSetting(key=key, value=value)
        session.add(row)
    else:
        row.value = value


async def get_channel_updates_config(session: AsyncSession) -> tuple[bool, int]:
    values = await get_settings(session, (CHANNEL_UPDATES_ENABLED, CHANNEL_UPDATE_THRESHOLD))
    return (
        _parse_bool(values.get(CHANNEL_UPDATES_ENABLED), DEFAULT_CHANNEL_UPDATES_ENABLED),
        _parse_positive_int(values.get(CHANNEL_UPDATE_THRESHOLD), DEFAULT_CHANNEL_UPDATE_THRESHOLD),
    )


# Persistent values managed from the authorized admin menu. Empty or absent rows
# use the existing environment configuration as a safe first-run fallback.
BOT_SETTING_DEFAULTS = {
    "community_group_url": "panel_flow_group_url",
    "community_channel_url": "panel_flow_channel_url",
    "community_instagram_url": "panel_flow_instagram_url",
    "community_website_url": "panel_flow_website_url",
    "payment_card_number": "payment_card_number",
    "payment_account_name": "payment_account_name",
}

def _bot_setting_default(key: str) -> str:
    attr = BOT_SETTING_DEFAULTS.get(key)
    return str(getattr(runtime_config, attr, "") or "").strip() if attr else ""

async def get_bot_settings(session: AsyncSession) -> dict[str, str]:
    """Read configurable public/payment values with one query and env fallbacks.

    Called at presentation/action time so updates take effect without restarting.
    This mapping is never exposed via API routes.
    """
    stored_values = await get_settings(session, BOT_SETTING_DEFAULTS)
    values: dict[str, str] = {}
    for key in BOT_SETTING_DEFAULTS:
        stored = stored_values.get(key)
        values[key] = str(stored).strip() if stored and str(stored).strip() else _bot_setting_default(key)
    return values

async def seed_bot_settings(session: AsyncSession) -> None:
    """Seed missing settings from the previous env-based configuration once.

    Existing non-empty DB values always win, allowing settings to persist through
    environment changes and deployments. Empty values may be filled from a legacy
    environment value during upgrade, but are never overwritten by a blank default.
    """
    existing = (await session.execute(
        select(AppSetting).where(AppSetting.key.in_(tuple(BOT_SETTING_DEFAULTS)))
    )).scalars().all()
    rows_by_key = {str(row.key): row for row in existing}
    for key in BOT_SETTING_DEFAULTS:
        row = rows_by_key.get(key)
        default = _bot_setting_default(key)
        if row is None:
            session.add(AppSetting(key=key, value=default))
        elif not str(row.value or "").strip() and default:
            row.value = default
    await session.commit()


def validate_admin_setting_value(key: str, raw_value: str) -> str:
    """Normalize and validate an admin-editable setting without logging its value."""
    from urllib.parse import urlparse
    from app.bot.validation import normalize_person_name, to_ascii_digits

    value = str(raw_value or "").strip()
    link_keys = {
        "community_group_url": {"t.me", "telegram.me"},
        "community_channel_url": {"t.me", "telegram.me"},
        "community_instagram_url": {"instagram.com", "www.instagram.com"},
        "community_website_url": None,
    }
    if key in link_keys:
        if len(value) > 300 or any(ch.isspace() for ch in value):
            raise ValueError("invalid_link")
        try:
            parsed = urlparse(value)
            host = (parsed.hostname or "").lower()
            allowed_hosts = link_keys[key]
            invalid_host = not host or (allowed_hosts is not None and host not in allowed_hosts)
            if parsed.scheme.lower() != "https" or invalid_host:
                raise ValueError("invalid_link")
            if key != "community_website_url" and not parsed.path.strip("/"):
                raise ValueError("invalid_link")
            if parsed.username or parsed.password or parsed.port is not None:
                raise ValueError("invalid_link")
        except (TypeError, ValueError):
            raise ValueError("invalid_link") from None
        return value
    if key == "payment_card_number":
        digits = to_ascii_digits(value).translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
        compact = "".join(ch for ch in digits if ch in "0123456789")
        if any(ch not in "0123456789 -\u200c" for ch in digits) or len(compact) != 16 or len(set(compact)) == 1:
            raise ValueError("invalid_card_number")
        total = 0
        for index, char in enumerate(reversed(compact)):
            digit = int(char)
            if index % 2 == 1:
                digit *= 2
                if digit > 9:
                    digit -= 9
            total += digit
        if total % 10:
            raise ValueError("invalid_card_number")
        return compact
    if key == "payment_account_name":
        name = normalize_person_name(value, min_length=3, max_length=100)
        if not name or len(name.split()) < 2:
            raise ValueError("invalid_cardholder_name")
        return name
    raise ValueError("unknown_setting")
