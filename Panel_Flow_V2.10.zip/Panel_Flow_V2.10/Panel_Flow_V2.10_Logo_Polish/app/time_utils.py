"""Canonical Tehran wall-clock utilities and UTC database timestamp helpers.

All human scheduling (quiet hours, local date boundaries, website calendar values)
uses Asia/Tehran. Operational timestamps remain stored as naive UTC for compatibility
with the existing PostgreSQL schema; conversions happen explicitly at boundaries.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

PLATFORM_TIMEZONE_NAME = "Asia/Tehran"
PLATFORM_TIMEZONE = ZoneInfo(PLATFORM_TIMEZONE_NAME)
UTC = timezone.utc


def utc_now_naive() -> datetime:
    """Return current UTC instant as naive UTC for legacy DateTime columns."""
    return datetime.now(UTC).replace(tzinfo=None)


def tehran_now() -> datetime:
    """Return current aware datetime in the platform's canonical Tehran zone."""
    return datetime.now(PLATFORM_TIMEZONE)


def tehran_today() -> date:
    """Return the platform-local calendar date (never the host/container date)."""
    return tehran_now().date()


def as_utc_aware(value: datetime) -> datetime:
    """Normalize an aware datetime or legacy-naive-UTC datetime to aware UTC."""
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def to_utc_naive(value: datetime) -> datetime:
    """Normalize an input instant to the established naive-UTC DB convention."""
    return as_utc_aware(value).replace(tzinfo=None)


def to_tehran(value: datetime) -> datetime:
    """Convert aware or legacy-naive-UTC timestamps to Tehran local time."""
    return as_utc_aware(value).astimezone(PLATFORM_TIMEZONE)


def tehran_local_to_utc_naive(value: datetime) -> datetime:
    """Convert a Tehran wall-clock datetime to naive UTC for DB persistence.

    Naive input is interpreted as a local Tehran wall clock, unlike as_utc_aware,
    which deliberately interprets legacy naive values as UTC.
    """
    local = value.replace(tzinfo=PLATFORM_TIMEZONE) if value.tzinfo is None else value.astimezone(PLATFORM_TIMEZONE)
    return local.astimezone(UTC).replace(tzinfo=None)
