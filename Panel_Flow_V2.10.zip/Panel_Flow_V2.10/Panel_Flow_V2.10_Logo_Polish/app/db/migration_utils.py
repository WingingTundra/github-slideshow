from __future__ import annotations

def split_sql_statements(sql: str) -> list[str]:
    """Split PostgreSQL migration SQL without breaking strings or dollar-quoted blocks.

    This deliberately avoids a dependency on a SQL parser. It understands the
    constructs that matter for our migrations: single/double-quoted strings,
    line/block comments, and PostgreSQL dollar-quoted bodies (including tagged
    forms such as $func$...$func$).
    """
    statements: list[str] = []
    start = 0
    i = 0
    n = len(sql)
    quote: str | None = None
    dollar_tag: str | None = None
    line_comment = False
    block_comment_depth = 0

    while i < n:
        ch = sql[i]

        if line_comment:
            if ch in "\r\n":
                line_comment = False
            i += 1
            continue

        if block_comment_depth:
            if sql.startswith("/*", i):
                block_comment_depth += 1
                i += 2
            elif sql.startswith("*/", i):
                block_comment_depth -= 1
                i += 2
            else:
                i += 1
            continue

        if dollar_tag is not None:
            if sql.startswith(dollar_tag, i):
                i += len(dollar_tag)
                dollar_tag = None
            else:
                i += 1
            continue

        if quote is not None:
            if ch == quote:
                # SQL escapes a quote by doubling it (e.g. '' or "").
                if i + 1 < n and sql[i + 1] == quote:
                    i += 2
                else:
                    quote = None
                    i += 1
            elif quote == "'" and ch == "\\" and i + 1 < n:
                # PostgreSQL may use backslash escapes when standard_conforming_strings is off.
                i += 2
            else:
                i += 1
            continue

        if sql.startswith("--", i):
            line_comment = True
            i += 2
            continue
        if sql.startswith("/*", i):
            block_comment_depth = 1
            i += 2
            continue
        if ch in ("'", '"'):
            quote = ch
            i += 1
            continue

        if ch == "$":
            j = i + 1
            while j < n and (sql[j].isalnum() or sql[j] == "_"):
                j += 1
            if j < n and sql[j] == "$":
                dollar_tag = sql[i : j + 1]
                i = j + 1
                continue

        if ch == ";":
            statement = sql[start:i].strip()
            if statement:
                statements.append(statement)
            start = i + 1
        i += 1

    if quote is not None or dollar_tag is not None or block_comment_depth:
        raise ValueError("Unterminated SQL quote, dollar-quoted block, or comment in migration")

    trailing = sql[start:].strip()
    if trailing:
        statements.append(trailing)
    return statements

