"""Lazy SQLAlchemy engine/session factory.

Deferring engine creation lets startup validate DATABASE_URL and report a useful
configuration error instead of crashing during module import. A configured
production URL is still used to create the normal async SQLAlchemy engine before
any database connection is attempted.
"""
from __future__ import annotations

from sqlalchemy.engine import make_url
from sqlalchemy import event
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

from app.config import settings


class _LazyAsyncEngine:
    def __init__(
        self,
        *,
        pool_size_setting: str = "database_pool_size",
        max_overflow_setting: str = "database_max_overflow",
        pool_timeout_setting: str = "database_pool_timeout_seconds",
    ) -> None:
        self._engine = None
        self._url: str | None = None
        self._pool_size_setting = pool_size_setting
        self._max_overflow_setting = max_overflow_setting
        self._pool_timeout_setting = pool_timeout_setting

    def _get_engine(self):
        url = (settings.database_url or "").strip()
        if not url:
            raise RuntimeError(
                "Database configuration invalid: set DATABASE_URL before using the database."
            )
        try:
            parsed = make_url(url)
        except Exception as exc:
            raise RuntimeError("Database configuration invalid: DATABASE_URL is malformed.") from exc
        if parsed.drivername != "postgresql+asyncpg" or not parsed.host or not parsed.database:
            raise RuntimeError(
                "Database configuration invalid: DATABASE_URL must specify postgresql+asyncpg, a hostname, and a database."
            )
        if self._engine is None:
            # Explicit, bounded pool settings make connection budgeting visible and
            # configurable rather than silently relying on SQLAlchemy defaults.
            self._engine = create_async_engine(
                url,
                pool_pre_ping=True,
                pool_size=int(getattr(settings, self._pool_size_setting)),
                max_overflow=int(getattr(settings, self._max_overflow_setting)),
                pool_timeout=float(getattr(settings, self._pool_timeout_setting)),
            )
            # DateTime(timezone=False) server defaults and raw SQL timestamps use
            # the PostgreSQL session timezone. Fix it to UTC so the legacy naive
            # timestamp convention stays correct regardless of host/container TZ.
            sync_engine = getattr(self._engine, "sync_engine", None)
            if sync_engine is not None:
                @event.listens_for(sync_engine, "connect")
                def _set_database_session_timezone(dbapi_connection, connection_record):
                    cursor = dbapi_connection.cursor()
                    try:
                        cursor.execute("SET TIME ZONE 'UTC'")
                    finally:
                        cursor.close()
            self._url = url
        elif self._url != url:
            raise RuntimeError("DATABASE_URL changed after the database engine was initialized; restart the process.")
        return self._engine

    def begin(self):
        return self._get_engine().begin()

    def dispose(self):
        # Match SQLAlchemy's async-engine API once the engine has been created;
        # before startup, disposal is a harmless no-op (also useful in tests).
        return self._engine.dispose() if self._engine is not None else None


class _LazySessionFactory:
    def __init__(self, lazy_engine: _LazyAsyncEngine) -> None:
        self._lazy_engine = lazy_engine
        self._factory = None
        self._factory_engine = None

    def __call__(self, *args, **kwargs):
        engine = self._lazy_engine._get_engine()
        if self._factory is None or engine is not self._factory_engine:
            self._factory = async_sessionmaker(
                engine, expire_on_commit=False, class_=AsyncSession
            )
            self._factory_engine = engine
        return self._factory(*args, **kwargs)


engine = _LazyAsyncEngine()
# Advisory locks live in a dedicated pool. Lock waiters can exhaust this bounded
# pool but cannot starve ordinary sessions that the lock holders need to finish.
event_isolation_engine = _LazyAsyncEngine(
    pool_size_setting="database_lock_pool_size",
    max_overflow_setting="database_lock_max_overflow",
    pool_timeout_setting="database_lock_pool_timeout_seconds",
)
SessionLocal = _LazySessionFactory(engine)


async def dispose_database_engines() -> None:
    """Release both pools during graceful bot shutdown, including partial startup."""
    # The lazy facade's dispose() is intentionally a no-op (returns None) before
    # an engine has been created; only await SQLAlchemy's async disposal when set.
    if engine._engine is not None:
        await engine.dispose()
    if event_isolation_engine._engine is not None:
        await event_isolation_engine.dispose()


async def get_session():
    async with SessionLocal() as session:
        yield session
