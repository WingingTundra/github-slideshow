from __future__ import annotations

from pathlib import Path
import asyncio
import errno
import logging
import hashlib
import socket

from sqlalchemy.exc import DBAPIError, OperationalError
from sqlalchemy.engine import make_url

from sqlalchemy import text

from app.db.models import Base
from app.db.session import engine


MIGRATION_DIR = Path(__file__).resolve().parents[2] / "migrations"
logger = logging.getLogger(__name__)


from app.db.migration_utils import split_sql_statements


async def _run_migrations(conn):
    await conn.execute(text("CREATE TABLE IF NOT EXISTS schema_migrations (version VARCHAR(100) PRIMARY KEY, applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)"))
    await conn.execute(text("ALTER TABLE schema_migrations ADD COLUMN IF NOT EXISTS checksum VARCHAR(64)"))
    applied_rows = (await conn.execute(text("SELECT version, checksum FROM schema_migrations"))).all()
    applied = {row[0]: row[1] for row in applied_rows}
    migration_paths = sorted(MIGRATION_DIR.glob("*.sql"))
    for path in migration_paths:
        version = path.name
        sql = path.read_text(encoding="utf-8")
        checksum = hashlib.sha256(sql.encode("utf-8")).hexdigest()
        if version in applied:
            recorded = applied[version]
            if recorded and recorded != checksum:
                raise RuntimeError(f"Database migration {version} checksum mismatch; restore the original migration file. Applied migrations must be immutable.")
            if not recorded:
                await conn.execute(text("UPDATE schema_migrations SET checksum = :checksum WHERE version = :version"), {"checksum": checksum, "version": version})
            continue
        # asyncpg does not accept a multi-statement SQL string through the
        # driver execute path. Split safely, then execute each statement.
        statements = split_sql_statements(sql)
        logger.info("Applying database migration %s (%s statements)", version, len(statements))
        for index, statement in enumerate(statements, start=1):
            try:
                await conn.exec_driver_sql(statement)
            except Exception as exc:
                # Include the migration and statement number in the exception
                # itself. Some hosting dashboards show only the final exception
                # line and hide the earlier structured log records.
                excerpt = " ".join(statement.split())[:220]
                logger.exception(
                    "Database migration %s failed at statement %s/%s: %s",
                    version, index, len(statements), excerpt,
                )
                raise RuntimeError(
                    f"Database migration {version} failed at statement {index}/{len(statements)} "
                    f"({type(exc).__name__}: {exc}); statement starts: {excerpt}"
                ) from exc
        await conn.execute(text("INSERT INTO schema_migrations(version, checksum) VALUES (:version, :checksum)"), {"version": version, "checksum": checksum})
        logger.info("Applied database migration %s", version)


async def _ensure_app_settings_timestamp_defaults(conn):
    """Repair timestamp defaults before *any* historical migration inserts settings.

    Some deployed V39/V40/V41 images attempted to seed ``app_settings`` using raw
    SQL that omits timestamps. Python-side SQLAlchemy defaults do not apply to raw
    SQL. Running this compatibility repair before the migration loop makes those
    inserts safe too, and also repairs a database whose columns exist but have no
    server defaults. Keep this idempotent: bot and API containers share startup.
    """
    statements = (
        "CREATE TABLE IF NOT EXISTS app_settings ("
        "id SERIAL PRIMARY KEY, key VARCHAR(100) NOT NULL UNIQUE, value TEXT NOT NULL, "
        "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, "
        "updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS created_at TIMESTAMP",
        "ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP",
        "UPDATE app_settings SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL",
        "UPDATE app_settings SET updated_at = CURRENT_TIMESTAMP WHERE updated_at IS NULL",
        "ALTER TABLE app_settings ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
        "ALTER TABLE app_settings ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP",
        "ALTER TABLE app_settings ALTER COLUMN created_at SET NOT NULL",
        "ALTER TABLE app_settings ALTER COLUMN updated_at SET NOT NULL",
    )
    for index, statement in enumerate(statements, start=1):
        try:
            await conn.exec_driver_sql(statement)
        except Exception as exc:
            excerpt = " ".join(statement.split())[:180]
            logger.exception(
                "app_settings timestamp compatibility preflight failed at statement %s/%s: %s",
                index, len(statements), excerpt,
            )
            raise RuntimeError(
                "Database app_settings compatibility preflight failed at "
                f"statement {index}/{len(statements)} ({type(exc).__name__}: {exc}); "
                f"statement starts: {excerpt}"
            ) from exc


async def _seed_v65_bot_settings(conn):
    """Persist legacy env defaults only for missing or blank V65 settings."""
    from app.config import settings as config

    defaults = {
        "community_group_url": config.panel_flow_group_url,
        "community_channel_url": config.panel_flow_channel_url,
        "community_instagram_url": config.panel_flow_instagram_url,
        "payment_card_number": config.payment_card_number,
        "payment_account_name": config.payment_account_name,
    }
    statement = text(
        "INSERT INTO app_settings(key, value, created_at, updated_at) "
        "VALUES (:key, :value, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) "
        "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP "
        "WHERE BTRIM(COALESCE(app_settings.value, '')) = '' AND BTRIM(EXCLUDED.value) <> ''"
    )
    for key, raw_value in defaults.items():
        await conn.execute(statement, {"key": key, "value": str(raw_value or "").strip()})


async def _init_db_once():
    async with engine.begin() as conn:
        # Both bot and API containers can enter startup together. Lock before
        # create_all as well as migrations so fresh-schema creation is serialized.
        try:
            await conn.execute(text("SELECT pg_advisory_xact_lock(70420261007)"))
        except Exception as exc:
            logger.exception("Could not acquire the database startup advisory lock")
            raise RuntimeError(f"Database advisory-lock step failed: {type(exc).__name__}: {exc}") from exc
        try:
            await conn.run_sync(Base.metadata.create_all)
        except Exception as exc:
            logger.exception("SQLAlchemy create_all failed before migrations")
            raise RuntimeError(f"Database create_all step failed: {type(exc).__name__}: {exc}") from exc
        # Important: preflight runs before legacy migrations. This protects against
        # an outdated migration file/image attempting INSERT INTO app_settings(key,
        # value) without explicitly supplying created_at and updated_at.
        await _ensure_app_settings_timestamp_defaults(conn)
        await _run_migrations(conn)
        await _seed_v65_bot_settings(conn)


def _exception_chain(exc):
    """Yield wrapped DB/network exceptions without looping through cycles."""
    seen = set()
    current = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current
        current = (
            getattr(current, "orig", None)
            or getattr(current, "__cause__", None)
            or getattr(current, "__context__", None)
        )


def is_retryable_database_error(exc: BaseException) -> bool:
    """Return True only for transient DNS/network/service availability errors.

    Authentication failures, malformed URLs, invalid database names, and SQL
    migration errors are intentionally not retried.
    """
    transient_errnos = {
        errno.ECONNREFUSED, errno.ETIMEDOUT, errno.EHOSTUNREACH,
        errno.ENETUNREACH, errno.ECONNRESET, errno.EPIPE,
    }
    transient_sqlstates = {"08000", "08001", "08003", "08006", "08007", "57P01", "57P02", "57P03"}
    transient_text = (
        "temporary failure in name resolution",
        "temporary failure resolving",
        "connection refused",
        "connection timed out",
        "server closed the connection unexpectedly",
        "connection is closed",
        "could not connect to server",
    )
    for item in _exception_chain(exc):
        if isinstance(item, socket.gaierror):
            return item.errno == getattr(socket, "EAI_AGAIN", -3)
        if getattr(item, "errno", None) in transient_errnos:
            return True
        sqlstate = getattr(item, "sqlstate", None) or getattr(item, "pgcode", None)
        if sqlstate in transient_sqlstates:
            return True
        if isinstance(item, (OperationalError, DBAPIError)):
            message = str(item).lower()
            if any(fragment in message for fragment in transient_text):
                return True
    return False


async def init_db():
    """Initialize schema with bounded exponential retry for transient connection failures."""
    from app.config import settings

    # A simple release marker makes it possible to distinguish a rebuilt image
    # from an old container that is still executing stale migration files.
    # Historical release marker retained for compatibility: Panel Flow V97 database initialization started.
    logger.info("Panel Flow V99 database initialization started")
    raw_url = (settings.database_url or "").strip()
    if not raw_url:
        logger.error("Database configuration is missing: DATABASE_URL is empty")
        raise RuntimeError("Database configuration invalid: set DATABASE_URL to a PostgreSQL asyncpg URL.")
    try:
        parsed_url = make_url(raw_url)
    except Exception as exc:
        logger.error("Database configuration is malformed: DATABASE_URL could not be parsed")
        raise RuntimeError("Database configuration invalid: DATABASE_URL is malformed.") from exc
    if parsed_url.drivername not in {"postgresql+asyncpg"} or not parsed_url.host or not parsed_url.database:
        logger.error("Database configuration is incomplete or uses an unsupported driver; expected postgresql+asyncpg with host and database")
        raise RuntimeError("Database configuration invalid: DATABASE_URL must specify postgresql+asyncpg, a hostname, and a database.")

    attempts = max(1, int(settings.database_startup_max_attempts))
    initial_delay = max(0.0, float(settings.database_startup_retry_initial_seconds))
    max_delay = max(initial_delay, float(settings.database_startup_retry_max_seconds))
    delay = initial_delay
    for attempt in range(1, attempts + 1):
        try:
            await _init_db_once()
            if attempt > 1:
                logger.info("Database initialized successfully after %s attempts", attempt)
            return
        except Exception as exc:
            retryable = is_retryable_database_error(exc)
            if not retryable or attempt >= attempts:
                if retryable:
                    logger.error(
                        "Database startup failed after %s attempts due to a transient connection/DNS error. "
                        "Verify DATABASE_URL hostname, port, network, and database health.", attempts,
                    )
                else:
                    logger.error(
                        "Database startup failed with a non-retryable error during connection/schema initialization. "
                        "Verify DATABASE_URL, credentials, database name, and migrations."
                    )
                logger.exception("Database initialization failed (attempt %s/%s)", attempt, attempts)
                # Surface the innermost driver/database exception in the final
                # startup error. A number of container dashboards collapse logs
                # and otherwise expose only this wrapper RuntimeError.
                chain = list(_exception_chain(exc))
                # Prefer our migration wrapper when present: it carries the exact
                # filename, statement number, and SQL excerpt. Choosing only the
                # deepest asyncpg exception would hide that actionable context.
                migration_context = next(
                    (item for item in chain if isinstance(item, RuntimeError) and "Database migration " in str(item)),
                    None,
                )
                root_cause = migration_context or (chain[-1] if chain else exc)
                detail = f"{type(root_cause).__name__}: {root_cause}"
                # Never echo credential-bearing connection strings/passwords.
                detail = detail.replace(raw_url, "<DATABASE_URL>")
                if parsed_url.password:
                    detail = detail.replace(parsed_url.password, "<redacted>")
                if retryable:
                    message = (
                        "Database initialization failed after bounded retries; verify DATABASE_URL, DNS, network "
                        f"connectivity, and database health. Root cause: {detail}"
                    )
                else:
                    message = (
                        "Database initialization failed with a non-retryable error; verify DATABASE_URL, credentials, "
                        f"schema, and migrations. Root cause: {detail}"
                    )
                raise RuntimeError(message) from exc
            logger.warning(
                "Transient database DNS/network failure during startup (attempt %s/%s); retrying in %.2f seconds",
                attempt, attempts, delay,
            )
            await asyncio.sleep(delay)
            delay = min(max_delay, delay * 2 if delay else initial_delay)
