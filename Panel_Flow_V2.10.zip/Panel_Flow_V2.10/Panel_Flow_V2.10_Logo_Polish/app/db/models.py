from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from enum import Enum

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, ForeignKeyConstraint, Integer, Numeric, String, Text, UniqueConstraint, Index, JSON, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from app.time_utils import utc_now_naive


class Base(DeclarativeBase):
    pass


class UserRole(str, Enum):
    PARTICIPANT = "participant"
    HOST = "host"
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"


class EventStatus(str, Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class RegistrationStatus(str, Enum):
    INITIATED = "initiated"
    PENDING_PAYMENT = "pending_payment"
    PENDING_VERIFICATION = "pending_verification"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    WAITLISTED = "waitlisted"


class PaymentStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class AttendanceStatus(str, Enum):
    UNMARKED = "unmarked"
    ATTENDED = "attended"
    NO_SHOW = "no_show"


class ModerationStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    telegram_username: Mapped[str | None] = mapped_column(String(255))
    is_bot: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    display_name: Mapped[str | None] = mapped_column(String(255))
    first_name: Mapped[str | None] = mapped_column(String(100))
    last_name: Mapped[str | None] = mapped_column(String(100))
    phone_number: Mapped[str | None] = mapped_column(String(50))
    # One-time onboarding attribution: code is the referrer's Telegram ID, stored
    # internally as a user FK to prevent self-referrals and multiple attribution.
    referred_by_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    referral_prompt_completed: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false", nullable=False
    )
    # Cumulative, durable count of distinct bookings that reached CONFIRMED.
    lifetime_confirmed_bookings: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    role: Mapped[UserRole] = mapped_column(default=UserRole.PARTICIPANT)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive)

    bookings: Mapped[list["Booking"]] = relationship(back_populates="booked_by")


class City(Base):
    __tablename__ = "cities"
    __table_args__ = (
        UniqueConstraint("slug", name="uq_cities_slug"),
        CheckConstraint("latitude BETWEEN 24 AND 40", name="ck_cities_latitude_iran_bounds"),
        CheckConstraint("longitude BETWEEN 43 AND 64", name="ck_cities_longitude_iran_bounds"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    name_fa: Mapped[str] = mapped_column(String(120), nullable=False)
    name_en: Mapped[str] = mapped_column(String(120), nullable=False)
    province_fa: Mapped[str] = mapped_column(String(120), nullable=False)
    province_en: Mapped[str] = mapped_column(String(120), nullable=False)
    latitude: Mapped[Decimal] = mapped_column(Numeric(9, 6), nullable=False)
    longitude: Mapped[Decimal] = mapped_column(Numeric(9, 6), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    is_founding_city: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    description_fa: Mapped[str | None] = mapped_column(Text, nullable=True)
    description_en: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))


class HostSubscription(Base):
    __tablename__ = "host_subscriptions"
    __table_args__ = (
        Index("ix_host_subscriptions_host_status_end", "host_user_id", "status", "ends_at"),
        CheckConstraint("status IN ('active','trial','suspended','cancelled')", name="ck_host_subscriptions_status"),
        CheckConstraint("plan_code IN ('starter','growth','pro','custom','legacy')", name="ck_host_subscriptions_plan"),
        CheckConstraint("price_amount >= 0", name="ck_host_subscriptions_price_nonnegative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    host_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    plan_code: Mapped[str] = mapped_column(String(40), nullable=False, default="starter")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="active", index=True)
    starts_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=utc_now_naive)
    ends_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    price_amount: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")
    currency: Mapped[str] = mapped_column(String(12), nullable=False, default="IRR", server_default="IRR")
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))


class Event(Base):
    __tablename__ = "events"
    __table_args__ = (
        ForeignKeyConstraint(["organization_id", "brand_id"], ["brands.organization_id", "brands.id"], ondelete="RESTRICT", name="fk_events_brand_organization"),
        CheckConstraint("(organization_id IS NULL AND brand_id IS NULL) OR (organization_id IS NOT NULL AND brand_id IS NOT NULL)", name="ck_events_organization_brand_pair"),
        CheckConstraint("event_type IN ('physical','online','hybrid')", name="ck_events_event_type"),
        CheckConstraint("capacity >= 0", name="ck_events_capacity_nonnegative"),
        Index(
            "uq_events_attendance_checkin_code_hash", "attendance_checkin_code_hash", unique=True,
            postgresql_where=text("attendance_checkin_code_hash IS NOT NULL"),
            sqlite_where=text("attendance_checkin_code_hash IS NOT NULL"),
        ),
        Index(
            "uq_events_creation_token", "creation_token", unique=True,
            postgresql_where=text("creation_token IS NOT NULL"),
            sqlite_where=text("creation_token IS NOT NULL"),
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    # Idempotency key for a single admin/host creation wizard. Old events remain NULL.
    creation_token: Mapped[str | None] = mapped_column(String(32), nullable=True)
    volume: Mapped[str] = mapped_column(String(80))
    title: Mapped[str] = mapped_column(String(255))
    # Human-entered display label (e.g. English, فارسی, Français); old panels may be unknown.
    language: Mapped[str | None] = mapped_column(String(80), nullable=True)
    description: Mapped[str | None] = mapped_column(Text)
    # Structured public discovery/content metadata; kept as compact JSON arrays.
    topic_tags: Mapped[list] = mapped_column(JSON().with_variant(JSONB, "postgresql"), default=list, server_default=text("'[]'"), nullable=False)
    agenda_items: Mapped[list] = mapped_column(JSON().with_variant(JSONB, "postgresql"), default=list, server_default=text("'[]'"), nullable=False)
    discussion_questions: Mapped[list] = mapped_column(JSON().with_variant(JSONB, "postgresql"), default=list, server_default=text("'[]'"), nullable=False)
    cover_image_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    # A postponed event remains publicly discoverable but registration is forcibly closed.
    is_postponed: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    postponement_note: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    # Presentation-only schedule text. The bot never parses or compares it.
    event_day_label: Mapped[str] = mapped_column(String(100), default="—")
    event_date_label: Mapped[str] = mapped_column(String(255), default="—")
    # Presentation-only time text. The bot never parses or schedules from it.
    start_time_label: Mapped[str] = mapped_column(String(5), default="—")
    end_time_label: Mapped[str] = mapped_column(String(5), default="—")
    venue: Mapped[str] = mapped_column(String(255))
    address: Mapped[str | None] = mapped_column(String(500))
    map_url: Mapped[str | None] = mapped_column(String(1000))
    city: Mapped[str] = mapped_column(String(100), default="Mashhad")
    city_id: Mapped[int | None] = mapped_column(ForeignKey("cities.id", ondelete="SET NULL"), nullable=True, index=True)
    organization_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True, index=True)
    # Tenant-safe composite FK above is the sole relationship constraint for a brand.
    brand_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    event_type: Mapped[str] = mapped_column(String(16), default="physical", server_default="physical", nullable=False)
    meeting_platform: Mapped[str | None] = mapped_column(String(40), nullable=True)
    meeting_link: Mapped[str | None] = mapped_column(Text, nullable=True)
    meeting_link_released_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    event_date_iso: Mapped[date | None] = mapped_column(Date, nullable=True, index=True)
    capacity: Mapped[int] = mapped_column(Integer)
    price_per_person: Mapped[Decimal] = mapped_column(Numeric(12, 0))
    # Optional total price for registration without a mandatory cafe-menu order.
    # NULL means this option is unavailable; it is not inferred from event dates.
    price_without_cafe_order: Mapped[Decimal | None] = mapped_column(Numeric(12, 0), nullable=True)
    status: Mapped[EventStatus] = mapped_column(default=EventStatus.DRAFT, index=True)
    # Registration is controlled manually, except that the system closes it once capacity is full.
    registration_open: Mapped[bool] = mapped_column(Boolean, default=False)
    # Distinguishes an automatic full-capacity closure from an explicit admin closure.
    # This lets a later capacity increase reopen only the automatic closure.
    registration_closed_reason: Mapped[str | None] = mapped_column(String(30), nullable=True)
    waitlist_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    # Optional per-panel operations: attendance is off by default; token hashes
    # are invalidated when attendance is disabled or an admin rotates the QR.
    attendance_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    attendance_checkin_token_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    attendance_checkin_code_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    attendance_checkin_session_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    attendance_checkin_token_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    attendance_checkin_code_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # New feedback is attendance-gated. The migration explicitly grandfatheres
    # already archived/feedback-enabled panels so existing review invitations work.
    feedback_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    feedback_attendance_required: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    cover_image_thumb_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    questions_pdf_path: Mapped[str | None] = mapped_column(String(1000))
    questions_file_name: Mapped[str | None] = mapped_column(String(255))
    archived: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    archived_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    host_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    host_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    # A draft can be explicitly submitted for review without changing public lifecycle status.
    submission_status: Mapped[str] = mapped_column(String(24), default="draft", server_default="draft", nullable=False, index=True)
    # Monotonically increases for every host submission. Review confirmations
    # are bound to this generation so an old admin screen cannot approve a
    # subsequently edited/resubmitted version of the same panel.
    submission_revision: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    submission_feedback: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Durable host notification tracking for approve/reject results. A stale
    # "sending" status means an administrator must reconcile delivery explicitly.
    submission_notification_status: Mapped[str] = mapped_column(String(20), default="not_attempted", server_default="not_attempted", nullable=False)
    submission_notification_attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    submission_notified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    submission_notification_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive)

    bookings: Mapped[list["Booking"]] = relationship(back_populates="event")
    host: Mapped["User"] = relationship()


class DiscussionSeries(Base):
    """A public, host-managed sequence of related discussion panels."""
    __tablename__ = "discussion_series"
    __table_args__ = (
        UniqueConstraint("slug", name="uq_discussion_series_slug"),
        Index("ix_discussion_series_host_status", "host_user_id", "status"),
        CheckConstraint("status IN ('published','archived')", name="ck_discussion_series_status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    host_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    organization_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True)
    slug: Mapped[str] = mapped_column(String(120), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="published", server_default="published", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class DiscussionSeriesEvent(Base):
    """Ordered event membership; duplicate panels in a series are forbidden."""
    __tablename__ = "discussion_series_events"
    __table_args__ = (
        UniqueConstraint("series_id", "event_id", name="uq_discussion_series_event"),
        UniqueConstraint("series_id", "position", name="uq_discussion_series_position"),
        Index("ix_discussion_series_events_event", "event_id"),
        CheckConstraint("position >= 0", name="ck_discussion_series_position_nonnegative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    series_id: Mapped[int] = mapped_column(ForeignKey("discussion_series.id", ondelete="CASCADE"), nullable=False)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class Booking(Base):
    __tablename__ = "bookings"
    __table_args__ = (
        CheckConstraint(
            "participant_count BETWEEN 1 AND 3",
            name="ck_bookings_participant_count_range",
        ),
        Index(
            "uq_bookings_web_client_request",
            "event_id", "booked_by_user_id", "client_request_id", unique=True,
            postgresql_where=text("client_request_id IS NOT NULL"),
            sqlite_where=text("client_request_id IS NOT NULL"),
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"))
    booked_by_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    # Optional web request key makes retries safe after a timeout or lost response.
    client_request_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    participant_count: Mapped[int] = mapped_column(Integer)
    total_amount: Mapped[Decimal] = mapped_column(Numeric(12, 0))
    # Contact number supplied for this specific booking; separate from the account profile
    # and from participant-specific numbers (which the current signup flow does not collect).
    contact_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    status: Mapped[RegistrationStatus] = mapped_column(default=RegistrationStatus.INITIATED, index=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime)
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime)
    # V80 distinguishes account-holder attendance from guest-only additional bookings.
    # NULL is retained for legacy rows whose original booking intent is ambiguous.
    registrant_attends: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    # Price/discount snapshots keep the amount auditable even if a promotion is later disabled.
    discount_code_id: Mapped[int | None] = mapped_column(ForeignKey("discount_codes.id", ondelete="SET NULL"), nullable=True)
    discount_code_snapshot: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # Keep discount scope/type after a code is disabled or its historical row is purged.
    discount_code_kind_snapshot: Mapped[str | None] = mapped_column(String(20), nullable=True)
    discount_amount: Mapped[Decimal] = mapped_column(Numeric(12, 0), default=0, server_default="0", nullable=False)
    # V63 price snapshots; NULL on pre-V63 bookings preserves their historical meaning.
    pricing_option: Mapped[str | None] = mapped_column(String(32), nullable=True)  # base / without_cafe_order
    base_price_snapshot: Mapped[Decimal | None] = mapped_column(Numeric(12, 0), nullable=True)
    alternative_price_snapshot: Mapped[Decimal | None] = mapped_column(Numeric(12, 0), nullable=True)
    # V67 cancellation follow-up; payment status remains historical and is never rewritten by event cancellation.
    cancellation_resolution: Mapped[str] = mapped_column(String(40), default="not_required", server_default="not_required", nullable=False, index=True)
    cancellation_resolution_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    cancellation_resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    event: Mapped["Event"] = relationship(back_populates="bookings")
    booked_by: Mapped["User"] = relationship(back_populates="bookings")
    participants: Mapped[list["Participant"]] = relationship(back_populates="booking", cascade="all, delete-orphan")
    payment: Mapped["Payment | None"] = relationship(back_populates="booking", uselist=False, cascade="all, delete-orphan")


class Participant(Base):
    __tablename__ = "participants"

    id: Mapped[int] = mapped_column(primary_key=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id"))
    first_name: Mapped[str | None] = mapped_column(String(100))
    last_name: Mapped[str | None] = mapped_column(String(100))
    full_name: Mapped[str] = mapped_column(String(255))
    phone_number: Mapped[str | None] = mapped_column(String(50), nullable=True)
    attendance_status: Mapped[AttendanceStatus] = mapped_column(default=AttendanceStatus.UNMARKED)
    # Set only on the account-holder participant in new primary bookings. Historical rows
    # remain NULL where a Telegram identity cannot be proven from stored data.
    user_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)

    booking: Mapped["Booking"] = relationship(back_populates="participants")


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id"), unique=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 0))
    receipt_file: Mapped[str | None] = mapped_column(String(1000))
    receipt_file_name: Mapped[str | None] = mapped_column(String(255))
    receipt_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[PaymentStatus] = mapped_column(default=PaymentStatus.PENDING)
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime)
    # Updated on every successful receipt replacement; retention is based on this field.
    receipt_uploaded_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)

    booking: Mapped["Booking"] = relationship(back_populates="payment")


class Question(Base):
    __tablename__ = "questions"

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id"))
    question_text: Mapped[str] = mapped_column(Text)
    submitted_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    category: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[ModerationStatus] = mapped_column(default=ModerationStatus.PENDING)
    answer_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    answered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    answer_notification_status: Mapped[str] = mapped_column(String(20), default="not_attempted", server_default="not_attempted", nullable=False)
    answer_notification_attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    answer_notified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    answer_notification_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    answer_notification_claimed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    answer_revision: Mapped[int] = mapped_column(Integer, default=1, server_default="1", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)


class Review(Base):
    __tablename__ = "reviews"
    __table_args__ = (
        UniqueConstraint("event_id", "user_id", name="uq_reviews_event_user"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reviewer_telegram_id: Mapped[int | None] = mapped_column(BigInteger, index=True)
    event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id"))
    booking_id: Mapped[int | None] = mapped_column(ForeignKey("bookings.id"), index=True)
    rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # Structured, optional post-panel feedback. Existing review rows remain valid.
    discussion_quality: Mapped[int | None] = mapped_column(Integer, nullable=True)
    moderator_rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    topic_relevance: Mapped[int | None] = mapped_column(Integer, nullable=True)
    would_attend_again: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    text: Mapped[str | None] = mapped_column(Text)
    status: Mapped[ModerationStatus] = mapped_column(default=ModerationStatus.PENDING)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)


class AppSetting(Base):
    __tablename__ = "app_settings"

    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    value: Mapped[str] = mapped_column(Text)
    # Keep both Python defaults and database/server defaults. Migrations use raw
    # SQL, which bypasses SQLAlchemy's Python-side defaults. Server defaults make
    # a brand-new database safe even if a historical INSERT supplies only key/value.
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utc_now_naive,
        server_default=text("CURRENT_TIMESTAMP"),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utc_now_naive,
        onupdate=utc_now_naive,
        server_default=text("CURRENT_TIMESTAMP"),
        nullable=False,
    )


class ChannelAnnouncement(Base):
    __tablename__ = "channel_announcements"
    __table_args__ = (
        UniqueConstraint("event_id", name="uq_channel_announcements_event"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"))
    # Kept under its historical column name for backward compatibility; this is
    # the exact target chat ID and can identify either a channel or a group.
    channel_id: Mapped[int] = mapped_column(BigInteger)
    destination_type: Mapped[str] = mapped_column(String(20), default="channel", server_default="channel", nullable=False)
    poster_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    initialized: Mapped[bool] = mapped_column(Boolean, default=False)
    last_capacity: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_remaining: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive)


class WaitlistEntry(Base):
    __tablename__ = "waitlist_entries"
    __table_args__ = (
        # Only one active queue entry per user/panel; closed or registered users
        # may make a fresh request later if business rules permit it.
        Index(
            "uq_waitlist_active_event_user", "event_id", "user_id", unique=True,
            postgresql_where=text("status IN ('waiting', 'invited', 'inviting')"),
            sqlite_where=text("status IN ('waiting', 'invited', 'inviting')"),
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    requested_participant_count: Mapped[int] = mapped_column(Integer)
    position: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(50), default="waiting")
    # Invitations are not seat holds. They expire after a bounded window so an
    # inactive invitee can return to the FIFO queue rather than staying stranded.
    invitation_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    next_invite_after: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)


class AdminAction(Base):
    __tablename__ = "admin_actions"

    id: Mapped[int] = mapped_column(primary_key=True)
    actor_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(100))
    entity_type: Mapped[str] = mapped_column(String(100))
    entity_id: Mapped[int | None] = mapped_column(Integer)
    details: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)


class FSMConversation(Base):
    """Durable aiogram FSM state/data scoped to the full Telegram storage key."""
    __tablename__ = "fsm_conversations"
    __table_args__ = (Index("ix_fsm_conversations_expires_at", "expires_at"),)

    storage_key: Mapped[str] = mapped_column(String(500), primary_key=True)
    state: Mapped[str | None] = mapped_column(String(255), nullable=True)
    data: Mapped[dict] = mapped_column(
        JSON().with_variant(JSONB(), "postgresql"), default=dict, nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)


class PanelPostLinkSession(Base):
    """Short-lived, one-use authorization for a group-post link initiated in DM."""
    __tablename__ = "panel_post_link_sessions"

    token: Mapped[str] = mapped_column(String(32), primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    admin_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    destination_type: Mapped[str] = mapped_column(String(20), default="group", nullable=False)
    pending_chat_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    pending_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)


class PaymentReviewAttempt(Base):
    """Immutable decision history for each distinct uploaded receipt version."""
    __tablename__ = "payment_review_attempts"
    __table_args__ = (
        UniqueConstraint("payment_id", "receipt_fingerprint", name="uq_payment_review_receipt_version"),
        Index("ix_payment_review_attempts_booking_time", "booking_id", "reviewed_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id", ondelete="CASCADE"), nullable=False)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="CASCADE"), nullable=False)
    receipt_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    decision: Mapped[str] = mapped_column(String(20), nullable=False)
    reason_category: Mapped[str | None] = mapped_column(String(40), nullable=True)
    reason_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewer_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    attempt_number: Mapped[int] = mapped_column(Integer, nullable=False)
    reviewed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)


class RewardBatch(Base):
    """Durable metadata for an idempotent personal-reward batch operation."""
    __tablename__ = "reward_batches"

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    config_json: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="preview", nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class RewardBatchRecipient(Base):
    """Per-recipient result row; unique batch/ID makes retries safe."""
    __tablename__ = "reward_batch_recipients"
    __table_args__ = (
        UniqueConstraint("batch_id", "telegram_id", name="uq_reward_batch_telegram_id"),
        Index("ix_reward_batch_recipient_outcome", "batch_id", "creation_status", "delivery_status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("reward_batches.id", ondelete="CASCADE"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    creation_status: Mapped[str] = mapped_column(String(30), default="pending", nullable=False)
    delivery_status: Mapped[str] = mapped_column(String(30), default="not_attempted", nullable=False)
    outcome_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    reward_code_id: Mapped[int | None] = mapped_column(ForeignKey("discount_codes.id", ondelete="SET NULL"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, nullable=False)


class AnnouncementBroadcast(Base):
    """Durable, idempotent broadcast run and recovery state."""
    __tablename__ = "announcement_broadcasts"

    id: Mapped[int] = mapped_column(primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    message_text: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="processing", nullable=False, index=True)
    total_recipient_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class AnnouncementDelivery(Base):
    """Per-user broadcast outcome; interrupted sends are never blindly duplicated."""
    __tablename__ = "announcement_deliveries"
    __table_args__ = (
        UniqueConstraint("broadcast_id", "telegram_id", name="uq_announcement_delivery_recipient"),
        Index("ix_announcement_delivery_status", "broadcast_id", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    broadcast_id: Mapped[int] = mapped_column(ForeignKey("announcement_broadcasts.id", ondelete="CASCADE"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="pending", nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, nullable=False)


class BookingConfirmationLedger(Base):
    """Idempotency ledger for lifetime confirmations.

    ``booking_id`` deliberately has no foreign key: historical confirmations must
    survive cleanup/deletion of an event's individual booking rows.
    """
    __tablename__ = "booking_confirmation_ledger"
    __table_args__ = (
        UniqueConstraint("booking_id", name="uq_confirmation_ledger_booking"),
        Index("ix_confirmation_ledger_user_id", "user_id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    booking_id: Mapped[int] = mapped_column(Integer, nullable=False)
    confirmed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)

class BlockedUser(Base):
    """Telegram-ID blocklist, independent of profile existence and booking retention.

    Rows intentionally have no FK to ``users`` so an admin can block a numeric
    Telegram ID before that person starts the bot, and moderation survives any
    cleanup of an individual user's booking data.
    """
    __tablename__ = "blocked_users"

    telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    blocked_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    blocked_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    # Throttle denial messages so a blocked spammer cannot make the bot reply to
    # every repeated message. Callback queries still receive a short alert.
    last_notice_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)



class DiscountCode(Base):
    """Public promotional code or private, recipient-bound reward."""
    __tablename__ = "discount_codes"

    id: Mapped[int] = mapped_column(primary_key=True)
    # Null for private rewards, which are delivered as a Telegram gift, not a code.
    code: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True, index=True)
    label: Mapped[str] = mapped_column(String(255), default="")
    kind: Mapped[str] = mapped_column(String(20), index=True)  # public, restricted, personal
    discount_type: Mapped[str] = mapped_column(String(20))  # percent, fixed
    discount_value: Mapped[Decimal] = mapped_column(Numeric(12, 0))
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", index=True, nullable=False)
    max_redemptions: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # once_total or once_per_panel for public codes. Personal rewards are always once_total.
    usage_policy: Mapped[str] = mapped_column(String(30), default="once_total", server_default="once_total")
    recipient_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    disabled_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    disabled_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)


class DiscountCodeEvent(Base):
    """Explicit event scope; drafts may be selected for advance planning."""
    __tablename__ = "discount_code_events"
    __table_args__ = (
        UniqueConstraint("discount_code_id", "event_id", name="uq_discount_code_event"),
        Index("ix_discount_code_events_event", "event_id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    discount_code_id: Mapped[int] = mapped_column(ForeignKey("discount_codes.id", ondelete="CASCADE"), nullable=False)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)


class DiscountRedemption(Base):
    """Approval/redeeming history. Pending requests persist checkout data but never reserve capacity."""
    __tablename__ = "discount_redemptions"
    __table_args__ = (
        Index("ix_discount_redemptions_code_user_status", "discount_code_id", "user_telegram_id", "status"),
        Index("ix_discount_redemptions_status_created", "status", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    discount_code_id: Mapped[int | None] = mapped_column(ForeignKey("discount_codes.id", ondelete="SET NULL"), nullable=True)
    code_snapshot: Mapped[str] = mapped_column(String(64), default="")
    event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id", ondelete="SET NULL"), nullable=True)
    event_label_snapshot: Mapped[str] = mapped_column(String(400), default="")
    user_telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    # Used only until the request is resolved; cleared once the registration is finalized/cancelled.
    draft_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    contact_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    participant_count: Mapped[int] = mapped_column(Integer, default=1)
    allow_duplicate: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    booking_id: Mapped[int | None] = mapped_column(ForeignKey("bookings.id", ondelete="SET NULL"), nullable=True, index=True)
    original_total: Mapped[Decimal | None] = mapped_column(Numeric(12, 0), nullable=True)
    discount_amount: Mapped[Decimal | None] = mapped_column(Numeric(12, 0), nullable=True)
    final_total: Mapped[Decimal | None] = mapped_column(Numeric(12, 0), nullable=True)
    reviewed_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # Message originally sent to the applicant; lets approval/rejection update it in-place.
    request_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    redeemed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive)


class CommunityChallenge(Base):
    """Community challenge; cleared rows retain only sequence/lifecycle metadata."""
    __tablename__ = "community_challenges"
    __table_args__ = (
        Index("ix_community_challenges_status_sequence", "status", "published_sequence"),
        UniqueConstraint("published_sequence", name="uq_community_challenge_sequence"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str | None] = mapped_column(String(180), nullable=True)
    prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    challenge_type: Mapped[str] = mapped_column(String(20), default="knowledge", nullable=False)
    reference_answer: Mapped[str | None] = mapped_column(Text, nullable=True)
    winner_count: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="open", index=True, nullable=False)
    published_sequence: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    results_finalized_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    cleared_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class ChallengeSubmission(Base):
    """Private answer, one per Telegram account/challenge."""
    __tablename__ = "challenge_submissions"
    __table_args__ = (
        UniqueConstraint("challenge_id", "telegram_id", name="uq_challenge_submission_user"),
        Index("ix_challenge_submissions_challenge", "challenge_id", "id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    challenge_id: Mapped[int] = mapped_column(ForeignKey("community_challenges.id", ondelete="CASCADE"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    answer_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    judging_status: Mapped[str] = mapped_column(String(20), default="unmarked", nullable=False)
    selected_place: Mapped[int | None] = mapped_column(Integer, nullable=True)
    submitted_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)


class ChallengeResultNotification(Base):
    """Track per-participant delivery of the final result announcement."""
    __tablename__ = "challenge_result_notifications"
    __table_args__ = (
        UniqueConstraint("challenge_id", "telegram_id", name="uq_challenge_result_notification_recipient"),
        CheckConstraint("status IN ('pending', 'sending', 'sent', 'failed')", name="ck_challenge_result_notification_status"),
        CheckConstraint("attempts >= 0", name="ck_challenge_result_notification_attempts"),
        Index("ix_challenge_result_notifications_status_created", "status", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    challenge_id: Mapped[int] = mapped_column(ForeignKey("community_challenges.id", ondelete="CASCADE"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    challenge_title_snapshot: Mapped[str] = mapped_column(String(180), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class XPAward(Base):
    """Append-only XP ledger with stable idempotency key and no FK to mutable content."""
    __tablename__ = "xp_awards"
    __table_args__ = (
        UniqueConstraint("award_key", name="uq_xp_award_key"),
        Index("ix_xp_awards_user_created", "telegram_id", "created_at"),
        Index("ix_xp_awards_type_event_user", "award_type", "event_id", "telegram_id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    points: Mapped[int] = mapped_column(Integer, nullable=False)
    award_type: Mapped[str] = mapped_column(String(50), nullable=False)
    award_key: Mapped[str] = mapped_column(String(220), nullable=False)
    event_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    challenge_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    source_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    note: Mapped[str | None] = mapped_column(String(300), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)


class CommunityProfile(Base):
    """Compact lifetime aggregates that survive challenge answer cleanup."""
    __tablename__ = "community_profiles"

    telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    challenge_participations: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    correct_answers: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    creative_first: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    creative_second: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    creative_third: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    reviews_submitted: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    recognized_contributions: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    current_streak: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    best_streak: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_finalized_sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    onboarding_sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, nullable=False)


class AchievementUnlock(Base):
    __tablename__ = "achievement_unlocks"
    __table_args__ = (UniqueConstraint("telegram_id", "achievement_key", name="uq_achievement_user_key"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    achievement_key: Mapped[str] = mapped_column(String(80), nullable=False)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    unlocked_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    celebrated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class WrappedReport(Base):
    __tablename__ = "wrapped_reports"
    __table_args__ = (UniqueConstraint("telegram_id", "report_year", name="uq_wrapped_user_year"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    report_year: Mapped[int] = mapped_column(Integer, nullable=False)
    report_text: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="generated", nullable=False)
    generated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, nullable=False)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str | None] = mapped_column(String(300), nullable=True)


class AttendanceAudit(Base):
    """Append-only record of attendance corrections and check-ins."""
    __tablename__ = "attendance_audits"
    __table_args__ = (Index("ix_attendance_audits_event_time", "event_id", "created_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id", ondelete="CASCADE"), nullable=False)
    actor_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    old_status: Mapped[str] = mapped_column(String(20), nullable=False)
    new_status: Mapped[str] = mapped_column(String(20), nullable=False)
    source: Mapped[str] = mapped_column(String(20), default="admin", server_default="admin", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class AdminDraftSnapshot(Base):
    """Recoverable snapshot of high-value admin event create/edit FSM workflows."""
    __tablename__ = "admin_draft_snapshots"

    admin_telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    state_name: Mapped[str] = mapped_column(String(160), nullable=False)
    data_json: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class ReferralVerification(Base):
    """Manual verification decision for an attributed invitee; attribution itself stays immutable."""
    __tablename__ = "referral_verifications"
    __table_args__ = (Index("ix_referral_verifications_verified_at", "verified", "verified_at"),)

    invitee_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    verified_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class TopicSuggestion(Base):
    """Member-submitted topic ideas that can be moderated and voted on."""
    __tablename__ = "topic_suggestions"
    __table_args__ = (Index("ix_topic_suggestions_status_created", "status", "created_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    moderator_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    moderation_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    moderated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class TopicVote(Base):
    """One active vote per user and topic suggestion."""
    __tablename__ = "topic_votes"
    __table_args__ = (UniqueConstraint("topic_id", "user_id", name="uq_topic_votes_topic_user"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topic_suggestions.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class AdminUserNote(Base):
    """Private, append-only internal notes attached to a registered user."""
    __tablename__ = "admin_user_notes"
    __table_args__ = (Index("ix_admin_user_notes_target_created", "target_user_id", "created_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    target_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    actor_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    note_text: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class UserModerationRecord(Base):
    """Durable moderation record; target Telegram ID survives ordinary row cleanup."""
    __tablename__ = "user_moderation_records"
    __table_args__ = (
        Index("ix_user_moderation_target_created", "target_telegram_id", "created_at"),
        Index("ix_user_moderation_active_expiry", "target_telegram_id", "active", "expires_at"),
        Index("ix_user_moderation_scope_active_expiry", "target_telegram_id", "action", "scope", "active", "expires_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    target_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    actor_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    action: Mapped[str] = mapped_column(String(32), nullable=False)  # warning / suspension / restriction / unban
    scope: Mapped[str] = mapped_column(String(40), default="account", server_default="account", nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class AdminPrivateMessage(Base):
    """Audit trail for admin-initiated private messages; send status is explicit."""
    __tablename__ = "admin_private_messages"
    __table_args__ = (Index("ix_admin_private_messages_target_created", "target_telegram_id", "created_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    actor_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    target_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    message_text: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    error_summary: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class AdminAnnouncement(Base):
    """Unified manual announcement operation, independent of legacy V62 runs."""
    __tablename__ = "admin_announcements"
    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_admin_announcements_idempotency"),
        Index("ix_admin_announcements_created", "created_at"),
        Index("ix_admin_announcements_event_created", "event_id", "created_at"),
        Index("ix_admin_announcements_status", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(64), nullable=False)
    announcement_type: Mapped[str] = mapped_column(String(32), nullable=False)  # upcoming / panel / participants
    purpose: Mapped[str] = mapped_column(String(40), nullable=False)
    event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id", ondelete="SET NULL"), nullable=True)
    actor_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    audience_policy: Mapped[str] = mapped_column(String(60), nullable=False)
    message_text: Mapped[str] = mapped_column(Text, nullable=False)
    message_meta_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="preview", server_default="preview", nullable=False)
    recipient_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    sent_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    failed_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    skipped_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class AdminAnnouncementDelivery(Base):
    """Per-recipient result; unique rows prevent repeat-send callbacks from cloning work."""
    __tablename__ = "admin_announcement_deliveries"
    __table_args__ = (
        UniqueConstraint("announcement_id", "telegram_id", name="uq_admin_announcement_recipient"),
        Index("ix_admin_announcement_delivery_status", "announcement_id", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    announcement_id: Mapped[int] = mapped_column(ForeignKey("admin_announcements.id", ondelete="CASCADE"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    last_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), onupdate=utc_now_naive, nullable=False)


class PanelAnnouncementPost(Base):
    """Channel post state scoped to an individual panel; no global history."""
    __tablename__ = "panel_announcement_posts"
    __table_args__ = (
        Index("ix_panel_announcement_posts_event_created", "event_id", "created_at"),
        Index("ix_panel_announcement_posts_status_created", "status", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    actor_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    chat_id: Mapped[str] = mapped_column(String(255), nullable=False)
    message_text: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="preview", server_default="preview", nullable=False)
    telegram_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    last_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    published_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class ArchivedPanelContent(Base):
    """Optional public recap for an already-archived, completed panel; never stores media."""
    __tablename__ = "archived_panel_content"
    __table_args__ = (UniqueConstraint("event_id", name="uq_archived_panel_content_event"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    recap: Mapped[str | None] = mapped_column(Text, nullable=True)
    highlights: Mapped[str | None] = mapped_column(Text, nullable=True)
    tags_json: Mapped[str] = mapped_column(Text, default="[]", server_default="[]", nullable=False)
    links_json: Mapped[str] = mapped_column(Text, default="[]", server_default="[]", nullable=False)
    updated_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class QuickFunActivity(Base):
    """Persisted text-only, non-progression entertainment activity."""
    __tablename__ = "quick_fun_activities"
    __table_args__ = (Index("ix_quick_fun_status_kind", "status", "kind", "created_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(20), nullable=False)  # quiz / wyr / riddle
    title: Mapped[str] = mapped_column(String(180), nullable=False)
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    options_json: Mapped[str] = mapped_column(Text, default="[]", server_default="[]", nullable=False)
    correct_option: Mapped[int | None] = mapped_column(Integer, nullable=True)
    answer_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    explanation: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="draft", server_default="draft", nullable=False, index=True)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    updated_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class QuickFunResponse(Base):
    """One private response per activity/person; aggregate queries expose no identities."""
    __tablename__ = "quick_fun_responses"
    __table_args__ = (
        UniqueConstraint("activity_id", "telegram_id", name="uq_quick_fun_response_user"),
        Index("ix_quick_fun_response_activity_value", "activity_id", "response_value"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    activity_id: Mapped[int] = mapped_column(ForeignKey("quick_fun_activities.id", ondelete="CASCADE"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    response_value: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class XPShopOffer(Base):
    """Administrator-managed percentage reward catalogue; existing requests snapshot their terms."""
    __tablename__ = "xp_shop_offers"
    __table_args__ = (
        CheckConstraint("discount_percent BETWEEN 1 AND 100", name="ck_xp_shop_offer_percent"),
        CheckConstraint("xp_cost BETWEEN 1 AND 1000000", name="ck_xp_shop_offer_cost"),
        CheckConstraint("usage_limit IS NULL OR usage_limit > 0", name="ck_xp_shop_offer_usage_limit"),
        Index("ix_xp_shop_offers_active_sort", "active", "sort_order", "id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    discount_percent: Mapped[int] = mapped_column(Integer, nullable=False)
    xp_cost: Mapped[int] = mapped_column(Integer, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    revision: Mapped[int] = mapped_column(Integer, default=1, server_default="1", nullable=False)
    usage_limit: Mapped[int | None] = mapped_column(Integer, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=100, server_default="100", nullable=False)
    created_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class ShopRequest(Base):
    """XP-reserved request; debit occurs once only after admin approval."""
    __tablename__ = "shop_requests"
    __table_args__ = (
        Index("ix_shop_requests_status_created", "status", "created_at"),
        Index("ix_shop_requests_user_status", "telegram_id", "status"),
        CheckConstraint("discount_percent BETWEEN 1 AND 100", name="ck_shop_request_percent"),
        CheckConstraint("xp_cost > 0", name="ck_shop_request_cost_positive"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    offer_id: Mapped[int | None] = mapped_column(ForeignKey("xp_shop_offers.id", ondelete="SET NULL"), nullable=True, index=True)
    offer_title_snapshot: Mapped[str | None] = mapped_column(String(120), nullable=True)
    offer_description_snapshot: Mapped[str | None] = mapped_column(Text, nullable=True)
    discount_percent: Mapped[int] = mapped_column(Integer, nullable=False)
    xp_cost: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="pending", server_default="pending", nullable=False)
    reviewed_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    denial_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Admin alert delivery is observable/retryable; the request itself remains the source of truth.
    admin_notification_status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    admin_notification_attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    admin_notified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    admin_notification_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class LuckyDrawCampaign(Base):
    """Explicitly activated, free, independently auditable user-claimed draw campaign."""
    __tablename__ = "lucky_draw_campaigns"
    __table_args__ = (
        Index("ix_lucky_draw_campaign_active", "active", "created_at"),
        Index("uq_lucky_draw_single_active", "active", unique=True,
              postgresql_where=text("active IS TRUE"), sqlite_where=text("active = 1")),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    label: Mapped[str] = mapped_column(String(180), nullable=False)
    probabilities_json: Mapped[str] = mapped_column(Text, nullable=False)
    config_version: Mapped[int] = mapped_column(Integer, default=1, server_default="1", nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    activated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    deactivated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class LuckyDrawClaim(Base):
    """One durable user claim per campaign; outcome/odds are immutable snapshots."""
    __tablename__ = "lucky_draw_claims"
    __table_args__ = (
        UniqueConstraint("campaign_id", "telegram_id", name="uq_lucky_draw_claim_user_campaign"),
        CheckConstraint("discount_percent IN (15, 25, 50, 100)", name="ck_lucky_draw_claim_percent"),
        Index("ix_lucky_draw_claim_campaign_created", "campaign_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    campaign_id: Mapped[int] = mapped_column(ForeignKey("lucky_draw_campaigns.id", ondelete="RESTRICT"), nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    discount_percent: Mapped[int] = mapped_column(Integer, nullable=False)
    odds_snapshot_json: Mapped[str] = mapped_column(Text, nullable=False)
    config_version: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class RewardIssue(Base):
    """Shared, audited manual code-issuance/delivery queue for shop and draw rewards."""
    __tablename__ = "reward_issues"
    __table_args__ = (
        UniqueConstraint("source_type", "source_id", name="uq_reward_issue_source"),
        Index("uq_reward_issue_discount_code_id", "discount_code_id", unique=True),
        Index("ix_reward_issues_status_created", "status", "created_at"),
        Index("ix_reward_issues_user_created", "telegram_id", "created_at"),
        CheckConstraint("discount_percent BETWEEN 1 AND 100", name="ck_reward_issue_percent"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    source_type: Mapped[str] = mapped_column(String(20), nullable=False)  # shop / lucky_draw
    source_id: Mapped[int] = mapped_column(Integer, nullable=False)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    discount_percent: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="awaiting_code", server_default="awaiting_code", nullable=False)
    discount_code_id: Mapped[int | None] = mapped_column(ForeignKey("discount_codes.id", ondelete="SET NULL"), nullable=True)
    assigned_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    assigned_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    delivery_state: Mapped[str] = mapped_column(String(30), default="not_attempted", server_default="not_attempted", nullable=False)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    delivery_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # A durable retry marker for administrator notifications, separate from user reward delivery.
    admin_notification_status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    admin_notification_attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    admin_notified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    admin_notification_error: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class WebsiteLoginChallenge(Base):
    """Short-lived, one-time browser login handoff confirmed inside Telegram."""
    __tablename__ = "website_login_challenges"
    __table_args__ = (Index("ix_website_login_challenges_status_expiry", "status", "expires_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=True)
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    authenticated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class WebsiteSavedEvent(Base):
    """Website-exclusive saved/favourite event collection, linked to the bot user."""
    __tablename__ = "website_saved_events"
    __table_args__ = (UniqueConstraint("user_id", "event_id", name="uq_website_saved_event_user_event"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class WebsiteRecentEventView(Base):
    """Private, bounded per-member recent panel history for the activity dashboard."""
    __tablename__ = "website_recent_event_views"
    __table_args__ = (
        UniqueConstraint("user_id", "event_id", name="uq_website_recent_view_user_event"),
        Index("ix_website_recent_views_user_viewed", "user_id", "last_viewed_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    view_count: Mapped[int] = mapped_column(Integer, default=1, server_default="1", nullable=False)
    last_viewed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)

# National organization ecosystem. Memberships are explicit tenant grants;
# never infer organization access from the global User.role field.
class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    logo_url: Mapped[str | None] = mapped_column(String(1000))
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    is_platform_founder: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    founding_city_id: Mapped[int | None] = mapped_column(ForeignKey("cities.id", ondelete="SET NULL"))
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class OrganizationMembership(Base):
    __tablename__ = "organization_memberships"
    __table_args__ = (
        UniqueConstraint("organization_id", "user_id", name="uq_org_membership_user"),
        UniqueConstraint("organization_id", "id", name="uq_org_membership_org_id"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    role: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)


class Brand(Base):
    __tablename__ = "brands"
    __table_args__ = (
        UniqueConstraint("organization_id", "slug", name="uq_brand_org_slug"),
        UniqueConstraint("organization_id", "id", name="uq_brand_org_id"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    slug: Mapped[str] = mapped_column(String(100), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    logo_url: Mapped[str | None] = mapped_column(String(1000))
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class BrandHostAssignment(Base):
    __tablename__ = "brand_host_assignments"
    __table_args__ = (
        ForeignKeyConstraint(["organization_id", "brand_id"], ["brands.organization_id", "brands.id"], ondelete="CASCADE", name="fk_brand_assignment_brand_tenant"),
        ForeignKeyConstraint(["organization_id", "membership_id"], ["organization_memberships.organization_id", "organization_memberships.id"], ondelete="CASCADE", name="fk_brand_assignment_membership_tenant"),
    )
    organization_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    membership_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class OrganizationCity(Base):
    __tablename__ = "organization_cities"
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), primary_key=True)
    city_id: Mapped[int] = mapped_column(ForeignKey("cities.id", ondelete="RESTRICT"), primary_key=True)


class HostVerification(Base):
    __tablename__ = "host_verifications"
    __table_args__ = (Index("ix_host_verifications_user_updated", "user_id", "updated_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False, index=True)
    legal_name: Mapped[str | None] = mapped_column(String(255))
    # Only authenticated ciphertext belongs here. The application has no plaintext fallback.
    national_id_ciphertext: Mapped[bytes | None] = mapped_column()
    national_id_fingerprint: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    date_of_birth: Mapped[date | None] = mapped_column(Date)
    verified_mobile: Mapped[str | None] = mapped_column(String(50))
    email: Mapped[str | None] = mapped_column(String(255))
    residence_city_id: Mapped[int | None] = mapped_column(ForeignKey("cities.id", ondelete="SET NULL"))
    biography: Mapped[str | None] = mapped_column(Text)
    hosting_experience: Mapped[str | None] = mapped_column(Text)
    rejection_reason: Mapped[str | None] = mapped_column(Text)
    requested_information: Mapped[str | None] = mapped_column(Text)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime)
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class HostApplication(Base):
    """A member's host application. Identity values are encrypted before storage."""
    __tablename__ = "host_applications"
    __table_args__ = (
        UniqueConstraint("user_id", name="uq_host_applications_user"),
        CheckConstraint(
            "status IN ('draft','submitted','under_review','more_information_required','approved','rejected','withdrawn')",
            name="ck_host_applications_status",
        ),
        Index("ix_host_applications_status_submitted", "status", "submitted_at"),
        Index("ix_host_applications_city_status", "residence_city_id", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(40), default="draft", server_default="draft", nullable=False)
    legal_name: Mapped[str | None] = mapped_column(String(255))
    national_id_ciphertext: Mapped[bytes | None] = mapped_column()
    national_id_fingerprint: Mapped[str | None] = mapped_column(String(64), nullable=True)
    date_of_birth: Mapped[date | None] = mapped_column(Date)
    verified_mobile: Mapped[str | None] = mapped_column(String(50))
    email: Mapped[str | None] = mapped_column(String(255))
    residence_city_id: Mapped[int | None] = mapped_column(ForeignKey("cities.id", ondelete="SET NULL"), nullable=True, index=True)
    english_proficiency: Mapped[str | None] = mapped_column(String(60))
    english_certification: Mapped[str | None] = mapped_column(String(255))
    relevant_experience: Mapped[str | None] = mapped_column(Text)
    hosting_background: Mapped[str | None] = mapped_column(Text)
    motivation: Mapped[str | None] = mapped_column(Text)
    portfolio_url: Mapped[str | None] = mapped_column(String(1000))
    preferred_city_ids: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    preferred_topics: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    preferred_formats: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    availability: Mapped[str | None] = mapped_column(Text)
    public_display_name: Mapped[str | None] = mapped_column(String(255))
    public_bio: Mapped[str | None] = mapped_column(Text)
    public_languages: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    applicant_response: Mapped[str | None] = mapped_column(Text)
    requested_information: Mapped[str | None] = mapped_column(Text)
    rejection_reason: Mapped[str | None] = mapped_column(Text)
    internal_notes: Mapped[str | None] = mapped_column(Text)
    interview_at: Mapped[datetime | None] = mapped_column(DateTime)
    interview_location: Mapped[str | None] = mapped_column(String(500))
    interview_notes: Mapped[str | None] = mapped_column(Text)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime)
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    withdrawn_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))


class HostApplicationHistory(Base):
    __tablename__ = "host_application_history"
    __table_args__ = (Index("ix_host_application_history_app_created", "application_id", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("host_applications.id", ondelete="CASCADE"), nullable=False, index=True)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    action: Mapped[str] = mapped_column(String(60), nullable=False)
    from_status: Mapped[str | None] = mapped_column(String(40))
    to_status: Mapped[str | None] = mapped_column(String(40))
    note: Mapped[str | None] = mapped_column(Text)
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))


class HostApplicationNotification(Base):
    __tablename__ = "host_application_notifications"
    __table_args__ = (Index("ix_host_application_notifications_user_created", "user_id", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("host_applications.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(180), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    read_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))


class HostPublicProfile(Base):
    __tablename__ = "host_public_profiles"
    __table_args__ = (UniqueConstraint("user_id", name="uq_host_public_profiles_user"), UniqueConstraint("slug", name="uq_host_public_profiles_slug"))
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    slug: Mapped[str] = mapped_column(String(120), nullable=False)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    bio: Mapped[str | None] = mapped_column(Text)
    languages: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    topics: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    city_ids: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))


class OrganizationVerification(Base):
    __tablename__ = "organization_verifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False, index=True)
    official_name: Mapped[str | None] = mapped_column(String(255))
    registration_number_ciphertext: Mapped[bytes | None] = mapped_column()
    national_legal_id_ciphertext: Mapped[bytes | None] = mapped_column()
    registered_address: Mapped[str | None] = mapped_column(Text)
    representative_name: Mapped[str | None] = mapped_column(String(255))
    rejection_reason: Mapped[str | None] = mapped_column(Text)
    requested_information: Mapped[str | None] = mapped_column(Text)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime)
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    price_amount: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    currency: Mapped[str] = mapped_column(String(12), default="IRR", nullable=False)
    duration_days: Mapped[int] = mapped_column(Integer, nullable=False)
    max_brands: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    max_hosts: Mapped[int] = mapped_column(Integer, default=2, nullable=False)
    features: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class OrganizationSubscription(Base):
    __tablename__ = "organization_subscriptions"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("subscription_plans.id", ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(20), default="trial", nullable=False)
    starts_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    ends_at: Mapped[datetime | None] = mapped_column(DateTime)
    price_amount: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    currency: Mapped[str] = mapped_column(String(12), default="IRR", nullable=False)
    notes: Mapped[str | None] = mapped_column(String(1000))
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class PlatformAuditLog(Base):
    __tablename__ = "platform_audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    organization_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id", ondelete="SET NULL"), index=True)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    target_type: Mapped[str | None] = mapped_column(String(60))
    target_id: Mapped[str | None] = mapped_column(String(100))
    reason: Mapped[str | None] = mapped_column(Text)
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text("CURRENT_TIMESTAMP"))


class UserTopicFollow(Base):
    """A normalized, private follow relationship to a Panel Flow taxonomy topic."""
    __tablename__ = "user_topic_follows"
    __table_args__ = (UniqueConstraint("user_id", "topic_key", name="uq_user_topic_follow"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    topic_key: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class UserOrganizationFollow(Base):
    """Follow relationship to an approved public organization."""
    __tablename__ = "user_organization_follows"
    __table_args__ = (UniqueConstraint("user_id", "organization_id", name="uq_user_organization_follow"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class UserDiscoveryPreference(Base):
    """Optional recommendation and promotional-notification preferences."""
    __tablename__ = "user_discovery_preferences"
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    preferred_city_id: Mapped[int | None] = mapped_column(ForeignKey("cities.id", ondelete="SET NULL"), nullable=True)
    preferred_language: Mapped[str | None] = mapped_column(String(80), nullable=True)
    preferred_format: Mapped[str | None] = mapped_column(String(16), nullable=True)
    notify_followed_topics: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    notify_followed_organizations: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    notify_panel_changes: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    notify_registration_reminders: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    # Optional followed-panel alerts can be delivered immediately or in a digest.
    digest_frequency: Mapped[str] = mapped_column(String(12), default="immediate", server_default="immediate", nullable=False)
    quiet_hours_start: Mapped[str | None] = mapped_column(String(5), nullable=True)
    quiet_hours_end: Mapped[str | None] = mapped_column(String(5), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class EventNotificationDelivery(Base):
    """Idempotency ledger shared by follow alerts, event changes and reminders."""
    __tablename__ = "event_notification_deliveries"
    __table_args__ = (
        UniqueConstraint("event_id", "user_id", "notification_key", name="uq_event_notification_delivery"),
        CheckConstraint("status IN ('pending','sent','failed','skipped')", name="ck_event_notification_delivery_status"),
        Index("ix_event_notification_deliveries_next_attempt", "status", "next_attempt_at"),
        Index("ix_event_notification_deliveries_digest_due", "digest_due_at"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    notification_key: Mapped[str] = mapped_column(String(100), nullable=False)
    notification_type: Mapped[str] = mapped_column(String(40), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", server_default="pending", nullable=False)
    reason: Mapped[str | None] = mapped_column(String(80), nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    last_error: Mapped[str | None] = mapped_column(String(120), nullable=True)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, onupdate=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    # Populated only for optional promotional digests. Transactional messages
    # continue to be delivered independently and are never bundled.
    digest_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    digest_due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class RecommendationFeedback(Base):
    """Private, explainable negative feedback used to suppress unwanted recommendations."""
    __tablename__ = "recommendation_feedback"
    __table_args__ = (
        UniqueConstraint("user_id", "event_id", name="uq_recommendation_feedback_user_event"),
        CheckConstraint("feedback IN ('not_interested')", name="ck_recommendation_feedback_kind"),
        Index("ix_recommendation_feedback_user_feedback", "user_id", "feedback"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    feedback: Mapped[str] = mapped_column(String(24), default="not_interested", server_default="not_interested", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"), nullable=False)


class NotificationOutbox(Base):
    """Durable, idempotent queue for side effects committed with domain changes."""
    __tablename__ = "notification_outbox"
    __table_args__ = (
        UniqueConstraint("dedupe_key", name="uq_notification_outbox_dedupe_key"),
        CheckConstraint("status IN ('pending','processing','sent','failed')", name="ck_notification_outbox_status"),
        Index("ix_notification_outbox_claim", "status", "available_at", "id"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    dedupe_key: Mapped[str] = mapped_column(String(180), nullable=False)
    event_type: Mapped[str] = mapped_column(String(80), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON().with_variant(JSONB, "postgresql"), nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending", server_default="pending")
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    available_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))
    locked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str | None] = mapped_column(String(240), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=utc_now_naive, server_default=text("CURRENT_TIMESTAMP"))
