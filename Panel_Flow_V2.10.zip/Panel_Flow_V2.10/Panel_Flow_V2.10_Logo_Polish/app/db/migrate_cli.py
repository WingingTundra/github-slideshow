"""Database migration CLI. Apply with ``python -m app.db.migrate_cli`` or inspect with ``--check``."""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import logging
import sys
from pathlib import Path

from sqlalchemy import text
from app.db.init import MIGRATION_DIR, init_db
from app.db.session import engine, dispose_database_engines


async def _check() -> int:
    migration_paths = sorted(MIGRATION_DIR.glob("*.sql"))
    try:
        async with engine.connect() as conn:
            table = await conn.scalar(text("SELECT to_regclass('public.schema_migrations')"))
            if table is None:
                print("schema_migrations is missing; database has not been initialized.")
                return 1
            rows = (await conn.execute(text("SELECT version, checksum FROM schema_migrations"))).all()
    except Exception as exc:
        print(f"Could not inspect database migration state: {type(exc).__name__}: {exc}")
        return 1
    applied = {str(version): checksum for version, checksum in rows}
    pending = [path.name for path in migration_paths if path.name not in applied]
    mismatched = []
    for path in migration_paths:
        recorded = applied.get(path.name)
        if recorded:
            current = hashlib.sha256(path.read_bytes()).hexdigest()
            if current != recorded:
                mismatched.append(path.name)
    if mismatched:
        print("Checksum mismatch (applied migrations must remain immutable): " + ", ".join(mismatched))
        return 1
    if pending:
        print("Pending migrations: " + ", ".join(pending))
        return 1
    print(f"Database is up to date; verified {len(migration_paths)} migration checksums.")
    return 0


async def _main() -> int:
    parser = argparse.ArgumentParser(description="Panel Flow database migration utility")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="verify applied versions and checksums without applying changes")
    mode.add_argument("--apply", action="store_true", help="apply pending migrations (default)")
    args = parser.parse_args()
    try:
        if args.check:
            return await _check()
        await init_db()
        print("Database migrations are up to date.")
        return 0
    finally:
        await dispose_database_engines()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    raise SystemExit(asyncio.run(_main()))
