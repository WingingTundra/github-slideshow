"""Tenant-safe national organization, brand, verification and subscription APIs.

All organization data access is checked server-side. Public endpoints expose only
approved entities; private endpoints require an approved membership or a platform
administrator. National identity numbers are encrypted before persistence and never
returned by these routes.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import re
from pathlib import Path
from datetime import timedelta
from typing import Literal

from cryptography.fernet import Fernet, InvalidToken
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import delete, func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.db.models import (
    Brand, BrandHostAssignment, City, Event, HostVerification, Organization,
    OrganizationCity, OrganizationMembership, OrganizationSubscription,
    OrganizationVerification, PlatformAuditLog, SubscriptionPlan, User, UserOrganizationFollow,
)
from app.db.session import get_session
from app.http_api.dependencies import get_current_api_user
from app.time_utils import tehran_today, utc_now_naive
from app.services.tenant_access import active_organization_subscription

router = APIRouter(prefix="/api/v1", tags=["National organizations"])

ROLES = {"owner", "admin", "host", "moderator", "finance"}
MEMBERSHIP_STATES = {"pending", "approved", "rejected", "suspended"}


class OrganizationCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=2, max_length=200)
    slug: str = Field(min_length=3, max_length=100, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    description: str | None = Field(default=None, max_length=5000)
    logo_url: str | None = Field(default=None, max_length=1000)
    city_ids: list[int] = Field(default_factory=list, max_length=30)


class OrganizationProfileUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = Field(default=None, min_length=2, max_length=200)
    description: str | None = Field(default=None, max_length=5000)

    @field_validator("name", "description")
    @classmethod
    def strip_profile_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized and value == "":
            return "" if value == "" else None
        return normalized


class BrandCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    slug: str = Field(min_length=2, max_length=100, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    name: str = Field(min_length=2, max_length=200)
    description: str | None = Field(default=None, max_length=5000)
    logo_url: str | None = Field(default=None, max_length=1000)


class Decision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: str = Field(pattern=r"^(approved|rejected|suspended|pending)$")
    reason: str | None = Field(default=None, max_length=1000)


class MembershipRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    requested_role: str = Field(default="host", pattern=r"^(host|moderator)$")
    message: str | None = Field(default=None, max_length=1000)


class BrandHostAssignmentInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    membership_ids: list[int] = Field(default_factory=list, max_length=100)


class OrganizationVerificationInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    official_name: str = Field(min_length=2, max_length=255)
    registration_number: str | None = Field(default=None, max_length=100)
    national_legal_id: str | None = Field(default=None, max_length=100)
    registered_address: str | None = Field(default=None, max_length=2000)
    representative_name: str | None = Field(default=None, max_length=255)


class MembershipDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: str = Field(pattern=r"^(approved|rejected|suspended)$")
    role: str = Field(default="host", pattern=r"^(admin|host|moderator|finance)$")
    reason: str | None = Field(default=None, max_length=1000)


class HostVerificationInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    legal_name: str = Field(min_length=3, max_length=255)
    national_id: str = Field(min_length=10, max_length=10)
    date_of_birth: str | None = Field(default=None, pattern=r"^\d{4}-\d{2}-\d{2}$")
    verified_mobile: str = Field(min_length=10, max_length=50)
    email: str = Field(min_length=5, max_length=255)
    residence_city_id: int | None = Field(default=None, gt=0)
    biography: str | None = Field(default=None, max_length=3000)
    hosting_experience: str | None = Field(default=None, max_length=3000)

    @field_validator("legal_name", "verified_mobile", "email")
    @classmethod
    def strip_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be blank")
        return value

    @field_validator("national_id")
    @classmethod
    def normalize_national_code(cls, value: str) -> str:
        table = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
        code = value.translate(table).strip()
        if not re.fullmatch(r"\d{10}", code) or len(set(code)) == 1:
            raise ValueError("کد ملی معتبر نیست")
        total = sum(int(code[i]) * (10 - i) for i in range(9))
        remainder = total % 11
        check = remainder if remainder < 2 else 11 - remainder
        if check != int(code[9]):
            raise ValueError("کد ملی معتبر نیست")
        return code


class VerificationDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: str = Field(pattern=r"^(approved|rejected|suspended|pending)$")
    reason: str | None = Field(default=None, max_length=2000)
    requested_information: str | None = Field(default=None, max_length=2000)


class PlanCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str = Field(min_length=2, max_length=40, pattern=r"^[a-z0-9_-]+$")
    name: str = Field(min_length=2, max_length=120)
    price_amount: int = Field(ge=0, le=10**12)
    currency: str = Field(default="IRR", pattern=r"^(IRR|TOMAN)$")
    duration_days: int = Field(ge=1, le=3650)
    max_brands: int = Field(ge=1, le=100)
    max_hosts: int = Field(ge=1, le=1000)
    features: dict = Field(default_factory=dict)
    is_active: bool = True


class SubscriptionAssign(BaseModel):
    model_config = ConfigDict(extra="forbid")
    plan_id: int = Field(gt=0)
    status: str = Field(default="active", pattern=r"^(trial|active|suspended|cancelled|expired)$")
    starts_at: str | None = None
    ends_at: str | None = None
    price_amount: int | None = Field(default=None, ge=0, le=10**12)
    currency: str | None = Field(default=None, pattern=r"^(IRR|TOMAN)$")
    notes: str | None = Field(default=None, max_length=1000)


def is_platform_admin(user: User) -> bool:
    return int(user.telegram_id) in settings.super_admin_id_set or str(getattr(user.role, "value", user.role)) in {"admin", "super_admin"}


def _verification_cipher() -> Fernet:
    key = (settings.host_identity_encryption_key or "").strip()
    if not key:
        raise HTTPException(503, detail={"code": "IDENTITY_ENCRYPTION_NOT_CONFIGURED", "message": "سامانه احراز هویت تا زمان تنظیم کلید رمزنگاری فعال نیست."})
    try:
        return Fernet(key.encode("ascii"))
    except Exception as exc:
        raise HTTPException(503, detail={"code": "IDENTITY_ENCRYPTION_KEY_INVALID"}) from exc


def _national_fingerprint(code: str) -> str:
    # HMAC prevents low-entropy national identifiers from being brute-forced from DB dumps.
    master_key = base64.urlsafe_b64decode(settings.host_identity_encryption_key.encode("ascii"))
    # Domain-separate the deterministic lookup key from the Fernet encryption key.
    # This avoids reusing the same raw key material for two cryptographic purposes.
    fingerprint_key = hmac.new(master_key, b"panel-flow/national-id-fingerprint/v1", hashlib.sha256).digest()
    return hmac.new(fingerprint_key, code.encode("ascii"), hashlib.sha256).hexdigest()


def _mask_national_id(ciphertext: bytes | None) -> str | None:
    if not ciphertext:
        return None
    # Do not decrypt for list/read views. Only last four digits may be exposed after
    # an explicit, separately audited reveal workflow (not currently provided).
    return "••••••••••"


async def require_membership(
    session: AsyncSession, user: User, organization_id: int,
    roles: set[str] | None = None,
) -> OrganizationMembership:
    membership = (await session.execute(select(OrganizationMembership).where(
        OrganizationMembership.organization_id == organization_id,
        OrganizationMembership.user_id == user.id,
        OrganizationMembership.status == "approved",
    ))).scalar_one_or_none()
    if membership is None or (roles and membership.role not in roles):
        raise HTTPException(403, detail={"code": "ORGANIZATION_ACCESS_DENIED"})
    org = await session.get(Organization, organization_id)
    if org is None or org.status != "approved":
        raise HTTPException(403, detail={"code": "ORGANIZATION_NOT_ACTIVE"})
    return membership


async def audit(session: AsyncSession, user: User | None, action: str, org_id: int | None,
                target_type: str, target_id: int | str, reason: str | None = None):
    session.add(PlatformAuditLog(actor_user_id=user.id if user else None, organization_id=org_id,
        action=action, target_type=target_type, target_id=str(target_id), reason=reason, metadata_json={}))


async def _current_host_verification(session: AsyncSession, user_id: int) -> HostVerification | None:
    return (await session.execute(select(HostVerification).where(HostVerification.user_id == user_id)
        .order_by(HostVerification.updated_at.desc(), HostVerification.id.desc()).limit(1))).scalar_one_or_none()


@router.get("/organizations")
async def public_organizations(q: str = Query(default="", max_length=100), session: AsyncSession = Depends(get_session)):
    stmt = select(Organization).where(Organization.status == "approved").order_by(Organization.is_platform_founder.desc(), Organization.name).limit(100)
    rows = (await session.execute(stmt)).scalars().all()
    term = q.strip().casefold()
    visible = [x for x in rows if not term or term in x.name.casefold() or term in (x.description or "").casefold()]
    return {"items": [{"id": x.id, "slug": x.slug, "name": x.name, "description": x.description,
        "logo_url": x.logo_url, "is_platform_founder": bool(x.is_platform_founder)} for x in visible]}


@router.get("/organizations/{slug}")
async def public_organization_detail(slug: str, session: AsyncSession = Depends(get_session)):
    org = (await session.execute(select(Organization).where(Organization.slug == slug, Organization.status == "approved"))).scalar_one_or_none()
    if org is None:
        raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    brands = (await session.execute(select(Brand).where(Brand.organization_id == org.id, Brand.status == "approved").order_by(Brand.name))).scalars().all()
    cities = (await session.execute(select(City).join(OrganizationCity, OrganizationCity.city_id == City.id)
        .where(OrganizationCity.organization_id == org.id, City.is_active.is_(True)).order_by(City.name_en))).scalars().all()
    events = (await session.execute(select(Event).join(City, City.id == Event.city_id).where(
        Event.organization_id == org.id, Event.status == "published", Event.archived.is_(False), City.is_active.is_(True)
    ).order_by(Event.event_date_iso.asc().nullslast(), Event.id.desc()).limit(30))).scalars().all()
    upcoming, past = [], []
    today = tehran_today()
    for event in events:
        card = {"id": event.id, "title": event.title, "city": event.city, "date": event.event_date_label,
            "day": event.event_day_label, "date_iso": event.event_date_iso.isoformat() if event.event_date_iso else None,
            "event_type": event.event_type}
        if event.event_date_iso and event.event_date_iso < today: past.append(card)
        else: upcoming.append(card)
    followers_count = int(await session.scalar(select(func.count(UserOrganizationFollow.id)).where(
        UserOrganizationFollow.organization_id == org.id)) or 0)
    panels_count = int(await session.scalar(select(func.count(Event.id)).where(
        Event.organization_id == org.id, Event.status.in_(("published", "completed")), Event.archived.is_(False))) or 0)
    verification_id = await session.scalar(select(OrganizationVerification.id).where(
        OrganizationVerification.organization_id == org.id, OrganizationVerification.status == "approved").limit(1))
    return {"organization": {"id": org.id, "slug": org.slug, "name": org.name, "description": org.description,
        "logo_url": org.logo_url, "is_platform_founder": bool(org.is_platform_founder),
        "verified": verification_id is not None, "followers_count": followers_count,
        "panels_count": panels_count, "active_city_count": len(cities)},
        "brands": [{"id": b.id, "slug": b.slug, "name": b.name, "description": b.description, "logo_url": b.logo_url} for b in brands],
        "cities": [{"id": c.id, "slug": c.slug, "name_fa": c.name_fa, "name_en": c.name_en} for c in cities],
        "upcoming_events": upcoming, "past_events": past}


@router.get("/organizations/{organization_slug}/brands/{brand_slug}")
async def public_brand_detail(organization_slug: str, brand_slug: str, session: AsyncSession = Depends(get_session)):
    result = (await session.execute(select(Brand, Organization).join(Organization, Organization.id == Brand.organization_id)
        .where(Organization.slug == organization_slug, Organization.status == "approved",
               Brand.slug == brand_slug, Brand.status == "approved"))).one_or_none()
    if result is None:
        raise HTTPException(404, detail={"code": "BRAND_NOT_FOUND"})
    brand, org = result
    cities = (await session.execute(select(City).join(OrganizationCity, OrganizationCity.city_id == City.id)
        .where(OrganizationCity.organization_id == org.id, City.is_active.is_(True)))).scalars().all()
    events = (await session.execute(select(
        Event
    ).where(
        Event.brand_id == brand.id,
        Event.organization_id == org.id,
        Event.status == "published",
        Event.archived.is_(False),
        Event.city_id.in_(select(City.id).where(City.is_active.is_(True))),
    ).order_by(Event.event_date_iso.asc().nullslast()).limit(20))).scalars().all()
    today = tehran_today()
    cards = [{"id": e.id, "title": e.title, "city": e.city, "date": e.event_date_label, "day": e.event_day_label,
        "date_iso": e.event_date_iso.isoformat() if e.event_date_iso else None, "event_type": e.event_type} for e in events]
    return {"brand": {"id": brand.id, "slug": brand.slug, "name": brand.name, "description": brand.description, "logo_url": brand.logo_url},
        "organization": {"id": org.id, "slug": org.slug, "name": org.name, "is_platform_founder": bool(org.is_platform_founder)},
        "cities": [{"slug": c.slug, "name_fa": c.name_fa, "name_en": c.name_en} for c in cities],
        "events": cards, "upcoming_events": [e for e in cards if not e["date_iso"] or e["date_iso"] >= today.isoformat()],
        "past_events": [e for e in cards if e["date_iso"] and e["date_iso"] < today.isoformat()]}


@router.patch("/organizations/{organization_id}/profile")
async def update_organization_profile(organization_id: int, payload: OrganizationProfileUpdate,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    org = await session.get(Organization, organization_id, with_for_update=True)
    if org is None:
        raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    changes = payload.model_dump(exclude_unset=True)
    for key, value in changes.items():
        if key == "name" and (value is None or len(value.strip()) < 2):
            raise HTTPException(422, detail={"code": "ORGANIZATION_NAME_REQUIRED"})
        setattr(org, key, value)
    org.updated_at = utc_now_naive()
    await audit(session, user, "organization.profile.updated", organization_id, "organization", organization_id)
    await session.commit()
    return {"id": org.id, "slug": org.slug, "name": org.name, "description": org.description, "logo_url": org.logo_url}


@router.post("/organizations/{organization_id}/media/logo")
async def upload_organization_logo(organization_id: int, file: UploadFile = File(...),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    org = await session.get(Organization, organization_id, with_for_update=True)
    if org is None:
        raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    from app.services.media_uploads import store_public_image
    try:
        stored = await store_public_image(file, prefix=f"org-{organization_id}-logo")
    except ValueError as exc:
        raise HTTPException(422, detail={"code": str(exc)}) from exc
    org.logo_url = str(stored["url"])
    org.updated_at = utc_now_naive()
    await audit(session, user, "organization.logo.updated", organization_id, "organization", organization_id)
    await session.commit()
    return {"organization_id": organization_id, **stored}


@router.post("/organizations/{organization_id}/brands/{brand_id}/media/logo")
async def upload_brand_logo(organization_id: int, brand_id: int, file: UploadFile = File(...),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    brand = await session.scalar(select(Brand).where(Brand.id == brand_id,
        Brand.organization_id == organization_id).with_for_update())
    if brand is None:
        raise HTTPException(404, detail={"code": "BRAND_NOT_FOUND"})
    from app.services.media_uploads import store_public_image
    try:
        stored = await store_public_image(file, prefix=f"org-{organization_id}-brand-{brand_id}")
    except ValueError as exc:
        raise HTTPException(422, detail={"code": str(exc)}) from exc
    brand.logo_url = str(stored["url"])
    await audit(session, user, "organization.brand_logo.updated", organization_id, "brand", brand_id)
    await session.commit()
    return {"organization_id": organization_id, "brand_id": brand_id, **stored}


@router.get("/media/{filename}", include_in_schema=False)
async def public_media(filename: str, variant: str = Query(default="full", pattern="^(full|thumb)$")):
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,120}\.webp", filename):
        raise HTTPException(404, detail={"code": "MEDIA_NOT_FOUND"})
    root = (Path(settings.upload_dir).resolve() / "public_media").resolve()
    selected_filename = filename[:-5] + "-thumb.webp" if variant == "thumb" else filename
    path = (root / selected_filename).resolve()
    if path.parent != root or path.is_symlink() or not path.is_file():
        # Old media created before variant support remains usable.
        path = (root / filename).resolve()
    if path.parent != root or path.is_symlink() or not path.is_file():
        raise HTTPException(404, detail={"code": "MEDIA_NOT_FOUND"})
    return FileResponse(path, media_type="image/webp", headers={
        "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff"})


@router.post("/organizations", status_code=201)
async def create_organization(payload: OrganizationCreate, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if await session.scalar(select(Organization.id).where(Organization.slug == payload.slug)):
        raise HTTPException(409, detail={"code": "ORGANIZATION_SLUG_TAKEN"})
    if payload.city_ids:
        valid = set((await session.execute(select(City.id).where(City.id.in_(payload.city_ids), City.is_active.is_(True)))).scalars().all())
        if valid != set(payload.city_ids):
            raise HTTPException(422, detail={"code": "CITY_UNAVAILABLE"})
    org = Organization(slug=payload.slug, name=payload.name.strip(), description=payload.description,
        logo_url=payload.logo_url, status="pending", is_platform_founder=False, created_by_user_id=user.id)
    session.add(org); await session.flush()
    membership = OrganizationMembership(organization_id=org.id, user_id=user.id, role="owner", status="pending")
    session.add(membership)
    for city_id in set(payload.city_ids):
        session.add(OrganizationCity(organization_id=org.id, city_id=city_id))
    await audit(session, user, "organization.application.created", org.id, "organization", org.id)
    await session.commit()
    return {"id": org.id, "slug": org.slug, "status": org.status, "membership_status": membership.status}


@router.get("/me/organizations")
async def my_organizations(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(Organization, OrganizationMembership).join(OrganizationMembership,
        OrganizationMembership.organization_id == Organization.id).where(OrganizationMembership.user_id == user.id)
        .order_by(Organization.name))).all()
    return {"items": [{"id": o.id, "slug": o.slug, "name": o.name, "organization_status": o.status,
        "role": m.role, "membership_status": m.status} for o, m in rows]}


@router.post("/organizations/{organization_id}/membership-requests", status_code=201)
async def request_organization_membership(organization_id: int, payload: MembershipRequest,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    org = await session.get(Organization, organization_id)
    if org is None or org.status != "approved":
        raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    existing = (await session.execute(select(OrganizationMembership).where(
        OrganizationMembership.organization_id == organization_id, OrganizationMembership.user_id == user.id))).scalar_one_or_none()
    if existing:
        if existing.status in {"pending", "approved"}:
            raise HTTPException(409, detail={"code": "MEMBERSHIP_ALREADY_EXISTS"})
        existing.role = payload.requested_role; existing.status = "pending"; existing.approved_at = None
    else:
        existing = OrganizationMembership(organization_id=organization_id, user_id=user.id, role=payload.requested_role, status="pending")
        session.add(existing)
    await audit(session, user, "membership.requested", organization_id, "membership", existing.id or 0, payload.message)
    await session.commit()
    return {"status": existing.status, "role": existing.role}


@router.get("/organizations/{organization_id}/brands")
async def organization_brands(organization_id: int, session: AsyncSession = Depends(get_session)):
    org = await session.get(Organization, organization_id)
    if org is None or org.status != "approved":
        raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    rows = (await session.execute(select(Brand).where(Brand.organization_id == organization_id, Brand.status == "approved").order_by(Brand.name))).scalars().all()
    return {"items": [{"id": b.id, "slug": b.slug, "name": b.name, "description": b.description, "logo_url": b.logo_url} for b in rows]}


@router.post("/organizations/{organization_id}/brands", status_code=201)
async def create_brand(organization_id: int, payload: BrandCreate, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    org = await session.get(Organization, organization_id)
    if org is None: raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    await require_membership(session, user, organization_id, {"owner", "admin"})
    sub, plan = await active_organization_subscription(session, organization_id)
    brand_count = int(await session.scalar(select(func.count(Brand.id)).where(Brand.organization_id == organization_id)) or 0)
    if plan and brand_count >= plan.max_brands:
        raise HTTPException(409, detail={"code": "PLAN_BRAND_LIMIT_REACHED", "limit": plan.max_brands})
    brand = Brand(organization_id=organization_id, slug=payload.slug, name=payload.name.strip(),
        description=payload.description, logo_url=payload.logo_url, status="pending")
    session.add(brand)
    try: await session.flush()
    except IntegrityError:
        await session.rollback(); raise HTTPException(409, detail={"code": "BRAND_SLUG_TAKEN"})
    await audit(session, user, "brand.created", organization_id, "brand", brand.id)
    await session.commit()
    return {"id": brand.id, "slug": brand.slug, "status": brand.status}


@router.get("/organizations/{organization_id}/members")
async def organization_members(organization_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    rows = (await session.execute(select(OrganizationMembership, User).join(User, User.id == OrganizationMembership.user_id)
        .where(OrganizationMembership.organization_id == organization_id).order_by(OrganizationMembership.created_at.desc()))).all()
    return {"items": [{"membership_id": m.id, "user_id": u.id, "display_name": u.display_name or u.first_name or "Member",
        "role": m.role, "status": m.status, "created_at": m.created_at} for m, u in rows]}


@router.patch("/organizations/{organization_id}/members/{membership_id}")
async def decide_membership(organization_id: int, membership_id: int, payload: MembershipDecision,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    membership = (await session.execute(select(OrganizationMembership).where(
        OrganizationMembership.id == membership_id, OrganizationMembership.organization_id == organization_id).with_for_update())).scalar_one_or_none()
    if membership is None: raise HTTPException(404, detail={"code": "MEMBERSHIP_NOT_FOUND"})
    if membership.role == "owner": raise HTTPException(409, detail={"code": "OWNER_MEMBERSHIP_REQUIRES_TRANSFER"})
    if payload.status == "approved":
        verification = await _current_host_verification(session, membership.user_id)
        if verification is None or verification.status != "approved":
            raise HTTPException(409, detail={"code": "HOST_VERIFICATION_REQUIRED"})
        if payload.role == "admin":
            await require_membership(session, user, organization_id, {"owner"})
        sub, plan = await active_organization_subscription(session, organization_id)
        member_count = int(await session.scalar(select(func.count(OrganizationMembership.id)).where(
            OrganizationMembership.organization_id == organization_id, OrganizationMembership.status == "approved",
            OrganizationMembership.role.in_(("owner", "admin", "host")))) or 0)
        if plan and member_count >= plan.max_hosts:
            raise HTTPException(409, detail={"code": "PLAN_HOST_LIMIT_REACHED", "limit": plan.max_hosts})
        membership.role = payload.role; membership.status = "approved"; membership.approved_at = utc_now_naive()
    else:
        membership.status = payload.status
    await audit(session, user, f"membership.{payload.status}", organization_id, "membership", membership.id, payload.reason)
    await session.commit()
    return {"membership_id": membership.id, "status": membership.status, "role": membership.role}


@router.get("/organizations/{organization_id}/brands/{brand_id}/hosts")
async def list_brand_hosts(organization_id: int, brand_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    brand = await session.get(Brand, brand_id)
    if brand is None or brand.organization_id != organization_id:
        raise HTTPException(404, detail={"code": "BRAND_NOT_FOUND"})
    rows = (await session.execute(select(OrganizationMembership, User).join(User, User.id == OrganizationMembership.user_id)
        .join(BrandHostAssignment, BrandHostAssignment.membership_id == OrganizationMembership.id)
        .where(BrandHostAssignment.organization_id == organization_id, BrandHostAssignment.brand_id == brand_id)
        .order_by(User.display_name))).all()
    return {"items": [{"membership_id": m.id, "user_id": u.id, "name": u.display_name or u.first_name or "Member"} for m, u in rows]}


@router.put("/organizations/{organization_id}/brands/{brand_id}/hosts")
async def set_brand_hosts(organization_id: int, brand_id: int, payload: BrandHostAssignmentInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    brand = await session.get(Brand, brand_id)
    if brand is None or brand.organization_id != organization_id or brand.status != "approved":
        raise HTTPException(404, detail={"code": "APPROVED_BRAND_NOT_FOUND"})
    await active_organization_subscription(session, organization_id)
    wanted = set(payload.membership_ids)
    members = (await session.execute(select(OrganizationMembership).where(
        OrganizationMembership.id.in_(wanted) if wanted else text("1=0"),
        OrganizationMembership.organization_id == organization_id,
        OrganizationMembership.status == "approved", OrganizationMembership.role == "host"))).scalars().all()
    if len(members) != len(wanted):
        raise HTTPException(422, detail={"code": "INVALID_HOST_MEMBERSHIP"})
    for member in members:
        verification = await _current_host_verification(session, member.user_id)
        if verification is None or verification.status != "approved":
            raise HTTPException(409, detail={"code": "HOST_VERIFICATION_REQUIRED", "membership_id": member.id})
    await session.execute(delete(BrandHostAssignment).where(
        BrandHostAssignment.organization_id == organization_id, BrandHostAssignment.brand_id == brand_id))
    for member in members:
        session.add(BrandHostAssignment(organization_id=organization_id, brand_id=brand_id, membership_id=member.id))
    await audit(session, user, "brand.host_assignments.updated", organization_id, "brand", brand_id,
        f"assigned_memberships={','.join(str(x) for x in sorted(wanted))}")
    await session.commit()
    return {"brand_id": brand_id, "assigned_memberships": sorted(wanted)}


@router.put("/organizations/{organization_id}/cities/{city_id}")
async def set_organization_city(organization_id: int, city_id: int, enabled: bool = Query(...),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    city = await session.get(City, city_id)
    if city is None or not city.is_active:
        raise HTTPException(404, detail={"code": "CITY_NOT_AVAILABLE"})
    row = await session.get(OrganizationCity, (organization_id, city_id))
    if enabled and row is None:
        session.add(OrganizationCity(organization_id=organization_id, city_id=city_id))
    elif not enabled and row is not None:
        await session.delete(row)
    await audit(session, user, "organization.city.updated", organization_id, "city", city_id, str(enabled))
    await session.commit()
    return {"city_id": city_id, "enabled": enabled}


@router.post("/me/host-verification", status_code=202)
async def submit_host_verification(payload: HostVerificationInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    cipher = _verification_cipher()
    city = await session.get(City, payload.residence_city_id) if payload.residence_city_id else None
    if payload.residence_city_id and city is None:
        raise HTTPException(422, detail={"code": "CITY_NOT_FOUND"})
    fingerprint = _national_fingerprint(payload.national_id)
    current = await _current_host_verification(session, user.id)
    duplicate = (await session.execute(select(HostVerification.id).where(
        HostVerification.national_id_fingerprint == fingerprint, HostVerification.user_id != user.id))).scalar_one_or_none()
    if duplicate:
        raise HTTPException(409, detail={"code": "NATIONAL_ID_ALREADY_IN_USE"})
    if current is None:
        current = HostVerification(user_id=user.id)
        session.add(current)
    elif current.status == "approved":
        raise HTTPException(409, detail={"code": "VERIFICATION_ALREADY_APPROVED"})
    current.status = "pending"
    current.legal_name = payload.legal_name
    current.national_id_ciphertext = cipher.encrypt(payload.national_id.encode("ascii"))
    current.national_id_fingerprint = fingerprint
    from datetime import date as date_type
    current.date_of_birth = date_type.fromisoformat(payload.date_of_birth) if payload.date_of_birth else None
    current.verified_mobile = payload.verified_mobile
    current.email = payload.email
    current.residence_city_id = payload.residence_city_id
    current.biography = payload.biography
    current.hosting_experience = payload.hosting_experience
    current.rejection_reason = None; current.requested_information = None
    current.submitted_at = utc_now_naive(); current.updated_at = utc_now_naive()
    await audit(session, user, "host_verification.submitted", None, "host_verification", current.id or 0)
    await session.commit()
    return {"status": "pending", "message": "درخواست احراز هویت برای بررسی ارسال شد."}


@router.get("/me/host-verification")
async def my_host_verification(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    row = await _current_host_verification(session, user.id)
    if row is None: return {"status": "not_submitted"}
    return {"status": row.status, "legal_name": row.legal_name, "national_id_masked": _mask_national_id(row.national_id_ciphertext),
        "rejection_reason": row.rejection_reason, "requested_information": row.requested_information,
        "submitted_at": row.submitted_at, "reviewed_at": row.reviewed_at}


@router.post("/organizations/{organization_id}/verification", status_code=202)
async def submit_organization_verification(organization_id: int, payload: OrganizationVerificationInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner"})
    cipher = _verification_cipher()
    row = (await session.execute(select(OrganizationVerification).where(
        OrganizationVerification.organization_id == organization_id).order_by(OrganizationVerification.created_at.desc(),
        OrganizationVerification.id.desc()).limit(1))).scalar_one_or_none()
    if row is None:
        row = OrganizationVerification(organization_id=organization_id); session.add(row)
    if row.status == "approved":
        raise HTTPException(409, detail={"code": "ORGANIZATION_VERIFICATION_ALREADY_APPROVED"})
    row.status = "pending"; row.official_name = payload.official_name.strip()
    row.registration_number_ciphertext = cipher.encrypt(payload.registration_number.strip().encode()) if payload.registration_number and payload.registration_number.strip() else None
    row.national_legal_id_ciphertext = cipher.encrypt(payload.national_legal_id.strip().encode()) if payload.national_legal_id and payload.national_legal_id.strip() else None
    row.registered_address = payload.registered_address; row.representative_name = payload.representative_name
    row.rejection_reason = None; row.requested_information = None; row.submitted_at = utc_now_naive(); row.updated_at = utc_now_naive()
    await audit(session, user, "organization_verification.submitted", organization_id, "organization_verification", row.id or 0)
    await session.commit()
    return {"status": "pending"}


@router.get("/organizations/{organization_id}/verification")
async def read_organization_verification(organization_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await require_membership(session, user, organization_id, {"owner", "admin"})
    row = (await session.execute(select(OrganizationVerification).where(
        OrganizationVerification.organization_id == organization_id).order_by(OrganizationVerification.created_at.desc(),
        OrganizationVerification.id.desc()).limit(1))).scalar_one_or_none()
    if row is None: return {"status": "not_submitted"}
    return {"status": row.status, "official_name": row.official_name, "registered_address": row.registered_address,
        "representative_name": row.representative_name, "rejection_reason": row.rejection_reason,
        "requested_information": row.requested_information, "submitted_at": row.submitted_at, "reviewed_at": row.reviewed_at}


@router.get("/staff/platform/organization-verifications")
async def platform_organization_verifications(status: str = Query(default="pending", pattern=r"^(pending|approved|rejected|suspended|all)$"),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    stmt = select(OrganizationVerification, Organization).join(Organization, Organization.id == OrganizationVerification.organization_id).order_by(OrganizationVerification.submitted_at.desc().nullslast()).limit(200)
    if status != "all": stmt = stmt.where(OrganizationVerification.status == status)
    rows = (await session.execute(stmt)).all()
    return {"items": [{"id": v.id, "organization_id": o.id, "organization": o.name, "official_name": v.official_name,
        "status": v.status, "submitted_at": v.submitted_at, "rejection_reason": v.rejection_reason,
        "requested_information": v.requested_information} for v, o in rows]}


@router.patch("/staff/platform/organization-verifications/{verification_id}")
async def review_organization_verification(verification_id: int, payload: VerificationDecision,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    row = (await session.execute(select(OrganizationVerification).where(OrganizationVerification.id == verification_id).with_for_update())).scalar_one_or_none()
    if row is None: raise HTTPException(404, detail={"code": "VERIFICATION_NOT_FOUND"})
    if payload.status in {"rejected", "suspended"} and not (payload.reason or "").strip():
        raise HTTPException(422, detail={"code": "REASON_REQUIRED"})
    row.status = payload.status; row.rejection_reason = payload.reason; row.requested_information = payload.requested_information
    row.reviewed_at = utc_now_naive(); row.reviewed_by_user_id = user.id; row.updated_at = utc_now_naive()
    await audit(session, user, f"organization_verification.{payload.status}", row.organization_id,
        "organization_verification", row.id, payload.reason or payload.requested_information)
    await session.commit()
    return {"id": row.id, "status": row.status}


@router.get("/staff/platform/host-verifications")
async def platform_host_verifications(status: str = Query(default="pending", pattern=r"^(pending|approved|rejected|suspended|all)$"),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    stmt = select(HostVerification, User).join(User, User.id == HostVerification.user_id).order_by(HostVerification.submitted_at.desc().nullslast()).limit(200)
    if status != "all": stmt = stmt.where(HostVerification.status == status)
    rows = (await session.execute(stmt)).all()
    return {"items": [{"id": v.id, "user_id": u.id, "name": v.legal_name, "display_name": u.display_name or u.first_name,
        "national_id_masked": _mask_national_id(v.national_id_ciphertext), "status": v.status,
        "submitted_at": v.submitted_at, "rejection_reason": v.rejection_reason, "requested_information": v.requested_information} for v, u in rows]}


@router.patch("/staff/platform/host-verifications/{verification_id}")
async def review_host_verification(verification_id: int, payload: VerificationDecision, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    row = (await session.execute(select(HostVerification).where(HostVerification.id == verification_id).with_for_update())).scalar_one_or_none()
    if row is None: raise HTTPException(404, detail={"code": "VERIFICATION_NOT_FOUND"})
    if payload.status in {"rejected", "suspended"} and not (payload.reason or "").strip():
        raise HTTPException(422, detail={"code": "REASON_REQUIRED"})
    row.status = payload.status; row.rejection_reason = payload.reason; row.requested_information = payload.requested_information
    row.reviewed_at = utc_now_naive(); row.reviewed_by_user_id = user.id; row.updated_at = utc_now_naive()
    await audit(session, user, f"host_verification.{payload.status}", None, "host_verification", row.id, payload.reason)
    await session.commit()
    return {"id": row.id, "status": row.status}


@router.get("/staff/platform/organizations")
async def platform_organizations(status: str = Query(default="pending", pattern="^(pending|approved|rejected|suspended|all)$"),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    stmt = select(Organization).order_by(Organization.created_at.desc()).limit(200)
    if status != "all": stmt = stmt.where(Organization.status == status)
    rows = (await session.execute(stmt)).scalars().all()
    return {"items": [{"id": o.id, "slug": o.slug, "name": o.name, "status": o.status,
        "is_platform_founder": o.is_platform_founder, "created_at": o.created_at} for o in rows]}


@router.patch("/staff/platform/organizations/{organization_id}")
async def moderate_organization(organization_id: int, payload: Decision, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    org = (await session.execute(select(Organization).where(Organization.id == organization_id).with_for_update())).scalar_one_or_none()
    if org is None: raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    if org.is_platform_founder and payload.status != "approved": raise HTTPException(409, detail={"code": "FOUNDING_ORGANIZATION_PROTECTED"})
    if payload.status == "approved":
        owners = (await session.execute(select(OrganizationMembership).where(OrganizationMembership.organization_id == org.id,
            OrganizationMembership.role == "owner", OrganizationMembership.status.in_(("pending", "approved")) ))).scalars().all()
        if not owners: raise HTTPException(409, detail={"code": "ORGANIZATION_OWNER_REQUIRED"})
        for owner in owners:
            verification = await _current_host_verification(session, owner.user_id)
            if verification is None or verification.status != "approved":
                raise HTTPException(409, detail={"code": "OWNER_IDENTITY_VERIFICATION_REQUIRED", "user_id": owner.user_id})
        for owner in owners:
            owner.status = "approved"; owner.approved_at = utc_now_naive()
    org.status = payload.status; org.updated_at = utc_now_naive()
    await audit(session, user, f"organization.{payload.status}", org.id, "organization", org.id, payload.reason)
    await session.commit()
    return {"id": org.id, "status": org.status}


@router.get("/staff/platform/brands")
async def platform_brands(status: str = Query(default="pending", pattern=r"^(pending|approved|rejected|suspended|all)$"),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    stmt = select(Brand, Organization).join(Organization, Organization.id == Brand.organization_id).order_by(Brand.created_at.desc()).limit(300)
    if status != "all": stmt = stmt.where(Brand.status == status)
    rows = (await session.execute(stmt)).all()
    return {"items": [{"id": b.id, "organization_id": o.id, "organization": o.name, "slug": b.slug, "name": b.name, "status": b.status} for b, o in rows]}


@router.patch("/staff/platform/brands/{brand_id}")
async def moderate_brand(brand_id: int, payload: Decision, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    brand = (await session.execute(select(Brand).where(Brand.id == brand_id).with_for_update())).scalar_one_or_none()
    if brand is None: raise HTTPException(404, detail={"code": "BRAND_NOT_FOUND"})
    org = await session.get(Organization, brand.organization_id)
    if org is None or (org.is_platform_founder and payload.status != "approved"):
        raise HTTPException(409, detail={"code": "FOUNDING_BRAND_PROTECTED"})
    if payload.status == "approved" and org.status != "approved":
        raise HTTPException(409, detail={"code": "ORGANIZATION_NOT_APPROVED"})
    brand.status = payload.status
    await audit(session, user, f"brand.{payload.status}", brand.organization_id, "brand", brand.id, payload.reason)
    await session.commit()
    return {"id": brand.id, "status": brand.status}


@router.get("/staff/platform/subscription-plans")
async def platform_subscription_plans(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    rows = (await session.execute(select(SubscriptionPlan).order_by(SubscriptionPlan.price_amount))).scalars().all()
    return {"items": [{"id": p.id, "code": p.code, "name": p.name, "price_amount": p.price_amount, "currency": p.currency,
        "duration_days": p.duration_days, "max_brands": p.max_brands, "max_hosts": p.max_hosts, "features": p.features, "is_active": p.is_active} for p in rows]}


@router.post("/staff/platform/subscription-plans", status_code=201)
async def create_subscription_plan(payload: PlanCreate, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    plan = SubscriptionPlan(**payload.model_dump())
    session.add(plan)
    try: await session.flush()
    except IntegrityError:
        await session.rollback(); raise HTTPException(409, detail={"code": "PLAN_CODE_TAKEN"})
    await audit(session, user, "subscription_plan.created", None, "subscription_plan", plan.id)
    await session.commit()
    return {"id": plan.id, "code": plan.code}


@router.post("/staff/platform/organizations/{organization_id}/subscription")
async def assign_organization_subscription(organization_id: int, payload: SubscriptionAssign,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not is_platform_admin(user): raise HTTPException(403, detail={"code": "PLATFORM_ADMIN_REQUIRED"})
    org = await session.get(Organization, organization_id)
    plan = await session.get(SubscriptionPlan, payload.plan_id)
    if org is None: raise HTTPException(404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    if plan is None or not plan.is_active: raise HTTPException(404, detail={"code": "SUBSCRIPTION_PLAN_NOT_FOUND"})
    from datetime import datetime
    starts = datetime.fromisoformat(payload.starts_at) if payload.starts_at else utc_now_naive()
    ends = datetime.fromisoformat(payload.ends_at) if payload.ends_at else starts + timedelta(days=plan.duration_days)
    if ends <= starts: raise HTTPException(422, detail={"code": "INVALID_SUBSCRIPTION_RANGE"})
    await session.execute(
        # Keep old subscription records as history; latest row is authoritative.
        select(OrganizationSubscription.id).where(OrganizationSubscription.organization_id == organization_id).with_for_update()
    )
    sub = OrganizationSubscription(organization_id=organization_id, plan_id=plan.id, status=payload.status,
        starts_at=starts, ends_at=ends, price_amount=payload.price_amount if payload.price_amount is not None else plan.price_amount,
        currency=payload.currency or plan.currency, notes=payload.notes, created_by_user_id=user.id)
    session.add(sub); await session.flush()
    await audit(session, user, "organization.subscription.assigned", organization_id, "subscription", sub.id)
    await session.commit()
    return {"id": sub.id, "status": sub.status, "starts_at": sub.starts_at, "ends_at": sub.ends_at, "plan": plan.code}


def subscription_workspace_view(sub: OrganizationSubscription | None, plan: SubscriptionPlan | None, role: str) -> dict | None:
    """Return tenant subscription status while limiting pricing to finance roles."""
    if sub is None:
        return None
    view = {
        "status": sub.status,
        "starts_at": sub.starts_at,
        "ends_at": sub.ends_at,
        "plan": plan.code if plan else None,
        "max_brands": plan.max_brands if plan else None,
        "max_hosts": plan.max_hosts if plan else None,
    }
    if role in {"owner", "admin", "finance"}:
        view.update({"price_amount": sub.price_amount, "currency": sub.currency})
    return view


@router.get("/organizations/{organization_id}/workspace")
async def organization_workspace(organization_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    membership = await require_membership(session, user, organization_id)
    org = await session.get(Organization, organization_id)
    brands = (await session.execute(select(Brand).where(Brand.organization_id == organization_id).order_by(Brand.name))).scalars().all()
    members_count = int(await session.scalar(select(func.count(OrganizationMembership.id)).where(
        OrganizationMembership.organization_id == organization_id, OrganizationMembership.status == "approved")) or 0)
    pending_count = int(await session.scalar(select(func.count(OrganizationMembership.id)).where(
        OrganizationMembership.organization_id == organization_id, OrganizationMembership.status == "pending")) or 0)
    sub = (await session.execute(select(OrganizationSubscription).where(OrganizationSubscription.organization_id == organization_id)
        .order_by(OrganizationSubscription.created_at.desc(), OrganizationSubscription.id.desc()).limit(1))).scalar_one_or_none()
    plan = await session.get(SubscriptionPlan, sub.plan_id) if sub and sub.plan_id else None
    city_rows = (await session.execute(select(City).join(OrganizationCity, OrganizationCity.city_id == City.id)
        .where(OrganizationCity.organization_id == organization_id))).scalars().all()
    subscription_view = subscription_workspace_view(sub, plan, membership.role)
    return {"organization": {"id": org.id, "slug": org.slug, "name": org.name, "description": org.description,
        "status": org.status, "role": membership.role},
        "brands": [{"id": b.id, "slug": b.slug, "name": b.name, "status": b.status} for b in brands],
        "cities": [{"id": c.id, "slug": c.slug, "name_fa": c.name_fa, "name_en": c.name_en} for c in city_rows],
        "metrics": {"approved_members": members_count, "pending_members": pending_count, "brands": len(brands)},
        "subscription": subscription_view}
