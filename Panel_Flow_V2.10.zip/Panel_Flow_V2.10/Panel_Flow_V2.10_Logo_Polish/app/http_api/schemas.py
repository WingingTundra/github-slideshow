from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class TelegramLoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    init_data: str = Field(min_length=1, max_length=16_384)


class PublicOrganizationAttribution(BaseModel):
    id: int
    slug: str
    name: str
    is_platform_founder: bool = False


class PublicBrandAttribution(BaseModel):
    id: int
    slug: str
    name: str


class PublicEventRead(BaseModel):
    id: int
    volume: str
    title: str
    language: str | None = None
    description: str | None = None
    day: str
    date: str
    start_time: str
    end_time: str | None = None
    venue: str
    address: str | None = None
    map_url: str | None = None
    city: str
    city_id: int | None = None
    date_iso: str | None = None
    capacity: int
    price_per_person: int
    price_without_cafe_order: int | None = None
    status: str
    registration_open: bool
    event_type: str = "physical"
    meeting_platform: str | None = None
    is_postponed: bool = False
    postponement_note: str | None = None
    cover_image_url: str | None = None
    cover_image_thumb_url: str | None = None
    waitlist_enabled: bool = False
    host_name: str | None = None
    organization_id: int | None = None
    brand_id: int | None = None
    topic_tags: list[str] = Field(default_factory=list)
    agenda_items: list[str] = Field(default_factory=list)
    discussion_questions: list[str] = Field(default_factory=list)
    organization: PublicOrganizationAttribution | None = None
    brand: PublicBrandAttribution | None = None


class PublicEventPage(BaseModel):
    items: list[PublicEventRead]
    total: int
    limit: int
    offset: int
    next_cursor: str | None = None


class ApiUserRead(BaseModel):
    id: int
    display_name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    telegram_username: str | None = None
    phone_number: str | None = None
    role: str
    created_at: datetime | None = None


class TelegramLoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: ApiUserRead


class MyBookingRead(BaseModel):
    id: int
    event_id: int
    event_title: str
    event_day: str
    event_date: str
    event_start_time: str
    event_end_time: str | None = None
    event_date_iso: date | None = None
    event_type: str = "physical"
    event_venue: str
    event_city: str
    participant_count: int
    total_amount: int
    status: str
    created_at: datetime | None = None
    confirmed_at: datetime | None = None
    cancelled_at: datetime | None = None
    cancellation_resolution: str | None = None


class MyBookingPage(BaseModel):
    items: list[MyBookingRead]
    total: int
    limit: int
    offset: int


class ErrorResponse(BaseModel):
    detail: str
    code: str | None = None
    extra: dict[str, Any] | None = None
