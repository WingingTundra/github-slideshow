from __future__ import annotations

import base64
import hashlib
import hmac
import re
from datetime import date, datetime, timedelta
from urllib.parse import urlsplit

from cryptography.fernet import Fernet
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.db.models import (
    Brand, BrandHostAssignment, City, HostApplication, HostApplicationHistory,
    HostApplicationNotification, HostPublicProfile, HostSubscription, HostVerification,
    Organization, OrganizationCity, OrganizationMembership, OrganizationSubscription,
    PlatformAuditLog, SubscriptionPlan, User, UserRole,
)
from app.db.session import get_session
from app.http_api.dependencies import get_current_api_user
from app.time_utils import tehran_today, utc_now_naive

router = APIRouter(prefix="/api/v1", tags=["Host applications"])

APPLICATION_STATUSES = {
    "draft", "submitted", "under_review", "more_information_required",
    "approved", "rejected", "withdrawn",
}


def _is_superadmin(user: User) -> bool:
    role = getattr(user.role, "value", user.role)
    return int(user.telegram_id) in settings.super_admin_only_id_set or str(role) == "super_admin"


def _can_apply_as_member(user: User) -> bool:
    role = str(getattr(user.role, "value", user.role))
    return role == "participant" and int(user.telegram_id) not in settings.super_admin_id_set


def _identity_cipher() -> Fernet:
    key = (settings.host_identity_encryption_key or "").strip()
    if not key:
        raise HTTPException(503, detail={"code": "IDENTITY_ENCRYPTION_NOT_CONFIGURED", "message": "Host identity encryption is not configured."})
    try:
        return Fernet(key.encode("ascii"))
    except Exception as exc:
        raise HTTPException(503, detail={"code": "IDENTITY_ENCRYPTION_KEY_INVALID"}) from exc


def _national_fingerprint(code: str) -> str:
    key = base64.urlsafe_b64decode(settings.host_identity_encryption_key.encode("ascii"))
    derived = hmac.new(key, b"panel-flow/national-id-fingerprint/v1", hashlib.sha256).digest()
    return hmac.new(derived, code.encode("ascii"), hashlib.sha256).hexdigest()


def _normalize_national_id(value: str) -> str:
    code = value.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")).strip()
    if not re.fullmatch(r"\d{10}", code) or len(set(code)) == 1:
        raise ValueError("A valid 10-digit national identity number is required.")
    total = sum(int(code[i]) * (10 - i) for i in range(9))
    remainder = total % 11
    if (remainder if remainder < 2 else 11 - remainder) != int(code[9]):
        raise ValueError("A valid national identity number is required.")
    return code


def _masked_identity(ciphertext: bytes | None) -> str | None:
    return "••••••••••" if ciphertext else None


def _application_payload(row: HostApplication, *, admin: bool = False) -> dict:
    result = {
        "id": row.id, "status": row.status, "legal_name": row.legal_name,
        "national_id_masked": _masked_identity(row.national_id_ciphertext),
        "date_of_birth": row.date_of_birth.isoformat() if row.date_of_birth else None,
        "verified_mobile": row.verified_mobile, "email": row.email,
        "residence_city_id": row.residence_city_id,
        "english_proficiency": row.english_proficiency, "english_certification": row.english_certification,
        "relevant_experience": row.relevant_experience, "hosting_background": row.hosting_background,
        "motivation": row.motivation, "portfolio_url": row.portfolio_url,
        "preferred_city_ids": row.preferred_city_ids or [], "preferred_topics": row.preferred_topics or [],
        "preferred_formats": row.preferred_formats or [], "availability": row.availability,
        "public_display_name": row.public_display_name, "public_bio": row.public_bio,
        "public_languages": row.public_languages or [], "applicant_response": row.applicant_response,
        "requested_information": row.requested_information, "rejection_reason": row.rejection_reason,
        "interview_at": row.interview_at, "interview_location": row.interview_location,
        "submitted_at": row.submitted_at,
        "reviewed_at": row.reviewed_at, "created_at": row.created_at, "updated_at": row.updated_at,
    }
    if admin:
        result.update({"user_id": row.user_id, "internal_notes": row.internal_notes,
                       "interview_notes": row.interview_notes,
                       "reviewed_by_user_id": row.reviewed_by_user_id})
    return result


def _history_payload(row: HostApplicationHistory, *, applicant: bool) -> dict | None:
    if applicant and row.action in {"internal_note", "admin_comment"}:
        return None
    return {"id": row.id, "action": row.action, "from_status": row.from_status,
            "to_status": row.to_status, "note": row.note, "created_at": row.created_at}


async def _record_history(session: AsyncSession, app: HostApplication, actor: User | None,
                          action: str, from_status: str | None, to_status: str | None,
                          note: str | None = None, metadata: dict | None = None) -> None:
    session.add(HostApplicationHistory(
        application_id=app.id, actor_user_id=actor.id if actor else None, action=action,
        from_status=from_status, to_status=to_status, note=note, metadata_json=metadata or {},
    ))


async def _notify_applicant(session: AsyncSession, app: HostApplication, title: str, message: str) -> None:
    session.add(HostApplicationNotification(
        application_id=app.id, user_id=app.user_id, title=title, message=message,
    ))


async def _get_or_create_application(session: AsyncSession, user: User) -> HostApplication:
    row = (await session.execute(select(HostApplication).where(HostApplication.user_id == user.id).with_for_update())).scalar_one_or_none()
    if row:
        return row
    row = HostApplication(user_id=user.id, status="draft")
    session.add(row)
    await session.flush()
    await _record_history(session, row, user, "draft_created", None, "draft")
    return row


class HostApplicationDraftInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    legal_name: str | None = Field(default=None, max_length=255)
    national_id: str | None = Field(default=None, max_length=32)
    date_of_birth: str | None = Field(default=None, pattern=r"^\d{4}-\d{2}-\d{2}$")
    verified_mobile: str | None = Field(default=None, max_length=50)
    email: str | None = Field(default=None, max_length=255)
    residence_city_id: int | None = Field(default=None, gt=0)
    english_proficiency: str | None = Field(default=None, max_length=60)
    english_certification: str | None = Field(default=None, max_length=255)
    relevant_experience: str | None = Field(default=None, max_length=5000)
    hosting_background: str | None = Field(default=None, max_length=5000)
    motivation: str | None = Field(default=None, max_length=5000)
    portfolio_url: str | None = Field(default=None, max_length=1000)
    preferred_city_ids: list[int] = Field(default_factory=list, max_length=30)
    preferred_topics: list[str] = Field(default_factory=list, max_length=30)
    preferred_formats: list[str] = Field(default_factory=list, max_length=5)
    availability: str | None = Field(default=None, max_length=3000)
    public_display_name: str | None = Field(default=None, max_length=255)
    public_bio: str | None = Field(default=None, max_length=3000)
    public_languages: list[str] = Field(default_factory=list, max_length=20)
    applicant_response: str | None = Field(default=None, max_length=3000)

    @field_validator("portfolio_url")
    @classmethod
    def validate_portfolio_url(cls, value: str | None) -> str | None:
        if not value or not value.strip():
            return None
        parsed = urlsplit(value.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Portfolio URL must use http or https.")
        return value.strip()

    @field_validator("preferred_formats")
    @classmethod
    def validate_formats(cls, values: list[str]) -> list[str]:
        allowed = {"in_person", "online", "hybrid"}
        normalized = list(dict.fromkeys(str(x).strip().lower() for x in values))
        if any(x not in allowed for x in normalized):
            raise ValueError("Unsupported hosting format.")
        return normalized

    @field_validator("date_of_birth")
    @classmethod
    def validate_birth_date(cls, value: str | None) -> str | None:
        if value:
            parsed = date.fromisoformat(value)
            if parsed > tehran_today():
                raise ValueError("Date of birth cannot be in the future.")
        return value

    @field_validator("email")
    @classmethod
    def validate_email_address(cls, value: str | None) -> str | None:
        if value and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value.strip()):
            raise ValueError("A valid email address is required.")
        return value.strip() if value else value

    @field_validator("national_id")
    @classmethod
    def validate_national_id(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        return _normalize_national_id(value)

    @field_validator("legal_name", "verified_mobile", "email", "english_proficiency", "public_display_name")
    @classmethod
    def strip_optional_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        return normalized or None


class HostApplicationReviewInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: str = Field(pattern=r"^(start_review|request_information|approve|reject|add_note|schedule_interview|suspend_host|revoke_host)$")
    note: str | None = Field(default=None, max_length=3000)
    interview_at: datetime | None = None
    interview_location: str | None = Field(default=None, max_length=500)
    interview_notes: str | None = Field(default=None, max_length=3000)


class ApplicationResponseInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    response: str = Field(min_length=5, max_length=3000)

    @field_validator("response")
    @classmethod
    def response_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Response cannot be blank.")
        return value.strip()


@router.get("/me/host-application")
async def get_my_host_application(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    row = (await session.execute(select(HostApplication).where(HostApplication.user_id == user.id))).scalar_one_or_none()
    if row is None:
        return {"application": None, "history": [], "notifications": []}
    history = (await session.execute(select(HostApplicationHistory).where(
        HostApplicationHistory.application_id == row.id).order_by(HostApplicationHistory.created_at.asc()))).scalars().all()
    notifications = (await session.execute(select(HostApplicationNotification).where(
        HostApplicationNotification.user_id == user.id,
        HostApplicationNotification.application_id == row.id).order_by(HostApplicationNotification.created_at.desc()).limit(50))).scalars().all()
    return {"application": _application_payload(row),
            "history": [item for item in (_history_payload(x, applicant=True) for x in history) if item],
            "notifications": [{"id": x.id, "title": x.title, "message": x.message, "read_at": x.read_at,
                               "created_at": x.created_at} for x in notifications]}


@router.patch("/me/host-application")
async def save_my_host_application_draft(payload: HostApplicationDraftInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not _can_apply_as_member(user):
        raise HTTPException(403, detail={"code": "REGULAR_MEMBER_ACCOUNT_REQUIRED"})
    app = await _get_or_create_application(session, user)
    if app.status not in {"draft", "more_information_required"}:
        raise HTTPException(409, detail={"code": "APPLICATION_NOT_EDITABLE", "status": app.status})
    values = payload.model_dump(exclude_unset=True)
    if "national_id" in values:
        national_id = values.pop("national_id")
        if national_id:
            fingerprint = _national_fingerprint(national_id)
            existing_app = (await session.execute(select(HostApplication.id).where(
                HostApplication.national_id_fingerprint == fingerprint,
                HostApplication.user_id != user.id))).scalar_one_or_none()
            existing_verification = (await session.execute(select(HostVerification.id).where(
                HostVerification.national_id_fingerprint == fingerprint,
                HostVerification.user_id != user.id))).scalar_one_or_none()
            if existing_app or existing_verification:
                raise HTTPException(409, detail={"code": "NATIONAL_ID_ALREADY_IN_USE"})
            app.national_id_ciphertext = _identity_cipher().encrypt(national_id.encode("ascii"))
            app.national_id_fingerprint = fingerprint
    if "date_of_birth" in values:
        raw = values.pop("date_of_birth")
        app.date_of_birth = date.fromisoformat(raw) if raw else None
    city_ids = values.get("preferred_city_ids", app.preferred_city_ids or [])
    city_id = values.get("residence_city_id", app.residence_city_id)
    normalized_city_ids = list(dict.fromkeys(int(x) for x in city_ids))
    validate_ids = set(normalized_city_ids + ([int(city_id)] if city_id else []))
    if validate_ids:
        found = set((await session.execute(select(City.id).where(City.id.in_(validate_ids), City.is_active.is_(True)))).scalars().all())
        if found != validate_ids:
            raise HTTPException(422, detail={"code": "CITY_NOT_AVAILABLE"})
    values["preferred_city_ids"] = normalized_city_ids
    for field, value in values.items():
        if field == "national_id":
            continue
        if field in {"preferred_topics", "public_languages"}:
            values[field] = list(dict.fromkeys(str(x).strip() for x in value if str(x).strip()))
        setattr(app, field, value)
    # If the applicant is responding to a request, retain the request for reference.
    app.updated_at = utc_now_naive()
    await _record_history(session, app, user, "draft_saved", app.status, app.status)
    await session.commit()
    return {"application": _application_payload(app), "saved": True}


@router.post("/me/host-application/submit", status_code=202)
async def submit_my_host_application(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not _can_apply_as_member(user):
        raise HTTPException(403, detail={"code": "REGULAR_MEMBER_ACCOUNT_REQUIRED"})
    app = (await session.execute(select(HostApplication).where(HostApplication.user_id == user.id).with_for_update())).scalar_one_or_none()
    if app is None:
        raise HTTPException(409, detail={"code": "APPLICATION_DRAFT_REQUIRED"})
    if app.status not in {"draft", "more_information_required"}:
        raise HTTPException(409, detail={"code": "APPLICATION_NOT_SUBMITTABLE", "status": app.status})
    missing = []
    required = {
        "legal_name": app.legal_name, "national_identity": app.national_id_ciphertext,
        "date_of_birth": app.date_of_birth, "mobile": app.verified_mobile, "email": app.email,
        "residence_city": app.residence_city_id, "english_proficiency": app.english_proficiency,
        "hosting_background": app.hosting_background, "motivation": app.motivation,
        "preferred_city": app.preferred_city_ids, "preferred_format": app.preferred_formats,
        "public_display_name": app.public_display_name, "public_bio": app.public_bio,
    }
    missing = [name for name, value in required.items() if not value]
    if missing:
        raise HTTPException(422, detail={"code": "APPLICATION_FIELDS_REQUIRED", "fields": missing})
    previous = app.status
    applicant_response = app.applicant_response if previous == "more_information_required" else None
    app.status = "submitted"
    app.submitted_at = utc_now_naive()
    app.reviewed_at = None; app.reviewed_by_user_id = None
    app.rejection_reason = None; app.requested_information = None
    # Preserve the applicant's response when resubmitting after an information request.
    app.applicant_response = applicant_response
    app.updated_at = utc_now_naive()
    if applicant_response:
        await _record_history(session, app, user, "information_provided", previous, "submitted", applicant_response)
    await _record_history(session, app, user, "submitted", previous, "submitted")
    await _notify_applicant(session, app, "Host application submitted", "Your host application has been submitted and is awaiting review.")
    session.add(PlatformAuditLog(actor_user_id=user.id, action="host_application.submitted",
        target_type="host_application", target_id=str(app.id), metadata_json={"user_id": user.id}))
    await session.commit()
    return {"id": app.id, "status": app.status, "submitted_at": app.submitted_at}


@router.post("/me/host-application/withdraw")
async def withdraw_my_host_application(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    app = (await session.execute(select(HostApplication).where(HostApplication.user_id == user.id).with_for_update())).scalar_one_or_none()
    if app is None or app.status not in {"draft", "submitted", "under_review", "more_information_required"}:
        raise HTTPException(409, detail={"code": "APPLICATION_CANNOT_BE_WITHDRAWN"})
    previous = app.status
    app.status = "withdrawn"; app.withdrawn_at = utc_now_naive(); app.updated_at = utc_now_naive()
    await _record_history(session, app, user, "withdrawn", previous, "withdrawn")
    session.add(PlatformAuditLog(actor_user_id=user.id, action="host_application.withdrawn",
        target_type="host_application", target_id=str(app.id), metadata_json={"user_id": user.id}))
    await session.commit()
    return {"id": app.id, "status": app.status}


@router.post("/me/host-application/reapply")
async def reapply_for_host(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not _can_apply_as_member(user):
        raise HTTPException(403, detail={"code": "REGULAR_MEMBER_ACCOUNT_REQUIRED"})
    app = (await session.execute(select(HostApplication).where(
        HostApplication.user_id == user.id).with_for_update())).scalar_one_or_none()
    if app is None or app.status not in {"rejected", "withdrawn"}:
        raise HTTPException(409, detail={"code": "APPLICATION_CANNOT_BE_REOPENED"})
    previous = app.status
    app.status = "draft"
    app.submitted_at = None
    app.reviewed_at = None
    app.reviewed_by_user_id = None
    app.withdrawn_at = None
    app.rejection_reason = None
    app.requested_information = None
    app.applicant_response = None
    app.updated_at = utc_now_naive()
    await _record_history(session, app, user, "reapplication_started", previous, "draft")
    session.add(PlatformAuditLog(actor_user_id=user.id, action="host_application.reapplication_started",
        target_type="host_application", target_id=str(app.id), metadata_json={"user_id": user.id}))
    await session.commit()
    return {"id": app.id, "status": app.status}


@router.post("/me/host-application/respond")
async def respond_to_host_application_request(payload: ApplicationResponseInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    app = (await session.execute(select(HostApplication).where(HostApplication.user_id == user.id).with_for_update())).scalar_one_or_none()
    if app is None or app.status != "more_information_required":
        raise HTTPException(409, detail={"code": "INFORMATION_RESPONSE_NOT_REQUESTED"})
    app.applicant_response = payload.response
    app.updated_at = utc_now_naive()
    await _record_history(session, app, user, "information_provided", app.status, app.status, payload.response)
    await _notify_applicant(session, app, "Additional information received", "Your response has been attached to the application.")
    await session.commit()
    return {"status": app.status, "response_saved": True}


@router.post("/me/host-application/notifications/{notification_id}/read")
async def mark_host_application_notification_read(notification_id: int,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    notification = (await session.execute(select(HostApplicationNotification).where(
        HostApplicationNotification.id == notification_id,
        HostApplicationNotification.user_id == user.id))).scalar_one_or_none()
    if notification is None:
        raise HTTPException(404, detail={"code": "NOTIFICATION_NOT_FOUND"})
    notification.read_at = utc_now_naive()
    await session.commit()
    return {"id": notification.id, "read": True}


@router.get("/staff/platform/host-applications")
async def list_host_applications(
    status: str = Query(default="all", pattern=r"^(all|draft|submitted|under_review|more_information_required|approved|rejected|withdrawn)$"),
    q: str = Query(default="", max_length=100), city_id: int | None = Query(default=None, gt=0),
    submitted_from: date | None = None, submitted_to: date | None = None,
    limit: int = Query(default=50, ge=1, le=200), offset: int = Query(default=0, ge=0, le=100000),
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not _is_superadmin(user):
        raise HTTPException(403, detail={"code": "SUPERADMIN_REQUIRED"})
    filters = []
    if status != "all": filters.append(HostApplication.status == status)
    if city_id: filters.append(HostApplication.residence_city_id == city_id)
    if submitted_from: filters.append(HostApplication.submitted_at >= datetime.combine(submitted_from, datetime.min.time()))
    if submitted_to: filters.append(HostApplication.submitted_at < datetime.combine(submitted_to + timedelta(days=1), datetime.min.time()))
    term = q.strip()
    stmt = select(HostApplication, User).join(User, User.id == HostApplication.user_id).where(*filters)
    if term:
        stmt = stmt.where(or_(HostApplication.legal_name.ilike(f"%{term}%"),
                              HostApplication.public_display_name.ilike(f"%{term}%"),
                              HostApplication.email.ilike(f"%{term}%"),
                              User.telegram_username.ilike(f"%{term}%")))
    total = int(await session.scalar(select(func.count()).select_from(stmt.subquery())) or 0)
    rows = (await session.execute(stmt.order_by(HostApplication.submitted_at.desc().nullslast(), HostApplication.updated_at.desc())
                                  .offset(offset).limit(limit))).all()
    items = []
    for app, member in rows:
        items.append({"id": app.id, "user_id": member.id,
                      "member_name": member.display_name or member.first_name or member.telegram_username or f"Member {member.id}",
                      "legal_name": app.legal_name, "email": app.email, "residence_city_id": app.residence_city_id,
                      "status": app.status, "national_id_masked": _masked_identity(app.national_id_ciphertext),
                      "submitted_at": app.submitted_at, "updated_at": app.updated_at})
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/staff/platform/host-applications/{application_id}")
async def get_host_application_details(application_id: int, user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session)):
    if not _is_superadmin(user):
        raise HTTPException(403, detail={"code": "SUPERADMIN_REQUIRED"})
    app = await session.get(HostApplication, application_id)
    if app is None:
        raise HTTPException(404, detail={"code": "APPLICATION_NOT_FOUND"})
    history = (await session.execute(select(HostApplicationHistory).where(
        HostApplicationHistory.application_id == app.id).order_by(HostApplicationHistory.created_at.asc()))).scalars().all()
    member = await session.get(User, app.user_id)
    city = await session.get(City, app.residence_city_id) if app.residence_city_id else None
    return {"application": _application_payload(app, admin=True),
            "member": {"id": member.id, "display_name": member.display_name, "telegram_username": member.telegram_username,
                       "role": getattr(member.role, "value", member.role)},
            "residence_city": city.name_en if city else None,
            "history": [_history_payload(x, applicant=False) for x in history]}


async def _ensure_host_workspace(session: AsyncSession, application: HostApplication, actor: User) -> dict:
    member = await session.get(User, application.user_id, with_for_update=True)
    if member is None:
        raise HTTPException(409, detail={"code": "APPLICATION_MEMBER_UNAVAILABLE"})
    # Keep explicit platform roles; promote a regular member only after the
    # superadmin approval action has been committed in this transaction.
    current_role = str(getattr(member.role, "value", member.role))
    telegram_id = int(member.telegram_id)
    if telegram_id in settings.super_admin_only_id_set or current_role == "super_admin":
        member.role = UserRole.SUPER_ADMIN
    elif telegram_id in settings.admin_id_set or current_role == "admin":
        member.role = UserRole.ADMIN
    else:
        member.role = UserRole.HOST

    verification = (await session.execute(select(HostVerification).where(
        HostVerification.user_id == member.id).order_by(HostVerification.updated_at.desc(), HostVerification.id.desc()).limit(1).with_for_update())).scalar_one_or_none()
    if verification is None:
        verification = HostVerification(user_id=member.id)
        session.add(verification)
        await session.flush()
    if application.national_id_fingerprint:
        conflicting = (await session.execute(select(HostVerification.id).where(
            HostVerification.national_id_fingerprint == application.national_id_fingerprint,
            HostVerification.user_id != member.id))).scalar_one_or_none()
        if conflicting:
            raise HTTPException(409, detail={"code": "NATIONAL_ID_ALREADY_IN_USE"})
    verification.status = "approved"
    verification.legal_name = application.legal_name
    verification.national_id_ciphertext = application.national_id_ciphertext
    verification.national_id_fingerprint = application.national_id_fingerprint
    verification.date_of_birth = application.date_of_birth
    verification.verified_mobile = application.verified_mobile
    verification.email = application.email
    verification.residence_city_id = application.residence_city_id
    verification.biography = application.public_bio
    verification.hosting_experience = application.hosting_background
    verification.rejection_reason = None; verification.requested_information = None
    verification.submitted_at = verification.submitted_at or application.submitted_at or utc_now_naive()
    verification.reviewed_at = utc_now_naive(); verification.reviewed_by_user_id = actor.id
    verification.updated_at = utc_now_naive()

    sub = (await session.execute(select(HostSubscription).where(
        HostSubscription.host_user_id == member.id).order_by(HostSubscription.created_at.desc(), HostSubscription.id.desc()).limit(1).with_for_update())).scalar_one_or_none()
    now = utc_now_naive()
    if sub is None:
        sub = HostSubscription(host_user_id=member.id, plan_code="starter", status="trial",
            starts_at=now, ends_at=now + timedelta(days=30), price_amount=0, currency="IRR",
            notes="30-day host onboarding trial created by explicit host application approval", created_by_user_id=actor.id)
        session.add(sub)
    else:
        sub.status = "trial"; sub.starts_at = now; sub.ends_at = now + timedelta(days=30)
        sub.notes = "Host access reactivated through explicit application approval"; sub.updated_at = now

    organization = (await session.execute(select(Organization).where(Organization.is_platform_founder.is_(True)))).scalar_one_or_none()
    if organization is None or organization.status != "approved":
        raise HTTPException(409, detail={"code": "PLATFORM_ORGANIZATION_NOT_READY"})
    brand = (await session.execute(select(Brand).where(Brand.organization_id == organization.id,
        Brand.slug == "panel-flow", Brand.status == "approved"))).scalar_one_or_none()
    if brand is None:
        raise HTTPException(409, detail={"code": "PLATFORM_BRAND_NOT_READY"})

    # The founding organization uses a platform-managed zero-cost plan when it
    # has not yet been assigned a plan. This is not applied to third-party orgs.
    plan = (await session.execute(select(SubscriptionPlan).where(SubscriptionPlan.code == "panel-flow-host-access"))).scalar_one_or_none()
    if plan is None:
        plan = SubscriptionPlan(code="panel-flow-host-access", name="Panel Flow Host Access", price_amount=0,
            currency="IRR", duration_days=3650, max_brands=100, max_hosts=1000,
            features={"host_workspace": True}, is_active=True)
        session.add(plan); await session.flush()
    org_sub = (await session.execute(select(OrganizationSubscription).where(
        OrganizationSubscription.organization_id == organization.id).order_by(OrganizationSubscription.created_at.desc(),
        OrganizationSubscription.id.desc()).limit(1).with_for_update())).scalar_one_or_none()
    if org_sub is None:
        org_sub = OrganizationSubscription(organization_id=organization.id, plan_id=plan.id,
            status="active", starts_at=now, price_amount=0, currency="IRR", created_by_user_id=actor.id)
        session.add(org_sub)
    elif org_sub.status not in {"active", "trial"} or (org_sub.ends_at and org_sub.ends_at <= now):
        raise HTTPException(409, detail={"code": "PLATFORM_ORGANIZATION_SUBSCRIPTION_INACTIVE"})
    elif not org_sub.plan_id:
        org_sub.plan_id = plan.id

    membership = (await session.execute(select(OrganizationMembership).where(
        OrganizationMembership.organization_id == organization.id,
        OrganizationMembership.user_id == member.id).with_for_update())).scalar_one_or_none()
    if membership is None:
        membership = OrganizationMembership(organization_id=organization.id, user_id=member.id,
            role="host", status="approved", approved_at=now)
        session.add(membership); await session.flush()
    else:
        membership.role = "host"; membership.status = "approved"; membership.approved_at = now
    assignment = await session.get(BrandHostAssignment, (brand.id, membership.id))
    # Composite PK for BrandHostAssignment is (brand_id, membership_id).
    if assignment is None:
        session.add(BrandHostAssignment(organization_id=organization.id, brand_id=brand.id, membership_id=membership.id))
    for city_id in set((application.preferred_city_ids or []) + ([application.residence_city_id] if application.residence_city_id else [])):
        city = await session.get(City, int(city_id))
        if city and city.is_active and await session.get(OrganizationCity, (organization.id, city.id)) is None:
            session.add(OrganizationCity(organization_id=organization.id, city_id=city.id))

    profile = (await session.execute(select(HostPublicProfile).where(HostPublicProfile.user_id == member.id).with_for_update())).scalar_one_or_none()
    base = re.sub(r"[^a-z0-9]+", "-", (application.public_display_name or f"host-{member.id}").lower()).strip("-")
    slug = (base[:90] or "panel-flow-host")
    desired_slug = f"{slug}-{member.id}"
    if profile is None:
        profile = HostPublicProfile(user_id=member.id, slug=desired_slug,
            display_name=application.public_display_name or member.display_name or member.first_name or "Panel Flow Host",
            bio=application.public_bio, languages=application.public_languages or [],
            topics=application.preferred_topics or [], city_ids=application.preferred_city_ids or [], is_active=True)
        session.add(profile)
    else:
        profile.display_name = application.public_display_name or profile.display_name
        profile.bio = application.public_bio; profile.languages = application.public_languages or []
        profile.topics = application.preferred_topics or []; profile.city_ids = application.preferred_city_ids or []
        profile.is_active = True; profile.updated_at = now
    return {"organization_id": organization.id, "brand_id": brand.id, "membership_id": membership.id,
            "public_profile_slug": profile.slug}


@router.post("/staff/platform/host-applications/{application_id}/review")
async def review_host_application(application_id: int, payload: HostApplicationReviewInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if not _is_superadmin(user):
        raise HTTPException(403, detail={"code": "SUPERADMIN_REQUIRED"})
    app = (await session.execute(select(HostApplication).where(HostApplication.id == application_id).with_for_update())).scalar_one_or_none()
    if app is None:
        raise HTTPException(404, detail={"code": "APPLICATION_NOT_FOUND"})
    action = payload.action
    before = app.status
    now = utc_now_naive()
    note = (payload.note or "").strip() or None
    workspace = None
    if action == "start_review":
        if before not in {"submitted", "more_information_required"}:
            raise HTTPException(409, detail={"code": "INVALID_APPLICATION_TRANSITION"})
        app.status = "under_review"
    elif action == "request_information":
        if before not in {"submitted", "under_review", "more_information_required"} or not note:
            raise HTTPException(422, detail={"code": "REQUEST_INFORMATION_REQUIRED"})
        app.status = "more_information_required"; app.requested_information = note
        app.applicant_response = None
    elif action == "approve":
        if before not in {"submitted", "under_review", "more_information_required"}:
            raise HTTPException(409, detail={"code": "INVALID_APPLICATION_TRANSITION"})
        workspace = await _ensure_host_workspace(session, app, user)
        app.status = "approved"; app.requested_information = None; app.rejection_reason = None
    elif action == "reject":
        if before not in {"submitted", "under_review", "more_information_required"} or not note:
            raise HTTPException(422, detail={"code": "REJECTION_REASON_REQUIRED"})
        app.status = "rejected"; app.rejection_reason = note
    elif action == "add_note":
        if not note:
            raise HTTPException(422, detail={"code": "NOTE_REQUIRED"})
        app.internal_notes = ((app.internal_notes or "") + f"\n[{now.isoformat()}] {note}").strip()
        # Do not copy the private note into applicant-visible history.
        action = "internal_note"
        note = None
    elif action == "schedule_interview":
        if payload.interview_at is None:
            raise HTTPException(422, detail={"code": "INTERVIEW_DATETIME_REQUIRED"})
        app.interview_at = payload.interview_at
        app.interview_location = (payload.interview_location or "").strip() or None
        app.interview_notes = (payload.interview_notes or "").strip() or None
    elif action in {"suspend_host", "revoke_host"}:
        if before != "approved" or not note:
            raise HTTPException(409, detail={"code": "APPROVED_HOST_AND_REASON_REQUIRED"})
        member = await session.get(User, app.user_id, with_for_update=True)
        if member and str(getattr(member.role, "value", member.role)) == "host":
            member.role = UserRole.PARTICIPANT
        verification = (await session.execute(select(HostVerification).where(
            HostVerification.user_id == app.user_id).order_by(HostVerification.updated_at.desc()).limit(1).with_for_update())).scalar_one_or_none()
        if verification:
            verification.status = "suspended"; verification.updated_at = now
        memberships = (await session.execute(select(OrganizationMembership).where(
            OrganizationMembership.user_id == app.user_id,
            OrganizationMembership.role == "host").with_for_update())).scalars().all()
        for membership in memberships:
            membership.status = "suspended"
        subscriptions = (await session.execute(select(HostSubscription).where(
            HostSubscription.host_user_id == app.user_id).with_for_update())).scalars().all()
        for subscription in subscriptions:
            if subscription.status in {"active", "trial"}:
                subscription.status = "suspended"; subscription.updated_at = now
        profile = (await session.execute(select(HostPublicProfile).where(HostPublicProfile.user_id == app.user_id).with_for_update())).scalar_one_or_none()
        if profile:
            profile.is_active = False; profile.updated_at = now
        app.status = "approved"  # Preserve decision history; access is suspended independently.
        action = "host_access_suspended" if action == "suspend_host" else "host_access_revoked"
    app.reviewed_at = now; app.reviewed_by_user_id = user.id; app.updated_at = now
    after = app.status
    await _record_history(session, app, user, action, before, after, note,
                          {"interview_at": payload.interview_at.isoformat() if payload.interview_at else None,
                           "workspace": workspace} if workspace else {})
    if action == "start_review":
        await _notify_applicant(session, app, "Host application under review", "A superadmin has started reviewing your host application.")
    elif action == "request_information":
        await _notify_applicant(session, app, "More information requested", note or "Please provide additional information.")
    elif action == "approve":
        await _notify_applicant(session, app, "Host application approved", "Your Host Workspace is ready. Sign in to Panel Flow and open Host Workspace from your account navigation.")
    elif action == "reject":
        await _notify_applicant(session, app, "Host application decision", note or "Your host application was not approved.")
    elif action == "schedule_interview":
        await _notify_applicant(session, app, "Host interview scheduled", f"Interview: {payload.interview_at.isoformat()} · {payload.interview_location or 'Details in your application page'}")
    elif action in {"host_access_suspended", "host_access_revoked"}:
        await _notify_applicant(session, app, "Host access updated", f"Host access was {action.replace('host_access_', '')}. Reason: {note}")
    session.add(PlatformAuditLog(actor_user_id=user.id, action=f"host_application.{action}",
        target_type="host_application", target_id=str(app.id), reason=note,
        metadata_json={"from_status": before, "to_status": after, "user_id": app.user_id, "workspace": workspace or {}}))
    await session.commit()
    return {"id": app.id, "status": app.status, "action": action, "workspace": workspace}


class HostProfileUpdateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    display_name: str = Field(min_length=2, max_length=255)
    bio: str | None = Field(default=None, max_length=3000)
    languages: list[str] = Field(default_factory=list, max_length=20)
    topics: list[str] = Field(default_factory=list, max_length=30)
    city_ids: list[int] = Field(default_factory=list, max_length=30)

    @field_validator("display_name")
    @classmethod
    def profile_name_not_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Display name cannot be blank.")
        return value

    @field_validator("languages", "topics")
    @classmethod
    def clean_profile_lists(cls, values: list[str]) -> list[str]:
        normalized = list(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))
        return normalized


@router.get("/me/host-profile")
async def get_my_host_profile(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    profile = (await session.execute(select(HostPublicProfile).where(
        HostPublicProfile.user_id == user.id))).scalar_one_or_none()
    if profile is None or not profile.is_active:
        raise HTTPException(404, detail={"code": "HOST_PROFILE_NOT_ACTIVE"})
    return {"slug": profile.slug, "display_name": profile.display_name, "bio": profile.bio,
            "languages": profile.languages or [], "topics": profile.topics or [],
            "city_ids": profile.city_ids or [], "is_active": profile.is_active}


@router.patch("/me/host-profile")
async def update_my_host_profile(payload: HostProfileUpdateInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    profile = (await session.execute(select(HostPublicProfile).where(
        HostPublicProfile.user_id == user.id).with_for_update())).scalar_one_or_none()
    if profile is None or not profile.is_active:
        raise HTTPException(404, detail={"code": "HOST_PROFILE_NOT_ACTIVE"})
    city_ids = list(dict.fromkeys(int(value) for value in payload.city_ids))
    if city_ids:
        active = set((await session.execute(select(City.id).where(
            City.id.in_(city_ids), City.is_active.is_(True)))).scalars().all())
        if active != set(city_ids):
            raise HTTPException(422, detail={"code": "CITY_NOT_AVAILABLE"})
    profile.display_name = payload.display_name
    profile.bio = payload.bio.strip() if payload.bio else None
    profile.languages = payload.languages
    profile.topics = payload.topics
    profile.city_ids = city_ids
    profile.updated_at = utc_now_naive()
    session.add(PlatformAuditLog(actor_user_id=user.id, action="host_profile.updated",
        target_type="host_public_profile", target_id=str(profile.id), metadata_json={"user_id": user.id}))
    await session.commit()
    return {"slug": profile.slug, "display_name": profile.display_name, "bio": profile.bio,
            "languages": profile.languages or [], "topics": profile.topics or [],
            "city_ids": profile.city_ids or [], "is_active": profile.is_active}


@router.get("/hosts/{slug}")
async def get_public_host_profile(slug: str, session: AsyncSession = Depends(get_session)):
    result = (await session.execute(select(HostPublicProfile, User).join(User, User.id == HostPublicProfile.user_id).where(
        HostPublicProfile.slug == slug, HostPublicProfile.is_active.is_(True)))).one_or_none()
    if result is None:
        raise HTTPException(404, detail={"code": "HOST_PROFILE_NOT_FOUND"})
    profile, member = result
    return {"slug": profile.slug, "display_name": profile.display_name, "bio": profile.bio,
            "languages": profile.languages or [], "topics": profile.topics or [],
            "city_ids": profile.city_ids or [], "created_at": profile.created_at}
