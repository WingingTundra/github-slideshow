"""Keep successful container health probes out of routine Uvicorn access logs."""
from __future__ import annotations

import logging


class SuccessfulHealthCheckFilter(logging.Filter):
    """Filter only successful GET /health requests; preserve failures and other traffic."""

    def filter(self, record: logging.LogRecord) -> bool:
        args = record.args
        method = path = None
        status_code = None
        if isinstance(args, tuple):
            # Uvicorn's current access logger uses:
            # (client_addr, method, full_path, http_version, status_code)
            if len(args) >= 5:
                method, path, status_code = args[1], args[2], args[4]
            # Compatibility with older/custom access formatters:
            # (client_addr, 'GET /health HTTP/1.1', status_code)
            elif len(args) >= 3:
                request_line = str(args[1]).split()
                if len(request_line) >= 2:
                    method, path = request_line[0], request_line[1]
                    status_code = args[2]
        if method is None or path is None or status_code is None:
            return True
        try:
            status = int(str(status_code).split()[0])
        except (TypeError, ValueError, IndexError):
            return True
        clean_path = str(path).split("?", 1)[0]
        if str(method).upper() == "GET" and clean_path in {"/health", "/health/"} and 200 <= status < 300:
            return False
        return True


def install_successful_health_filter() -> None:
    """Attach the narrow filter once the Uvicorn logger has been configured."""
    access_logger = logging.getLogger("uvicorn.access")
    if not any(isinstance(item, SuccessfulHealthCheckFilter) for item in access_logger.filters):
        access_logger.addFilter(SuccessfulHealthCheckFilter())
