from __future__ import annotations

import hashlib
import logging
import os
import re
import secrets
import shutil
import uuid
from collections import Counter
from datetime import date as date_type, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Query, Request, Response, UploadFile, status
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy import and_, delete, func, or_, select, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config import settings
from app.db.models import (
    AchievementUnlock, AdminAction, AttendanceAudit, AttendanceStatus, Booking, ChallengeSubmission, City, CommunityChallenge, HostSubscription,
    UserTopicFollow, UserOrganizationFollow, UserDiscoveryPreference, EventNotificationDelivery,
    Event, EventStatus, ModerationStatus, Payment, PaymentReviewAttempt, PaymentStatus,
    RegistrationStatus, Review, TopicSuggestion, TopicVote, User, UserRole,
    WebsiteLoginChallenge, WebsiteSavedEvent, XPAward, WaitlistEntry, ShopRequest, XPShopOffer, RewardIssue,
    Organization, OrganizationMembership, Brand, OrganizationCity, OrganizationSubscription, PlatformAuditLog,
    HostVerification, HostPublicProfile, Participant, RecommendationFeedback, WebsiteRecentEventView,
    DiscussionSeries, DiscussionSeriesEvent,
)
from app.db.session import get_session
from app.display_utils import has_end_time_label
from app.http_api.dependencies import get_current_api_user
from app.http_api.security import issue_access_token
from app.services.booking import create_booking, cancel_booking, retry_payment, expire_booking_if_due, MAX_PARTICIPANTS_PER_BOOKING
from app.services.community import leaderboard_rows, user_community_stats, unlock_eligible_achievements, record_paid_panel_award
from app.services.confirmation_ledger import record_confirmed_booking
from app.services.events import ACTIVE_BOOKING_STATUSES, registration_is_open, waitlist_is_available, seats_used
from app.services.payment_review import receipt_fingerprint, lock_payment_review_rows
from app.services.public_events import public_event_payload
from app.services.seat_disclosure import public_catalogue_availability_label, should_disclose_remaining_seats, should_show_capacity_filling_message
from app.services.app_settings import get_bot_settings
from app.services.xp_shop import list_shop_offers, shop_is_enabled, shop_offer_available, reserved_shop_xp, shop_offer_usage, available_shop_xp, shop_request_status_label
from app.services.discounts import validate_code_for_user
from app.services.admin_audit import write_admin_action
from app.services.user_access import has_active_feature_restriction
from app.time_utils import utc_now_naive, tehran_today, to_tehran
from app.bot.file_validation import file_content_matches
from app.services.tenant_access import (is_platform_admin as _tenant_is_admin, authorize_brand, authorize_event_manage, list_accessible_organization_ids)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1", tags=["Panel Flow Website"])


DISCOVERY_TOPICS: tuple[tuple[str, str, str], ...] = (
    ("philosophy", "Philosophy", "فلسفه"), ("psychology", "Psychology", "روان‌شناسی"),
    ("technology", "Technology", "فناوری"), ("science", "Science", "علم"),
    ("literature", "Literature", "ادبیات"), ("economics", "Economics", "اقتصاد"),
    ("art", "Art", "هنر"), ("education", "Education", "آموزش"),
    ("politics", "Politics", "سیاست"), ("business", "Business", "کسب‌وکار"),
    ("culture", "Culture", "فرهنگ"), ("history", "History", "تاریخ"),
)
DISCOVERY_TOPIC_KEYS = {row[0] for row in DISCOVERY_TOPICS}


class DiscoveryPreferencesInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    preferred_city_id: int | None = Field(default=None, gt=0)
    preferred_language: str | None = Field(default=None, max_length=80)
    preferred_format: str | None = Field(default=None, pattern="^(physical|online|hybrid)$")
    notify_followed_topics: bool | None = None
    notify_followed_organizations: bool | None = None
    notify_panel_changes: bool | None = None
    notify_registration_reminders: bool | None = None
    digest_frequency: str | None = Field(default=None, pattern="^(immediate|daily|weekly)$")
    quiet_hours_start: str | None = Field(default=None, pattern="^([01][0-9]|2[0-3]):[0-5][0-9]$")
    quiet_hours_end: str | None = Field(default=None, pattern="^([01][0-9]|2[0-3]):[0-5][0-9]$")

    @model_validator(mode="after")
    def quiet_hours_are_a_pair(self):
        if (self.quiet_hours_start is None) != (self.quiet_hours_end is None):
            raise ValueError("QUIET_HOURS_REQUIRE_START_AND_END")
        return self

    @field_validator("preferred_language")
    @classmethod
    def language_not_blank(cls, value: str | None) -> str | None:
        return value.strip() if value and value.strip() else None


class LoginChallengeRead(BaseModel):
    token: str
    expires_in: int


class LoginChallengePollInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    token: str = Field(min_length=30, max_length=100)


class BookingParticipantInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    phone_number: str | None = Field(default=None, max_length=50)

    @field_validator("first_name", "last_name")
    @classmethod
    def participant_names_not_blank(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Participant names cannot be blank")
        return normalized


class BookingCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_id: int = Field(gt=0)
    participants: list[BookingParticipantInput] = Field(min_length=1, max_length=3)
    contact_phone: str | None = Field(default=None, max_length=50)
    pricing_option: str = Field(default="base", pattern="^(base|without_cafe_order)$")
    discount_code: str | None = Field(default=None, max_length=64)
    idempotency_key: str | None = Field(default=None, min_length=16, max_length=64, pattern=r"^[A-Za-z0-9._:-]+$")


class HostAttendanceInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: str = Field(pattern=r"^(unmarked|attended|no_show)$")


class HostAttendanceToggleInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool


class HostDiscussionSeriesInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(min_length=2, max_length=255)
    description: str | None = Field(default=None, max_length=3000)
    event_ids: list[int] = Field(min_length=2, max_length=30)

    @field_validator("title")
    @classmethod
    def clean_series_title(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("SERIES_TITLE_TOO_SHORT")
        return value

    @field_validator("event_ids")
    @classmethod
    def distinct_event_ids(cls, value: list[int]) -> list[int]:
        if len(value) != len(set(value)) or any(int(item) <= 0 for item in value):
            raise ValueError("SERIES_EVENT_IDS_MUST_BE_UNIQUE_POSITIVE_IDS")
        return value

    @field_validator("description")
    @classmethod
    def clean_series_description(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


class WaitlistJoinInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    participant_count: int = Field(ge=1, le=MAX_PARTICIPANTS_PER_BOOKING)


class ShopRequestInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    offer_id: int = Field(gt=0)
    expected_revision: int = Field(ge=1)


class PlatformRoleUpdateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    role: str = Field(pattern=r"^(participant|admin|super_admin)$")


class ProfileUpdateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    display_name: str = Field(min_length=2, max_length=255)

    @field_validator("display_name")
    @classmethod
    def display_name_not_blank(cls, value: str) -> str:
        normalized = value.strip()
        if len(normalized) < 2:
            raise ValueError("Display name must contain at least two non-space characters")
        return normalized


class ReviewCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_id: int = Field(gt=0)
    rating: int = Field(ge=1, le=5)
    discussion_quality: int | None = Field(default=None, ge=1, le=5)
    moderator_rating: int | None = Field(default=None, ge=1, le=5)
    topic_relevance: int | None = Field(default=None, ge=1, le=5)
    would_attend_again: bool | None = None
    text: str = Field(min_length=10, max_length=2000)

    @field_validator("text")
    @classmethod
    def review_text_not_blank(cls, value: str) -> str:
        normalized = value.strip()
        if len(normalized) < 10:
            raise ValueError("Review text must contain at least ten non-space characters")
        return normalized


class ChallengeAnswerInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    answer_text: str = Field(min_length=1, max_length=4000)

    @field_validator("answer_text")
    @classmethod
    def challenge_answer_not_blank(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Answer cannot be blank")
        return normalized


class TopicCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(min_length=5, max_length=200)

    @field_validator("title")
    @classmethod
    def topic_title_not_blank(cls, value: str) -> str:
        normalized = value.strip()
        if len(normalized) < 5:
            raise ValueError("Topic title must contain at least five non-space characters")
        return normalized


class ShopReviewInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: str = Field(pattern="^(approved|denied)$")
    reason: str | None = Field(default=None, max_length=500)


class PaymentReviewInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: str = Field(pattern="^(approved|rejected)$")
    reason_category: str | None = Field(default=None, max_length=40)
    reason_text: str | None = Field(default=None, max_length=500)
    receipt_token: str = Field(min_length=12, max_length=12)


def _required_event_label(value: str, field_name: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} cannot be blank")
    return normalized


def _event_time_label(value: str) -> str:
    normalized = _required_event_label(value, "Time")
    if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", normalized):
        raise ValueError("Time must use 24-hour HH:MM format")
    return normalized


def _optional_event_time_label(value: str | None) -> str | None:
    if value is None or not value.strip():
        return None
    return _event_time_label(value)


class EventCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    volume: str = Field(min_length=1, max_length=80)
    title: str = Field(min_length=2, max_length=255)
    language: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=12000)
    day: str = Field(min_length=1, max_length=100)
    date: str = Field(min_length=1, max_length=255)
    date_iso: date_type | None = None
    city_id: int | None = Field(default=None, gt=0)
    start_time: str = Field(min_length=1, max_length=5)
    end_time: str | None = Field(default=None, max_length=5)
    venue: str | None = Field(default=None, max_length=255)
    address: str | None = Field(default=None, max_length=500)
    map_url: str | None = Field(default=None, max_length=1000)
    city: str = Field(default="Mashhad", min_length=1, max_length=100)
    capacity: int = Field(ge=0, le=10000)
    price_per_person: int = Field(ge=0, le=999999999999)
    price_without_cafe_order: int | None = Field(default=None, ge=0, le=999999999999)
    event_type: str = Field(default="physical", pattern="^(physical|online|hybrid)$")
    organization_id: int | None = Field(default=None, gt=0)
    brand_id: int | None = Field(default=None, gt=0)
    meeting_platform: str | None = Field(default=None, max_length=40)
    meeting_link: str | None = Field(default=None, max_length=2000)
    meeting_link_released: bool = False
    topic_tags: list[str] = Field(default_factory=list, max_length=12)
    agenda_items: list[str] = Field(default_factory=list, max_length=12)
    discussion_questions: list[str] = Field(default_factory=list, max_length=12)
    waitlist_enabled: bool = True

    @field_validator("topic_tags")
    @classmethod
    def valid_topic_tags(cls, values: list[str]) -> list[str]:
        normalized = list(dict.fromkeys(str(v).strip().lower() for v in values if str(v).strip()))
        if any(v not in DISCOVERY_TOPIC_KEYS for v in normalized):
            raise ValueError("Unknown Panel Flow topic")
        return normalized

    @field_validator("agenda_items")
    @classmethod
    def valid_agenda_items(cls, values: list[str]) -> list[str]:
        normalized = [str(v).strip() for v in values if str(v).strip()]
        if any(len(v) > 200 for v in normalized):
            raise ValueError("Agenda items must be 200 characters or fewer")
        return normalized

    @field_validator("discussion_questions")
    @classmethod
    def valid_discussion_questions(cls, values: list[str]) -> list[str]:
        normalized = [str(v).strip() for v in values if str(v).strip()]
        if any(len(v) < 5 or len(v) > 500 for v in normalized):
            raise ValueError("Discussion questions must contain 5 to 500 characters")
        return normalized

    @field_validator("volume", "title", "day", "date", "city")
    @classmethod
    def required_labels_not_blank(cls, value: str, info):
        normalized = _required_event_label(value, info.field_name)
        minimum = 2 if info.field_name == "title" else 1
        if len(normalized) < minimum:
            raise ValueError(f"{info.field_name} must contain at least {minimum} character(s)")
        return normalized

    @field_validator("start_time")
    @classmethod
    def start_time_must_be_valid(cls, value: str) -> str:
        return _event_time_label(value)

    @field_validator("end_time")
    @classmethod
    def end_time_must_be_valid_when_present(cls, value: str | None) -> str | None:
        return _optional_event_time_label(value)

    @model_validator(mode="after")
    def validate_modality(self):
        if self.event_type in {"physical", "hybrid"} and not (self.venue or "").strip():
            raise ValueError("Physical and hybrid events require a venue")
        if self.event_type in {"online", "hybrid"} and not (self.meeting_platform or "").strip():
            raise ValueError("Online and hybrid events require a meeting platform")
        if self.meeting_link and self.event_type == "physical":
            raise ValueError("Physical events cannot have a meeting link")
        return self

    @field_validator("meeting_link")
    @classmethod
    def meeting_link_must_be_http(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        parsed = urlsplit(value.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Meeting link must use http or https")
        return value.strip()

    @field_validator("map_url")
    @classmethod
    def map_url_must_be_http(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        normalized = value.strip()
        parsed = urlsplit(normalized)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Map URL must use http or https")
        return normalized


class EventUpdateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str | None = Field(default=None, min_length=2, max_length=255)
    language: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=12000)
    day: str | None = Field(default=None, max_length=100)
    date: str | None = Field(default=None, max_length=255)
    date_iso: date_type | None = None
    city_id: int | None = Field(default=None, gt=0)
    start_time: str | None = Field(default=None, max_length=5)
    end_time: str | None = Field(default=None, max_length=5)
    venue: str | None = Field(default=None, max_length=255)
    address: str | None = Field(default=None, max_length=500)
    map_url: str | None = Field(default=None, max_length=1000)
    city: str | None = Field(default=None, max_length=100)
    capacity: int | None = Field(default=None, ge=0, le=10000)
    price_per_person: int | None = Field(default=None, ge=0, le=999999999999)
    price_without_cafe_order: int | None = Field(default=None, ge=0, le=999999999999)
    registration_open: bool | None = None
    waitlist_enabled: bool | None = None
    status: str | None = Field(default=None, pattern="^(draft|published|completed|cancelled)$")
    event_type: str | None = Field(default=None, pattern="^(physical|online|hybrid)$")
    meeting_platform: str | None = Field(default=None, max_length=40)
    meeting_link: str | None = Field(default=None, max_length=2000)
    meeting_link_released: bool | None = None
    topic_tags: list[str] | None = Field(default=None, max_length=12)
    agenda_items: list[str] | None = Field(default=None, max_length=12)
    discussion_questions: list[str] | None = Field(default=None, max_length=12)
    is_postponed: bool | None = None
    postponement_note: str | None = Field(default=None, max_length=2000)
    cover_image_url: str | None = Field(default=None, max_length=1000)

    @field_validator("postponement_note")
    @classmethod
    def clean_postponement_note(cls, value: str | None) -> str | None:
        return value.strip() if value and value.strip() else None

    @field_validator("cover_image_url")
    @classmethod
    def cover_image_must_be_managed_media(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        value = value.strip()
        if not re.fullmatch(r"/api/v1/media/[a-z0-9][a-z0-9_-]{0,120}\.webp", value):
            raise ValueError("Use the managed image upload endpoint")
        return value

    @field_validator("topic_tags")
    @classmethod
    def update_topic_tags(cls, values: list[str] | None) -> list[str] | None:
        if values is None: return None
        normalized = list(dict.fromkeys(str(v).strip().lower() for v in values if str(v).strip()))
        if any(v not in DISCOVERY_TOPIC_KEYS for v in normalized): raise ValueError("Unknown Panel Flow topic")
        return normalized

    @field_validator("agenda_items")
    @classmethod
    def update_agenda_items(cls, values: list[str] | None) -> list[str] | None:
        if values is None: return None
        normalized = [str(v).strip() for v in values if str(v).strip()]
        if any(len(v) > 200 for v in normalized): raise ValueError("Agenda items must be 200 characters or fewer")
        return normalized

    @field_validator("discussion_questions")
    @classmethod
    def update_questions(cls, values: list[str] | None) -> list[str] | None:
        if values is None: return None
        normalized = [str(v).strip() for v in values if str(v).strip()]
        if any(len(v) < 5 or len(v) > 500 for v in normalized): raise ValueError("Discussion questions must contain 5 to 500 characters")
        return normalized

    @model_validator(mode="after")
    def reject_null_for_required_columns(self):
        for field_name in (
            "title", "day", "date", "start_time", "city", "capacity",
            "price_per_person", "registration_open", "waitlist_enabled", "status", "event_type",
            "topic_tags", "agenda_items", "discussion_questions", "is_postponed",
        ):
            if field_name in self.model_fields_set and getattr(self, field_name) is None:
                raise ValueError(f"{field_name} cannot be null")
        return self

    @field_validator("title", "day", "date", "city")
    @classmethod
    def optional_required_labels_not_blank(cls, value: str | None, info):
        if value is None:
            return None
        normalized = _required_event_label(value, info.field_name)
        minimum = 2 if info.field_name == "title" else 1
        if len(normalized) < minimum:
            raise ValueError(f"{info.field_name} must contain at least {minimum} character(s)")
        return normalized

    @field_validator("start_time")
    @classmethod
    def optional_start_time_must_be_valid(cls, value: str | None) -> str | None:
        return _event_time_label(value) if value is not None else None

    @field_validator("end_time")
    @classmethod
    def optional_end_time_must_be_valid(cls, value: str | None) -> str | None:
        return _optional_event_time_label(value)

    @field_validator("meeting_link")
    @classmethod
    def meeting_link_must_be_http(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        parsed = urlsplit(value.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Meeting link must use http or https")
        return value.strip()

    @field_validator("map_url")
    @classmethod
    def map_url_must_be_http(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        normalized = value.strip()
        parsed = urlsplit(normalized)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Map URL must use http or https")
        return normalized


def _role(user: User) -> str:
    stored_role = user.role.value if hasattr(user.role, "value") else str(user.role)
    if int(user.telegram_id) in settings.super_admin_only_id_set or stored_role == "super_admin":
        return "super_admin"
    if int(user.telegram_id) in settings.admin_id_set or stored_role == "admin":
        return "admin"
    return stored_role


def _is_admin(user: User) -> bool:
    # This is evaluated from the freshly-loaded user on every request. The protected
    # environment allow-list remains authoritative, matching the bot policy.
    return int(user.telegram_id) in settings.super_admin_id_set or user.role in {UserRole.ADMIN, UserRole.SUPER_ADMIN}


def _require_admin(user: User) -> None:
    if not _is_admin(user):
        raise HTTPException(status_code=403, detail={"code": "ADMIN_REQUIRED", "message": "این بخش فقط برای مدیران در دسترس است."})


def _is_superadmin(user: User) -> bool:
    role = str(getattr(user.role, "value", user.role))
    return int(user.telegram_id) in settings.super_admin_only_id_set or role == "super_admin"


def _require_superadmin(user: User) -> None:
    if not _is_superadmin(user):
        raise HTTPException(status_code=403, detail={"code": "SUPERADMIN_REQUIRED"})


def _require_admin_or_host(user: User) -> None:
    # This is only a coarse authenticated-staff guard. Actual tenant permissions
    # are always decided by tenant_access.py using approved memberships,
    # verification, subscription state and brand assignments.
    if not user or not user.id:
        raise HTTPException(status_code=403, detail={"code": "STAFF_REQUIRED"})


async def _ensure_active_host_subscription(user: User, session: AsyncSession) -> None:
    if _is_admin(user):
        return
    now = utc_now_naive()
    subscription = (await session.execute(
        select(HostSubscription).where(HostSubscription.host_user_id == user.id)
        .order_by(HostSubscription.created_at.desc(), HostSubscription.id.desc()).limit(1)
    )).scalar_one_or_none()
    if subscription is None or subscription.status not in {"active", "trial"} or (subscription.ends_at and subscription.ends_at <= now):
        raise HTTPException(status_code=403, detail={
            "code": "HOST_SUBSCRIPTION_INACTIVE",
            "message": "اشتراک میزبانی شما فعال نیست. برای تمدید با مدیر پلتفرم در ارتباط باشید.",
        })


def _city_payload(city: City, event_count: int = 0, *, upcoming_count: int = 0, completed_count: int = 0, recent_activity_count: int = 0, organization_count: int = 0, topic_tags: list[str] | None = None) -> dict:
    return {
        "id": int(city.id), "slug": city.slug, "name_fa": city.name_fa, "name_en": city.name_en,
        "province_fa": city.province_fa, "province_en": city.province_en,
        "latitude": float(city.latitude), "longitude": float(city.longitude),
        "event_count": int(event_count), "upcoming_event_count": int(upcoming_count),
        "completed_event_count": int(completed_count), "recent_activity_count": int(recent_activity_count),
        "organization_count": int(organization_count), "topic_tags": list(topic_tags or []), "is_active": bool(city.is_active),
        "is_founding_city": bool(city.is_founding_city),
        "description_fa": city.description_fa, "description_en": city.description_en,
    }


def _subscription_payload(subscription: HostSubscription | None) -> dict:
    if subscription is None:
        return {"plan_code": None, "status": "inactive", "starts_at": None, "ends_at": None,
                "price_amount": 0, "days_remaining": 0}
    now = utc_now_naive()
    remaining = None if subscription.ends_at is None else max(0, (to_tehran(subscription.ends_at).date() - tehran_today()).days)
    status_value = subscription.status
    if status_value in {"active", "trial"} and subscription.ends_at and subscription.ends_at <= now:
        status_value = "expired"
    return {"id": int(subscription.id), "plan_code": subscription.plan_code, "status": status_value,
            "starts_at": subscription.starts_at, "ends_at": subscription.ends_at,
            "price_amount": int(subscription.price_amount), "currency": subscription.currency,
            "notes": subscription.notes, "days_remaining": remaining}


def _event_read_payload(event: Event, used: int, *, include_detail: bool = True) -> dict:
    remaining = max(0, int(event.capacity) - int(used))
    waitlist = waitlist_is_available(event, used)
    payload = public_event_payload(event, used, include_extended=True)
    payload["availability_label"] = public_catalogue_availability_label(
        event.capacity, remaining,
        registration_open=registration_is_open(event),
        waitlist_available=waitlist,
    )
    payload["waitlist_enabled"] = waitlist
    payload["city_id"] = int(event.city_id) if event.city_id is not None else None
    payload["date_iso"] = event.event_date_iso.isoformat() if event.event_date_iso else None
    payload["remaining_seats"] = remaining if should_disclose_remaining_seats(event.capacity, remaining) else None
    payload["filling_soon"] = should_show_capacity_filling_message(event.capacity, used, remaining)
    payload["organization_id"] = int(event.organization_id) if event.organization_id is not None else None
    payload["brand_id"] = int(event.brand_id) if event.brand_id is not None else None
    payload["topic_tags"] = list(event.topic_tags or [])
    payload["agenda_items"] = list(event.agenda_items or [])
    payload["discussion_questions"] = list(event.discussion_questions or [])
    if include_detail:
        payload.update({
            "host_name": event.host_name,
            "archived": bool(event.archived),
            "created_at": event.created_at,
        })
    return payload


def _booking_payload(booking: Booking, event: Event | None, payment: Payment | None = None) -> dict:
    if event is None:
        return {"id": int(booking.id), "event_id": int(booking.event_id), "status": str(booking.status.value if hasattr(booking.status, 'value') else booking.status)}
    return {
        "id": int(booking.id), "event_id": int(event.id), "event_title": event.title,
        "event_day": event.event_day_label, "event_date": event.event_date_label,
        "event_start_time": event.start_time_label,
        "event_end_time": event.end_time_label if has_end_time_label(event.end_time_label) else None,
        "event_date_iso": event.event_date_iso.isoformat() if event.event_date_iso else None,
        "event_type": event.event_type or "physical",
        "event_venue": event.venue, "event_city": event.city,
        "participant_count": int(booking.participant_count), "total_amount": int(Decimal(booking.total_amount or 0)),
        "status": booking.status.value if hasattr(booking.status, "value") else str(booking.status),
        "created_at": booking.created_at, "confirmed_at": booking.confirmed_at,
        "cancelled_at": booking.cancelled_at, "expires_at": booking.expires_at,
        "cancellation_resolution": getattr(booking, "cancellation_resolution", None),
        "discount_amount": int(Decimal(getattr(booking, "discount_amount", 0) or 0)),
        "discount_code": booking.discount_code_snapshot,
        "payment_status": (payment.status.value if hasattr(payment.status, "value") else str(payment.status)) if payment else None,
        "receipt_submitted": bool(payment and (payment.receipt_file or payment.receipt_text)),
    }


def _raise_service_error(exc: ValueError) -> None:
    code = str(exc)
    messages = {
        "EVENT_NOT_OPEN": (409, "ثبت‌نام این پنل در حال حاضر باز نیست."),
        "PRICE_CHANGED": (409, "قیمت پنل تغییر کرده است؛ صفحه را تازه کنید."),
        "DUPLICATE": (409, "برای این پنل از قبل رزرو فعال دارید."),
        "FULL": (409, "ظرفیت این پنل تکمیل شده است."),
        "TOO_MANY": (422, "تعداد نفرات بیشتر از ظرفیت مجاز است."),
        "USER_SEAT_LIMIT": (409, "حداکثر سه صندلی فعال برای هر حساب مجاز است."),
        "USER_BOOKING_RESTRICTED": (403, "امکان ثبت‌نام برای این حساب محدود شده است."),
        "NO_PARTICIPANTS": (422, "اطلاعات شرکت‌کنندگان کامل نیست."),
        "PARTICIPANT_NAME_REQUIRED": (422, "نام و نام خانوادگی همه شرکت‌کنندگان الزامی است."),
        "INVALID_BOOKER_PHONE": (422, "شماره تماس معتبر نیست."),
        "INVALID_PARTICIPANT_PHONE": (422, "شماره تماس یکی از شرکت‌کنندگان معتبر نیست."),
        "PAYMENT_CONFIGURATION_MISSING": (503, "اطلاعات پرداخت هنوز توسط مدیر تنظیم نشده است."),
        "NOT_FOUND": (404, "رزرو پیدا نشد."),
        "NOT_RETRYABLE": (409, "این رزرو امکان ارسال مجدد رسید ندارد."),
        "CONFIRMED_CANCELLATION_FORBIDDEN": (409, "لغو ثبت‌نام تأییدشدهٔ دارای پرداخت از این مسیر امکان‌پذیر نیست؛ با پشتیبانی تماس بگیرید."),
        "NOT_CANCELLABLE": (409, "این رزرو در وضعیت فعلی قابل لغو نیست."),
    }
    http_status, message = messages.get(code, (400, "درخواست قابل انجام نیست."))
    raise HTTPException(status_code=http_status, detail={"code": code, "message": message}) from exc


class HostCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    telegram_id: int = Field(gt=0)
    plan_code: str = Field(default="starter", pattern="^(starter|growth|pro|custom)$")
    duration_days: int = Field(default=30, ge=1, le=730)
    price_amount: int = Field(default=0, ge=0, le=999999999999)
    currency: str = Field(default="TOMAN", pattern="^(IRR|TOMAN)$")
    status: str = Field(default="active", pattern="^(active|trial|suspended)$")
    notes: str | None = Field(default=None, max_length=500)


class HostSubscriptionUpdateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    plan_code: str | None = Field(default=None, pattern="^(starter|growth|pro|custom|legacy)$")
    duration_days: int | None = Field(default=None, ge=1, le=730)
    price_amount: int | None = Field(default=None, ge=0, le=999999999999)
    currency: str | None = Field(default=None, pattern="^(IRR|TOMAN)$")
    status: str | None = Field(default=None, pattern="^(active|trial|suspended|cancelled)$")
    notes: str | None = Field(default=None, max_length=500)


class CityCreateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    slug: str = Field(min_length=2, max_length=80, pattern="^[a-z0-9]+(?:-[a-z0-9]+)*$")
    name_fa: str = Field(min_length=2, max_length=120)
    name_en: str = Field(min_length=2, max_length=120)
    province_fa: str = Field(min_length=2, max_length=120)
    province_en: str = Field(min_length=2, max_length=120)
    latitude: float = Field(ge=24, le=40)
    longitude: float = Field(ge=43, le=64)
    description_fa: str | None = Field(default=None, max_length=4000)
    description_en: str | None = Field(default=None, max_length=4000)

    @field_validator("name_fa", "name_en", "province_fa", "province_en")
    @classmethod
    def city_labels_not_blank(cls, value: str, info) -> str:
        normalized = value.strip()
        if len(normalized) < 2:
            raise ValueError(f"{info.field_name} must contain at least two non-space characters")
        return normalized


class CityUpdateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name_fa: str | None = Field(default=None, min_length=2, max_length=120)
    name_en: str | None = Field(default=None, min_length=2, max_length=120)
    province_fa: str | None = Field(default=None, min_length=2, max_length=120)
    province_en: str | None = Field(default=None, min_length=2, max_length=120)
    latitude: float | None = Field(default=None, ge=24, le=40)
    longitude: float | None = Field(default=None, ge=43, le=64)
    is_active: bool | None = None
    description_fa: str | None = Field(default=None, max_length=4000)
    description_en: str | None = Field(default=None, max_length=4000)

    @field_validator("name_fa", "name_en", "province_fa", "province_en")
    @classmethod
    def optional_city_labels_not_blank(cls, value: str | None, info) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if len(normalized) < 2:
            raise ValueError(f"{info.field_name} must contain at least two non-space characters")
        return normalized

    @model_validator(mode="after")
    def reject_null_for_non_nullable_columns(self):
        for field_name in ("name_fa", "name_en", "province_fa", "province_en", "latitude", "longitude", "is_active"):
            if field_name in self.model_fields_set and getattr(self, field_name) is None:
                raise ValueError(f"{field_name} cannot be null")
        return self


@router.post("/auth/telegram/link", response_model=LoginChallengeRead)
async def create_website_login_challenge(session: AsyncSession = Depends(get_session)):
    """Create a one-time handoff that is approved by opening a bot deep link."""
    if len(settings.api_token_secret or "") < 32:
        raise HTTPException(status_code=503, detail={"code": "AUTH_NOT_CONFIGURED", "message": "ورود وب‌سایت هنوز پیکربندی نشده است."})
    token = secrets.token_urlsafe(32)
    now = utc_now_naive()
    # Keep this small table bounded without a separate scheduler.
    # Serialize challenge creation and cap outstanding one-time links. This keeps
    # anonymous login attempts from growing the challenge table without bound.
    await session.execute(text("SELECT pg_advisory_xact_lock(70420261101)"))
    await session.execute(delete(WebsiteLoginChallenge).where(WebsiteLoginChallenge.expires_at <= now))
    outstanding = int(await session.scalar(select(func.count(WebsiteLoginChallenge.id)).where(
        WebsiteLoginChallenge.expires_at > now, WebsiteLoginChallenge.status.in_(("pending", "authenticated"))
    )) or 0)
    if outstanding >= 500:
        raise HTTPException(status_code=429, detail={"code": "LOGIN_CAPACITY", "message": "ورودهای هم‌زمان زیادی در حال انجام است؛ چند دقیقه دیگر دوباره تلاش کنید."})
    session.add(WebsiteLoginChallenge(
        token_hash=hashlib.sha256(token.encode("utf-8")).hexdigest(),
        status="pending", created_at=now, expires_at=now + timedelta(minutes=5),
    ))
    await session.commit()
    return {"token": token, "expires_in": 300}


@router.post("/auth/telegram/link/poll")
async def poll_website_login_challenge(payload: LoginChallengePollInput, session: AsyncSession = Depends(get_session)):
    # Keep the one-time bearer handoff out of URL paths/query strings and routine
    # reverse-proxy access logs. POST responses are not cacheable by default.
    digest = hashlib.sha256(payload.token.encode("utf-8")).hexdigest()
    challenge = (await session.execute(select(WebsiteLoginChallenge).where(WebsiteLoginChallenge.token_hash == digest).with_for_update())).scalar_one_or_none()
    now = utc_now_naive()
    if challenge is None or challenge.expires_at <= now:
        raise HTTPException(status_code=410, detail={"code": "LOGIN_CHALLENGE_EXPIRED", "message": "مهلت ورود پایان یافته است. دوباره تلاش کنید."})
    if challenge.status == "pending":
        return {"status": "pending"}
    if challenge.status != "authenticated" or not challenge.user_id or not challenge.telegram_id:
        raise HTTPException(status_code=410, detail={"code": "LOGIN_CHALLENGE_USED"})
    user = await session.get(User, int(challenge.user_id))
    if user is None or int(user.telegram_id) != int(challenge.telegram_id):
        challenge.status = "consumed"
        await session.commit()
        raise HTTPException(status_code=410, detail={"code": "LOGIN_ACCOUNT_UNAVAILABLE"})
    from app.services.authorization import active_account_restriction
    if await active_account_restriction(user.telegram_id):
        challenge.status = "consumed"
        challenge.consumed_at = now
        await session.commit()
        raise HTTPException(status_code=403, detail={"code": "ACCOUNT_RESTRICTED"})
    access_token, ttl = issue_access_token(
        user_id=user.id, telegram_id=user.telegram_id,
        secret=settings.api_token_secret, ttl_seconds=settings.api_token_ttl_seconds,
    )
    challenge.status = "consumed"
    challenge.consumed_at = now
    await session.commit()
    return {"status": "authenticated", "access_token": access_token, "token_type": "bearer", "expires_in": ttl,
            "user": {"id": user.id, "display_name": user.display_name, "first_name": user.first_name,
                     "last_name": user.last_name, "telegram_username": user.telegram_username,
                     "phone_number": user.phone_number, "role": _role(user), "created_at": user.created_at}}


@router.get("/calendar/events")
async def public_calendar_events(limit: int = Query(default=1000, ge=1, le=2000), offset: int = Query(default=0, ge=0, le=100000), session: AsyncSession = Depends(get_session)):
    base = (Event.status == EventStatus.PUBLISHED, Event.archived.is_(False), Event.event_date_iso.is_not(None),
            Event.city_id.in_(select(City.id).where(City.is_active.is_(True))))
    total = int(await session.scalar(select(func.count(Event.id)).where(*base)) or 0)
    rows = (await session.execute(select(Event).where(*base).order_by(Event.event_date_iso.asc(), Event.id.desc()).offset(offset).limit(limit))).scalars().all()
    ids = [int(row.id) for row in rows]
    usage_rows = (await session.execute(select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_(ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES)).group_by(Booking.event_id))).all() if ids else []
    usage = {int(event_id): int(count) for event_id, count in usage_rows}
    return {"items": [_event_read_payload(row, usage.get(int(row.id), 0)) for row in rows], "total": total, "limit": limit, "offset": offset}


@router.get("/cities")
async def public_cities(session: AsyncSession = Depends(get_session)):
    cities = (await session.execute(select(City).where(City.is_active.is_(True)).order_by(City.is_founding_city.desc(), City.name_en))).scalars().all()
    counts = dict((int(city_id), int(count)) for city_id, count in (await session.execute(
        select(Event.city_id, func.count(Event.id)).where(
            Event.city_id.is_not(None), Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
        ).group_by(Event.city_id)
    )).all())
    org_counts = dict((int(city_id), int(count)) for city_id, count in (await session.execute(
        select(OrganizationCity.city_id, func.count(func.distinct(OrganizationCity.organization_id))).join(
            Organization, Organization.id == OrganizationCity.organization_id).where(
            Organization.status == "approved").group_by(OrganizationCity.city_id)
    )).all())
    today = tehran_today()
    upcoming_counts = dict((int(city_id), int(count)) for city_id, count in (await session.execute(
        select(Event.city_id, func.count(Event.id)).where(
            Event.city_id.is_not(None), Event.status == EventStatus.PUBLISHED, Event.archived.is_(False),
            Event.event_date_iso.is_not(None), Event.event_date_iso >= today
        ).group_by(Event.city_id)
    )).all())
    completed_counts = dict((int(city_id), int(count)) for city_id, count in (await session.execute(
        select(Event.city_id, func.count(Event.id)).where(
            Event.city_id.is_not(None), Event.status == EventStatus.COMPLETED, Event.archived.is_(False)
        ).group_by(Event.city_id)
    )).all())
    recent_cutoff = utc_now_naive() - timedelta(days=30)
    activity_counts = dict((int(city_id), int(count)) for city_id, count in (await session.execute(
        select(Event.city_id, func.count(Event.id)).where(
            Event.city_id.is_not(None), Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
            Event.archived.is_(False), Event.updated_at >= recent_cutoff
        ).group_by(Event.city_id)
    )).all())
    # Return only public category keys (never member activity or identities). Keep
    # the map payload bounded to the latest 1,000 public panels nationally.
    city_topics: dict[int, set[str]] = {}
    city_ids = [int(city.id) for city in cities]
    if city_ids:
        topic_rows = (await session.execute(select(Event.city_id, Event.topic_tags).where(
            Event.city_id.in_(city_ids), Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
        ).order_by(Event.updated_at.desc(), Event.id.desc()).limit(1000))).all()
        for city_id, tags in topic_rows:
            if city_id is None:
                continue
            values = city_topics.setdefault(int(city_id), set())
            values.update(str(tag) for tag in (tags or []) if isinstance(tag, str))
    return {"items": [_city_payload(city, counts.get(int(city.id), 0),
        upcoming_count=upcoming_counts.get(int(city.id), 0),
        completed_count=completed_counts.get(int(city.id), 0),
        recent_activity_count=activity_counts.get(int(city.id), 0),
        organization_count=org_counts.get(int(city.id), 0),
        topic_tags=sorted(city_topics.get(int(city.id), set()))) for city in cities], "total": len(cities)}


@router.get("/cities/{slug}")
async def public_city_detail(slug: str, limit: int = Query(default=100, ge=1, le=100), offset: int = Query(default=0, ge=0, le=100000), session: AsyncSession = Depends(get_session)):
    city = (await session.execute(select(City).where(City.slug == slug, City.is_active.is_(True)))).scalar_one_or_none()
    if city is None:
        raise HTTPException(status_code=404, detail={"code": "CITY_NOT_FOUND", "message": "این شهر در فهرست شهرهای فعال پیدا نشد."})
    base = (Event.city_id == city.id, Event.status == EventStatus.PUBLISHED, Event.archived.is_(False))
    total = int(await session.scalar(select(func.count(Event.id)).where(*base)) or 0)
    rows = (await session.execute(select(Event).where(*base).order_by(Event.event_date_iso.asc().nullslast(), Event.id.desc()).offset(offset).limit(limit))).scalars().all()
    ids = [int(row.id) for row in rows]
    usage_rows = (await session.execute(select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_(ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES)).group_by(Booking.event_id))).all() if ids else []
    usage = {int(event_id): int(count) for event_id, count in usage_rows}
    items = [_event_read_payload(row, usage.get(int(row.id), 0)) for row in rows]
    org_ids = {int(row.organization_id) for row in rows if row.organization_id is not None}
    brand_ids = {int(row.brand_id) for row in rows if row.brand_id is not None}
    public_orgs = (await session.execute(select(Organization).where(
        Organization.id.in_(org_ids), Organization.status == "approved"))).scalars().all() if org_ids else []
    public_brands = (await session.execute(select(Brand).where(
        Brand.id.in_(brand_ids), Brand.status == "approved"))).scalars().all() if brand_ids else []
    org_map = {int(org.id): org for org in public_orgs}
    brand_map = {int(brand.id): brand for brand in public_brands}
    for row, item in zip(rows, items):
        item["city"] = city.name_en
        item["city_id"] = int(city.id)
        org = org_map.get(int(row.organization_id)) if row.organization_id is not None else None
        brand = brand_map.get(int(row.brand_id)) if row.brand_id is not None else None
        item["organization"] = ({"id": org.id, "slug": org.slug, "name": org.name,
            "is_platform_founder": bool(org.is_platform_founder)} if org else None)
        item["brand"] = ({"id": brand.id, "slug": brand.slug, "name": brand.name} if brand else None)
    organizations = (await session.execute(select(Organization).join(OrganizationCity,
        OrganizationCity.organization_id == Organization.id).where(
        OrganizationCity.city_id == city.id, Organization.status == "approved").order_by(Organization.is_platform_founder.desc(), Organization.name))).scalars().all()
    org_data = []
    for org in organizations:
        brands = (await session.execute(select(Brand).where(Brand.organization_id == org.id, Brand.status == "approved").order_by(Brand.name))).scalars().all()
        org_data.append({"id": org.id, "slug": org.slug, "name": org.name, "description": org.description,
            "logo_url": org.logo_url, "is_platform_founder": bool(org.is_platform_founder),
            "brands": [{"id": b.id, "slug": b.slug, "name": b.name, "logo_url": b.logo_url} for b in brands]})
    today = tehran_today()
    upcoming_count = int(await session.scalar(select(func.count(Event.id)).where(
        Event.city_id == city.id, Event.status == EventStatus.PUBLISHED, Event.archived.is_(False),
        Event.event_date_iso.is_not(None), Event.event_date_iso >= today)) or 0)
    completed_count = int(await session.scalar(select(func.count(Event.id)).where(
        Event.city_id == city.id, Event.status == EventStatus.COMPLETED, Event.archived.is_(False))) or 0)
    recent_completed = (await session.execute(select(Event).where(
        Event.city_id == city.id, Event.status == EventStatus.COMPLETED, Event.archived.is_(False)
    ).order_by(Event.updated_at.desc(), Event.id.desc()).limit(6))).scalars().all()
    topic_rows = (await session.execute(select(Event.topic_tags).where(
        Event.city_id == city.id, Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
        Event.archived.is_(False), Event.updated_at >= utc_now_naive() - timedelta(days=365)
    ).order_by(Event.updated_at.desc()).limit(250))).scalars().all()
    topic_counts = Counter(
        str(tag) for tags in topic_rows for tag in (tags or [])
        if isinstance(tag, str) and tag in DISCOVERY_TOPIC_KEYS
    )
    popular_topics = [{"key": key, "panel_count": count} for key, count in topic_counts.most_common(8)]
    recent_completed_payload = [
        _event_read_payload(row, 0) for row in recent_completed
    ]
    return {"city": _city_payload(city, total, upcoming_count=upcoming_count,
            completed_count=completed_count, organization_count=len(organizations),
            recent_activity_count=int(await session.scalar(select(func.count(Event.id)).where(
                Event.city_id == city.id, Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
                Event.archived.is_(False), Event.updated_at >= utc_now_naive() - timedelta(days=30)
            )) or 0)),
        "items": items, "organizations": org_data, "recent_completed_events": recent_completed_payload,
        "popular_topics": popular_topics, "total": total, "limit": limit, "offset": offset}


@router.get("/discovery/topics")
async def discovery_topics():
    """Return the stable, public topic taxonomy; it contains no member data."""
    return {"items": [{"key": key, "name_en": en, "name_fa": fa} for key, en, fa in DISCOVERY_TOPICS], "total": len(DISCOVERY_TOPICS)}


@router.get("/me/follows")
async def read_my_follows(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    topic_keys = (await session.execute(select(UserTopicFollow.topic_key).where(
        UserTopicFollow.user_id == user.id).order_by(UserTopicFollow.topic_key))).scalars().all()
    organizations = (await session.execute(select(Organization).join(
        UserOrganizationFollow, UserOrganizationFollow.organization_id == Organization.id
    ).where(UserOrganizationFollow.user_id == user.id, Organization.status == "approved").order_by(Organization.name))).scalars().all()
    return {"topics": list(topic_keys), "organizations": [
        {"id": int(row.id), "slug": row.slug, "name": row.name, "logo_url": row.logo_url}
        for row in organizations
    ]}


@router.put("/me/follows/topics/{topic_key}")
async def follow_topic(topic_key: str, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    key = (topic_key or "").strip().lower()
    if key not in DISCOVERY_TOPIC_KEYS:
        raise HTTPException(status_code=404, detail={"code": "TOPIC_NOT_FOUND"})
    existing = await session.scalar(select(UserTopicFollow.id).where(
        UserTopicFollow.user_id == user.id, UserTopicFollow.topic_key == key))
    if existing is None:
        session.add(UserTopicFollow(user_id=user.id, topic_key=key))
        try:
            await session.commit()
        except IntegrityError:
            await session.rollback()  # A concurrent follow already created the unique row.
    return {"topic_key": key, "following": True}


@router.delete("/me/follows/topics/{topic_key}")
async def unfollow_topic(topic_key: str, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    key = (topic_key or "").strip().lower()
    if key not in DISCOVERY_TOPIC_KEYS:
        raise HTTPException(status_code=404, detail={"code": "TOPIC_NOT_FOUND"})
    await session.execute(delete(UserTopicFollow).where(
        UserTopicFollow.user_id == user.id, UserTopicFollow.topic_key == key))
    await session.commit()
    return {"topic_key": key, "following": False}


@router.put("/me/follows/organizations/{organization_id}")
async def follow_organization(organization_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    organization = await session.scalar(select(Organization).where(
        Organization.id == organization_id, Organization.status == "approved"))
    if organization is None:
        raise HTTPException(status_code=404, detail={"code": "ORGANIZATION_NOT_FOUND"})
    existing = await session.scalar(select(UserOrganizationFollow.id).where(
        UserOrganizationFollow.user_id == user.id, UserOrganizationFollow.organization_id == organization_id))
    if existing is None:
        session.add(UserOrganizationFollow(user_id=user.id, organization_id=organization_id))
        try:
            await session.commit()
        except IntegrityError:
            await session.rollback()
    return {"organization_id": organization_id, "following": True}


@router.delete("/me/follows/organizations/{organization_id}")
async def unfollow_organization(organization_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await session.execute(delete(UserOrganizationFollow).where(
        UserOrganizationFollow.user_id == user.id, UserOrganizationFollow.organization_id == organization_id))
    await session.commit()
    return {"organization_id": organization_id, "following": False}


@router.get("/me/discovery/preferences")
async def read_discovery_preferences(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    pref = await session.get(UserDiscoveryPreference, user.id)
    if pref is None:
        return {"preferred_city_id": None, "preferred_language": None, "preferred_format": None,
            "notify_followed_topics": False, "notify_followed_organizations": False,
            "notify_panel_changes": True, "notify_registration_reminders": True,
            "digest_frequency": "immediate", "quiet_hours_start": None, "quiet_hours_end": None}
    return {"preferred_city_id": pref.preferred_city_id, "preferred_language": pref.preferred_language,
        "preferred_format": pref.preferred_format, "notify_followed_topics": pref.notify_followed_topics,
        "notify_followed_organizations": pref.notify_followed_organizations,
        "notify_panel_changes": pref.notify_panel_changes,
        "notify_registration_reminders": pref.notify_registration_reminders,
        "digest_frequency": pref.digest_frequency, "quiet_hours_start": pref.quiet_hours_start,
        "quiet_hours_end": pref.quiet_hours_end}


@router.patch("/me/discovery/preferences")
async def update_discovery_preferences(payload: DiscoveryPreferencesInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if payload.preferred_city_id is not None:
        city_is_active = await session.scalar(select(City.id).where(
            City.id == payload.preferred_city_id, City.is_active.is_(True)))
        if city_is_active is None:
            raise HTTPException(status_code=422, detail={"code": "CITY_UNAVAILABLE"})
    pref = await session.get(UserDiscoveryPreference, user.id)
    if pref is None:
        pref = UserDiscoveryPreference(user_id=user.id)
        session.add(pref)
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(pref, key, value)
    await session.commit()
    return await read_discovery_preferences(user, session)


def _recommendation_score(event: Event, *, topic_keys: set[str], organization_ids: set[int],
                          city_id: int | None, language: str | None, event_format: str | None,
                          attended_organization_ids: set[int], saved_topic_keys: set[str],
                          used_seats: int = 0, now=None,
                          attended_organization_last_date: dict[int, date_type | None] | None = None,
                          saved_topic_last_at: dict[str, object] | None = None) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    event_topics = set(event.topic_tags or [])
    followed_matches = event_topics & topic_keys
    if followed_matches:
        score += 4 * min(len(followed_matches), 3)
        reasons.append("topic")
    saved_only_matches = (event_topics & saved_topic_keys) - topic_keys
    if saved_only_matches:
        # Saves are useful but weaker than explicit follows, and their value
        # decays with age: 3 points <=30d, 2 <=90d, 1 <=180d, then expires.
        if saved_topic_last_at is None or now is None:
            score += 4 * min(len(saved_only_matches), 3)  # legacy caller compatibility
            reasons.append("topic")
        else:
            saved_points = 0
            for topic_key in saved_only_matches:
                last_saved = saved_topic_last_at.get(topic_key)
                if last_saved is None:
                    continue
                saved_dt = to_tehran(last_saved).date() if hasattr(last_saved, "tzinfo") else last_saved
                age_days = max(0, (tehran_today() - saved_dt).days)
                saved_points += 3 if age_days <= 30 else 2 if age_days <= 90 else 1 if age_days <= 180 else 0
            if saved_points:
                score += min(saved_points, 6)
                reasons.append("saved_interest")
    if event.organization_id and int(event.organization_id) in organization_ids:
        score += 7
        reasons.append("organization")
    if city_id and event.city_id == city_id:
        score += 3
        reasons.append("city")
    if language and event.language and event.language.casefold() == language.casefold():
        score += 2
        reasons.append("language")
    if event_format and event.event_type == event_format:
        score += 1
        reasons.append("format")
    if event.organization_id and int(event.organization_id) in attended_organization_ids:
        if attended_organization_last_date is None or now is None:
            attendance_points = 2  # preserve existing helper callers
        else:
            last_attended = attended_organization_last_date.get(int(event.organization_id))
            age_days = max(0, (tehran_today() - last_attended).days) if last_attended else 10_000
            attendance_points = 2 if age_days <= 30 else 1 if age_days <= 180 else 0
        if attendance_points:
            score += attendance_points
            reasons.append("attendance")
    # Recency is bounded and never overwhelms a direct topic/organization match.
    last_updated = getattr(event, "updated_at", None) or getattr(event, "created_at", None)
    if now is not None and last_updated is not None:
        age_days = max(0, (now - last_updated).total_seconds() / 86400)
        if age_days <= 7:
            score += 2
            reasons.append("recent")
        elif age_days <= 30:
            score += 1
            reasons.append("recent")
    remaining = max(0, int(event.capacity or 0) - int(used_seats or 0))
    if registration_is_open(event) and remaining > 0:
        score += 2
        reasons.append("available")
    return score, reasons


@router.get("/me/recommendations")
async def recommended_for_me(limit: int = Query(default=8, ge=1, le=20), user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    from collections import Counter
    now = utc_now_naive()
    follows = await read_my_follows(user, session)
    topic_keys = set(follows["topics"])
    organization_ids = {int(row["id"]) for row in follows["organizations"]}
    pref = await session.get(UserDiscoveryPreference, user.id)
    city_id = int(pref.preferred_city_id) if pref and pref.preferred_city_id else None
    language = pref.preferred_language if pref else None
    event_format = pref.preferred_format if pref else None
    attendance_rows = (await session.execute(select(
        Event.organization_id, func.max(Event.event_date_iso)
    ).join(Booking, Booking.event_id == Event.id).join(
        Participant, Participant.booking_id == Booking.id
    ).where(
        Booking.booked_by_user_id == user.id, Booking.status == RegistrationStatus.CONFIRMED,
        Participant.user_telegram_id == user.telegram_id,
        Participant.attendance_status == AttendanceStatus.ATTENDED,
        Event.organization_id.is_not(None), Event.event_date_iso.is_not(None),
        Event.event_date_iso <= tehran_today(),
    ).group_by(Event.organization_id))).all()
    attended_org_last_date = {int(org_id): attended_date for org_id, attended_date in attendance_rows if org_id and attended_date}
    attended_orgs = set(attended_org_last_date)
    saved_rows = (await session.execute(select(
        Event.topic_tags, WebsiteSavedEvent.created_at
    ).join(WebsiteSavedEvent, WebsiteSavedEvent.event_id == Event.id).where(
        WebsiteSavedEvent.user_id == user.id
    ))).all()
    saved_topic_last_at: dict[str, object] = {}
    for tags, saved_at in saved_rows:
        for topic_key in tags or []:
            current_saved_at = saved_topic_last_at.get(str(topic_key))
            if current_saved_at is None or (saved_at is not None and saved_at > current_saved_at):
                saved_topic_last_at[str(topic_key)] = saved_at
    saved_topic_keys = set(saved_topic_last_at)
    suppressed_ids = set((await session.execute(select(RecommendationFeedback.event_id).where(
        RecommendationFeedback.user_id == user.id,
        RecommendationFeedback.feedback == "not_interested",
    ))).scalars().all())
    events = (await session.execute(select(Event).where(
        Event.status == EventStatus.PUBLISHED, Event.archived.is_(False),
        Event.registration_open.is_(True), Event.is_postponed.is_(False),
        Event.id.not_in(suppressed_ids) if suppressed_ids else text("1=1"),
        Event.city_id.in_(select(City.id).where(City.is_active.is_(True)))
    ).order_by(Event.event_date_iso.asc().nullslast(), Event.id.desc()).limit(250))).scalars().all()
    event_ids = [int(row.id) for row in events]
    usage_rows = (await session.execute(select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_(event_ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES))
        .group_by(Booking.event_id))).all() if event_ids else []
    usage = {int(event_id): int(count) for event_id, count in usage_rows}
    ranked = []
    for event in events:
        score, reasons = _recommendation_score(event, topic_keys=topic_keys,
            organization_ids=organization_ids, city_id=city_id, language=language,
            event_format=event_format, attended_organization_ids={int(v) for v in attended_orgs if v},
            saved_topic_keys=saved_topic_keys, used_seats=usage.get(int(event.id), 0), now=now,
            attended_organization_last_date=attended_org_last_date,
            saved_topic_last_at=saved_topic_last_at)
        if score <= 0:
            continue
        ranked.append((score, event, reasons))
    ranked.sort(key=lambda item: (-item[0], item[1].event_date_iso or date_type.max, -int(item[1].id)))
    # Keep recommendations varied: at most two events per organization when
    # alternatives exist, while preserving score order and backfilling the list.
    selected = []
    overflow = []
    organization_counts = Counter()
    for item in ranked:
        organization_id = int(item[1].organization_id or 0)
        if organization_id and organization_counts[organization_id] >= 2:
            overflow.append(item)
            continue
        selected.append(item)
        if organization_id:
            organization_counts[organization_id] += 1
        if len(selected) >= limit:
            break
    if len(selected) < limit:
        selected.extend(overflow[:limit-len(selected)])
    reason_labels = {"topic": "Because you follow a topic", "organization": "From an organization you follow",
        "city": "In your preferred city", "language": "In your preferred language",
        "format": "Matches your preferred format", "attendance": "Similar to an organization you attended",
        "recent": "Recently updated", "available": "Registration is open"}
    items = []
    for score, event, reasons in selected:
        payload = _event_read_payload(event, usage.get(int(event.id), 0))
        payload["recommendation_score"] = int(score)
        payload["recommendation_reasons"] = [reason_labels[key] for key in reasons]
        items.append(payload)
    return {"items": items, "total": len(items)}


@router.put("/me/recommendations/{event_id}/feedback")
async def suppress_recommendation(event_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    event = await session.scalar(select(Event.id).where(Event.id == event_id,
        Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)))
    if event is None:
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    row = await session.scalar(select(RecommendationFeedback).where(
        RecommendationFeedback.user_id == user.id, RecommendationFeedback.event_id == event_id))
    if row is None:
        session.add(RecommendationFeedback(user_id=user.id, event_id=event_id, feedback="not_interested"))
    await session.commit()
    return {"event_id": event_id, "feedback": "not_interested"}


@router.delete("/me/recommendations/{event_id}/feedback")
async def restore_recommendation(event_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    await session.execute(delete(RecommendationFeedback).where(
        RecommendationFeedback.user_id == user.id, RecommendationFeedback.event_id == event_id))
    await session.commit()
    return {"event_id": event_id, "feedback": None}


@router.get("/events/{event_id}/related")
async def related_public_events(event_id: int, limit: int = Query(default=3, ge=1, le=6), session: AsyncSession = Depends(get_session)):
    current = await session.scalar(select(Event).where(Event.id == event_id,
        Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]), Event.archived.is_(False)))
    if current is None:
        raise HTTPException(status_code=404, detail={"code": "EVENT_NOT_FOUND"})
    candidates = (await session.execute(select(Event).where(
        Event.id != event_id, Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]), Event.archived.is_(False),
        Event.city_id.in_(select(City.id).where(City.is_active.is_(True)))
    ).order_by(Event.event_date_iso.asc().nullslast(), Event.id.desc()).limit(150))).scalars().all()
    current_topics = set(current.topic_tags or [])
    ranked = []
    for event in candidates:
        shared = current_topics & set(event.topic_tags or [])
        score = 5 * len(shared) + (3 if current.organization_id and current.organization_id == event.organization_id else 0) + (1 if current.city_id and current.city_id == event.city_id else 0)
        if score:
            ranked.append((score, event))
    ranked.sort(key=lambda pair: (-pair[0], pair[1].event_date_iso or date_type.max, -int(pair[1].id)))
    selected = [event for _, event in ranked[:limit]]
    ids = [int(row.id) for row in selected]
    usage_rows = (await session.execute(select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_(ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES)).group_by(Booking.event_id))).all() if ids else []
    usage = {int(event_id): int(count) for event_id, count in usage_rows}
    return {"items": [_event_read_payload(row, usage.get(int(row.id), 0)) for row in selected], "total": len(selected)}


@router.get("/seo/robots.txt", include_in_schema=False)
async def seo_robots(request: Request):
    origin = (settings.panel_flow_website_url or "").strip().rstrip("/")
    if not origin:
        scheme = (request.headers.get("x-forwarded-proto") or request.url.scheme).split(",")[0].strip()
        host = (request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc).split(",")[0].strip()
        origin = f"{scheme}://{host}"
    body = "\n".join([
        "User-agent: *", "Allow: /", "Disallow: /workspace", "Disallow: /me",
        "Disallow: /my-bookings", "Disallow: /my-organizations", "Disallow: /become-a-host",
        "Disallow: /host-application", "Disallow: /saved", "Disallow: /sign-in", "Disallow: /api/",
        f"Sitemap: {origin}/sitemap.xml", "",
    ])
    return Response(body, media_type="text/plain; charset=utf-8", headers={"Cache-Control": "public, max-age=300"})


@router.get("/seo/sitemap.xml", include_in_schema=False)
async def seo_sitemap(request: Request, session: AsyncSession = Depends(get_session)):
    from xml.sax.saxutils import escape
    origin = (settings.panel_flow_website_url or "").strip().rstrip("/")
    if not origin:
        scheme = (request.headers.get("x-forwarded-proto") or request.url.scheme).split(",")[0].strip()
        host = (request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc).split(",")[0].strip()
        origin = f"{scheme}://{host}"
    entries: list[tuple[str, str | None]] = [
        ("/", None), ("/events", None), ("/cities", None), ("/calendar", None),
        ("/community", None), ("/about", None),
    ]
    # Every administrator-enabled city has a public directory page, even before
    # its first panel is published.
    city_rows = (await session.execute(select(City.slug).where(
        City.is_active.is_(True)).order_by(City.slug))).scalars().all()
    entries.extend((f"/cities/{slug}", None) for slug in city_rows)
    organization_rows = (await session.execute(select(Organization.slug).where(Organization.status == "approved").order_by(Organization.slug))).scalars().all()
    entries.extend((f"/organizations/{slug}", None) for slug in organization_rows)
    brand_rows = (await session.execute(select(Organization.slug, Brand.slug).join(Brand, Brand.organization_id == Organization.id).where(
        Organization.status == "approved", Brand.status == "approved").order_by(Organization.slug, Brand.slug))).all()
    entries.extend((f"/organizations/{org_slug}/brands/{brand_slug}", None) for org_slug, brand_slug in brand_rows)
    host_rows = (await session.execute(select(HostPublicProfile.slug).where(
        HostPublicProfile.is_active.is_(True)).order_by(HostPublicProfile.slug))).scalars().all()
    entries.extend((f"/hosts/{slug}", None) for slug in host_rows)
    series_rows = (await session.execute(
        select(DiscussionSeries.slug)
        .join(DiscussionSeriesEvent, DiscussionSeriesEvent.series_id == DiscussionSeries.id)
        .join(Event, Event.id == DiscussionSeriesEvent.event_id)
        .where(DiscussionSeries.status == "published", Event.archived.is_(False),
               Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED)))
        .group_by(DiscussionSeries.id, DiscussionSeries.slug)
        .having(func.count(Event.id) >= 2)
        .order_by(DiscussionSeries.slug)
    )).scalars().all()
    entries.extend((f"/series/{slug}", None) for slug in series_rows)
    event_rows = (await session.execute(select(Event.id, Event.updated_at).join(City, City.id == Event.city_id).where(
        City.is_active.is_(True), Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]), Event.archived.is_(False)
    ).order_by(Event.id))).all()
    entries.extend((f"/events/{event_id}", updated.isoformat() if updated else None) for event_id, updated in event_rows)
    urls = []
    for path, lastmod in entries:
        urls.append(f"<url><loc>{escape(origin + path)}</loc>{f'<lastmod>{escape(lastmod)}</lastmod>' if lastmod else ''}</url>")
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + ''.join(urls) + '</urlset>'
    return Response(xml, media_type="application/xml", headers={"Cache-Control": "public, max-age=300"})


@router.get("/seo/validate", include_in_schema=False)
async def seo_validate(request: Request, session: AsyncSession = Depends(get_session)):
    from urllib.parse import urlsplit
    import re
    path = urlsplit(request.headers.get("x-original-uri", "")).path
    event_match = re.fullmatch(r"/events/([1-9][0-9]*)/?", path)
    city_match = re.fullmatch(r"/cities/([a-z0-9]+(?:-[a-z0-9]+)*)/?", path)
    brand_match = re.fullmatch(r"/organizations/([a-z0-9]+(?:-[a-z0-9]+)*)/brands/([a-z0-9]+(?:-[a-z0-9]+)*)/?", path)
    organization_match = re.fullmatch(r"/organizations/([a-z0-9]+(?:-[a-z0-9]+)*)/?", path)
    host_match = re.fullmatch(r"/hosts/([a-z0-9]+(?:-[a-z0-9]+)*)/?", path)
    if event_match:
        exists = await session.scalar(select(Event.id).join(City, City.id == Event.city_id).where(
            Event.id == int(event_match.group(1)), Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
            Event.archived.is_(False), City.is_active.is_(True)))
        if exists is None:
            raise HTTPException(status_code=403, detail="Not found")
    elif city_match:
        exists = await session.scalar(select(City.id).where(City.slug == city_match.group(1), City.is_active.is_(True)))
        if exists is None:
            raise HTTPException(status_code=403, detail="Not found")
    elif brand_match:
        exists = await session.scalar(select(Brand.id).join(Organization, Organization.id == Brand.organization_id).where(
            Organization.slug == brand_match.group(1), Organization.status == "approved",
            Brand.slug == brand_match.group(2), Brand.status == "approved"))
        if exists is None:
            raise HTTPException(status_code=403, detail="Not found")
    elif organization_match:
        exists = await session.scalar(select(Organization.id).where(
            Organization.slug == organization_match.group(1), Organization.status == "approved"))
        if exists is None:
            raise HTTPException(status_code=403, detail="Not found")
    elif host_match:
        exists = await session.scalar(select(HostPublicProfile.id).where(
            HostPublicProfile.slug == host_match.group(1), HostPublicProfile.is_active.is_(True)))
        if exists is None:
            raise HTTPException(status_code=403, detail="Not found")
    else:
        raise HTTPException(status_code=403, detail="Not found")
    return {"ok": True}


@router.get("/events/{event_id}")
async def get_public_event(event_id: int, session: AsyncSession = Depends(get_session)):
    event = (await session.execute(select(Event).where(
        Event.id == event_id, Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]), Event.archived.is_(False),
        Event.city_id.in_(select(City.id).where(City.is_active.is_(True)))
    ))).scalar_one_or_none()
    if event is None:
        raise HTTPException(status_code=404, detail={"code": "EVENT_NOT_FOUND", "message": "این پنل پیدا نشد یا دیگر منتشرشده نیست."})
    used = await seats_used(session, event_id)
    payload = _event_read_payload(event, used)
    series_row = (await session.execute(
        select(DiscussionSeries, DiscussionSeriesEvent.position)
        .join(DiscussionSeriesEvent, DiscussionSeriesEvent.series_id == DiscussionSeries.id)
        .where(DiscussionSeriesEvent.event_id == event.id, DiscussionSeries.status == "published")
        .order_by(DiscussionSeriesEvent.position).limit(1)
    )).first()
    if series_row:
        series, position = series_row
        payload["discussion_series"] = {"id": int(series.id), "slug": series.slug, "title": series.title,
                                         "position": int(position)}
    if event.organization_id:
        organization = await session.get(Organization, event.organization_id)
        if organization and organization.status == "approved":
            payload["organization"] = {"id": organization.id, "slug": organization.slug, "name": organization.name,
                "is_platform_founder": organization.is_platform_founder}
    if event.brand_id:
        brand = await session.get(Brand, event.brand_id)
        if brand and brand.status == "approved":
            payload["brand"] = {"id": brand.id, "slug": brand.slug, "name": brand.name}
    return payload


@router.get("/community/overview")
async def public_community_overview(session: AsyncSession = Depends(get_session)):
    challenges = (await session.execute(select(CommunityChallenge).where(
        CommunityChallenge.status == "open", CommunityChallenge.cleared_at.is_(None)
    ).order_by(CommunityChallenge.published_sequence.desc().nullslast(), CommunityChallenge.id.desc()).limit(6))).scalars().all()
    try:
        leaderboard = await leaderboard_rows(session, limit=10)
    except Exception:
        logger.exception("Public leaderboard could not be loaded")
        leaderboard = []
    return {
        "leaderboard": leaderboard,
        "challenges": [{"id": c.id, "title": c.title, "prompt": c.prompt, "type": c.challenge_type,
                        "created_at": c.created_at} for c in challenges],
    }


@router.get("/me/overview")
async def read_my_overview(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    stats = await user_community_stats(session, user.telegram_id)
    offers = []
    if await shop_is_enabled(session):
        for offer in await list_shop_offers(session, active_only=True):
            if await shop_offer_available(session, offer):
                offers.append({"id": offer.id, "title": offer.title, "description": offer.description,
                               "discount_percent": offer.discount_percent, "xp_cost": offer.xp_cost,
                               "usage_limit": offer.usage_limit, "expires_at": offer.expires_at,
                               "revision": int(getattr(offer, "revision", 1) or 1)})
    recent_xp = (await session.execute(select(XPAward).where(XPAward.telegram_id == user.telegram_id)
        .order_by(XPAward.created_at.desc(), XPAward.id.desc()).limit(12))).scalars().all()
    reserved = await reserved_shop_xp(session, user.telegram_id)
    shop_history = (await session.execute(select(ShopRequest).where(
        ShopRequest.telegram_id == user.telegram_id
    ).order_by(ShopRequest.created_at.desc(), ShopRequest.id.desc()).limit(10))).scalars().all()
    issue_ids = [int(row.id) for row in shop_history]
    issue_rows = (await session.execute(select(RewardIssue).where(
        RewardIssue.source_type == "shop", RewardIssue.source_id.in_(issue_ids)
    ))).scalars().all() if issue_ids else []
    issue_by_request = {int(row.source_id): row for row in issue_rows}
    from app.services.referrals import count_referrals_for_telegram_id
    referral_count = await count_referrals_for_telegram_id(session, user.telegram_id)
    return {
        "profile": {"id": user.id, "display_name": user.display_name, "first_name": user.first_name,
                    "last_name": user.last_name, "username": user.telegram_username, "phone_number": user.phone_number,
                    "role": _role(user), "created_at": user.created_at},
        "stats": {k: v for k, v in stats.items() if k != "badges"},
        "badges": [{"key": b.achievement_key, "title": b.title, "unlocked_at": b.unlocked_at} for b in stats.get("badges", [])],
        "referral_code": str(user.telegram_id), "reserved_shop_xp": reserved,
        "available_shop_xp": max(0, int(stats["xp"]) - reserved),
        "recent_xp": [{"points": a.points, "type": a.award_type, "note": a.note, "created_at": a.created_at} for a in recent_xp],
        "shop_offers": offers,
        "shop_enabled": await shop_is_enabled(session),
        "shop_history": [{"id": row.id, "title": row.offer_title_snapshot or f"تخفیف {row.discount_percent}٪",
                          "discount_percent": row.discount_percent, "xp_cost": row.xp_cost,
                          "status": row.status,
                          "status_label": shop_request_status_label(row.status, issue_by_request.get(int(row.id)).status if issue_by_request.get(int(row.id)) else None),
                          "created_at": row.created_at} for row in shop_history],
        "referral_count": referral_count,
    }


@router.post("/me/shop/requests")
async def create_website_shop_request(payload: ShopRequestInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    locked_user = (await session.execute(select(User).where(User.id == user.id).with_for_update())).scalar_one_or_none()
    if locked_user is None:
        raise HTTPException(status_code=404, detail={"code": "USER_NOT_FOUND"})
    if not await shop_is_enabled(session):
        raise HTTPException(status_code=409, detail={"code": "SHOP_DISABLED", "message": "فروشگاه امتیاز در حال حاضر غیرفعال است."})
    offer = (await session.execute(select(XPShopOffer).where(XPShopOffer.id == payload.offer_id).with_for_update())).scalar_one_or_none()
    if offer is None or not offer.active or not await shop_offer_available(session, offer):
        raise HTTPException(status_code=409, detail={"code": "OFFER_UNAVAILABLE", "message": "این پیشنهاد دیگر در دسترس نیست."})
    if int(getattr(offer, "revision", 1) or 1) != payload.expected_revision:
        raise HTTPException(status_code=409, detail={"code": "OFFER_CHANGED", "message": "شرایط پیشنهاد تغییر کرده است؛ صفحه را تازه کنید."})
    balance = await user_community_stats(session, user.telegram_id)
    reserved = await reserved_shop_xp(session, user.telegram_id)
    cost = int(offer.xp_cost)
    if available_shop_xp(int(balance.get("xp", 0)), reserved) < cost:
        raise HTTPException(status_code=409, detail={"code": "INSUFFICIENT_XP", "message": "امتیاز قابل استفاده برای این درخواست کافی نیست."})
    row = ShopRequest(telegram_id=int(user.telegram_id), offer_id=int(offer.id),
        offer_title_snapshot=str(offer.title)[:120], offer_description_snapshot=str(offer.description or "")[:2000] or None,
        discount_percent=int(offer.discount_percent), xp_cost=cost, status="pending")
    session.add(row)
    try:
        await session.commit()
    except IntegrityError as exc:
        await session.rollback()
        raise HTTPException(status_code=409, detail={"code": "SHOP_REQUEST_CONFLICT", "message": "درخواست به‌دلیل هم‌زمانی ثبت نشد؛ دوباره تلاش کنید."}) from exc
    return {"id": row.id, "status": row.status, "xp_reserved": cost, "message": "درخواست ثبت شد؛ XP تا زمان بررسی مدیر رزرو می‌شود."}


@router.post("/me/shop/requests/{request_id}/cancel")
async def cancel_website_shop_request(request_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    row = (await session.execute(select(ShopRequest).where(
        ShopRequest.id == request_id, ShopRequest.telegram_id == user.telegram_id
    ).with_for_update())).scalar_one_or_none()
    if row is None or row.status != "pending":
        raise HTTPException(status_code=409, detail={"code": "SHOP_REQUEST_NOT_CANCELLABLE", "message": "این درخواست دیگر قابل لغو نیست."})
    row.status = "cancelled"
    row.updated_at = utc_now_naive()
    await session.commit()
    return {"id": row.id, "status": row.status}


@router.get("/me/waitlist")
async def list_my_waitlist(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(WaitlistEntry, Event).join(Event, Event.id == WaitlistEntry.event_id).where(
        WaitlistEntry.user_id == user.id, WaitlistEntry.status.in_(("waiting", "invited", "inviting"))
    ).order_by(WaitlistEntry.created_at.desc(), WaitlistEntry.id.desc()))).all()
    items = []
    for entry, event in rows:
        rank = int(await session.scalar(select(func.count(WaitlistEntry.id)).where(
            WaitlistEntry.event_id == event.id, WaitlistEntry.status.in_(("waiting", "invited", "inviting")),
            or_(
                WaitlistEntry.position < entry.position,
                and_(WaitlistEntry.position == entry.position, WaitlistEntry.created_at < entry.created_at),
                and_(WaitlistEntry.position == entry.position, WaitlistEntry.created_at == entry.created_at, WaitlistEntry.id <= entry.id),
            )
        )) or 1)
        items.append({"id": entry.id, "event_id": event.id, "event_title": event.title,
            "event_date": event.event_date_label, "requested_participant_count": entry.requested_participant_count,
            "status": entry.status, "position": rank, "invitation_expires_at": entry.invitation_expires_at})
    return {"items": items, "total": len(items)}


@router.post("/events/{event_id}/waitlist")
async def join_event_waitlist(event_id: int, payload: WaitlistJoinInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
    if event is None or event.archived or event.status != EventStatus.PUBLISHED or bool(getattr(event, "is_postponed", False)) or not event.waitlist_enabled:
        raise HTTPException(status_code=409, detail={"code": "WAITLIST_UNAVAILABLE", "message": "فهرست انتظار این پنل در دسترس نیست."})
    used = await seats_used(session, event.id)
    if not waitlist_is_available(event, used):
        raise HTTPException(status_code=409, detail={"code": "WAITLIST_NOT_NEEDED", "message": "ظرفیت خالی شده است؛ از مسیر ثبت‌نام اقدام کنید."})
    if payload.participant_count > int(event.capacity):
        raise HTTPException(status_code=422, detail={"code": "WAITLIST_COUNT_EXCEEDS_CAPACITY", "message": f"تعداد نفرات نمی‌تواند از ظرفیت کل پنل ({int(event.capacity)}) بیشتر باشد."})
    duplicate = (await session.execute(select(WaitlistEntry).where(
        WaitlistEntry.event_id == event.id, WaitlistEntry.user_id == user.id,
        WaitlistEntry.status.in_(("waiting", "invited", "inviting"))
    ))).scalar_one_or_none()
    if duplicate:
        raise HTTPException(status_code=409, detail={"code": "WAITLIST_DUPLICATE", "message": "شما قبلاً در فهرست انتظار این پنل هستید."})
    active = int(await session.scalar(select(func.count(WaitlistEntry.id)).where(
        WaitlistEntry.event_id == event.id, WaitlistEntry.status.in_(("waiting", "invited", "inviting"))
    )) or 0)
    max_position = int(await session.scalar(select(func.coalesce(func.max(WaitlistEntry.position), 0)).where(
        WaitlistEntry.event_id == event.id, WaitlistEntry.status.in_(("waiting", "invited", "inviting"))
    )) or 0)
    row = WaitlistEntry(event_id=event.id, user_id=user.id,
        requested_participant_count=payload.participant_count, position=max_position + 1)
    session.add(row)
    try:
        await session.commit()
    except IntegrityError as exc:
        await session.rollback()
        raise HTTPException(status_code=409, detail={"code": "WAITLIST_DUPLICATE", "message": "شما قبلاً در فهرست انتظار این پنل هستید."}) from exc
    return {"id": row.id, "status": row.status, "position": active + 1,
            "message": "درخواست شما در فهرست انتظار ثبت شد؛ این درخواست رزرو قطعی نیست."}


@router.delete("/me/waitlist/{entry_id}")
async def leave_website_waitlist(entry_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    row = (await session.execute(select(WaitlistEntry).where(
        WaitlistEntry.id == entry_id, WaitlistEntry.user_id == user.id,
        WaitlistEntry.status.in_(("waiting", "invited"))
    ).with_for_update())).scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=409, detail={"code": "WAITLIST_NOT_CANCELLABLE", "message": "این درخواست دیگر قابل لغو نیست."})
    row.status = "cancelled"
    row.invitation_expires_at = None
    await session.commit()
    return {"id": row.id, "status": row.status}


@router.get("/me/attendance")
async def my_verified_attendance(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    """Return only participants marked attended on the member's own confirmed bookings."""
    rows = (await session.execute(
        select(Participant, Booking, Event)
        .join(Booking, Booking.id == Participant.booking_id)
        .join(Event, Event.id == Booking.event_id)
        .where(Booking.booked_by_user_id == user.id, Booking.status == RegistrationStatus.CONFIRMED,
               Participant.attendance_status == AttendanceStatus.ATTENDED)
        .order_by(Event.event_date_iso.desc().nullslast(), Event.id.desc(), Participant.id.asc())
        .limit(500)
    )).all()
    grouped: dict[int, dict] = {}
    for participant, booking, event in rows:
        item = grouped.setdefault(int(event.id), {
            "event_id": int(event.id), "event_title": event.title,
            "event_date": event.event_date_label, "date_iso": event.event_date_iso.isoformat() if event.event_date_iso else None,
            "city": event.city, "venue": event.venue, "participants": [],
        })
        item["participants"].append({"participant_id": int(participant.id), "name": participant.full_name})
    return {"items": list(grouped.values()), "total_events": len(grouped),
            "total_attended": sum(len(item["participants"]) for item in grouped.values())}


@router.patch("/me/profile")
async def update_my_profile(payload: ProfileUpdateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    user.display_name = payload.display_name.strip()
    await session.commit()
    await session.refresh(user)
    return {"id": user.id, "display_name": user.display_name, "first_name": user.first_name,
            "last_name": user.last_name, "username": user.telegram_username, "role": _role(user)}


@router.post("/me/recent-events/{event_id}")
async def record_recent_event_view(event_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    """Record a private view of a genuinely public panel for this member only."""
    event_exists = await session.scalar(select(Event.id).join(City, City.id == Event.city_id).where(
        Event.id == event_id, Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
        Event.archived.is_(False), City.is_active.is_(True)))
    if event_exists is None:
        raise HTTPException(status_code=404, detail={"code": "EVENT_NOT_FOUND"})
    row = (await session.execute(select(WebsiteRecentEventView).where(
        WebsiteRecentEventView.user_id == user.id, WebsiteRecentEventView.event_id == event_id
    ).with_for_update())).scalar_one_or_none()
    now = utc_now_naive()
    if row is None:
        row = WebsiteRecentEventView(user_id=user.id, event_id=event_id, view_count=1, last_viewed_at=now)
        session.add(row)
    else:
        row.view_count = min(int(row.view_count or 0) + 1, 2_147_483_647)
        row.last_viewed_at = now
    try:
        await session.flush()
    except IntegrityError:
        await session.rollback()
        row = (await session.execute(select(WebsiteRecentEventView).where(
            WebsiteRecentEventView.user_id == user.id, WebsiteRecentEventView.event_id == event_id
        ).with_for_update())).scalar_one_or_none()
        if row is None:
            raise
        row.view_count = min(int(row.view_count or 0) + 1, 2_147_483_647)
        row.last_viewed_at = now
    # Keep only the most recent 30 panel records for each member.
    keep_ids = select(WebsiteRecentEventView.id).where(
        WebsiteRecentEventView.user_id == user.id
    ).order_by(WebsiteRecentEventView.last_viewed_at.desc(), WebsiteRecentEventView.id.desc()).limit(30)
    await session.execute(delete(WebsiteRecentEventView).where(
        WebsiteRecentEventView.user_id == user.id, WebsiteRecentEventView.id.not_in(keep_ids)
    ))
    await session.commit()
    return {"recorded": True, "event_id": event_id}


@router.get("/me/activity")
async def read_my_activity(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    """Compact, private activity dashboard payload with bounded, grouped queries."""
    today = tehran_today()
    upcoming_rows = (await session.execute(select(Booking, Event).join(Event, Event.id == Booking.event_id).where(
        Booking.booked_by_user_id == user.id,
        Booking.status.in_(ACTIVE_BOOKING_STATUSES), Event.status == EventStatus.PUBLISHED,
        Event.archived.is_(False), Event.is_postponed.is_(False), Event.event_date_iso >= today,
    ).order_by(Event.event_date_iso.asc(), Event.start_time_label.asc(), Booking.id.desc()).limit(12))).all()
    upcoming = [_booking_payload(booking, event) for booking, event in upcoming_rows]

    saved_rows = (await session.execute(select(Event).join(WebsiteSavedEvent, WebsiteSavedEvent.event_id == Event.id).where(
        WebsiteSavedEvent.user_id == user.id, Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
    ).order_by(WebsiteSavedEvent.created_at.desc()).limit(6))).scalars().all()
    saved = [_event_read_payload(event, 0) for event in saved_rows]

    recent_rows = (await session.execute(select(Event, WebsiteRecentEventView).join(
        WebsiteRecentEventView, WebsiteRecentEventView.event_id == Event.id
    ).join(City, City.id == Event.city_id).where(
        WebsiteRecentEventView.user_id == user.id, Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
        Event.archived.is_(False), City.is_active.is_(True)
    ).order_by(WebsiteRecentEventView.last_viewed_at.desc(), WebsiteRecentEventView.id.desc()).limit(8))).all()
    recent = [{**_event_read_payload(event, 0), "last_viewed_at": view.last_viewed_at,
               "view_count": int(view.view_count or 1)} for event, view in recent_rows]

    followed_topics = list((await session.execute(select(UserTopicFollow.topic_key).where(
        UserTopicFollow.user_id == user.id
    ).order_by(UserTopicFollow.topic_key))).scalars().all())
    followed_orgs = (await session.execute(select(Organization.id, Organization.slug, Organization.name).join(
        UserOrganizationFollow, UserOrganizationFollow.organization_id == Organization.id
    ).where(UserOrganizationFollow.user_id == user.id, Organization.status == "approved").order_by(Organization.name))).all()
    return {
        "upcoming_bookings": upcoming,
        "saved_panels": saved,
        "recently_viewed": recent,
        "followed_topics": followed_topics,
        "followed_organizations": [{"id": int(row.id), "slug": row.slug, "name": row.name} for row in followed_orgs],
        "counts": {"upcoming_bookings": len(upcoming), "saved_panels": len(saved),
                   "recently_viewed": len(recent), "followed_topics": len(followed_topics),
                   "followed_organizations": len(followed_orgs)},
    }


@router.get("/me/saved-events")
async def list_my_saved_events(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(Event).join(WebsiteSavedEvent, WebsiteSavedEvent.event_id == Event.id)
        .where(WebsiteSavedEvent.user_id == user.id, Event.status == EventStatus.PUBLISHED, Event.archived.is_(False))
        .order_by(WebsiteSavedEvent.created_at.desc()))).scalars().all()
    event_ids = [int(event.id) for event in rows]
    usage_rows = (await session.execute(
        select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_(event_ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES))
        .group_by(Booking.event_id)
    )).all() if event_ids else []
    usage_by_event = {int(event_id): int(count or 0) for event_id, count in usage_rows}
    result = [_event_read_payload(event, usage_by_event.get(int(event.id), 0)) for event in rows]
    return {"items": result, "total": len(result)}


@router.put("/me/saved-events/{event_id}")
async def save_event(event_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    event = (await session.execute(select(Event).where(Event.id == event_id, Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)))).scalar_one_or_none()
    if event is None:
        raise HTTPException(status_code=404, detail={"code": "EVENT_NOT_FOUND"})
    existing = (await session.execute(select(WebsiteSavedEvent).where(WebsiteSavedEvent.user_id == user.id, WebsiteSavedEvent.event_id == event_id))).scalar_one_or_none()
    if existing is None:
        session.add(WebsiteSavedEvent(user_id=user.id, event_id=event_id))
        await session.commit()
    return {"saved": True, "event_id": event_id}


@router.delete("/me/saved-events/{event_id}")
async def unsave_event(event_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    saved = (await session.execute(select(WebsiteSavedEvent).where(WebsiteSavedEvent.user_id == user.id, WebsiteSavedEvent.event_id == event_id))).scalar_one_or_none()
    if saved is not None:
        await session.delete(saved)
        await session.commit()
    return {"saved": False, "event_id": event_id}


@router.post("/bookings")
async def create_website_booking(payload: BookingCreateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    event = await session.get(Event, payload.event_id)
    if event is None:
        raise HTTPException(status_code=404, detail={"code": "EVENT_NOT_FOUND"})
    bot_settings = await get_bot_settings(session)
    card = str(bot_settings.get("payment_card_number") or settings.payment_card_number or "").strip()
    account_name = str(bot_settings.get("payment_account_name") or settings.payment_account_name or "").strip()
    discount = None
    if payload.discount_code:
        try:
            discount = await validate_code_for_user(session, raw_code=payload.discount_code,
                telegram_id=user.telegram_id, event_id=payload.event_id)
        except ValueError as exc:
            _raise_service_error(exc)
    try:
        booking = await create_booking(
            session, user.id, payload.event_id,
            [p.model_dump() for p in payload.participants],
            contact_phone=payload.contact_phone,
            discount_code_id=int(discount.id) if discount else None,
            pricing_option=payload.pricing_option,
            expected_base_price=event.price_per_person,
            expected_alternative_price=event.price_without_cafe_order,
            payment_details_configured=bool(card and account_name),
            client_request_id=payload.idempotency_key,
        )
    except ValueError as exc:
        _raise_service_error(exc)
    if Decimal(str(booking.total_amount or 0)) > 0:
        payment = (await session.execute(select(Payment).where(Payment.booking_id == booking.id))).scalar_one_or_none()
        if payment is None:
            session.add(Payment(booking_id=booking.id, amount=booking.total_amount, status=PaymentStatus.PENDING))
            await session.commit()
    await session.refresh(booking)
    return {"booking": _booking_payload(booking, event),
            "payment_instructions": ({"card_number": card, "account_name": account_name} if int(booking.total_amount or 0) > 0 else None),
            "reservation_timeout_minutes": settings.reservation_timeout_minutes}


@router.get("/bookings/{booking_id}/payment-instructions")
async def get_booking_payment_instructions(booking_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    booking = await session.get(Booking, booking_id)
    if booking is None or booking.booked_by_user_id != user.id:
        raise HTTPException(status_code=404, detail={"code": "BOOKING_NOT_FOUND"})
    if booking.status != RegistrationStatus.PENDING_PAYMENT:
        raise HTTPException(status_code=409, detail={"code": "BOOKING_NOT_PAYABLE", "message": "این رزرو در حال حاضر در انتظار پرداخت نیست."})
    if expire_booking_if_due(booking):
        await session.commit()
        raise HTTPException(status_code=409, detail={"code": "BOOKING_EXPIRED", "message": "مهلت پرداخت پایان یافته و صندلی آزاد شده است."})
    bot_settings = await get_bot_settings(session)
    card = str(bot_settings.get("payment_card_number") or settings.payment_card_number or "").strip()
    account_name = str(bot_settings.get("payment_account_name") or settings.payment_account_name or "").strip()
    if not card or not account_name:
        raise HTTPException(status_code=503, detail={"code": "PAYMENT_CONFIGURATION_MISSING", "message": "اطلاعات پرداخت هنوز توسط مدیر تنظیم نشده است."})
    return {"booking_id": booking.id, "amount": int(booking.total_amount or 0),
            "payment_instructions": {"card_number": card, "account_name": account_name}}


@router.post("/bookings/{booking_id}/receipt")
async def upload_booking_receipt(
    booking_id: int,
    receipt: UploadFile | None = File(default=None),
    receipt_text: str | None = None,
    user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session),
):
    if not receipt and not (receipt_text or "").strip():
        raise HTTPException(status_code=422, detail={"code": "RECEIPT_REQUIRED", "message": "فایل یا متن رسید را وارد کنید."})
    if receipt_text is not None and len(receipt_text) > 4000:
        raise HTTPException(status_code=422, detail={"code": "RECEIPT_TEXT_TOO_LONG"})
    booking = (await session.execute(select(Booking).where(Booking.id == booking_id).with_for_update().execution_options(populate_existing=True))).scalar_one_or_none()
    if booking is None or booking.booked_by_user_id != user.id:
        raise HTTPException(status_code=404, detail={"code": "BOOKING_NOT_FOUND"})
    if booking.status not in (RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.REJECTED):
        raise HTTPException(status_code=409, detail={"code": "BOOKING_NOT_ACCEPTING_RECEIPTS", "message": "این رزرو در وضعیت دریافت رسید نیست."})
    if expire_booking_if_due(booking):
        await session.commit()
        raise HTTPException(status_code=409, detail={"code": "BOOKING_EXPIRED", "message": "مهلت پرداخت پایان یافته و صندلی آزاد شده است."})
    event = (await session.execute(select(Event).where(Event.id == booking.event_id).with_for_update().execution_options(populate_existing=True))).scalar_one_or_none()
    if event is None or event.status != EventStatus.PUBLISHED or event.archived:
        raise HTTPException(status_code=409, detail={"code": "EVENT_NOT_ACTIVE", "message": "این پنل دیگر فعال نیست."})

    stored_path = None
    original_name = None
    if receipt is not None:
        original_name = Path(receipt.filename or "receipt").name[:255]
        suffix = Path(original_name).suffix.lower()
        allowed = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png"}
        mime = (receipt.content_type or "").lower()
        if suffix not in allowed or (mime and mime != allowed[suffix]):
            raise HTTPException(status_code=415, detail={"code": "UNSUPPORTED_RECEIPT", "message": "فقط فایل‌های PDF، JPG و PNG پذیرفته می‌شوند."})
        content = await receipt.read(settings.max_upload_mb * 1024 * 1024 + 1)
        if not content or len(content) > settings.max_upload_mb * 1024 * 1024:
            raise HTTPException(status_code=413, detail={"code": "RECEIPT_TOO_LARGE", "message": f"حداکثر حجم فایل {settings.max_upload_mb} مگابایت است."})
        upload_root = Path(settings.upload_dir).resolve()
        upload_root.mkdir(parents=True, exist_ok=True)
        free_mb = shutil.disk_usage(upload_root).free / (1024 * 1024)
        if free_mb < int(settings.upload_min_free_mb):
            raise HTTPException(status_code=507, detail={"code": "UPLOAD_STORAGE_LOW"})
        if settings.max_upload_storage_mb > 0:
            current_size = sum(p.stat().st_size for p in upload_root.rglob("*") if p.is_file())
            if current_size + len(content) > settings.max_upload_storage_mb * 1024 * 1024:
                raise HTTPException(status_code=507, detail={"code": "UPLOAD_STORAGE_QUOTA"})
        extension = ".jpg" if suffix == ".jpeg" else suffix
        stored = upload_root / f"booking_{booking_id}_web_{uuid.uuid4().hex}{extension}"
        stored.write_bytes(content)
        if not file_content_matches(str(stored), extension):
            stored.unlink(missing_ok=True)
            raise HTTPException(status_code=415, detail={"code": "INVALID_FILE_CONTENT", "message": "محتوای فایل با فرمت آن مطابقت ندارد."})
        stored_path = str(stored)

    payment = (await session.execute(select(Payment).where(Payment.booking_id == booking.id).with_for_update())).scalar_one_or_none()
    if payment is None:
        payment = Payment(booking_id=booking.id, amount=booking.total_amount)
        session.add(payment)
    payment.amount = booking.total_amount
    payment.receipt_file = stored_path
    payment.receipt_file_name = original_name
    payment.receipt_text = receipt_text.strip() if receipt_text else None
    payment.receipt_uploaded_at = utc_now_naive()
    payment.status = PaymentStatus.PENDING
    payment.reviewed_at = None
    payment.reviewed_by = None
    booking.status = RegistrationStatus.PENDING_VERIFICATION
    booking.expires_at = None
    await session.commit()
    return {"status": "pending_verification", "booking_id": booking_id, "message": "رسید دریافت شد و در انتظار بررسی مدیر است."}


@router.post("/bookings/{booking_id}/cancel")
async def cancel_website_booking(booking_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    try:
        booking = await cancel_booking(session, user.id, booking_id)
    except ValueError as exc:
        _raise_service_error(exc)
    return {"booking_id": booking.id, "status": booking.status.value if hasattr(booking.status, 'value') else str(booking.status)}


@router.post("/bookings/{booking_id}/retry-payment")
async def retry_website_payment(booking_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    try:
        booking = await retry_payment(session, user.id, booking_id)
    except ValueError as exc:
        _raise_service_error(exc)
    bot_settings = await get_bot_settings(session)
    return {"booking_id": booking.id, "status": booking.status.value if hasattr(booking.status, 'value') else str(booking.status),
            "payment_instructions": {"card_number": bot_settings.get("payment_card_number") or settings.payment_card_number,
                                     "account_name": bot_settings.get("payment_account_name") or settings.payment_account_name}}


@router.get("/me/reviews/eligible")
async def eligible_review_events(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(Event).join(Booking, Booking.event_id == Event.id).where(
        Booking.booked_by_user_id == user.id,
        Booking.status == RegistrationStatus.CONFIRMED,
        or_(Event.status == EventStatus.COMPLETED, Event.archived.is_(True)),
    ).order_by(Event.id.desc()))).scalars().unique().all()
    reviewed = set((await session.execute(select(Review.event_id).where(Review.user_id == user.id))).scalars().all())
    return {"items": [{"id": e.id, "title": e.title, "date": e.event_date_label, "venue": e.venue} for e in rows if e.id not in reviewed]}


@router.post("/me/reviews")
async def create_website_review(payload: ReviewCreateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    eligible = (await session.execute(select(Booking.id).join(Event, Event.id == Booking.event_id).where(
        Booking.booked_by_user_id == user.id, Booking.event_id == payload.event_id,
        Booking.status == RegistrationStatus.CONFIRMED,
        or_(Event.status == EventStatus.COMPLETED, Event.archived.is_(True)),
    ).limit(1))).scalar_one_or_none()
    if eligible is None:
        raise HTTPException(status_code=403, detail={"code": "REVIEW_NOT_ELIGIBLE", "message": "ثبت‌نام تأییدشده‌ای برای ثبت نظر دربارهٔ این پنل پیدا نشد."})
    review = Review(user_id=user.id, reviewer_telegram_id=user.telegram_id, event_id=payload.event_id,
                    booking_id=int(eligible), rating=payload.rating,
                    discussion_quality=payload.discussion_quality,
                    moderator_rating=payload.moderator_rating,
                    topic_relevance=payload.topic_relevance,
                    would_attend_again=payload.would_attend_again,
                    text=payload.text.strip(), status=ModerationStatus.PENDING)
    session.add(review)
    try:
        await session.commit()
    except IntegrityError as exc:
        await session.rollback()
        raise HTTPException(status_code=409, detail={"code": "REVIEW_ALREADY_EXISTS", "message": "برای این پنل قبلاً نظر ثبت کرده‌اید."}) from exc
    return {"id": review.id, "status": "pending"}


@router.get("/community/topics")
async def list_community_topics(session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(TopicSuggestion).where(TopicSuggestion.status == "approved")
        .order_by(TopicSuggestion.created_at.desc()).limit(50))).scalars().all()
    counts = {}
    if rows:
        count_rows = (await session.execute(select(TopicVote.topic_id, func.count(TopicVote.id))
            .where(TopicVote.topic_id.in_([r.id for r in rows])).group_by(TopicVote.topic_id))).all()
        counts = {int(k): int(v) for k, v in count_rows}
    return {"items": [{"id": r.id, "title": r.title, "votes": counts.get(r.id, 0), "created_at": r.created_at} for r in rows]}


@router.post("/community/topics")
async def submit_community_topic(payload: TopicCreateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if await has_active_feature_restriction(session, user.telegram_id, "suggestions"):
        raise HTTPException(status_code=403, detail={"code": "SUGGESTIONS_RESTRICTED"})
    row = TopicSuggestion(user_id=user.id, title=payload.title.strip(), status="pending")
    session.add(row)
    await session.commit()
    return {"id": row.id, "status": row.status, "message": "پیشنهاد شما برای بررسی ارسال شد."}


@router.post("/community/topics/{topic_id}/vote")
async def vote_for_topic(topic_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    topic = await session.get(TopicSuggestion, topic_id)
    if topic is None or topic.status != "approved":
        raise HTTPException(status_code=404, detail={"code": "TOPIC_NOT_FOUND"})
    existing = (await session.execute(select(TopicVote).where(TopicVote.topic_id == topic_id, TopicVote.user_id == user.id))).scalar_one_or_none()
    if existing is not None:
        await session.delete(existing)
        saved = False
    else:
        session.add(TopicVote(topic_id=topic_id, user_id=user.id))
        saved = True
    await session.commit()
    return {"voted": saved}


@router.get("/community/challenges")
async def list_community_challenges(user: User | None = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(CommunityChallenge).where(
        CommunityChallenge.cleared_at.is_(None), CommunityChallenge.status.in_(("open", "closed", "finalized"))
    ).order_by(CommunityChallenge.published_sequence.desc().nullslast(), CommunityChallenge.id.desc()).limit(20))).scalars().all()
    ids = [r.id for r in rows]
    submitted = set()
    if user and ids:
        submitted = set((await session.execute(select(ChallengeSubmission.challenge_id).where(
            ChallengeSubmission.challenge_id.in_(ids), ChallengeSubmission.telegram_id == user.telegram_id
        ))).scalars().all())
    return {"items": [{"id": r.id, "title": r.title, "prompt": r.prompt, "type": r.challenge_type,
                       "status": r.status, "created_at": r.created_at, "submitted": r.id in submitted,
                       "can_submit": r.status == "open" and r.id not in submitted} for r in rows]}


@router.post("/community/challenges/{challenge_id}/submit")
async def submit_challenge_answer(challenge_id: int, payload: ChallengeAnswerInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if await has_active_feature_restriction(session, user.telegram_id, "challenges"):
        raise HTTPException(status_code=403, detail={"code": "CHALLENGES_RESTRICTED"})
    challenge = (await session.execute(select(CommunityChallenge).where(CommunityChallenge.id == challenge_id).with_for_update())).scalar_one_or_none()
    if challenge is None or challenge.status != "open" or challenge.cleared_at is not None:
        raise HTTPException(status_code=409, detail={"code": "CHALLENGE_CLOSED"})
    row = ChallengeSubmission(challenge_id=challenge_id, telegram_id=user.telegram_id,
                              answer_text=payload.answer_text.strip(), judging_status="unmarked")
    session.add(row)
    try:
        await session.commit()
    except IntegrityError as exc:
        await session.rollback()
        raise HTTPException(status_code=409, detail={"code": "CHALLENGE_ALREADY_SUBMITTED"}) from exc
    return {"status": "submitted"}


# --------------------------- Staff and administration ---------------------------

@router.get("/staff/platform/hosts")
async def platform_list_hosts(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_superadmin(user)
    hosts = (await session.execute(select(User).where(User.role == UserRole.HOST).order_by(User.created_at.desc()))).scalars().all()
    items = []
    for host in hosts:
        subscription = (await session.execute(select(HostSubscription).where(HostSubscription.host_user_id == host.id)
            .order_by(HostSubscription.created_at.desc(), HostSubscription.id.desc()).limit(1))).scalar_one_or_none()
        items.append({"id": int(host.id), "telegram_id": int(host.telegram_id), "username": host.telegram_username,
            "name": host.display_name or " ".join(filter(None, [host.first_name, host.last_name])) or host.telegram_username or str(host.telegram_id),
            "subscription": _subscription_payload(subscription)})
    return {"items": items, "total": len(items)}


@router.post("/staff/platform/hosts")
async def platform_add_host(payload: HostCreateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_superadmin(user)
    host = (await session.execute(select(User).where(User.telegram_id == payload.telegram_id).with_for_update())).scalar_one_or_none()
    if host is None:
        raise HTTPException(status_code=404, detail={"code": "TELEGRAM_ACCOUNT_NOT_FOUND", "message": "این کاربر هنوز در ربات Panel Flow حسابی نساخته است. ابتدا باید ربات را Start کند."})
    if int(host.telegram_id) in settings.super_admin_id_set:
        raise HTTPException(status_code=409, detail={"code": "SUPER_ADMIN_CANNOT_BE_HOST", "message": "حساب مدیر کل را نمی‌توان به میزبان تبدیل کرد."})
    now = utc_now_naive()
    if host.role == UserRole.HOST:
        current_subscription = (await session.execute(select(HostSubscription).where(HostSubscription.host_user_id == host.id)
            .order_by(HostSubscription.created_at.desc(), HostSubscription.id.desc()).limit(1))).scalar_one_or_none()
        if current_subscription and current_subscription.status in {"active", "trial"} and (current_subscription.ends_at is None or current_subscription.ends_at > now):
            raise HTTPException(status_code=409, detail={"code": "HOST_ALREADY_ACTIVE", "message": "این حساب از قبل میزبان فعال است. اشتراک فعلی را از فهرست میزبان‌ها ویرایش یا تمدید کنید."})
    host.role = UserRole.HOST
    subscription = HostSubscription(host_user_id=host.id, plan_code=payload.plan_code, status=payload.status,
        starts_at=now, ends_at=now + timedelta(days=payload.duration_days), price_amount=payload.price_amount,
        currency=payload.currency, notes=payload.notes, created_by_user_id=user.id, created_at=now, updated_at=now)
    session.add(subscription)
    await session.flush()
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_host_added",
        entity_type="user", entity_id=host.id, details={"telegram_id": int(host.telegram_id), "plan": payload.plan_code, "days": payload.duration_days})
    await session.commit()
    return {"id": int(host.id), "telegram_id": int(host.telegram_id), "name": host.display_name or host.telegram_username or str(host.telegram_id),
            "subscription": _subscription_payload(subscription)}


@router.patch("/staff/platform/hosts/{host_user_id}/subscription")
async def platform_update_host_subscription(host_user_id: int, payload: HostSubscriptionUpdateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_superadmin(user)
    host = await session.get(User, host_user_id, with_for_update=True)
    if host is None or host.role != UserRole.HOST or int(host.telegram_id) in settings.super_admin_id_set:
        raise HTTPException(status_code=404, detail={"code": "HOST_NOT_FOUND"})
    subscription = (await session.execute(select(HostSubscription).where(HostSubscription.host_user_id == host.id)
        .order_by(HostSubscription.created_at.desc(), HostSubscription.id.desc()).limit(1).with_for_update())).scalar_one_or_none()
    now = utc_now_naive()
    if subscription is None:
        subscription = HostSubscription(host_user_id=host.id, plan_code="starter", status="suspended", starts_at=now,
            created_by_user_id=user.id, created_at=now, updated_at=now)
        session.add(subscription)
    changes = payload.model_dump(exclude_unset=True)
    if "plan_code" in changes and changes["plan_code"] is not None:
        subscription.plan_code = changes["plan_code"]
    if "price_amount" in changes and changes["price_amount"] is not None:
        subscription.price_amount = changes["price_amount"]
    if "currency" in changes and changes["currency"] is not None:
        subscription.currency = changes["currency"]
    if "notes" in changes:
        subscription.notes = changes["notes"]
    if "status" in changes and changes["status"] is not None:
        subscription.status = changes["status"]
    if payload.duration_days is not None:
        base = subscription.ends_at if subscription.ends_at and subscription.ends_at > now else now
        subscription.ends_at = base + timedelta(days=payload.duration_days)
        if subscription.starts_at > now:
            subscription.starts_at = now
    elif subscription.ends_at is None and subscription.status in {"active", "trial"}:
        subscription.ends_at = now + timedelta(days=30)
    subscription.updated_at = now
    await session.flush()
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_host_subscription_updated",
        entity_type="host_subscription", entity_id=subscription.id, details={"host_user_id": host.id, "fields": sorted(changes)})
    await session.commit()
    return {"id": int(host.id), "subscription": _subscription_payload(subscription)}


@router.post("/staff/platform/hosts/{host_user_id}/deactivate")
async def platform_deactivate_host(host_user_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_superadmin(user)
    host = await session.get(User, host_user_id, with_for_update=True)
    if host is None or host.role != UserRole.HOST or int(host.telegram_id) in settings.super_admin_id_set:
        raise HTTPException(status_code=404, detail={"code": "HOST_NOT_FOUND"})
    host.role = UserRole.PARTICIPANT
    now = utc_now_naive()
    await session.execute(update(HostSubscription).where(
        HostSubscription.host_user_id == host.id, HostSubscription.status.in_(("active", "trial"))
    ).values(status="suspended", updated_at=now))
    await session.execute(update(HostVerification).where(
        HostVerification.user_id == host.id, HostVerification.status == "approved"
    ).values(status="suspended", updated_at=now))
    await session.execute(update(OrganizationMembership).where(
        OrganizationMembership.user_id == host.id, OrganizationMembership.role == "host",
        OrganizationMembership.status == "approved"
    ).values(status="suspended"))
    await session.execute(update(HostPublicProfile).where(
        HostPublicProfile.user_id == host.id
    ).values(is_active=False, updated_at=now))
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_host_deactivated",
        entity_type="user", entity_id=host.id, details={"telegram_id": int(host.telegram_id), "preserved_member_account": True})
    await session.commit()
    return {"id": int(host.id), "role": "participant"}


@router.get("/staff/platform/cities")
async def platform_list_cities(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    cities = (await session.execute(select(City).order_by(City.name_en))).scalars().all()
    counts = dict((int(city_id), int(count)) for city_id, count in (await session.execute(
        select(Event.city_id, func.count(Event.id)).where(
            Event.city_id.is_not(None), Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
        ).group_by(Event.city_id)
    )).all())
    return {"items": [_city_payload(city, counts.get(int(city.id), 0)) for city in cities], "total": len(cities)}


@router.post("/staff/platform/cities")
async def platform_add_city(payload: CityCreateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    if await session.scalar(select(City.id).where(City.slug == payload.slug)):
        raise HTTPException(status_code=409, detail={"code": "CITY_SLUG_EXISTS"})
    city = City(**payload.model_dump(), is_active=True)
    session.add(city)
    await session.flush()
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_city_added", entity_type="city", entity_id=city.id, details={"slug": city.slug})
    await session.commit()
    return _city_payload(city)


@router.patch("/staff/platform/cities/{city_id}")
async def platform_update_city(city_id: int, payload: CityUpdateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    city = await session.get(City, city_id, with_for_update=True)
    if city is None:
        raise HTTPException(status_code=404, detail={"code": "CITY_NOT_FOUND"})
    changes = payload.model_dump(exclude_unset=True)
    if city.is_founding_city and changes.get("is_active") is False:
        raise HTTPException(status_code=409, detail={"code": "FOUNDING_CITY_CANNOT_BE_DISABLED"})
    for key, value in changes.items():
        setattr(city, key, value)
    city.updated_at = utc_now_naive()
    if "name_en" in changes:
        await session.execute(update(Event).where(Event.city_id == city.id).values(city=city.name_en, updated_at=city.updated_at))
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_city_updated", entity_type="city", entity_id=city.id, details={"fields": sorted(changes)})
    await session.commit()
    return _city_payload(city)


@router.get("/staff/dashboard")
async def staff_dashboard(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin_or_host(user)
    own_only = not _is_admin(user)
    allowed_orgs = await list_accessible_organization_ids(session, user) if own_only else []
    owner_orgs = (await session.execute(select(OrganizationMembership.organization_id).where(
        OrganizationMembership.user_id == user.id, OrganizationMembership.status == "approved",
        OrganizationMembership.role.in_(("owner", "admin"))))).scalars().all() if own_only else []
    host_orgs = set(allowed_orgs) - set(owner_orgs) if own_only else set()
    tenant_filter = []
    if own_only:
        tenant_filter = [or_(Event.organization_id.in_(owner_orgs) if owner_orgs else text("1=0"),
                             (Event.organization_id.in_(host_orgs) & (Event.host_id == user.id)) if host_orgs else text("1=0"))]
    event_total = int(await session.scalar(select(func.count(Event.id)).where(*tenant_filter)) or 0)
    published = int(await session.scalar(select(func.count(Event.id)).where(Event.status == EventStatus.PUBLISHED, Event.archived.is_(False), *tenant_filter)) or 0)
    pending_receipt_stmt = select(func.count(Payment.id)).join(Booking, Booking.id == Payment.booking_id).join(
        Event, Event.id == Booking.event_id).where(
        Payment.status == PaymentStatus.PENDING, Booking.status == RegistrationStatus.PENDING_VERIFICATION,
        or_((Payment.receipt_file.is_not(None) & (Payment.receipt_file != "")), (Payment.receipt_text.is_not(None) & (Payment.receipt_text != ""))),
        *tenant_filter)
    pending_receipts = int(await session.scalar(pending_receipt_stmt) or 0)
    pending_reviews = 0 if own_only else int(await session.scalar(select(func.count(Review.id)).where(Review.status == ModerationStatus.PENDING)) or 0)
    pending_bookings = int(await session.scalar(select(func.count(Booking.id)).join(Event, Event.id == Booking.event_id)
        .where(Booking.status.in_((RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.PENDING_VERIFICATION)), *tenant_filter)) or 0)
    gross = int(await session.scalar(select(func.coalesce(func.sum(Booking.total_amount), 0)).join(
        Event, Event.id == Booking.event_id).where(Booking.status == RegistrationStatus.CONFIRMED, *tenant_filter)) or 0)
    recent = (await session.execute(select(Event).where(*tenant_filter).order_by(Event.updated_at.desc()).limit(6))).scalars().all()
    event_cards = []
    for event in recent:
        used = await seats_used(session, event.id)
        event_cards.append({**_event_read_payload(event, used), "host_id": event.host_id})
    subscription = None
    if not _is_admin(user) and len(allowed_orgs) == 1:
        from app.db.models import OrganizationSubscription, SubscriptionPlan
        row = (await session.execute(select(OrganizationSubscription).where(OrganizationSubscription.organization_id == allowed_orgs[0])
            .order_by(OrganizationSubscription.created_at.desc(), OrganizationSubscription.id.desc()).limit(1))).scalar_one_or_none()
        plan = await session.get(SubscriptionPlan, row.plan_id) if row and row.plan_id else None
        if row:
            subscription = {"status": row.status, "ends_at": row.ends_at, "plan_code": plan.code if plan else None}
    return {"metrics": {"events": event_total, "published_events": published, "pending_receipts": pending_receipts,
                         "pending_reviews": pending_reviews, "pending_bookings": pending_bookings, "confirmed_revenue": gross},
            "recent_events": event_cards, "staff_role": "admin" if _is_admin(user) else "organization_member",
            "subscription": subscription}


@router.get("/staff/events")
async def staff_events(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session),
                       limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0, le=100000)):
    _require_admin_or_host(user)
    stmt = select(Event).order_by(Event.id.desc())
    count_stmt = select(func.count(Event.id))
    if not _is_admin(user):
        allowed_orgs = await list_accessible_organization_ids(session, user)
        owner_orgs = (await session.execute(select(OrganizationMembership.organization_id).where(
            OrganizationMembership.user_id == user.id, OrganizationMembership.status == "approved",
            OrganizationMembership.role.in_(("owner", "admin"))))).scalars().all()
        host_orgs = set(allowed_orgs) - set(owner_orgs)
        scope = or_(Event.organization_id.in_(owner_orgs) if owner_orgs else text("1=0"),
                    (Event.organization_id.in_(host_orgs) & (Event.host_id == user.id)) if host_orgs else text("1=0"))
        stmt = stmt.where(scope); count_stmt = count_stmt.where(scope)
    total = int(await session.scalar(count_stmt) or 0)
    rows = (await session.execute(stmt.offset(offset).limit(limit))).scalars().all()
    member_roles: dict[int, str] = {}
    if not _is_admin(user):
        role_rows = (await session.execute(select(OrganizationMembership.organization_id, OrganizationMembership.role).where(
            OrganizationMembership.user_id == user.id, OrganizationMembership.status == "approved"))).all()
        member_roles = {int(org_id): str(role) for org_id, role in role_rows}
    result = []
    for event in rows:
        used = await seats_used(session, event.id)
        role = member_roles.get(int(event.organization_id)) if event.organization_id else None
        from app.services.event_quality import evaluate_event_quality
        result.append({**_event_read_payload(event, used), "host_id": event.host_id,
                       "content_quality": evaluate_event_quality(event),
                       "can_publish": bool(_is_admin(user) or role in {"owner", "admin"}),
                       "submission_status": event.submission_status, "submission_feedback": event.submission_feedback})
    return {"items": result, "total": total, "limit": limit, "offset": offset}


@router.post("/staff/events")
async def staff_create_event(payload: EventCreateInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin_or_host(user)
    # New event creation is organization-owned. Legacy host subscriptions are not
    # used as an authorization source; the call remains only to produce a clear
    # legacy-host migration error for clients that still omit organization_id.
    organization_id = payload.organization_id
    brand_id = payload.brand_id
    if organization_id is None:
        if not _is_admin(user):
            await _ensure_active_host_subscription(user, session)
            raise HTTPException(status_code=422, detail={"code": "ORGANIZATION_AND_BRAND_REQUIRED", "message": "برای ساخت پنل، سازمان و برند میزبان را انتخاب کنید."})
        founder = (await session.execute(select(Organization).where(Organization.is_platform_founder.is_(True)))).scalar_one_or_none()
        if founder is None: raise HTTPException(status_code=503, detail={"code": "FOUNDING_ORGANIZATION_NOT_CONFIGURED"})
        organization_id = founder.id
    if brand_id is None:
        founder_brand = (await session.execute(select(Brand).where(Brand.organization_id == organization_id,
            Brand.slug == "panel-flow", Brand.status == "approved"))).scalar_one_or_none()
        if founder_brand is None:
            raise HTTPException(status_code=422, detail={"code": "BRAND_REQUIRED"})
        brand_id = founder_brand.id
    await authorize_brand(session, user, organization_id, brand_id)
    selected_city = await session.get(City, payload.city_id) if payload.city_id else None
    if payload.city_id and (selected_city is None or not selected_city.is_active):
        raise HTTPException(status_code=422, detail={"code": "CITY_UNAVAILABLE", "message": "شهر انتخاب‌شده فعال نیست."})
    if selected_city is None:
        selected_city = (await session.execute(select(City).where(or_(func.lower(City.name_en) == payload.city.strip().lower(), City.name_fa == payload.city.strip()), City.is_active.is_(True)))).scalar_one_or_none()
    if selected_city is None:
        raise HTTPException(status_code=422, detail={"code": "CITY_UNAVAILABLE"})
    meeting_link = payload.meeting_link
    released_at = utc_now_naive() if meeting_link and payload.meeting_link_released else None
    venue = (payload.venue or "").strip() if payload.event_type in {"physical", "hybrid"} else ("Online" if payload.event_type == "online" else "Hybrid")
    event = Event(
        volume=payload.volume.strip(), title=payload.title.strip(), language=payload.language,
        description=payload.description, topic_tags=payload.topic_tags, agenda_items=payload.agenda_items,
        discussion_questions=payload.discussion_questions, event_day_label=payload.day.strip(), event_date_label=payload.date.strip(),
        start_time_label=payload.start_time.strip(), end_time_label=(payload.end_time or "—").strip(),
        venue=venue, address=payload.address if payload.event_type in {"physical", "hybrid"} else None,
        map_url=payload.map_url if payload.event_type in {"physical", "hybrid"} else None,
        city=selected_city.name_en, city_id=selected_city.id, event_date_iso=payload.date_iso,
        organization_id=organization_id, brand_id=brand_id, event_type=payload.event_type,
        meeting_platform=payload.meeting_platform, meeting_link=meeting_link, meeting_link_released_at=released_at,
        capacity=payload.capacity, waitlist_enabled=bool(payload.waitlist_enabled), price_per_person=Decimal(payload.price_per_person),
        price_without_cafe_order=Decimal(payload.price_without_cafe_order) if payload.price_without_cafe_order is not None else None,
        status=EventStatus.DRAFT, registration_open=False, host_id=user.id,
        host_name=user.display_name or user.first_name or "",
    )
    session.add(event)
    # Make the organization's multi-city participation explicit.
    relation = await session.get(OrganizationCity, (organization_id, selected_city.id))
    if relation is None:
        session.add(OrganizationCity(organization_id=organization_id, city_id=selected_city.id))
    await session.flush()
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=organization_id,
        action="event.created", target_type="event", target_id=str(event.id),
        metadata_json={"brand_id": brand_id, "event_type": event.event_type}))
    if _is_admin(user):
        await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_event_created",
                                 entity_type="event", entity_id=event.id, details={"title": event.title, "organization_id": organization_id, "brand_id": brand_id})
    await session.commit(); await session.refresh(event)
    return {"id": event.id, "status": "draft", "organization_id": organization_id, "brand_id": brand_id, "event_type": event.event_type}


@router.post("/staff/events/{event_id}/cover-image")
async def upload_event_cover_image(event_id: int, background_tasks: BackgroundTasks,
    file: UploadFile = File(...), user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin_or_host(user)
    event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
    if event is None:
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    await authorize_event_manage(session, user, event)
    if event.archived or event.status in {EventStatus.CANCELLED, EventStatus.COMPLETED}:
        raise HTTPException(409, detail={"code": "EVENT_NOT_EDITABLE"})
    from app.services.media_uploads import store_public_image
    try:
        stored = await store_public_image(file, prefix=f"event-{event_id}-cover")
    except ValueError as exc:
        raise HTTPException(422, detail={"code": str(exc)}) from exc
    was_published = event.status == EventStatus.PUBLISHED
    event.cover_image_url = str(stored["url"])
    event.cover_image_thumb_url = str(stored.get("thumbnail_url") or stored["url"])
    event.updated_at = utc_now_naive()
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=event.organization_id,
        action="event.cover_image.updated", target_type="event", target_id=str(event.id), metadata_json={
            "original_bytes": int(stored["original_bytes"]), "stored_bytes": int(stored["stored_bytes"])}))
    if was_published:
        from app.services.notification_outbox import enqueue_event_notification
        await enqueue_event_notification(session, event_id=int(event.id), event_type="panel.changed",
            change_key=f"cover-{event.updated_at.isoformat(timespec='microseconds')}")
    await session.commit()
    return {"event_id": event_id, **stored}


@router.patch("/staff/events/{event_id}")
async def staff_update_event(event_id: int, payload: EventUpdateInput, background_tasks: BackgroundTasks, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin_or_host(user)
    event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
    if event is None:
        raise HTTPException(status_code=404, detail={"code": "EVENT_NOT_FOUND"})
    membership = await authorize_event_manage(session, user, event)
    was_published = event.status == EventStatus.PUBLISHED
    changes = payload.model_dump(exclude_unset=True)
    if changes.get("cover_image_url"):
        filename = str(changes["cover_image_url"]).rsplit("/", 1)[-1]
        expected_prefix = f"event-{event_id}-cover-"
        media_path = Path(settings.upload_dir).resolve() / "public_media" / filename
        if not filename.startswith(expected_prefix) or media_path.is_symlink() or not media_path.is_file():
            raise HTTPException(status_code=403, detail={"code": "EVENT_COVER_MEDIA_NOT_OWNED"})
    if "capacity" in changes and changes["capacity"] is not None:
        occupied = await seats_used(session, event.id)
        if int(changes["capacity"]) < occupied:
            raise HTTPException(status_code=409, detail={"code": "CAPACITY_BELOW_ACTIVE_BOOKINGS", "message": f"ظرفیت جدید نمی‌تواند کمتر از تعداد صندلی‌های رزروشده ({occupied}) باشد."})
    can_manage_lifecycle = bool(membership and membership.role in {"owner", "admin"})
    if not _is_admin(user) and not can_manage_lifecycle:
        if event.status != EventStatus.DRAFT or any(k in changes for k in ("status", "registration_open", "is_postponed", "postponement_note")):
            raise HTTPException(status_code=403, detail={"code": "HOST_DRAFT_ONLY", "message": "میزبان فقط می‌تواند پیش‌نویس پنل تخصیص‌یافته به خود را ویرایش کند."})
    if not _is_admin(user) and can_manage_lifecycle and "status" in changes:
        requested_status = changes["status"]
        allowed_transition = ((event.status == EventStatus.DRAFT and requested_status == "published") or
                              (event.status == EventStatus.PUBLISHED and requested_status in {"completed", "cancelled"}))
        if not allowed_transition:
            raise HTTPException(status_code=409, detail={"code": "INVALID_EVENT_STATUS_TRANSITION"})
    if changes.get("is_postponed") is True and event.status != EventStatus.PUBLISHED:
        raise HTTPException(status_code=409, detail={"code": "ONLY_PUBLISHED_EVENTS_CAN_BE_POSTPONED"})
    if "postponement_note" in changes and changes.get("postponement_note") and not (changes.get("is_postponed", event.is_postponed)):
        raise HTTPException(status_code=422, detail={"code": "POSTPONEMENT_NOTE_REQUIRES_POSTPONED_EVENT"})
    if changes.get("status") == "published" and event.is_postponed and changes.get("is_postponed") is not False:
        raise HTTPException(status_code=409, detail={"code": "UNPOSTPONE_BEFORE_REOPENING"})
    mapping = {"day": "event_day_label", "date": "event_date_label", "date_iso": "event_date_iso", "start_time": "start_time_label", "end_time": "end_time_label"}
    next_type = changes.get("event_type", event.event_type)
    old_meeting_link = event.meeting_link
    for key, value in changes.items():
        if key in {"meeting_link_released", "is_postponed", "postponement_note"}:
            # Lifecycle changes are applied below, after regular event fields.
            continue
        target = mapping.get(key, key)
        if key in {"price_per_person", "price_without_cafe_order"}:
            value = Decimal(value) if value is not None else None
        if key == "city_id":
            city = await session.get(City, value) if value is not None else None
            if value is not None and (city is None or not city.is_active):
                raise HTTPException(status_code=422, detail={"code": "CITY_UNAVAILABLE"})
            if city is not None:
                event.city = city.name_en
                relation = await session.get(OrganizationCity, (event.organization_id, city.id)) if event.organization_id else None
                if event.organization_id and relation is None:
                    session.add(OrganizationCity(organization_id=event.organization_id, city_id=city.id))
            event.city_id = city.id if city is not None else None
            continue
        if key == "status":
            if value == "published":
                if next_type in {"physical", "hybrid"} and (not (event.venue or "").strip() or event.venue.strip().casefold() in {"online", "hybrid"}):
                    raise HTTPException(status_code=422, detail={"code": "EVENT_INCOMPLETE", "message": "محل برگزاری الزامی است."})
                if next_type in {"online", "hybrid"} and (not event.meeting_platform or not event.meeting_platform.strip()):
                    raise HTTPException(status_code=422, detail={"code": "MEETING_PLATFORM_REQUIRED"})
                if not event.title or event.capacity <= 0 or not event.organization_id or not event.brand_id:
                    raise HTTPException(status_code=422, detail={"code": "EVENT_INCOMPLETE"})
                # Re-check live membership, verification, subscription and brand assignment at publish time.
                await authorize_event_manage(session, user, event)
                event.registration_open = True; event.registration_closed_reason = None
            target_status = EventStatus(value)
            from app.services.event_lifecycle import transition_event
            try:
                transition_event(event, target_status)
            except ValueError as exc:
                raise HTTPException(status_code=409, detail={"code": "INVALID_EVENT_STATUS_TRANSITION"}) from exc
            value = target_status
        setattr(event, target, value)
    event.event_type = next_type
    if changes.get("is_postponed") is True:
        from app.services.event_lifecycle import postpone_event
        try:
            postpone_event(event, note=changes.get("postponement_note"))
        except ValueError as exc:
            raise HTTPException(status_code=409, detail={"code": "ONLY_PUBLISHED_EVENTS_CAN_BE_POSTPONED"}) from exc
    elif changes.get("is_postponed") is False and event.is_postponed:
        from app.services.event_lifecycle import resume_postponed_event
        try:
            resume_postponed_event(event, reopen_registration=bool(changes.get("registration_open", False)))
        except ValueError as exc:
            raise HTTPException(status_code=409, detail={"code": "EVENT_NOT_POSTPONED"}) from exc
    elif "postponement_note" in changes:
        if not event.is_postponed:
            raise HTTPException(status_code=422, detail={"code": "POSTPONEMENT_NOTE_REQUIRES_POSTPONED_EVENT"})
        event.postponement_note = changes.get("postponement_note")
    if event.is_postponed and changes.get("registration_open") is True:
        raise HTTPException(status_code=409, detail={"code": "EVENT_POSTPONED"})
    if event.event_type in {"physical", "hybrid"} and (not (event.venue or "").strip() or event.venue.strip().casefold() in {"online", "hybrid"}):
        raise HTTPException(status_code=422, detail={"code": "VENUE_REQUIRED"})
    if event.event_type in {"online", "hybrid"} and not (event.meeting_platform or "").strip():
        raise HTTPException(status_code=422, detail={"code": "MEETING_PLATFORM_REQUIRED"})
    if "meeting_link" in changes and changes["meeting_link"] != old_meeting_link:
        # A changed private link is never inherited as already released.
        event.meeting_link_released_at = None
    if event.event_type == "physical":
        event.meeting_platform = None; event.meeting_link = None; event.meeting_link_released_at = None
    elif event.event_type == "online":
        event.venue = "Online"; event.address = None; event.map_url = None
    if "meeting_link_released" in changes:
        if changes["meeting_link_released"] and event.meeting_link and event.event_type in {"online", "hybrid"}:
            event.meeting_link_released_at = utc_now_naive()
        else:
            event.meeting_link_released_at = None
    if "cover_image_url" in changes:
        event.cover_image_thumb_url = (f"{str(event.cover_image_url).split('?')[0]}?variant=thumb"
            if event.cover_image_url else None)
    event.updated_at = utc_now_naive()
    await session.flush()
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=event.organization_id,
        action="event.updated", target_type="event", target_id=str(event.id),
        metadata_json={"fields": sorted(changes), "status": str(event.status.value if hasattr(event.status, "value") else event.status)}))
    if _is_admin(user):
        await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_event_updated",
                                 entity_type="event", entity_id=event.id, details={"fields": sorted(changes)})
    changed_public_fields = {
        "title", "description", "day", "date", "date_iso", "start_time", "end_time",
        "venue", "address", "map_url", "city_id", "city", "capacity", "price_per_person",
        "price_without_cafe_order", "registration_open", "waitlist_enabled", "status",
        "event_type", "meeting_platform", "topic_tags", "agenda_items", "discussion_questions",
        "is_postponed", "postponement_note", "cover_image_url",
    }
    if not was_published and event.status == EventStatus.PUBLISHED:
        from app.services.notification_outbox import enqueue_event_notification
        await enqueue_event_notification(session, event_id=int(event.id), event_type="panel.published")
    elif was_published and changed_public_fields.intersection(changes):
        from app.services.notification_outbox import enqueue_event_notification
        change_key = f"update-{event.updated_at.isoformat(timespec='microseconds')}"
        await enqueue_event_notification(session, event_id=int(event.id), event_type="panel.changed", change_key=change_key)
    await session.commit()
    return {"id": event.id, "status": event.status.value if hasattr(event.status, "value") else str(event.status),
            "registration_open": registration_is_open(event), "is_postponed": bool(event.is_postponed),
            "postponement_note": event.postponement_note}


@router.get("/me/bookings/{booking_id}/meeting-details")
async def booking_meeting_details(booking_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    booking = await session.get(Booking, booking_id)
    if booking is None or booking.booked_by_user_id != user.id or booking.status != RegistrationStatus.CONFIRMED:
        raise HTTPException(404, detail={"code": "BOOKING_NOT_FOUND"})
    event = await session.get(Event, booking.event_id)
    if event is None or event.event_type not in {"online", "hybrid"} or not event.meeting_link or not event.meeting_link_released_at:
        raise HTTPException(404, detail={"code": "MEETING_DETAILS_NOT_AVAILABLE"})
    return {"event_id": event.id, "meeting_platform": event.meeting_platform, "meeting_link": event.meeting_link,
        "released_at": event.meeting_link_released_at}


@router.get("/staff/shop/requests")
async def staff_shop_requests(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session),
                              limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0, le=100000)):
    _require_admin(user)
    base = select(ShopRequest).where(ShopRequest.status == "pending").order_by(ShopRequest.created_at.asc(), ShopRequest.id.asc())
    total = int(await session.scalar(select(func.count(ShopRequest.id)).where(ShopRequest.status == "pending")) or 0)
    rows = (await session.execute(base.offset(offset).limit(limit))).scalars().all()
    return {"items": [{"id": row.id, "telegram_id": row.telegram_id, "title": row.offer_title_snapshot or f"تخفیف {row.discount_percent}٪",
                        "discount_percent": row.discount_percent, "xp_cost": row.xp_cost, "created_at": row.created_at,
                        "denial_reason": row.denial_reason} for row in rows], "total": total, "limit": limit, "offset": offset}


@router.post("/staff/shop/requests/{request_id}/review")
async def review_website_shop_request(request_id: int, payload: ShopReviewInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    request_row = (await session.execute(select(ShopRequest).where(ShopRequest.id == request_id).with_for_update())).scalar_one_or_none()
    if request_row is None or request_row.status != "pending":
        raise HTTPException(status_code=409, detail={"code": "SHOP_REQUEST_NOT_PENDING", "message": "این درخواست دیگر در انتظار بررسی نیست."})
    target_user = (await session.execute(select(User).where(User.telegram_id == request_row.telegram_id).with_for_update())).scalar_one_or_none()
    if target_user is None:
        raise HTTPException(status_code=409, detail={"code": "SHOP_USER_MISSING", "message": "حساب کاربر پیدا نشد؛ درخواست نیازمند بررسی دستی است."})
    if payload.decision == "denied":
        reason = (payload.reason or "").strip()
        if not reason:
            raise HTTPException(status_code=422, detail={"code": "SHOP_DENIAL_REASON_REQUIRED", "message": "برای رد درخواست، ذکر دلیل الزامی است."})
        request_row.status = "denied"
        request_row.denial_reason = reason
        request_row.reviewed_by_telegram_id = int(user.telegram_id)
        request_row.reviewed_at = utc_now_naive()
        request_row.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_shop_request_denied",
            entity_type="shop_request", entity_id=request_id, details={"telegram_id": request_row.telegram_id, "reason": reason[:300]})
        await session.commit()
        return {"id": request_id, "status": "denied"}
    balance = await user_community_stats(session, request_row.telegram_id)
    reserved = await reserved_shop_xp(session, request_row.telegram_id, exclude_request_id=request_id)
    if available_shop_xp(int(balance.get("xp", 0)), reserved) < int(request_row.xp_cost):
        raise HTTPException(status_code=409, detail={"code": "SHOP_XP_INSUFFICIENT", "message": "پس از درنظرگرفتن رزروهای دیگر، موجودی XP کافی نیست."})
    from app.services.community import award_once
    inserted = await award_once(session, telegram_id=request_row.telegram_id, points=-int(request_row.xp_cost),
        award_type="shop_redemption", award_key=f"my-shop-request:{request_id}:debit", source_id=str(request_id),
        note="Approved درخواست XP شاپ")
    if not inserted:
        raise HTTPException(status_code=409, detail={"code": "SHOP_XP_ALREADY_DEBITED", "message": "کسر XP قبلاً ثبت شده و نیازمند تطبیق است."})
    request_row.status = "awaiting_code"
    request_row.reviewed_by_telegram_id = int(user.telegram_id)
    request_row.reviewed_at = utc_now_naive()
    request_row.updated_at = utc_now_naive()
    issue = RewardIssue(source_type="shop", source_id=request_id, telegram_id=request_row.telegram_id,
                        discount_percent=int(request_row.discount_percent), status="awaiting_code")
    session.add(issue)
    await session.flush()
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action="website_shop_request_approved_xp_debited",
        entity_type="shop_request", entity_id=request_id, details={"telegram_id": request_row.telegram_id,
        "discount_percent": request_row.discount_percent, "xp_cost": request_row.xp_cost, "reward_issue_id": issue.id})
    await session.commit()
    return {"id": request_id, "status": "awaiting_code", "reward_issue_id": issue.id, "xp_debited": int(request_row.xp_cost)}


async def _authorize_host_owned_event(session: AsyncSession, user: User, event_id: int) -> Event:
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    event = await session.get(Event, event_id)
    if event is None or event.host_id != user.id:
        # Return the same result for nonexistent and other-host events.
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    await authorize_event_manage(session, user, event, allow_platform_admin=False)
    return event


@router.get("/staff/host/events/{event_id}/participants")
async def host_event_participants(event_id: int, user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session), limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0, le=100000),
    waitlist_offset: int = Query(default=0, ge=0, le=100000)):
    event = await _authorize_host_owned_event(session, user, event_id)
    base = select(Booking).where(Booking.event_id == event.id)
    total = int(await session.scalar(select(func.count(Booking.id)).where(Booking.event_id == event.id)) or 0)
    rows = (await session.execute(base.options(
        selectinload(Booking.participants), selectinload(Booking.booked_by), selectinload(Booking.payment)
    ).order_by(Booking.created_at.desc(), Booking.id.desc()).offset(offset).limit(limit))).scalars().all()
    items = []
    for booking in rows:
        registrant = booking.booked_by
        payment = booking.payment
        items.append({
            "booking_id": booking.id, "status": booking.status.value if hasattr(booking.status, "value") else str(booking.status),
            "participant_count": booking.participant_count, "total_amount": int(booking.total_amount or 0),
            "contact_phone": booking.contact_phone, "created_at": booking.created_at,
            "confirmed_at": booking.confirmed_at,
            "registrant": {"display_name": registrant.display_name or registrant.first_name or registrant.telegram_username or f"Member {registrant.id}",
                           "telegram_username": registrant.telegram_username},
            "payment": ({"status": payment.status.value if hasattr(payment.status, "value") else str(payment.status),
                         "amount": int(payment.amount or 0), "receipt_text": payment.receipt_text,
                         "receipt_file_name": payment.receipt_file_name, "has_file": bool(payment.receipt_file)} if payment else None),
            "participants": [{"id": person.id, "full_name": person.full_name, "phone_number": person.phone_number,
                              "attendance_status": person.attendance_status.value if hasattr(person.attendance_status, "value") else str(person.attendance_status)}
                             for person in booking.participants],
        })
    active_waitlist_filter = (WaitlistEntry.event_id == event.id,
                              WaitlistEntry.status.in_(("waiting", "invited", "inviting")))
    waitlist_total = int(await session.scalar(select(func.count(WaitlistEntry.id)).where(*active_waitlist_filter)) or 0)
    wait_rows = (await session.execute(
        select(WaitlistEntry, User)
        .join(User, User.id == WaitlistEntry.user_id)
        .where(*active_waitlist_filter)
        .order_by(WaitlistEntry.position.asc(), WaitlistEntry.created_at.asc(), WaitlistEntry.id.asc())
        .offset(waitlist_offset).limit(limit)
    )).all()
    waitlist = [{"id": int(entry.id), "position": waitlist_offset + index + 1, "status": entry.status,
                 "requested_participant_count": int(entry.requested_participant_count),
                 "member_name": member.display_name or member.first_name or f"Member {member.id}",
                 "invitation_expires_at": entry.invitation_expires_at, "created_at": entry.created_at}
                for index, (entry, member) in enumerate(wait_rows)]
    return {"event": {"id": event.id, "title": event.title,
                       "status": event.status.value if hasattr(event.status, "value") else str(event.status),
                       "archived": bool(event.archived), "registration_open": bool(event.registration_open),
                       "waitlist_enabled": bool(event.waitlist_enabled),
                       "attendance_enabled": bool(event.attendance_enabled)},
            "items": items, "total": total, "limit": limit, "offset": offset,
            "waitlist": waitlist, "waitlist_total": waitlist_total, "waitlist_offset": waitlist_offset}


@router.patch("/staff/host/events/{event_id}/attendance")
async def host_toggle_event_attendance(event_id: int, payload: HostAttendanceToggleInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    event = await _authorize_host_owned_event(session, user, event_id)
    if payload.enabled and (event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED)):
        raise HTTPException(409, detail={"code": "ATTENDANCE_EVENT_NOT_READY"})
    event = (await session.execute(select(Event).where(Event.id == event.id).with_for_update()
        .execution_options(populate_existing=True))).scalar_one()
    if event.host_id != user.id:
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    if payload.enabled and (event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED)):
        raise HTTPException(409, detail={"code": "ATTENDANCE_EVENT_NOT_READY"})
    event.attendance_enabled = bool(payload.enabled)
    if not payload.enabled:
        # Turning off attendance immediately revokes existing QR and manual codes.
        event.attendance_checkin_token_hash = None
        event.attendance_checkin_code_hash = None
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=event.organization_id,
        action="host.event_attendance_enabled" if payload.enabled else "host.event_attendance_disabled",
        target_type="event", target_id=str(event.id), metadata_json={"enabled": bool(payload.enabled)}))
    await session.commit()
    return {"event_id": int(event.id), "attendance_enabled": bool(event.attendance_enabled)}


@router.patch("/staff/host/events/{event_id}/waitlist")
async def host_toggle_event_waitlist(event_id: int, payload: HostAttendanceToggleInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    """Allow the assigned host to enable or pause the existing event waitlist."""
    event = await _authorize_host_owned_event(session, user, event_id)
    if payload.enabled and (event.archived or event.status != EventStatus.PUBLISHED):
        raise HTTPException(409, detail={"code": "WAITLIST_EVENT_NOT_READY"})
    event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update()
        .execution_options(populate_existing=True))).scalar_one_or_none()
    if event is None or event.host_id != user.id:
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    if payload.enabled and (event.archived or event.status != EventStatus.PUBLISHED):
        raise HTTPException(409, detail={"code": "WAITLIST_EVENT_NOT_READY"})
    event.waitlist_enabled = bool(payload.enabled)
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=event.organization_id,
        action="host.event_waitlist_enabled" if payload.enabled else "host.event_waitlist_disabled",
        target_type="event", target_id=str(event.id), metadata_json={"enabled": bool(payload.enabled)}))
    await session.commit()
    return {"event_id": int(event.id), "waitlist_enabled": bool(event.waitlist_enabled)}


@router.post("/staff/host/events/{event_id}/attendance/qr")
async def host_create_attendance_qr(event_id: int, response: Response,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    """Rotate event-scoped check-in proofs and return a private, non-cacheable QR image."""
    event = await _authorize_host_owned_event(session, user, event_id)
    if not event.attendance_enabled:
        raise HTTPException(409, detail={"code": "ATTENDANCE_NOT_ENABLED"})
    if event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED):
        raise HTTPException(409, detail={"code": "ATTENDANCE_EVENT_NOT_READY"})
    if not settings.bot_token:
        raise HTTPException(503, detail={"code": "TELEGRAM_BOT_NOT_CONFIGURED"})
    # Do not hold a database transaction open while waiting for Telegram or
    # rendering the QR. Capture the scalar identity before rollback (which expires
    # ORM instances), then re-lock and revalidate before rotating proofs.
    target_event_id = int(event.id)
    await session.rollback()
    try:
        from aiogram import Bot
        bot = Bot(token=settings.bot_token)
        try:
            bot_identity = await bot.get_me()
        finally:
            await bot.session.close()
        if not bot_identity.username:
            raise RuntimeError("TELEGRAM_BOT_USERNAME_UNAVAILABLE")
        token_value = secrets.token_hex(12)
        deep_link = f"https://t.me/{bot_identity.username}?start=checkin_{target_event_id}_{token_value}"
        import qrcode
        qr_image = qrcode.make(deep_link)
        output = __import__("io").BytesIO()
        qr_image.save(output, format="PNG")
        qr_data_url = "data:image/png;base64," + __import__("base64").b64encode(output.getvalue()).decode("ascii")
    except Exception as exc:
        logger.exception("Host QR generation failed for event %s", event_id)
        raise HTTPException(503, detail={"code": "ATTENDANCE_QR_GENERATION_FAILED"}) from exc

    event = (await session.execute(select(Event).where(Event.id == target_event_id).with_for_update()
        .execution_options(populate_existing=True))).scalar_one_or_none()
    if event is None or event.host_id != user.id:
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    if not event.attendance_enabled:
        raise HTTPException(409, detail={"code": "ATTENDANCE_NOT_ENABLED"})
    if event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED):
        raise HTTPException(409, detail={"code": "ATTENDANCE_EVENT_NOT_READY"})

    token_hash = hashlib.sha256(token_value.encode("utf-8")).hexdigest()
    session_id = secrets.token_hex(8)
    saved_code = None
    for _attempt in range(12):
        code = f"{secrets.randbelow(1_000_000):06d}"
        code_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
        duplicate = await session.scalar(select(Event.id).where(Event.attendance_checkin_code_hash == code_hash,
                                                                  Event.id != event.id).limit(1))
        if duplicate is not None:
            continue
        expires_at = utc_now_naive() + timedelta(hours=12)
        event.attendance_checkin_token_hash = token_hash
        event.attendance_checkin_code_hash = code_hash
        event.attendance_checkin_session_id = session_id
        event.attendance_checkin_token_expires_at = expires_at
        event.attendance_checkin_code_expires_at = expires_at
        try:
            session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=event.organization_id,
                action="host.attendance_qr_rotated", target_type="event", target_id=str(event.id),
                metadata_json={"credentials_rotated": True}))
            await session.commit()
            saved_code = code
            break
        except IntegrityError:
            await session.rollback()
            event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update()
                .execution_options(populate_existing=True))).scalar_one_or_none()
            if event is None or event.host_id != user.id:
                raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
            if not event.attendance_enabled:
                raise HTTPException(409, detail={"code": "ATTENDANCE_NOT_ENABLED"})
            if event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED):
                raise HTTPException(409, detail={"code": "ATTENDANCE_EVENT_NOT_READY"})
    if saved_code is None:
        raise HTTPException(503, detail={"code": "ATTENDANCE_CODE_COLLISION_RETRY"})
    response.headers["Cache-Control"] = "private, no-store, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return {"event_id": int(event.id), "qr_data_url": qr_data_url, "manual_code": saved_code,
            "instructions": "Participants scan this QR with the Telegram account used for their confirmed booking, then select their own participant name. Generating a new QR invalidates the previous QR and code."}


@router.get("/staff/host/events/{event_id}/attendance-history")
async def host_event_attendance_history(event_id: int, user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session), limit: int = Query(default=100, ge=1, le=200)):
    event = await _authorize_host_owned_event(session, user, event_id)
    rows = (await session.execute(
        select(AttendanceAudit, Participant.full_name)
        .join(Participant, Participant.id == AttendanceAudit.participant_id)
        .where(AttendanceAudit.event_id == event.id)
        .order_by(AttendanceAudit.created_at.desc(), AttendanceAudit.id.desc()).limit(limit)
    )).all()
    return {"items": [{"id": int(audit.id), "participant_name": name, "old_status": audit.old_status,
                       "new_status": audit.new_status, "source": audit.source, "created_at": audit.created_at}
                      for audit, name in rows]}


@router.patch("/staff/host/events/{event_id}/participants/{participant_id}/attendance")
async def host_update_participant_attendance(event_id: int, participant_id: int, payload: HostAttendanceInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    event = await _authorize_host_owned_event(session, user, event_id)
    event = (await session.execute(select(Event).where(Event.id == event.id).with_for_update()
        .execution_options(populate_existing=True))).scalar_one()
    if event.host_id != user.id:
        raise HTTPException(404, detail={"code": "EVENT_NOT_FOUND"})
    if not event.attendance_enabled:
        raise HTTPException(409, detail={"code": "ATTENDANCE_NOT_ENABLED"})
    participant = (await session.execute(select(Participant).join(Booking, Booking.id == Participant.booking_id).where(
        Participant.id == participant_id, Booking.event_id == event.id,
        Booking.status == RegistrationStatus.CONFIRMED).with_for_update())).scalar_one_or_none()
    if participant is None:
        raise HTTPException(404, detail={"code": "PARTICIPANT_NOT_FOUND"})
    before = participant.attendance_status.value if hasattr(participant.attendance_status, "value") else str(participant.attendance_status)
    if before != payload.status:
        participant.attendance_status = AttendanceStatus(payload.status)
        session.add(AttendanceAudit(event_id=event.id, participant_id=participant.id,
            actor_telegram_id=int(user.telegram_id), old_status=before, new_status=payload.status, source="host_web"))
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=event.organization_id,
        action="host.participant_attendance_updated", target_type="participant", target_id=str(participant.id),
        metadata_json={"event_id": event.id, "from": before, "to": payload.status}))
    await session.commit()
    return {"participant_id": participant.id, "attendance_status": payload.status}


def _series_slug_base(title: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", title.casefold()).strip("-")[:90]
    return base or f"discussion-series-{secrets.token_hex(4)}"


async def _validate_host_series_events(session: AsyncSession, user: User, event_ids: list[int]) -> tuple[list[Event], int | None]:
    if len(event_ids) < 2 or len(event_ids) > 30 or len(event_ids) != len(set(event_ids)):
        raise HTTPException(422, detail={"code": "SERIES_REQUIRES_2_TO_30_UNIQUE_EVENTS"})
    events = []
    for event_id in event_ids:
        event = await _authorize_host_owned_event(session, user, int(event_id))
        if event.archived or event.is_postponed or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED):
            raise HTTPException(409, detail={"code": "SERIES_EVENTS_MUST_BE_PUBLIC_OR_COMPLETED_AND_NOT_POSTPONED", "event_id": event_id})
        events.append(event)
    org_ids = {int(event.organization_id) if event.organization_id is not None else None for event in events}
    if len(org_ids) > 1:
        raise HTTPException(422, detail={"code": "SERIES_EVENTS_MUST_SHARE_ORGANIZATION"})
    return events, next(iter(org_ids))


@router.get("/series")
async def public_discussion_series(session: AsyncSession = Depends(get_session),
    limit: int = Query(default=30, ge=1, le=100), offset: int = Query(default=0, ge=0, le=10000)):
    series_rows = (await session.execute(select(DiscussionSeries).where(DiscussionSeries.status == "published")
        .order_by(DiscussionSeries.updated_at.desc(), DiscussionSeries.id.desc()).offset(offset).limit(limit))).scalars().all()
    ids = [int(row.id) for row in series_rows]
    grouped: dict[int, list[tuple[DiscussionSeriesEvent, Event]]] = {item: [] for item in ids}
    if ids:
        rows = (await session.execute(select(DiscussionSeriesEvent, Event)
            .join(Event, Event.id == DiscussionSeriesEvent.event_id)
            .where(DiscussionSeriesEvent.series_id.in_(ids), Event.archived.is_(False),
                   Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED)))
            .order_by(DiscussionSeriesEvent.series_id, DiscussionSeriesEvent.position))).all()
        for link, event in rows:
            grouped[int(link.series_id)].append((link, event))
    items = []
    for series in series_rows:
        pairs = grouped.get(int(series.id), [])
        if len(pairs) < 2:
            continue
        items.append({"id": int(series.id), "slug": series.slug, "title": series.title,
            "description": series.description, "event_count": len(pairs),
            "upcoming_count": sum(1 for _, event in pairs if event.status == EventStatus.PUBLISHED),
            "events": [{"id": int(event.id), "title": event.title, "date": event.event_date_label,
                        "date_iso": event.event_date_iso.isoformat() if event.event_date_iso else None,
                        "city": event.city, "status": event.status.value if hasattr(event.status, "value") else str(event.status)}
                       for _, event in pairs]})
    return {"items": items, "total": len(items), "limit": limit, "offset": offset}


@router.get("/series/{slug}")
async def public_discussion_series_detail(slug: str, session: AsyncSession = Depends(get_session)):
    series = (await session.execute(select(DiscussionSeries).where(
        DiscussionSeries.slug == slug, DiscussionSeries.status == "published"))).scalar_one_or_none()
    if series is None:
        raise HTTPException(404, detail={"code": "SERIES_NOT_FOUND"})
    rows = (await session.execute(select(Event).join(DiscussionSeriesEvent, DiscussionSeriesEvent.event_id == Event.id)
        .where(DiscussionSeriesEvent.series_id == series.id, Event.archived.is_(False),
               Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED)))
        .order_by(DiscussionSeriesEvent.position))).scalars().all()
    if len(rows) < 2:
        raise HTTPException(404, detail={"code": "SERIES_NOT_FOUND"})
    used_rows = (await session.execute(
        select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
        .where(Booking.event_id.in_([int(event.id) for event in rows]),
               Booking.status.in_(ACTIVE_BOOKING_STATUSES))
        .group_by(Booking.event_id)
    )).all()
    used_by_event = {int(event_id): int(used or 0) for event_id, used in used_rows}
    payload_events = [_event_read_payload(event, used_by_event.get(int(event.id), 0)) for event in rows]
    return {"id": int(series.id), "slug": series.slug, "title": series.title,
            "description": series.description, "events": payload_events}


@router.get("/staff/host/series")
async def host_discussion_series_list(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    series_rows = (await session.execute(select(DiscussionSeries).where(
        DiscussionSeries.host_user_id == user.id, DiscussionSeries.status != "archived")
        .order_by(DiscussionSeries.updated_at.desc(), DiscussionSeries.id.desc()))).scalars().all()
    series_ids = [int(series.id) for series in series_rows]
    event_rows = (await session.execute(select(DiscussionSeriesEvent.series_id, Event.id, Event.title)
        .join(Event, Event.id == DiscussionSeriesEvent.event_id)
        .where(DiscussionSeriesEvent.series_id.in_(series_ids) if series_ids else False)
        .order_by(DiscussionSeriesEvent.series_id, DiscussionSeriesEvent.position))).all()
    events_by_series: dict[int, list[dict[str, object]]] = {}
    for series_id, event_id, title in event_rows:
        events_by_series.setdefault(int(series_id), []).append({"id": int(event_id), "title": title})
    results = []
    for series in series_rows:
        events = events_by_series.get(int(series.id), [])
        results.append({"id": int(series.id), "slug": series.slug, "title": series.title,
            "description": series.description, "event_ids": [int(row["id"]) for row in events],
            "events": events})
    return {"items": results, "total": len(results)}


@router.post("/staff/host/series", status_code=201)
async def host_create_discussion_series(payload: HostDiscussionSeriesInput, user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session)):
    events, organization_id = await _validate_host_series_events(session, user, payload.event_ids)
    base = _series_slug_base(payload.title)
    slug = base
    suffix = 2
    while await session.scalar(select(DiscussionSeries.id).where(DiscussionSeries.slug == slug).limit(1)):
        slug = f"{base[:110]}-{suffix}"
        suffix += 1
    series = DiscussionSeries(host_user_id=user.id, organization_id=organization_id, slug=slug,
        title=payload.title, description=payload.description, status="published")
    session.add(series)
    await session.flush()
    for position, event in enumerate(events):
        session.add(DiscussionSeriesEvent(series_id=series.id, event_id=event.id, position=position))
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=organization_id,
        action="host.discussion_series_created", target_type="discussion_series", target_id=str(series.id),
        metadata_json={"event_count": len(events)}))
    await session.commit()
    return {"id": int(series.id), "slug": series.slug, "title": series.title}


@router.patch("/staff/host/series/{series_id}")
async def host_update_discussion_series(series_id: int, payload: HostDiscussionSeriesInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    series = (await session.execute(select(DiscussionSeries).where(
        DiscussionSeries.id == series_id, DiscussionSeries.host_user_id == user.id,
        DiscussionSeries.status == "published").with_for_update())).scalar_one_or_none()
    if series is None:
        raise HTTPException(404, detail={"code": "SERIES_NOT_FOUND"})
    events, organization_id = await _validate_host_series_events(session, user, payload.event_ids)
    series.title = payload.title
    series.description = payload.description
    series.organization_id = organization_id
    base = _series_slug_base(payload.title)
    if base != series.slug:
        slug = base
        suffix = 2
        while await session.scalar(select(DiscussionSeries.id).where(DiscussionSeries.slug == slug,
                DiscussionSeries.id != series.id).limit(1)):
            slug = f"{base[:110]}-{suffix}"
            suffix += 1
        series.slug = slug
    await session.execute(delete(DiscussionSeriesEvent).where(DiscussionSeriesEvent.series_id == series.id))
    for position, event in enumerate(events):
        session.add(DiscussionSeriesEvent(series_id=series.id, event_id=event.id, position=position))
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=organization_id,
        action="host.discussion_series_updated", target_type="discussion_series", target_id=str(series.id),
        metadata_json={"event_count": len(events)}))
    await session.commit()
    return {"id": int(series.id), "slug": series.slug, "title": series.title}


@router.delete("/staff/host/series/{series_id}")
async def host_archive_discussion_series(series_id: int, user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    series = (await session.execute(select(DiscussionSeries).where(
        DiscussionSeries.id == series_id, DiscussionSeries.host_user_id == user.id,
        DiscussionSeries.status == "published").with_for_update())).scalar_one_or_none()
    if series is None:
        raise HTTPException(404, detail={"code": "SERIES_NOT_FOUND"})
    series.status = "archived"
    session.add(PlatformAuditLog(actor_user_id=user.id, organization_id=series.organization_id,
        action="host.discussion_series_archived", target_type="discussion_series", target_id=str(series.id),
        metadata_json={"archived": True}))
    await session.commit()
    return {"id": int(series.id), "status": "archived"}


@router.get("/staff/host/payments")
async def host_payment_records(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session),
    event_id: int | None = Query(default=None, gt=0), limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0, le=100000)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    stmt = select(Payment, Booking, Event, User).join(Booking, Booking.id == Payment.booking_id).join(
        Event, Event.id == Booking.event_id).join(User, User.id == Booking.booked_by_user_id).where(Event.host_id == user.id)
    if event_id:
        stmt = stmt.where(Event.id == event_id)
    total_stmt = select(func.count(Payment.id)).join(Booking, Booking.id == Payment.booking_id).join(
        Event, Event.id == Booking.event_id).where(Event.host_id == user.id)
    if event_id:
        total_stmt = total_stmt.where(Event.id == event_id)
    total = int(await session.scalar(total_stmt) or 0)
    rows = (await session.execute(stmt.order_by(Payment.created_at.desc(), Payment.id.desc()).offset(offset).limit(limit))).all()
    event_cache: dict[int, Event] = {}
    items = []
    for payment, booking, event, registrant in rows:
        if event.id not in event_cache:
            event_cache[event.id] = await _authorize_host_owned_event(session, user, event.id)
        items.append({"id": payment.id, "booking_id": booking.id, "event_id": event.id,
            "event_title": event.title, "booking_status": booking.status.value if hasattr(booking.status, "value") else str(booking.status),
            "payment_status": payment.status.value if hasattr(payment.status, "value") else str(payment.status),
            "registrant_name": registrant.display_name or registrant.first_name or registrant.telegram_username or f"Member {registrant.id}",
            "participant_count": booking.participant_count, "amount": int(payment.amount or 0),
            "receipt_text": payment.receipt_text, "receipt_file_name": payment.receipt_file_name,
            "has_file": bool(payment.receipt_file), "created_at": payment.receipt_uploaded_at or payment.created_at})
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/staff/host/payments/{payment_id}/receipt")
async def host_download_own_receipt(payment_id: int, user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    row = (await session.execute(select(Payment, Booking, Event).join(
        Booking, Booking.id == Payment.booking_id).join(Event, Event.id == Booking.event_id).where(
            Payment.id == payment_id, Event.host_id == user.id))).one_or_none()
    if row is None:
        raise HTTPException(404, detail={"code": "RECEIPT_NOT_FOUND"})
    payment, booking, event = row
    await _authorize_host_owned_event(session, user, event.id)
    if not payment.receipt_file:
        raise HTTPException(404, detail={"code": "RECEIPT_NOT_FOUND"})
    from fastapi.responses import FileResponse
    root = Path(settings.upload_dir).resolve(); path = Path(payment.receipt_file).resolve()
    try:
        path.relative_to(root)
    except ValueError:
        raise HTTPException(404, detail={"code": "RECEIPT_NOT_FOUND"})
    if not path.is_file():
        raise HTTPException(404, detail={"code": "RECEIPT_NOT_FOUND"})
    media = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png"}.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(path, media_type=media, filename=payment.receipt_file_name or path.name,
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@router.get("/staff/host/reviews")
async def host_reviews(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session),
    limit: int = Query(default=100, ge=1, le=200), offset: int = Query(default=0, ge=0, le=100000)):
    if str(getattr(user.role, "value", user.role)) != "host":
        raise HTTPException(403, detail={"code": "HOST_WORKSPACE_REQUIRED"})
    stmt = select(Review, Event, User).join(Event, Event.id == Review.event_id).join(User, User.id == Review.user_id).where(
        Event.host_id == user.id, Review.status == ModerationStatus.APPROVED)
    total_stmt = select(func.count(Review.id)).join(Event, Event.id == Review.event_id).where(
        Event.host_id == user.id, Review.status == ModerationStatus.APPROVED)
    total = int(await session.scalar(total_stmt) or 0)
    rows = (await session.execute(stmt.order_by(Review.created_at.desc(), Review.id.desc()).offset(offset).limit(limit))).all()
    # Reviews are visible only for events the host can currently manage.
    event_cache: dict[int, Event] = {}
    items = []
    for review, event, reviewer in rows:
        if event.id not in event_cache:
            event_cache[event.id] = await _authorize_host_owned_event(session, user, event.id)
        items.append({"id": review.id, "event_id": event.id, "event_title": event.title,
            "rating": review.rating, "discussion_quality": review.discussion_quality,
            "moderator_rating": review.moderator_rating, "topic_relevance": review.topic_relevance,
            "would_attend_again": review.would_attend_again,
            "text": review.text, "created_at": review.created_at,
            "reviewer_name": reviewer.display_name or reviewer.first_name or "Panel Flow member"})
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/staff/payments")
async def staff_pending_payments(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session),
                                 limit: int = Query(default=30, ge=1, le=100), offset: int = Query(default=0, ge=0, le=100000)):
    _require_admin(user)
    base = select(Payment).join(Booking, Booking.id == Payment.booking_id).where(
        Payment.status == PaymentStatus.PENDING, Booking.status == RegistrationStatus.PENDING_VERIFICATION,
        or_((Payment.receipt_file.is_not(None) & (Payment.receipt_file != "")), (Payment.receipt_text.is_not(None) & (Payment.receipt_text != "")))
    )
    total = int(await session.scalar(select(func.count()).select_from(Payment).join(Booking, Booking.id == Payment.booking_id).where(
        Payment.status == PaymentStatus.PENDING, Booking.status == RegistrationStatus.PENDING_VERIFICATION,
        or_((Payment.receipt_file.is_not(None) & (Payment.receipt_file != "")), (Payment.receipt_text.is_not(None) & (Payment.receipt_text != "")))
    )) or 0)
    rows = (await session.execute(base.options(selectinload(Payment.booking).selectinload(Booking.event),
        selectinload(Payment.booking).selectinload(Booking.booked_by)).order_by(Payment.created_at.asc(), Payment.id.asc()).offset(offset).limit(limit))).scalars().all()
    return {"items": [{"id": p.id, "booking_id": p.booking.id, "event_id": p.booking.event.id,
                       "event_title": p.booking.event.title, "event_date": p.booking.event.event_date_label,
                       "user_name": p.booking.booked_by.display_name or p.booking.booked_by.first_name or str(p.booking.booked_by.telegram_id),
                       "telegram_username": p.booking.booked_by.telegram_username,
                       "participant_count": p.booking.participant_count, "amount": int(p.amount or 0),
                       "receipt_text": p.receipt_text, "receipt_file_name": p.receipt_file_name,
                       "has_file": bool(p.receipt_file), "receipt_token": receipt_fingerprint(p)[:12],
                       "submitted_at": p.receipt_uploaded_at or p.created_at} for p in rows], "total": total}


@router.get("/staff/payments/{payment_id}/receipt")
async def staff_download_receipt(payment_id: int, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    from fastapi.responses import FileResponse
    payment = (await session.execute(select(Payment).where(Payment.id == payment_id))).scalar_one_or_none()
    if payment is None or not payment.receipt_file:
        raise HTTPException(status_code=404, detail={"code": "RECEIPT_NOT_FOUND"})
    root = Path(settings.upload_dir).resolve()
    path = Path(payment.receipt_file).resolve()
    try:
        path.relative_to(root)
    except ValueError:
        raise HTTPException(status_code=404, detail={"code": "RECEIPT_NOT_FOUND"})
    if not path.is_file():
        raise HTTPException(status_code=404, detail={"code": "RECEIPT_NOT_FOUND"})
    suffix = path.suffix.lower()
    media = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png"}.get(suffix, "application/octet-stream")
    return FileResponse(path, media_type=media, filename=payment.receipt_file_name or path.name, headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@router.post("/staff/payments/{payment_id}/review")
async def staff_review_payment(payment_id: int, payload: PaymentReviewInput, user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    if payload.decision == "rejected" and (payload.reason_category not in {"not_received", "amount_mismatch", "unclear", "duplicate", "other"} or not (payload.reason_text or "").strip()):
        raise HTTPException(status_code=422, detail={"code": "REJECTION_REASON_REQUIRED"})
    payment, booking, event = await lock_payment_review_rows(session, payment_id)
    if not payment or not booking or not event:
        raise HTTPException(status_code=404, detail={"code": "PAYMENT_NOT_FOUND"})
    if (payment.status != PaymentStatus.PENDING or booking.status != RegistrationStatus.PENDING_VERIFICATION
        or receipt_fingerprint(payment)[:12] != payload.receipt_token or not (payment.receipt_file or payment.receipt_text)):
        raise HTTPException(status_code=409, detail={"code": "RECEIPT_CHANGED", "message": "رسید تغییر کرده یا قبلاً بررسی شده است؛ فهرست را تازه کنید."})
    approve = payload.decision == "approved"
    if approve and (event.status != EventStatus.PUBLISHED or event.archived):
        raise HTTPException(status_code=409, detail={"code": "EVENT_NOT_ACTIVE"})
    now = utc_now_naive()
    payment.status = PaymentStatus.APPROVED if approve else PaymentStatus.REJECTED
    payment.reviewed_at = now
    payment.reviewed_by = user.id
    booking.status = RegistrationStatus.CONFIRMED if approve else RegistrationStatus.REJECTED
    booking.confirmed_at = now if approve else None
    booking.expires_at = None
    if approve:
        await record_confirmed_booking(session, booking, confirmed_at=now)
        if int(payment.amount or 0) > 0:
            await record_paid_panel_award(session, booking, payment)
    prior_attempts = int(await session.scalar(select(func.count(PaymentReviewAttempt.id)).where(PaymentReviewAttempt.payment_id == payment_id)) or 0)
    fingerprint = receipt_fingerprint(payment)
    session.add(PaymentReviewAttempt(booking_id=booking.id, payment_id=payment.id, receipt_fingerprint=fingerprint,
        decision=payload.decision, reason_category=None if approve else payload.reason_category,
        reason_text=None if approve else payload.reason_text.strip(), reviewer_telegram_id=user.telegram_id,
        attempt_number=prior_attempts + 1, reviewed_at=now))
    session.add(PlatformAuditLog(
        actor_user_id=user.id, organization_id=event.organization_id,
        action="payment.approved" if approve else "payment.rejected",
        target_type="payment", target_id=str(payment.id),
        metadata_json={"booking_id": int(booking.id), "event_id": int(event.id),
                       "decision": payload.decision,
                       "reason_category": None if approve else payload.reason_category},
    ))
    await write_admin_action(session, actor_telegram_id=user.telegram_id,
        action="receipt_approved" if approve else "receipt_rejected", entity_type="payment", entity_id=payment.id,
        details={"booking_id": booking.id, "event_id": event.id, "reason_category": payload.reason_category,
                 "reason": payload.reason_text})
    owner_id = booking.booked_by_user_id
    await session.commit()
    if approve:
        try:
            await unlock_eligible_achievements(session, int((await session.scalar(select(User.telegram_id).where(User.id == owner_id))) or 0))
            await session.commit()
        except Exception:
            logger.exception("Achievement evaluation failed after website payment review")
    return {"payment_id": payment_id, "booking_id": booking.id, "decision": payload.decision,
            "booking_status": booking.status.value if hasattr(booking.status, "value") else str(booking.status),
            "message": "تغییر وضعیت ثبت شد. وضعیت در ربات نیز به‌روز است."}


@router.get("/staff/reviews")
async def staff_reviews(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    rows = (await session.execute(select(Review).where(
        Review.status == ModerationStatus.PENDING).order_by(Review.created_at.asc()).limit(100))).scalars().all()
    result = []
    for review in rows:
        event = await session.get(Event, review.event_id) if review.event_id else None
        reviewer = await session.get(User, review.user_id)
        result.append({"id": review.id, "event_id": review.event_id, "event_title": event.title if event else "پنل حذف‌شده",
                       "user_name": (reviewer.display_name or reviewer.first_name) if reviewer else "کاربر",
                       "rating": review.rating, "discussion_quality": review.discussion_quality,
                       "moderator_rating": review.moderator_rating, "topic_relevance": review.topic_relevance,
                       "would_attend_again": review.would_attend_again,
                       "text": review.text, "created_at": review.created_at})
    return {"items": result}


@router.patch("/staff/reviews/{review_id}")
async def moderate_review(review_id: int, decision: str = Query(pattern="^(approved|rejected)$"), user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    review = (await session.execute(select(Review).where(Review.id == review_id).with_for_update())).scalar_one_or_none()
    if review is None:
        raise HTTPException(status_code=404, detail={"code": "REVIEW_NOT_FOUND"})
    review.status = ModerationStatus(decision)
    event = await session.get(Event, review.event_id) if review.event_id else None
    session.add(PlatformAuditLog(actor_user_id=user.id,
        organization_id=event.organization_id if event else None,
        action=f"review.{decision}", target_type="review", target_id=str(review.id),
        metadata_json={"event_id": review.event_id, "rating": review.rating}))
    await write_admin_action(session, actor_telegram_id=user.telegram_id, action=f"review_{decision}",
                             entity_type="review", entity_id=review.id, details={"event_id": review.event_id})
    await session.commit()
    return {"id": review.id, "status": decision}


@router.get("/staff/users")
async def staff_search_users(q: str = Query(default="", max_length=100), user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session),
                            limit: int = Query(default=25, ge=1, le=100), offset: int = Query(default=0, ge=0, le=100000)):
    _require_admin(user)
    stmt = select(User).order_by(User.created_at.desc())
    if q.strip():
        term = f"%{q.strip()}%"
        filters = [User.display_name.ilike(term), User.first_name.ilike(term), User.last_name.ilike(term), User.telegram_username.ilike(term)]
        if q.strip().isdigit():
            filters.append(User.telegram_id == int(q.strip()))
        stmt = stmt.where(or_(*filters))
    rows = (await session.execute(stmt.offset(offset).limit(limit))).scalars().all()
    return {"items": [{"id": u.id, "telegram_id": u.telegram_id, "name": u.display_name or " ".join(filter(None, [u.first_name, u.last_name])),
                       "username": u.telegram_username, "phone_number": u.phone_number, "role": _role(u),
                       "created_at": u.created_at, "confirmed_bookings": u.lifetime_confirmed_bookings} for u in rows]}


@router.patch("/staff/platform/users/{target_user_id}/role")
async def platform_update_user_role(target_user_id: int, payload: PlatformRoleUpdateInput,
    user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_superadmin(user)
    target = await session.get(User, target_user_id, with_for_update=True)
    if target is None:
        raise HTTPException(404, detail={"code": "USER_NOT_FOUND"})
    current_role = str(getattr(target.role, "value", target.role))
    if current_role == "host":
        raise HTTPException(409, detail={"code": "HOST_ROLE_REQUIRES_HOST_APPROVAL_WORKFLOW"})
    if int(target.telegram_id) in settings.super_admin_only_id_set | settings.admin_id_set:
        if payload.role != _role(target):
            raise HTTPException(409, detail={"code": "ROLE_MANAGED_BY_ENVIRONMENT", "message": "This account's role is assigned through the deployment allow-list."})
        return {"id": target.id, "role": _role(target), "unchanged": True}
    if target.id == user.id and payload.role != "super_admin":
        raise HTTPException(409, detail={"code": "CANNOT_DEMOTE_CURRENT_SUPERADMIN"})
    if current_role == "super_admin" and payload.role != "super_admin":
        other_superadmins = int(await session.scalar(select(func.count(User.id)).where(
            User.id != target.id, User.role == UserRole.SUPER_ADMIN)) or 0)
        configured_superadmins = settings.super_admin_only_id_set - {int(target.telegram_id)}
        if other_superadmins == 0 and not configured_superadmins:
            raise HTTPException(409, detail={"code": "LAST_SUPERADMIN_CANNOT_BE_DEMOTED"})
    target.role = UserRole(payload.role)
    target.updated_at = utc_now_naive()
    session.add(PlatformAuditLog(actor_user_id=user.id, action="platform.user_role_updated",
        target_type="user", target_id=str(target.id), metadata_json={"from_role": current_role, "to_role": payload.role,
            "target_telegram_id": int(target.telegram_id)}))
    await session.commit()
    return {"id": target.id, "role": payload.role, "updated": True}


@router.get("/staff/audit-logs")
async def staff_audit_logs(
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0, le=10_000),
    action: str | None = Query(default=None, max_length=100),
    user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session),
):
    """Merge website audit records and legacy Telegram admin actions safely."""
    _require_superadmin(user)
    # Some website-admin operations are already written to both ledgers. Exclude
    # those mirrors so the unified view shows one entry per decision.
    mirrored_admin_actions = {
        "website_event_created", "website_event_updated", "receipt_approved",
        "receipt_rejected", "review_approved", "review_rejected",
    }
    platform_filter = [PlatformAuditLog.action == action.strip()] if action else []
    admin_filter = [AdminAction.action == action.strip()] if action else [
        AdminAction.action.notin_(mirrored_admin_actions)
    ]
    platform_total = int(await session.scalar(
        select(func.count(PlatformAuditLog.id)).where(*platform_filter)
    ) or 0)
    admin_total = int(await session.scalar(
        select(func.count(AdminAction.id)).where(*admin_filter)
    ) or 0)
    # Both sources are sorted independently, then merged. Capping the look-ahead
    # keeps pagination bounded while supporting the current admin UI's first page.
    fetch_limit = min(offset + limit, 10_000)
    platform_rows = (await session.execute(
        select(PlatformAuditLog, User).outerjoin(User, User.id == PlatformAuditLog.actor_user_id)
        .where(*platform_filter).order_by(PlatformAuditLog.created_at.desc(), PlatformAuditLog.id.desc())
        .limit(fetch_limit)
    )).all() if fetch_limit else []
    admin_rows = (await session.execute(
        select(AdminAction, User).outerjoin(User, User.id == AdminAction.actor_user_id)
        .where(*admin_filter).order_by(AdminAction.created_at.desc(), AdminAction.id.desc())
        .limit(fetch_limit)
    )).all() if fetch_limit else []

    safe_metadata_keys = {
        "event_id", "booking_id", "payment_id", "from_role", "to_role", "decision",
        "rating", "status", "organization_id", "brand_id", "reason_category",
    }
    items = []
    for log, actor in platform_rows:
        raw = log.metadata_json if isinstance(log.metadata_json, dict) else {}
        safe_metadata = {key: raw[key] for key in safe_metadata_keys if key in raw}
        items.append({
            "id": f"platform:{int(log.id)}", "action": log.action, "source": "website",
            "target_type": log.target_type, "target_id": log.target_id,
            "organization_id": log.organization_id,
            "actor_name": ((actor.display_name or actor.first_name or actor.telegram_username)
                           if actor else "System"),
            "created_at": log.created_at, "metadata": safe_metadata,
        })
    for log, actor in admin_rows:
        items.append({
            "id": f"telegram:{int(log.id)}", "action": log.action, "source": "telegram",
            "target_type": log.entity_type, "target_id": str(log.entity_id) if log.entity_id is not None else None,
            "organization_id": None,
            "actor_name": ((actor.display_name or actor.first_name or actor.telegram_username)
                           if actor else "Administrator"),
            "created_at": log.created_at, "metadata": {},
        })
    items.sort(key=lambda item: (
        item["created_at"].isoformat() if hasattr(item["created_at"], "isoformat") else str(item["created_at"] or ""),
        str(item["id"]),
    ), reverse=True)
    page = items[offset:offset + limit]
    return {"items": page, "total": platform_total + admin_total, "limit": limit, "offset": offset}


@router.get("/staff/topics")
async def staff_pending_topics(user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    rows = (await session.execute(select(TopicSuggestion).where(TopicSuggestion.status == "pending")
                                  .order_by(TopicSuggestion.created_at.asc()).limit(100))).scalars().all()
    result = []
    for row in rows:
        owner = await session.get(User, row.user_id)
        result.append({"id": row.id, "title": row.title, "user_name": owner.display_name if owner else "کاربر", "created_at": row.created_at})
    return {"items": result}


@router.patch("/staff/topics/{topic_id}")
async def moderate_topic(topic_id: int, decision: str = Query(pattern="^(approved|rejected)$"), user: User = Depends(get_current_api_user), session: AsyncSession = Depends(get_session)):
    _require_admin(user)
    row = (await session.execute(select(TopicSuggestion).where(TopicSuggestion.id == topic_id).with_for_update())).scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail={"code": "TOPIC_NOT_FOUND"})
    row.status = decision
    row.moderator_telegram_id = user.telegram_id
    row.moderated_at = utc_now_naive()
    await session.commit()
    return {"id": topic_id, "status": decision}
