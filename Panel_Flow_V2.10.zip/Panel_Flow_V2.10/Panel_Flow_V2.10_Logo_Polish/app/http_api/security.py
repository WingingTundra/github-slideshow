from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qsl

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class InvalidTelegramInitData(ValueError):
    """Telegram Mini App initData is missing, expired, or fails verification."""


class InvalidAccessToken(ValueError):
    """Panel Flow API access token is invalid or expired."""


@dataclass(frozen=True)
class VerifiedTelegramInitData:
    telegram_id: int
    auth_date: int
    user_data: dict[str, Any]


# Telegram's currently published production Ed25519 public key for third-party
# Mini App initData validation. This is public material, not a secret. See:
# https://core.telegram.org/bots/webapps#validating-data-for-third-party-use
TELEGRAM_PRODUCTION_PUBLIC_KEY_HEX = "e7bf03a2fa4602af4580703d88dda5bb59f32ed8b02a56c187fe7d34caed242d"


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64url_decode(value: str) -> bytes:
    if not value:
        raise ValueError("invalid base64url")
    unpadded = value.rstrip("=")
    padding_length = len(value) - len(unpadded)
    if padding_length > 2 or "=" in unpadded or any(
        ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_" for ch in unpadded
    ):
        raise ValueError("invalid base64url")
    return base64.urlsafe_b64decode(unpadded + "=" * (-len(unpadded) % 4))


def validate_telegram_init_data(
    init_data: str,
    *,
    bot_id: int | None,
    max_age_seconds: int = 900,
    now: int | None = None,
    future_tolerance_seconds: int = 60,
    public_key_hex: str = TELEGRAM_PRODUCTION_PUBLIC_KEY_HEX,
) -> VerifiedTelegramInitData:
    """Verify raw Telegram Mini App initData with Telegram's Ed25519 signature.

    This third-party validation scheme deliberately avoids giving the HTTP API
    container the privileged BOT_TOKEN secret. Pass raw ``initData`` (never the
    untrusted parsed ``initDataUnsafe`` object) from the browser.
    """
    if not isinstance(init_data, str) or not init_data or len(init_data) > 16_384:
        raise InvalidTelegramInitData("invalid initData length")
    if bot_id is None or int(bot_id) <= 0:
        raise InvalidTelegramInitData("Telegram bot ID is not configured")

    try:
        parsed = parse_qsl(init_data, keep_blank_values=True, strict_parsing=True, max_num_fields=100)
    except (ValueError, UnicodeError) as exc:
        raise InvalidTelegramInitData("malformed initData") from exc
    params: dict[str, str] = {}
    for key, value in parsed:
        if not key or key in params:
            raise InvalidTelegramInitData("duplicate or empty initData key")
        params[key] = value

    supplied_hash = params.get("hash", "")
    supplied_signature = params.get("signature", "")
    if len(supplied_hash) != 64 or not supplied_signature:
        raise InvalidTelegramInitData("missing or malformed hash/signature")

    # Telegram's third-party signature data-check-string starts with
    # '<bot_id>:WebAppData\n' and excludes both hash and signature.
    data_fields = "\n".join(
        f"{key}={value}" for key, value in sorted(params.items())
        if key not in {"hash", "signature"}
    )
    data_check_string = f"{int(bot_id)}:WebAppData\n{data_fields}".encode("utf-8")
    try:
        public_key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key_hex))
        signature = _b64url_decode(supplied_signature)
        public_key.verify(signature, data_check_string)
    except (ValueError, InvalidSignature) as exc:
        raise InvalidTelegramInitData("signature verification failed") from exc

    try:
        auth_date = int(params["auth_date"])
        user_data = json.loads(params["user"])
        telegram_id = int(user_data["id"])
    except (KeyError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise InvalidTelegramInitData("missing or malformed user/auth_date") from exc
    if not isinstance(user_data, dict) or auth_date <= 0 or telegram_id <= 0:
        raise InvalidTelegramInitData("invalid user/auth_date values")

    current = int(time.time()) if now is None else int(now)
    if auth_date > current + max(0, int(future_tolerance_seconds)):
        raise InvalidTelegramInitData("auth_date is in the future")
    if current - auth_date > max(1, int(max_age_seconds)):
        raise InvalidTelegramInitData("initData has expired")

    return VerifiedTelegramInitData(telegram_id=telegram_id, auth_date=auth_date, user_data=user_data)


def issue_access_token(
    *,
    user_id: int,
    telegram_id: int,
    secret: str,
    ttl_seconds: int = 1800,
    now: int | None = None,
) -> tuple[str, int]:
    """Issue a short-lived HMAC-signed bearer token with no external dependency."""
    if not secret or len(secret.encode("utf-8")) < 32:
        raise ValueError("API_TOKEN_SECRET must contain at least 32 bytes")
    if int(user_id) <= 0 or int(telegram_id) <= 0:
        raise ValueError("invalid user identifiers")
    issued_at = int(time.time()) if now is None else int(now)
    ttl = max(60, min(int(ttl_seconds), 86_400))
    claims = {
        "iss": "panel-flow-api",
        "aud": "panel-flow-client",
        "sub": str(int(user_id)),
        "tg": int(telegram_id),
        "iat": issued_at,
        "exp": issued_at + ttl,
    }
    body = _b64url_encode(json.dumps(claims, separators=(",", ":"), sort_keys=True).encode("utf-8"))
    signature = hmac.new(secret.encode("utf-8"), body.encode("ascii"), hashlib.sha256).digest()
    return f"{body}.{_b64url_encode(signature)}", ttl


def verify_access_token(token: str, *, secret: str, now: int | None = None) -> dict[str, Any]:
    """Validate signature, issuer, audience, and token timestamps."""
    if not secret or len(secret.encode("utf-8")) < 32:
        raise InvalidAccessToken("API token signing secret is not configured")
    if not isinstance(token, str) or len(token) > 4096 or token.count(".") != 1:
        raise InvalidAccessToken("malformed token")
    body, encoded_signature = token.split(".", 1)
    try:
        received_signature = _b64url_decode(encoded_signature)
        claims = json.loads(_b64url_decode(body))
    except (ValueError, UnicodeError, json.JSONDecodeError) as exc:
        raise InvalidAccessToken("malformed token") from exc
    expected_signature = hmac.new(secret.encode("utf-8"), body.encode("ascii"), hashlib.sha256).digest()
    if not hmac.compare_digest(received_signature, expected_signature):
        raise InvalidAccessToken("invalid token signature")
    if not isinstance(claims, dict) or claims.get("iss") != "panel-flow-api" or claims.get("aud") != "panel-flow-client":
        raise InvalidAccessToken("invalid token claims")
    try:
        subject = int(claims["sub"])
        telegram_id = int(claims["tg"])
        issued_at = int(claims["iat"])
        expires_at = int(claims["exp"])
    except (KeyError, TypeError, ValueError) as exc:
        raise InvalidAccessToken("missing token claims") from exc
    current = int(time.time()) if now is None else int(now)
    if subject <= 0 or telegram_id <= 0 or issued_at > current + 60 or expires_at <= current or expires_at <= issued_at:
        raise InvalidAccessToken("expired or invalid token timestamps")
    claims["sub"] = subject
    claims["tg"] = telegram_id
    return claims
