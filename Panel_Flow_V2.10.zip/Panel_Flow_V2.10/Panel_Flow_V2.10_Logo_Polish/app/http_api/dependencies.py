from __future__ import annotations

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.db.models import User
from app.db.session import get_session
from app.http_api.security import InvalidAccessToken, verify_access_token
from app.services.authorization import active_account_restriction

_bearer_scheme = HTTPBearer(auto_error=False)


async def get_current_api_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    session: AsyncSession = Depends(get_session),
) -> User:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "AUTHENTICATION_REQUIRED", "message": "A valid bearer token is required."},
            headers={"WWW-Authenticate": "Bearer"},
        )
    try:
        claims = verify_access_token(credentials.credentials, secret=settings.api_token_secret)
    except InvalidAccessToken as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "INVALID_ACCESS_TOKEN", "message": "The access token is invalid or expired."},
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    result = await session.execute(select(User).where(
        User.id == int(claims["sub"]),
        User.telegram_id == int(claims["tg"]),
    ))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "ACCOUNT_NOT_FOUND", "message": "The account is no longer available."},
            headers={"WWW-Authenticate": "Bearer"},
        )
    # Access tokens are not a way around a newly applied block or suspension.
    if await active_account_restriction(user.telegram_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "ACCOUNT_RESTRICTED", "message": "This account is not permitted to access the API."},
        )
    return user
