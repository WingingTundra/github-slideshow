from __future__ import annotations

import logging
import base64
from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config import settings
from app.db.models import Booking, User
from app.db.session import get_session
from app.display_utils import has_end_time_label
from app.http_api.dependencies import get_current_api_user
from app.http_api.schemas import (
    ApiUserRead,
    MyBookingPage,
    MyBookingRead,
    PublicEventPage,
    PublicEventRead,
    TelegramLoginRequest,
    TelegramLoginResponse,
)
from app.http_api.security import InvalidTelegramInitData, issue_access_token, validate_telegram_init_data
from app.services.public_events import list_public_event_payloads
from app.services.authorization import active_account_restriction

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1", tags=["Panel Flow API v1"])


def _user_payload(user: User) -> dict:
    stored_role = user.role.value if hasattr(user.role, "value") else str(user.role)
    if int(user.telegram_id) in settings.super_admin_only_id_set or stored_role == "super_admin":
        role = "super_admin"
    elif int(user.telegram_id) in settings.admin_id_set or stored_role == "admin":
        role = "admin"
    else:
        role = stored_role
    return {
        "id": int(user.id),
        "display_name": user.display_name,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "telegram_username": user.telegram_username,
        "phone_number": user.phone_number,
        "role": role,
        "created_at": user.created_at,
    }



@router.get("/health")
async def versioned_health():
    return {"status": "ok", "api_version": "v1"}


@router.get("/events", response_model=PublicEventPage)
async def list_public_events(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0, le=1_000_000),
    city_id: int | None = Query(default=None, gt=0),
    q: str = Query(default="", max_length=100),
    topic: str | None = Query(default=None, max_length=50),
    organization_id: int | None = Query(default=None, gt=0),
    language: str | None = Query(default=None, max_length=80),
    event_type: str | None = Query(default=None, pattern="^(physical|online|hybrid)$"),
    date_from: date | None = Query(default=None),
    date_to: date | None = Query(default=None),
    availability: str | None = Query(default=None, pattern="^(open|waitlist)$"),
    sort: str = Query(default="newest", pattern="^(newest|upcoming|price|title|relevance)$"),
    cursor: str | None = Query(default=None, max_length=180),
    session: AsyncSession = Depends(get_session),
):
    """Return only published, non-archived public events, with stable pagination."""
    if date_from and date_to and date_to < date_from:
        raise HTTPException(status_code=422, detail={"code": "INVALID_DATE_RANGE", "message": "The end date must not be earlier than the start date."})
    cursor_value = None
    if cursor:
        if sort != "newest" or offset:
            raise HTTPException(status_code=422, detail={"code": "CURSOR_REQUIRES_NEWEST_SORT_AND_ZERO_OFFSET"})
        try:
            raw = base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4)).decode("utf-8")
            timestamp_raw, event_id_raw = raw.rsplit("|", 1)
            cursor_value = (datetime.fromisoformat(timestamp_raw), int(event_id_raw))
            if cursor_value[1] <= 0:
                raise ValueError("invalid event id")
        except Exception as exc:
            raise HTTPException(status_code=422, detail={"code": "INVALID_EVENT_CURSOR"}) from exc
    items, total = await list_public_event_payloads(
        session, limit=limit, offset=offset, include_extended=True, city_id=city_id,
        query=q, topic=topic, organization_id=organization_id, language=language,
        event_type=event_type, date_from=date_from, date_to=date_to,
        availability=availability, sort=sort, cursor=cursor_value, include_cursor_metadata=True,
    )
    next_cursor = None
    if items and "_pagination_cursor" in items[-1]:
        marker = items[-1].pop("_pagination_cursor")
        raw_cursor = f"{marker['updated_at']}|{marker['id']}".encode("utf-8")
        next_cursor = base64.urlsafe_b64encode(raw_cursor).decode("ascii").rstrip("=")
    return {"items": items, "total": total, "limit": limit, "offset": offset, "next_cursor": next_cursor}


@router.post("/auth/telegram", response_model=TelegramLoginResponse)
async def authenticate_telegram_mini_app(
    payload: TelegramLoginRequest,
    session: AsyncSession = Depends(get_session),
):
    """Exchange verified Telegram Mini App initData for a short-lived API token.

    Accounts must already exist from the bot's established registration flow. This
    endpoint deliberately does not create accounts or trust client-supplied names.
    """
    if not settings.api_token_secret or len(settings.api_token_secret.encode("utf-8")) < 32 or settings.telegram_bot_id is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"code": "API_AUTH_NOT_CONFIGURED", "message": "API token signing secret or TELEGRAM_BOT_ID is not configured."},
        )
    try:
        identity = validate_telegram_init_data(
            payload.init_data,
            bot_id=settings.telegram_bot_id,
            max_age_seconds=settings.telegram_init_data_max_age_seconds,
        )
    except InvalidTelegramInitData as exc:
        logger.info("Rejected Telegram Mini App authentication request: %s", str(exc))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "INVALID_TELEGRAM_INIT_DATA", "message": "Telegram login data is invalid or expired."},
        ) from exc

    user = (await session.execute(select(User).where(User.telegram_id == identity.telegram_id))).scalar_one_or_none()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "BOT_REGISTRATION_REQUIRED", "message": "Please complete registration with the Panel Flow bot first."},
        )
    if await active_account_restriction(user.telegram_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "ACCOUNT_RESTRICTED", "message": "This account is not permitted to access the API."},
        )
    try:
        token, expires_in = issue_access_token(
            user_id=user.id,
            telegram_id=user.telegram_id,
            secret=settings.api_token_secret,
            ttl_seconds=settings.api_token_ttl_seconds,
        )
    except ValueError as exc:
        # Config validation belongs in startup as well; retain a safe API error
        # rather than letting an operator mistake become an internal stack trace.
        logger.error("Could not issue API access token: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"code": "API_AUTH_NOT_CONFIGURED", "message": "API token signing is not configured correctly."},
        ) from exc
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": expires_in,
        "user": _user_payload(user),
    }


@router.get("/me", response_model=ApiUserRead)
async def read_my_profile(user: User = Depends(get_current_api_user)):
    """Read the authenticated account's own profile; no arbitrary user IDs accepted."""
    return _user_payload(user)


@router.get("/me/bookings", response_model=MyBookingPage)
async def read_my_bookings(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0, le=1_000_000),
    user: User = Depends(get_current_api_user),
    session: AsyncSession = Depends(get_session),
):
    """List the authenticated user's own bookings without receipt contents or paths."""
    base_filter = Booking.booked_by_user_id == int(user.id)
    total = int((await session.execute(select(func.count(Booking.id)).where(base_filter))).scalar_one())
    rows = (await session.execute(
        select(Booking)
        .options(selectinload(Booking.event))
        .where(base_filter)
        .order_by(Booking.created_at.desc(), Booking.id.desc())
        .offset(offset)
        .limit(limit)
    )).scalars().all()
    items = []
    for booking in rows:
        event = booking.event
        if event is None:
            # Legacy integrity anomaly: skip rather than leaking a partial record or
            # causing the entire self-service page to fail.
            continue
        booking_status = booking.status.value if hasattr(booking.status, "value") else str(booking.status)
        items.append({
            "id": int(booking.id),
            "event_id": int(event.id),
            "event_title": event.title,
            "event_day": event.event_day_label,
            "event_date": event.event_date_label,
            "event_start_time": event.start_time_label,
            "event_end_time": event.end_time_label if has_end_time_label(event.end_time_label) else None,
            "event_date_iso": event.event_date_iso,
            "event_type": event.event_type or "physical",
            "event_venue": event.venue,
            "event_city": event.city,
            "participant_count": int(booking.participant_count),
            "total_amount": int(Decimal(booking.total_amount)),
            "status": booking_status,
            "created_at": booking.created_at,
            "confirmed_at": booking.confirmed_at,
            "cancelled_at": booking.cancelled_at,
            "cancellation_resolution": getattr(booking, "cancellation_resolution", None),
        })
    return {"items": items, "total": total, "limit": limit, "offset": offset}
