from __future__ import annotations

from contextlib import asynccontextmanager
from html import escape
import re
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Request, Response, status
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.init import init_db
from app.http_api.health_logging import install_successful_health_filter
from app.config import settings
from app.db.session import get_session
from app.db.models import City, Event, EventStatus, NotificationOutbox, EventNotificationDelivery
from app.services.public_events import list_public_event_payloads
from app.http_api.routes import router as api_v1_router
from app.http_api.website_routes import router as website_router
from app.http_api.organization_routes import router as organization_router
from app.http_api.host_application_routes import router as host_application_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    install_successful_health_filter()
    await init_db()
    yield


api = FastAPI(title="Panel Flow API", version="1.0.0", lifespan=lifespan)

# Browser access stays disabled until an operator explicitly configures origins.
# Bearer tokens are used instead of cross-origin cookies, so credentials are not
# enabled and wildcard origins are rejected by Settings validation.
if settings.api_cors_origin_list:
    api.add_middleware(
        CORSMiddleware,
        allow_origins=settings.api_cors_origin_list,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
        max_age=600,
    )


@api.get("/health")
async def health():
    return {"status": "ok"}


@api.get("/health/db")
async def health_db(response: Response, session: AsyncSession = Depends(get_session)):
    try:
        await session.execute(select(1))
        return {"status": "ok"}
    except Exception:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        return {"status": "unavailable"}


@api.get("/health/ready")
async def health_ready(response: Response, session: AsyncSession = Depends(get_session)):
    """Readiness probe: report ready only when the database can answer a query."""
    try:
        await session.execute(select(1))
        return {"status": "ready", "database": "ok", "timezone": settings.app_timezone}
    except Exception:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        return {"status": "not_ready", "database": "unavailable"}


@api.get("/health/operational")
async def health_operational(response: Response, session: AsyncSession = Depends(get_session)):
    """Low-cardinality operational signals for a deployment monitor."""
    try:
        await session.execute(select(1))
        pending_outbox = int(await session.scalar(select(func.count(NotificationOutbox.id)).where(
            NotificationOutbox.status == "pending")) or 0)
        processing_outbox = int(await session.scalar(select(func.count(NotificationOutbox.id)).where(
            NotificationOutbox.status == "processing")) or 0)
        failed_outbox = int(await session.scalar(select(func.count(NotificationOutbox.id)).where(
            NotificationOutbox.status == "failed")) or 0)
        failed_deliveries = int(await session.scalar(select(func.count(EventNotificationDelivery.id)).where(
            EventNotificationDelivery.status == "failed")) or 0)
        return {"status": "ok", "timezone": settings.app_timezone,
                "notification_outbox": {"pending": pending_outbox, "processing": processing_outbox, "failed": failed_outbox},
                "failed_event_deliveries": failed_deliveries}
    except Exception:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        return {"status": "unavailable", "timezone": settings.app_timezone}


if settings.api_enabled:
    api.include_router(api_v1_router)
    api.include_router(website_router)
    api.include_router(organization_router)
    api.include_router(host_application_router)

    @api.get("/share/events/{event_id}", response_class=HTMLResponse, include_in_schema=False)
    async def event_social_preview(event_id: int, request: Request,
                                   session: AsyncSession = Depends(get_session)):
        """Serve crawler-readable event metadata, then send browsers to the SPA page."""
        row = (await session.execute(
            select(Event, City).join(City, City.id == Event.city_id).where(
                Event.id == event_id,
                Event.status.in_([EventStatus.PUBLISHED, EventStatus.COMPLETED]),
                Event.archived.is_(False), City.is_active.is_(True),
            )
        )).one_or_none()
        if row is None:
            return HTMLResponse("<!doctype html><title>Panel not found | Panel Flow</title>", status_code=404)
        event, city = row
        configured_site = (settings.panel_flow_website_url or "").strip().rstrip("/")
        configured_parts = urlsplit(configured_site) if configured_site else None
        configured_host = configured_parts.netloc if configured_parts else ""
        if (configured_parts and configured_parts.scheme in {"https", "http"}
                and re.fullmatch(r"[A-Za-z0-9.-]{1,253}(?::[0-9]{1,5})?", configured_host)
                and not configured_parts.username and not configured_parts.password):
            # A configured canonical public URL takes precedence over request headers.
            base = f"{configured_parts.scheme}://{configured_host}"
        else:
            forwarded_host = request.headers.get("x-forwarded-host") or request.headers.get("host") or "localhost"
            # Only accept a DNS hostname (optionally with a port) from the trusted proxy.
            # This value is interpolated into HTML attributes, so reject quotes and all other syntax.
            host = forwarded_host.split(",", 1)[0].strip()
            if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}(?::[0-9]{1,5})?", host):
                host = "localhost"
            forwarded_proto = (request.headers.get("x-forwarded-proto") or request.url.scheme).split(",", 1)[0].strip().lower()
            scheme = "https" if forwarded_proto == "https" else "http"
            base = f"{scheme}://{host}"
        canonical = f"{base}/events/{int(event.id)}"
        image_value = (event.cover_image_url or "").strip()
        if image_value.startswith("https://") or image_value.startswith("http://"):
            image_url = image_value
        elif image_value.startswith("/"):
            image_url = f"{base}{image_value}"
        else:
            image_url = f"{base}/panel-flow-share.svg"
        title = escape(f"{event.title} | Panel Flow")
        description_text = " · ".join(part for part in [event.event_date_label, event.city or city.name_en, event.venue] if part)
        description = escape((event.description or description_text or "Discover this discussion panel on Panel Flow.")[:280])
        image = escape(image_url, quote=True)
        url = escape(canonical, quote=True)
        html = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><meta name="description" content="{description}"><meta name="robots" content="index,follow,max-image-preview:large">
<link rel="canonical" href="{url}"><meta property="og:type" content="website"><meta property="og:site_name" content="Panel Flow"><meta property="og:title" content="{title}"><meta property="og:description" content="{description}"><meta property="og:url" content="{url}"><meta property="og:image" content="{image}"><meta property="og:image:alt" content="{title}"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{title}"><meta name="twitter:description" content="{description}"><meta name="twitter:image" content="{image}">
<meta http-equiv="refresh" content="0;url={url}"></head><body><p><a href="{url}">Open this panel on Panel Flow</a></p></body></html>"""
        return HTMLResponse(html, headers={"Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff"})

    @api.get("/events", include_in_schema=False)
    async def events(session: AsyncSession = Depends(get_session)):
        # Backwards-compatible legacy endpoint. Keep its response fields stable for
        # any client that already consumes /events; new clients should use /api/v1.
        rows, _ = await list_public_event_payloads(
            session, include_extended=False
        )
        return rows
