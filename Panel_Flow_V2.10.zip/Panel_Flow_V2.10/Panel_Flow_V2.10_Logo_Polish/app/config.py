import math
import re
from urllib.parse import urlsplit

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str = ""
    database_url: str = ""
    # Both names are accepted for compatibility; they resolve to the same full-admin set.
    super_admin_ids: str = ""
    admin_ids: str = ""
    panel_flow_channel_url: str = ""
    panel_flow_channel_id: int | None = None
    panel_flow_group_url: str = ""
    panel_flow_instagram_url: str = ""
    panel_flow_website_url: str = ""
    # Platform-wide wall-clock zone. This release intentionally standardizes it.
    app_timezone: str = "Asia/Tehran"
    payment_card_number: str = ""
    payment_account_name: str = ""
    reservation_timeout_minutes: int = 45
    # Durable FSM conversations expire after a bounded inactivity window.
    fsm_storage_ttl_seconds: int = 604800
    # Bounded startup retry policy for transient PostgreSQL DNS/network failures.
    database_startup_max_attempts: int = 5
    database_startup_retry_initial_seconds: float = 1.0
    database_startup_retry_max_seconds: float = 8.0
    # Main application pool and FSM advisory-lock pool are separate so concurrent
    # updates waiting on per-user locks cannot consume every handler DB connection.
    database_pool_size: int = 5
    database_max_overflow: int = 10
    database_pool_timeout_seconds: float = 30.0
    database_lock_pool_size: int = 5
    database_lock_max_overflow: int = 5
    database_lock_pool_timeout_seconds: float = 30.0
    upload_dir: str = "/data/uploads"
    max_upload_mb: int = 10
    # Public profile/event images are constrained and converted to WebP server-side.
    max_image_upload_mb: int = 8
    image_max_dimension: int = 2200
    image_webp_quality: int = 82
    # Upload-storage safety: quota 0 disables the hard quota; minimum free space is independent.
    max_upload_storage_mb: int = 0
    upload_storage_warning_percent: int = 80
    upload_storage_critical_percent: int = 92
    upload_min_free_mb: int = 256
    rate_limit_messages: int = 12
    rate_limit_message_window_seconds: int = 12
    rate_limit_message_burst: int = 4
    rate_limit_callbacks: int = 30
    rate_limit_callback_window_seconds: int = 12
    rate_limit_callback_burst: int = 8
    rate_limit_notice_cooldown_seconds: int = 30
    rate_limit_admin_multiplier: int = 3
    # Stored receipt files/text are purged after this many days; outcomes stay in the DB.
    receipt_retention_days: int = 30
    # Orphan uploads (including superseded receipts and replaced question files).
    upload_orphan_retention_days: int = 30
    api_enabled: bool = True
    # Dedicated signing secret for short-lived web/Mini App bearer tokens. Keep
    # separate from BOT_TOKEN and generate with: python -c "import secrets; print(secrets.token_urlsafe(48))".
    api_token_secret: str = ""
    # Fernet key for encrypting national identity values. Generate with cryptography.fernet.Fernet.generate_key().
    host_identity_encryption_key: str = ""
    api_token_ttl_seconds: int = 1800
    telegram_init_data_max_age_seconds: int = 900
    # Non-secret numeric ID (prefix before the colon in the bot token); avoids
    # passing the privileged BOT_TOKEN to the HTTP API container.
    telegram_bot_id: int | None = None
    # Comma-separated HTTPS origins allowed to call the API from a browser.
    # Empty means CORS is not enabled; never use wildcard origins with credentials.
    api_cors_origins: str = ""
    # Single source of truth for official human support links; value excludes @.
    support_username: str = "PanelFlowAdmin"


    @field_validator("app_timezone")
    @classmethod
    def enforce_platform_timezone(cls, value):
        if str(value).strip() != "Asia/Tehran":
            raise ValueError("APP_TIMEZONE is fixed to Asia/Tehran for the Panel Flow platform")
        return "Asia/Tehran"

    @field_validator("database_pool_size", "database_lock_pool_size")
    @classmethod
    def validate_database_pool_sizes(cls, value):
        if not 1 <= int(value) <= 100:
            raise ValueError("database pool sizes must be between 1 and 100")
        return int(value)

    @field_validator("database_max_overflow", "database_lock_max_overflow")
    @classmethod
    def validate_database_pool_overflow(cls, value):
        if not 0 <= int(value) <= 100:
            raise ValueError("database pool overflow must be between 0 and 100")
        return int(value)

    @field_validator("database_pool_timeout_seconds", "database_lock_pool_timeout_seconds")
    @classmethod
    def validate_database_pool_timeouts(cls, value):
        timeout = float(value)
        if not math.isfinite(timeout) or not 1.0 <= timeout <= 300.0:
            raise ValueError("database pool timeouts must be finite and between 1 and 300 seconds")
        return timeout

    @field_validator("max_upload_mb")
    @classmethod
    def validate_max_upload_mb(cls, value):
        if not 1 <= int(value) <= 100:
            raise ValueError("max_upload_mb must be between 1 and 100")
        return int(value)

    @field_validator("max_image_upload_mb")
    @classmethod
    def validate_max_image_upload_mb(cls, value):
        if not 1 <= int(value) <= 20:
            raise ValueError("max_image_upload_mb must be between 1 and 20")
        return int(value)

    @field_validator("image_max_dimension")
    @classmethod
    def validate_image_max_dimension(cls, value):
        if not 512 <= int(value) <= 4000:
            raise ValueError("image_max_dimension must be between 512 and 4000")
        return int(value)

    @field_validator("image_webp_quality")
    @classmethod
    def validate_image_webp_quality(cls, value):
        if not 60 <= int(value) <= 92:
            raise ValueError("image_webp_quality must be between 60 and 92")
        return int(value)

    @field_validator("max_upload_storage_mb", "upload_min_free_mb")
    @classmethod
    def validate_nonnegative_storage_settings(cls, value):
        if int(value) < 0:
            raise ValueError("storage/retention settings must be non-negative")
        return int(value)

    @field_validator("upload_storage_warning_percent", "upload_storage_critical_percent")
    @classmethod
    def validate_storage_percent(cls, value):
        if not 1 <= int(value) <= 100:
            raise ValueError("storage threshold percentages must be between 1 and 100")
        return int(value)


    @field_validator("fsm_storage_ttl_seconds")
    @classmethod
    def validate_fsm_storage_ttl(cls, value):
        if not 300 <= int(value) <= 2_592_000:
            raise ValueError("fsm_storage_ttl_seconds must be between 300 and 2592000")
        return int(value)

    @field_validator("api_token_ttl_seconds")
    @classmethod
    def validate_api_token_ttl(cls, value):
        if not 60 <= int(value) <= 86_400:
            raise ValueError("api_token_ttl_seconds must be between 60 and 86400")
        return int(value)

    @field_validator("telegram_init_data_max_age_seconds")
    @classmethod
    def validate_telegram_init_data_age(cls, value):
        if not 60 <= int(value) <= 86_400:
            raise ValueError("telegram_init_data_max_age_seconds must be between 60 and 86400")
        return int(value)

    @field_validator("panel_flow_website_url", mode="before")
    @classmethod
    def validate_panel_flow_website_url(cls, value):
        raw = str(value or "").strip()
        if not raw:
            return ""
        parsed = urlsplit(raw)
        local_http = parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if (
            (parsed.scheme != "https" and not local_http) or not parsed.netloc
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path not in {"", "/"}
        ):
            raise ValueError("panel_flow_website_url must be an HTTPS origin (HTTP is allowed only for localhost)")
        return f"{parsed.scheme}://{parsed.netloc}"

    @field_validator("api_cors_origins", mode="before")
    @classmethod
    def validate_api_cors_origins(cls, value):
        raw = str(value or "").strip()
        if not raw:
            return ""
        origins = []
        for candidate in raw.split(","):
            origin = candidate.strip()
            if not origin or origin == "*":
                raise ValueError("api_cors_origins must contain explicit origins, not wildcard")
            parsed = urlsplit(origin)
            local_http = parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}
            if (
                parsed.scheme != "https" and not local_http
            ) or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
                raise ValueError("each API CORS origin must be an HTTPS origin (HTTP is allowed only for localhost)")
            normalized = f"{parsed.scheme}://{parsed.netloc}"
            if normalized not in origins:
                origins.append(normalized)
        return ",".join(origins)

    @field_validator("support_username", mode="before")
    @classmethod
    def normalize_support_username(cls, value):
        text = str(value or cls.model_fields["support_username"].default).strip().removeprefix("@")
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{4,31}", text):
            raise ValueError("support_username must be a valid Telegram username without @")
        return text

    @field_validator("telegram_bot_id", mode="before")
    @classmethod
    def empty_telegram_bot_id_is_unconfigured(cls, value):
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        parsed = int(value)
        if parsed <= 0:
            raise ValueError("telegram_bot_id must be a positive Telegram bot ID")
        return parsed

    @field_validator("panel_flow_channel_id", mode="before")
    @classmethod
    def empty_channel_id_is_unconfigured(cls, value):
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        try:
            parsed = int(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("panel_flow_channel_id must be a negative Telegram channel/group ID") from exc
        # Telegram channels and supergroups use negative numeric chat IDs.
        # Reject positive IDs to prevent an accidental DM target being used
        # as the public announcement destination.
        if parsed >= 0:
            raise ValueError("panel_flow_channel_id must be a negative Telegram channel/group ID")
        return parsed

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


    @property
    def api_cors_origin_list(self) -> list[str]:
        return [origin for origin in self.api_cors_origins.split(",") if origin]

    @property
    def support_display_username(self) -> str:
        return f"@{self.support_username}"

    @property
    def support_url(self) -> str:
        return f"https://t.me/{self.support_username}"

    @property
    def admin_id_set(self) -> set[int]:
        return self._parse_id_list(self.admin_ids)

    @property
    def super_admin_only_id_set(self) -> set[int]:
        return self._parse_id_list(self.super_admin_ids)

    @staticmethod
    def _parse_id_list(raw_values: str) -> set[int]:
        ids: set[int] = set()
        for raw in str(raw_values or "").split(","):
            raw = raw.strip()
            if not raw:
                continue
            try:
                ids.add(int(raw))
            except ValueError:
                continue
        return ids

    @property
    def super_admin_id_set(self) -> set[int]:
        ids: set[int] = set()
        for raw in f"{self.super_admin_ids},{self.admin_ids}".split(","):
            raw = raw.strip()
            if not raw:
                continue
            try:
                ids.add(int(raw))
            except ValueError:
                continue
        return ids


settings = Settings()
