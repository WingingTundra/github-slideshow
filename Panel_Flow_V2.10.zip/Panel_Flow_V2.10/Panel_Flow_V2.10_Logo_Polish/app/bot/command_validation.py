from __future__ import annotations


def is_unrouted_telegram_command(text: str | None, bot_username: str | None = None) -> bool:
    """Return True for slash commands that must not fall through to FSM text fields.

    Public commands that actually match their registered handlers are handled before
    this filter. Here, the only intentional pass-through is /admin when addressed to
    this bot (or without an @mention), allowing the admin router to enforce access.
    """
    value = (text or "").strip()
    if not value.startswith("/"):
        return False
    token = value.split(maxsplit=1)[0]
    raw = token[1:]
    if "@" in raw:
        command, mention = raw.split("@", 1)
    else:
        command, mention = raw, None
    if command == "admin":
        if mention is None:
            return False
        if bot_username and mention.casefold() == bot_username.casefold():
            return False
    return True
