"""PostgreSQL-backed aiogram FSM storage with bounded expiry and full key isolation.

The database is already a required production dependency, so this avoids adding Redis.
Writes lock one conversation row; first insertion uses ON CONFLICT to serialize races
between workers. Storage keys include bot/chat/user/thread/business/destiny dimensions.
"""
from __future__ import annotations

import asyncio
import json
import logging
from contextlib import asynccontextmanager
from datetime import timedelta
from typing import Any

from aiogram.fsm.storage.base import BaseEventIsolation, BaseStorage, StorageKey
from sqlalchemy import delete, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert

from app.config import settings
from app.db.models import FSMConversation
from app.db.session import SessionLocal, event_isolation_engine
from app.time_utils import utc_now_naive

logger = logging.getLogger(__name__)


def _key_text(key: StorageKey) -> str:
    """Versioned and unambiguous key; do not collapse private/group or thread states."""
    parts = (
        int(getattr(key, "bot_id", 0) or 0),
        int(getattr(key, "chat_id", 0) or 0),
        int(getattr(key, "user_id", 0) or 0),
        int(getattr(key, "thread_id", 0) or 0),
        str(getattr(key, "business_connection_id", None) or ""),
        str(getattr(key, "destiny", "default") or "default"),
    )
    return "v1|" + "|".join(str(part).replace("|", "%7C") for part in parts)


def _state_value(state: Any) -> str | None:
    if state is None:
        return None
    value = getattr(state, "state", state)
    return str(value) if value is not None else None


class PostgresFSMStorage(BaseStorage):
    """Persistent FSM storage. Expired or malformed data is cleared, never trusted."""

    def __init__(self, *, ttl_seconds: int | None = None) -> None:
        self.ttl_seconds = int(ttl_seconds or settings.fsm_storage_ttl_seconds)
        if not 300 <= self.ttl_seconds <= 2_592_000:
            raise ValueError("FSM storage TTL must be between 300 and 2592000 seconds")
        self._writes = 0
        self._cleanup_lock = asyncio.Lock()

    def _expiry(self):
        return utc_now_naive() + timedelta(seconds=self.ttl_seconds)

    async def _locked_row(self, session, storage_key: str) -> FSMConversation:
        now = utc_now_naive()
        # This is PostgreSQL-specific intentionally: production is required to use
        # PostgreSQL/asyncpg, and ON CONFLICT prevents concurrent first-use races.
        stmt = pg_insert(FSMConversation).values(
            storage_key=storage_key, state=None, data={}, updated_at=now,
            expires_at=now + timedelta(seconds=self.ttl_seconds),
        ).on_conflict_do_nothing(index_elements=[FSMConversation.storage_key])
        await session.execute(stmt)
        result = await session.execute(
            select(FSMConversation).where(
                FSMConversation.storage_key == storage_key,
            ).with_for_update()
        )
        row = result.scalar_one()
        if row.expires_at <= now:
            row.state = None
            row.data = {}
        return row

    async def _occasionally_cleanup(self) -> None:
        self._writes += 1
        if self._writes % 100:
            return
        async with self._cleanup_lock:
            try:
                async with SessionLocal() as session:
                    await session.execute(delete(FSMConversation).where(FSMConversation.expires_at <= utc_now_naive()))
                    await session.commit()
            except Exception:
                logger.warning("FSM expiry cleanup failed; expired rows remain inaccessible", exc_info=True)

    async def get_state(self, key: StorageKey) -> str | None:
        now = utc_now_naive()
        async with SessionLocal() as session:
            row = (await session.execute(select(FSMConversation).where(
                FSMConversation.storage_key == _key_text(key),
            ))).scalar_one_or_none()
            if row is None:
                return None
            if row.expires_at <= now:
                await session.execute(delete(FSMConversation).where(FSMConversation.storage_key == row.storage_key))
                await session.commit()
                return None
            return row.state

    async def set_state(self, key: StorageKey, state: Any = None) -> None:
        now = utc_now_naive()
        async with SessionLocal() as session:
            row = await self._locked_row(session, _key_text(key))
            row.state = _state_value(state)
            row.updated_at = now
            row.expires_at = now + timedelta(seconds=self.ttl_seconds)
            await session.commit()
        await self._occasionally_cleanup()

    async def get_data(self, key: StorageKey) -> dict[str, Any]:
        now = utc_now_naive()
        async with SessionLocal() as session:
            row = (await session.execute(select(FSMConversation).where(
                FSMConversation.storage_key == _key_text(key),
            ))).scalar_one_or_none()
            if row is None:
                return {}
            if row.expires_at <= now:
                await session.execute(delete(FSMConversation).where(FSMConversation.storage_key == row.storage_key))
                await session.commit()
                return {}
            if not isinstance(row.data, dict):
                # Old or manually corrupted payloads are reset rather than passed to
                # handlers where they could authorize or complete a stale operation.
                row.data = {}
                row.state = None
                row.updated_at = now
                row.expires_at = now + timedelta(seconds=self.ttl_seconds)
                await session.commit()
                return {}
            return dict(row.data)

    async def set_data(self, key: StorageKey, data: dict[str, Any]) -> None:
        if not isinstance(data, dict):
            raise TypeError("FSM data must be a dictionary")
        # Fail at this boundary rather than allowing driver-dependent serialization.
        encoded = json.dumps(data, ensure_ascii=False, default=str)
        safe_data = json.loads(encoded)
        now = utc_now_naive()
        async with SessionLocal() as session:
            row = await self._locked_row(session, _key_text(key))
            row.data = safe_data
            row.updated_at = now
            row.expires_at = now + timedelta(seconds=self.ttl_seconds)
            await session.commit()
        await self._occasionally_cleanup()

    async def update_data(self, key: StorageKey, data: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(data, dict):
            raise TypeError("FSM update data must be a dictionary")
        now = utc_now_naive()
        async with SessionLocal() as session:
            row = await self._locked_row(session, _key_text(key))
            current = row.data if isinstance(row.data, dict) else {}
            # JSON roundtrip ensures every accepted value remains DB-serializable.
            merged = {**current, **data}
            row.data = json.loads(json.dumps(merged, ensure_ascii=False, default=str))
            row.updated_at = now
            row.expires_at = now + timedelta(seconds=self.ttl_seconds)
            result = dict(row.data)
            await session.commit()
        await self._occasionally_cleanup()
        return result

    async def close(self) -> None:
        # The shared SQLAlchemy engine lifecycle belongs to app/db/session.py.
        return None

    async def cleanup_expired(self) -> int:
        async with SessionLocal() as session:
            result = await session.execute(delete(FSMConversation).where(
                FSMConversation.expires_at <= utc_now_naive(),
            ))
            await session.commit()
            return int(result.rowcount or 0)


async def periodic_fsm_cleanup(storage: PostgresFSMStorage, interval_seconds: int = 3600) -> None:
    while True:
        try:
            await asyncio.sleep(max(300, int(interval_seconds)))
            await storage.cleanup_expired()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.warning("Periodic FSM cleanup failed", exc_info=True)


class PostgresEventIsolation(BaseEventIsolation):
    """Serialize updates for one Telegram storage key across processes/replicas."""

    @asynccontextmanager
    async def lock(self, key: StorageKey):
        lock_key = _key_text(key)
        # Transaction-scoped advisory locks are released on success, error, or
        # cancellation, without creating a second infrastructure dependency.
        async with event_isolation_engine.begin() as conn:
            await conn.execute(
                text("SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))"),
                {"key": lock_key},
            )
            yield

    async def close(self) -> None:
        # Shared engine lifetime is managed by the bot's graceful shutdown.
        return None
