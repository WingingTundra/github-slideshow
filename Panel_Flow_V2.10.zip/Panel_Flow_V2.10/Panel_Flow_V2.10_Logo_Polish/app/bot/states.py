from aiogram.fsm.state import State, StatesGroup


class ProfileStates(StatesGroup):
    waiting_full_name = State()
    # Retained as compatibility state names; new onboarding uses waiting_full_name.
    waiting_first_name = State()
    waiting_last_name = State()
    waiting_phone = State()
    waiting_referral_choice = State()
    waiting_referral_code = State()


class ProfileEditStates(StatesGroup):
    waiting_full_name = State()
    waiting_phone = State()


class BookingStates(StatesGroup):
    selecting_pricing = State()
    selecting_edit_field = State()
    selecting_edit_participant = State()
    editing_participant_name = State()
    editing_booker_phone = State()
    waiting_count = State()
    waiting_participant_name = State()
    waiting_booker_phone = State()
    waiting_discount_choice = State()
    waiting_discount_code = State()
    confirm = State()
    waiting_receipt = State()


class WaitlistStates(StatesGroup):
    waiting_count = State()


class QuestionStates(StatesGroup):
    waiting_text = State()


class AdminEventStates(StatesGroup):
    volume = State()
    title = State()
    language = State()
    description = State()
    day_name = State()
    date_text = State()
    start_time = State()
    end_time = State()
    venue = State()
    address = State()
    map_url = State()
    capacity = State()
    price = State()
    alternative_price = State()
    waitlist = State()
    host = State()
    questions_pdf = State()
    confirm = State()


class AdminEditStates(StatesGroup):
    title = State()
    description = State()
    language = State()
    day_name = State()
    date_text = State()
    venue = State()
    address = State()
    map_url = State()
    capacity = State()
    price = State()
    alternative_price = State()


class AdminQuickEditStates(StatesGroup):
    """One-field edit with preview and explicit, stale-safe confirmation."""
    waiting_value = State()
    confirming = State()


class ReviewStates(StatesGroup):
    waiting_comment = State()
    confirm = State()


class AdminChannelStates(StatesGroup):
    waiting_poster = State()
    confirming_replacement = State()


class AdminReceiptRejectStates(StatesGroup):
    waiting_custom_reason = State()
    confirming = State()


class BulkRewardStates(StatesGroup):
    waiting_recipients = State()
    waiting_value = State()
    waiting_reason = State()


class AdminManageStates(StatesGroup):
    waiting_pdf = State()
    announcement_confirm = State()
    reminder_confirm = State()
    channel_threshold = State()
    question_answer = State()


class AdminBlockStates(StatesGroup):
    waiting_telegram_id = State()


class DiscountAdminStates(StatesGroup):
    waiting_public_code = State()
    waiting_personal_telegram_id = State()
    waiting_personal_value = State()
    waiting_personal_reason = State()
    selecting_events = State()
    waiting_max_uses = State()


class CommunityStates(StatesGroup):
    waiting_challenge_answer = State()
    confirming_challenge_answer = State()


class CommunityAdminStates(StatesGroup):
    challenge_title = State()
    challenge_prompt = State()
    challenge_winner_count = State()
    challenge_reference = State()
    wrapped_year = State()
    competition_telegram_id = State()
    competition_title = State()
    competition_note = State()
    xp_value = State()


class AdminSettingsStates(StatesGroup):
    waiting_link = State()
    waiting_card_number = State()
    waiting_cardholder_name = State()
    confirming_link = State()
    confirming_card = State()


class CancellationCaseStates(StatesGroup):
    waiting_note = State()


class TopicSuggestionStates(StatesGroup):
    waiting_text = State()


class AdminConsoleStates(StatesGroup):
    user_search = State()
    user_filter_xp = State()
    xp_amount = State()
    xp_reason = State()
    xp_confirm = State()
    note_text = State()
    message_text = State()
    message_confirm = State()
    role_reason = State()
    moderation_reason = State()
    moderation_confirm = State()
    role_confirm = State()
    announcement_custom = State()
    announcement_edit_body = State()
    host_manager_id = State()
    review_reason = State()
    review_confirm = State()


class V77AdminStates(StatesGroup):
    archive_recap = State()
    archive_highlights = State()
    archive_tags = State()
    archive_links = State()
    quick_fun_payload = State()
    draw_label = State()
    draw_odds = State()
    shop_costs = State()
    shop_denial = State()
    shop_denial_confirm = State()
    reward_code = State()
    refund_reason = State()
    refund_confirm = State()
    shop_offer_title = State()
    shop_offer_percent = State()
    shop_offer_cost = State()
    shop_offer_description = State()
    shop_offer_limit = State()
    shop_offer_expires = State()
    shop_offer_edit = State()


class NavigationStates(StatesGroup):
    """Temporary, non-destructive confirmation before abandoning any active form."""
    confirm_discard = State()

