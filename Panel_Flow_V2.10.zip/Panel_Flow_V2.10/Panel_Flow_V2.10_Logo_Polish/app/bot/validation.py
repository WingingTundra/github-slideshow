from __future__ import annotations

import re
import unicodedata
from urllib.parse import urlparse


_PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
_ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
_TIME_RE = re.compile(r"^(?:[01]\d|2[0-3]):[0-5]\d$")
_WEB_SCHEME_RE = re.compile(r"(?i)\b(?:https?|ftp)://\S+")
_WWW_RE = re.compile(r"(?i)(?<![\w-])www\.[^\s]+")
_DOMAIN_RE = re.compile(
    r"(?i)(?<![\w-])(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}"
    r"(?::\d+)?(?:[/?#][^\s)]*)?"
)


def to_ascii_digits(value: str) -> str:
    """Convert Persian/Arabic-Indic numerals to Western digits."""
    return value.translate(_PERSIAN_DIGITS).translate(_ARABIC_DIGITS)


def normalize_iranian_mobile(value: str) -> str | None:
    """Validate and normalize a supported Iranian mobile representation.

    Accepted canonical forms are represented internally as +989XXXXXXXXX.
    Harmless spaces, parentheses, periods, and hyphens are ignored.
    """
    raw = to_ascii_digits((value or "").strip())
    if not raw or not re.fullmatch(r"[+0-9\s().-]+", raw):
        return None

    compact = re.sub(r"[\s().-]", "", raw)
    if compact.startswith("+98"):
        rest = compact[3:]
    elif compact.startswith("0098"):
        rest = compact[4:]
    elif compact.startswith("98"):
        rest = compact[2:]
    elif compact.startswith("0"):
        rest = compact[1:]
    elif compact.startswith("9"):
        rest = compact
    else:
        return None

    if rest.startswith("0"):
        rest = rest[1:]

    if len(rest) != 10 or not rest.isdigit() or not rest.startswith("9"):
        return None

    return f"+98{rest}"


_NAME_SEPARATORS = frozenset(" -'’‐‑‒–—.")
_COMMAND_RE = re.compile(r"^/[A-Za-z0-9_]+(?:@[A-Za-z0-9_]+)?(?:\s|$)")


def normalize_person_name(value: str, *, min_length: int = 2, max_length: int = 100) -> str | None:
    """Normalize and validate a person-name field without assuming Latin script.

    Unicode letters (including Persian), combining marks, spaces, apostrophes,
    hyphens, and periods used in initials are supported. URLs, commands,
    numeric-only strings, punctuation-only strings, and symbols are rejected.
    """
    text = " ".join((value or "").split())
    if not text or _COMMAND_RE.match(text):
        return None
    if not min_length <= len(text) <= max_length or is_link_like_text(text):
        return None
    if not any(unicodedata.category(char).startswith("L") for char in text):
        return None
    for char in text:
        category = unicodedata.category(char)
        if category.startswith("L") or category.startswith("M") or char in _NAME_SEPARATORS or char in {"\u200c", "\u200d"}:
            continue
        return None
    return text


_LANGUAGE_SEPARATORS = frozenset(" -'’&+,.()")

def normalize_panel_language(value: str | None, *, max_length: int = 80) -> str | None:
    """Validate a human-readable language label in any script.

    Examples include English, Français, فارسی, and English and Persian.
    Commands, URLs, usernames, and punctuation-only input are rejected so an
    accidental /admin message cannot be saved as a panel language.
    """
    text = " ".join((value or "").strip().split())
    if len(text) < 2 or len(text) > max_length or text.startswith("/"):
        return None
    if "@" in text or is_link_like_text(text):
        return None
    if not any(unicodedata.category(char).startswith("L") for char in text):
        return None
    for char in text:
        category = unicodedata.category(char)
        if category.startswith("L") or category.startswith("M") or char in _LANGUAGE_SEPARATORS or char in {"\u200c", "\u200d"}:
            continue
        return None
    return text


def parse_full_name(value: str) -> tuple[str, str] | None:
    """Parse a person's first + last name, keeping compound surnames intact."""
    normalized = normalize_person_name(value, min_length=3, max_length=201)
    if normalized is None:
        return None
    parts = normalized.split()
    if len(parts) < 2:
        return None
    first = normalize_person_name(parts[0], min_length=2, max_length=100)
    last = normalize_person_name(" ".join(parts[1:]), min_length=2, max_length=100)
    if first is None or last is None:
        return None
    return first, last


def parse_integer(value: str, *, minimum: int | None = None, maximum: int | None = None) -> int | None:
    """Parse an integer entered using Western, Persian, or Arabic-Indic digits."""
    text = to_ascii_digits((value or "").strip())
    if not re.fullmatch(r"[+-]?\d+", text):
        return None
    try:
        result = int(text)
    except (TypeError, ValueError, OverflowError):
        return None
    if minimum is not None and result < minimum:
        return None
    if maximum is not None and result > maximum:
        return None
    return result


def normalize_display_time(value: str) -> str | None:
    """Validate a presentation-only HH:MM time and return Western digits."""
    value = to_ascii_digits((value or "").strip())
    if not _TIME_RE.fullmatch(value):
        return None
    return value


def is_link_like_text(value: str) -> bool:
    """Detect obvious web/Telegram/map/shortened links in human-text fields."""
    text = (value or "").strip()
    if not text:
        return False
    if _WEB_SCHEME_RE.search(text) or _WWW_RE.search(text):
        return True
    return _DOMAIN_RE.search(text) is not None


def is_valid_http_url(value: str) -> bool:
    """Validate an absolute HTTP(S) URL for the dedicated map-link field."""
    try:
        text = (value or "").strip()
        if not text or any(char.isspace() for char in text):
            return False
        parsed = urlparse(text)
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc or not parsed.hostname:
            return False
        _ = parsed.port  # Accessing port rejects malformed port specifications.
        return True
    except (TypeError, ValueError):
        return False


_VOLUME_LABEL_RE = re.compile(r"^[A-Za-z0-9]+(?:[ -][A-Za-z0-9]+)*$")

def normalize_volume_label(value: str | None, *, max_length: int = 40) -> str | None:
    """Validate the panel's English-only volume label without accepting commands.

    Numeric values keep the existing 1..1,000,000 convention. Named volumes may
    contain English letters, digits, spaces, and internal hyphens only. Slash
    commands, @mentions, URLs, punctuation, and non-Latin text are rejected.
    """
    text = " ".join((value or "").strip().split())
    if not text or len(text) > max_length or text.startswith("/"):
        return None
    if not _VOLUME_LABEL_RE.fullmatch(text):
        return None
    # A single-digit volume such as "9" is valid. Apply the minimum length
    # only to named labels, after the numeric case has been handled.
    if text.isdigit():
        number = int(text)
        if not 1 <= number <= 1_000_000:
            return None
        return str(number)
    if len(text) < 2:
        return None
    if not any("A" <= char <= "Z" or "a" <= char <= "z" for char in text):
        return None
    if is_link_like_text(text):
        return None
    return text
