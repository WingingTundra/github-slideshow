"""Telegram-native admin/host console, participant roster, and unified manual announcements.

The module deliberately reuses V71's User/Booking/XPAward/Event models and the existing
announcement send primitive. Every mutating route re-checks role/ownership at the action
boundary; callbacks are navigation hints, never authorization.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import secrets
import re
from urllib.parse import urlparse
from datetime import timedelta
from html import escape

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import delete, func, not_, or_, select, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

from app.bot.states import AdminConsoleStates, AdminEventStates
from app.bot.keyboards import admin_event_creation_step_keyboard
from app.config import settings
from app.db.models import (
    AchievementUnlock, AdminAction, AdminAnnouncement, AdminAnnouncementDelivery, AdminPrivateMessage,
    AdminUserNote, AppSetting, Booking, BlockedUser, ChallengeSubmission, CommunityChallenge,
    ReferralVerification,
    CommunityProfile, DiscountRedemption, Event, EventStatus, Payment,
    Question, RegistrationStatus, Review, TopicSuggestion, User, UserModerationRecord,
    UserRole, WaitlistEntry, WrappedReport, XPAward, PanelAnnouncementPost,
)
from app.db.session import SessionLocal, event_isolation_engine
from app.services.admin_audit import write_admin_action
from app.services.host_notifications import notify_host_submission_review
from app.services.host_submission_review import (
    approval_callback_data, bump_submission_revision, current_submission_revision,
    rejection_callback_data, submission_revision_matches,
)
from app.services.announcements import send_announcement_to_user
from app.services.community import total_xp, attended_panel_count
from app.services.referrals import count_referrals_for_telegram_id
from app.services.events import announcement_events_statement, seats_used
from app.services.user_access import parse_telegram_numeric_id
from app.display_utils import admin_status_display_label, volume_label, panel_detail_line
from app.time_utils import utc_now_naive

router = Router(name="panel-flow-admin-console")
logger = logging.getLogger(__name__)
USER_PAGE_SIZE = 6
_UNSET = object()
ROSTER_PAGE_SIZE = 8
ANNOUNCEMENT_PAGE_SIZE = 6
HOST_REVIEW_PAGE_SIZE = 5
HOST_NOTIFICATION_PAGE_SIZE = 6

ROLE_LABELS = {
    UserRole.SUPER_ADMIN: "مدیر",
    UserRole.HOST: "میزبان",
    UserRole.PARTICIPANT: "شرکت‌کننده",
}
ROLE_FILTERS = {"admins": UserRole.SUPER_ADMIN, "hosts": UserRole.HOST, "attendees": UserRole.PARTICIPANT}


def _role(user: User | None):
    if user is None:
        return None
    try:
        value = user.role
        return value if isinstance(value, UserRole) else UserRole(str(getattr(value, "value", value)))
    except Exception:
        return None


def _name(user: User | None) -> str:
    if user is None:
        return "—"
    return str(user.display_name or " ".join(x for x in (user.first_name, user.last_name) if x) or "—")


async def _is_admin(telegram_id: int) -> bool:
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(int(telegram_id))


def _is_owner(telegram_id: int) -> bool:
    return int(telegram_id) in settings.super_admin_id_set


async def _get_user(session, telegram_id: int) -> User | None:
    return (await session.execute(select(User).where(User.telegram_id == int(telegram_id)))).scalar_one_or_none()


async def _is_host(telegram_id: int) -> bool:
    from app.services.authorization import is_host_telegram_id
    return await is_host_telegram_id(telegram_id)


async def _host_owns_event(session, telegram_id: int, event_id: int) -> bool:
    user = await _get_user(session, telegram_id)
    if _role(user) != UserRole.HOST:
        return False
    event = await session.get(Event, int(event_id))
    return bool(event and event.host_id == user.id)


async def _authorized_event_actor(telegram_id: int, event_id: int) -> tuple[bool, bool]:
    """Return (authorized, is_admin); hosts are authorized only for their own panel."""
    if await _is_admin(telegram_id):
        return True, True
    async with SessionLocal() as session:
        return await _host_owns_event(session, telegram_id, event_id), False


async def _setting_value(session, key: str, default: str = "") -> str:
    row = (await session.execute(select(AppSetting).where(AppSetting.key == key))).scalar_one_or_none()
    return str(row.value if row else default)


async def _write_announcement_audit(session, *, actor_telegram_id: int, action: str, entity_id: int, details: dict) -> None:
    """Audit a panel announcement by Admin or authorized Host in the shared action ledger.

    The generic admin-audit service intentionally rejects non-Admin actors. The
    announcement flows additionally allow Hosts for their own panels, so those
    authorized actions are represented directly in the same AdminAction ledger.
    The caller must already have checked role and panel ownership. Final delivery
    completion is recorded for the original initiator even if their role changes
    while the already-authorized send operation is running.
    """
    actor_telegram_id = int(actor_telegram_id)
    actor = (await session.execute(select(User).where(User.telegram_id == actor_telegram_id))).scalar_one_or_none()
    if actor_telegram_id in settings.super_admin_id_set or (actor and _role(actor) == UserRole.SUPER_ADMIN):
        await write_admin_action(
            session, actor_telegram_id=actor_telegram_id, action=action,
            entity_type="admin_announcement", entity_id=entity_id, details=details,
        )
        return
    if actor is None:
        raise PermissionError("ANNOUNCEMENT_AUDIT_ACTOR_NOT_REGISTERED")
    safe_details = json.dumps(details, ensure_ascii=False, default=str, separators=(",", ":"))[:4000]
    session.add(AdminAction(
        actor_user_id=int(actor.id), action=str(action)[:100], entity_type="admin_announcement",
        entity_id=int(entity_id), details=safe_details, created_at=utc_now_naive(),
    ))
    await session.flush()


async def _can_manage_role_change(actor_id: int, old_role: UserRole | None, new_role: UserRole) -> bool:
    # Protected owner configuration is the only authority for Admin-role changes.
    if _is_owner(actor_id):
        return True
    if old_role == UserRole.SUPER_ADMIN or new_role == UserRole.SUPER_ADMIN:
        return False
    async with SessionLocal() as session:
        authorized = await _setting_value(session, "host_role_manager_ids", "")
    ids = set()
    for raw in authorized.split(","):
        try:
            ids.add(int(raw.strip()))
        except (ValueError, TypeError):
            continue
    return int(actor_id) in ids and old_role in {UserRole.HOST, UserRole.PARTICIPANT} and new_role in {UserRole.HOST, UserRole.PARTICIPANT}


def _role_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛡 مدیران", callback_data="admin:console:roles:list:admins:0"),
         InlineKeyboardButton(text="🎤 میزبان‌ها", callback_data="admin:console:roles:list:hosts:0")],
        [InlineKeyboardButton(text="👥 شرکت‌کنندگان", callback_data="admin:console:roles:list:attendees:0")],
        [InlineKeyboardButton(text="🔎 جست‌وجوی کاربر", callback_data="admin:console:users:search"),
         InlineKeyboardButton(text="📝 بررسی پنل‌های ارسالی", callback_data="admin:console:reviews")],
        [InlineKeyboardButton(text="🔐 مجوز انتصاب میزبان توسط مدیر", callback_data="admin:console:host_managers")],
        [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
    ])


def _user_profile_keyboard(user: User, actor_id: int, *, can_manage_roles: bool = False) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text="⭐ مدیریت XP", callback_data=f"admin:console:xp:{user.id}"),
         InlineKeyboardButton(text="💬 پیام خصوصی", callback_data=f"admin:console:message:{user.id}")],
        [InlineKeyboardButton(text="📚 رزروها و پرداخت‌ها", callback_data=f"admin:console:profile:bookings:{user.id}:0"),
         InlineKeyboardButton(text="🏅 پاسپورت و جامعه", callback_data=f"admin:console:profile:community:{user.id}")],
        [InlineKeyboardButton(text="🗒 یادداشت داخلی", callback_data=f"admin:console:note:{user.id}"),
         InlineKeyboardButton(text="🛡 مدیریت دسترسی", callback_data=f"admin:console:moderation:{user.id}")],
        [InlineKeyboardButton(text="🕘 تاریخچه مدیریت", callback_data=f"admin:console:history:user:{user.id}")],
        [InlineKeyboardButton(text="🤝 مدیریت معرفی‌ها", callback_data=f"admin:console:referrals:{user.id}:0")],
    ]
    if can_manage_roles or _is_owner(actor_id):
        buttons.append([InlineKeyboardButton(text="🔁 تغییر نقش", callback_data=f"admin:console:role:{user.id}")])
    buttons.append([InlineKeyboardButton(text="🔙 فهرست کاربران", callback_data="admin:console:users")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def _announcement_main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📣 انتشار معرفی یک پنل در کانال", callback_data="admin:announce:v89:pick:0")],
        [InlineKeyboardButton(text="👥 پیام به ثبت‌نام‌شده‌ها", callback_data="admin:announce:v72:purpose:0")],
        [InlineKeyboardButton(text="🗓 اطلاع‌رسانی پنل‌های پیش‌رو", callback_data="admin:announce:v72:upcoming")],
        [InlineKeyboardButton(text="📢 به‌روزرسانی‌های کانال", callback_data="admin:channel_updates")],
        [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
    ])


def _panel_announcement_keyboard(event_id: int, admin: bool) -> InlineKeyboardMarkup:
    rows = []
    if admin:
        rows.append([InlineKeyboardButton(text="📣 انتشار معرفی این پنل در کانال", callback_data=f"admin:announce:v89:choose:{event_id}")])
        rows.append([InlineKeyboardButton(text="👥 پیام به ثبت‌نام‌شده‌ها", callback_data=f"admin:announce:v72:purposepanel:{event_id}:custom")])
        rows.append([InlineKeyboardButton(text="🗂 تاریخچه انتشار کانال", callback_data=f"admin:announce:v89:history:{event_id}:0")])
    else:
        rows.append([InlineKeyboardButton(text="👥 پیام به ثبت‌نام‌شده‌ها", callback_data=f"admin:announce:v72:purposepanel:{event_id}:custom")])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به مدیریت پنل", callback_data=f"admin:event:view:{event_id}" if admin else f"host:panel:view:{event_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _confirmed_statuses():
    # This is the application's actual authoritative confirmation status, not receipt submission.
    return (RegistrationStatus.CONFIRMED,)


# -----------------------------------------------------------------------------
# Admin overview, user search, profiles, roles, XP, internal notes and messaging
# -----------------------------------------------------------------------------

@router.callback_query(F.data == "admin:console:users")
async def console_users(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await _render_user_directory(c, page=0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:users:page:\d+$"))
async def console_users_page(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    page = int((c.data or "").rsplit(":", 1)[1])
    await _render_user_directory(c, page=page, state=state)
    await c.answer()


@router.callback_query(F.data == "admin:console:users:search")
async def console_users_search_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(AdminConsoleStates.user_search)
    await c.message.edit_text("نام، بخشی از نام، نام کاربری یا شناسه عددی تلگرام را بفرستید. فیلترهای فعلی حفظ می‌شوند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data="admin:console:users:cancel_filter")]]))
    await c.answer()


@router.message(AdminConsoleStates.user_search)
async def console_users_search(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    term = (message.text or "").strip()[:160]
    if len(term) < 2:
        return await message.answer("حداقل دو نویسه یا یک شناسه عددی ارسال کنید.")
    await state.set_state(None)
    await _render_user_directory(message, page=0, search=term, state=state)


async def _render_user_directory(
    target, *, page: int, search=_UNSET, role_filter=_UNSET,
    account_filter=_UNSET, participation_filter=_UNSET, registration_filter=_UNSET,
    xp_min=_UNSET, xp_max=_UNSET, sort_key=_UNSET, state: FSMContext | None = None,
):
    """Paginated directory with database-backed filters and stable sorting."""
    data = await state.get_data() if state is not None else {}
    search = data.get("console_search_term") if search is _UNSET else search
    role_filter = data.get("console_role_filter") if role_filter is _UNSET else role_filter
    account_filter = data.get("console_account_filter", "all") if account_filter is _UNSET else account_filter
    participation_filter = data.get("console_participation_filter", "all") if participation_filter is _UNSET else participation_filter
    registration_filter = data.get("console_registration_filter", "all") if registration_filter is _UNSET else registration_filter
    xp_min = data.get("console_xp_min") if xp_min is _UNSET else xp_min
    xp_max = data.get("console_xp_max") if xp_max is _UNSET else xp_max
    sort_key = data.get("console_sort_key", "newest") if sort_key is _UNSET else sort_key
    if role_filter not in ROLE_FILTERS:
        role_filter = None
    if account_filter not in {"all", "active", "blocked"}:
        account_filter = "all"
    if participation_filter not in {"all", "confirmed", "none"}:
        participation_filter = "all"
    if registration_filter not in {"all", "recent30", "older30"}:
        registration_filter = "all"
    if sort_key not in {"newest", "oldest", "name", "xp_desc", "xp_asc"}:
        sort_key = "newest"
    try:
        xp_min = int(xp_min) if xp_min is not None else None
        xp_max = int(xp_max) if xp_max is not None else None
    except (TypeError, ValueError):
        xp_min, xp_max = None, None

    xp_totals = select(
        XPAward.telegram_id.label("telegram_id"),
        func.coalesce(func.sum(XPAward.points), 0).label("xp"),
    ).group_by(XPAward.telegram_id).subquery()
    stmt = select(User).outerjoin(xp_totals, xp_totals.c.telegram_id == User.telegram_id)
    if search:
        escaped_search = str(search).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        pattern = f"%{escaped_search}%"
        choices = [User.display_name.ilike(pattern), User.first_name.ilike(pattern), User.last_name.ilike(pattern), User.telegram_username.ilike(pattern)]
        parsed_id = parse_telegram_numeric_id(str(search))
        if parsed_id is not None:
            choices.append(User.telegram_id == parsed_id)
        stmt = stmt.where(or_(*choices))
    if role_filter in ROLE_FILTERS:
        stmt = stmt.where(User.role == ROLE_FILTERS[role_filter])
    now = utc_now_naive()
    suspended_ids = select(UserModerationRecord.target_telegram_id).where(
        UserModerationRecord.action == "suspension", UserModerationRecord.scope == "account",
        UserModerationRecord.active.is_(True),
        or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
    )
    blocked_condition = or_(User.telegram_id.in_(select(BlockedUser.telegram_id)), User.telegram_id.in_(suspended_ids))
    if account_filter == "blocked":
        stmt = stmt.where(blocked_condition)
    elif account_filter == "active":
        stmt = stmt.where(not_(blocked_condition))
    confirmed_user_ids = select(Booking.booked_by_user_id).where(Booking.status == RegistrationStatus.CONFIRMED)
    if participation_filter == "confirmed":
        stmt = stmt.where(User.id.in_(confirmed_user_ids))
    elif participation_filter == "none":
        stmt = stmt.where(User.id.not_in(confirmed_user_ids))
    if registration_filter == "recent30":
        stmt = stmt.where(User.created_at >= now - timedelta(days=30))
    elif registration_filter == "older30":
        stmt = stmt.where(User.created_at < now - timedelta(days=30))
    xp_expr = func.coalesce(xp_totals.c.xp, 0)
    if xp_min is not None:
        stmt = stmt.where(xp_expr >= xp_min)
    if xp_max is not None:
        stmt = stmt.where(xp_expr <= xp_max)

    if sort_key == "name":
        order_by = (func.lower(func.coalesce(User.display_name, User.first_name, "")), User.id.asc())
    elif sort_key == "oldest":
        order_by = (User.created_at.asc(), User.id.asc())
    elif sort_key == "xp_desc":
        order_by = (xp_expr.desc(), User.id.desc())
    elif sort_key == "xp_asc":
        order_by = (xp_expr.asc(), User.id.asc())
    else:
        order_by = (User.created_at.desc(), User.id.desc())

    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0)
        page_count = max(1, (total + USER_PAGE_SIZE - 1) // USER_PAGE_SIZE)
        page = max(0, min(int(page), page_count - 1))
        users = (await session.execute(stmt.order_by(*order_by).offset(page * USER_PAGE_SIZE).limit(USER_PAGE_SIZE))).scalars().all()
        xp_rows = (await session.execute(select(XPAward.telegram_id, func.coalesce(func.sum(XPAward.points), 0)).where(XPAward.telegram_id.in_([int(u.telegram_id) for u in users]) if users else False).group_by(XPAward.telegram_id))).all() if users else []
        xp_by_id = {int(tg_id): int(xp) for tg_id, xp in xp_rows}
        blocked_ids = set((await session.execute(select(BlockedUser.telegram_id).where(BlockedUser.telegram_id.in_([int(u.telegram_id) for u in users])))).scalars().all()) if users else set()
        suspended_current = set((await session.execute(select(UserModerationRecord.target_telegram_id).where(
            UserModerationRecord.target_telegram_id.in_([int(u.telegram_id) for u in users]) if users else False,
            UserModerationRecord.action == "suspension", UserModerationRecord.scope == "account",
            UserModerationRecord.active.is_(True),
            or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
        ))).scalars().all()) if users else set()

    if state is not None:
        await state.update_data(
            console_search_term=search, console_role_filter=role_filter,
            console_account_filter=account_filter, console_participation_filter=participation_filter,
            console_registration_filter=registration_filter, console_xp_min=xp_min, console_xp_max=xp_max,
            console_sort_key=sort_key,
        )
    rows = []
    for user in users:
        label = f"{_name(user)[:22]} · {ROLE_LABELS.get(_role(user), 'شرکت‌کننده')} · XP {xp_by_id.get(int(user.telegram_id), 0)}"
        rows.append([InlineKeyboardButton(text=label[:64], callback_data=f"admin:console:user:{user.id}")])
    nav = []
    token = _search_token(search)
    role_token = role_filter or "all"
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:console:users:query:{role_token}:{page - 1}:{token}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:console:users:query:{role_token}:{page + 1}:{token}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔎 جست‌وجو", callback_data="admin:console:users:search"), InlineKeyboardButton(text="🧹 پاک‌کردن همهٔ فیلترها", callback_data="admin:console:users")])
    rows.append([
        InlineKeyboardButton(text={"all": "وضعیت: همه", "active": "وضعیت: فعال", "blocked": "وضعیت: مسدود/تعلیق"}[account_filter], callback_data=f"admin:console:users:set:status:{ {'all':'active','active':'blocked','blocked':'all'}[account_filter] }"),
        InlineKeyboardButton(text={"all": "مشارکت: همه", "confirmed": "مشارکت: تأییدشده", "none": "مشارکت: بدون رزرو"}[participation_filter], callback_data=f"admin:console:users:set:participation:{ {'all':'confirmed','confirmed':'none','none':'all'}[participation_filter] }"),
    ])
    rows.append([
        InlineKeyboardButton(text=f"XP: {xp_min if xp_min is not None else '—'} تا {xp_max if xp_max is not None else '—'}", callback_data="admin:console:users:filter:xp"),
        InlineKeyboardButton(text={"all": "تاریخ: همه", "recent30": "ثبت‌نام: ۳۰ روز اخیر", "older30": "ثبت‌نام: قدیمی‌تر"}[registration_filter], callback_data=f"admin:console:users:set:registration:{ {'all':'recent30','recent30':'older30','older30':'all'}[registration_filter] }"),
    ])
    rows.append([
        InlineKeyboardButton(text={"newest": "مرتب‌سازی: جدیدترین", "oldest": "مرتب‌سازی: قدیمی‌ترین", "name": "مرتب‌سازی: نام", "xp_desc": "مرتب‌سازی: XP بیشتر", "xp_asc": "مرتب‌سازی: XP کمتر"}[sort_key], callback_data=f"admin:console:users:sort:{ {'newest':'oldest','oldest':'name','name':'xp_desc','xp_desc':'xp_asc','xp_asc':'newest'}[sort_key] }"),
    ])
    if role_filter:
        rows.append([InlineKeyboardButton(text="🔙 نقش‌ها", callback_data="admin:console:roles")])
    rows.append([InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")])
    title = "👤 <b>مدیریت کاربران</b>"
    if role_filter:
        title += f"\nفیلتر نقش: {ROLE_LABELS.get(ROLE_FILTERS.get(role_filter), role_filter)}"
    if search:
        title += f"\nجست‌وجو: <code>{escape(str(search))}</code>"
    active_filters = []
    if account_filter != "all": active_filters.append("وضعیت")
    if participation_filter != "all": active_filters.append("مشارکت")
    if registration_filter != "all": active_filters.append("تاریخ ثبت‌نام")
    if xp_min is not None or xp_max is not None: active_filters.append("XP")
    if active_filters: title += "\nفیلترها: " + "، ".join(active_filters)
    title += f"\nکاربران: {total} · صفحه {page + 1}/{page_count}"
    lines = [title, ""]
    for user in users:
        username = f" · @{escape(user.telegram_username.lstrip('@'))}" if user.telegram_username else ""
        status = "مسدود" if int(user.telegram_id) in blocked_ids else ("تعلیق" if int(user.telegram_id) in suspended_current else "فعال")
        lines.append(f"• {escape(_name(user)[:50])}{username} · {ROLE_LABELS.get(_role(user), 'شرکت‌کننده')} · {status} · XP {xp_by_id.get(int(user.telegram_id), 0)}")
    if not users:
        lines.append("کاربری با این معیارها پیدا نشد. فیلترها را تغییر دهید یا پاک کنید.")
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    text = "\n".join(lines)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=markup)
    else:
        await target.answer(text, reply_markup=markup)


@router.callback_query(F.data.regexp(r"^admin:console:users:set:(status|participation|registration):(all|active|blocked|confirmed|none|recent30|older30)$"))
@router.callback_query(F.data.regexp(r"^admin:console:users:sort:(newest|oldest|name|xp_desc|xp_asc)$"))
async def console_users_set_filter(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(None)
    data = await state.get_data()
    if ":sort:" in (c.data or ""):
        new_sort = (c.data or "").rsplit(":", 1)[1]
        await state.update_data(console_sort_key=new_sort)
    else:
        parts = (c.data or "").split(":")
        dimension, value = parts[4], parts[5]
        mapping = {"status": "console_account_filter", "participation": "console_participation_filter", "registration": "console_registration_filter"}
        await state.update_data({mapping[dimension]: value})
    await _render_user_directory(c, page=0, state=state)
    await c.answer()


@router.callback_query(F.data == "admin:console:users:cancel_filter")
async def console_users_cancel_filter_input(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(None)
    await _render_user_directory(c, page=0, state=state)
    await c.answer()


@router.callback_query(F.data == "admin:console:users:filter:xp")
async def console_users_xp_filter_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(AdminConsoleStates.user_filter_xp)
    await c.message.edit_text("بازهٔ XP را به‌صورت «حداقل حداکثر» وارد کنید؛ برای کران باز از * استفاده کنید. نمونه: 100 500 یا 250 * . برای پاک‌کردن فیلتر، clear بفرستید.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data="admin:console:users:cancel_filter")]]))
    await c.answer()


@router.message(AdminConsoleStates.user_filter_xp)
async def console_users_xp_filter_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    if raw.lower() == "clear":
        low = high = None
    else:
        parts = raw.replace(",", " ").split()
        if len(parts) != 2:
            return await message.answer("دو مقدار بفرستید؛ مثل 100 500، یا برای کران باز از * استفاده کنید.")
        try:
            low = None if parts[0] == "*" else int(parts[0])
            high = None if parts[1] == "*" else int(parts[1])
        except ValueError:
            return await message.answer("مقادیر باید عدد صحیح نامنفی یا * باشند.")
        if (low is not None and low < 0) or (high is not None and high < 0) or (low is not None and high is not None and low > high):
            return await message.answer("بازهٔ XP نامعتبر است؛ حداقل باید نامنفی و کوچک‌تر یا مساوی حداکثر باشد.")
    await state.set_state(None)
    await state.update_data(console_xp_min=low, console_xp_max=high)
    await _render_user_directory(message, page=0, state=state)

def _search_token(search: str | None) -> str:
    # Callback data is limited to 64 bytes; the search itself remains in FSM only.
    return "none" if not search else "search"


@router.callback_query(F.data.regexp(r"^admin:console:users:query:(all|admins|hosts|attendees):\d+:(none|search)$"))
async def console_users_query_page(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    # Search text is intentionally not echoed into callback data. Requiring a fresh search
    # after pagination avoids stale/forged callback queries changing a stored filter.
    role_filter = None if parts[4] == "all" else parts[4]
    page = int(parts[5])
    data = await state.get_data()
    search = data.get("console_search_term") if parts[6] == "search" else None
    await _render_user_directory(c, page=page, role_filter=role_filter, search=search, state=state)
    await c.answer()


async def _is_blocked(telegram_id: int) -> bool:
    async with SessionLocal() as session:
        return await session.get(BlockedUser, int(telegram_id)) is not None


async def _xp_for_user(telegram_id: int) -> int:
    async with SessionLocal() as session:
        return await total_xp(session, int(telegram_id))


@router.callback_query(F.data == "admin:console:roles")
async def console_roles(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    async with SessionLocal() as session:
        counts = {}
        for key, role in ROLE_FILTERS.items():
            counts[key] = int(await session.scalar(select(func.count(User.id)).where(User.role == role)) or 0)
    text = (
        "🛡 <b>نقش‌ها و میزبان‌ها</b>\n\n"
        f"مدیران: {counts['admins']}\nمیزبان‌ها: {counts['hosts']}\nشرکت‌کنندگان: {counts['attendees']}\n\n"
        "شناسه‌های تعریف‌شده در تنظیمات محیطی، اختیار مالک محافظت‌شده را حفظ می‌کنند. تغییر نقش در این بخش بلافاصله اعمال می‌شود."
    )
    await c.message.edit_text(text, reply_markup=_role_menu())
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:roles:list:(admins|hosts|attendees):\d+$"))
async def console_role_list(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    parts = (c.data or "").split(":")
    filter_name, page = parts[-2], int(parts[-1])
    await _render_user_directory(c, page=page, role_filter=filter_name, state=state)
    await c.answer()


@router.callback_query(F.data == "admin:console:host_managers")
async def console_host_managers(c: CallbackQuery, state: FSMContext):
    if not _is_owner(c.from_user.id):
        return await c.answer("تنها مالک محافظت‌شده می‌تواند مجوز تعیین میزبان را مدیریت کند.", show_alert=True)
    await state.clear()
    async with SessionLocal() as session:
        raw = await _setting_value(session, "host_role_manager_ids", "")
        ids = []
        for item in raw.split(","):
            try:
                ids.append(int(item.strip()))
            except (ValueError, TypeError):
                continue
        user_rows = (await session.execute(select(User).where(User.telegram_id.in_(ids), User.role == UserRole.SUPER_ADMIN))).scalars().all() if ids else []
    rows = [[InlineKeyboardButton(text=f"➖ لغو مجوز {int(u.telegram_id)}", callback_data=f"admin:console:host_manager:remove:{int(u.telegram_id)}")] for u in user_rows]
    rows.append([InlineKeyboardButton(text="➕ افزودن مدیر مجاز", callback_data="admin:console:host_manager:add")])
    rows.append([InlineKeyboardButton(text="🔙 نقش‌ها", callback_data="admin:console:roles")])
    await c.message.edit_text("🔐 <b>مجوز مدیریت نقش میزبان</b>\n\nفقط مدیر ثبت‌شده را اضافه کنید. این مجوز اجازهٔ تغییر نقش مدیر را نمی‌دهد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data == "admin:console:host_manager:add")
async def console_host_manager_add(c: CallbackQuery, state: FSMContext):
    if not _is_owner(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.set_state(AdminConsoleStates.host_manager_id)
    await c.message.edit_text("شناسهٔ تلگرام یک مدیر ثبت‌شده را وارد کنید. این مجوز فقط تغییر نقش میزبان یا شرکت‌کننده را مجاز می‌کند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data="admin:console:host_managers")]]))
    await c.answer()


@router.message(AdminConsoleStates.host_manager_id)
async def console_host_manager_save(message: Message, state: FSMContext):
    if not _is_owner(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    tg_id = parse_telegram_numeric_id(message.text)
    if tg_id is None:
        return await message.answer("شناسه عددی معتبر بفرستید.")
    async with SessionLocal() as session:
        user = await _get_user(session, tg_id)
        if user is None or _role(user) != UserRole.SUPER_ADMIN or _is_owner(tg_id):
            return await message.answer("این شناسه متعلق به مدیر ثبت‌شده‌ای نیست که بتوان مجوز محدود مدیریت میزبان به او داد.")
        setting = (await session.execute(select(AppSetting).where(AppSetting.key == "host_role_manager_ids"))).scalar_one_or_none()
        ids = set()
        for raw in (setting.value if setting else "").split(","):
            try: ids.add(int(raw.strip()))
            except (ValueError, TypeError): pass
        ids.add(tg_id)
        if setting:
            setting.value = ",".join(str(x) for x in sorted(ids))
            setting.updated_at = utc_now_naive()
        else:
            session.add(AppSetting(key="host_role_manager_ids", value=",".join(str(x) for x in sorted(ids))))
        await write_admin_action(session, actor_telegram_id=message.from_user.id, action="host_role_manager_added", entity_type="user", entity_id=user.id, details={"target_telegram_id": tg_id})
        await session.commit()
    await state.clear()
    await message.answer(f"✅ مجوز محدود مدیریت میزبان برای شناسهٔ {tg_id} ذخیره شد.", reply_markup=_role_menu())


@router.callback_query(F.data.regexp(r"^admin:console:host_manager:remove:\d+$"))
async def console_host_manager_remove(c: CallbackQuery):
    if not _is_owner(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    target = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        setting = (await session.execute(select(AppSetting).where(AppSetting.key == "host_role_manager_ids"))).scalar_one_or_none()
        ids = set()
        for raw in (setting.value if setting else "").split(","):
            try: ids.add(int(raw.strip()))
            except (ValueError, TypeError): pass
        ids.discard(target)
        if setting:
            setting.value = ",".join(str(x) for x in sorted(ids))
            setting.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="host_role_manager_removed", entity_type="user", details={"target_telegram_id": target})
        await session.commit()
    await c.answer("مجوز لغو شد.")
    await console_roles(c)


@router.callback_query(F.data.regexp(r"^admin:console:user:\d+$"))
async def console_user_profile(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    target_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, target_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        xp = await total_xp(session, user.telegram_id)
        bookings = int(await session.scalar(select(func.count(Booking.id)).where(Booking.booked_by_user_id == user.id)) or 0)
        confirmed = int(await session.scalar(select(func.count(Booking.id)).where(Booking.booked_by_user_id == user.id, Booking.status == RegistrationStatus.CONFIRMED)) or 0)
        community = await session.get(CommunityProfile, int(user.telegram_id))
        notes = int(await session.scalar(select(func.count(AdminUserNote.id)).where(AdminUserNote.target_user_id == user.id)) or 0)
        achievements = int(await session.scalar(select(func.count(AchievementUnlock.id)).where(AchievementUnlock.telegram_id == user.telegram_id)) or 0)
        reviews = int(await session.scalar(select(func.count(Review.id)).where(Review.user_id == user.id)) or 0)
        payments = int(await session.scalar(select(func.count(Payment.id)).join(Booking, Payment.booking_id == Booking.id).where(Booking.booked_by_user_id == user.id)) or 0)
        discounts = int(await session.scalar(select(func.count(DiscountRedemption.id)).where(DiscountRedemption.user_telegram_id == user.telegram_id)) or 0)
        moderation_rows = (await session.execute(select(UserModerationRecord).where(UserModerationRecord.target_telegram_id == user.telegram_id).order_by(UserModerationRecord.created_at.desc()).limit(3))).scalars().all()
        blocked = await session.get(BlockedUser, int(user.telegram_id)) is not None
        active_suspension = bool(await session.scalar(select(UserModerationRecord.id).where(
            UserModerationRecord.target_telegram_id == user.telegram_id,
            UserModerationRecord.action == "suspension", UserModerationRecord.scope == "account",
            UserModerationRecord.active.is_(True),
            or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > utc_now_naive()),
        ).limit(1)))
    status = "ممنوع از ربات" if blocked else ("تعلیق فعال" if active_suspension else "فعال")
    username = f"@{escape(user.telegram_username.lstrip('@'))}" if user.telegram_username else "ندارد"
    text = (
        f"👤 <b>{escape(_name(user))}</b>\n\n"
        f"شناسهٔ تلگرام: <code>{int(user.telegram_id)}</code>\nنام کاربری: {username}\n"
        f"نقش: <b>{ROLE_LABELS.get(_role(user), 'شرکت‌کننده')}</b>\nوضعیت دسترسی: {status}\n"
        f"عضویت: {user.created_at.strftime('%Y-%m-%d') if user.created_at else 'نامشخص'}\n\n"
        f"⭐ XP فعلی: <b>{xp}</b>\nرزروها: {bookings} · تأییدشده: {confirmed}\n"
        f"چالش‌ها: {community.challenge_participations if community else '—'} · پاسخ درست: {community.correct_answers if community else '—'}\n"
        f"دستاوردهای ذخیره‌شده: {achievements} · بازخوردها: {reviews}\n"
        f"رکوردهای پرداخت مرتبط با رزرو: {payments} · سوابق درخواست تخفیف: {discounts}\n"
        f"یادداشت‌های داخلی: {notes}\n\n"
        "جزئیات پاسپورت یا فعالیت‌هایی که دادهٔ مستقلی برای آن‌ها ذخیره نشده، از روی اطلاعات موجود حدس زده نمی‌شوند."
    )
    can_manage_roles = _is_owner(c.from_user.id) or await _can_manage_role_change(c.from_user.id, _role(user), UserRole.HOST)
    await c.message.edit_text(text, reply_markup=_user_profile_keyboard(user, c.from_user.id, can_manage_roles=can_manage_roles))
    await c.answer()


async def _render_user_referrals(c: CallbackQuery, referrer_id: int, requested_page: int = 0):
    page_size = 6
    async with SessionLocal() as session:
        referrer = await session.get(User, referrer_id)
        if not referrer:
            return await c.answer("کاربر معرف پیدا نشد.", show_alert=True)
        total = int(await session.scalar(select(func.count(User.id)).where(User.referred_by_user_id == referrer_id)) or 0)
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(max(0, int(requested_page)), pages - 1)
        referrals = (await session.execute(
            select(User, ReferralVerification)
            .outerjoin(ReferralVerification, ReferralVerification.invitee_user_id == User.id)
            .where(User.referred_by_user_id == referrer_id)
            .order_by(User.created_at.asc(), User.id.asc())
            .offset(page * page_size).limit(page_size)
        )).all()
        referrer_name = _name(referrer)
        referral_rows = []
        for invitee, verification in referrals:
            profile_complete = bool(str(invitee.first_name or "").strip() and str(invitee.last_name or "").strip() and str(invitee.phone_number or "").strip())
            booked = int(invitee.lifetime_confirmed_bookings or 0) > 0
            attended = await attended_panel_count(session, int(invitee.telegram_id))
            verified = bool(verification and verification.verified)
            full_name = _name(invitee)
            stages = ["ثبت‌نام", "پروفایل کامل" if profile_complete else "پروفایل ناقص",
                      "اولین رزرو" if booked else "بدون رزرو",
                      "مشارکت" if attended > 0 else "بدون مشارکت ثبت‌شده",
                      "تأیید دستی" if verified else "تأییدنشده"]
            referral_rows.append((invitee, verified, full_name, stages, attended))
    lines = [f"<b>🤝 معرفی‌های {escape(referrer_name)}</b>",
             f"تعداد معرفی‌های ثبت‌شده: {total} · صفحهٔ {page+1}/{pages}",
             "مراحل به‌صورت اطلاعاتی محاسبه می‌شوند؛ فقط مرحلهٔ تأیید نهایی دستی است.", ""]
    buttons = []
    for invitee, verified, full_name, stages, attended in referral_rows:
        lines.append(f"<b>{escape(full_name)}</b> · شناسه <code>{int(invitee.telegram_id)}</code>")
        lines.append(" · ".join(stages) + f" · {attended} پنل")
        buttons.append([InlineKeyboardButton(
            text=("✅ لغو تأیید دستی" if verified else f"☑️ تأیید نهایی · {full_name[:28]}"),
            callback_data=f"admin:console:referrals:verify:{referrer_id}:{int(invitee.id)}:{page}",
        )])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:console:referrals:{referrer_id}:{page-1}"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:console:referrals:{referrer_id}:{page+1}"))
    if nav:
        buttons.append(nav)
    buttons += [[InlineKeyboardButton(text="🔙 پروفایل معرف", callback_data=f"admin:console:user:{referrer_id}")],
                [InlineKeyboardButton(text="🔙 فهرست کاربران", callback_data="admin:console:users")]]
    if not referral_rows:
        lines.append("هنوز کد معرفی این کاربر برای حسابی ثبت نشده است.")
    await c.message.edit_text("\n\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))


@router.callback_query(F.data.regexp(r"^admin:console:referrals:\d+:\d+$"))
async def console_user_referrals(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    await _render_user_referrals(c, int(parts[3]), int(parts[4]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:referrals:verify:\d+:\d+:\d+$"))
async def console_referral_verify_toggle(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    referrer_id, invitee_id, page = int(parts[4]), int(parts[5]), int(parts[6])
    async with SessionLocal() as session:
        invitee = (await session.execute(select(User).where(
            User.id == invitee_id, User.referred_by_user_id == referrer_id
        ).with_for_update())).scalar_one_or_none()
        if not invitee:
            return await c.answer("رابطهٔ معرفی پیدا نشد یا تغییر کرده است.", show_alert=True)
        verification = await session.get(ReferralVerification, invitee_id)
        if verification is None:
            verification = ReferralVerification(invitee_user_id=invitee_id)
            session.add(verification)
        verification.verified = not bool(verification.verified)
        verification.verified_by_telegram_id = int(c.from_user.id) if verification.verified else None
        verification.verified_at = utc_now_naive() if verification.verified else None
        verification.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=c.from_user.id,
            action="referral_manually_verified" if verification.verified else "referral_manual_verification_revoked",
            entity_type="referral", entity_id=invitee_id,
            details={"referrer_user_id": referrer_id, "invitee_telegram_id": int(invitee.telegram_id), "verified": bool(verification.verified)})
        await session.commit()
    await c.answer("وضعیت تأیید معرفی به‌روزرسانی شد.")
    await _render_user_referrals(c, referrer_id, page)


@router.callback_query(F.data.regexp(r"^admin:console:profile:bookings:\d+:\d+$"))
async def console_user_profile_bookings(c: CallbackQuery, state: FSMContext):
    """Paginated booking history, with status and receipt metadata kept مخصوص مدیران."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    parts = (c.data or "").split(":")
    user_id, requested_page = int(parts[4]), int(parts[5])
    page_size = 6
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        total = int(await session.scalar(select(func.count(Booking.id)).where(Booking.booked_by_user_id == user.id)) or 0)
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(max(0, requested_page), pages - 1)
        bookings = (await session.execute(
            select(Booking).options(
                selectinload(Booking.event), selectinload(Booking.payment), selectinload(Booking.participants),
            ).where(Booking.booked_by_user_id == user.id)
            .order_by(Booking.created_at.desc(), Booking.id.desc())
            .offset(page * page_size).limit(page_size)
        )).scalars().all()
    labels = {
        RegistrationStatus.INITIATED: "در حال تکمیل", RegistrationStatus.PENDING_PAYMENT: "در انتظار پرداخت",
        RegistrationStatus.PENDING_VERIFICATION: "در انتظار بررسی رسید", RegistrationStatus.CONFIRMED: "تأییدشده",
        RegistrationStatus.CANCELLED: "لغوشده", RegistrationStatus.REJECTED: "رسید ردشده",
        RegistrationStatus.EXPIRED: "مهلت پرداخت به پایان رسیده", RegistrationStatus.WAITLISTED: "در صف انتظار",
    }
    lines = [f"📚 <b>رزروها و پرداخت‌ها · {escape(_name(user))}</b>", f"همهٔ رکوردها: {total} · صفحه {page + 1}/{pages}", ""]
    rows = []
    for booking in bookings:
        event_title = booking.event.title if booking.event else f"پنل #{booking.event_id}"
        status = labels.get(booking.status, admin_status_display_label(booking.status))
        payment_status = "رکورد پرداختی وجود ندارد"
        if booking.payment:
            payment_status = admin_status_display_label(booking.payment.status)
        date_label = booking.created_at.strftime("%Y-%m-%d") if booking.created_at else "تاریخ نامشخص"
        attended = sum(1 for item in booking.participants if str(getattr(item.attendance_status, "value", item.attendance_status)) == "attended")
        no_show = sum(1 for item in booking.participants if str(getattr(item.attendance_status, "value", item.attendance_status)) == "no_show")
        lines.append(f"• <b>#{booking.id}</b> · {escape(str(event_title)[:60])}\n  {escape(status)} · {booking.participant_count} نفر · {int(booking.total_amount or 0):,} · پرداخت: {escape(payment_status)} · {date_label}\n  حضور ثبت‌شده: {attended} · غیبت ثبت‌شده: {no_show}")
        rows.append([InlineKeyboardButton(
            text=f"#{booking.id} · {str(event_title)[:30]}"[:64],
            callback_data=f"admin:console:profile:booking:{user.id}:{booking.id}:{page}",
        )])
    if not bookings:
        lines.append("هیچ رکورد رزروی برای این کاربر ثبت نشده است.")
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:console:profile:bookings:{user_id}:{page-1}"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:console:profile:bookings:{user_id}:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="👤 پروفایل کاربر", callback_data=f"admin:console:user:{user_id}")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:profile:booking:\d+:\d+:\d+$"))
async def console_user_profile_booking_detail(c: CallbackQuery, state: FSMContext):
    """Show a single user's booking/payment review details without receipt contents."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    parts = (c.data or "").split(":")
    user_id, booking_id, page = int(parts[4]), int(parts[5]), int(parts[6])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        booking = (await session.execute(select(Booking).options(
            selectinload(Booking.event), selectinload(Booking.payment), selectinload(Booking.participants),
        ).where(Booking.id == booking_id, Booking.booked_by_user_id == user.id))).scalar_one_or_none()
        if not booking:
            return await c.answer("این رزرو متعلق به کاربر انتخاب‌شده نیست.", show_alert=True)
        reviewer_telegram_id = None
        if booking.payment and booking.payment.reviewed_by:
            reviewer = await session.get(User, int(booking.payment.reviewed_by))
            reviewer_telegram_id = int(reviewer.telegram_id) if reviewer else None
    status = admin_status_display_label(booking.status)
    event = booking.event
    payment = booking.payment
    participants = booking.participants or []
    attended = sum(1 for item in participants if str(getattr(item.attendance_status, "value", item.attendance_status)) == "attended")
    no_show = sum(1 for item in participants if str(getattr(item.attendance_status, "value", item.attendance_status)) == "no_show")
    unmarked = sum(1 for item in participants if str(getattr(item.attendance_status, "value", item.attendance_status)) == "unmarked")
    lines = [
        f"🧾 <b>جزئیات رزرو #{booking.id}</b>", f"کاربر: {escape(_name(user))} · <code>{int(user.telegram_id)}</code>",
        f"پنل: {escape(str(event.title if event else f'#{booking.event_id}'))}",
        f"وضعیت رزرو: {escape(status)}", f"ایجاد: {booking.created_at.strftime('%Y-%m-%d %H:%M') if booking.created_at else 'نامشخص'}",
        f"نفرات: {int(booking.participant_count)} · مبلغ نهایی: {int(booking.total_amount or 0):,}",
        f"تخفیف ثبت‌شده: {int(booking.discount_amount or 0):,} · کد/هدیه: {escape(str(booking.discount_code_snapshot or 'ندارد'))}",
        f"گزینهٔ قیمت: {escape(str(booking.pricing_option or 'قدیمی/ثبت‌نشده'))}",
        f"لغو: {booking.cancelled_at.strftime('%Y-%m-%d %H:%M') if booking.cancelled_at else 'ندارد'}",
        f"حضور: حاضر {attended} · غایب {no_show} · بدون علامت {unmarked}",
    ]
    if payment:
        payment_status = admin_status_display_label(payment.status)
        lines += ["", "<b>بررسی پرداخت</b>", f"وضعیت پرداخت: {escape(payment_status)}",
                  f"مبلغ رکورد پرداخت: {int(payment.amount or 0):,}",
                  f"رسید: {'ثبت شده' if (payment.receipt_file or payment.receipt_text) else 'ثبت نشده'}",
                  f"نام فایل رسید: {escape(str(payment.receipt_file_name or 'ندارد')[:120])}",
                  f"زمان ارسال رسید: {payment.receipt_uploaded_at.strftime('%Y-%m-%d %H:%M') if payment.receipt_uploaded_at else 'نامشخص'}",
                  f"بازبین شناسهٔ تلگرام: {reviewer_telegram_id if reviewer_telegram_id else 'نامشخص'}",
                  f"زمان بررسی: {payment.reviewed_at.strftime('%Y-%m-%d %H:%M') if payment.reviewed_at else 'نامشخص'}"]
    else:
        lines += ["", "برای این رزرو رکورد Payment ایجاد نشده است."]
    if getattr(booking, "cancellation_resolution", None) and str(booking.cancellation_resolution) not in {"not_required", "resolved"}:
        lines += ["", f"پیگیری لغو/مالی: {escape(str(booking.cancellation_resolution))}"]
        if getattr(booking, "cancellation_resolution_note", None):
            lines.append(f"یادداشت پیگیری: {escape(str(booking.cancellation_resolution_note)[:300])}")
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 تاریخچه رزروها", callback_data=f"admin:console:profile:bookings:{user_id}:{page}")],
        [InlineKeyboardButton(text="👤 پروفایل کاربر", callback_data=f"admin:console:user:{user_id}")],
    ]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:profile:community:\d+$"))
async def console_user_profile_community(c: CallbackQuery, state: FSMContext):
    """Display stored Passport, challenge, review, suggestion and Wrapped details."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        profile = await session.get(CommunityProfile, int(user.telegram_id))
        xp = await total_xp(session, int(user.telegram_id))
        referrals = await count_referrals_for_telegram_id(session, int(user.telegram_id))
        badges = (await session.execute(select(AchievementUnlock).where(
            AchievementUnlock.telegram_id == int(user.telegram_id)
        ).order_by(AchievementUnlock.unlocked_at.desc()).limit(8))).scalars().all()
        challenges = (await session.execute(select(
            CommunityChallenge.title, ChallengeSubmission.judging_status,
            ChallengeSubmission.selected_place, ChallengeSubmission.submitted_at,
        ).join(ChallengeSubmission, ChallengeSubmission.challenge_id == CommunityChallenge.id)
         .where(ChallengeSubmission.telegram_id == int(user.telegram_id))
         .order_by(ChallengeSubmission.submitted_at.desc()).limit(4))).all()
        suggestions = (await session.execute(select(TopicSuggestion.title, TopicSuggestion.status, TopicSuggestion.created_at)
            .where(TopicSuggestion.user_id == user.id).order_by(TopicSuggestion.created_at.desc()).limit(3))).all()
        questions = (await session.execute(select(Question.question_text, Question.category, Question.status, Question.created_at)
            .where(Question.submitted_by == user.id).order_by(Question.created_at.desc()).limit(3))).all()
        reviews = (await session.execute(select(Review.rating, Review.text, Review.created_at, Event.title)
            .outerjoin(Event, Event.id == Review.event_id).where(Review.user_id == user.id)
            .order_by(Review.created_at.desc()).limit(3))).all()
        wrapped = (await session.execute(select(WrappedReport.report_year, WrappedReport.status, WrappedReport.generated_at)
            .where(WrappedReport.telegram_id == int(user.telegram_id))
            .order_by(WrappedReport.report_year.desc()).limit(3))).all()
        xp_rows = (await session.execute(select(XPAward.points, XPAward.award_type, XPAward.note, XPAward.created_at)
            .where(XPAward.telegram_id == int(user.telegram_id)).order_by(XPAward.created_at.desc(), XPAward.id.desc()).limit(5))).all()
        question_count = int(await session.scalar(select(func.count(Question.id)).where(Question.submitted_by == user.id)) or 0)
        suggestion_count = int(await session.scalar(select(func.count(TopicSuggestion.id)).where(TopicSuggestion.user_id == user.id)) or 0)
        review_count = int(await session.scalar(select(func.count(Review.id)).where(Review.user_id == user.id)) or 0)
    if profile is None:
        passport_lines = [f"XP ثبت‌شده: {xp}", "پاسپورت: داده‌های تجمیعی جامعه برای این کاربر هنوز ثبت نشده است."]
    else:
        passport_lines = [
            f"پاسپورت · امتیاز: {xp}", f"چالش‌ها: {int(profile.challenge_participations or 0)} · پاسخ درست: {int(profile.correct_answers or 0)}",
            f"رتبه‌های خلاقانه ۱/۲/۳: {int(profile.creative_first or 0)}/{int(profile.creative_second or 0)}/{int(profile.creative_third or 0)}",
            f"نظرها: {int(profile.reviews_submitted or 0)} · مشارکت تقدیرشده: {int(profile.recognized_contributions or 0)}",
            f"پیوستگی فعلی/بهترین: {int(profile.current_streak or 0)}/{int(profile.best_streak or 0)} · ارجاع‌های موفق: {referrals}",
        ]
    lines = [f"🏅 <b>پاسپورت و فعالیت‌های جامعه · {escape(_name(user))}</b>", "", *passport_lines, "", f"<b>نشان‌های ثبت‌شده ({len(badges)} مورد اخیر)</b>"]
    lines.extend([f"• {escape(b.title)} · {b.unlocked_at.strftime('%Y-%m-%d') if b.unlocked_at else '—'}" for b in badges] or ["• نشان ثبت‌شده‌ای وجود ندارد"])
    lines += ["", "<b>چالش‌های اخیر</b>"]
    lines.extend([f"• {escape(str(title or 'چالش'))[:70]} · {escape(admin_status_display_label(status))} · رتبه {int(place) if place else '—'} · {submitted.strftime('%Y-%m-%d') if submitted else '—'}" for title, status, place, submitted in challenges] or ["• سابقهٔ قابل نمایش وجود ندارد"])
    lines += ["", f"<b>پیشنهاد موضوع ({suggestion_count})</b>"]
    lines.extend([f"• {escape(str(title)[:70])} · {escape(admin_status_display_label(status))}" for title, status, _created in suggestions] or ["• موردی ثبت نشده"])
    lines += ["", f"<b>سؤال‌های ارسالی ({question_count})</b>"]
    lines.extend([f"• {escape(str(question)[:90])} · {escape(str(category or '—'))} · {escape(admin_status_display_label(status))}" for question, category, status, _created in questions] or ["• موردی ثبت نشده"])
    lines += ["", f"<b>نظرها ({review_count})</b>"]
    lines.extend([f"• {escape(str(title or 'پنل'))[:45]} · امتیاز {int(rating) if rating is not None else 'بدون امتیاز'} · {escape(str(review_text or '')[:90])}" for rating, review_text, _created, title in reviews] or ["• موردی ثبت نشده"])
    lines += ["", "<b>XP اخیر</b>"]
    lines.extend([f"• {int(points):+d} · {escape(str(kind))} · {escape(str(note or '—')[:70])} · {created.strftime('%Y-%m-%d') if created else '—'}" for points, kind, note, created in xp_rows] or ["• رکورد XP ثبت نشده"])
    lines += ["", "<b>Wrapped</b>"]
    lines.extend([f"• {int(year)} · {escape(admin_status_display_label(status))} · {generated.strftime('%Y-%m-%d') if generated else '—'}" for year, status, generated in wrapped] or ["• گزارش ذخیره‌شده‌ای وجود ندارد"])
    community_text = "\n".join(lines)
    if len(community_text) > 3900:
        compact_lines = list(lines)
        while compact_lines and len("\n".join(compact_lines)) > 3800:
            compact_lines.pop()
        compact_lines.append("… ادامهٔ سوابق برای کوتاه‌ماندن صفحه نمایش داده نشد.")
        community_text = "\n".join(compact_lines)
    await c.message.edit_text(community_text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📚 رزروها و پرداخت‌ها", callback_data=f"admin:console:profile:bookings:{user_id}:0")],
        [InlineKeyboardButton(text="👤 پروفایل کاربر", callback_data=f"admin:console:user:{user_id}")],
    ]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:role:\d+$"))
async def console_role_options(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    target_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, target_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        if _is_owner(user.telegram_id):
            return await c.answer("نقش مالک محافظت‌شده قابل تغییر نیست.", show_alert=True)
        old_role = _role(user)
    allowed_host_management = await _can_manage_role_change(c.from_user.id, old_role, UserRole.HOST) or await _can_manage_role_change(c.from_user.id, old_role, UserRole.PARTICIPANT)
    if not _is_owner(c.from_user.id) and not allowed_host_management:
        return await c.answer("فقط مالک یا مدیر دارای مجوز مدیریت میزبان می‌تواند نقش این کاربر را تغییر دهد.", show_alert=True)
    rows = []
    if _is_owner(c.from_user.id):
        rows.append([InlineKeyboardButton(text="👑 مدیر", callback_data=f"admin:console:role:prepare:{target_id}:SUPER_ADMIN")])
    if _is_owner(c.from_user.id) or allowed_host_management:
        rows.append([InlineKeyboardButton(text="🎤 میزبان", callback_data=f"admin:console:role:prepare:{target_id}:HOST")])
        rows.append([InlineKeyboardButton(text="👥 شرکت‌کننده", callback_data=f"admin:console:role:prepare:{target_id}:PARTICIPANT")])
    rows.append([InlineKeyboardButton(text="🔙 پروفایل", callback_data=f"admin:console:user:{target_id}")])
    await c.message.edit_text("نقش جدید را انتخاب کنید. نقش مدیر و حساب مالک محافظت‌شده فقط از سوی مالک قابل تغییر است؛ تغییر نقش با دلیل الزامی و تأیید نهایی انجام می‌شود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:role:prepare:\d+:(SUPER_ADMIN|HOST|PARTICIPANT)$"))
async def console_role_prepare(c: CallbackQuery, state: FSMContext):
    parts = (c.data or "").split(":")
    user_id, new_role_name = int(parts[4]), parts[5]
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        if _is_owner(user.telegram_id):
            return await c.answer("نقش مالک محافظت‌شده از این مسیر قابل تغییر نیست.", show_alert=True)
        new_role = UserRole(new_role_name)
        old_role = _role(user)
        if not await _can_manage_role_change(c.from_user.id, old_role, new_role):
            return await c.answer("اجازهٔ این تغییر نقش وجود ندارد.", show_alert=True)
        if old_role == new_role:
            return await c.answer("این کاربر هم‌اکنون همین نقش را دارد.", show_alert=True)
    await state.clear()
    await state.update_data(role_target_user_id=user_id, role_target_telegram_id=int(user.telegram_id), role_new_role=new_role_name)
    await state.set_state(AdminConsoleStates.role_reason)
    await c.message.edit_text(f"تغییر نقش {escape(_name(user))} از {ROLE_LABELS.get(old_role, 'شرکت‌کننده')} به {ROLE_LABELS[new_role]}\n\nدلیل تغییر را وارد کنید (الزامی):", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:user:{user_id}")]]))
    await c.answer()


@router.message(AdminConsoleStates.role_reason)
async def console_role_reason(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    reason = (message.text or "").strip()
    if len(reason) < 3 or len(reason) > 500:
        return await message.answer("دلیل باید بین ۳ تا ۵۰۰ نویسه باشد.")
    data = await state.get_data()
    async with SessionLocal() as session:
        target = await session.get(User, int(data.get("role_target_user_id", 0)))
        if not target or _is_owner(target.telegram_id):
            await state.clear()
            return await message.answer("هدف تغییر نقش معتبر نیست یا نقش آن محافظت می‌شود.")
        new_role = UserRole(str(data["role_new_role"]))
        old_role = _role(target)
        if not await _can_manage_role_change(message.from_user.id, old_role, new_role):
            await state.clear()
            return await message.answer("اجازهٔ این تغییر نقش وجود ندارد.")
    token = secrets.token_hex(12)
    await state.update_data(role_reason=reason, role_token=token)
    await state.set_state(AdminConsoleStates.role_confirm)
    rows = [[InlineKeyboardButton(text="✅ تأیید تغییر نقش", callback_data=f"admin:console:role:confirm:{data['role_target_user_id']}:{token}")], [InlineKeyboardButton(text="❌ لغو", callback_data=f"admin:console:user:{data['role_target_user_id']}")]]
    await message.answer(f"<b>پیش‌نمایش تغییر نقش</b>\nکاربر: {escape(_name(target))} (<code>{int(target.telegram_id)}</code>)\nنقش قبلی: {ROLE_LABELS.get(old_role, 'شرکت‌کننده')}\nنقش جدید: {ROLE_LABELS[new_role]}\nدلیل: {escape(reason)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:console:role:confirm:\d+:[a-f0-9]+$"))
async def console_role_confirm(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    user_id, token = int(parts[4]), parts[5]
    data = await state.get_data()
    if data.get("role_token") != token or int(data.get("role_target_user_id", 0)) != user_id:
        return await c.answer("این تأیید منقضی شده است؛ تغییر را از ابتدا شروع کنید.", show_alert=True)
    async with SessionLocal() as session:
        target = (await session.execute(select(User).where(User.id == user_id).with_for_update())).scalar_one_or_none()
        if not target or _is_owner(target.telegram_id):
            return await c.answer("هدف نامعتبر یا محافظت‌شده است.", show_alert=True)
        old_role = _role(target)
        new_role = UserRole(str(data["role_new_role"]))
        if not await _can_manage_role_change(c.from_user.id, old_role, new_role):
            return await c.answer("اجازهٔ این تغییر نقش دیگر معتبر نیست.", show_alert=True)
        if old_role == new_role:
            await state.clear()
            return await c.answer("نقش تغییر نکرده است.", show_alert=True)
        target.role = new_role
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="user_role_changed", entity_type="user", entity_id=user_id, details={"target_telegram_id": int(target.telegram_id), "previous_role": old_role.value if old_role else None, "new_role": new_role.value, "reason": data.get("role_reason")})
        await session.commit()
        telegram_id = int(target.telegram_id)
    await state.clear()
    await c.message.edit_text(f"✅ نقش کاربر <code>{telegram_id}</code> به {ROLE_LABELS[new_role]} تغییر یافت.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 مشاهدهٔ پروفایل", callback_data=f"admin:console:user:{user_id}")], [InlineKeyboardButton(text="🛡 نقش‌ها", callback_data="admin:console:roles")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:xp:\d+$"))
async def console_xp_menu(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        xp = await total_xp(session, user.telegram_id)
    rows = [
        [InlineKeyboardButton(text="➕ افزودن XP", callback_data=f"admin:console:xp:start:{user_id}:add"), InlineKeyboardButton(text="➖ کسر XP", callback_data=f"admin:console:xp:start:{user_id}:subtract")],
        [InlineKeyboardButton(text="🎯 تعیین موجودی دقیق", callback_data=f"admin:console:xp:start:{user_id}:set")],
        [InlineKeyboardButton(text="🔙 پروفایل", callback_data=f"admin:console:user:{user_id}")],
    ]
    await c.message.edit_text(f"⭐ <b>مدیریت XP</b>\nکاربر: {escape(_name(user))}\nموجودی فعلی: <b>{xp}</b>\n\nهر تغییر با دلیل الزامی و به‌صورت افزایشی در دفتر XP ثبت می‌شود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:xp:start:\d+:(add|subtract|set)$"))
async def console_xp_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    user_id, mode = int(parts[4]), parts[5]
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        xp = await total_xp(session, user.telegram_id)
    await state.clear()
    await state.update_data(xp_target_user_id=user_id, xp_target_telegram_id=int(user.telegram_id), xp_mode=mode, xp_base_balance=xp)
    await state.set_state(AdminConsoleStates.xp_amount)
    label = {"add": "مقدار XP برای افزودن", "subtract": "مقدار XP برای کسر", "set": "موجودی نهایی XP"}[mode]
    await c.message.edit_text(f"{label} را به‌صورت عدد صحیح وارد کنید. موجودی فعلی: <b>{xp}</b>\nحداکثر مقدار مجاز: ۱٬۰۰۰٬۰۰۰.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:xp:{user_id}")]]))
    await c.answer()


@router.message(AdminConsoleStates.xp_amount)
async def console_xp_amount(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    if not raw.isdigit() or int(raw) > 1_000_000:
        return await message.answer("عدد صحیح بین صفر تا ۱٬۰۰۰٬۰۰۰ وارد کنید.")
    data = await state.get_data()
    amount = int(raw)
    if data.get("xp_mode") in {"add", "subtract"} and amount < 1:
        return await message.answer("برای افزودن یا کسر، عدد باید بزرگ‌تر از صفر باشد.")
    await state.update_data(xp_amount=amount)
    await state.set_state(AdminConsoleStates.xp_reason)
    await message.answer("دلیل تغییر XP را وارد کنید (۳ تا ۳۰۰ نویسه):")


@router.message(AdminConsoleStates.xp_reason)
async def console_xp_reason(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    reason = (message.text or "").strip()
    if not 3 <= len(reason) <= 300:
        return await message.answer("دلیل باید بین ۳ تا ۳۰۰ نویسه باشد.")
    data = await state.get_data()
    async with SessionLocal() as session:
        user = await session.get(User, int(data.get("xp_target_user_id", 0)))
        if not user:
            await state.clear()
            return await message.answer("کاربر پیدا نشد؛ عملیات لغو شد.")
        current = await total_xp(session, user.telegram_id)
    amount = int(data["xp_amount"])
    mode = str(data["xp_mode"])
    delta = amount if mode == "add" else (-amount if mode == "subtract" else amount - current)
    result = current + delta
    if result < 0:
        return await message.answer(f"این تغییر موجودی را منفی می‌کند ({result}). مقدار کمتری وارد کنید.")
    token = secrets.token_hex(12)
    await state.update_data(xp_reason=reason, xp_token=token, xp_current_preview=current, xp_delta=delta, xp_result_preview=result)
    rows = [[InlineKeyboardButton(text="✅ تأیید و اعمال XP", callback_data=f"admin:console:xp:confirm:{data['xp_target_user_id']}:{token}")], [InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:user:{data['xp_target_user_id']}")]]
    await state.set_state(AdminConsoleStates.xp_confirm)
    await message.answer(f"<b>پیش‌نمایش تغییر XP</b>\nموجودی فعلی: {current}\nتغییر: {delta:+d}\nموجودی جدید: {result}\nدلیل: {escape(reason)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:console:xp:confirm:\d+:[a-f0-9]+$"))
async def console_xp_confirm(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    user_id, token = int(parts[4]), parts[5]
    data = await state.get_data()
    if data.get("xp_token") != token or int(data.get("xp_target_user_id", 0)) != user_id:
        return await c.answer("این تأیید منقضی شده است؛ تغییر XP را دوباره شروع کنید.", show_alert=True)
    async with SessionLocal() as session:
        user = (await session.execute(select(User).where(User.id == user_id).with_for_update())).scalar_one_or_none()
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        current = await total_xp(session, user.telegram_id)
        if current != int(data.get("xp_current_preview", -1)):
            return await c.answer("موجودی XP هم‌زمان تغییر کرده است؛ برای جلوگیری از اعمال مقدار کهنه، عملیات را دوباره شروع کنید.", show_alert=True)
        if current + int(data["xp_delta"]) < 0:
            return await c.answer("موجودی نمی‌تواند منفی شود.", show_alert=True)
        award_key = f"admin-manual-xp:{token}"
        existing = (await session.execute(select(XPAward.id).where(XPAward.award_key == award_key))).scalar_one_or_none()
        if existing is not None:
            return await c.answer("این تغییر قبلاً اعمال شده است.", show_alert=True)
        session.add(XPAward(telegram_id=int(user.telegram_id), points=int(data["xp_delta"]), award_type="admin_manual_adjustment", award_key=award_key, note=str(data["xp_reason"])[:300]))
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="user_xp_adjusted", entity_type="user", entity_id=user_id, details={"target_telegram_id": int(user.telegram_id), "previous_balance": current, "delta": int(data["xp_delta"]), "resulting_balance": current + int(data["xp_delta"]), "reason": data["xp_reason"], "xp_award_key": award_key})
        await session.commit()
        result = current + int(data["xp_delta"])
        tg_id = int(user.telegram_id)
    await state.clear()
    await c.message.edit_text(f"✅ XP به‌روزرسانی شد.\nموجودی قبلی: {current}\nتغییر: {int(data['xp_delta']):+d}\nموجودی جدید: <b>{result}</b>", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 پروفایل کاربر", callback_data=f"admin:console:user:{user_id}")], [InlineKeyboardButton(text="⭐ مدیریت XP", callback_data=f"admin:console:xp:{user_id}")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:note:\d+$"))
async def console_note_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
    await state.clear()
    await state.update_data(note_target_user_id=user_id)
    await state.set_state(AdminConsoleStates.note_text)
    await c.message.edit_text(f"یادداشت داخلی برای {escape(_name(user))} را ارسال کنید (۱۰ تا ۲۰۰۰ نویسه). این یادداشت به کاربر یا میزبان نمایش داده نمی‌شود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:user:{user_id}")]]))
    await c.answer()


@router.message(AdminConsoleStates.note_text)
async def console_note_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    note = (message.text or "").strip()
    if not 10 <= len(note) <= 2000:
        return await message.answer("یادداشت باید بین ۱۰ تا ۲۰۰۰ نویسه باشد.")
    data = await state.get_data()
    async with SessionLocal() as session:
        target = await session.get(User, int(data.get("note_target_user_id", 0)))
        if not target:
            await state.clear()
            return await message.answer("کاربر پیدا نشد؛ یادداشت ذخیره نشد.")
        row = AdminUserNote(target_user_id=target.id, actor_telegram_id=message.from_user.id, note_text=note)
        session.add(row)
        await write_admin_action(session, actor_telegram_id=message.from_user.id, action="user_internal_note_added", entity_type="user", entity_id=target.id, details={"note_id": None, "length": len(note)})
        await session.commit()
        user_id = target.id
    await state.clear()
    await message.answer("✅ یادداشت داخلی ذخیره شد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 پروفایل کاربر", callback_data=f"admin:console:user:{user_id}")]]))


@router.callback_query(F.data.regexp(r"^admin:console:message:\d+$"))
async def console_message_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
    await state.clear()
    await state.update_data(message_target_user_id=user_id, message_target_telegram_id=int(user.telegram_id))
    await state.set_state(AdminConsoleStates.message_text)
    await c.message.edit_text(f"پیام خصوصی برای {escape(_name(user))} را بنویسید (حداکثر ۳۵۰۰ نویسه). پیش از ارسال، پیش‌نمایش و تأیید نمایش داده می‌شود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:user:{user_id}")]]))
    await c.answer()


@router.message(AdminConsoleStates.message_text)
async def console_message_preview(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    body = (message.text or "").strip()
    if not body or len(body) > 3500:
        return await message.answer("پیام باید بین ۱ تا ۳۵۰۰ نویسه باشد.")
    data = await state.get_data()
    token = secrets.token_hex(10)
    await state.update_data(message_body=body, message_token=token)
    await state.set_state(AdminConsoleStates.message_confirm)
    rows = [[InlineKeyboardButton(text="✅ ارسال پیام خصوصی", callback_data=f"admin:console:message:send:{data['message_target_user_id']}:{token}")], [InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:user:{data['message_target_user_id']}")]]
    await message.answer(f"<b>پیش‌نمایش پیام خصوصی</b>\nگیرنده: <code>{int(data['message_target_telegram_id'])}</code>\n\n{escape(body)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:console:message:send:\d+:[a-f0-9]+$"))
async def console_message_send(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    user_id, token = int(parts[4]), parts[5]
    data = await state.get_data()
    if data.get("message_token") != token or int(data.get("message_target_user_id", 0)) != user_id:
        return await c.answer("این پیش‌نمایش منقضی شده است.", show_alert=True)
    body, target_tg = str(data.get("message_body", "")), int(data.get("message_target_telegram_id", 0))
    async with SessionLocal() as session:
        target = await session.get(User, user_id)
        if not target or int(target.telegram_id) != target_tg:
            return await c.answer("گیرنده معتبر نیست.", show_alert=True)
        row = AdminPrivateMessage(actor_telegram_id=c.from_user.id, target_telegram_id=target_tg, message_text=body, status="pending")
        session.add(row)
        await session.commit()
        message_id = row.id
    try:
        await c.bot.send_message(target_tg, body, parse_mode=None, disable_web_page_preview=True)
        status, error = "sent", None
    except Exception as exc:
        status, error = "failed", f"{type(exc).__name__}: {str(exc)[:220]}"
    async with SessionLocal() as session:
        row = await session.get(AdminPrivateMessage, message_id)
        if row:
            row.status = status
            row.error_summary = error
            await write_admin_action(session, actor_telegram_id=c.from_user.id, action="admin_private_message_sent" if status == "sent" else "admin_private_message_failed", entity_type="user", entity_id=user_id, details={"target_telegram_id": target_tg, "message_id": message_id, "status": status, "error": error})
            await session.commit()
    await state.clear()
    outcome = "درخواست ارسال با موفقیت به Telegram تحویل داده شد؛ خوانده‌شدن قابل تأیید نیست." if status == "sent" else "ارسال ناموفق بود. ممکن است کاربر هنوز ربات را شروع نکرده یا ربات را مسدود کرده باشد."
    await c.message.edit_text(("✅ " if status == "sent" else "❌ ") + outcome, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 بازگشت به پروفایل", callback_data=f"admin:console:user:{user_id}")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:history:user:\d+$"))
async def console_user_history(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        notes = (await session.execute(select(AdminUserNote).where(AdminUserNote.target_user_id == user_id).order_by(AdminUserNote.created_at.desc()).limit(5))).scalars().all()
        moderation = (await session.execute(select(UserModerationRecord).where(UserModerationRecord.target_telegram_id == user.telegram_id).order_by(UserModerationRecord.created_at.desc()).limit(8))).scalars().all()
        messages = (await session.execute(select(AdminPrivateMessage).where(AdminPrivateMessage.target_telegram_id == user.telegram_id).order_by(AdminPrivateMessage.created_at.desc()).limit(5))).scalars().all()
        awards = (await session.execute(select(XPAward).where(XPAward.telegram_id == user.telegram_id, XPAward.award_type == "admin_manual_adjustment").order_by(XPAward.created_at.desc()).limit(5))).scalars().all()
    lines = [f"🕘 <b>تاریخچه مدیریتی · {escape(_name(user))}</b>", "", "<b>XP دستی</b>"]
    lines.extend([f"• {a.points:+d} XP · {escape(a.created_at.strftime('%Y-%m-%d') if a.created_at else '—')} · {escape(a.note or '—')[:100]}" for a in awards] or ["• موردی ثبت نشده"])
    lines += ["", "<b>نظارت و رسیدگی</b>"]
    lines.extend([f"• {escape(r.action)} / {escape(r.scope)} · {escape(r.reason[:100])} · {r.created_at.strftime('%Y-%m-%d') if r.created_at else '—'}" for r in moderation] or ["• موردی ثبت نشده"])
    lines += ["", "<b>پیام‌های خصوصی</b>"]
    lines.extend([f"• {escape(admin_status_display_label(m.status))} · {m.created_at.strftime('%Y-%m-%d') if m.created_at else '—'} · {escape(m.message_text[:80])}" for m in messages] or ["• موردی ثبت نشده"])
    lines += ["", "<b>یادداشت‌های داخلی</b>"]
    lines.extend([f"• {escape(n.created_at.strftime('%Y-%m-%d') if n.created_at else '—')} · نویسنده {int(n.actor_telegram_id)} · {escape(n.note_text[:100])}" for n in notes] or ["• موردی ثبت نشده"])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 پروفایل", callback_data=f"admin:console:user:{user_id}")], [InlineKeyboardButton(text="🔙 کاربران", callback_data="admin:console:users")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:moderation:\d+$"))
async def console_moderation_menu(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user:
            return await c.answer("کاربر پیدا نشد.", show_alert=True)
        if _role(user) == UserRole.SUPER_ADMIN or _is_owner(user.telegram_id):
            return await c.answer("برای جلوگیری از قفل‌شدن پنل، دسترسی مدیر یا مالک از این مسیر قابل محدودسازی نیست.", show_alert=True)
        blocked = await session.get(BlockedUser, user.telegram_id) is not None
        now = utc_now_naive()
        active_scopes = set((await session.execute(select(UserModerationRecord.scope).where(
            UserModerationRecord.target_telegram_id == int(user.telegram_id),
            UserModerationRecord.action == "restriction", UserModerationRecord.active.is_(True),
            or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
        ))).scalars().all())
    scope_summary = ", ".join({"booking": "رزرو", "suggestions": "پیشنهادها", "challenges": "چالش‌ها"}.get(x, x) for x in sorted(active_scopes)) or "هیچ‌کدام"
    rows = [
        [InlineKeyboardButton(text="⚠️ ثبت اخطار", callback_data=_moderation_start_callback(user_id, "warning"))],
        [InlineKeyboardButton(text="⏳ تعلیق ۲۴ ساعته", callback_data=_moderation_start_callback(user_id, "suspend24")), InlineKeyboardButton(text="⏳ تعلیق ۷ روزه", callback_data=_moderation_start_callback(user_id, "suspend7"))],
        [InlineKeyboardButton(text="⛔ مسدودسازی نامحدود", callback_data=_moderation_start_callback(user_id, "ban")) if not blocked else InlineKeyboardButton(text="✅ رفع مسدودیت", callback_data=_moderation_start_callback(user_id, "restore"))],
        [InlineKeyboardButton(text="🔧 محدودیت‌های تفکیکی قابلیت‌ها", callback_data=f"admin:console:moderation:scopes:{user_id}")],
        [InlineKeyboardButton(text="🔙 پروفایل", callback_data=f"admin:console:user:{user_id}")],
    ]
    await c.message.edit_text(f"🛡 <b>مدیریت دسترسی · {escape(_name(user))}</b>\n\nوضعیت حساب: {'مسدود' if blocked else 'فعال'}\nمحدودیت‌های تفکیکی فعال: {escape(scope_summary)}\n\nمحدودیت قابلیت‌ها جدا از مسدودسازی کل حساب است؛ رزرو، پیشنهادها و چالش‌ها را مستقل می‌توان کنترل کرد. اطلاعات رزرو، پرداخت و XP حذف نمی‌شود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


_FEATURE_SCOPE_LABELS = {"booking": "ثبت رزرو پنل", "suggestions": "ارسال پیشنهاد و بازخورد", "challenges": "ارسال پاسخ چالش"}

_MODERATION_ACTION_CODES = {
    "warning": "w", "suspend24": "s24", "suspend7": "s7", "ban": "b", "restore": "r",
    "restrict_booking_24": "b24", "restrict_booking_7": "b7", "restrict_booking_forever": "bf",
    "restrict_suggestions_24": "s24x", "restrict_suggestions_7": "s7x", "restrict_suggestions_forever": "sfx",
    "restrict_challenges_24": "c24", "restrict_challenges_7": "c7", "restrict_challenges_forever": "cf",
    "unrestrict_booking": "ub", "unrestrict_suggestions": "us", "unrestrict_challenges": "uc",
}
_MODERATION_CODE_ACTIONS = {value: key for key, value in _MODERATION_ACTION_CODES.items()}


def _moderation_start_callback(user_id: int, action: str) -> str:
    code = _MODERATION_ACTION_CODES.get(action)
    if not code:
        raise ValueError(f"Unknown moderation action: {action}")
    return f"mc:{int(user_id)}:{code}"



@router.callback_query(F.data.regexp(r"^admin:console:moderation:scopes:\d+$"))
async def console_moderation_scopes(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    user_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user or _role(user) == UserRole.SUPER_ADMIN or _is_owner(user.telegram_id):
            return await c.answer("کاربر هدف معتبر نیست یا حساب مدیریتی محافظت می‌شود.", show_alert=True)
        now = utc_now_naive()
        active = set((await session.execute(select(UserModerationRecord.scope).where(
            UserModerationRecord.target_telegram_id == int(user.telegram_id),
            UserModerationRecord.action == "restriction", UserModerationRecord.active.is_(True),
            or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
        ))).scalars().all())
    rows = []
    for scope, label in _FEATURE_SCOPE_LABELS.items():
        prefix = "✅ فعال" if scope in active else "⚪ غیرفعال"
        rows.append([InlineKeyboardButton(text=f"{prefix} · {label}", callback_data=f"admin:console:moderation:scope:{user_id}:{scope}")])
    rows.append([InlineKeyboardButton(text="🔙 مدیریت دسترسی", callback_data=f"admin:console:moderation:{user_id}")])
    await c.message.edit_text(f"🔧 <b>محدودیت‌های تفکیکی</b>\nکاربر: {escape(_name(user))}\n\nاین محدودیت‌ها فقط قابلیت انتخاب‌شده را متوقف می‌کنند و دسترسی به سایر بخش‌های ربات را حفظ می‌کنند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:moderation:scope:\d+:(booking|suggestions|challenges)$"))
async def console_moderation_scope_options(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    user_id, scope = int(parts[4]), parts[5]
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user or _role(user) == UserRole.SUPER_ADMIN or _is_owner(user.telegram_id):
            return await c.answer("کاربر هدف معتبر نیست یا حساب مدیریتی محافظت می‌شود.", show_alert=True)
        now = utc_now_naive()
        active = (await session.execute(select(UserModerationRecord).where(
            UserModerationRecord.target_telegram_id == int(user.telegram_id),
            UserModerationRecord.action == "restriction", UserModerationRecord.scope == scope,
            UserModerationRecord.active.is_(True),
            or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
        ).order_by(UserModerationRecord.created_at.desc()).limit(1))).scalar_one_or_none()
    rows = [
        [InlineKeyboardButton(text="⏳ محدودیت ۲۴ ساعته", callback_data=_moderation_start_callback(user_id, f"restrict_{scope}_24")), InlineKeyboardButton(text="⏳ محدودیت ۷ روزه", callback_data=_moderation_start_callback(user_id, f"restrict_{scope}_7"))],
        [InlineKeyboardButton(text="⛔ محدودیت تا لغو دستی", callback_data=_moderation_start_callback(user_id, f"restrict_{scope}_forever"))],
    ]
    if active:
        rows.append([InlineKeyboardButton(text="✅ لغو محدودیت فعال", callback_data=_moderation_start_callback(user_id, f"unrestrict_{scope}"))])
    rows.append([InlineKeyboardButton(text="🔙 محدودیت‌های تفکیکی", callback_data=f"admin:console:moderation:scopes:{user_id}")])
    expiry_text = (f"تا {active.expires_at.strftime('%Y-%m-%d %H:%M')}" if active and active.expires_at else "تا لغو دستی") if active else "فعال نیست"
    await c.message.edit_text(f"🔧 <b>{_FEATURE_SCOPE_LABELS[scope]}</b>\nوضعیت فعلی: {expiry_text}\n\nمدت محدودیت را انتخاب کنید. اجرای هر تغییر به دلیل و تأیید نهایی نیاز دارد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^(mc:\d+:[a-z0-9]+|admin:console:moderation:start:\d+:(warning|suspend24|suspend7|ban|restore|restrict_(booking|suggestions|challenges)_(24|7|forever)|unrestrict_(booking|suggestions|challenges)))$"))
async def console_moderation_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    if parts[0] == "mc" and len(parts) == 3:
        user_id, action = int(parts[1]), _MODERATION_CODE_ACTIONS.get(parts[2], "")
        if not action:
            return await c.answer("این گزینه معتبر نیست؛ فهرست را تازه کنید.", show_alert=True)
    else:
        user_id, action = int(parts[4]), parts[5]
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        if not user or _is_owner(user.telegram_id) or _role(user) == UserRole.SUPER_ADMIN:
            return await c.answer("کاربر هدف معتبر نیست یا حساب مدیریتی محافظت می‌شود.", show_alert=True)
    await state.clear()
    await state.update_data(moderation_target_user_id=user_id, moderation_target_telegram_id=int(user.telegram_id), moderation_action=action)
    await state.set_state(AdminConsoleStates.moderation_reason)
    labels = {"warning": "اخطار", "suspend24": "تعلیق دسترسی برای ۲۴ ساعت", "suspend7": "تعلیق دسترسی برای ۷ روز", "ban": "مسدودسازی نامحدود", "restore": "رفع محدودیت و بازگرداندن دسترسی"}
    if action.startswith("restrict_"):
        _, scope, duration = action.split("_", 2)
        duration_label = {"24": "۲۴ ساعت", "7": "۷ روز", "forever": "تا لغو دستی"}[duration]
        labels[action] = f"محدودیت { _FEATURE_SCOPE_LABELS[scope] } · {duration_label}"
    elif action.startswith("unrestrict_"):
        scope = action.split("_", 1)[1]
        labels[action] = f"رفع محدودیت { _FEATURE_SCOPE_LABELS[scope] }"
    await c.message.edit_text(f"اقدام انتخابی: <b>{labels[action]}</b>\nدلیل را وارد کنید (الزامی، ۳ تا ۵۰۰ نویسه):", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:console:moderation:{user_id}")]]))
    await c.answer()


@router.message(AdminConsoleStates.moderation_reason)
async def console_moderation_reason(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    reason = (message.text or "").strip()
    if not 3 <= len(reason) <= 500:
        return await message.answer("دلیل باید بین ۳ تا ۵۰۰ نویسه باشد.")
    data = await state.get_data()
    token = secrets.token_hex(10)
    await state.update_data(moderation_reason=reason, moderation_token=token)
    await state.set_state(AdminConsoleStates.moderation_confirm)
    labels = {"warning": "ثبت اخطار", "suspend24": "تعلیق ۲۴ ساعته", "suspend7": "تعلیق ۷ روزه", "ban": "مسدودسازی نامحدود", "restore": "رفع محدودیت"}
    action = str(data["moderation_action"])
    if action.startswith("restrict_"):
        _, scope, duration = action.split("_", 2)
        duration_label = {"24": "۲۴ ساعت", "7": "۷ روز", "forever": "تا لغو دستی"}[duration]
        labels[action] = f"محدودیت {_FEATURE_SCOPE_LABELS[scope]} · {duration_label}"
    elif action.startswith("unrestrict_"):
        scope = action.split("_", 1)[1]
        labels[action] = f"رفع محدودیت {_FEATURE_SCOPE_LABELS[scope]}"
    rows = [[InlineKeyboardButton(text="✅ تأیید اقدام", callback_data=f"admin:console:moderation:confirm:{data['moderation_target_user_id']}:{token}")], [InlineKeyboardButton(text="❌ لغو", callback_data=f"admin:console:user:{data['moderation_target_user_id']}")]]
    await message.answer(f"<b>پیش‌نمایش اقدام نظارتی</b>\nهدف: <code>{int(data['moderation_target_telegram_id'])}</code>\nاقدام: {labels[data['moderation_action']]}\nدلیل: {escape(reason)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:console:moderation:confirm:\d+:[a-f0-9]+$"))
async def console_moderation_confirm(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    user_id, token = int(parts[4]), parts[5]
    data = await state.get_data()
    if data.get("moderation_token") != token or int(data.get("moderation_target_user_id", 0)) != user_id:
        return await c.answer("این تأیید منقضی شده است.", show_alert=True)
    action, target_tg, reason = str(data["moderation_action"]), int(data["moderation_target_telegram_id"]), str(data["moderation_reason"])
    now = utc_now_naive()
    expires = now + timedelta(days=1 if action == "suspend24" else 7) if action in {"suspend24", "suspend7"} else None
    if action.startswith("restrict_"):
        duration = action.rsplit("_", 1)[1]
        expires = now + timedelta(hours=24) if duration == "24" else (now + timedelta(days=7) if duration == "7" else None)
    async with SessionLocal() as session:
        target = await session.get(User, user_id, with_for_update=True)
        if not target or int(target.telegram_id) != target_tg or _is_owner(target_tg) or _role(target) == UserRole.SUPER_ADMIN:
            return await c.answer("هدف نامعتبر یا مدیریتی و محافظت‌شده است.", show_alert=True)
        if action == "ban":
            if await session.get(BlockedUser, target_tg) is None:
                session.add(BlockedUser(telegram_id=target_tg, blocked_by_telegram_id=c.from_user.id, blocked_at=now))
            audit_action = "user_banned"
            session.add(UserModerationRecord(target_telegram_id=target_tg, actor_telegram_id=c.from_user.id, action="ban", scope="account", reason=reason, active=True, created_at=now))
        elif action == "restore":
            await session.execute(delete(BlockedUser).where(BlockedUser.telegram_id == target_tg))
            await session.execute(update(UserModerationRecord).where(UserModerationRecord.target_telegram_id == target_tg, UserModerationRecord.active.is_(True), UserModerationRecord.action.in_(("suspension", "ban"))).values(active=False, resolved_at=now))
            session.add(UserModerationRecord(target_telegram_id=target_tg, actor_telegram_id=c.from_user.id, action="restore", scope="account", reason=reason, active=False, resolved_at=now, created_at=now))
            audit_action = "user_access_restored"
        elif action == "warning":
            session.add(UserModerationRecord(target_telegram_id=target_tg, actor_telegram_id=c.from_user.id, action="warning", scope="account", reason=reason, active=False, created_at=now))
            audit_action = "user_warning_issued"
        elif action.startswith("restrict_"):
            _, scope, _duration = action.split("_", 2)
            await session.execute(update(UserModerationRecord).where(
                UserModerationRecord.target_telegram_id == target_tg,
                UserModerationRecord.action == "restriction", UserModerationRecord.scope == scope,
                UserModerationRecord.active.is_(True),
            ).values(active=False, resolved_at=now))
            session.add(UserModerationRecord(target_telegram_id=target_tg, actor_telegram_id=c.from_user.id, action="restriction", scope=scope, reason=reason, active=True, expires_at=expires, created_at=now))
            audit_action = "user_feature_restricted"
        elif action.startswith("unrestrict_"):
            scope = action.split("_", 1)[1]
            await session.execute(update(UserModerationRecord).where(
                UserModerationRecord.target_telegram_id == target_tg,
                UserModerationRecord.action == "restriction", UserModerationRecord.scope == scope,
                UserModerationRecord.active.is_(True),
            ).values(active=False, resolved_at=now))
            session.add(UserModerationRecord(target_telegram_id=target_tg, actor_telegram_id=c.from_user.id, action="restriction_removed", scope=scope, reason=reason, active=False, resolved_at=now, created_at=now))
            audit_action = "user_feature_restriction_removed"
        else:
            # New suspension replaces prior account suspensions for predictable status.
            await session.execute(update(UserModerationRecord).where(UserModerationRecord.target_telegram_id == target_tg, UserModerationRecord.action == "suspension", UserModerationRecord.active.is_(True)).values(active=False, resolved_at=now))
            session.add(UserModerationRecord(target_telegram_id=target_tg, actor_telegram_id=c.from_user.id, action="suspension", scope="account", reason=reason, active=True, expires_at=expires, created_at=now))
            audit_action = "user_suspended"
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action=audit_action, entity_type="user", entity_id=user_id, details={"target_telegram_id": target_tg, "moderation_action": action, "reason": reason, "expires_at": expires})
        await session.commit()
    await state.clear()
    destination = f"admin:console:moderation:scopes:{user_id}" if action.startswith(("restrict_", "unrestrict_")) else f"admin:console:moderation:{user_id}"
    await c.message.edit_text("✅ اقدام نظارتی ثبت شد. تاریخچه و دسترسی کاربر به‌روزرسانی شده است.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🛡 ادامهٔ مدیریت دسترسی", callback_data=destination)], [InlineKeyboardButton(text="👤 پروفایل کاربر", callback_data=f"admin:console:user:{user_id}")]]))
    await c.answer()

# -----------------------------------------------------------------------------
# Signed-up People: confirmed-only by default, status-aware Show All view
# -----------------------------------------------------------------------------

_REGISTRATION_LABELS = {
    RegistrationStatus.INITIATED: "در حال تکمیل",
    RegistrationStatus.PENDING_PAYMENT: "در انتظار پرداخت",
    RegistrationStatus.PENDING_VERIFICATION: "در انتظار بررسی رسید",
    RegistrationStatus.CONFIRMED: "تأییدشده",
    RegistrationStatus.CANCELLED: "لغوشده",
    RegistrationStatus.REJECTED: "رسید ردشده",
    RegistrationStatus.EXPIRED: "مهلت پرداخت به پایان رسیده",
    RegistrationStatus.WAITLISTED: "در صف انتظار",
}


@router.callback_query(F.data.regexp(r"^admin:event:participants:\d+$"))
async def console_participants_default(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    await _render_signed_up_people(c, event_id, page=1, view="confirmed")
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:participants_page:\d+:\d+$"))
async def console_participants_confirmed_page(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    await _render_signed_up_people(c, int(parts[3]), page=int(parts[4]), view="confirmed")
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:participants_all:\d+:\d+$"))
async def console_participants_all(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    await _render_signed_up_people(c, int(parts[3]), page=int(parts[4]), view="all")
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:participants_filter:\d+:(all|pending|rejected|cancelled|initiated|expired|confirmed|waitlisted):\d+$"))
async def console_participants_filter(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    await _render_signed_up_people(c, int(parts[3]), page=int(parts[5]), view="all", status_filter=parts[4])
    await c.answer()


async def _render_signed_up_people(c: CallbackQuery, event_id: int, *, page: int, view: str, status_filter: str = "all"):
    if not await _is_admin(c.from_user.id):
        return await c.answer("فهرست افراد ثبت‌نام‌شده فقط برای مدیران مجاز است.", show_alert=True)
    from app.display_utils import volume_label

    page = max(1, int(page))
    async with SessionLocal() as session:
        event = await session.get(Event, int(event_id))
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        active_seats = await seats_used(session, event_id)
        grouped = (await session.execute(
            select(Booking.status, func.count(Booking.id), func.coalesce(func.sum(Booking.participant_count), 0))
            .where(Booking.event_id == event_id).group_by(Booking.status)
        )).all()
        counts = {str(getattr(st, "value", st)): {"bookings": int(n), "seats": int(seats)} for st, n, seats in grouped}
        waitlist_count = int(await session.scalar(select(func.count(WaitlistEntry.id)).where(
            WaitlistEntry.event_id == event_id, WaitlistEntry.status.in_(("waiting", "invited", "inviting"))
        )) or 0)
        confirmed_seats = counts.get(RegistrationStatus.CONFIRMED.value, {}).get("seats", 0)
        confirmed_bookings = counts.get(RegistrationStatus.CONFIRMED.value, {}).get("bookings", 0)

        if view == "confirmed":
            count = confirmed_bookings
            pages = max(1, (count + ROSTER_PAGE_SIZE - 1) // ROSTER_PAGE_SIZE)
            page = min(page, pages)
            bookings = (await session.execute(
                select(Booking).options(selectinload(Booking.participants), selectinload(Booking.booked_by))
                .where(Booking.event_id == event_id, Booking.status == RegistrationStatus.CONFIRMED)
                .order_by(Booking.confirmed_at.asc().nulls_last(), Booking.id.asc())
                .offset((page - 1) * ROSTER_PAGE_SIZE).limit(ROSTER_PAGE_SIZE)
            )).scalars().all()
            waitlist_rows = []
        elif status_filter == "waitlisted":
            count = waitlist_count
            pages = max(1, (count + ROSTER_PAGE_SIZE - 1) // ROSTER_PAGE_SIZE)
            page = min(page, pages)
            bookings = []
            waitlist_rows = (await session.execute(
                select(WaitlistEntry, User).outerjoin(User, WaitlistEntry.user_id == User.id)
                .where(WaitlistEntry.event_id == event_id, WaitlistEntry.status.in_(("waiting", "invited", "inviting")))
                .order_by(WaitlistEntry.position.asc(), WaitlistEntry.created_at.asc())
                .offset((page - 1) * ROSTER_PAGE_SIZE).limit(ROSTER_PAGE_SIZE)
            )).all()
        else:
            filter_statuses = {
                "pending": (RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.PENDING_VERIFICATION),
                "rejected": (RegistrationStatus.REJECTED,),
                "cancelled": (RegistrationStatus.CANCELLED,),
                "initiated": (RegistrationStatus.INITIATED,),
                "expired": (RegistrationStatus.EXPIRED,),
                "confirmed": (RegistrationStatus.CONFIRMED,),
            }
            stmt = select(Booking).options(selectinload(Booking.participants), selectinload(Booking.booked_by), selectinload(Booking.payment)).where(Booking.event_id == event_id)
            count_stmt = select(func.count(Booking.id)).where(Booking.event_id == event_id)
            if status_filter in filter_statuses:
                stmt = stmt.where(Booking.status.in_(filter_statuses[status_filter]))
                count_stmt = count_stmt.where(Booking.status.in_(filter_statuses[status_filter]))
            count = int(await session.scalar(count_stmt) or 0)
            pages = max(1, (count + ROSTER_PAGE_SIZE - 1) // ROSTER_PAGE_SIZE)
            page = min(page, pages)
            bookings = (await session.execute(stmt.order_by(Booking.created_at.desc(), Booking.id.desc()).offset((page - 1) * ROSTER_PAGE_SIZE).limit(ROSTER_PAGE_SIZE))).scalars().all()
            waitlist_rows = []

    heading = f"<b>{escape(str(event.title))}</b>\n{escape(volume_label(event.volume))}"
    if view == "confirmed":
        lines = [heading, f"✅ ثبت‌نام قطعی: <b>{confirmed_seats} / {int(event.capacity)}</b> · صندلی باقی‌مانده: {max(0, int(event.capacity) - active_seats)}", "نمای فعلی: فقط ثبت‌نام‌های تأییدشده", ""]
        pages = max(1, (confirmed_bookings + ROSTER_PAGE_SIZE - 1) // ROSTER_PAGE_SIZE)
        if not bookings:
            lines.append("هنوز ثبت‌نام تأییدشده‌ای وجود ندارد.")
        for index, booking in enumerate(bookings, start=(page - 1) * ROSTER_PAGE_SIZE + 1):
            names = [str(p.full_name or "—") for p in (booking.participants or [])]
            if not names:
                names = [_name(booking.booked_by)]
            names_text = ", ".join(names[:3]) + (f" و {len(names)-3} نفر دیگر" if len(names) > 3 else "")
            lines.append(f"{index}. {escape(names_text[:180])} · رزرو #{int(booking.id)}")
        rows = [[InlineKeyboardButton(text="📚 نمایش همهٔ وضعیت‌ها", callback_data=f"admin:event:participants_all:{event_id}:1")]]
        nav = []
        if page > 1:
            nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:event:participants_page:{event_id}:{page - 1}"))
        if page < pages:
            nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:event:participants_page:{event_id}:{page + 1}"))
        if nav: rows.append(nav)
    else:
        label_filter = {"all": "همه رزروها", "pending": "در انتظار پرداخت/بررسی", "rejected": "رسیدهای ردشده", "cancelled": "لغوشده‌ها", "initiated": "ثبت‌نام‌های ناتمام", "expired": "منقضی‌شده‌ها", "confirmed": "تأییدشده‌ها", "waitlisted": "لیست انتظار"}.get(status_filter, "همه رزروها")
        status_counts_text = " · ".join(f"{_REGISTRATION_LABELS.get(RegistrationStatus(k), k)}: {v['bookings']}" for k, v in counts.items() if v["bookings"])
        lines = [heading, f"ثبت‌نام قطعی: {confirmed_seats} / {int(event.capacity)} · صندلی باقی‌مانده: {max(0, int(event.capacity) - active_seats)}", f"نمایش همهٔ وضعیت‌ها: {label_filter}", f"رزروها برحسب وضعیت: {status_counts_text or 'بدون رزرو'} · لیست انتظار فعال: {waitlist_count}", f"صفحه {page}/{pages}", ""]
        if status_filter == "waitlisted":
            if not waitlist_rows:
                lines.append("ورودی فعالی در لیست انتظار وجود ندارد.")
            for entry, user in waitlist_rows:
                lines.append(f"• #{int(entry.id)} · جایگاه {int(entry.position)} · {escape(_name(user))} · {escape(admin_status_display_label(entry.status))} · {int(entry.requested_participant_count)} نفر")
        else:
            if not bookings:
                lines.append("رزروی با این وضعیت پیدا نشد.")
            for booking in bookings:
                status = getattr(booking.status, "value", booking.status)
                state_label = _REGISTRATION_LABELS.get(RegistrationStatus(str(status)), admin_status_display_label(status)) if str(status) in {x.value for x in RegistrationStatus} else admin_status_display_label(status)
                names = [str(p.full_name or "—") for p in (booking.participants or [])]
                if not names: names = [_name(booking.booked_by)]
                names_text = ", ".join(names[:3]) + (f" و {len(names)-3} نفر دیگر" if len(names) > 3 else "")
                payment = getattr(getattr(booking, "payment", None), "status", None)
                payment_label = admin_status_display_label(payment) if payment is not None else "رکورد پرداختی وجود ندارد"
                lines.append(f"• رزرو #{int(booking.id)} · {escape(state_label)} · {int(booking.participant_count)} نفر · {escape(str(payment_label))}\n  {escape(names_text[:220])}")
        rows = [
            [InlineKeyboardButton(text="همه", callback_data=f"admin:event:participants_filter:{event_id}:all:1"), InlineKeyboardButton(text="در انتظار", callback_data=f"admin:event:participants_filter:{event_id}:pending:1")],
            [InlineKeyboardButton(text="ردشده", callback_data=f"admin:event:participants_filter:{event_id}:rejected:1"), InlineKeyboardButton(text="لغوشده", callback_data=f"admin:event:participants_filter:{event_id}:cancelled:1")],
            [InlineKeyboardButton(text="تأییدشده", callback_data=f"admin:event:participants_filter:{event_id}:confirmed:1"), InlineKeyboardButton(text=f"لیست انتظار ({waitlist_count})", callback_data=f"admin:event:participants_filter:{event_id}:waitlisted:1")],
            [InlineKeyboardButton(text="✅ فقط قطعی‌ها", callback_data=f"admin:event:participants:{event_id}")],
        ]
        nav = []
        callback_prefix = f"admin:event:participants_filter:{event_id}:{status_filter}" if status_filter != "all" else f"admin:event:participants_all:{event_id}"
        if page > 1:
            nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"{callback_prefix}:{page-1}"))
        if page < pages:
            nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"{callback_prefix}:{page+1}"))
        if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔄 تازه‌سازی", callback_data=(f"admin:event:participants:{event_id}" if view == "confirmed" else f"admin:event:participants_filter:{event_id}:{status_filter}:{page}"))])
    rows.append([InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{event_id}")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))

# -----------------------------------------------------------------------------
# Host-only panel space and Admin review queue
# -----------------------------------------------------------------------------

@router.message(Command("host"))
async def host_home_command(message: Message, state: FSMContext):
    if await _is_admin(message.from_user.id):
        if await state.get_state():
            from app.bot.handlers.admin import _request_admin_navigation_confirmation
            if await _request_admin_navigation_confirmation(message, state):
                return
        return await message.answer("برای مدیریت کامل از /admin استفاده کنید.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="بازکردن مدیریت", callback_data="admin:home")]]))
    if not await _is_host(message.from_user.id):
        return await message.answer("این بخش برای کاربران دارای نقش میزبان فعال است.")
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(message, state):
        return
    await _render_host_panels(message, message.from_user.id, page=0)


@router.callback_query(F.data == "host:home")
async def host_home_callback(c: CallbackQuery, state: FSMContext):
    if not await _is_host(c.from_user.id):
        return await c.answer("این بخش فقط برای میزبان‌هاست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    await _render_host_panels(c, c.from_user.id, page=0)
    await c.answer()


async def _render_host_panels(target, telegram_id: int, page: int = 0):
    from app.display_utils import volume_label
    async with SessionLocal() as session:
        user = await _get_user(session, telegram_id)
        if not user or _role(user) != UserRole.HOST:
            return
        stmt = select(Event).where(Event.host_id == user.id, Event.archived.is_(False))
        total = int(await session.scalar(select(func.count(Event.id)).where(Event.host_id == user.id, Event.archived.is_(False))) or 0)
        page_count = max(1, (total + 7 - 1) // 7)
        page = max(0, min(int(page), page_count - 1))
        events = (await session.execute(stmt.order_by(Event.updated_at.desc(), Event.id.desc()).offset(page * 7).limit(7))).scalars().all()
        counts = {}
        if events:
            group_rows = (await session.execute(
                select(Booking.event_id, Booking.status, func.coalesce(func.sum(Booking.participant_count), 0))
                .where(Booking.event_id.in_([e.id for e in events]))
                .group_by(Booking.event_id, Booking.status)
            )).all()
            for eid, status, seats in group_rows:
                key = str(getattr(status, "value", status))
                counts.setdefault(int(eid), {})[key] = int(seats)
    rows = [[InlineKeyboardButton(text="➕ ساخت پیش‌نویس پنل", callback_data="admin:event:create")]]
    for event in events:
        rows.append([InlineKeyboardButton(text=f"{volume_label(event.volume)} · {event.title}"[:64], callback_data=f"host:panel:view:{event.id}")])
    nav = []
    if page > 0: nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"host:panels:{page-1}"))
    if page + 1 < page_count: nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"host:panels:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔄 تازه‌سازی", callback_data="host:home")])
    lines = ["🎤 <b>فضای میزبان</b>", "فقط پنل‌های متعلق به شما نمایش داده می‌شوند. هویت افراد ثبت‌نام‌شده و سوابق پرداخت در این بخش ارائه نمی‌شود.", ""]
    if not events:
        lines.append("هنوز پنلی برای این میزبان ثبت نشده است.")
    for event in events:
        cn = counts.get(int(event.id), {})
        confirmed = cn.get(RegistrationStatus.CONFIRMED.value, 0)
        pending = cn.get(RegistrationStatus.PENDING_PAYMENT.value, 0) + cn.get(RegistrationStatus.PENDING_VERIFICATION.value, 0)
        lines.append(f"• <b>{escape(event.title)}</b> · وضعیت: {escape(admin_status_display_label(event.status))} · قطعی: {confirmed}/{int(event.capacity)} · در انتظار: {pending}")
    lines.append(f"\nپنل‌ها: {total} · صفحه {page+1}/{page_count}")
    text = "\n".join(lines)
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=markup)
    else:
        await target.answer(text, reply_markup=markup)


@router.callback_query(F.data.regexp(r"^host:panels:\d+$"))
async def host_panels_page(c: CallbackQuery, state: FSMContext):
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    await _render_host_panels(c, c.from_user.id, int((c.data or "").rsplit(":", 1)[1]))
    await c.answer()


@router.callback_query(F.data == "admin:event:create")
async def admin_or_host_create_start(c: CallbackQuery, state: FSMContext):
    # This exact route is placed before the legacy admin router so Host can start the
    # existing validated draft wizard. Admins are delegated to the unchanged handler.
    if await _is_admin(c.from_user.id):
        from app.bot.handlers.admin import create_event_start
        return await create_event_start(c, state)
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state():
        return await c.answer("یک فرایند فعال دارید؛ ابتدا آن را تکمیل یا با /cancel لغو کنید.", show_alert=True)
    await state.clear()
    await state.update_data(
        creator_telegram_id=int(c.from_user.id),
        event_creation_token=secrets.token_hex(16),
    )
    await state.set_state(AdminEventStates.volume)
    from app.bot.handlers.admin import _creation_prompt
    await _creation_prompt(
        c.message, state,
        "پیش‌نویس پنل را بسازید. میزبان‌ها می‌توانند پیش‌نویس خود را ذخیره و برای بررسی مدیر ارسال کنند؛ انتشار نهایی با مدیر است.\n\n"
        "شماره یا نام Volume را به انگلیسی وارد کنید.",
    )
    await c.answer()


@router.callback_query(F.data == "admin:event:create:questions:skip")
async def admin_or_host_skip_questions(c: CallbackQuery, state: FSMContext):
    return await c.answer("برای ادامه بدون فایل، در مرحلهٔ فعلی فقط علامت «-» را ارسال کنید.", show_alert=True)


async def _finish_host_event_creation(message: Message, state: FSMContext, *, submit: bool):
    data = await state.get_data()
    actor_id = int(data.get("creator_telegram_id") or getattr(getattr(message, "from_user", None), "id", 0))
    if not await _is_host(actor_id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    async with SessionLocal() as session:
        host = await _get_user(session, actor_id)
        if not host or _role(host) != UserRole.HOST:
            await state.clear()
            return await message.answer("حساب میزبان پیدا نشد؛ دوباره از /host اقدام کنید.")
        host_name = _name(host) if _name(host) != "—" else "میزبان"
        creation_token = str(data.get("event_creation_token") or secrets.token_hex(16))
        if not data.get("event_creation_token"):
            await state.update_data(event_creation_token=creation_token)
        event = Event(
            volume=str(data["volume"]), creation_token=creation_token,
            title=str(data["title"]), language=data.get("language"),
            description=data.get("description") or None, event_day_label=str(data["day_name"]),
            event_date_label=str(data["date_text"]), start_time_label=str(data["start_time"]),
            end_time_label=str(data.get("end_time") or "—"), venue=str(data["venue"]),
            address=data.get("address") or None, map_url=data.get("map_url") or None,
            capacity=int(data["capacity"]), price_per_person=int(data["price"]),
            price_without_cafe_order=(int(data["price_without_cafe_order"]) if data.get("price_without_cafe_order") else None),
            status=EventStatus.DRAFT, registration_open=False, waitlist_enabled=bool(data.get("waitlist", True)),
            questions_pdf_path=data.get("questions_path") or None, questions_file_name=data.get("questions_file_name") or None,
            host_name=host_name, host_id=host.id, submission_status="submitted" if submit else "draft",
            submission_revision=1 if submit else 0,
        )
        session.add(event)
        try:
            await session.flush()
            session.add(AdminAction(actor_user_id=host.id, action="host_panel_submitted" if submit else "host_panel_draft_created", entity_type="event", entity_id=int(event.id), details=json.dumps({"title": event.title}, ensure_ascii=False), created_at=utc_now_naive()))
            await session.commit()
            event_id = int(event.id)
        except IntegrityError:
            # A double click or concurrent callback must not create a second draft.
            await session.rollback()
            token = creation_token
            existing = await session.scalar(select(Event).where(Event.creation_token == token)) if token else None
            if existing is None:
                raise
            from aiogram.types import ReplyKeyboardRemove
            await message.answer("کنترل‌های ایجاد پنل بسته شد.", reply_markup=ReplyKeyboardRemove())
            await state.clear()
            return await message.edit_text(
                f"این فرایند قبلاً ثبت شده است؛ پنل #{int(existing.id)} ایجاد شده و از ثبت تکراری جلوگیری شد.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="🎤 پنل‌های من", callback_data="host:home")
                ], [InlineKeyboardButton(text="مشاهده پنل", callback_data=f"host:panel:view:{int(existing.id)}")]]),
            )
    from aiogram.types import ReplyKeyboardRemove
    await message.answer("کنترل‌های ایجاد پنل بسته شد.", reply_markup=ReplyKeyboardRemove())
    await state.clear()
    if submit:
        text = f"✅ پیش‌نویس پنل #{event_id} برای بررسی مدیر ارسال شد. تا زمان تأیید، قابل انتشار عمومی نیست."
    else:
        text = f"✅ پیش‌نویس پنل #{event_id} ذخیره شد. می‌توانید آن را بررسی و سپس برای بررسی مدیر ارسال کنید."
    await message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🎤 پنل‌های من", callback_data="host:home")], [InlineKeyboardButton(text="مشاهده پنل", callback_data=f"host:panel:view:{event_id}")]]))


@router.callback_query(F.data.regexp(r"^host:event:create:draft:[0-9a-f]{32}$"))
async def host_create_save_draft(c: CallbackQuery, state: FSMContext):
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    data = await state.get_data()
    token = (c.data or "").rsplit(":", 1)[1]
    if (
        await state.get_state() != AdminEventStates.confirm.state
        or data.get("event_creation_token") != token
        or int(data.get("creator_telegram_id") or 0) != int(c.from_user.id)
        or int(data.get("event_creation_prompt_message_id") or 0) != int(getattr(c.message, "message_id", 0) or 0)
    ):
        return await c.answer("این دکمه مربوط به فرایند قبلی یا مرحلهٔ قبلی است؛ از آخرین پیام ربات استفاده کنید.", show_alert=True)
    await _finish_host_event_creation(c.message, state, submit=False)
    await c.answer()


@router.callback_query(F.data.regexp(r"^host:event:create:submit:[0-9a-f]{32}$"))
async def host_create_submit(c: CallbackQuery, state: FSMContext):
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    data = await state.get_data()
    token = (c.data or "").rsplit(":", 1)[1]
    if (
        await state.get_state() != AdminEventStates.confirm.state
        or data.get("event_creation_token") != token
        or int(data.get("creator_telegram_id") or 0) != int(c.from_user.id)
        or int(data.get("event_creation_prompt_message_id") or 0) != int(getattr(c.message, "message_id", 0) or 0)
    ):
        return await c.answer("این دکمه مربوط به فرایند قبلی یا مرحلهٔ قبلی است؛ از آخرین پیام ربات استفاده کنید.", show_alert=True)
    await _finish_host_event_creation(c.message, state, submit=True)
    await c.answer()


@router.callback_query(F.data.regexp(r"^host:panel:view:\d+$"))
async def host_panel_view(c: CallbackQuery):
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    from app.display_utils import volume_label
    async with SessionLocal() as session:
        host = await _get_user(session, c.from_user.id)
        event = await session.get(Event, event_id)
        if not host or not event or event.host_id != host.id:
            return await c.answer("این پنل متعلق به شما نیست.", show_alert=True)
        grouped = (await session.execute(select(Booking.status, func.coalesce(func.sum(Booking.participant_count), 0)).where(Booking.event_id == event_id).group_by(Booking.status))).all()
        status_seats = {str(getattr(status, "value", status)): int(seats) for status, seats in grouped}
        waitlist_count = int(await session.scalar(select(func.count(WaitlistEntry.id)).where(WaitlistEntry.event_id == event_id, WaitlistEntry.status.in_(("waiting", "invited", "inviting")))) or 0)
        actor_id = int(host.telegram_id)
    confirmed = status_seats.get(RegistrationStatus.CONFIRMED.value, 0)
    pending = status_seats.get(RegistrationStatus.PENDING_PAYMENT.value, 0) + status_seats.get(RegistrationStatus.PENDING_VERIFICATION.value, 0)
    text = (f"🎤 <b>{escape(event.title)}</b>\n{escape(volume_label(event.volume))}\n\n"
            f"وضعیت پنل: {escape(admin_status_display_label(event.status))}\nوضعیت بررسی: {escape(admin_status_display_label(event.submission_status))}\n"
            f"ثبت‌نام قطعی: <b>{confirmed}/{int(event.capacity)}</b> · صندلی باقی‌مانده: {max(0, int(event.capacity)-confirmed-pending)}\n"
            f"در انتظار پرداخت/بررسی: {pending} · لیست انتظار فعال: {waitlist_count}\n\n")
    if event.submission_feedback:
        text += f"بازخورد مدیر: {escape(event.submission_feedback[:700])}\n\n"
    text += "هویت افراد ثبت‌نام‌شده، شناسه‌ها، رزروهای فردی و اطلاعات پرداخت در فضای میزبان نمایش داده نمی‌شوند."
    rows = []
    if event.status == EventStatus.DRAFT and event.submission_status in {"draft", "rejected"}:
        rows.append([InlineKeyboardButton(text="✏️ ویرایش پیش‌نویس", callback_data=f"admin:event:edit:{event_id}")])
        rows.append([InlineKeyboardButton(text="📨 ارسال برای بررسی مدیر", callback_data=f"host:panel:submit:{event_id}")])
    if event.status == EventStatus.PUBLISHED:
        rows.append([InlineKeyboardButton(text="📢 ارتباطات پنل", callback_data=f"admin:event:announcements:{event_id}")])
        if event.registration_open:
            rows.append([InlineKeyboardButton(text="🔒 بستن ثبت‌نام", callback_data=f"host:panel:close:{event_id}")])
    rows += [[InlineKeyboardButton(text="🔄 تازه‌سازی", callback_data=f"host:panel:view:{event_id}")], [InlineKeyboardButton(text="🔙 پنل‌های من", callback_data="host:home")]]
    await c.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:edit:\d+$"))
async def admin_or_host_edit_start(c: CallbackQuery, state: FSMContext):
    if await _is_admin(c.from_user.id):
        from app.bot.handlers.admin import edit_start
        return await edit_start(c, state)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        host = await _get_user(session, c.from_user.id)
        event = await session.get(Event, event_id)
        if not host or _role(host) != UserRole.HOST or not event or event.host_id != host.id:
            return await c.answer("این پنل متعلق به شما نیست.", show_alert=True)
        if event.status != EventStatus.DRAFT or event.submission_status not in {"draft", "rejected"}:
            return await c.answer("فقط پیش‌نویس‌های در حال ویرایش یا دارای بازخورد ردشده قابل ویرایش هستند.", show_alert=True)
    from app.bot.handlers.admin import _start_edit
    await _start_edit(c, state, event_id)


@router.callback_query(F.data.regexp(r"^host:panel:submit:\d+$"))
async def host_submit_existing_draft(c: CallbackQuery):
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        host = await _get_user(session, c.from_user.id)
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if not host or not event or event.host_id != host.id:
            return await c.answer("این پنل متعلق به شما نیست.", show_alert=True)
        if event.status != EventStatus.DRAFT or event.submission_status not in {"draft", "rejected"}:
            return await c.answer("این پنل در وضعیت قابل ارسال برای بررسی نیست.", show_alert=True)
        event.submission_status = "submitted"
        bump_submission_revision(event)
        event.submission_feedback = None
        session.add(AdminAction(actor_user_id=host.id, action="host_panel_submitted", entity_type="event", entity_id=event_id, details=json.dumps({"title": event.title}, ensure_ascii=False), created_at=utc_now_naive()))
        await session.commit()
    await c.message.edit_text("✅ پنل برای بررسی مدیر ارسال شد. تا قبل از تأیید و انتشار، برای کاربران عمومی قابل مشاهده نیست.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🎤 پنل‌های من", callback_data="host:home")], [InlineKeyboardButton(text="مشاهده پنل", callback_data=f"host:panel:view:{event_id}")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^host:panel:close:\d+$"))
async def host_close_own_panel(c: CallbackQuery):
    if not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        host = await _get_user(session, c.from_user.id)
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if not host or not event or event.host_id != host.id:
            return await c.answer("این پنل متعلق به شما نیست.", show_alert=True)
        if event.status != EventStatus.PUBLISHED or not event.registration_open:
            return await c.answer("ثبت‌نام این پنل در حال حاضر باز نیست.", show_alert=True)
        event.registration_open = False
        event.registration_closed_reason = "manual"
        session.add(AdminAction(actor_user_id=host.id, action="host_registration_manually_closed", entity_type="event", entity_id=event_id, details=json.dumps({"title": event.title}, ensure_ascii=False), created_at=utc_now_naive()))
        await session.commit()
    await c.message.edit_text("✅ ثبت‌نام پنل بسته شد. این اقدام فقط ثبت‌نام را می‌بندد و پنل را لغو یا آرشیو نمی‌کند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="مشاهده پنل", callback_data=f"host:panel:view:{event_id}")], [InlineKeyboardButton(text="پنل‌های من", callback_data="host:home")]]))
    await c.answer()


async def _render_host_submission_queue(c: CallbackQuery, page: int = 0) -> None:
    page = max(0, int(page))
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(Event.id)).where(
            Event.submission_status == "submitted", Event.status == EventStatus.DRAFT,
            Event.archived.is_(False),
        )) or 0)
        last_page = max(0, (total - 1) // HOST_REVIEW_PAGE_SIZE)
        page = min(page, last_page)
        events = (await session.execute(
            select(Event).options(selectinload(Event.host)).where(
                Event.submission_status == "submitted", Event.status == EventStatus.DRAFT,
                Event.archived.is_(False),
            ).order_by(Event.updated_at.asc(), Event.id.asc())
            .offset(page * HOST_REVIEW_PAGE_SIZE).limit(HOST_REVIEW_PAGE_SIZE)
        )).scalars().all()
    rows = []
    lines = ["📝 <b>صف بررسی پنل‌های ارسالی</b>", f"در انتظار بررسی: <b>{total}</b>", ""]
    for event in events:
        host_name = _name(event.host)
        time_label = str(event.start_time_label or "—")
        if event.end_time_label and event.end_time_label != "—":
            time_label += f"–{event.end_time_label}"
        description = str(event.description or "").strip().replace("\n", " ")
        if len(description) > 190:
            description = description[:187].rstrip() + "…"
        lines.append(
            f"<b>#{int(event.id)} · {escape(str(event.volume))} — {escape(str(event.title))}</b>\n"
            + panel_detail_line("میزبان", escape(host_name), icon="👤") + "\n"
            + panel_detail_line("زبان", escape(str(event.language or '—')), icon="🌐") + "\n"
            + panel_detail_line("روز و تاریخ", f"{escape(str(event.event_day_label or '—'))} · {escape(str(event.event_date_label or '—'))}", icon="📅") + "\n"
            + panel_detail_line("ساعت", escape(time_label), icon="⏰") + "\n"
            + panel_detail_line("مکان", escape(str(event.venue or '—')), icon="📍") + "\n"
            + panel_detail_line("ظرفیت", int(event.capacity), icon="👥") + "\n"
            + panel_detail_line("قیمت", f"{int(event.price_per_person):,} تومان", icon="💰") + "\n"
            f"{escape(description) if description else 'توضیحی ثبت نشده است.'}\n"
        )
        rows.append([
            InlineKeyboardButton(text=f"✅ تأیید #{event.id}", callback_data=f"admin:console:review:approve:{event.id}"),
            InlineKeyboardButton(text=f"❌ رد #{event.id}", callback_data=f"admin:console:review:reject:{event.id}"),
        ])
        rows.append([InlineKeyboardButton(text=f"جزئیات کامل #{event.id}", callback_data=f"admin:event:view:{event.id}")])
    if not events:
        lines.append("پنل ارسالی در انتظار بررسی وجود ندارد.")
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:console:reviews:page:{page-1}"))
    if page < last_page:
        navigation.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:console:reviews:page:{page+1}"))
    if navigation:
        rows.append(navigation)
    rows.append([InlineKeyboardButton(text=f"صفحه {page+1} از {last_page+1}", callback_data=f"admin:console:reviews:page:{page}")])
    rows.append([InlineKeyboardButton(text="🔔 اطلاع‌رسانی میزبان‌ها", callback_data="admin:console:host-notifications:page:0")])
    rows.append([InlineKeyboardButton(text="🔄 تازه‌سازی", callback_data="admin:console:reviews"), InlineKeyboardButton(text="🔙 مدیریت", callback_data="admin:home")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)


@router.callback_query(F.data == "admin:console:reviews")
async def admin_review_queue(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await _render_host_submission_queue(c, 0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:reviews:page:\d+$"))
async def admin_review_queue_page(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("صفحه نامعتبر است.", show_alert=True)
    await _render_host_submission_queue(c, page)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:review:approve:\d+$"))
async def admin_review_approve(c: CallbackQuery):
    """Show a confirmation before approving a host submission for publication review."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        event_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id))).scalar_one_or_none()
        if not event or event.status != EventStatus.DRAFT or event.submission_status != "submitted" or event.archived:
            return await c.answer("این پنل دیگر در صف بررسی نیست.", show_alert=True)
        submission_revision = current_submission_revision(event)
        host = await session.get(User, event.host_id) if event.host_id else None
        from app.display_utils import volume_label
        title = f"{volume_label(event.volume)} — {event.title}"
        desc = str(event.description or "").strip().replace("\n", " ")
        if len(desc) > 450:
            desc = desc[:447].rstrip() + "…"
        time_label = str(event.start_time_label or "—")
        if event.end_time_label and event.end_time_label != "—":
            time_label += f"–{event.end_time_label}"
        body = (
            "<b>تأیید بررسی پنل ارسالی</b>\n\n"
            f"پنل: <b>{escape(title[:180])}</b>\n"
            + panel_detail_line("میزبان", escape(_name(host)), icon="👤") + "\n"
            + panel_detail_line("زمان نمایشی", f"{escape(str(event.event_day_label or '—'))} · {escape(str(event.event_date_label or '—'))} · {escape(time_label)}", icon="📅") + "\n"
            + panel_detail_line("محل", escape(str(event.venue or '—')), icon="📍") + "\n"
            + panel_detail_line("ظرفیت", int(event.capacity), icon="👥") + "\n"
            + panel_detail_line("قیمت پایه", f"{int(event.price_per_person or 0):,} تومان", icon="💰") + "\n\n"
            f"{escape(desc) if desc else 'توضیحی ثبت نشده است.'}\n\n"
            "تأیید فقط وضعیت بررسی را به «تأییدشده» تغییر می‌دهد. <b>پنل عمومی منتشر نمی‌شود</b> تا زمانی که آن را جداگانه از مدیریت پنل منتشر کنید."
        )
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید بررسی", callback_data=approval_callback_data(event_id, submission_revision))],
        [InlineKeyboardButton(text="⬅️ بازگشت به صف", callback_data="admin:console:reviews")],
    ]), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data.regexp(r"^hrap:\d+:\d+$"))
async def admin_review_approve_confirm(c: CallbackQuery):
    """Approve only the exact host-submission generation shown in the preview."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _, event_raw, revision_raw = (c.data or "").split(":")
        event_id, expected_revision = int(event_raw), int(revision_raw)
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if (
            not event or event.status != EventStatus.DRAFT or event.submission_status != "submitted"
            or event.archived or not submission_revision_matches(event, expected_revision)
        ):
            return await c.answer("این نسخه تغییر کرده یا دیگر در صف بررسی نیست؛ لطفاً صف را تازه‌سازی کنید.", show_alert=True)
        event.submission_status = "approved"
        event.submission_feedback = None
        event.submission_notification_status = "pending" if event.host_id else "not_applicable"
        event.submission_notification_error = None
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="host_panel_approved", entity_type="event", entity_id=event_id, details={"host_id": event.host_id, "title": event.title, "submission_revision": expected_revision})
        await session.commit()
    notification_result = await notify_host_submission_review(c.bot, event_id)
    notification_note = {
        "sent": "اطلاع‌رسانی میزبان ارسال شد.",
        "already_sent": "اطلاع‌رسانی قبلاً ثبت شده بود.",
        "not_applicable": "برای این پنل میزبان ثبت نشده است.",
        "failed": "ارسال اطلاع‌رسانی ناموفق بود؛ از صف اطلاع‌رسانی میزبان‌ها دوباره تلاش کنید.",
        "uncertain": "وضعیت ارسال نامشخص است؛ پیش از تلاش مجدد، تحویل را بررسی کنید.",
    }.get(notification_result, "وضعیت اطلاع‌رسانی در صف مدیریت قابل بررسی است.")
    await c.message.edit_text(
        f"✅ پنل #{event_id} تأیید شد. برای عمومی‌شدن، همچنان باید از منوی مدیریت آن را منتشر کنید.\n\n{notification_note}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📝 صف بررسی", callback_data="admin:console:reviews")],
            [InlineKeyboardButton(text="🔔 وضعیت اطلاع‌رسانی میزبان", callback_data="admin:console:host-notifications:page:0")],
            [InlineKeyboardButton(text="⚙️ مدیریت پنل", callback_data=f"admin:event:view:{event_id}")],
        ])
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:review:approve_confirm:\d+$"))
async def admin_review_approve_confirm_legacy(c: CallbackQuery):
    """Old confirmations lack a submission revision and must fail closed."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.answer("این تأیید متعلق به نسخهٔ قبلی است؛ لطفاً صف بررسی را تازه‌سازی و پنل را دوباره باز کنید.", show_alert=True)


@router.callback_query(F.data.regexp(r"^admin:console:review:reject:\d+$"))
async def admin_review_reject_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event or event.status != EventStatus.DRAFT or event.submission_status != "submitted" or event.archived:
            return await c.answer("این پنل دیگر در صف بررسی نیست.", show_alert=True)
        submission_revision = current_submission_revision(event)
    await state.clear()
    await state.update_data(review_event_id=event_id, review_submission_revision=submission_revision)
    await state.set_state(AdminConsoleStates.review_reason)
    await c.message.edit_text(f"دلیل رد پیش‌نویس «{escape(event.title)}» را وارد کنید؛ میزبان این بازخورد را در /host می‌بیند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data="admin:console:reviews")]]))
    await c.answer()


@router.message(AdminConsoleStates.review_reason)
async def admin_review_reject_reason(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    reason = (message.text or "").strip()
    if not 5 <= len(reason) <= 1000:
        return await message.answer("بازخورد باید بین ۵ تا ۱۰۰۰ نویسه باشد.")
    token = secrets.token_hex(8)
    data = await state.get_data()
    revision = int(data.get("review_submission_revision", -1))
    if revision < 0:
        await state.clear()
        return await message.answer("نسخهٔ درخواست مشخص نیست؛ صف بررسی را تازه‌سازی کنید.")
    try:
        callback_data = rejection_callback_data(int(data["review_event_id"]), revision, token)
    except ValueError:
        await state.clear()
        return await message.answer("ساخت دکمهٔ تأیید ناموفق بود؛ لطفاً دوباره از صف بررسی اقدام کنید.")
    await state.update_data(review_reason_text=reason, review_token=token)
    await state.set_state(AdminConsoleStates.review_confirm)
    await message.answer(f"<b>پیش‌نمایش رد پنل</b>\nشناسه: #{int(data['review_event_id'])}\nدلیل: {escape(reason)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ تأیید رد و ارسال بازخورد", callback_data=callback_data)], [InlineKeyboardButton(text="❌ لغو", callback_data="admin:console:reviews")]]))


@router.callback_query(F.data.regexp(r"^hrrj:\d+:\d+:[a-f0-9]{16}$"))
async def admin_review_reject_confirm(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _, event_raw, revision_raw, token = (c.data or "").split(":")
        event_id, expected_revision = int(event_raw), int(revision_raw)
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ تأیید معتبر نیست.", show_alert=True)
    data = await state.get_data()
    if (
        await state.get_state() != AdminConsoleStates.review_confirm.state
        or data.get("review_token") != token
        or int(data.get("review_event_id", 0)) != event_id
        or int(data.get("review_submission_revision", -1)) != expected_revision
    ):
        return await c.answer("این تأیید منقضی شده است؛ نسخهٔ جدید را دوباره بررسی کنید.", show_alert=True)
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if (
            not event or event.status != EventStatus.DRAFT or event.submission_status != "submitted"
            or event.archived or not submission_revision_matches(event, expected_revision)
        ):
            return await c.answer("این نسخه تغییر کرده یا دیگر در صف بررسی نیست؛ لطفاً صف را تازه‌سازی کنید.", show_alert=True)
        event.submission_status = "rejected"
        event.submission_feedback = str(data["review_reason_text"])
        event.submission_notification_status = "pending" if event.host_id else "not_applicable"
        event.submission_notification_error = None
        host_id = int(event.host_id) if event.host_id else None
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="host_panel_rejected", entity_type="event", entity_id=event_id, details={"host_id": host_id, "reason": data["review_reason_text"], "submission_revision": expected_revision})
        await session.commit()
    notification_result = await notify_host_submission_review(c.bot, event_id)
    notification_note = {
        "sent": "اطلاع‌رسانی میزبان ارسال شد.",
        "already_sent": "اطلاع‌رسانی قبلاً ثبت شده بود.",
        "not_applicable": "برای این پنل میزبان ثبت نشده است.",
        "failed": "ارسال اطلاع‌رسانی ناموفق بود؛ از صف اطلاع‌رسانی میزبان‌ها دوباره تلاش کنید.",
        "uncertain": "وضعیت ارسال نامشخص است؛ پیش از تلاش مجدد، تحویل را بررسی کنید.",
    }.get(notification_result, "وضعیت اطلاع‌رسانی در صف مدیریت قابل بررسی است.")
    await state.clear()
    await c.message.edit_text(
        f"✅ پنل #{event_id} رد شد و بازخورد ذخیره شد.\n\n{notification_note}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📝 صف بررسی", callback_data="admin:console:reviews")],
            [InlineKeyboardButton(text="🔔 وضعیت اطلاع‌رسانی میزبان", callback_data="admin:console:host-notifications:page:0")],
            [InlineKeyboardButton(text="⚙️ مدیریت پنل", callback_data=f"admin:event:view:{event_id}")],
        ])
    )
    await c.answer()

async def _render_host_notification_queue(c: CallbackQuery, page: int = 0) -> None:
    page = max(0, int(page))
    states = ("pending", "failed", "sending")
    eligible = [Event.submission_status.in_(("approved", "rejected")), Event.submission_notification_status.in_(states)]
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(Event.id)).where(*eligible)) or 0)
        last_page = max(0, (total - 1) // HOST_NOTIFICATION_PAGE_SIZE)
        page = min(page, last_page)
        events = (await session.execute(
            select(Event).where(*eligible).order_by(Event.updated_at.desc(), Event.id.desc())
            .offset(page * HOST_NOTIFICATION_PAGE_SIZE).limit(HOST_NOTIFICATION_PAGE_SIZE)
        )).scalars().all()
    lines = ["<b>🔔 اطلاع‌رسانی میزبان‌ها</b>", f"نیازمند بررسی یا تلاش مجدد: <b>{total}</b>", ""]
    rows = []
    labels = {"pending": "در انتظار بررسی", "failed": "ناموفق", "sending": "در حال ارسال؛ نیازمند بررسی تحویل"}
    for event in events:
        lines.append(
            f"<b>#{event.id} · {escape(str(event.title))}</b> · "
            f"{'تأییدشده' if event.submission_status == 'approved' else 'ردشده'} · "
            f"{labels.get(event.submission_notification_status, admin_status_display_label(event.submission_notification_status))}\n"
            f"تلاش: {int(event.submission_notification_attempts or 0)} · "
            f"خطا: {escape(str(event.submission_notification_error or '—')[:100])}\n"
        )
        if event.submission_notification_status in {"pending", "failed"}:
            rows.append([InlineKeyboardButton(text=f"🔁 تلاش مجدد برای #{event.id}", callback_data=f"admin:console:host-notification:retry:{event.id}")])
        elif event.submission_notification_status == "sending":
            rows.append([
                InlineKeyboardButton(text=f"✅ تحویل تأیید شد #{event.id}", callback_data=f"admin:console:host-notification:mark-sent:{event.id}"),
                InlineKeyboardButton(text=f"⚠️ تحویل نشد #{event.id}", callback_data=f"admin:console:host-notification:mark-failed:{event.id}"),
            ])
    if not events:
        lines.append("اطلاع‌رسانی میزبانِ نیازمند اقدام وجود ندارد.")
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:console:host-notifications:page:{page-1}"))
    if page < last_page:
        navigation.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:console:host-notifications:page:{page+1}"))
    if navigation:
        rows.append(navigation)
    rows.append([InlineKeyboardButton(text=f"صفحه {page+1} از {last_page+1}", callback_data=f"admin:console:host-notifications:page:{page}")])
    rows.append([InlineKeyboardButton(text="📝 صف بررسی پنل‌ها", callback_data="admin:console:reviews")])
    rows.append([InlineKeyboardButton(text="🔙 مدیریت", callback_data="admin:home")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:console:review:reject_confirm:\d+:[a-f0-9]+$"))
async def admin_review_reject_confirm_legacy(c: CallbackQuery):
    """Old rejection previews do not identify the submission revision."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.answer("این تأیید متعلق به نسخهٔ قبلی است؛ لطفاً صف بررسی را تازه‌سازی و پنل را دوباره باز کنید.", show_alert=True)


@router.callback_query(F.data.regexp(r"^admin:console:host-notifications:page:\d+$"))
async def admin_host_notification_queue(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("صفحه نامعتبر است.", show_alert=True)
    await _render_host_notification_queue(c, page)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:console:host-notification:retry:\d+$"))
async def admin_host_notification_retry(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    result = await notify_host_submission_review(c.bot, event_id)
    note = {
        "sent": "اطلاع‌رسانی ارسال و ثبت شد.",
        "already_sent": "این اطلاع‌رسانی قبلاً ارسال شده است.",
        "not_applicable": "میزبانی برای این پنل ثبت نشده است.",
        "failed": "ارسال ناموفق بود؛ علت در صف ثبت شد.",
        "uncertain": "وضعیت ارسال نامشخص است؛ ارسال خودکار تکرار نشد. تحویل را بررسی کنید.",
        "not_ready": "وضعیت پنل برای این اطلاع‌رسانی معتبر نیست.",
    }.get(result, "وضعیت در صف ثبت شد.")
    await c.answer(note, show_alert=result in {"uncertain", "failed", "not_ready"})
    await _render_host_notification_queue(c, 0)


async def _reconcile_host_notification(c: CallbackQuery, *, delivered: bool) -> None:
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if not event or event.submission_notification_status != "sending" or event.submission_status not in {"approved", "rejected"}:
            return await c.answer("این مورد دیگر در وضعیت نامشخص نیست.", show_alert=True)
        event.submission_notification_status = "sent" if delivered else "failed"
        event.submission_notified_at = utc_now_naive() if delivered else None
        event.submission_notification_error = None if delivered else "admin_verified_not_delivered"
        await write_admin_action(session, actor_telegram_id=c.from_user.id,
            action="host_notification_delivery_reconciled", entity_type="event", entity_id=event_id,
            details={"outcome": "verified_delivered" if delivered else "verified_not_delivered"})
        await session.commit()
    await c.answer("تحویل طبق بررسی مدیر ثبت شد." if delivered else "عدم تحویل ثبت شد؛ اکنون تلاش مجدد در دسترس است.", show_alert=True)
    await _render_host_notification_queue(c, 0)


@router.callback_query(F.data.regexp(r"^admin:console:host-notification:mark-sent:\d+$"))
async def admin_host_notification_mark_sent(c: CallbackQuery):
    await _reconcile_host_notification(c, delivered=True)


@router.callback_query(F.data.regexp(r"^admin:console:host-notification:mark-failed:\d+$"))
async def admin_host_notification_mark_failed(c: CallbackQuery):
    await _reconcile_host_notification(c, delivered=False)


# -----------------------------------------------------------------------------
# One shared manual announcement implementation: preview -> confirm -> delivery
# -----------------------------------------------------------------------------

_PURPOSE_LABELS = {
    "upcoming_lineup": "پنل‌های پیش‌رو",
    "individual_panel": "معرفی یک پنل",
    "reminder_today": "یادآوری دستی روز برگزاری",
    "important_update": "به‌روزرسانی مهم",
    "cancellation_notice": "اعلام لغو پنل",
    "custom": "پیام سفارشی به ثبت‌نام‌شده‌ها",
}


def _purpose_keyboard(event_id: int | None = None) -> InlineKeyboardMarkup:
    if event_id is None:
        rows = [
            [InlineKeyboardButton(text="🔔 یادآوری دستی همان روز", callback_data="admin:announce:v72:purpose:reminder_today")],
            [InlineKeyboardButton(text="📌 به‌روزرسانی مهم", callback_data="admin:announce:v72:purpose:important_update")],
            [InlineKeyboardButton(text="❌ اعلام لغو پنل", callback_data="admin:announce:v72:purpose:cancellation_notice")],
            [InlineKeyboardButton(text="✍️ پیام سفارشی", callback_data="admin:announce:v72:purpose:custom")],
            [InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")],
        ]
    else:
        rows = [
            [InlineKeyboardButton(text="🔔 یادآوری دستی همان روز", callback_data=f"admin:announce:v72:purposepanel:{event_id}:reminder_today")],
            [InlineKeyboardButton(text="📌 به‌روزرسانی مهم", callback_data=f"admin:announce:v72:purposepanel:{event_id}:important_update")],
            [InlineKeyboardButton(text="❌ اعلام لغو پنل", callback_data=f"admin:announce:v72:purposepanel:{event_id}:cancellation_notice")],
            [InlineKeyboardButton(text="✍️ پیام سفارشی", callback_data=f"admin:announce:v72:purposepanel:{event_id}:custom")],
            [InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:announcements:{event_id}")],
        ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _bot_username(bot) -> str:
    me = await bot.get_me()
    username = str(getattr(me, "username", "") or "").strip().removeprefix("@")
    if not username:
        raise RuntimeError("Bot username is not available; cannot build a registration deep link.")
    return username


def _registration_url(username: str, event_id: int) -> str:
    return f"https://t.me/{username}?start=panel_{int(event_id)}"


def _event_display_text(event: Event, register_url: str, *, include_link: bool = True) -> str:
    from app.display_utils import volume_label, has_end_time_label
    description = (event.description or "").strip()
    if len(description) > 500:
        description = description[:497] + "..."
    time_label = str(event.start_time_label or "—")
    if has_end_time_label(event.end_time_label):
        time_label += f"–{event.end_time_label}"
    lines = [
        f"<b>{escape(volume_label(event.volume))} — {escape(event.title)}</b>",
        (panel_detail_line("زبان", escape(event.language), icon="🌐") if event.language else ""),
        (escape(description) if description else ""),
        panel_detail_line("روز و تاریخ", f"{escape(str(event.event_day_label or '—'))} — {escape(str(event.event_date_label or '—'))}", icon="📅"),
        panel_detail_line("زمان", escape(time_label), icon="⏰"),
        panel_detail_line("مکان", escape(str(event.venue or '—')), icon="📍"),
        (panel_detail_line("آدرس", escape(event.address), icon="📌") if event.address else ""),
    ]
    if include_link:
        lines.append(f"🎟 <a href=\"{escape(register_url, quote=True)}\">مشاهده پنل و ثبت‌نام</a>")
    return "\n".join(line for line in lines if line)


async def _build_upcoming_lineup(session, bot) -> tuple[str, int]:
    from app.services.events import announcement_events_statement
    events = (await session.execute(announcement_events_statement())).scalars().all()
    eligible = [e for e in events if e.status == EventStatus.PUBLISHED and not e.archived]
    if not eligible:
        return "", 0
    username = await _bot_username(bot)
    chunks = ["📣 <b>پنل‌های منتشرشده Panel Flow</b>", "پنل‌های زیر برای مشاهده و ثبت‌نام در دسترس‌اند:", ""]
    included = 0
    char_budget = 3500
    for event in eligible:
        item = _event_display_text(event, _registration_url(username, event.id))
        addition = item + "\n\n"
        if sum(len(x) for x in chunks) + len(addition) > char_budget:
            break
        chunks.append(addition)
        included += 1
    if included < len(eligible):
        chunks.append(f"\nبرای مشاهده سایر پنل‌ها وارد ربات شوید. ({len(eligible)-included} پنل دیگر)")
    return "\n".join(chunks).strip(), len(eligible)


async def _collect_announcement_recipients(session, announcement_type: str, purpose: str, event_id: int | None) -> list[int]:
    now = utc_now_naive()
    blocked_subquery = select(BlockedUser.telegram_id)
    suspended_subquery = select(UserModerationRecord.target_telegram_id).where(
        UserModerationRecord.action == "suspension", UserModerationRecord.scope == "account",
        UserModerationRecord.active.is_(True),
        or_(UserModerationRecord.expires_at.is_(None), UserModerationRecord.expires_at > now),
    )
    if announcement_type in {"upcoming", "panel"}:
        stmt = select(User.telegram_id).where(
            User.telegram_id > 0, User.is_bot.is_(False),
            ~User.telegram_id.in_(blocked_subquery),
            ~User.telegram_id.in_(suspended_subquery),
        ).order_by(User.id)
    else:
        if event_id is None:
            return []
        if purpose == "cancellation_notice":
            statuses = (RegistrationStatus.CONFIRMED, RegistrationStatus.CANCELLED)
            stmt = select(User.telegram_id).join(Booking, Booking.booked_by_user_id == User.id).where(
                Booking.event_id == int(event_id), Booking.status.in_(statuses),
                or_(Booking.status == RegistrationStatus.CONFIRMED, Booking.confirmed_at.is_not(None)),
                User.telegram_id > 0, User.is_bot.is_(False),
                ~User.telegram_id.in_(blocked_subquery),
                ~User.telegram_id.in_(suspended_subquery),
            ).distinct().order_by(User.telegram_id)
        else:
            stmt = select(User.telegram_id).join(Booking, Booking.booked_by_user_id == User.id).where(
                Booking.event_id == int(event_id), Booking.status == RegistrationStatus.CONFIRMED,
                User.telegram_id > 0, User.is_bot.is_(False),
                ~User.telegram_id.in_(blocked_subquery),
                ~User.telegram_id.in_(suspended_subquery),
            ).distinct().order_by(User.telegram_id)
    ids = (await session.execute(stmt)).scalars().all()
    return sorted({int(i) for i in ids if int(i) > 0})


async def _duplicate_announcement(session, announcement_type: str, purpose: str, event_id: int | None):
    cutoff = utc_now_naive() - timedelta(hours=24)
    stmt = select(AdminAnnouncement).where(
        AdminAnnouncement.announcement_type == announcement_type,
        AdminAnnouncement.purpose == purpose,
        AdminAnnouncement.created_at >= cutoff,
        AdminAnnouncement.status.in_(("sending", "completed", "partial", "failed")),
    )
    stmt = stmt.where(AdminAnnouncement.event_id.is_(None) if event_id is None else AdminAnnouncement.event_id == int(event_id))
    return (await session.execute(stmt.order_by(AdminAnnouncement.created_at.desc()).limit(1))).scalar_one_or_none()


async def _announcement_authorized(telegram_id: int, announcement: AdminAnnouncement, *, require_admin_for_global: bool = True) -> bool:
    if await _is_admin(telegram_id):
        return True
    if require_admin_for_global and announcement.announcement_type in {"upcoming", "panel"}:
        return False
    if announcement.event_id is None:
        return False
    async with SessionLocal() as session:
        return await _host_owns_event(session, telegram_id, int(announcement.event_id))


async def _persist_announcement_preview(
    session, *, actor_id: int, announcement_type: str, purpose: str,
    event_id: int | None, event_title: str | None, message_body: str,
    recipients: list[int],
) -> int:
    """Persist every announcement preview via one shared, auditable path."""
    duplicate = await _duplicate_announcement(session, announcement_type, purpose, event_id)
    meta = {"panel_title": event_title, "duplicate_previous_id": int(duplicate.id) if duplicate else None}
    audience_policy = (
        "general_eligible_users" if announcement_type in {"upcoming", "panel"}
        else "confirmed_and_affected_historical_bookers" if purpose == "cancellation_notice"
        else "confirmed_bookers"
    )
    item = AdminAnnouncement(
        idempotency_key=secrets.token_hex(24), announcement_type=announcement_type,
        purpose=purpose, event_id=int(event_id) if event_id is not None else None,
        actor_telegram_id=int(actor_id), audience_policy=audience_policy,
        message_text=message_body, message_meta_json=json.dumps(meta, ensure_ascii=False),
        status="preview", recipient_count=len(recipients), created_at=utc_now_naive(),
    )
    session.add(item)
    await session.flush()
    for telegram_id in recipients:
        session.add(AdminAnnouncementDelivery(
            announcement_id=int(item.id), telegram_id=int(telegram_id), status="pending",
            attempts=0, updated_at=utc_now_naive(),
        ))
    await _write_announcement_audit(
        session, actor_telegram_id=actor_id, action="announcement_preview_created", entity_id=int(item.id),
        details={"type": announcement_type, "purpose": purpose, "event_id": event_id, "recipient_count": len(recipients)},
    )
    await session.commit()
    return int(item.id)


async def _create_announcement_preview(c: CallbackQuery, *, announcement_type: str, purpose: str, event_id: int | None = None, message_body: str | None = None):
    actor_id = int(c.from_user.id)
    is_admin_actor = await _is_admin(actor_id)
    if announcement_type in {"upcoming", "panel"} and not is_admin_actor:
        return await c.answer("فقط مدیر می‌تواند پیام عمومی ارسال کند.", show_alert=True)
    if event_id is not None:
        async with SessionLocal() as session:
            event = await session.get(Event, int(event_id))
            if not event:
                return await c.answer("پنل پیدا نشد.", show_alert=True)
            if not is_admin_actor and not await _host_owns_event(session, actor_id, event_id):
                return await c.answer("این پنل متعلق به شما نیست.", show_alert=True)
            if announcement_type == "panel" and (event.status != EventStatus.PUBLISHED or event.archived):
                return await c.answer("فقط پنل منتشرشده و غیرآرشیوی قابل معرفی عمومی است.", show_alert=True)
            if purpose == "cancellation_notice" and event.status != EventStatus.CANCELLED:
                return await c.answer("ابتدا پنل را از مسیر مدیریت به وضعیت لغوشده ببرید؛ این پیام فقط برای پنل لغوشده مجاز است.", show_alert=True)
            if announcement_type == "participants":
                if purpose == "cancellation_notice":
                    if event.status != EventStatus.CANCELLED or event.archived:
                        return await c.answer("اعلام لغو فقط برای پنل لغوشده و غیرآرشیوی مجاز است.", show_alert=True)
                elif event.status != EventStatus.PUBLISHED or event.archived:
                    return await c.answer("یادآوری، به‌روزرسانی و پیام عمومی ثبت‌نام‌شده‌ها فقط برای پنل منتشرشده و غیرآرشیوی مجاز است.", show_alert=True)
            event_title = event.title
            if purpose == "reminder_today":
                username = await _bot_username(c.bot)
                message_body = (
                    f"🔔 <b>یادآوری Panel Flow</b>\n\n{_event_display_text(event, _registration_url(username, event.id), include_link=False)}\n\n"
                    "امروز روز برگزاری پنل است؛ منتظرتان هستیم!"
                )
            elif purpose == "individual_panel":
                username = await _bot_username(c.bot)
                message_body = (
                    "📣 <b>پنل تازه در Panel Flow</b>\n\n"
                    + _event_display_text(event, _registration_url(username, event.id))
                )
            elif purpose == "important_update":
                message_body = f"📌 <b>به‌روزرسانی مهم پنل</b>\n{escape(event.title)}\n\n{escape(message_body or '')}"
            elif purpose == "cancellation_notice":
                message_body = f"❌ <b>اطلاعیه لغو پنل</b>\n{escape(event.title)}\n\n{escape(message_body or 'این پنل لغو شده است.')}\n\nدر صورت نیاز به پیگیری رزرو، لطفاً از پشتیبانی ربات کمک بگیرید."
            elif purpose == "custom":
                message_body = f"📣 <b>پیام برای ثبت‌نام‌شده‌های پنل</b>\n{escape(event.title)}\n\n{escape(message_body or '')}"
        if not message_body:
            return await c.answer("متن پیام خالی است.", show_alert=True)
    else:
        event_title = None
        if announcement_type == "upcoming":
            async with SessionLocal() as session:
                message_body, eligible_count = await _build_upcoming_lineup(session, c.bot)
            if not eligible_count or not message_body:
                return await c.answer("هیچ پنل منتشرشده و قابل اعلامی وجود ندارد؛ پیام ارسال نشد.", show_alert=True)
        else:
            return await c.answer("برای این نوع پیام باید پنل مشخص شود.", show_alert=True)

    if not message_body or not str(message_body).strip():
        return await c.answer("متن پیام خالی است.", show_alert=True)
    if len(message_body) > 3900:
        message_body = message_body[:3890] + "…"

    async with SessionLocal() as session:
        # Revalidate panel before committing a preview and calculate the actual recipient set.
        if event_id is not None:
            event = await session.get(Event, int(event_id))
            if not event:
                return await c.answer("پنل پیدا نشد.", show_alert=True)
            if announcement_type == "panel" and (event.status != EventStatus.PUBLISHED or event.archived):
                return await c.answer("پنل دیگر برای معرفی عمومی واجد شرایط نیست.", show_alert=True)
            if not is_admin_actor and not await _host_owns_event(session, actor_id, event_id):
                return await c.answer("اجازهٔ ارسال برای این پنل وجود ندارد.", show_alert=True)
        recipients = await _collect_announcement_recipients(session, announcement_type, purpose, event_id)
        if not recipients:
            return await c.answer("در حال حاضر دریافت‌کننده واجد شرایطی وجود ندارد؛ پیش‌نمایش ارسال ساخته نشد.", show_alert=True)
        announcement_id = await _persist_announcement_preview(
            session, actor_id=actor_id, announcement_type=announcement_type, purpose=purpose,
            event_id=event_id, event_title=event_title, message_body=message_body, recipients=recipients,
        )
    await _render_announcement_preview(c, announcement_id)
    await c.answer()


async def _render_announcement_preview(c: CallbackQuery, announcement_id: int):
    async with SessionLocal() as session:
        announcement = await session.get(AdminAnnouncement, int(announcement_id))
        if not announcement:
            return await c.answer("پیش‌نمایش پیدا نشد.", show_alert=True)
        recipients = int(await session.scalar(select(func.count(AdminAnnouncementDelivery.id)).where(AdminAnnouncementDelivery.announcement_id == announcement_id)) or 0)
        event = await session.get(Event, announcement.event_id) if announcement.event_id else None
        meta = json.loads(announcement.message_meta_json or "{}")
        duplicate_id = meta.get("duplicate_previous_id")
        status = announcement.status
    if not await _announcement_authorized(c.from_user.id, announcement):
        return await c.answer("دسترسی به این پیش‌نمایش مجاز نیست.", show_alert=True)
    title = _PURPOSE_LABELS.get(announcement.purpose, announcement.announcement_type)
    audience = "کاربران واجد شرایط ربات" if announcement.announcement_type in {"upcoming", "panel"} else ("ثبت‌نام‌کنندگان قطعی و افراد مرتبط با رزروهای قطعی تاریخی" if announcement.purpose == "cancellation_notice" else "ثبت‌نام‌کنندگان تأییدشدهٔ پنل")
    lines = ["📣 <b>پیش‌نمایش اطلاع‌رسانی</b>", f"نوع: {escape(title)}"]
    if event:
        lines.append(f"پنل: <b>{escape(event.title)}</b>")
    lines += [f"مخاطب: {audience}", f"تعداد دریافت‌کنندگان: <b>{recipients}</b>"]
    if duplicate_id:
        async with SessionLocal() as session:
            previous = await session.get(AdminAnnouncement, int(duplicate_id))
        if previous:
            lines.append(f"⚠️ هشدار تکرار: پیام مشابه #{previous.id} در {previous.created_at.strftime('%Y-%m-%d %H:%M')} ثبت شده است. اگر پیام دوم عمدی است، می‌توانید ادامه دهید.")
    lines += ["", "<b>متن ارسالی</b>", announcement.message_text, "", "با تأیید، پیام به‌صورت دستی ارسال می‌شود؛ هیچ زمان‌بندی خودکاری وجود ندارد."]
    rows = []
    if status == "preview" and recipients > 0:
        rows.append([InlineKeyboardButton(text="✅ تأیید و ارسال", callback_data=f"admin:announce:v72:send:{announcement_id}")])
        rows.append([InlineKeyboardButton(text="✏️ ویرایش پیام", callback_data=f"admin:announce:v72:edit:{announcement_id}"), InlineKeyboardButton(text="❌ لغو", callback_data=f"admin:announce:v72:cancel:{announcement_id}")])
    elif status in {"sending", "completed", "partial", "failed"}:
        rows.append([InlineKeyboardButton(text="📊 گزارش ارسال", callback_data=f"admin:announce:v72:view:{announcement_id}")])
    if event and await _is_admin(c.from_user.id):
        rows.append([InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{event.id}")])
    elif event:
        rows.append([InlineKeyboardButton(text="🔙 پنل من", callback_data=f"host:panel:view:{event.id}")])
    else:
        rows.append([InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)


@router.callback_query(F.data == "admin:announcements")
async def unified_announcements_menu(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text("📣 <b>اطلاع‌رسانی‌ها</b>\n\nمعرفی یک پنل، ارسال پیام به ثبت‌نام‌شده‌ها و اعلام پنل‌های پیش‌رو را از این بخش مدیریت کنید.\nسوابق هر پنل از صفحهٔ مدیریت همان پنل در دسترس است.", reply_markup=_announcement_main_keyboard())
    await c.answer()


def _panel_channel_post_text(event: Event) -> str:
    """Consistent bilingual-safe channel announcement body; CTA lives on a button."""
    from app.display_utils import volume_label, has_end_time_label
    def ltr(value: str) -> str:
        return "⁦" + escape(str(value)) + "⁩"
    time_value = str(event.start_time_label or "—")
    if has_end_time_label(event.end_time_label):
        time_value += f"–{event.end_time_label}"
    lines = [
        "📣 <b>پنل تازه در Panel Flow</b>",
        "",
        f"<b>{escape(volume_label(event.volume))} — {ltr(event.title)}</b>",
    ]
    if event.language:
        lines.append(panel_detail_line("زبان", ltr(event.language), icon="🌐"))
    if (event.description or "").strip():
        description = (event.description or "").strip()
        if len(description) > 500:
            description = description[:497] + "…"
        lines.extend(["", escape(description)])
    lines.extend([
        "",
        panel_detail_line("روز و تاریخ", f"{escape(str(event.event_day_label or '—'))} — {ltr(str(event.event_date_label or '—'))}", icon="📅"),
        panel_detail_line("زمان", ltr(time_value), icon="⏰"),
        panel_detail_line("مکان", ltr(str(event.venue or '—')), icon="📍"),
    ])
    if event.address:
        lines.append(panel_detail_line("آدرس", ltr(event.address), icon="📌"))
    return "\n".join(lines)


async def _configured_channel_target(session) -> tuple[str | None, str | None]:
    """Use explicit channel ID when configured; otherwise derive a public @username."""
    configured_id = getattr(settings, "panel_flow_channel_id", None)
    if configured_id:
        try:
            numeric_id = int(configured_id)
            if numeric_id:
                return str(numeric_id), None
        except (TypeError, ValueError):
            pass
    from app.services.app_settings import get_bot_settings
    values = await get_bot_settings(session)
    raw_url = str(values.get("community_channel_url") or "").strip()
    try:
        parsed = urlparse(raw_url)
        host = (parsed.hostname or "").lower()
        path_parts = [part for part in parsed.path.split("/") if part]
        if parsed.scheme != "https" or host not in {"t.me", "telegram.me"} or not path_parts:
            return None, "لینک عمومی کانال یا شناسهٔ عددی کانال در تنظیمات ثبت نشده است."
        candidate = path_parts[0]
        if candidate.startswith(("+", "joinchat")) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{4,31}", candidate):
            return None, "لینک کانال خصوصی است؛ برای انتشار، شناسهٔ عددی کانال را در تنظیمات سرور وارد کنید."
        return "@" + candidate, None
    except Exception:
        return None, "تنظیمات کانال معتبر نیست؛ لینک عمومی یا شناسهٔ عددی کانال را بررسی کنید."


def _channel_post_keyboard(post_id: int, registration_url: str, *, preview: bool = True) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="🎟 مشاهده پنل و ثبت‌نام", url=registration_url)]]
    if preview:
        rows.append([InlineKeyboardButton(text="🚀 انتشار در کانال", callback_data=f"admin:announce:v89:publish:{post_id}")])
        rows.append([InlineKeyboardButton(text="❌ لغو انتشار", callback_data=f"admin:announce:v89:cancel:{post_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data.regexp(r"^admin:announce:v89:pick:\d+$"))
async def panel_channel_announcement_picker(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(Event.id)).where(
            Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
        )) or 0)
        pages = max(1, (total + 6) // 7)
        page = min(page, pages - 1)
        events = (await session.execute(select(Event).where(
            Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
        ).order_by(Event.id.desc()).offset(page * 7).limit(7))).scalars().all()
    rows = [[InlineKeyboardButton(
        text=f"{event.volume} — {event.title}"[:64],
        callback_data=f"admin:announce:v89:choose:{int(event.id)}",
    )] for event in events]
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:announce:v89:pick:{page-1}"))
    if page + 1 < pages:
        navigation.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:announce:v89:pick:{page+1}"))
    if navigation:
        rows.append(navigation)
    rows.append([InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")])
    body = f"<b>انتخاب پنل برای انتشار در کانال</b>\n\nصفحهٔ {page+1} از {pages}" if events else "پنل منتشرشده‌ای برای معرفی در کانال وجود ندارد."
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v89:choose:\d+$"))
async def panel_channel_announcement_preview(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    try:
        username = await _bot_username(c.bot)
    except Exception:
        return await c.answer("نام کاربری ربات برای ساخت دکمهٔ ثبت‌نام در دسترس نیست.", show_alert=True)
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event or event.status != EventStatus.PUBLISHED or event.archived:
            return await c.answer("این پنل دیگر برای انتشار در دسترس نیست.", show_alert=True)
        chat_id, target_error = await _configured_channel_target(session)
        if target_error:
            return await c.answer(target_error, show_alert=True)
        body = _panel_channel_post_text(event)
        post = PanelAnnouncementPost(
            event_id=event_id, actor_telegram_id=int(c.from_user.id),
            chat_id=str(chat_id), message_text=body, status="preview",
        )
        session.add(post)
        await session.flush()
        post_id = int(post.id)
        await session.commit()
        registration_url = _registration_url(username, event_id)
    await c.message.edit_text(
        "<b>پیش‌نمایش انتشار در کانال</b>\n\n" + body,
        reply_markup=_channel_post_keyboard(post_id, registration_url),
        disable_web_page_preview=True,
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v89:cancel:\d+$"))
async def cancel_panel_channel_announcement(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    post_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        post = await session.get(PanelAnnouncementPost, post_id, with_for_update=True)
        if not post or post.actor_telegram_id != int(c.from_user.id) or post.status != "preview":
            return await c.answer("این پیش‌نمایش دیگر قابل لغو نیست.", show_alert=True)
        post.status = "cancelled"
        await session.commit()
    await c.message.edit_text("انتشار این پنل لغو شد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")
    ]]))
    await c.answer("لغو شد.")


@router.callback_query(F.data.regexp(r"^admin:announce:v89:publish:\d+$"))
async def publish_panel_channel_announcement(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    post_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        post = await session.get(PanelAnnouncementPost, post_id, with_for_update=True)
        if not post:
            return await c.answer("پیش‌نمایش پیدا نشد.", show_alert=True)
        if post.status != "preview":
            return await c.answer("این انتشار قبلاً پردازش شده است؛ برای جلوگیری از ارسال تکراری دوباره منتشر نمی‌شود.", show_alert=True)
        event = await session.get(Event, post.event_id)
        if not event or event.status != EventStatus.PUBLISHED or event.archived:
            post.status = "cancelled"
            post.last_error = "event_no_longer_publishable"
            await session.commit()
            return await c.answer("پنل دیگر منتشرشده و فعال نیست؛ انتشار لغو شد.", show_alert=True)
        post.status = "sending"
        post.last_error = None
        await session.commit()
        chat_id = post.chat_id
        body = post.message_text
        event_id = int(post.event_id)
    await c.answer("در حال انتشار در کانال…")
    try:
        bot_user = await c.bot.get_me()
        member = await c.bot.get_chat_member(chat_id, bot_user.id)
        member_status = str(getattr(member, "status", ""))
        if member_status not in {"administrator", "creator"}:
            raise RuntimeError("ربات باید مدیر کانال باشد.")
        can_post = getattr(member, "can_post_messages", None)
        if member_status == "administrator" and can_post is False:
            raise RuntimeError("مجوز انتشار پیام در کانال برای ربات فعال نیست.")
        username = str(getattr(bot_user, "username", "") or "").strip().removeprefix("@")
        if not username:
            raise RuntimeError("نام کاربری ربات در دسترس نیست.")
        sent = await c.bot.send_message(
            chat_id=chat_id, text=body,
            reply_markup=_channel_post_keyboard(post_id, _registration_url(username, event_id), preview=False),
            disable_web_page_preview=True,
        )
        final_status = "published"
        final_error = None
        message_id = int(sent.message_id)
    except Exception as exc:
        # Explicit Bot API rejections are safe to label failed; network/unknown
        # outcomes may have reached Telegram and must never be blindly retried.
        from aiogram.exceptions import TelegramAPIError, TelegramNetworkError
        final_status = "failed" if isinstance(exc, TelegramAPIError) and not isinstance(exc, TelegramNetworkError) else "unknown"
        final_error = f"{type(exc).__name__}: {exc}"[:255]
        message_id = None
        logger.warning("Panel channel publication failed/unknown post_id=%s", post_id, exc_info=True)
    async with SessionLocal() as session:
        post = await session.get(PanelAnnouncementPost, post_id, with_for_update=True)
        if post and post.status == "sending":
            post.status = final_status
            post.last_error = final_error
            post.telegram_message_id = message_id
            post.published_at = utc_now_naive() if final_status == "published" else None
            await session.commit()
    if final_status == "published":
        await c.message.edit_text(f"✅ معرفی پنل #{event_id} در کانال منتشر شد.\nشناسهٔ پیام: <code>{message_id}</code>", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🗂 تاریخچه این پنل", callback_data=f"admin:announce:v89:history:{event_id}:0")
        ], [InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")]]))
    elif final_status == "failed":
        await c.message.edit_text(f"❌ انتشار پنل #{event_id} توسط Telegram رد شد.\nجزئیات: {escape(final_error or 'خطای نامشخص')}", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")
        ]]))
    else:
        await c.message.edit_text(f"⚠️ نتیجهٔ انتشار پنل #{event_id} نامشخص است. برای جلوگیری از پیام تکراری، ارسال خودکار تکرار نشد. ابتدا کانال را بررسی کنید.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🗂 تاریخچه این پنل", callback_data=f"admin:announce:v89:history:{event_id}:0")
        ]]))


@router.callback_query(F.data.regexp(r"^admin:announce:v89:history:\d+:\d+$"))
async def panel_channel_announcement_history(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    if len(parts) != 6:
        return await c.answer("شناسهٔ تاریخچه معتبر نیست.", show_alert=True)
    event_id, page = int(parts[4]), max(0, int(parts[5]))
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        total = int(await session.scalar(select(func.count(PanelAnnouncementPost.id)).where(PanelAnnouncementPost.event_id == event_id)) or 0)
        posts = (await session.execute(select(PanelAnnouncementPost).where(
            PanelAnnouncementPost.event_id == event_id
        ).order_by(PanelAnnouncementPost.created_at.desc()).offset(page * 8).limit(8))).scalars().all()
    labels = {"preview": "پیش‌نویس", "sending": "در حال ارسال", "published": "منتشرشده", "failed": "ناموفق", "unknown": "نامشخص", "cancelled": "لغوشده"}
    lines = [f"🗂 <b>تاریخچه انتشار کانال · {escape(event.title)}</b>"]
    for post in posts:
        stamp = post.published_at or post.created_at
        stamp_text = stamp.strftime("%Y-%m-%d %H:%M") if stamp else "—"
        lines.append(f"• #{post.id} · {labels.get(post.status, post.status)} · {escape(stamp_text)}")
        if post.last_error and post.status in {"failed", "unknown"}:
            lines.append(f"  <i>{escape(post.last_error[:100])}</i>")
    if not posts:
        lines.append("هنوز معرفی‌ای برای این پنل در کانال منتشر نشده است.")
    rows = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:announce:v89:history:{event_id}:{page-1}"))
    if (page + 1) * 8 < total:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:announce:v89:history:{event_id}:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="📣 معرفی دوباره پنل در کانال", callback_data=f"admin:announce:v89:choose:{event_id}")])
    rows.append([InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{event_id}")])
    await c.message.edit_text("\n\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


async def recover_interrupted_announcements(bot) -> None:
    """Mark interrupted channel sends unknown and resume safe pending DM deliveries."""
    try:
        async with SessionLocal() as session:
            interrupted_posts = (await session.execute(select(PanelAnnouncementPost).where(
                PanelAnnouncementPost.status == "sending"
            ))).scalars().all()
            for post in interrupted_posts:
                post.status = "unknown"
                post.last_error = "process_restarted_before_result_was_recorded"
            ids = (await session.execute(select(AdminAnnouncement.id).where(
                AdminAnnouncement.status.in_(("sending", "partial"))
            ))).scalars().all()
            await session.commit()
        for announcement_id in ids:
            await _process_unified_announcement(bot, int(announcement_id))
    except Exception:
        logger.exception("Announcement recovery failed during startup")


@router.callback_query(F.data == "admin:announce:v72:upcoming")
async def unified_upcoming_announcement(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _create_announcement_preview(c, announcement_type="upcoming", purpose="upcoming_lineup")


@router.callback_query(F.data.regexp(r"^admin:announce:v72:pick:panel:\d+$"))
async def unified_panel_picker(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    page = int((c.data or "").rsplit(":", 1)[1])
    await _render_announcement_panel_picker(c, purpose="panel", page=page)
    await c.answer()


async def _render_announcement_panel_picker(c: CallbackQuery, *, purpose: str, page: int, purpose_for_participants: str | None = None):
    async with SessionLocal() as session:
        if purpose == "panel":
            stmt = select(Event).where(Event.status == EventStatus.PUBLISHED, Event.archived.is_(False))
        elif purpose_for_participants == "cancellation_notice":
            stmt = select(Event).where(Event.status == EventStatus.CANCELLED, Event.archived.is_(False))
        else:
            stmt = select(Event).where(Event.status.in_((EventStatus.PUBLISHED, EventStatus.CANCELLED)), Event.archived.is_(False))
        total = int(await session.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0)
        pages = max(1, (total + 7 - 1) // 7)
        page = min(max(0, page), pages - 1)
        events = (await session.execute(stmt.order_by(Event.id.desc()).offset(page * 7).limit(7))).scalars().all()
    rows = []
    for event in events:
        callback = f"admin:announce:v72:choose_panel:{event.id}" if purpose == "panel" else f"admin:announce:v72:choose_participants:{purpose_for_participants}:{event.id}"
        label = f"{event.title} · #{event.id}"
        if event.status == EventStatus.CANCELLED:
            label = "❌ " + label
        rows.append([InlineKeyboardButton(text=label[:64], callback_data=callback)])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:announce:v72:pick:panel:{page-1}" if purpose == "panel" else f"admin:announce:v72:pick:participants:{purpose_for_participants}:{page-1}"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:announce:v72:pick:panel:{page+1}" if purpose == "panel" else f"admin:announce:v72:pick:participants:{purpose_for_participants}:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")])
    if not events:
        title = "پنل واجد شرایطی برای این نوع پیام وجود ندارد."
    else:
        title = f"پنل را انتخاب کنید · صفحه {page+1}/{pages}"
    await c.message.edit_text(title, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:announce:v72:pick:participants:(reminder_today|important_update|cancellation_notice|custom):\d+$"))
async def unified_participants_picker(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    purpose, page = parts[5], int(parts[6])
    await _render_announcement_panel_picker(c, purpose="participants", purpose_for_participants=purpose, page=page)
    await c.answer()


@router.callback_query(F.data == "admin:announce:v72:purpose:0")
async def unified_choose_participant_purpose(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text("👥 <b>پیام به ثبت‌نام‌شده‌ها</b>\n\nمخاطبان بر اساس ثبت‌نام‌های واقعی انتخاب می‌شوند. میزبان‌ها فقط می‌توانند به مخاطبان پنل‌های خود پیام بدهند و فهرست افراد را نمی‌بینند.", reply_markup=_purpose_keyboard())
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:purpose:(reminder_today|important_update|cancellation_notice|custom)$"))
async def unified_participant_purpose_selected(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    purpose = (c.data or "").rsplit(":", 1)[1]
    if purpose == "cancellation_notice":
        await _render_announcement_panel_picker(c, purpose="participants", purpose_for_participants=purpose, page=0)
    else:
        await _render_announcement_panel_picker(c, purpose="participants", purpose_for_participants=purpose, page=0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:purposepanel:\d+:(reminder_today|important_update|cancellation_notice|custom)$"))
async def unified_panel_purpose_selected(c: CallbackQuery, state: FSMContext):
    event_id, purpose = int((c.data or "").split(":")[4]), (c.data or "").rsplit(":", 1)[1]
    authorized, is_admin_actor = await _authorized_event_actor(c.from_user.id, event_id)
    if not authorized:
        return await c.answer("اجازهٔ ارسال برای این پنل وجود ندارد.", show_alert=True)
    if purpose in {"important_update", "cancellation_notice", "custom"}:
        async with SessionLocal() as session:
            event = await session.get(Event, event_id)
            if not event:
                return await c.answer("پنل پیدا نشد.", show_alert=True)
            if purpose == "cancellation_notice" and event.status != EventStatus.CANCELLED:
                return await c.answer("ابتدا وضعیت پنل را به لغوشده تغییر دهید.", show_alert=True)
        await state.clear()
        await state.update_data(announcement_custom_event_id=event_id, announcement_custom_purpose=purpose, announcement_custom_actor_admin=is_admin_actor)
        await state.set_state(AdminConsoleStates.announcement_custom)
        prompts = {"important_update": "متن به‌روزرسانی مهم را بنویسید (۳ تا ۲۰۰۰ نویسه).", "cancellation_notice": "متن اطلاعیهٔ لغو را بنویسید (۳ تا ۲۰۰۰ نویسه).", "custom": "پیام دلخواه به ثبت‌نام‌شده‌ها را بنویسید (۳ تا ۲۰۰۰ نویسه)."}
        return await c.message.edit_text(f"پنل انتخاب‌شده: #{event_id}\n{prompts[purpose]}", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ لغو", callback_data=f"admin:event:announcements:{event_id}")]]))
    await _create_announcement_preview(c, announcement_type="participants", purpose=purpose, event_id=event_id)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:choose_participants:(reminder_today|important_update|cancellation_notice|custom):\d+$"))
async def unified_participants_panel_selected(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    purpose, event_id = parts[5], int(parts[6])
    if purpose in {"important_update", "cancellation_notice", "custom"}:
        async with SessionLocal() as session:
            event = await session.get(Event, event_id)
            if not event:
                return await c.answer("پنل پیدا نشد.", show_alert=True)
            if purpose == "cancellation_notice" and event.status != EventStatus.CANCELLED:
                return await c.answer("برای پیام لغو باید ابتدا پنل از مسیر مدیریت لغو شده باشد.", show_alert=True)
        await state.clear()
        await state.update_data(announcement_custom_event_id=event_id, announcement_custom_purpose=purpose, announcement_custom_actor_admin=True)
        await state.set_state(AdminConsoleStates.announcement_custom)
        prompts = {"important_update": "متن به‌روزرسانی مهم را بنویسید (۳ تا ۲۰۰۰ نویسه).", "cancellation_notice": "متن اطلاعیهٔ لغو را بنویسید (۳ تا ۲۰۰۰ نویسه).", "custom": "پیام دلخواه به ثبت‌نام‌شده‌ها را بنویسید (۳ تا ۲۰۰۰ نویسه)."}
        return await c.message.edit_text(f"پنل انتخاب‌شده: #{event_id}\n{prompts[purpose]}", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ لغو", callback_data="admin:announcements")]]))
    await _create_announcement_preview(c, announcement_type="participants", purpose=purpose, event_id=event_id)
    await c.answer()


@router.message(AdminConsoleStates.announcement_custom)
async def unified_custom_announcement_body(message: Message, state: FSMContext):
    body = (message.text or "").strip()
    if not 3 <= len(body) <= 2000:
        return await message.answer("متن پیام باید بین ۳ تا ۲۰۰۰ نویسه باشد.")
    data = await state.get_data()
    event_id = int(data.get("announcement_custom_event_id", 0))
    purpose = str(data.get("announcement_custom_purpose", "custom"))
    authorized, is_admin_actor = await _authorized_event_actor(message.from_user.id, event_id)
    if not authorized:
        await state.clear()
        return await message.answer("اجازهٔ ارسال برای این پنل وجود ندارد.")
    await state.clear()
    # A small callback-shaped adapter lets both message-originated and callback-originated
    # flows use the same durable preview/recipient implementation.
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event:
            return await message.answer("پنل پیدا نشد؛ پیام ساخته نشد.")
        if purpose == "cancellation_notice":
            if event.status != EventStatus.CANCELLED or event.archived:
                return await message.answer("پنل دیگر در وضعیت مجاز برای اطلاعیه لغو نیست؛ پیام ساخته نشد.")
        elif event.status != EventStatus.PUBLISHED or event.archived:
            return await message.answer("به‌روزرسانی و پیام سفارشی فقط برای پنل منتشرشده و غیرآرشیوی مجاز است.")
        prefix = {"important_update": f"📌 <b>به‌روزرسانی مهم پنل</b>\n{escape(event.title)}", "cancellation_notice": f"❌ <b>اطلاعیه لغو پنل</b>\n{escape(event.title)}", "custom": f"📣 <b>پیام برای ثبت‌نام‌شده‌های پنل</b>\n{escape(event.title)}"}[purpose]
        body_html = f"{prefix}\n\n{escape(body)}"
        if purpose == "cancellation_notice":
            body_html += "\n\nدر صورت نیاز به پیگیری رزرو، لطفاً از پشتیبانی ربات کمک بگیرید."
        recipients = await _collect_announcement_recipients(session, "participants", purpose, event_id)
        if not recipients:
            return await message.answer("در حال حاضر دریافت‌کننده واجد شرایطی وجود ندارد؛ پیام ارسال نشد.")
        announcement_id = await _persist_announcement_preview(
            session, actor_id=int(message.from_user.id), announcement_type="participants",
            purpose=purpose, event_id=event_id, event_title=event.title,
            message_body=body_html, recipients=recipients,
        )
    markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="بازکردن پیش‌نمایش", callback_data=f"admin:announce:v72:view:{announcement_id}")]])
    await message.answer("پیش‌نمایش پیام آماده است. با بازکردن آن، مخاطبان و متن نهایی را بررسی کنید؛ تا زمان تأیید صریح، هیچ پیامی ارسال نمی‌شود.", reply_markup=markup)


async def show_panel_communications_from_message(message: Message, event_id: int) -> bool:
    """Authenticated Telegram deep-link entry into one panel's existing contact flow."""
    authorized, is_admin_actor = await _authorized_event_actor(int(message.from_user.id), int(event_id))
    if not authorized:
        await message.answer("برای ارتباط با شرکت‌کنندگان این پنل، باید مدیر یا میزبان همین پنل باشید.")
        return True
    async with SessionLocal() as session:
        event = await session.get(Event, int(event_id))
        if event is None:
            await message.answer("پنل پیدا نشد.")
            return True
        can_promote = is_admin_actor and event.status == EventStatus.PUBLISHED and not event.archived
        markup = _panel_announcement_keyboard(int(event_id), can_promote)
        title = event.title
    await message.answer(
        f"📣 <b>ارتباطات پنل</b>\n{escape(title)}\n\n"
        "مخاطبان در سمت سرور و بر اساس رزروهای واجد شرایط تعیین می‌شوند. ابتدا پیش‌نمایش پیام و مخاطبان را بررسی کنید؛ ارسال فقط پس از تأیید صریح انجام می‌شود.",
        reply_markup=markup,
        disable_web_page_preview=True,
    )
    return True


@router.callback_query(F.data.regexp(r"^admin:event:announcements:\d+$"))
async def panel_announcement_menu(c: CallbackQuery, state: FSMContext):
    await state.clear()
    event_id = int((c.data or "").rsplit(":", 1)[1])
    authorized, is_admin_actor = await _authorized_event_actor(c.from_user.id, event_id)
    if not authorized:
        return await c.answer("اجازهٔ دسترسی به این پنل وجود ندارد.", show_alert=True)
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        can_promote = is_admin_actor and event.status == EventStatus.PUBLISHED and not event.archived
        markup = _panel_announcement_keyboard(event_id, can_promote)
        title = event.title
    await c.message.edit_text(f"📣 <b>اطلاع‌رسانی‌های پنل</b>\n{escape(title)}\n\nاین صفحه فقط عملیات مربوط به همین پنل را نشان می‌دهد. میزبان‌ها فقط ارتباطات مجاز با ثبت‌نام‌شده‌های پنل خود را می‌بینند.", reply_markup=markup)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:startpanel:\d+$"))
async def panel_global_announcement_start(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("فقط مدیر می‌تواند پیام عمومی ارسال کند.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    await _create_announcement_preview(c, announcement_type="panel", purpose="individual_panel", event_id=event_id)


@router.callback_query(F.data.regexp(r"^admin:announce:v72:purposepanel:\d+$"))
async def panel_announcement_choose_purpose(c: CallbackQuery):
    event_id = int((c.data or "").rsplit(":", 1)[1])
    authorized, _ = await _authorized_event_actor(c.from_user.id, event_id)
    if not authorized:
        return await c.answer("اجازهٔ دسترسی به این پنل وجود ندارد.", show_alert=True)
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
    await c.message.edit_text(f"👥 <b>پیام به ثبت‌نام‌شده‌ها</b>\nپنل: {escape(event.title)}\n\nنوع پیام را انتخاب کنید. مخاطبان در سمت سرور محاسبه می‌شوند و نام افراد به میزبان نمایش داده نمی‌شود.", reply_markup=_purpose_keyboard(event_id))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:choose_panel:\d+$"))
async def unified_panel_selected(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    await _create_announcement_preview(c, announcement_type="panel", purpose="individual_panel", event_id=event_id)


@router.callback_query(F.data.regexp(r"^admin:announce:v72:edit:\d+$"))
async def unified_announcement_edit_start(c: CallbackQuery, state: FSMContext):
    announcement_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        announcement = await session.get(AdminAnnouncement, announcement_id)
        if not announcement:
            return await c.answer("پیش‌نمایش پیدا نشد.", show_alert=True)
        if announcement.status != "preview":
            return await c.answer("پیامی که ارسال آن آغاز شده قابل ویرایش نیست.", show_alert=True)
    if not await _announcement_authorized(c.from_user.id, announcement):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.update_data(announcement_edit_id=announcement_id)
    await state.set_state(AdminConsoleStates.announcement_edit_body)
    await c.message.edit_text("متن جایگزین پیام را بفرستید (پیام به‌صورت متن ساده ارسال می‌شود؛ لینک‌های HTML قبلی جایگزین خواهند شد).", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:announce:v72:view:{announcement_id}")]]))
    await c.answer()


@router.message(AdminConsoleStates.announcement_edit_body)
async def unified_announcement_edit_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id) and not await _is_host(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    body = (message.text or "").strip()
    if not 3 <= len(body) <= 3900:
        return await message.answer("متن جایگزین باید بین ۳ تا ۳۹۰۰ نویسه باشد.")
    data = await state.get_data()
    announcement_id = int(data.get("announcement_edit_id", 0))
    async with SessionLocal() as session:
        announcement = (await session.execute(select(AdminAnnouncement).where(AdminAnnouncement.id == announcement_id).with_for_update())).scalar_one_or_none()
        if not announcement or announcement.status != "preview":
            await state.clear()
            return await message.answer("پیش‌نمایش دیگر قابل ویرایش نیست.")
        # Editing an announcement is restricted to its initiator unless the actor is the owner.
        if int(announcement.actor_telegram_id) != int(message.from_user.id) and not _is_owner(message.from_user.id):
            await state.clear()
            return await message.answer("فقط سازنده یا مالک محافظت‌شده می‌تواند این پیش‌نمایش را ویرایش کند.")
        announcement.message_text = escape(body)
        # Recompute before preview; recipients remain unchanged unless the booking state changed.
        recipients = await _collect_announcement_recipients(session, announcement.announcement_type, announcement.purpose, announcement.event_id)
        saved = set((await session.execute(select(AdminAnnouncementDelivery.telegram_id).where(AdminAnnouncementDelivery.announcement_id == announcement_id))).scalars().all())
        if saved != set(recipients):
            await session.execute(delete(AdminAnnouncementDelivery).where(AdminAnnouncementDelivery.announcement_id == announcement_id))
            for tg_id in recipients:
                session.add(AdminAnnouncementDelivery(announcement_id=announcement_id, telegram_id=tg_id, status="pending", updated_at=utc_now_naive()))
            announcement.recipient_count = len(recipients)
        await session.commit()
    await state.clear()
    await message.answer("✅ متن جایگزین ذخیره شد. پیش‌نمایش به‌روز شده را بررسی کنید.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="مشاهده پیش‌نمایش", callback_data=f"admin:announce:v72:view:{announcement_id}")]]))


@router.callback_query(F.data.regexp(r"^admin:announce:v72:cancel:\d+$"))
async def unified_announcement_cancel(c: CallbackQuery):
    announcement_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        announcement = (await session.execute(select(AdminAnnouncement).where(AdminAnnouncement.id == announcement_id).with_for_update())).scalar_one_or_none()
        if not announcement:
            return await c.answer("پیش‌نمایش پیدا نشد.", show_alert=True)
        if not await _announcement_authorized(c.from_user.id, announcement):
            return await c.answer("دسترسی مجاز نیست.", show_alert=True)
        if announcement.status != "preview":
            return await c.answer("ارسال قبلاً آغاز شده و قابل لغو نیست.", show_alert=True)
        announcement.status = "cancelled"
        await _write_announcement_audit(session, actor_telegram_id=c.from_user.id, action="announcement_preview_cancelled", entity_id=announcement_id, details={"type": announcement.announcement_type, "purpose": announcement.purpose})
        await session.commit()
    await c.message.edit_text("✅ پیش‌نمایش لغو شد؛ هیچ پیامی ارسال نشد.", reply_markup=_announcement_main_keyboard() if await _is_admin(c.from_user.id) else InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="بازگشت به پنل", callback_data=f"host:panel:view:{announcement.event_id}")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:send:\d+$"))
async def unified_announcement_send(c: CallbackQuery):
    if not await _is_admin(c.from_user.id) and not await _is_host(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    announcement_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        # Serialize sends sharing the same type/purpose/panel, not merely repeated
        # clicks on the same preview. This closes the race where two distinct previews
        # are confirmed simultaneously before either one becomes visible in history.
        candidate = (await session.execute(select(
            AdminAnnouncement.announcement_type, AdminAnnouncement.purpose, AdminAnnouncement.event_id,
        ).where(AdminAnnouncement.id == announcement_id))).one_or_none()
        if not candidate:
            return await c.answer("اطلاع‌رسانی پیدا نشد.", show_alert=True)
        lock_material = f"panel-flow-announcement:{candidate[0]}:{candidate[1]}:{candidate[2] or 0}".encode("utf-8")
        lock_key = int.from_bytes(hashlib.sha256(lock_material).digest()[:8], "big")
        if lock_key > 0x7FFFFFFFFFFFFFFF:
            lock_key -= 0x10000000000000000
        await session.execute(text("SELECT pg_advisory_xact_lock(:lock_key)"), {"lock_key": lock_key})
        announcement = (await session.execute(
            select(AdminAnnouncement).where(AdminAnnouncement.id == announcement_id)
            .with_for_update().execution_options(populate_existing=True)
        )).scalar_one_or_none()
        if not announcement:
            return await c.answer("اطلاع‌رسانی پیدا نشد.", show_alert=True)
        if not await _announcement_authorized(c.from_user.id, announcement):
            return await c.answer("اجازهٔ این ارسال وجود ندارد.", show_alert=True)
        if announcement.status != "preview":
            return await c.answer("این عملیات قبلاً آغاز شده یا لغو شده است؛ ارسال دوباره انجام نمی‌شود.", show_alert=True)
        if announcement.event_id is not None:
            event = await session.get(Event, int(announcement.event_id))
            if not event:
                return await c.answer("پنل حذف شده؛ ارسال متوقف شد.", show_alert=True)
            if announcement.announcement_type == "panel" and (event.status != EventStatus.PUBLISHED or event.archived):
                return await c.answer("پنل دیگر برای معرفی عمومی واجد شرایط نیست.", show_alert=True)
            if announcement.purpose == "cancellation_notice":
                if event.status != EventStatus.CANCELLED or event.archived:
                    return await c.answer("پنل دیگر در وضعیت مجاز برای اعلام لغو نیست؛ ارسال متوقف شد.", show_alert=True)
            elif announcement.announcement_type == "participants" and (event.status != EventStatus.PUBLISHED or event.archived):
                return await c.answer("پنل دیگر منتشرشده و غیرآرشیوی نیست؛ ارسال متوقف شد.", show_alert=True)
            if not await _is_admin(c.from_user.id):
                actor = await _get_user(session, c.from_user.id)
                if not actor or event.host_id != actor.id:
                    return await c.answer("پنل دیگر متعلق به شما نیست.", show_alert=True)
        fresh_recipients = await _collect_announcement_recipients(session, announcement.announcement_type, announcement.purpose, announcement.event_id)
        meta = json.loads(announcement.message_meta_json or "{}")
        duplicate = await _duplicate_announcement(session, announcement.announcement_type, announcement.purpose, announcement.event_id)
        known_duplicate_id = int(meta.get("duplicate_previous_id") or 0)
        if duplicate and int(duplicate.id) != known_duplicate_id:
            # Do not silently bypass a newer matching operation created after this preview.
            meta["duplicate_previous_id"] = int(duplicate.id)
            announcement.message_meta_json = json.dumps(meta, ensure_ascii=False)
            await session.commit()
            await c.answer("یک اطلاع‌رسانی مشابه از زمان پیش‌نمایش ثبت شده است؛ هشدار اضافه شد. لطفاً پیش‌نمایش را دوباره بررسی کنید.", show_alert=True)
            await _render_announcement_preview(c, announcement_id)
            return
        stored_recipients = set((await session.execute(select(AdminAnnouncementDelivery.telegram_id).where(AdminAnnouncementDelivery.announcement_id == announcement_id))).scalars().all())
        if stored_recipients != set(fresh_recipients):
            await session.execute(delete(AdminAnnouncementDelivery).where(AdminAnnouncementDelivery.announcement_id == announcement_id))
            for tg_id in fresh_recipients:
                session.add(AdminAnnouncementDelivery(announcement_id=announcement_id, telegram_id=tg_id, status="pending", updated_at=utc_now_naive()))
            announcement.recipient_count = len(fresh_recipients)
            await session.commit()
            await c.answer("مخاطبان از زمان پیش‌نمایش تغییر کرده‌اند؛ شمارش و پیش‌نمایش به‌روز شد. دوباره بررسی و تأیید کنید.", show_alert=True)
            await _render_announcement_preview(c, announcement_id)
            return
        if not fresh_recipients:
            return await c.answer("مخاطب واجد شرایطی وجود ندارد؛ ارسال انجام نشد.", show_alert=True)
        # The status compare-and-set is the duplicate-click/concurrency safeguard.
        result = await session.execute(update(AdminAnnouncement).where(AdminAnnouncement.id == announcement_id, AdminAnnouncement.status == "preview").values(status="sending", started_at=utc_now_naive()))
        if not result.rowcount:
            return await c.answer("این ارسال قبلاً آغاز شده است.", show_alert=True)
        await _write_announcement_audit(session, actor_telegram_id=c.from_user.id, action="announcement_sending_started", entity_id=announcement_id, details={"type": announcement.announcement_type, "purpose": announcement.purpose, "event_id": announcement.event_id, "recipient_count": announcement.recipient_count})
        await session.commit()
    await c.answer("ارسال دستی آغاز شد؛ نتیجهٔ هر دریافت‌کننده ثبت می‌شود.")
    await c.message.edit_text("📣 ارسال در حال انجام است؛ نتیجهٔ نهایی در گزارش قابل مشاهده خواهد بود.")
    await _process_unified_announcement(c.bot, announcement_id)
    await _render_announcement_result(c, announcement_id)


async def _process_unified_announcement(bot, announcement_id: int):
    """Process one durable broadcast under a cross-process advisory lock.

    A crash after Telegram accepted a message but before its result was committed
    is ambiguous. Old ``sending`` rows are therefore changed to ``unknown`` and
    never resent; only ``pending`` rows are resumed.
    """
    lock_key = int.from_bytes(
        hashlib.sha256(f"panel-flow-unified-announcement:{int(announcement_id)}".encode()).digest()[:8],
        byteorder="big", signed=True,
    )
    lock_engine = event_isolation_engine._get_engine()
    async with lock_engine.connect() as lock_connection:
        acquired = bool(await lock_connection.scalar(
            text("SELECT pg_try_advisory_lock(:lock_key)"), {"lock_key": lock_key}
        ))
        await lock_connection.commit()
        if not acquired:
            logger.info("Announcement %s is already being processed by another worker", announcement_id)
            return
        try:
            await _process_unified_announcement_locked(bot, int(announcement_id))
        finally:
            try:
                await lock_connection.execute(
                    text("SELECT pg_advisory_unlock(:lock_key)"), {"lock_key": lock_key}
                )
                await lock_connection.commit()
            except Exception:
                logger.exception("Could not release announcement advisory lock id=%s", announcement_id)


async def _process_unified_announcement_locked(bot, announcement_id: int):
    async with SessionLocal() as session:
        announcement = await session.get(AdminAnnouncement, int(announcement_id), with_for_update=True)
        if not announcement or announcement.status not in {"sending", "partial"}:
            return
        # These rows may have been interrupted after Telegram accepted a request.
        # They are surfaced as uncertain and never automatically sent again.
        interrupted = (await session.execute(select(AdminAnnouncementDelivery).where(
            AdminAnnouncementDelivery.announcement_id == announcement_id,
            AdminAnnouncementDelivery.status == "sending",
        ).with_for_update())).scalars().all()
        for delivery in interrupted:
            delivery.status = "unknown"
            delivery.last_error = "process_interrupted_after_send_started; verify Telegram delivery before any manual action"
            delivery.updated_at = utc_now_naive()
        delivery_ids = (await session.execute(select(AdminAnnouncementDelivery.id).where(
            AdminAnnouncementDelivery.announcement_id == announcement_id,
            AdminAnnouncementDelivery.status == "pending",
        ).order_by(AdminAnnouncementDelivery.id))).scalars().all()
        await session.commit()

    for delivery_id in delivery_ids:
        async with SessionLocal() as session:
            delivery = (await session.execute(select(AdminAnnouncementDelivery).where(
                AdminAnnouncementDelivery.id == delivery_id
            ).with_for_update())).scalar_one_or_none()
            announcement = await session.get(AdminAnnouncement, int(announcement_id))
            if not delivery or delivery.status != "pending" or not announcement or announcement.status not in {"sending", "partial"}:
                continue
            delivery.status = "sending"
            delivery.attempts = int(delivery.attempts or 0) + 1
            delivery.updated_at = utc_now_naive()
            telegram_id = int(delivery.telegram_id)
            body = str(announcement.message_text)
            await session.commit()
        try:
            result = await send_announcement_to_user(bot, telegram_id, body, reply_markup=None, max_attempts=4, delay_seconds=0.05)
            result_status = str(result.status)
            result_error = (result.error or "")[:255] or None
            result_attempts = max(1, int(result.attempts))
        except Exception as exc:
            # Unexpected adapter/network failures have uncertain delivery status.
            logger.exception("Announcement delivery adapter raised; announcement_id=%s recipient=%s", announcement_id, telegram_id)
            result_status = "unknown"
            result_error = f"{type(exc).__name__}: {exc}"[:255]
            result_attempts = 1
        if result_status not in {"sent", "failed", "unknown"}:
            result_status = "unknown"
            result_error = result_error or "unrecognized_delivery_status"
        async with SessionLocal() as session:
            delivery = (await session.execute(select(AdminAnnouncementDelivery).where(
                AdminAnnouncementDelivery.id == delivery_id
            ).with_for_update())).scalar_one_or_none()
            if delivery and delivery.status == "sending":
                delivery.status = result_status
                delivery.last_error = result_error
                delivery.attempts = max(1, int(delivery.attempts or 0)) + max(0, result_attempts - 1)
                delivery.updated_at = utc_now_naive()
                await session.commit()
        await asyncio.sleep(0.05)

    async with SessionLocal() as session:
        announcement = (await session.execute(select(AdminAnnouncement).where(
            AdminAnnouncement.id == int(announcement_id)
        ).with_for_update())).scalar_one_or_none()
        if not announcement:
            return
        grouped = (await session.execute(select(
            AdminAnnouncementDelivery.status, func.count(AdminAnnouncementDelivery.id)
        ).where(AdminAnnouncementDelivery.announcement_id == announcement_id).group_by(
            AdminAnnouncementDelivery.status
        ))).all()
        counts = {str(status): int(count) for status, count in grouped}
        sent = counts.get("sent", 0)
        pending = counts.get("pending", 0)
        uncertain_or_failed = counts.get("failed", 0) + counts.get("unknown", 0)
        announcement.sent_count = sent
        announcement.failed_count = uncertain_or_failed
        announcement.skipped_count = counts.get("skipped", 0)
        announcement.status = (
            "sending" if pending > 0 else
            "completed" if uncertain_or_failed == 0 else
            "partial" if sent else "failed"
        )
        announcement.completed_at = utc_now_naive() if pending == 0 else None
        await _write_announcement_audit(
            session, actor_telegram_id=announcement.actor_telegram_id,
            action="announcement_sending_finished", entity_id=announcement_id,
            details={"status": announcement.status, "sent": sent,
                     "failed_or_unknown": uncertain_or_failed, "pending": pending,
                     "recipient_count": announcement.recipient_count},
        )
        await session.commit()


async def _render_announcement_result(c: CallbackQuery, announcement_id: int):
    async with SessionLocal() as session:
        announcement = await session.get(AdminAnnouncement, int(announcement_id))
        if not announcement:
            return await c.answer("گزارش پیدا نشد.")
        rows = (await session.execute(select(AdminAnnouncementDelivery.status, func.count(AdminAnnouncementDelivery.id)).where(AdminAnnouncementDelivery.announcement_id == announcement_id).group_by(AdminAnnouncementDelivery.status))).all()
        counts = {str(status): int(count) for status, count in rows}
    lines = ["📊 <b>نتیجه اطلاع‌رسانی</b>", f"شناسه عملیات: #{announcement_id}", f"وضعیت: {escape(admin_status_display_label(announcement.status))}", f"نوع: {escape(_PURPOSE_LABELS.get(announcement.purpose, announcement.announcement_type))}", f"دریافت‌کنندگان هدف: {int(announcement.recipient_count)}", f"ارسال موفق: <b>{counts.get('sent', 0)}</b>", f"ناموفق: <b>{counts.get('failed', 0)}</b>", f"نامشخص: <b>{counts.get('unknown', 0)}</b>", f"در انتظار/در حال ارسال: {counts.get('pending', 0)+counts.get('sending', 0)}", "", "موفقیت یعنی Telegram درخواست ارسال را پذیرفته است؛ خوانده‌شدن پیام قابل تأیید نیست."]
    rows_kb = [[InlineKeyboardButton(text="📊 جزئیات", callback_data=f"admin:announce:v72:view:{announcement_id}")]]
    if announcement.event_id:
        rows_kb.append([InlineKeyboardButton(text="پنل مربوطه", callback_data=f"admin:event:announcements:{announcement.event_id}")])
    else:
        rows_kb.append([InlineKeyboardButton(text="مرکز اطلاع‌رسانی", callback_data="admin:announcements")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows_kb))


@router.callback_query(F.data.regexp(r"^admin:announce:v72:view:\d+$"))
async def unified_announcement_view(c: CallbackQuery, state: FSMContext):
    await state.clear()
    announcement_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        announcement = await session.get(AdminAnnouncement, announcement_id)
        if not announcement:
            return await c.answer("اطلاع‌رسانی پیدا نشد.", show_alert=True)
        deliveries = (await session.execute(select(AdminAnnouncementDelivery).where(AdminAnnouncementDelivery.announcement_id == announcement_id, AdminAnnouncementDelivery.status.in_(("failed", "unknown"))).order_by(AdminAnnouncementDelivery.id).limit(8))).scalars().all()
        counts_rows = (await session.execute(select(AdminAnnouncementDelivery.status, func.count(AdminAnnouncementDelivery.id)).where(AdminAnnouncementDelivery.announcement_id == announcement_id).group_by(AdminAnnouncementDelivery.status))).all()
        counts = {str(st): int(n) for st, n in counts_rows}
    if not await _announcement_authorized(c.from_user.id, announcement):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    admin = await _is_admin(c.from_user.id)
    lines = ["📊 <b>جزئیات اطلاع‌رسانی</b>", f"عملیات: #{announcement_id}", f"وضعیت: {escape(admin_status_display_label(announcement.status))}", f"نوع: {escape(_PURPOSE_LABELS.get(announcement.purpose, announcement.announcement_type))}", f"مخاطب هدف: {announcement.recipient_count}", f"موفق: {counts.get('sent', 0)} · ناموفق: {counts.get('failed', 0)} · نامشخص: {counts.get('unknown', 0)}", "", "<b>متن ثبت‌شده</b>", announcement.message_text]
    if admin and deliveries:
        lines += ["", "<b>چند تلاش ناموفق/نامشخص</b>"]
        lines += [f"• <code>{int(d.telegram_id)}</code> · {escape(admin_status_display_label(d.status))} · {escape((d.last_error or 'بدون جزئیات')[:100])}" for d in deliveries]
    elif not admin:
        lines += ["", "جزئیات هویت گیرندگان یا خطای هر شخص در سطح میزبان قابل مشاهده نیست."]
    rows = []
    if announcement.status == "preview":
        rows.append([InlineKeyboardButton(text="✅ تأیید و ارسال", callback_data=f"admin:announce:v72:send:{announcement_id}"), InlineKeyboardButton(text="✏️ ویرایش", callback_data=f"admin:announce:v72:edit:{announcement_id}")])
    if admin and counts.get("failed", 0) > 0 and announcement.status in {"partial", "completed", "failed"}:
        rows.append([InlineKeyboardButton(text=f"🔁 تلاش مجدد فقط برای {counts.get('failed', 0)} گیرندهٔ ناموفق", callback_data=f"admin:announce:v73:retry_prompt:{announcement_id}")])
    rows.append([InlineKeyboardButton(text="📋 تاریخچه", callback_data=f"admin:announce:v72:panel_history:{announcement.event_id}:0" if announcement.event_id else "admin:announce:v72:history:0")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v73:retry_prompt:\d+$"))
async def unified_announcement_retry_prompt(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("فقط مدیر می‌تواند ارسال‌های ناموفق را تکرار کند.", show_alert=True)
    announcement_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        announcement = await session.get(AdminAnnouncement, announcement_id)
        if not announcement or announcement.status not in {"partial", "completed", "failed"}:
            return await c.answer("این عملیات در وضعیت قابل تکرار نیست.", show_alert=True)
        failed = int(await session.scalar(select(func.count(AdminAnnouncementDelivery.id)).where(
            AdminAnnouncementDelivery.announcement_id == announcement_id, AdminAnnouncementDelivery.status == "failed"
        )) or 0)
        unknown = int(await session.scalar(select(func.count(AdminAnnouncementDelivery.id)).where(
            AdminAnnouncementDelivery.announcement_id == announcement_id, AdminAnnouncementDelivery.status == "unknown"
        )) or 0)
    if failed <= 0:
        return await c.answer("گیرندهٔ دارای نتیجهٔ قطعیِ ناموفق برای تلاش مجدد وجود ندارد.", show_alert=True)
    await c.message.edit_text(
        f"🔁 <b>تلاش مجدد پیام‌های ناموفق</b>\n\nعملیات: #{announcement_id}\n"
        f"فقط گیرندگان دارای وضعیت قطعی «ناموفق»: <b>{failed}</b>\n"
        f"ارسال‌های موفق دوباره ارسال نمی‌شوند. موارد با نتیجهٔ نامشخص نیز به‌منظور جلوگیری از پیام تکراری دست‌نخورده می‌مانند: {unknown}\n\n"
        "با تأیید، همان پیام ثبت‌شده فقط برای گیرندگان ناموفق دوباره ارسال می‌شود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأیید تلاش مجدد", callback_data=f"admin:announce:v73:retry_confirm:{announcement_id}")],
            [InlineKeyboardButton(text="❌ لغو", callback_data=f"admin:announce:v72:view:{announcement_id}")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v73:retry_confirm:\d+$"))
async def unified_announcement_retry_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("فقط مدیر می‌تواند ارسال‌های ناموفق را تکرار کند.", show_alert=True)
    announcement_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        announcement = (await session.execute(select(AdminAnnouncement).where(
            AdminAnnouncement.id == announcement_id
        ).with_for_update())).scalar_one_or_none()
        if not announcement or announcement.status not in {"partial", "completed", "failed"}:
            return await c.answer("این عملیات قبلاً آغاز شده یا دیگر قابل تکرار نیست.", show_alert=True)
        # Lock the durable operation row and touch only explicit failures. 'unknown'
        # can mean Telegram accepted a send but the result was lost, so retrying it
        # could create duplicates and is intentionally excluded.
        failed_rows = (await session.execute(select(AdminAnnouncementDelivery).where(
            AdminAnnouncementDelivery.announcement_id == announcement_id,
            AdminAnnouncementDelivery.status == "failed",
        ).with_for_update())).scalars().all()
        if not failed_rows:
            return await c.answer("گیرندهٔ ناموفق جدیدی برای ارسال مجدد وجود ندارد.", show_alert=True)
        for delivery in failed_rows:
            delivery.status = "pending"
            delivery.updated_at = utc_now_naive()
        announcement.status = "sending"
        announcement.started_at = utc_now_naive()
        announcement.completed_at = None
        announcement.failed_count = 0
        await _write_announcement_audit(
            session, actor_telegram_id=c.from_user.id, action="announcement_failed_recipients_retry_started",
            entity_id=announcement_id, details={"retry_count": len(failed_rows), "scope": "failed_only"},
        )
        await session.commit()
    await c.answer(f"تلاش مجدد برای {len(failed_rows)} گیرنده آغاز شد.")
    await c.message.edit_text("🔁 ارسال مجدد فقط برای گیرندگان ناموفق در حال انجام است…")
    await _process_unified_announcement(c.bot, announcement_id)
    await _render_announcement_result(c, announcement_id)


@router.callback_query(F.data.regexp(r"^admin:announce:v72:history:\d+$"))
async def unified_announcement_history(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    page = int((c.data or "").rsplit(":", 1)[1])
    await _render_announcement_history(c, page=page, event_id=None)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announce:v72:panel_history:\d+:\d+$"))
async def unified_panel_announcement_history(c: CallbackQuery):
    parts = (c.data or "").split(":")
    event_id, page = int(parts[4]), int(parts[5])
    authorized, is_admin_actor = await _authorized_event_actor(c.from_user.id, event_id)
    if not authorized:
        return await c.answer("اجازهٔ مشاهدهٔ این تاریخچه وجود ندارد.", show_alert=True)
    await _render_announcement_history(c, page=page, event_id=event_id, is_admin_actor=is_admin_actor)
    await c.answer()


async def _render_announcement_history(c: CallbackQuery, *, page: int, event_id: int | None, is_admin_actor: bool | None = None):
    async with SessionLocal() as session:
        stmt = select(AdminAnnouncement)
        if event_id is not None:
            stmt = stmt.where(AdminAnnouncement.event_id == int(event_id))
        total = int(await session.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0)
        pages = max(1, (total + ANNOUNCEMENT_PAGE_SIZE - 1) // ANNOUNCEMENT_PAGE_SIZE)
        page = min(max(0, int(page)), pages - 1)
        items = (await session.execute(stmt.order_by(AdminAnnouncement.created_at.desc(), AdminAnnouncement.id.desc()).offset(page * ANNOUNCEMENT_PAGE_SIZE).limit(ANNOUNCEMENT_PAGE_SIZE))).scalars().all()
        event = await session.get(Event, event_id) if event_id else None
    rows = []
    lines = ["🗂 <b>تاریخچه اطلاع‌رسانی</b>"]
    if event:
        lines.append(f"پنل: {escape(event.title)}")
    lines.append(f"عملیات ثبت‌شده: {total} · صفحه {page+1}/{pages}\n")
    for item in items:
        label = _PURPOSE_LABELS.get(item.purpose, item.announcement_type)
        lines.append(f"• #{item.id} · {escape(label)} · {escape(admin_status_display_label(item.status))} · موفق {item.sent_count}/{item.recipient_count} · {item.created_at.strftime('%Y-%m-%d %H:%M') if item.created_at else '—'}")
        rows.append([InlineKeyboardButton(text=f"جزئیات #{item.id} · {label}"[:64], callback_data=f"admin:announce:v72:view:{item.id}")])
    if not items:
        lines.append("هنوز تاریخچه‌ای برای این محدوده ثبت نشده است.")
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:announce:v72:panel_history:{event_id}:{page-1}" if event_id else f"admin:announce:v72:history:{page-1}"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:announce:v72:panel_history:{event_id}:{page+1}" if event_id else f"admin:announce:v72:history:{page+1}"))
    if nav: rows.append(nav)
    if event_id is not None:
        rows.append([InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌های پنل", callback_data=f"admin:event:announcements:{event_id}")])
    else:
        rows.append([InlineKeyboardButton(text="🔙 اطلاع‌رسانی‌ها", callback_data="admin:announcements")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
