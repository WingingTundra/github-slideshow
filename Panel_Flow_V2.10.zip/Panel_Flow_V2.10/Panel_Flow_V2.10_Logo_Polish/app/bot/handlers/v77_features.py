"""V77 community features with V78 reliability and workflow polish.

Past Panels, سرگرمی کوتاه, XP Shop, and free Lucky Draw remain backward-compatible. All content is text/URL only; سرگرمی کوتاه has no XP/progression calls. XP spending uses
XPAward as the only balance ledger, with idempotent award keys and persistent reservations.
"""
from __future__ import annotations

import json
import logging
import secrets
from datetime import datetime, timedelta
from html import escape
from urllib.parse import urlparse

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError

from app.bot.states import V77AdminStates
from app.bot.text_limits import limit_telegram_html
from app.config import settings
from app.db.models import (
    AdminAction, AppSetting, ArchivedPanelContent, Booking, DiscountCode, Event, EventStatus,
    LuckyDrawCampaign, LuckyDrawClaim, QuickFunActivity, QuickFunResponse,
    RewardIssue, Review, RegistrationStatus, ShopRequest, XPShopOffer, User, UserRole, XPAward,
)
from app.db.session import SessionLocal
from app.services.admin_audit import write_admin_action
from app.services.app_settings import get_setting, set_setting
from app.services.community import total_xp
from app.services.reward_notifications import notify_admins
from app.services.xp_shop import (
    SHOP_DEFAULT_COSTS, available_shop_xp, configured_shop_costs, reserved_shop_xp,
    shop_economy_summary, shop_request_status_label, shop_is_enabled, set_shop_enabled,
    list_shop_offers, shop_offer_available, shop_offer_by_id, shop_offer_usage, xp_economy_totals,
)
from app.time_utils import utc_now_naive
from app.display_utils import admin_status_display_label, status_display_label, truncate_display_text, volume_label, panel_detail_line

router = Router(name="v77-community-features")
logger = logging.getLogger(__name__)
PAGE_SIZE = 6
DRAW_DEFAULT_ODDS = {15: 60, 25: 25, 50: 12, 100: 3}


async def _is_admin(telegram_id: int) -> bool:
    """Delegate admin authorization to the canonical, uncached service."""
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(telegram_id)


def _kb(rows: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _json_dict(raw: str | None, default: dict | list):
    try:
        value = json.loads(raw or "")
        return value if isinstance(value, type(default)) else default
    except (TypeError, ValueError):
        return default


def _format_date(event: Event) -> str:
    return " – ".join(x for x in (event.event_day_label, event.event_date_label) if x and x != "—") or "تاریخ ثبت نشده"


def _safe_url(raw: str) -> str:
    """Validate syntax only; never fetch or follow a user-supplied URL."""
    value = str(raw or "").strip()
    if not value or len(value) > 1000 or any(ch.isspace() or ord(ch) < 32 for ch in value):
        raise ValueError("URL must be a compact absolute HTTP(S) URL")
    try:
        parsed = urlparse(value)
        # Accessing .port also forces urllib to reject malformed/non-numeric ports.
        port = parsed.port
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc or not parsed.hostname:
            raise ValueError("URL must be absolute HTTP(S)")
        if parsed.username or parsed.password:
            raise ValueError("Credential-bearing URLs are not supported")
        if port is not None and not (1 <= port <= 65535):
            raise ValueError("URL port is outside the valid range")
    except (ValueError, UnicodeError) as exc:
        raise ValueError("URL must be a valid absolute HTTP(S) URL without credentials") from exc
    return value


_V77_STATES = {
    V77AdminStates.archive_recap.state, V77AdminStates.archive_highlights.state,
    V77AdminStates.archive_tags.state, V77AdminStates.archive_links.state,
    V77AdminStates.quick_fun_payload.state, V77AdminStates.draw_label.state,
    V77AdminStates.draw_odds.state, V77AdminStates.shop_costs.state,
    V77AdminStates.shop_denial.state, V77AdminStates.shop_denial_confirm.state, V77AdminStates.reward_code.state,
    V77AdminStates.refund_reason.state, V77AdminStates.refund_confirm.state,
    V77AdminStates.shop_offer_title.state, V77AdminStates.shop_offer_percent.state,
    V77AdminStates.shop_offer_cost.state, V77AdminStates.shop_offer_description.state,
    V77AdminStates.shop_offer_limit.state, V77AdminStates.shop_offer_expires.state, V77AdminStates.shop_offer_edit.state,
}

async def _clear_v77_state(state: FSMContext | None) -> None:
    """Clear only an active V77 form when a V77 navigation callback leaves it."""
    if state is not None and await state.get_state() in _V77_STATES:
        await state.clear()


async def _can_start_v77_form(c: CallbackQuery, state: FSMContext) -> bool:
    """Do not overwrite another feature's active FSM when an admin opens V77 tools."""
    current = await state.get_state()
    if current and current not in _V77_STATES:
        await c.answer("فرایند دیگری در حال انجام است. ابتدا آن را تکمیل کنید یا /cancel بزنید.", show_alert=True)
        return False
    await _clear_v77_state(state)
    return True


async def _show(c: CallbackQuery, text: str, markup: InlineKeyboardMarkup | None = None, *, preview: bool = True):
    try:
        await c.message.edit_text(limit_telegram_html(text), reply_markup=markup, disable_web_page_preview=preview)
    except Exception as exc:
        if "message is not modified" not in str(exc).lower():
            raise
    await c.answer()


async def render_past_panels(target: Message | CallbackQuery, page: int = 0):
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(Event.id)).where(
            Event.archived.is_(True), Event.status == EventStatus.COMPLETED
        )) or 0)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        page = min(max(0, int(page)), pages - 1)
        events = (await session.execute(select(Event).where(
            Event.archived.is_(True), Event.status == EventStatus.COMPLETED
        ).order_by(Event.archived_at.desc().nullslast(), Event.updated_at.desc(), Event.id.desc())
          .offset(page * PAGE_SIZE).limit(PAGE_SIZE))).scalars().all()
    rows = [[InlineKeyboardButton(
        text=truncate_display_text(f"📚 {volume_label(e.volume)} · {(e.title or 'پنل')}", 64),
        callback_data=f"user:pastpanels:view:{int(e.id)}:{page}",
    )] for e in events]
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"user:pastpanels:page:{page-1}"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"user:pastpanels:page:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")])
    body = "📚 <b>پنل‌های گذشته</b>\n\nتاریخچهٔ پنل‌های برگزارشده را اینجا ببینید."
    if events:
        body += f"\nصفحهٔ {page+1} از {pages}"
    else:
        body += "\n\nدر حال حاضر پنل گذشته‌ای برای نمایش وجود ندارد."
    markup = _kb(rows)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(body, reply_markup=markup)
        await target.answer()
    else:
        await target.answer(body, reply_markup=markup)


@router.callback_query(F.data == "user:pastpanels")
async def past_panels_start(c: CallbackQuery):
    await render_past_panels(c, 0)


@router.callback_query(F.data.regexp(r"^user:pastpanels:page:\d+$"))
async def past_panels_page(c: CallbackQuery):
    try:
        page = max(0, int(c.data.rsplit(":", 1)[1]))
    except ValueError:
        return await c.answer("صفحه نامعتبر است.", show_alert=True)
    await render_past_panels(c, page)


@router.callback_query(F.data.regexp(r"^user:pastpanels:view:\d+:\d+$"))
async def past_panels_detail(c: CallbackQuery):
    try:
        _, _, _, eid_s, page_s = c.data.split(":")
        eid, page = int(eid_s), int(page_s)
    except (ValueError, TypeError):
        return await c.answer("شناسه پنل نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived or event.status != EventStatus.COMPLETED:
            return await c.answer("این پنل در آرشیو عمومی موجود نیست.", show_alert=True)
        content = (await session.execute(select(ArchivedPanelContent).where(
            ArchivedPanelContent.event_id == eid
        ))).scalar_one_or_none()
        viewer = (await session.execute(select(User).where(User.telegram_id == int(c.from_user.id)))).scalar_one_or_none()
        eligible_booking = None
        existing_review = None
        if viewer is not None and event.feedback_enabled:
            eligible_booking = (await session.execute(select(Booking).where(
                Booking.event_id == eid,
                Booking.booked_by_user_id == viewer.id,
                Booking.status == RegistrationStatus.CONFIRMED,
            ).order_by(Booking.created_at.desc()).limit(1))).scalar_one_or_none()
            if eligible_booking is not None:
                existing_review = (await session.execute(select(Review.id).where(
                    Review.event_id == eid, Review.user_id == viewer.id
                ).limit(1))).scalar_one_or_none()
    body = f"<b>📚 {escape(volume_label(event.volume))}</b>\n\n<b>{escape(event.title or 'پنل')}</b>\n"
    if event.description and event.description.strip():
        body += f"\n📝 <b>توضیحات</b>\n{escape(event.description.strip())}\n"
    body += "\n" + panel_detail_line("روز و تاریخ", escape(_format_date(event)), icon="📅")
    if event.language:
        body += "\n" + panel_detail_line("زبان", escape(event.language), icon="🌐")
    if event.venue:
        body += "\n" + panel_detail_line("مکان", escape(event.venue), icon="📍")
    if event.address:
        body += "\n\n" + panel_detail_line("آدرس", escape(event.address), icon="📌")
    if content and content.recap and content.recap.strip():
        body += f"\n\n💬 <b>جمع‌بندی</b>\n{escape(content.recap.strip())}"
    if content and content.highlights and content.highlights.strip():
        body += f"\n\n✨ <b>نکته‌های مهم گفت‌وگو</b>\n{escape(content.highlights.strip())}"
    tags = _json_dict(content.tags_json if content else None, [])
    if tags:
        body += "\n\n🏷 " + " · ".join(escape(str(tag)) for tag in tags[:10])
    rows = []
    for link in _json_dict(content.links_json if content else None, []):
        if not isinstance(link, dict):
            continue
        label, url = str(link.get("label") or "منبع تکمیلی")[:50], str(link.get("url") or "")
        try:
            _safe_url(url)
            rows.append([InlineKeyboardButton(text=label, url=url)])
        except ValueError:
            # Invalid historical URLs are hidden rather than rendered as active buttons.
            continue
    if eligible_booking is not None:
        if existing_review is None:
            rows.append([InlineKeyboardButton(text="📝 ثبت نظر برای این پنل", callback_data=f"user:review:event:{eid}")])
        else:
            body += "\n\n✅ نظر شما برای این پنل ثبت شده است."
    rows += [[InlineKeyboardButton(text="⬅️ بازگشت به آرشیو", callback_data=f"user:pastpanels:page:{max(0, page)}")],
             [InlineKeyboardButton(text="🏠 منوی اصلی", callback_data="user:home")]]
    await _show(c, body, _kb(rows))


# ------------------------- Admin: Past Panels content -------------------------

@router.callback_query(F.data == "admin:v77:home")
async def v77_admin_home(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    await _clear_v77_state(state)
    await _show(c, "<b>🧰 ابزارهای تکمیلی</b>\n\nمدیریت محتوای آرشیو، XP شاپ، Giveaways و صدور یا تحویل جایزه‌ها.", _kb([
        [InlineKeyboardButton(text="📚 مدیریت محتوای پنل‌های گذشته", callback_data="admin:v77:archive:list:0")],
        [InlineKeyboardButton(text="🛍 درخواست‌های XP شاپ", callback_data="admin:v77:shop:queue:0")],
        [InlineKeyboardButton(text="🎁 مدیریت Giveaways", callback_data="admin:v77:draw:list")],
        [InlineKeyboardButton(text="🎟 صدور و تحویل هدیه‌ها", callback_data="admin:v77:rewards:queue:0")],
        [InlineKeyboardButton(text="🔔 تلاش دوباره برای هشدارها", callback_data="admin:v78:notifications:retry")],
        [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
    ]))


@router.callback_query(F.data == "admin:v78:notifications:retry")
async def admin_v78_retry_notifications(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    async with SessionLocal() as session:
        alert_states=("pending","failed","not_attempted")
        shops=(await session.execute(select(ShopRequest).where(
            ShopRequest.status=="pending",ShopRequest.admin_notification_status.in_(alert_states)
        ).order_by(ShopRequest.created_at.asc(),ShopRequest.id.asc()).limit(30))).scalars().all()
        issues=(await session.execute(select(RewardIssue).where(
            RewardIssue.status.in_(("awaiting_code","ready_to_deliver","delivery_failed","delivery_uncertain","sending")),
            RewardIssue.admin_notification_status.in_(alert_states)
        ).order_by(RewardIssue.created_at.asc(),RewardIssue.id.asc()).limit(30))).scalars().all()
    candidates=[(x.created_at,"shop",x) for x in shops]+[(x.created_at,"reward",x) for x in issues]
    candidates.sort(key=lambda x:(x[0],x[1],int(x[2].id)))
    candidates=candidates[:25]
    sent=failed=0
    for _,kind,item in candidates:
        if kind=="shop":
            message=(f"🛍 <b>درخواست XP شاپ #{item.id}</b>\nتخفیف: {item.discount_percent}% · امتیاز رزروشده: {item.xp_cost}\n"
                     f"شناسهٔ تلگرام دریافت‌کننده: <code>{item.telegram_id}</code> · وضعیت فعلی: {escape(admin_status_display_label(item.status))}")
            markup=_kb([[InlineKeyboardButton(text="مشاهدهٔ درخواست",callback_data=f"admin:v77:shop:view:{item.id}")],
                        [InlineKeyboardButton(text="درخواست‌های در انتظار فروشگاه",callback_data="admin:v77:shop:queue:0")]])
            outcome=await notify_admins(c.bot,ShopRequest,int(item.id),message,markup)
        else:
            message=(f"🎟 <b>پروندهٔ صدور هدیه #{item.id}</b>\nمنبع: {escape(item.source_type)} #{item.source_id} · {item.discount_percent}%\n"
                     f"شناسهٔ تلگرام دریافت‌کننده: <code>{item.telegram_id}</code> · وضعیت: {escape(admin_status_display_label(item.status))}")
            markup=_kb([[InlineKeyboardButton(text="مشاهدهٔ پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{item.id}")],
                        [InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]])
            outcome=await notify_admins(c.bot,RewardIssue,int(item.id),message,markup)
        if outcome["sent"]: sent+=1
        else: failed+=1
    remaining=0
    async with SessionLocal() as session:
        alert_states=("pending","failed","not_attempted")
        remaining=(int(await session.scalar(select(func.count(ShopRequest.id)).where(ShopRequest.status=="pending",ShopRequest.admin_notification_status.in_(alert_states))) or 0)
                   +int(await session.scalar(select(func.count(RewardIssue.id)).where(RewardIssue.status.in_(("awaiting_code","ready_to_deliver","delivery_failed","delivery_uncertain","sending")),RewardIssue.admin_notification_status.in_(alert_states))) or 0))
    await _show(c,f"<b>تلاش دوباره برای اطلاع‌رسانی به مدیران</b>\nارسال‌شده به دست‌کم یک مدیر: {sent}\nهمچنان ناموفق: {failed}\nاطلاع‌رسانی‌های پردازش‌نشده یا قابل تلاش مجدد: {remaining}\n\nفقط وضعیت اطلاع‌رسانی به‌روزرسانی شد؛ پرونده‌های فروشگاه و هدایا تغییری نکردند.",_kb([[InlineKeyboardButton(text="ابزارهای تکمیلی",callback_data="admin:v77:home")]]))


@router.callback_query(F.data == "admin:v78:shop:economy")
async def admin_v78_shop_economy(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    async with SessionLocal() as session:
        offers = await list_shop_offers(session, active_only=True)
        xp_q=select(XPAward.telegram_id.label("tg"),func.coalesce(func.sum(XPAward.points),0).label("xp")).group_by(XPAward.telegram_id).subquery()
        reserve_q=select(ShopRequest.telegram_id.label("tg"),func.coalesce(func.sum(ShopRequest.xp_cost),0).label("reserved")).where(ShopRequest.status=="pending").group_by(ShopRequest.telegram_id).subquery()
        rows=(await session.execute(select(
            User.telegram_id,func.coalesce(xp_q.c.xp,0).label("xp"),func.coalesce(reserve_q.c.reserved,0).label("reserved")
        ).outerjoin(xp_q,xp_q.c.tg==User.telegram_id).outerjoin(reserve_q,reserve_q.c.tg==User.telegram_id))).all()
        economy = await xp_economy_totals(session)
    balances=[available_shop_xp(int(row.xp or 0),int(row.reserved or 0)) for row in rows]
    total_users=len(balances)
    text=("<b>📊 گزارش اقتصاد XP و فروشگاه</b>\n\n"
          f"کل XP مثبت ثبت‌شده: <b>{economy['total_earned']}</b>\n"
          f"کل XP مصرف‌شده در فروشگاه: <b>{economy['total_spent']}</b>\n"
          f"اصلاحات دستی ثبت‌شده: <b>{economy['manual_adjustments']}</b>\n"
          f"مجموع خالص XP در دفترکل: <b>{economy['net_xp']}</b>\n"
          f"XP رزروشده در درخواست‌های در انتظار: <b>{economy['reserved_xp']}</b>\n"
          f"XP بازپرداخت‌شده: <b>{economy['refunded_xp']}</b>\n\n"
          f"درخواست‌های در انتظار: {economy['pending_requests']}\n"
          f"پاداش‌های تأییدشده: {economy['approved_rewards']}\n"
          f"پاداش‌های تحویل‌شده: {economy['delivered_rewards']}\n\n"
          f"کاربران ثبت‌نام‌شده: {total_users} · میانهٔ XP قابل استفاده: {int(__import__('statistics').median(balances)) if balances else 0}\n"
          "این گزارش فقط آمار تجمیعی را نمایش می‌دهد و شامل شناسه یا موجودی افراد نیست.")
    if offers:
        text += "\n\n<b>کاربرانی که توان دریافت هر پیشنهاد فعال را دارند</b>"
        for offer in offers:
            affordable=sum(1 for balance in balances if balance >= int(offer.xp_cost))
            share=(100.0*affordable/total_users) if total_users else 0.0
            cap=f" · سقف {int(offer.usage_limit)}" if offer.usage_limit is not None else ""
            text+=f"\n• {escape(offer.title)} · {int(offer.discount_percent)}٪ · {int(offer.xp_cost)} XP{cap}: {affordable}/{total_users} ({share:.1f}٪)"
    else:
        text += "\n\nپیشنهاد فعال برای محاسبهٔ توان خرید وجود ندارد."
    text += "\n\nقیمت‌ها خودکار تغییر نمی‌کنند؛ درخواست‌های قبلی هزینه و درصد ثبت‌شدهٔ خود را حفظ می‌کنند."
    await _show(c,text,_kb([[InlineKeyboardButton(text="🛍 مدیریت فروشگاه و پیشنهادها",callback_data="admin:v77:shop:manage")],
                            [InlineKeyboardButton(text="درخواست‌های XP شاپ",callback_data="admin:v77:shop:queue:0")],
                            [InlineKeyboardButton(text="ابزارهای تکمیلی",callback_data="admin:v77:home")]]))


async def _render_admin_archive_list(c: CallbackQuery, page: int = 0):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(Event.id)).where(
            Event.archived.is_(True), Event.status == EventStatus.COMPLETED
        )) or 0)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        page = min(max(0, page), pages-1)
        events = (await session.execute(select(Event).where(
            Event.archived.is_(True), Event.status == EventStatus.COMPLETED
        ).order_by(Event.archived_at.desc().nullslast(), Event.id.desc()).offset(page*PAGE_SIZE).limit(PAGE_SIZE))).scalars().all()
    rows = [[InlineKeyboardButton(text=truncate_display_text(f"{volume_label(e.volume)} · {(e.title or 'پنل')}", 64), callback_data=f"admin:v77:archive:view:{e.id}:{page}")] for e in events]
    nav = []
    if page > 0: nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:v77:archive:list:{page-1}"))
    if page + 1 < pages: nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:v77:archive:list:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 ابزارهای جامعه", callback_data="admin:v77:home")])
    text = f"<b>مدیریت محتوای پنل‌های گذشته</b> · {total} پنل تکمیل‌شدهٔ آرشیوشده\nپنلی را برای ویرایش متن و پیوندهای آن انتخاب کنید."
    if not events: text += "\n\nموردی در آرشیو برای ویرایش وجود ندارد."
    await _show(c, text, _kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:archive:list:\d+$"))
async def admin_v77_archive_list(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try: page = int(c.data.rsplit(":", 1)[1])
    except ValueError: return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await _clear_v77_state(state)
    await _render_admin_archive_list(c, page)


async def _archive_content(session, event_id: int):
    return (await session.execute(select(ArchivedPanelContent).where(ArchivedPanelContent.event_id == event_id))).scalar_one_or_none()


@router.callback_query(F.data.regexp(r"^admin:v77:archive:view:\d+:\d+$"))
async def admin_v77_archive_view(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try: _, _, _, _, eid_s, page_s = c.data.split(":"); eid, page = int(eid_s), int(page_s)
    except (ValueError, TypeError): return await c.answer("شناسهٔ پنل معتبر نیست.", show_alert=True)
    await _clear_v77_state(state)
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived or event.status != EventStatus.COMPLETED:
            return await c.answer("فقط پنل‌های تکمیل‌شدهٔ آرشیوشده قابل ویرایش هستند.", show_alert=True)
        row = await _archive_content(session, eid)
    text = f"<b>پنل گذشته · {escape(str(event.volume))} · {escape(event.title)}</b>\n\n"
    text += f"<b>تاریخ:</b> {escape(_format_date(event))}\n\n"
    text += f"<b>خلاصه</b>\n{escape(row.recap or '—') if row else '—'}\n\n<b>نکات برجسته</b>\n{escape(row.highlights or '—') if row else '—'}\n\n"
    text += f"<b>برچسب‌ها:</b> {escape(', '.join(_json_dict(row.tags_json if row else None, [])) or '—')}\n"
    text += f"<b>پیوندهای بیرونی:</b> {len(_json_dict(row.links_json if row else None, [])) if row else 0}"
    rows = [
        [InlineKeyboardButton(text="ویرایش خلاصه", callback_data=f"admin:v77:archive:edit:{eid}:recap"), InlineKeyboardButton(text="ویرایش نکات برجسته", callback_data=f"admin:v77:archive:edit:{eid}:highlights")],
        [InlineKeyboardButton(text="ویرایش برچسب‌ها", callback_data=f"admin:v77:archive:edit:{eid}:tags"), InlineKeyboardButton(text="ویرایش پیوندها", callback_data=f"admin:v77:archive:edit:{eid}:links")],
        [InlineKeyboardButton(text="👁 پیش‌نمایش عمومی", callback_data=f"admin:v77:archive:preview:{eid}:{page}")],
        [InlineKeyboardButton(text="⬅️ فهرست آرشیو", callback_data=f"admin:v77:archive:list:{page}")],
    ]
    await _show(c, text, _kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:archive:preview:\d+:\d+$"))
async def admin_v77_archive_preview(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try: _, _, _, _, eid_s, page_s = c.data.split(":"); eid, page = int(eid_s), int(page_s)
    except (ValueError, TypeError): return await c.answer("شناسهٔ پنل معتبر نیست.", show_alert=True)
    await _clear_v77_state(state)
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        row = await _archive_content(session, eid)
    if not event or not event.archived or event.status != EventStatus.COMPLETED:
        return await c.answer("محتوای آرشیو در دسترس نیست.", show_alert=True)
    body = f"<b>پیش‌نمایش · {escape(event.title)}</b>\n\n{escape(event.description or '')}\n\n" + panel_detail_line("روز و تاریخ", escape(_format_date(event)), icon="📅")
    if row and row.recap: body += f"\n\n<b>خلاصه</b>\n{escape(row.recap)}"
    if row and row.highlights: body += f"\n\n<b>نکات برجسته</b>\n{escape(row.highlights)}"
    if row and _json_dict(row.tags_json, []): body += "\n\n🏷 " + escape(" · ".join(_json_dict(row.tags_json, [])))
    rows = [[InlineKeyboardButton(text=str(link.get("label") or "پیوند")[:50], url=link["url"])] for link in _json_dict(row.links_json if row else None, []) if isinstance(link, dict) and link.get("url") and _safe_url_or_none(str(link["url"]))]
    rows.append([InlineKeyboardButton(text="✏️ ویرایش محتوا", callback_data=f"admin:v77:archive:view:{eid}:{page}")])
    await _show(c, body, _kb(rows))


def _safe_url_or_none(value: str) -> bool:
    try: _safe_url(value); return True
    except ValueError: return False


@router.callback_query(F.data.regexp(r"^admin:v77:archive:edit:\d+:(recap|highlights|tags|links)$"))
async def admin_v77_archive_edit(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _can_start_v77_form(c, state): return
    try: _, _, _, _, eid_s, field = c.data.split(":"); eid = int(eid_s)
    except (ValueError, TypeError): return await c.answer("پنل یا فیلد انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived or event.status != EventStatus.COMPLETED:
            return await c.answer("فقط پنل‌های تکمیل‌شدهٔ آرشیوشده قابل ویرایش هستند.", show_alert=True)
    state_map = {"recap": V77AdminStates.archive_recap, "highlights": V77AdminStates.archive_highlights, "tags": V77AdminStates.archive_tags, "links": V77AdminStates.archive_links}
    prompts = {
        "recap": "خلاصهٔ کوتاهی از پنل بفرستید (حداکثر ۲٬۰۰۰ نویسه). برای حذف آن /clear را بفرستید.",
        "highlights": "نکات برجستهٔ گفت‌وگو را بفرستید (حداکثر ۲٬۰۰۰ نویسه). برای حذف آن‌ها /clear را بفرستید.",
        "tags": "حداکثر ۱۰ برچسب را با ویرگول از هم جدا کنید؛ طول هرکدام حداکثر ۴۰ نویسه باشد. برای حذف برچسب‌ها /clear را بفرستید.",
        "links": "هر پیوند را در یک خط و با الگوی عنوان | https://example.org بفرستید. برای حذف همهٔ پیوندها پیام خالی یا /clear بفرستید. فقط پیوندهای HTTP(S) پذیرفته می‌شوند و مقصد آن‌ها دریافت نمی‌شود.",
    }
    await state.update_data(v77_event_id=eid, v77_archive_field=field)
    await state.set_state(state_map[field])
    await c.message.edit_text(f"{escape(event.title)}\n\n{prompts[field]}", reply_markup=_kb([[InlineKeyboardButton(text="انصراف", callback_data=f"admin:v77:archive:view:{eid}:0")]]))
    await c.answer()


@router.message(V77AdminStates.archive_recap)
@router.message(V77AdminStates.archive_highlights)
@router.message(V77AdminStates.archive_tags)
@router.message(V77AdminStates.archive_links)
async def admin_v77_archive_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    data = await state.get_data(); eid = int(data.get("v77_event_id") or 0); field = str(data.get("v77_archive_field") or "")
    raw = (message.text or "").strip()
    if raw.lower() in {"/cancel", "cancel"}:
        await state.clear(); return await message.answer("ویرایش لغو شد.", reply_markup=_kb([[InlineKeyboardButton(text="ابزارهای تکمیلی", callback_data="admin:v77:home")]]))
    try:
        if field in {"recap", "highlights"}:
            if raw.lower() == "/clear": value = None
            elif len(raw) > 2000: raise ValueError("Text is limited to 2,000 characters.")
            else: value = raw or None
        elif field == "tags":
            value = [] if raw.lower() == "/clear" or not raw else list(dict.fromkeys(x.strip() for x in raw.split(",") if x.strip()))
            if len(value) > 10 or any(len(x) > 40 for x in value): raise ValueError("Use at most 10 tags, each 40 characters or fewer.")
        elif field == "links":
            value = []
            if raw.lower() != "/clear" and raw:
                for line in raw.splitlines():
                    if "|" not in line: raise ValueError("Each line must be Label | https://example.org")
                    label, url = (part.strip() for part in line.split("|", 1))
                    if not label or len(label) > 50: raise ValueError("Labels must be 1–50 characters.")
                    value.append({"label": label, "url": _safe_url(url)})
                if len(value) > 5: raise ValueError("At most five links are allowed.")
        else: raise ValueError("Unknown field.")
    except ValueError as exc:
        return await message.answer(str(exc))
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived or event.status != EventStatus.COMPLETED:
            await state.clear(); return await message.answer("این پنل دیگر در آرشیوِ قابل ویرایش قرار ندارد.")
        row = await _archive_content(session, eid)
        if row is None:
            row = ArchivedPanelContent(event_id=eid); session.add(row); await session.flush()
        if field in {"recap", "highlights"}: setattr(row, field, value)
        elif field == "tags": row.tags_json = json.dumps(value, ensure_ascii=False)
        elif field == "links": row.links_json = json.dumps(value, ensure_ascii=False)
        row.updated_by_telegram_id = int(message.from_user.id); row.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=message.from_user.id, action="archived_panel_content_updated", entity_type="event", entity_id=eid, details={"field": field, "item_count": len(value) if isinstance(value, list) else None})
        await session.commit()
        title = event.title
    await state.clear()
    await message.answer(f"✅ ذخیره شد. محتوای عمومی آرشیو برای {escape(title)}.", reply_markup=_kb([[InlineKeyboardButton(text="ویرایش محتوای پنل", callback_data=f"admin:v77:archive:view:{eid}:0")], [InlineKeyboardButton(text="ابزارهای تکمیلی", callback_data="admin:v77:home")]]))

# ------------------------- سرگرمی کوتاه (no progression effects) -------------------------

async def _quick_fun_menu(c: CallbackQuery):
    await _show(c, "<b>🎲 سرگرمی کوتاه</b>\n\nسرگرمی‌های کوتاه و متنی؛ فعالیت‌های این بخش هیچ XP، نشان، زنجیرهٔ مشارکت یا امتیاز رتبه‌بندی ایجاد نمی‌کنند.", _kb([
        [InlineKeyboardButton(text="🧠 آزمون کوتاه", callback_data="community:quickfun:kind:quiz")],
        [InlineKeyboardButton(text="🤔 دو راهی", callback_data="community:quickfun:kind:wyr")],
        [InlineKeyboardButton(text="🧩 Riddles", callback_data="community:quickfun:kind:riddle")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")],
    ]))


@router.callback_query(F.data == "community:quickfun")
async def quick_fun_home(c: CallbackQuery):
    await _quick_fun_menu(c)


@router.callback_query(F.data.regexp(r"^community:quickfun:kind:(quiz|wyr|riddle)(?::\d+)?$"))
async def quick_fun_list(c: CallbackQuery):
    parts = c.data.split(":")
    kind = parts[3]
    try: page = max(0, int(parts[4])) if len(parts) > 4 else 0
    except ValueError: return await c.answer("صفحه در دسترس نیست.", show_alert=True)
    labels = {"quiz": "آزمون کوتاه", "wyr": "دو راهی", "riddle": "Riddles"}
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(QuickFunActivity.id)).where(
            QuickFunActivity.kind == kind, QuickFunActivity.status == "published"
        )) or 0)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        page = min(page, pages - 1)
        rows_db = (await session.execute(select(QuickFunActivity).where(
            QuickFunActivity.kind == kind, QuickFunActivity.status == "published"
        ).order_by(QuickFunActivity.created_at.desc(), QuickFunActivity.id.desc())
         .offset(page * PAGE_SIZE).limit(PAGE_SIZE))).scalars().all()
    rows = [[InlineKeyboardButton(text=(x.title[:52] or labels[kind]), callback_data=f"community:quickfun:open:{x.id}")] for x in rows_db]
    nav = []
    if page > 0: nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"community:quickfun:kind:{kind}:{page-1}"))
    if page + 1 < pages: nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"community:quickfun:kind:{kind}:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 سرگرمی کوتاه", callback_data="community:quickfun")])
    text = f"<b>{labels[kind]}</b>\n\nSelect an activity."
    if total: text += f"\nPage {page+1} of {pages}."
    if not rows_db: text += "\n\nفعلاً محتوای منتشرشده‌ای در این بخش نیست."
    await _show(c, text, _kb(rows))


@router.callback_query(F.data.regexp(r"^community:quickfun:open:\d+$"))
async def quick_fun_open(c: CallbackQuery):
    try: aid = int(c.data.rsplit(":", 1)[1])
    except ValueError: return await c.answer("فعالیت در دسترس نیست.", show_alert=True)
    await _render_quick_fun_activity(c, aid)


async def _render_quick_fun_activity(c: CallbackQuery, aid: int) -> None:
    async with SessionLocal() as session:
        activity = await session.get(QuickFunActivity, aid, with_for_update=True)
        if not activity or activity.status != "published":
            return await c.answer("این فعالیت دیگر فعال نیست.", show_alert=True)
        prior = (await session.execute(select(QuickFunResponse).where(
            QuickFunResponse.activity_id == aid, QuickFunResponse.telegram_id == c.from_user.id
        ))).scalar_one_or_none()
        counts = (await session.execute(select(QuickFunResponse.response_value, func.count(QuickFunResponse.id)).where(
            QuickFunResponse.activity_id == aid
        ).group_by(QuickFunResponse.response_value))).all() if activity.kind == "wyr" else []
    options = _json_dict(activity.options_json, [])
    text = f"<b>{escape(activity.title)}</b>\n\n{escape(activity.prompt)}"
    rows: list[list[InlineKeyboardButton]] = []
    if activity.kind == "quiz":
        if prior:
            selected = int(prior.response_value) if prior.response_value.isdigit() else -1
            correct = selected == int(activity.correct_option if activity.correct_option is not None else -99)
            text += "\n\n✅ پاسخ ثبت شده: " + ("درست" if correct else "نادرست") + " · هر فعالیت فقط یک پاسخ می‌پذیرد."
            if not correct and activity.correct_option is not None and 0 <= int(activity.correct_option) < len(options):
                text += f"\nپاسخ درست: <b>{escape(str(options[int(activity.correct_option)]))}</b>"
            if activity.explanation: text += "\n\n💡 " + escape(activity.explanation)
        else:
            text += "\n\nیک پاسخ انتخاب کنید؛ نتیجه بلافاصله نمایش داده می‌شود."
            for i, option in enumerate(options[:4]): rows.append([InlineKeyboardButton(text=str(option)[:60], callback_data=f"community:quickfun:answer:{aid}:{i}")])
    elif activity.kind == "wyr":
        if not prior:
            for i, option in enumerate(options[:2]): rows.append([InlineKeyboardButton(text=str(option)[:60], callback_data=f"community:quickfun:answer:{aid}:{i}")])
            text += "\n\nانتخاب شما خصوصی است؛ نتایج فقط به‌صورت تجمیعی نمایش داده می‌شوند."
        else:
            text += "\n\n✅ انتخاب شما ثبت شده است."
        total_votes = sum(int(count) for _, count in counts)
        # Do not present identifiable records or noisy percentages before there are enough responses.
        if total_votes >= 3:
            by_value = {str(key): int(value) for key, value in counts}
            text += f"\n\n<b>نتایج تجمیعی ({total_votes} پاسخ)</b>\n"
            for i, option in enumerate(options[:2]):
                count = by_value.get(str(i), 0); pct = round(100 * count / total_votes)
                text += f"{escape(str(option))}: {count} ({pct}%)\n"
    else:  # riddle: reveal configured answer; never pretend to grade an uncollected guess.
        if not prior:
            rows.append([InlineKeyboardButton(text="💡 نمایش پاسخ", callback_data=f"community:quickfun:answer:{aid}:reveal")])
            text += "\n\nاین معما پاسخ متنی دریافت نمی‌کند؛ دکمه، پاسخ ثبت‌شده را نشان می‌دهد."
        else:
            text += f"\n\n<b>پاسخ</b>\n{escape(activity.answer_text or 'پاسخی ثبت نشده است.')}"
            if activity.explanation: text += "\n\n💡 " + escape(activity.explanation)
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به سرگرمی کوتاه", callback_data=f"community:quickfun:kind:{activity.kind}")])
    await _show(c, text, _kb(rows))


@router.callback_query(F.data.regexp(r"^community:quickfun:answer:\d+:(\d+|reveal)$"))
async def quick_fun_answer(c: CallbackQuery):
    try:
        parts = c.data.split(":"); aid = int(parts[3]); choice = parts[4]
    except (ValueError, IndexError): return await c.answer("پاسخ نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        activity = await session.get(QuickFunActivity, aid, with_for_update=True)
        if not activity or activity.status != "published":
            return await c.answer("این فعالیت دیگر فعال نیست.", show_alert=True)
        prior = (await session.execute(select(QuickFunResponse).where(
            QuickFunResponse.activity_id == aid, QuickFunResponse.telegram_id == c.from_user.id
        ))).scalar_one_or_none()
        options = _json_dict(activity.options_json, [])
        if activity.kind == "riddle":
            if choice != "reveal": return await c.answer("پاسخ نامعتبر است.", show_alert=True)
            response_value = "reveal"
        else:
            if not choice.isdigit() or not 0 <= int(choice) < len(options):
                return await c.answer("گزینه نامعتبر است.", show_alert=True)
            response_value = choice
        if prior is None:
            try:
                async with session.begin_nested():
                    session.add(QuickFunResponse(activity_id=aid, telegram_id=c.from_user.id, response_value=response_value))
                    await session.flush()
                await session.commit()
            except IntegrityError:
                await session.rollback()
                return await c.answer("پاسخ قبلاً ثبت شده است.", show_alert=True)
        else:
            # Reopening a riddle may reveal its answer again; all other submissions stay final.
            if activity.kind != "riddle":
                return await c.answer("پاسخ شما قبلاً ثبت شده است.", show_alert=True)
    # Re-render the exact persisted state; no XP/award services are invoked here.
    return await _render_quick_fun_activity(c, aid)


def _parse_quickfun_payload(raw: str) -> dict:
    parts = [x.strip() for x in raw.split("|")]
    if not parts or parts[0].lower() not in {"quiz", "wyr", "riddle"}:
        raise ValueError("Use quiz | Title | Question | options separated by semicolons | correct option number | optional explanation; or wyr | Title | Question | option A | option B; or riddle | Title | Riddle | Answer | optional explanation.")
    kind = parts[0].lower()
    if kind == "quiz":
        if len(parts) not in {5, 6}: raise ValueError("Quiz format needs 5 or 6 fields.")
        title, prompt = parts[1], parts[2]; options = [x.strip() for x in parts[3].split(";") if x.strip()]
        if not 2 <= len(options) <= 4: raise ValueError("Quiz needs 2–4 semicolon-separated options.")
        try: correct = int(parts[4]) - 1
        except ValueError: raise ValueError("Correct option must be a number starting from 1.")
        if not 0 <= correct < len(options): raise ValueError("Correct option is outside the available options.")
        answer = None; explanation = parts[5] if len(parts) == 6 and parts[5] else None
    elif kind == "wyr":
        if len(parts) != 5: raise ValueError("Would You Rather format needs exactly 5 fields.")
        title, prompt = parts[1], parts[2]; options = parts[3:5]; correct = None; answer = None; explanation = None
    else:
        if len(parts) not in {4, 5}: raise ValueError("Riddle format needs 4 or 5 fields.")
        title, prompt = parts[1], parts[2]; options = []; correct = None; answer = parts[3]; explanation = parts[4] if len(parts) == 5 and parts[4] else None
    if not title or not prompt or len(title) > 180 or len(prompt) > 2000: raise ValueError("Title (1–180 chars) and prompt (1–2,000 chars) are required.")
    if any(len(x) > 250 for x in options): raise ValueError("Options are limited to 250 characters each.")
    if answer is not None and (not answer or len(answer) > 1000): raise ValueError("Riddle answer is required (up to 1,000 chars).")
    if explanation and len(explanation) > 1000: raise ValueError("Explanation is limited to 1,000 characters.")
    return {"kind": kind, "title": title, "prompt": prompt, "options_json": json.dumps(options, ensure_ascii=False), "correct_option": correct, "answer_text": answer, "explanation": explanation}


@router.callback_query(F.data.regexp(r"^admin:v77:fun:list:\d+$"))
async def admin_v77_fun_list(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _clear_v77_state(state)
    page = max(0, int(c.data.rsplit(":",1)[1])); size = PAGE_SIZE
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(QuickFunActivity.id))) or 0)
        pages = max(1, (total+size-1)//size); page = min(page,pages-1)
        items = (await session.execute(select(QuickFunActivity).order_by(QuickFunActivity.created_at.desc(), QuickFunActivity.id.desc()).offset(page*size).limit(size))).scalars().all()
    rows = [[InlineKeyboardButton(text=truncate_display_text(f"{admin_status_display_label(x.status)} · {admin_status_display_label(x.kind)} · {x.title}", 64), callback_data=f"admin:v77:fun:view:{x.id}")] for x in items]
    rows.append([InlineKeyboardButton(text="➕ فعالیت سرگرمی تازه", callback_data="admin:v77:fun:new")])
    nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️ قبلی",callback_data=f"admin:v77:fun:list:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="بعدی ➡️",callback_data=f"admin:v77:fun:list:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="ابزارهای تکمیلی",callback_data="admin:v77:home")])
    await _show(c,f"<b>مدیریت سرگرمی‌های کوتاه</b> · {total} مورد ذخیره‌شده\nمحتوای پیش‌نویس برای کاربران نمایش داده نمی‌شود.",_kb(rows))


@router.callback_query(F.data == "admin:v77:fun:new")
async def admin_v77_fun_new(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _can_start_v77_form(c, state): return
    await state.update_data(v77_fun_id=0); await state.set_state(V77AdminStates.quick_fun_payload)
    await c.message.edit_text("<b>ایجاد پیش‌نویس سرگرمی کوتاه</b>\n\nمحتوا را در یک خط و مطابق یکی از الگوهای زیر بفرستید. مقادیر انگلیسیِ ابتدای هر الگو، نوع فعالیت هستند و باید بدون تغییر وارد شوند.\n<code>quiz | Title | Question | Option A;Option B;Option C | correct option number (starting at 1) | optional explanation</code>\n<code>wyr | Title | Question | Option A | Option B</code>\n<code>riddle | Title | Riddle | Answer | optional explanation</code>\n\nاین فعالیت‌ها XP یا امتیاز پیشرفت ایجاد نمی‌کنند.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data="admin:v77:fun:list:0")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:v77:fun:edit:\d+$"))
async def admin_v77_fun_edit(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _can_start_v77_form(c, state): return
    aid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        item=await session.get(QuickFunActivity,aid)
        if not item: return await c.answer("فعالیت پیدا نشد.",show_alert=True)
        responses=int(await session.scalar(select(func.count(QuickFunResponse.id)).where(QuickFunResponse.activity_id==aid)) or 0)
    if responses:
        return await c.answer("برای این فعالیت پاسخ ثبت شده است. آن را به‌صورت پیش‌نویس تازه تکثیر کنید؛ رأی‌ها و نتایج قبلی بدون تغییر می‌مانند.",show_alert=True)
    await state.update_data(v77_fun_id=aid); await state.set_state(V77AdminStates.quick_fun_payload)
    await c.message.edit_text("محتوای اصلاح‌شده را با همان الگو ارسال کنید. هنوز پاسخی برای این مورد ثبت نشده است؛ اگر پیش از ذخیره پاسخ تازه‌ای ثبت شود، برای حفظ سوابق امکان ویرایش وجود نخواهد داشت.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:fun:view:{aid}")]]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:v77:fun:duplicate:\d+$"))
async def admin_v77_fun_duplicate(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _clear_v77_state(state)
    aid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        source=await session.get(QuickFunActivity,aid,with_for_update=True)
        if not source: return await c.answer("فعالیت پیدا نشد.",show_alert=True)
        response_count=int(await session.scalar(select(func.count(QuickFunResponse.id)).where(QuickFunResponse.activity_id==aid)) or 0)
        title=(source.title[:165] + " (new version)")[:180]
        clone=QuickFunActivity(
            kind=source.kind,title=title,prompt=source.prompt,options_json=source.options_json,
            correct_option=source.correct_option,answer_text=source.answer_text,explanation=source.explanation,
            status="draft",created_by_telegram_id=int(c.from_user.id),updated_by_telegram_id=int(c.from_user.id),
        )
        session.add(clone); await session.flush(); new_id=int(clone.id)
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="quick_fun_activity_duplicated",entity_type="quick_fun_activity",entity_id=new_id,details={"source_activity_id":aid,"source_responses":response_count,"created_as":"draft"})
        await session.commit()
    await _show(c,f"✅ پیش‌نویس شمارهٔ {new_id} از فعالیت شمارهٔ {aid} ساخته شد. فعالیت اصلی و {response_count} پاسخ قبلی آن تغییر نکرده‌اند. پیش از انتشار، پیش‌نویس تازه را ویرایش و پیش‌نمایش کنید.",_kb([[InlineKeyboardButton(text="مشاهدهٔ پیش‌نویس تازه",callback_data=f"admin:v77:fun:view:{new_id}")],[InlineKeyboardButton(text="فهرست سرگرمی‌ها",callback_data="admin:v77:fun:list:0")]]))


@router.message(V77AdminStates.quick_fun_payload)
async def admin_v77_fun_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    if (message.text or "").strip().lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("ویرایش سرگرمی کوتاه لغو شد.", reply_markup=_kb([[InlineKeyboardButton(text="فهرست سرگرمی‌ها", callback_data="admin:v77:fun:list:0")]]))
    data=await state.get_data(); old_id=int(data.get("v77_fun_id") or 0)
    try: payload=_parse_quickfun_payload(message.text or "")
    except ValueError as exc: return await message.answer(str(exc))
    async with SessionLocal() as session:
        if old_id:
            item=(await session.execute(select(QuickFunActivity).where(QuickFunActivity.id==old_id).with_for_update())).scalar_one_or_none()
            if not item: await state.clear(); return await message.answer("فعالیت پیدا نشد.")
            response_count=int(await session.scalar(select(func.count(QuickFunResponse.id)).where(QuickFunResponse.activity_id==old_id)) or 0)
            if response_count:
                await state.clear()
                return await message.answer("برای این فعالیت پاسخ تازه ثبت شده و سوابق آن قفل شده است. از صفحهٔ فعالیت، گزینهٔ «تکثیر به‌صورت پیش‌نویس تازه» را انتخاب کنید؛ هیچ تغییری ذخیره نشد.",reply_markup=_kb([[InlineKeyboardButton(text="مشاهدهٔ فعالیت",callback_data=f"admin:v77:fun:view:{old_id}")]]))
            if item.kind != payload["kind"] and item.status == "published":
                return await message.answer("پیش از تغییر قالب، این فعالیت را غیرفعال کنید.")
            was_published = item.status == "published"
            item.kind=payload["kind"]
            for key,value in payload.items(): setattr(item,key,value)
            if was_published:
                item.status = "draft"
            item.updated_by_telegram_id=int(message.from_user.id); item.updated_at=utc_now_naive()
            item_id=item.id
        else:
            item=QuickFunActivity(**payload,status="draft",created_by_telegram_id=int(message.from_user.id),updated_by_telegram_id=int(message.from_user.id))
            session.add(item); await session.flush(); item_id=item.id
        await write_admin_action(session,actor_telegram_id=message.from_user.id,action="quick_fun_content_saved",entity_type="quick_fun_activity",entity_id=int(item_id),details={"kind":payload["kind"],"status":item.status})
        await session.commit()
    await state.clear()
    await message.answer("✅ به‌صورت پیش‌نویس ذخیره شد." if not old_id else "✅ محتوا به‌روزرسانی شد. مورد منتشرشده برای بررسی دوباره به پیش‌نویس برگشت؛ پس از بازبینی، آن را دوباره پیش‌نمایش و منتشر کنید.",reply_markup=_kb([[InlineKeyboardButton(text="مشاهدهٔ فعالیت",callback_data=f"admin:v77:fun:view:{item_id}")],[InlineKeyboardButton(text="فهرست سرگرمی‌ها",callback_data="admin:v77:fun:list:0")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:fun:view:\d+$"))
async def admin_v77_fun_view(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _clear_v77_state(state)
    aid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        item=await session.get(QuickFunActivity,aid)
        if not item: return await c.answer("فعالیت پیدا نشد.",show_alert=True)
        count=int(await session.scalar(select(func.count(QuickFunResponse.id)).where(QuickFunResponse.activity_id==aid)) or 0)
        options=_json_dict(item.options_json,[])
    text=f"<b>{escape(item.title)}</b> · {admin_status_display_label(item.kind)} · {admin_status_display_label(item.status)}\n\n{escape(item.prompt)}"
    if options: text += "\n\n"+"\n".join(f"{i+1}. {escape(x)}" for i,x in enumerate(options))
    if item.kind=="quiz": text += f"\n\nگزینهٔ درست: {int(item.correct_option or 0)+1}"
    if item.kind=="riddle": text += f"\n\nپاسخ: {escape(item.answer_text or '')}"
    if item.explanation: text += f"\nتوضیح: {escape(item.explanation)}"
    text += f"\n\nتعداد مشارکت‌ها: {count}"
    if count:
        rows=[[InlineKeyboardButton(text="📄 تکثیر به‌صورت پیش‌نویس تازه",callback_data=f"admin:v77:fun:duplicate:{aid}")]]
    else:
        rows=[[InlineKeyboardButton(text="✏️ ویرایش محتوا",callback_data=f"admin:v77:fun:edit:{aid}")]]
    if item.status != "published": rows.append([InlineKeyboardButton(text="🚀 انتشار",callback_data=f"admin:v77:fun:publish:{aid}")])
    if item.status == "published": rows.append([InlineKeyboardButton(text="⛔ غیرفعال‌سازی",callback_data=f"admin:v77:fun:deactivate:{aid}")])
    if item.status == "inactive": rows.append([InlineKeyboardButton(text="🚀 انتشار دوباره",callback_data=f"admin:v77:fun:publish:{aid}")])
    rows += [[InlineKeyboardButton(text="پیش‌نمایش برای کاربر",callback_data=f"admin:v77:fun:preview:{aid}")],[InlineKeyboardButton(text="فهرست سرگرمی‌ها",callback_data="admin:v77:fun:list:0")]]
    await _show(c,text,_kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:fun:preview:\d+$"))
async def admin_v77_fun_preview(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _clear_v77_state(state)
    aid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session: item=await session.get(QuickFunActivity,aid)
    if not item: return await c.answer("فعالیت پیدا نشد.",show_alert=True)
    options=_json_dict(item.options_json,[])
    text=f"<b>پیش‌نمایش کاربر · {escape(item.title)}</b>\n\n{escape(item.prompt)}\n\nنوع: {escape(admin_status_display_label(item.kind))} · وضعیت: {escape(admin_status_display_label(item.status))}"
    if item.kind in {"quiz","wyr"} and options:
        text += "\n\n" + "\n".join(f"{i+1}. {escape(str(value))}" for i,value in enumerate(options))
    if item.kind == "riddle":
        text += "\n\nکاربران گزینهٔ «نمایش پاسخ» را می‌بینند و پاسخ آن‌ها نمره‌دهی نمی‌شود."
    text += "\n\n<b>کلید پاسخ (فقط مدیر)</b>"
    if item.kind == "quiz" and item.correct_option is not None and 0 <= item.correct_option < len(options):
        text += f"\nگزینهٔ درست: {item.correct_option+1} · {escape(str(options[item.correct_option]))}"
    elif item.kind == "riddle":
        text += f"\nپاسخ: {escape(item.answer_text or '—')}"
    else:
        text += "\nفعالیت دو راهی پاسخ درست ندارد."
    if item.explanation: text += "\nتوضیح: " + escape(item.explanation)
    text += "\n\nسرگرمی‌های کوتاه XP یا پاداش پیشرفت ایجاد نمی‌کنند."
    await _show(c,text,_kb([[InlineKeyboardButton(text="بازگشت به فعالیت",callback_data=f"admin:v77:fun:view:{aid}")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:fun:(publish|deactivate):\d+$"))
async def admin_v77_fun_set_status(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    action, aid_s = c.data.split(":")[-2:]; aid=int(aid_s)
    async with SessionLocal() as session:
        item=await session.get(QuickFunActivity,aid)
        count=int(await session.scalar(select(func.count(QuickFunResponse.id)).where(QuickFunResponse.activity_id==aid)) or 0) if item else 0
    if not item: return await c.answer("فعالیت پیدا نشد.",show_alert=True)
    if action=="publish":
        if item.status=="published": return await c.answer("این فعالیت هم‌اکنون منتشر شده است.",show_alert=True)
        options=_json_dict(item.options_json,[])
        if not item.title.strip() or not item.prompt.strip(): return await c.answer("محتوای فعالیت کامل نیست.",show_alert=True)
        if item.kind in {"quiz","wyr"} and len(options)<2: return await c.answer("گزینه‌ها وارد نشده‌اند.",show_alert=True)
        if item.kind=="quiz" and (item.correct_option is None or not 0<=item.correct_option<len(options)): return await c.answer("پاسخ درست معتبر نیست.",show_alert=True)
        if item.kind=="riddle" and not (item.answer_text or "").strip(): return await c.answer("واردکردن پاسخ معما الزامی است.",show_alert=True)
        action_text="publish"
        notice=f"فعالیت «{escape(item.title)}» برای کاربران منتشر شود؟ بلافاصله امکان مشارکت فعال می‌شود و {count} پاسخ قبلی به همین فعالیت پیوسته باقی می‌ماند."
        button="✅ تأیید انتشار"
    else:
        if item.status!="published": return await c.answer("این فعالیت در حال حاضر منتشر نشده است.",show_alert=True)
        action_text="deactivate"
        notice=f"فعالیت «{escape(item.title)}» غیرفعال شود؟ کاربران دیگر نمی‌توانند پاسخ ثبت کنند؛ پاسخ‌های موجود حفظ می‌شوند."
        button="⛔ تأیید غیرفعال‌سازی"
    await _show(c,notice,_kb([[InlineKeyboardButton(text=button,callback_data=f"admin:v78:fun:apply:{action_text}:{aid}")],[InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:fun:view:{aid}")]]))


@router.callback_query(F.data.regexp(r"^admin:v78:fun:apply:(publish|deactivate):\d+$"))
async def admin_v78_fun_apply_status(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    parts=c.data.split(":"); action=parts[-2]; aid=int(parts[-1]); new_status="published" if action=="publish" else "inactive"
    async with SessionLocal() as session:
        item=(await session.execute(select(QuickFunActivity).where(QuickFunActivity.id==aid).with_for_update())).scalar_one_or_none()
        if not item: return await c.answer("فعالیت پیدا نشد.",show_alert=True)
        if action=="publish":
            if item.status=="published": return await c.answer("این فعالیت هم‌اکنون منتشر شده است.",show_alert=True)
            options=_json_dict(item.options_json,[])
            if not item.title.strip() or not item.prompt.strip(): return await c.answer("محتوای فعالیت کامل نیست.",show_alert=True)
            if item.kind in {"quiz","wyr"} and len(options)<2: return await c.answer("گزینه‌ها وارد نشده‌اند.",show_alert=True)
            if item.kind=="quiz" and (item.correct_option is None or not 0<=item.correct_option<len(options)): return await c.answer("پاسخ درست معتبر نیست.",show_alert=True)
            if item.kind=="riddle" and not (item.answer_text or "").strip(): return await c.answer("واردکردن پاسخ معما الزامی است.",show_alert=True)
        elif item.status!="published":
            return await c.answer("این فعالیت دیگر منتشرشده نیست.",show_alert=True)
        item.status=new_status; item.updated_by_telegram_id=int(c.from_user.id); item.updated_at=utc_now_naive()
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action=f"quick_fun_{new_status}",entity_type="quick_fun_activity",entity_id=aid,details={"kind":item.kind,"response_count":int(await session.scalar(select(func.count(QuickFunResponse.id)).where(QuickFunResponse.activity_id==aid)) or 0)})
        await session.commit()
    await _show(c,f"✅ وضعیت فعالیت اکنون «{admin_status_display_label(new_status)}» است.",_kb([[InlineKeyboardButton(text="مشاهدهٔ فعالیت",callback_data=f"admin:v77:fun:view:{aid}")],[InlineKeyboardButton(text="فهرست سرگرمی‌ها",callback_data="admin:v77:fun:list:0")]]))

# ------------------------- My Shop: reservation + append-only XP ledger -------------------------

async def _shop_costs(session) -> dict[int, int]:
    """Compatibility wrapper; business rules live in app.services.xp_shop."""
    return await configured_shop_costs(session)


async def _shop_reserved(session, telegram_id: int, *, exclude_request_id: int | None = None) -> int:
    return await reserved_shop_xp(session, telegram_id, exclude_request_id=exclude_request_id)


async def _render_shop(c: CallbackQuery):
    async with SessionLocal() as session:
        enabled = await shop_is_enabled(session)
        balance = await total_xp(session, c.from_user.id)
        reserved = await _shop_reserved(session, c.from_user.id)
        offers = await list_shop_offers(session, active_only=True) if enabled else []
        offer_availability = {int(o.id): await shop_offer_available(session, o) for o in offers}
        offer_usage = {int(o.id): await shop_offer_usage(session, int(o.id)) for o in offers if o.usage_limit is not None}
        history = (await session.execute(select(ShopRequest).where(
            ShopRequest.telegram_id == c.from_user.id
        ).order_by(ShopRequest.created_at.desc(), ShopRequest.id.desc()).limit(5))).scalars().all()
        history_ids=[int(x.id) for x in history]
        issues=(await session.execute(select(RewardIssue).where(
            RewardIssue.source_type=="shop", RewardIssue.source_id.in_(history_ids)
        ))).scalars().all() if history_ids else []
        issues_by_request={int(x.source_id):x for x in issues}
    available = available_shop_xp(balance, reserved)
    if enabled:
        text = f"<b>🛍 XP شاپ</b>\n\nکل امتیاز ثبت‌شده: <b>{balance}</b>\nرزرو برای درخواست‌های در انتظار: <b>{reserved}</b>\nامتیاز قابل استفاده: <b>{available}</b>"
        rows = []
        if offers:
            text += "\n\n<b>پیشنهادهای فعال</b>"
            for offer in offers:
                title = escape(offer.title)
                description = f"\n{escape(offer.description)}" if offer.description else ""
                usage = ""
                if offer.usage_limit is not None:
                    used = int(offer_usage.get(int(offer.id), 0))
                    usage = f" · ظرفیت باقی‌مانده: {max(0, int(offer.usage_limit) - used)}"
                text += f"\n\n• <b>{title}</b> · {int(offer.discount_percent)}٪ · {int(offer.xp_cost)} XP{description}{usage}"
                if offer_availability.get(int(offer.id)) and available >= int(offer.xp_cost):
                    rows.append([InlineKeyboardButton(
                        text=truncate_display_text(f"درخواست {offer.title} · {int(offer.xp_cost)} XP", 64),
                        callback_data=f"community:shop:request:id:{int(offer.id)}",
                    )])
        else:
            text += "\n\nدر حال حاضر پیشنهاد فعالی برای دریافت وجود ندارد."
    else:
        text = ("<b>🛍 XP شاپ</b>\n\nفروشگاه امتیاز در حال حاضر غیرفعال است. "
                "موجودی و سوابق امتیاز شما محفوظ خواهد بود و درخواست‌های قبلی همچنان قابل پیگیری هستند.")
        rows = []
    if history:
        text += "\n\n<b>درخواست‌های اخیر</b>"
        for item in history:
            issue=issues_by_request.get(int(item.id))
            label=shop_request_status_label(item.status, issue.status if issue else None)
            offer_label = item.offer_title_snapshot or f"تخفیف {item.discount_percent}٪"
            text += f"\n#{item.id} · {escape(offer_label)} · {escape(label)}"
            if item.status == "pending":
                rows.append([InlineKeyboardButton(text=f"لغو درخواست #{item.id}", callback_data=f"community:shop:cancel:{item.id}")])
    else:
        text += "\n\nهنوز درخواستی ثبت نکرده‌اید."
    rows += [[InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")]]
    await _show(c, text, _kb(rows))


@router.callback_query(F.data == "community:shop")
async def shop_home(c: CallbackQuery):
    await _render_shop(c)


async def _shop_request_preview_for_offer(c: CallbackQuery, offer_id: int):
    async with SessionLocal() as session:
        if not await shop_is_enabled(session):
            return await c.answer("فروشگاه در حال حاضر غیرفعال است.", show_alert=True)
        offer = await shop_offer_by_id(session, offer_id, active_only=True)
        if not offer or not await shop_offer_available(session, offer):
            return await c.answer("این پیشنهاد دیگر در دسترس نیست.", show_alert=True)
        cost = int(offer.xp_cost); percent = int(offer.discount_percent)
        balance = await total_xp(session, c.from_user.id); reserved = await _shop_reserved(session, c.from_user.id)
        title = str(offer.title); description = str(offer.description or "")
        revision = int(getattr(offer, "revision", 1) or 1)
    available = available_shop_xp(balance, reserved)
    if available < cost:
        return await c.answer("امتیاز قابل استفاده برای این درخواست کافی نیست.", show_alert=True)
    await _show(c, f"<b>تأیید درخواست {escape(title)}</b>\n\nمیزان تخفیف: <b>{percent}٪</b>\nهزینه: <b>{cost} XP</b>\nامتیاز قابل استفاده فعلی: {available}\n{escape(description)}\n\nاین مقدار فقط تا زمان بررسی مدیر رزرو می‌شود و در صورت تأیید، از XP شما کسر خواهد شد.", _kb([
        [InlineKeyboardButton(text="✅ تأیید درخواست", callback_data=f"community:shop:confirm:id:{offer_id}:rev:{revision}")],
        [InlineKeyboardButton(text="انصراف", callback_data="community:shop")],
    ]))


@router.callback_query(F.data.regexp(r"^community:shop:request:id:\d+$"))
async def shop_request_preview(c: CallbackQuery):
    await _shop_request_preview_for_offer(c, int(c.data.rsplit(":", 1)[1]))


@router.callback_query(F.data.regexp(r"^community:shop:confirm:id:\d+:rev:\d+$"))
async def shop_request_confirm(c: CallbackQuery):
    parts = c.data.split(":")
    await _shop_request_confirm_for_offer(c, int(parts[4]), int(parts[6]))


async def _shop_request_confirm_for_offer(c: CallbackQuery, offer_id: int, expected_revision: int | None = None):
    try:
        async with SessionLocal() as session:
            user = (await session.execute(select(User).where(User.telegram_id == c.from_user.id).with_for_update())).scalar_one_or_none()
            if user is None:
                return await c.answer("برای درخواست، ابتدا ثبت‌نام ربات را کامل کنید.", show_alert=True)
            if not await shop_is_enabled(session):
                return await c.answer("فروشگاه در حال حاضر غیرفعال است.", show_alert=True)
            offer = (await session.execute(select(XPShopOffer).where(
                XPShopOffer.id == offer_id
            ).with_for_update())).scalar_one_or_none()
            if not offer or not offer.active:
                return await c.answer("این پیشنهاد دیگر فعال نیست.", show_alert=True)
            if expected_revision is None or int(getattr(offer, "revision", 1) or 1) != int(expected_revision):
                await c.answer("شرایط پیشنهاد تغییر کرده است؛ لطفاً جزئیات جدید را بررسی و دوباره تأیید کنید.", show_alert=True)
                return await _shop_request_preview_for_offer(c, offer_id)
            if not await shop_offer_available(session, offer):
                return await c.answer("این پیشنهاد دیگر قابل دریافت نیست؛ ممکن است مهلت یا ظرفیت آن به پایان رسیده باشد.", show_alert=True)
            cost = int(offer.xp_cost); percent = int(offer.discount_percent)
            balance = await total_xp(session, c.from_user.id); reserved = await _shop_reserved(session, c.from_user.id)
            if balance - reserved < cost:
                return await c.answer("موجودی قابل استفاده تغییر کرده است؛ دوباره بررسی کنید.", show_alert=True)
            req = ShopRequest(
                telegram_id=c.from_user.id, offer_id=int(offer.id),
                offer_title_snapshot=str(offer.title)[:120],
                offer_description_snapshot=str(offer.description or "")[:2000] or None,
                discount_percent=percent, xp_cost=cost, status="pending",
            )
            session.add(req); await session.flush()
            await session.commit(); request_id = int(req.id)
            offer_title = str(offer.title)
    except IntegrityError:
        return await c.answer("درخواست به‌دلیل هم‌زمانی ثبت نشد؛ دوباره تلاش کنید.", show_alert=True)
    await notify_admins(c.bot,ShopRequest,request_id,
        f"🛍 <b>درخواست XP شاپ #{request_id}</b>\nپیشنهاد: {escape(offer_title)} · {percent}٪\nامتیاز رزروشده: {cost}\nشناسهٔ تلگرام دریافت‌کننده: <code>{c.from_user.id}</code>",
        _kb([[InlineKeyboardButton(text="مشاهدهٔ درخواست",callback_data=f"admin:v77:shop:view:{request_id}")],
             [InlineKeyboardButton(text="درخواست‌های در انتظار فروشگاه",callback_data="admin:v77:shop:queue:0")]]))
    await _show(c, f"✅ درخواست #{request_id} ثبت شد. {cost} XP تا زمان تصمیم مدیر رزرو شده است؛ هنوز از موجودی کسر نشده.", _kb([[InlineKeyboardButton(text="مشاهدهٔ درخواست‌ها", callback_data="community:shop")],[InlineKeyboardButton(text="بازگشت",callback_data="community:home")]]))


# Old inline keyboards from V93 may still contain percentage-based callback data.
# They are routed into the current catalogue and revalidated against both switches.
@router.callback_query(F.data.regexp(r"^community:shop:request:(15|25|50|100)$"))
async def shop_request_preview_legacy(c: CallbackQuery):
    percent = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        offer = (await session.execute(select(XPShopOffer).where(
            XPShopOffer.discount_percent == percent, XPShopOffer.active.is_(True)
        ).order_by(XPShopOffer.sort_order, XPShopOffer.id).limit(1))).scalar_one_or_none()
    if not offer:
        return await c.answer("این پیشنهاد دیگر در دسترس نیست.", show_alert=True)
    await _shop_request_preview_for_offer(c, int(offer.id))


@router.callback_query(F.data.regexp(r"^community:shop:confirm:(15|25|50|100)$"))
async def shop_request_confirm_legacy(c: CallbackQuery):
    percent = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        offer = (await session.execute(select(XPShopOffer).where(
            XPShopOffer.discount_percent == percent, XPShopOffer.active.is_(True)
        ).order_by(XPShopOffer.sort_order, XPShopOffer.id).limit(1))).scalar_one_or_none()
    if not offer:
        return await c.answer("این پیشنهاد دیگر در دسترس نیست.", show_alert=True)
    await _shop_request_preview_for_offer(c, int(offer.id))


@router.callback_query(F.data.regexp(r"^community:shop:cancel:\d+$"))
async def shop_request_cancel(c: CallbackQuery):
    rid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        req=(await session.execute(select(ShopRequest).where(ShopRequest.id==rid,ShopRequest.telegram_id==c.from_user.id).with_for_update())).scalar_one_or_none()
        if not req or req.status!="pending": return await c.answer("این درخواست دیگر قابل لغو نیست.",show_alert=True)
        req.status="cancelled"; req.updated_at=utc_now_naive(); await session.commit()
    return await _render_shop(c)


@router.callback_query(F.data.regexp(r"^admin:v77:shop:queue:\d+$"))
async def admin_shop_queue(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    page=max(0,int(c.data.rsplit(":",1)[1])); size=PAGE_SIZE
    async with SessionLocal() as session:
        total=int(await session.scalar(select(func.count(ShopRequest.id)).where(ShopRequest.status=="pending")) or 0)
        pages=max(1,(total+size-1)//size); page=min(page,pages-1)
        items=(await session.execute(select(ShopRequest).where(ShopRequest.status=="pending").order_by(ShopRequest.created_at.asc(),ShopRequest.id.asc()).offset(page*size).limit(size))).scalars().all()
    rows=[[InlineKeyboardButton(text=f"#{x.id} · {x.discount_percent}% · {x.xp_cost} XP · {x.telegram_id}",callback_data=f"admin:v77:shop:view:{x.id}")] for x in items]
    nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️ قبلی",callback_data=f"admin:v77:shop:queue:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="بعدی ➡️",callback_data=f"admin:v77:shop:queue:{page+1}"))
    if nav: rows.append(nav)
    rows += [[InlineKeyboardButton(text="🛍 مدیریت فروشگاه و پیشنهادها",callback_data="admin:v77:shop:manage")],
             [InlineKeyboardButton(text="📊 گزارش اقتصاد XP",callback_data="admin:v78:shop:economy")],
             [InlineKeyboardButton(text="ابزارهای تکمیلی",callback_data="admin:v77:home")]]
    await _show(c,f"<b>درخواست‌های XP شاپ</b> · در انتظار: {total}\nدرخواست‌های در انتظار، XP را رزرو می‌کنند اما هنوز از موجودی کسر نمی‌کنند.",_kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:shop:view:\d+$"))
async def admin_shop_view(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    rid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session: req=await session.get(ShopRequest,rid)
    if not req: return await c.answer("درخواست پیدا نشد.",show_alert=True)
    request_title = req.offer_title_snapshot or f"تخفیف {req.discount_percent}٪"
    text=f"<b>درخواست XP شاپ #{rid}</b>\n\nپیشنهاد: {escape(request_title)}\nکاربر: <code>{req.telegram_id}</code>\nتخفیف: {req.discount_percent}%\nمقدار XP ثبت‌شده: {req.xp_cost}\nوضعیت: {escape(admin_status_display_label(req.status))}\nاطلاع‌رسانی به مدیر: {escape(admin_status_display_label(req.admin_notification_status))} (تعداد تلاش: {int(req.admin_notification_attempts or 0)})\nایجاد: {req.created_at:%Y-%m-%d %H:%M UTC}"
    if req.admin_notification_error: text += f"\nآخرین خطای اطلاع‌رسانی به مدیر: {escape(req.admin_notification_error)}"
    rows=[]
    if req.status=="pending":
        rows += [[InlineKeyboardButton(text="✅ بررسی و تأیید",callback_data=f"admin:v77:shop:approve:{rid}")],[InlineKeyboardButton(text="❌ رد درخواست (با ذکر دلیل)",callback_data=f"admin:v77:shop:deny:{rid}")]]
    rows += [[InlineKeyboardButton(text="فهرست درخواست‌های در انتظار",callback_data="admin:v77:shop:queue:0")]]
    await _show(c,text,_kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:shop:approve:\d+$"))
async def admin_shop_approve_preview(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    rid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        req=await session.get(ShopRequest,rid)
    if not req or req.status!="pending": return await c.answer("این درخواست دیگر در انتظار بررسی نیست.",show_alert=True)
    await _show(c,f"<b>تأیید درخواست فروشگاه · #{rid}</b>\n\nدریافت‌کننده: <code>{req.telegram_id}</code>\nتخفیف: {req.discount_percent}%\nXP قابل کسر از سوابق موجود: <b>{req.xp_cost}</b>\n\nاین اقدام برگشت‌پذیر نیست. با تأیید، همین مقدار دقیقاً یک بار از XP کسر و پروندهٔ صدور دستی هدیه ایجاد می‌شود.",_kb([
        [InlineKeyboardButton(text="✅ تأیید و کسر XP",callback_data=f"admin:v77:shop:approve-confirm:{rid}")],
        [InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:shop:view:{rid}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v77:shop:approve-confirm:\d+$"))
async def admin_shop_approve(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    rid=int(c.data.rsplit(":",1)[1]); user_tg=None; percent=cost=None
    async with SessionLocal() as session:
        req=(await session.execute(select(ShopRequest).where(ShopRequest.id==rid).with_for_update())).scalar_one_or_none()
        if not req or req.status!="pending": return await c.answer("این درخواست دیگر در انتظار بررسی نیست.",show_alert=True)
        user_tg=int(req.telegram_id)
        locked_user_id = await session.scalar(select(User.id).where(User.telegram_id==user_tg).with_for_update())
        if locked_user_id is None:
            return await c.answer("حساب کاربر دیگر وجود ندارد؛ این درخواست باید به‌صورت دستی بررسی و تعیین تکلیف شود.",show_alert=True)
        bal=await total_xp(session,user_tg); reserved=await _shop_reserved(session,user_tg,exclude_request_id=rid)
        if bal-reserved<int(req.xp_cost): return await c.answer("پس از رزروهای دیگر، موجودی XP کافی نیست.",show_alert=True)
        debit=await _create_ledger_award(session,telegram_id=user_tg,points=-int(req.xp_cost),award_type="shop_redemption",award_key=f"my-shop-request:{rid}:debit",source_id=str(rid),note="Approved درخواست XP شاپ")
        if not debit: return await c.answer("کسر XP قبلاً ثبت شده است؛ این درخواست به بررسی و تطبیق نیاز دارد.",show_alert=True)
        req.status="awaiting_code"; req.reviewed_by_telegram_id=int(c.from_user.id); req.reviewed_at=utc_now_naive(); req.updated_at=utc_now_naive()
        issue=RewardIssue(source_type="shop",source_id=rid,telegram_id=user_tg,discount_percent=int(req.discount_percent),status="awaiting_code")
        session.add(issue); await session.flush(); reward_issue_id=int(issue.id)
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="my_shop_request_approved_xp_debited",entity_type="shop_request",entity_id=rid,details={"telegram_id":user_tg,"discount_percent":req.discount_percent,"xp_cost":req.xp_cost,"reward_issue_id":issue.id})
        await session.commit(); percent=int(req.discount_percent); cost=int(req.xp_cost)
    await notify_admins(c.bot,RewardIssue,reward_issue_id,
        f"🎟 <b>نیاز به صدور هدیه · #{reward_issue_id}</b>\nدرخواست XP شاپ #{rid} · {percent}% · user <code>{user_tg}</code>\nوضعیت: در انتظار کد تخفیف شخصیِ سازگار",
        _kb([[InlineKeyboardButton(text="مشاهدهٔ پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{reward_issue_id}")],
             [InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]]))
    try: await c.bot.send_message(user_tg,f"✅ درخواست فروشگاه شما تأیید شد. {cost} XP کسر شد. تخفیف {percent}% در صف صدور/تحویل هدیه قرار گرفته؛ پس از آماده‌شدن به شما اطلاع داده می‌شود.")
    except Exception: logger.info("Could not notify shop approval target; request_id=%s",rid)
    await _show(c,"✅ درخواست تأیید شد. کسر XP دقیقاً یک بار ثبت شد؛ اکنون یک هدیهٔ شخصیِ سازگار را از صف صدور تخصیص دهید.",_kb([[InlineKeyboardButton(text="🎟 صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")],[InlineKeyboardButton(text="درخواست‌های فروشگاه",callback_data="admin:v77:shop:queue:0")]]))


async def _create_ledger_award(session, *, telegram_id: int, points: int, award_type: str, award_key: str, source_id: str, note: str) -> bool:
    """Local idempotent ledger insert mirroring community.award_once without new XP systems."""
    try:
        async with session.begin_nested():
            session.add(XPAward(telegram_id=int(telegram_id),points=int(points),award_type=award_type,award_key=award_key,source_id=source_id,note=note[:300]))
            await session.flush()
        return True
    except IntegrityError:
        return False


@router.callback_query(F.data.regexp(r"^admin:v77:shop:deny:\d+$"))
async def admin_shop_deny_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    rid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        req=await session.get(ShopRequest,rid)
        if not req or req.status!="pending": return await c.answer("این درخواست دیگر در انتظار بررسی نیست.",show_alert=True)
    if not await _can_start_v77_form(c, state): return
    await state.update_data(v77_shop_request_id=rid); await state.set_state(V77AdminStates.shop_denial)
    await c.message.edit_text(f"درخواست شمارهٔ {rid}: دلیل رد را بنویسید (حداکثر ۵۰۰ نویسه). با رد درخواست، امتیاز رزروشده آزاد می‌شود.")
    await c.answer()


@router.message(V77AdminStates.shop_denial)
async def admin_shop_deny_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    reason=(message.text or "").strip()
    if reason.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("رد درخواست لغو شد؛ درخواست همچنان در انتظار بررسی است.",reply_markup=_kb([[InlineKeyboardButton(text="صف درخواست‌های فروشگاه",callback_data="admin:v77:shop:queue:0")]]))
    data=await state.get_data(); rid=int(data.get("v77_shop_request_id") or 0)
    if not reason or reason.startswith("/") or len(reason)>500: return await message.answer("دلیل رد را حداکثر در ۵۰۰ نویسه بفرستید یا /cancel را ارسال کنید.")
    async with SessionLocal() as session:
        req=await session.get(ShopRequest,rid)
        if not req or req.status!="pending": await state.clear(); return await message.answer("این درخواست دیگر در انتظار بررسی نیست.")
    await state.update_data(v77_shop_denial_reason=reason)
    await state.set_state(V77AdminStates.shop_denial_confirm)
    await message.answer(f"<b>تأیید رد درخواست #{rid}</b>\n\nReason: {escape(reason)}\n\nامتیاز رزروشده آزاد می‌شود؛ تاکنون هیچ XPای کسر نشده است.",reply_markup=_kb([
        [InlineKeyboardButton(text="✅ تأیید رد درخواست",callback_data=f"admin:v77:shop:deny-confirm:{rid}")],
        [InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:shop:view:{rid}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v77:shop:deny-confirm:\d+$"))
async def admin_shop_deny_confirm(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    data=await state.get_data()
    try:
        rid=int(c.data.rsplit(":",1)[1]); expected=int(data.get("v77_shop_request_id") or 0)
    except (TypeError,ValueError): return await c.answer("مهلت تأیید رد درخواست پایان یافته است؛ درخواست را دوباره باز کنید.",show_alert=True)
    reason=str(data.get("v77_shop_denial_reason") or "").strip()
    if rid!=expected or not reason: return await c.answer("مهلت تأیید رد درخواست پایان یافته است؛ درخواست را دوباره باز کنید.",show_alert=True)
    async with SessionLocal() as session:
        req=(await session.execute(select(ShopRequest).where(ShopRequest.id==rid).with_for_update())).scalar_one_or_none()
        if not req or req.status!="pending":
            await state.clear(); return await c.answer("این درخواست دیگر در انتظار بررسی نیست.",show_alert=True)
        req.status="denied"; req.denial_reason=reason; req.reviewed_by_telegram_id=int(c.from_user.id); req.reviewed_at=utc_now_naive(); req.updated_at=utc_now_naive()
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="my_shop_request_denied",entity_type="shop_request",entity_id=rid,details={"telegram_id":req.telegram_id,"reason":reason[:300]})
        target=int(req.telegram_id); await session.commit()
    await state.clear()
    try: await c.bot.send_message(target,f"درخواست فروشگاه شما رد شد. دلیل: {reason}")
    except Exception: logger.info("Could not notify denied shop request; request_id=%s",rid)
    await _show(c,f"درخواست شمارهٔ {rid} رد شد و امتیاز رزروشده آزاد شد.",_kb([[InlineKeyboardButton(text="صف درخواست‌های فروشگاه",callback_data="admin:v77:shop:queue:0")]]))


@router.callback_query(F.data == "admin:v77:shop:costs")
async def admin_shop_costs(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    async with SessionLocal() as session: costs=await _shop_costs(session)
    if not await _can_start_v77_form(c, state): return
    await state.set_state(V77AdminStates.shop_costs)
    await c.message.edit_text("هزینهٔ XP برای هر سطح تخفیف شخصی را تنظیم کنید. مقادیر فعلی: "+", ".join(f"{p}%={costs[p]}" for p in (15,25,50,100))+"\n\nالگو: <code>15=20,25=40,50=80,100=160</code>. واردکردن هر چهار مقدار الزامی است. این بخش XP جدید ایجاد یا صفر نمی‌کند. برای حفظ مقادیر قبلی /cancel را بفرستید.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data="admin:v77:shop:queue:0")]]))
    await c.answer()


@router.message(V77AdminStates.shop_costs)
async def admin_shop_costs_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    if (message.text or "").strip().lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("ویرایش هزینه‌های فروشگاه لغو شد؛ مقادیر قبلی بدون تغییر باقی ماندند.",reply_markup=_kb([[InlineKeyboardButton(text="صف درخواست‌های فروشگاه",callback_data="admin:v77:shop:queue:0")]]))
    try:
        values={}
        for chunk in (message.text or "").split(","):
            key,val=chunk.strip().split("=",1); values[int(key.strip())]=int(val.strip())
        if set(values)!={15,25,50,100} or any(v<1 or v>1_000_000 for v in values.values()): raise ValueError
    except ValueError: return await message.answer("مقادیر معتبر نیستند. هر چهار هزینهٔ مثبت XP را با الگوی 15=20,25=40,50=80,100=160 وارد کنید.")
    async with SessionLocal() as session:
        await set_setting(session,"v77_my_shop_costs",json.dumps({str(k):v for k,v in values.items()}))
        await write_admin_action(session,actor_telegram_id=message.from_user.id,action="my_shop_costs_updated",entity_type="app_setting",details={"costs":values})
        await session.commit()
    await state.clear(); await message.answer("✅ هزینه‌های فروشگاه برای درخواست‌های آینده به‌روزرسانی شد؛ درخواست‌های قبلی همان هزینهٔ ثبت‌شدهٔ خود را حفظ می‌کنند.",reply_markup=_kb([[InlineKeyboardButton(text="صف درخواست‌های فروشگاه",callback_data="admin:v77:shop:queue:0")]]))

# ------------------------- XP Shop catalogue management -------------------------

async def _render_shop_management(c: CallbackQuery):
    async with SessionLocal() as session:
        enabled = await shop_is_enabled(session)
        offers = await list_shop_offers(session)
        usage = {int(item.id): await shop_offer_usage(session, int(item.id)) for item in offers}
    rows = [[InlineKeyboardButton(
        text=("🟢 فروشگاه: فعال" if enabled else "🔴 فروشگاه: غیرفعال"),
        callback_data="admin:v77:shop:toggle",
    )]]
    for offer in offers:
        state_label = "فعال" if offer.active else "غیرفعال"
        cap_label = f" · {usage[int(offer.id)]}/{int(offer.usage_limit)}" if offer.usage_limit is not None else ""
        label = f"{'🟢' if offer.active else '🔴'} {offer.title} · {offer.discount_percent}% · {offer.xp_cost} XP · {state_label}{cap_label}"
        rows.append([InlineKeyboardButton(text=truncate_display_text(label, 64), callback_data=f"admin:v77:shop:offer:{int(offer.id)}")])
    rows += [
        [InlineKeyboardButton(text="➕ افزودن پیشنهاد", callback_data="admin:v77:shop:add")],
        [InlineKeyboardButton(text="📊 گزارش اقتصاد XP", callback_data="admin:v78:shop:economy")],
        [InlineKeyboardButton(text="📥 درخواست‌های کاربران", callback_data="admin:v77:shop:queue:0")],
        [InlineKeyboardButton(text="🔙 ابزارهای تکمیلی", callback_data="admin:v77:home")],
    ]
    status = "فعال" if enabled else "غیرفعال"
    body = (f"<b>🛍 مدیریت XP شاپ</b>\n\nوضعیت کلی فروشگاه: <b>{status}</b>\n"
            "غیرفعال‌سازی فقط درخواست جدید را متوقف می‌کند؛ درخواست‌های قبلی، صدور هدایا، تحویل و سوابق XP حفظ می‌شوند.\n\n"
            "برای تغییر قیمت یا مشخصات یک پیشنهاد، آن را انتخاب کنید.")
    await _show(c, body, _kb(rows))


@router.callback_query(F.data == "admin:v77:shop:manage")
async def admin_shop_manage(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _clear_v77_state(state)
    await _render_shop_management(c)


@router.callback_query(F.data == "admin:v77:shop:toggle")
async def admin_shop_toggle(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        current = await shop_is_enabled(session)
        await set_shop_enabled(session, not current)
        await write_admin_action(session, actor_telegram_id=c.from_user.id,
            action="xp_shop_enabled" if not current else "xp_shop_disabled",
            entity_type="app_setting", details={"enabled": not current})
        await session.commit()
    await _render_shop_management(c)


@router.callback_query(F.data.regexp(r"^admin:v77:shop:offer:\d+$"))
async def admin_shop_offer_view(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    offer_id = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        offer = await shop_offer_by_id(session, offer_id)
        if not offer:
            return await c.answer("پیشنهاد پیدا نشد.", show_alert=True)
        used = await shop_offer_usage(session, offer_id)
    expired = bool(offer.expires_at and offer.expires_at <= utc_now_naive())
    status = "منقضی" if expired else ("فعال" if offer.active else "غیرفعال")
    usage_label = f"{used} از {int(offer.usage_limit)}" if offer.usage_limit is not None else "بدون محدودیت"
    expiry_label = offer.expires_at.strftime("%Y-%m-%d %H:%M UTC") if offer.expires_at else "بدون انقضا"
    rows = [
        [InlineKeyboardButton(text=("🔴 غیرفعال‌کردن پیشنهاد" if offer.active else "🟢 فعال‌کردن پیشنهاد"), callback_data=f"admin:v77:shop:offer-toggle:{offer_id}")],
        [InlineKeyboardButton(text="✏️ ویرایش عنوان", callback_data=f"admin:v77:shop:offer-edit:{offer_id}:title"),
         InlineKeyboardButton(text="✏️ ویرایش درصد", callback_data=f"admin:v77:shop:offer-edit:{offer_id}:percent")],
        [InlineKeyboardButton(text="✏️ ویرایش هزینه XP", callback_data=f"admin:v77:shop:offer-edit:{offer_id}:cost")],
        [InlineKeyboardButton(text="✏️ ویرایش توضیحات", callback_data=f"admin:v77:shop:offer-edit:{offer_id}:description"),
         InlineKeyboardButton(text="✏️ محدودیت استفاده", callback_data=f"admin:v77:shop:offer-edit:{offer_id}:limit")],
        [InlineKeyboardButton(text="⏳ تاریخ انقضا", callback_data=f"admin:v77:shop:offer-edit:{offer_id}:expires")],
        [InlineKeyboardButton(text="🔙 فهرست پیشنهادها", callback_data="admin:v77:shop:manage")],
    ]
    body = (f"<b>{escape(offer.title)}</b>\n\nوضعیت: {status}\nتخفیف: {int(offer.discount_percent)}٪\n"
            f"هزینه: {int(offer.xp_cost)} XP\nتوضیحات: {escape(offer.description or '—')}\n"
            f"استفاده: {usage_label}\nانقضا: {escape(expiry_label)}\n\nتغییرات فقط بر درخواست‌های آینده اثر می‌گذارند؛ اطلاعات ثبت‌شدهٔ درخواست‌های قبلی ثابت می‌ماند.")
    await _show(c, body, _kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:shop:offer-toggle:\d+$"))
async def admin_shop_offer_toggle(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    offer_id = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        offer = (await session.execute(select(XPShopOffer).where(XPShopOffer.id == offer_id).with_for_update())).scalar_one_or_none()
        if not offer:
            return await c.answer("پیشنهاد پیدا نشد.", show_alert=True)
        offer.active = not bool(offer.active)
        offer.revision = int(getattr(offer, "revision", 1) or 1) + 1
        offer.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=c.from_user.id,
            action="xp_shop_offer_activated" if offer.active else "xp_shop_offer_deactivated",
            entity_type="xp_shop_offer", entity_id=offer_id,
            details={"active": bool(offer.active), "discount_percent": int(offer.discount_percent)})
        await session.commit()
    await c.answer("وضعیت پیشنهاد به‌روزرسانی شد.")
    # Re-render the list so the changed state is visible immediately.
    await _render_shop_management(c)


@router.callback_query(F.data == "admin:v77:shop:add")
async def admin_shop_offer_add_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _can_start_v77_form(c, state):
        return
    await state.update_data(shop_offer_creator=int(c.from_user.id))
    await state.set_state(V77AdminStates.shop_offer_title)
    await c.message.edit_text("عنوان پیشنهاد جدید را وارد کنید (۳ تا ۱۲۰ نویسه). برای لغو /cancel را بفرستید.")
    await c.answer()


@router.message(V77AdminStates.shop_offer_title, F.text)
async def admin_shop_offer_add_title(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    value = (message.text or "").strip()
    if value.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("افزودن پیشنهاد لغو شد.", reply_markup=_kb([[InlineKeyboardButton(text="مدیریت XP شاپ", callback_data="admin:v77:shop:manage")]]))
    if not 3 <= len(value) <= 120 or value.startswith("/"):
        return await message.answer("عنوان باید بین ۳ تا ۱۲۰ نویسه باشد.")
    await state.update_data(shop_offer_title=value)
    await state.set_state(V77AdminStates.shop_offer_percent)
    await message.answer("درصد تخفیف را به‌صورت عدد صحیح بین ۱ تا ۱۰۰ وارد کنید.")


@router.message(V77AdminStates.shop_offer_percent, F.text)
async def admin_shop_offer_add_percent(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip()
    if raw.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("افزودن پیشنهاد لغو شد.")
    try:
        percent = int(raw)
        if not 1 <= percent <= 100: raise ValueError
    except ValueError:
        return await message.answer("درصد باید عدد صحیحی بین ۱ تا ۱۰۰ باشد.")
    await state.update_data(shop_offer_percent=percent)
    await state.set_state(V77AdminStates.shop_offer_cost)
    await message.answer("هزینهٔ این پیشنهاد را به XP وارد کنید (۱ تا ۱٬۰۰۰٬۰۰۰).")


@router.message(V77AdminStates.shop_offer_cost, F.text)
async def admin_shop_offer_add_cost(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip()
    if raw.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("افزودن پیشنهاد لغو شد.")
    try:
        cost = int(raw)
        if not 1 <= cost <= 1_000_000: raise ValueError
    except ValueError:
        return await message.answer("هزینه باید عدد صحیحی بین ۱ تا ۱٬۰۰۰٬۰۰۰ باشد.")
    await state.update_data(shop_offer_cost=cost)
    await state.set_state(V77AdminStates.shop_offer_description)
    await message.answer("توضیحات پیشنهاد را وارد کنید (حداکثر ۵۰۰ نویسه)، یا برای بدون توضیح «-» بفرستید.")


@router.message(V77AdminStates.shop_offer_description, F.text)
async def admin_shop_offer_add_description(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    value = (message.text or "").strip()
    if value.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("افزودن پیشنهاد لغو شد.")
    if value not in {"-", "—"} and len(value) > 500:
        return await message.answer("توضیحات حداکثر ۵۰۰ نویسه است.")
    await state.update_data(shop_offer_description="" if value in {"-", "—"} else value)
    await state.set_state(V77AdminStates.shop_offer_limit)
    await message.answer("محدودیت تعداد دریافت را وارد کنید (عدد مثبت)، یا «-» برای بدون محدودیت.")


@router.message(V77AdminStates.shop_offer_limit, F.text)
async def admin_shop_offer_add_limit(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip()
    if raw.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("افزودن پیشنهاد لغو شد.")
    if raw in {"-", "—"}:
        usage_limit = None
    else:
        try:
            usage_limit = int(raw)
            if not 1 <= usage_limit <= 1_000_000: raise ValueError
        except ValueError:
            return await message.answer("محدودیت باید عددی بین ۱ تا ۱٬۰۰۰٬۰۰۰ یا «-» باشد.")
    await state.update_data(shop_offer_usage_limit=usage_limit)
    await state.set_state(V77AdminStates.shop_offer_expires)
    await message.answer("زمان انقضا را به UTC و با قالب YYYY-MM-DD HH:MM وارد کنید؛ برای بدون انقضا «-» بفرستید.")


@router.message(V77AdminStates.shop_offer_expires, F.text)
async def admin_shop_offer_add_expires(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip()
    if raw.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("افزودن پیشنهاد لغو شد.", reply_markup=_kb([[InlineKeyboardButton(text="مدیریت XP شاپ", callback_data="admin:v77:shop:manage")]]))
    if raw in {"-", "—"}:
        expires_at = None
    else:
        try:
            expires_at = datetime.strptime(raw, "%Y-%m-%d %H:%M")
            if expires_at <= utc_now_naive(): raise ValueError
        except ValueError:
            return await message.answer("زمان معتبر نیست یا در گذشته است. قالب: YYYY-MM-DD HH:MM (UTC)، یا «-».")
    data = await state.get_data()
    async with SessionLocal() as session:
        offer = XPShopOffer(
            title=str(data["shop_offer_title"]), description=str(data.get("shop_offer_description") or "") or None,
            discount_percent=int(data["shop_offer_percent"]), xp_cost=int(data["shop_offer_cost"]),
            usage_limit=data.get("shop_offer_usage_limit"), expires_at=expires_at,
            active=False, created_by_telegram_id=int(message.from_user.id),
            sort_order=int(data["shop_offer_percent"]),
        )
        session.add(offer); await session.flush(); offer_id=int(offer.id)
        await write_admin_action(session, actor_telegram_id=message.from_user.id, action="xp_shop_offer_created",
            entity_type="xp_shop_offer", entity_id=offer_id,
            details={"discount_percent": offer.discount_percent, "xp_cost": offer.xp_cost,
                     "usage_limit": offer.usage_limit, "expires_at_utc": expires_at.isoformat() if expires_at else None})
        await session.commit()
    await state.clear()
    await message.answer(f"✅ پیشنهاد «{escape(str(data['shop_offer_title']))}» ایجاد شد و تا زمان فعال‌سازی توسط مدیر غیرفعال می‌ماند.", reply_markup=_kb([
        [InlineKeyboardButton(text="مشاهدهٔ پیشنهاد", callback_data=f"admin:v77:shop:offer:{offer_id}")],
        [InlineKeyboardButton(text="مدیریت XP شاپ", callback_data="admin:v77:shop:manage")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v77:shop:offer-edit:\d+:(title|percent|cost|description|limit|expires)$"))
async def admin_shop_offer_edit_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _can_start_v77_form(c, state):
        return
    parts = c.data.split(":")
    offer_id, field = int(parts[4]), parts[5]
    async with SessionLocal() as session:
        offer = await shop_offer_by_id(session, offer_id)
    if not offer:
        return await c.answer("پیشنهاد پیدا نشد.", show_alert=True)
    prompts = {
        "title": "عنوان جدید را وارد کنید (۳ تا ۱۲۰ نویسه).",
        "percent": "درصد تخفیف جدید را بین ۱ تا ۱۰۰ وارد کنید.",
        "cost": "هزینهٔ XP جدید را بین ۱ تا ۱٬۰۰۰٬۰۰۰ وارد کنید.",
        "description": "توضیحات جدید را وارد کنید (حداکثر ۵۰۰ نویسه) یا «-» برای پاک‌کردن.",
        "limit": "محدودیت جدید را عدد مثبت وارد کنید؛ «-» یعنی بدون محدودیت.",
        "expires": "زمان انقضای جدید را به UTC با قالب YYYY-MM-DD HH:MM وارد کنید؛ «-» یعنی پاک‌کردن انقضا.",
    }
    await state.update_data(shop_offer_edit_id=offer_id, shop_offer_edit_field=field)
    await state.set_state(V77AdminStates.shop_offer_edit)
    await c.message.edit_text(f"ویرایش پیشنهاد «{escape(offer.title)}»\n\n{prompts[field]}\nبرای لغو /cancel را بفرستید.")
    await c.answer()


@router.message(V77AdminStates.shop_offer_edit, F.text)
async def admin_shop_offer_edit_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        await state.clear(); return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip()
    if raw.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("ویرایش لغو شد.", reply_markup=_kb([[InlineKeyboardButton(text="مدیریت XP شاپ", callback_data="admin:v77:shop:manage")]]))
    data = await state.get_data()
    offer_id = int(data.get("shop_offer_edit_id") or 0)
    field = str(data.get("shop_offer_edit_field") or "")
    try:
        if field == "title":
            if not 3 <= len(raw) <= 120 or raw.startswith("/"): raise ValueError
            value = raw
        elif field == "percent":
            value = int(raw)
            if not 1 <= value <= 100: raise ValueError
        elif field == "cost":
            value = int(raw)
            if not 1 <= value <= 1_000_000: raise ValueError
        elif field == "description":
            if len(raw) > 500: raise ValueError
            value = None if raw in {"-", "—"} else raw
        elif field == "limit":
            value = None if raw in {"-", "—"} else int(raw)
            if value is not None and not 1 <= value <= 1_000_000: raise ValueError
        elif field == "expires":
            value = None if raw in {"-", "—"} else datetime.strptime(raw, "%Y-%m-%d %H:%M")
            if value is not None and value <= utc_now_naive(): raise ValueError
        else:
            raise ValueError
    except ValueError:
        return await message.answer("مقدار واردشده معتبر نیست؛ مطابق راهنمای همین مرحله تلاش کنید.")
    async with SessionLocal() as session:
        offer = (await session.execute(select(XPShopOffer).where(XPShopOffer.id == offer_id).with_for_update())).scalar_one_or_none()
        if not offer:
            await state.clear(); return await message.answer("پیشنهاد پیدا نشد؛ ویرایش لغو شد.")
        if field == "limit" and value is not None:
            used = await shop_offer_usage(session, offer_id)
            if value < used:
                return await message.answer(f"محدودیت نمی‌تواند کمتر از {used} درخواست ثبت‌شده یا در حال اجرا باشد.")
        setattr(offer, {"title":"title", "percent":"discount_percent", "cost":"xp_cost", "description":"description", "limit":"usage_limit", "expires":"expires_at"}[field], value)
        offer.revision = int(getattr(offer, "revision", 1) or 1) + 1
        offer.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=message.from_user.id, action="xp_shop_offer_updated",
            entity_type="xp_shop_offer", entity_id=offer_id,
            details={"field": field, "expires_at_utc": value.isoformat() if field == "expires" and value else None})
        await session.commit()
    await state.clear()
    await message.answer("✅ پیشنهاد به‌روزرسانی شد. درخواست‌های قبلی با مشخصات زمان ثبت خود باقی می‌مانند.", reply_markup=_kb([
        [InlineKeyboardButton(text="مشاهدهٔ پیشنهاد", callback_data=f"admin:v77:shop:offer:{offer_id}")],
        [InlineKeyboardButton(text="مدیریت XP شاپ", callback_data="admin:v77:shop:manage")],
    ]))


# ------------------------- Lucky Draw: free, manual activation, one claim -------------------------

async def _draw_odds(session) -> dict[int, int]:
    raw=await get_setting(session,"v77_lucky_draw_odds")
    try:
        parsed=json.loads(raw) if raw else {}
        if not isinstance(parsed, dict): raise ValueError
        odds={p:int(parsed.get(str(p),DRAW_DEFAULT_ODDS[p])) for p in (15,25,50,100)}
        if any(v<0 or v>100 for v in odds.values()) or sum(odds.values())!=100: raise ValueError
        return odds
    except (TypeError,ValueError,json.JSONDecodeError):
        return dict(DRAW_DEFAULT_ODDS)


def _parse_odds(raw: str) -> dict[int,int]:
    values={}
    for part in raw.split(","):
        key,value=part.strip().split("=",1)
        key_int, value_int = int(key.strip()), int(value.strip())
        if key_int in values:
            raise ValueError("هر سطح تخفیف باید دقیقاً یک بار وارد شود.")
        values[key_int] = value_int
    if set(values)!={15,25,50,100} or any(v<0 or v>100 for v in values.values()) or sum(values.values())!=100:
        raise ValueError("احتمال‌ها باید شامل ۱۵، ۲۵، ۵۰ و ۱۰۰ باشند و مجموع آن‌ها دقیقاً ۱۰۰ شود.")
    return values


def _choose_prize(odds: dict[int,int]) -> int:
    roll=secrets.randbelow(100); edge=0
    for percent in (15,25,50,100):
        edge += int(odds[percent])
        if roll < edge: return percent
    # Validated probabilities sum to 100; defensive fallback is the final nonzero tier.
    return next(p for p in (100,50,25,15) if odds[p] > 0)


@router.callback_query(F.data == "community:draw")
async def lucky_draw_home(c: CallbackQuery):
    async with SessionLocal() as session:
        campaign=(await session.execute(select(LuckyDrawCampaign).where(LuckyDrawCampaign.active.is_(True)).order_by(LuckyDrawCampaign.activated_at.desc(),LuckyDrawCampaign.id.desc()).limit(1))).scalar_one_or_none()
        if not campaign:
            history = (await session.execute(
                select(LuckyDrawClaim, LuckyDrawCampaign)
                .join(LuckyDrawCampaign, LuckyDrawCampaign.id == LuckyDrawClaim.campaign_id)
                .where(LuckyDrawClaim.telegram_id == c.from_user.id)
                .order_by(LuckyDrawClaim.created_at.desc(), LuckyDrawClaim.id.desc()).limit(5)
            )).all()
            body = "🎁 <b>Giveaways</b>\n\nفعلاً کمپین فعالی وجود ندارد. هر زمان کمپینی فعال شود، می‌توانید از همین بخش و به‌صورت داوطلبانه شرکت کنید."
            if history:
                body += "\n\n<b>نتایج قبلی شما</b>"
                for old_claim, old_campaign in history:
                    old_issue = (await session.execute(select(RewardIssue).where(
                        RewardIssue.source_type == "lucky_draw", RewardIssue.source_id == old_claim.id
                    ))).scalar_one_or_none()
                    status = ("تحویل ثبت‌شده" if old_issue and old_issue.status == "delivered" else
                              "در صف صدور کد" if old_issue and old_issue.status == "awaiting_code" else
                              "آمادهٔ تحویل" if old_issue and old_issue.status == "ready_to_deliver" else
                              "نیازمند اقدام مدیر" if old_issue and old_issue.status == "delivery_failed" else
                              "وضعیت تحویل نیازمند بررسی" if old_issue and old_issue.status in {"delivery_uncertain","sending"} else
                              "در حال پیگیری")
                    body += f"\n• {escape(old_campaign.label)} — تخفیف {old_claim.discount_percent}% · {status}"
            return await _show(c,body,_kb([[InlineKeyboardButton(text="🔙 بازگشت",callback_data="community:home")]]))
        claim=(await session.execute(select(LuckyDrawClaim).where(LuckyDrawClaim.campaign_id==campaign.id,LuckyDrawClaim.telegram_id==c.from_user.id))).scalar_one_or_none()
        odds=_json_dict(campaign.probabilities_json,{})
        count=int(await session.scalar(select(func.count(LuckyDrawClaim.id)).where(LuckyDrawClaim.campaign_id==campaign.id)) or 0)
        issue=None
        if claim: issue=(await session.execute(select(RewardIssue).where(RewardIssue.source_type=="lucky_draw",RewardIssue.source_id==claim.id))).scalar_one_or_none()
    if claim:
        text=f"🎁 <b>{escape(campaign.label)}</b>\n\nشما قبلاً نتیجهٔ این کمپین را دریافت کرده‌اید: <b>تخفیف {claim.discount_percent}%</b>. هر نفر در هر کمپین فقط یک بار می‌تواند شرکت کند.\n\n"
        if issue and issue.status=="awaiting_code": text += "🎟 جایزه در صف صدور هدیهٔ شخصی توسط مدیر است."
        elif issue and issue.status=="delivered": text += "✅ تحویل هدیه ثبت شده است؛ پیام تحویل را بررسی کنید."
        elif issue and issue.status=="ready_to_deliver": text += "🎟 هدیه آمادهٔ تحویل است و هنوز ارسال نشده."
        elif issue and issue.status in {"delivery_uncertain","sending"}: text += "⚠️ وضعیت تحویل نامشخص است و مدیر باید آن را بررسی کند."
        elif issue and issue.status=="delivery_failed": text += "⚠️ تحویل ناموفق بوده و نیازمند پیگیری مدیر است."
        else: text += "وضعیت تحویل در حال پیگیری است."
        rows=[[InlineKeyboardButton(text="🔙 بازگشت",callback_data="community:home")]]
    else:
        chances="\n".join(f"• {p}% تخفیف: <b>{int(odds.get(str(p),odds.get(p,0)))}%</b> احتمال" for p in (15,25,50,100))
        text=f"🎁 <b>{escape(campaign.label)}</b>\n\nشرکت در Giveaways رایگان است؛ XP یا پولی مصرف نمی‌شود و نتیجه روی XP، streak یا رتبه‌بندی اثری ندارد. شرکت‌کردن اختیاری است و هر حساب در هر کمپین فقط یک بار می‌تواند نتیجه بگیرد.\n\n<b>احتمال‌های دقیق</b>\n{chances}\n\nکل شرکت‌کنندگان تا این لحظه: {count}\n\nبا زدن دکمهٔ زیر نتیجه را دریافت می‌کنید؛ مدیر کد/هدیهٔ متناسب را جداگانه صادر می‌کند."
        rows=[[InlineKeyboardButton(text="🎲 تأیید و دریافت نتیجه",callback_data=f"community:draw:claim:{campaign.id}")],[InlineKeyboardButton(text="🔙 بازگشت",callback_data="community:home")]]
    await _show(c,text,_kb(rows))


@router.callback_query(F.data.regexp(r"^community:draw:claim:\d+$"))
async def lucky_draw_claim(c: CallbackQuery):
    try: cid=int(c.data.rsplit(":",1)[1])
    except ValueError: return await c.answer("کمپین انتخاب‌شده معتبر نیست.",show_alert=True)
    percent=None; claim_id=None
    async with SessionLocal() as session:
        campaign=(await session.execute(select(LuckyDrawCampaign).where(LuckyDrawCampaign.id==cid).with_for_update())).scalar_one_or_none()
        if not campaign or not campaign.active: return await c.answer("این کمپین فعال نیست یا پایان یافته است.",show_alert=True)
        prior=(await session.execute(select(LuckyDrawClaim).where(LuckyDrawClaim.campaign_id==cid,LuckyDrawClaim.telegram_id==c.from_user.id))).scalar_one_or_none()
        if prior: return await c.answer(f"نتیجهٔ شما قبلاً ثبت شده: {prior.discount_percent}%.",show_alert=True)
        odds=_json_dict(campaign.probabilities_json,{})
        try:
            normalized={p:int(odds.get(str(p),odds.get(p,0))) for p in (15,25,50,100)}
            if any(v<0 for v in normalized.values()) or sum(normalized.values())!=100: raise ValueError
        except (TypeError,ValueError): return await c.answer("احتمال‌های کمپین معتبر نیستند؛ لطفاً مدیر را مطلع کنید.",show_alert=True)
        percent=_choose_prize(normalized)
        try:
            async with session.begin_nested():
                claim=LuckyDrawClaim(campaign_id=cid,telegram_id=c.from_user.id,discount_percent=percent,odds_snapshot_json=json.dumps({str(k):v for k,v in normalized.items()},sort_keys=True),config_version=int(campaign.config_version))
                session.add(claim); await session.flush(); claim_id=int(claim.id)
                reward_issue=RewardIssue(source_type="lucky_draw",source_id=claim_id,telegram_id=c.from_user.id,discount_percent=percent,status="awaiting_code")
                session.add(reward_issue); await session.flush(); reward_issue_id=int(reward_issue.id)
            await session.commit()
        except IntegrityError:
            await session.rollback()
            prior=(await session.execute(select(LuckyDrawClaim).where(LuckyDrawClaim.campaign_id==cid,LuckyDrawClaim.telegram_id==c.from_user.id))).scalar_one_or_none()
            if prior: return await c.answer(f"نتیجهٔ شما قبلاً ثبت شده: {prior.discount_percent}%.",show_alert=True)
            return await c.answer("نتیجه ثبت نشد؛ لطفاً دوباره بخش Giveaways را باز کنید.",show_alert=True)
    await notify_admins(c.bot,RewardIssue,reward_issue_id,
        f"🎁 <b>جایزهٔ Giveaways در انتظار تخصیص کد · شمارهٔ {reward_issue_id}</b>\nکمپین شمارهٔ {cid} · جایزه {percent}% · دریافت‌کننده <code>{c.from_user.id}</code>",
        _kb([[InlineKeyboardButton(text="مشاهدهٔ پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{reward_issue_id}")],
             [InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]]))
    await _show(c,f"🎉 نتیجهٔ شما: <b>تخفیف {percent}%</b>!\n\nنتیجه ثبت شده و XP مصرف نشده است. مدیر باید هدیهٔ شخصی سازگار با سیاست تخفیف پنل‌ها را صادر و تحویل دهد.",_kb([[InlineKeyboardButton(text="مشاهدهٔ وضعیت جایزه",callback_data="community:draw")],[InlineKeyboardButton(text="بازگشت",callback_data="community:home")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:draw:list(?::\d+)?$"))
async def admin_draw_list(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    try:
        page = max(0, int(c.data.rsplit(":", 1)[1])) if ":" in c.data else 0
    except ValueError:
        return await c.answer("صفحه در دسترس نیست.", show_alert=True)
    size = PAGE_SIZE
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(LuckyDrawCampaign.id))) or 0)
        pages = max(1, (total + size - 1) // size)
        page = min(page, pages - 1)
        items = (await session.execute(select(LuckyDrawCampaign).order_by(
            LuckyDrawCampaign.created_at.desc(), LuckyDrawCampaign.id.desc()
        ).offset(page * size).limit(size))).scalars().all()
        counts = {int(x.id): int(await session.scalar(select(func.count(LuckyDrawClaim.id)).where(
            LuckyDrawClaim.campaign_id == x.id
        )) or 0) for x in items}
        odds = await _draw_odds(session)
    rows = [[InlineKeyboardButton(
        text=f"{'🟢 فعال' if x.active else '⚪ غیرفعال'} · #{x.id} · {x.label[:24]} · {counts[x.id]} شرکت‌کننده",
        callback_data=f"admin:v77:draw:view:{x.id}",
    )] for x in items]
    nav = []
    if page > 0: nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:v77:draw:list:{page-1}"))
    if page + 1 < pages: nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:v77:draw:list:{page+1}"))
    if nav: rows.append(nav)
    rows += [[InlineKeyboardButton(text="➕ ایجاد کمپین", callback_data="admin:v77:draw:create")],
             [InlineKeyboardButton(text="⚖️ تنظیم احتمال‌های کمپین بعدی", callback_data="admin:v77:draw:odds")],
             [InlineKeyboardButton(text="ابزارهای تکمیلی", callback_data="admin:v77:home")]]
    text = "<b>مدیریت Giveaways</b>\n\nکمپین‌های تازه به‌صورت پیش‌فرض غیرفعال هستند و فقط با اقدام صریح مدیر فعال می‌شوند.\nاحتمال‌های تنظیم‌شده برای کمپین‌های جدید: " + ", ".join(f"{p}%={odds[p]}%" for p in (15,25,50,100))
    if total: text += f"\nPage {page+1}/{pages} · {total} کمپین."
    if not items: text += "\n\nهنوز کمپینی ایجاد نشده است."
    await _show(c, text, _kb(rows))


@router.callback_query(F.data == "admin:v77:draw:odds")
async def admin_draw_odds_start(c: CallbackQuery,state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    async with SessionLocal() as session: odds=await _draw_odds(session)
    if not await _can_start_v77_form(c, state): return
    await state.set_state(V77AdminStates.draw_odds)
    await c.message.edit_text("احتمال‌های کمپین بعدی را مشخص کنید؛ مجموع آن‌ها باید دقیقاً ۱۰۰ باشد. احتمال‌های کمپین‌های قبلی بدون تغییر می‌مانند.\n\nمقادیر فعلی: "+", ".join(f"{p}={odds[p]}" for p in (15,25,50,100))+"\n\nالگو: <code>15=60,25=25,50=12,100=3</code> را بفرستید یا /cancel را ارسال کنید.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data="admin:v77:draw:list")]]))
    await c.answer()


@router.message(V77AdminStates.draw_odds)
async def admin_draw_odds_save(message: Message,state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    if (message.text or "").strip().lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("ویرایش احتمال‌ها لغو شد؛ مقادیر ذخیره‌شده تغییری نکردند.",reply_markup=_kb([[InlineKeyboardButton(text="کمپین‌ها",callback_data="admin:v77:draw:list")]]))
    try: odds=_parse_odds(message.text or "")
    except (ValueError,TypeError) as exc: return await message.answer(str(exc) or "احتمال‌ها معتبر نیستند؛ مجموع باید ۱۰۰ باشد.")
    async with SessionLocal() as session:
        old_version = await _draw_odds_version(session)
        version = old_version + 1
        await set_setting(session,"v77_lucky_draw_odds",json.dumps({str(k):v for k,v in odds.items()},sort_keys=True))
        await set_setting(session,"v77_lucky_draw_odds_version",str(version))
        await write_admin_action(session,actor_telegram_id=message.from_user.id,action="lucky_draw_odds_updated",entity_type="app_setting",details={"odds":odds,"config_version":version,"applies_to":"future_campaigns_only"})
        await session.commit()
    await state.clear(); await message.answer("✅ احتمال‌ها برای کمپین‌های آینده ذخیره شد؛ تنظیمات کمپین‌های موجود بدون تغییر ماند.",reply_markup=_kb([[InlineKeyboardButton(text="کمپین‌ها",callback_data="admin:v77:draw:list")]]))


@router.callback_query(F.data == "admin:v77:draw:create")
async def admin_draw_create_start(c: CallbackQuery,state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    if not await _can_start_v77_form(c, state): return
    await state.set_state(V77AdminStates.draw_label)
    await c.message.edit_text("عنوان کوتاهی برای کمپین رایگان جدید وارد کنید. کمپین ابتدا غیرفعال ساخته می‌شود و باید آن را جداگانه فعال کنید. برای خروج بدون ذخیره /cancel را بفرستید.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data="admin:v77:draw:list")]]))
    await c.answer()


@router.message(V77AdminStates.draw_label)
async def admin_draw_create_save(message: Message,state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    label=(message.text or "").strip()
    if label.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("ایجاد کمپین لغو شد و کمپینی ساخته نشد.",reply_markup=_kb([[InlineKeyboardButton(text="کمپین‌ها",callback_data="admin:v77:draw:list")]]))
    if not label or label.startswith("/") or len(label)>180: return await message.answer("واردکردن عنوان حداکثر ۱۸۰ نویسه‌ای الزامی است؛ یا /cancel را بفرستید.")
    async with SessionLocal() as session:
        odds=await _draw_odds(session)
        config_version=await _draw_odds_version(session)
        campaign=LuckyDrawCampaign(label=label,probabilities_json=json.dumps({str(k):v for k,v in odds.items()},sort_keys=True),config_version=config_version,active=False,created_by_telegram_id=int(message.from_user.id))
        session.add(campaign); await session.flush()
        await write_admin_action(session,actor_telegram_id=message.from_user.id,action="lucky_draw_campaign_created",entity_type="lucky_draw_campaign",entity_id=campaign.id,details={"active":False,"odds":odds})
        await session.commit(); cid=int(campaign.id)
    await state.clear(); await message.answer(f"کمپین شمارهٔ {cid} به‌صورت غیرفعال ایجاد شد. احتمال‌ها: "+", ".join(f"{p}%={odds[p]}%" for p in (15,25,50,100)),reply_markup=_kb([[InlineKeyboardButton(text="فعال‌سازی کمپین",callback_data=f"admin:v77:draw:activate:{cid}")],[InlineKeyboardButton(text="جزئیات کمپین",callback_data=f"admin:v77:draw:view:{cid}")],[InlineKeyboardButton(text="فهرست کمپین‌ها",callback_data="admin:v77:draw:list")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:draw:view:\d+$"))
async def admin_draw_view(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    cid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        campaign=await session.get(LuckyDrawCampaign,cid)
        if not campaign: return await c.answer("کمپین پیدا نشد.",show_alert=True)
        count=int(await session.scalar(select(func.count(LuckyDrawClaim.id)).where(LuckyDrawClaim.campaign_id==cid)) or 0)
        odds=_json_dict(campaign.probabilities_json,{})
    text=f"<b>Giveaways · کمپین شمارهٔ {cid}</b>\n\nعنوان: {escape(campaign.label)}\nوضعیت: {'فعال' if campaign.active else 'غیرفعال'}\nنسخهٔ تنظیمات: {campaign.config_version}\nشرکت‌کنندگان: {count}\n\nاحتمال‌ها: "+", ".join(f"{p}%={int(odds.get(str(p),0))}%" for p in (15,25,50,100))
    rows=[]
    if not campaign.active: rows.append([InlineKeyboardButton(text="✅ فعال‌سازی",callback_data=f"admin:v77:draw:activate:{cid}")])
    else: rows.append([InlineKeyboardButton(text="⛔ غیرفعال‌سازی / پایان",callback_data=f"admin:v77:draw:deactivate:{cid}")])
    rows += [[InlineKeyboardButton(text="کمپین‌ها",callback_data="admin:v77:draw:list")]]
    await _show(c,text,_kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:draw:(activate|deactivate):\d+$"))
async def admin_draw_set_active_preview(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    parts=c.data.split(":"); action=parts[3]; cid=int(parts[4])
    async with SessionLocal() as session:
        campaign=await session.get(LuckyDrawCampaign,cid)
        if not campaign: return await c.answer("کمپین پیدا نشد.",show_alert=True)
        if action == "activate" and campaign.active:
            return await c.answer("این کمپین از قبل فعال است.",show_alert=True)
        if action == "deactivate" and not campaign.active:
            return await c.answer("این کمپین از قبل غیرفعال است.",show_alert=True)
        count=int(await session.scalar(select(func.count(LuckyDrawClaim.id)).where(LuckyDrawClaim.campaign_id==cid)) or 0)
        odds=_json_dict(campaign.probabilities_json,{})
        normalized={p:int(odds.get(str(p),0)) for p in (15,25,50,100)}
        if action == "activate" and (any(v<0 or v>100 for v in normalized.values()) or sum(normalized.values())!=100):
            return await c.answer("احتمال‌های کمپین معتبر نیستند.",show_alert=True)
        active_other=(await session.execute(select(LuckyDrawCampaign).where(LuckyDrawCampaign.active.is_(True),LuckyDrawCampaign.id!=cid))).scalars().all()
    action_label = "فعال‌سازی" if action == "activate" else "پایان‌دادن و غیرفعال‌سازی"
    warning = " یک کمپین فعال دیگر نیز پایان داده خواهد شد." if action == "activate" and active_other else ""
    body=(f"<b>تأیید {action_label} کمپین #{cid}</b>\n\nعنوان: {escape(campaign.label)}\nوضعیت فعلی: {'فعال' if campaign.active else 'غیرفعال'}\nشرکت‌کنندگان: {count}\nاحتمال‌ها: "
          + ", ".join(f"{p}%={normalized[p]}%" for p in (15,25,50,100))
          + f"\n\n{warning} این اقدام برای کاربران پیامی ارسال نمی‌کند و کمپین تازه‌ای نمی‌سازد.")
    await _show(c,body,_kb([
        [InlineKeyboardButton(text="✅ تأیید",callback_data=f"admin:v77:draw:apply:{action}:{cid}")],
        [InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:draw:view:{cid}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v77:draw:apply:(activate|deactivate):\d+$"))
async def admin_draw_set_active_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    parts=c.data.split(":"); action=parts[4]; cid=int(parts[5]); now=utc_now_naive()
    async with SessionLocal() as session:
        # All campaign-state changes share this row lock, including the first activation
        # when there is no active campaign row for SELECT ... FOR UPDATE to lock.
        await session.execute(select(AppSetting.id).where(AppSetting.key=="v77_lucky_draw_activation_lock").with_for_update())
        campaign=(await session.execute(select(LuckyDrawCampaign).where(LuckyDrawCampaign.id==cid).with_for_update())).scalar_one_or_none()
        if not campaign: return await c.answer("کمپین پیدا نشد.",show_alert=True)
        if action=="activate":
            odds=_json_dict(campaign.probabilities_json,{})
            try:
                normalized={p:int(odds.get(str(p),0)) for p in (15,25,50,100)}
                if any(v<0 or v>100 for v in normalized.values()) or sum(normalized.values())!=100: raise ValueError
            except (TypeError,ValueError): return await c.answer("احتمال‌های کمپین معتبر نیستند.",show_alert=True)
            active=(await session.execute(select(LuckyDrawCampaign).where(LuckyDrawCampaign.active.is_(True)).with_for_update())).scalars().all()
            for old in active:
                if old.id != cid:
                    old.active=False; old.deactivated_at=now
                    await write_admin_action(session,actor_telegram_id=c.from_user.id,action="lucky_draw_campaign_deactivated",entity_type="lucky_draw_campaign",entity_id=old.id,details={"active":False,"reason":"replaced_by_another_campaign","replacement_campaign_id":cid,"config_version":old.config_version})
            campaign.active=True; campaign.activated_at=now; campaign.deactivated_at=None
        else:
            if not campaign.active: return await c.answer("این کمپین از قبل غیرفعال است.",show_alert=True)
            campaign.active=False; campaign.deactivated_at=now
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action=f"lucky_draw_campaign_{action}d",entity_type="lucky_draw_campaign",entity_id=cid,details={"active":campaign.active,"config_version":campaign.config_version})
        await session.commit(); active_now=campaign.active
    await _show(c,f"✅ وضعیت کمپین شمارهٔ {cid}: {'فعال' if active_now else 'پایان‌یافته'}. هیچ پیامی برای کاربران ارسال نشد.",_kb([[InlineKeyboardButton(text="جزئیات کمپین",callback_data=f"admin:v77:draw:view:{cid}")],[InlineKeyboardButton(text="کمپین‌ها",callback_data="admin:v77:draw:list")]]))

# ------------------------- Reward issuance/delivery shared by Shop and Draw -------------------------

@router.callback_query(F.data.regexp(r"^admin:v77:rewards:queue:\d+$"))
async def admin_reward_queue(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    page=max(0,int(c.data.rsplit(":",1)[1])); size=PAGE_SIZE
    pending_statuses=("awaiting_code","ready_to_deliver","delivery_failed","delivery_uncertain","sending")
    async with SessionLocal() as session:
        total=int(await session.scalar(select(func.count(RewardIssue.id)).where(RewardIssue.status.in_(pending_statuses))) or 0)
        pages=max(1,(total+size-1)//size); page=min(page,pages-1)
        items=(await session.execute(select(RewardIssue).where(RewardIssue.status.in_(pending_statuses)).order_by(RewardIssue.created_at.asc(),RewardIssue.id.asc()).offset(page*size).limit(size))).scalars().all()
    rows=[[InlineKeyboardButton(text=f"#{x.id} · {admin_status_display_label(x.source_type)} · {x.discount_percent}% · {admin_status_display_label(x.status)} · {x.telegram_id}",callback_data=f"admin:v77:rewards:view:{x.id}")] for x in items]
    nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️ قبلی",callback_data=f"admin:v77:rewards:queue:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="بعدی ➡️",callback_data=f"admin:v77:rewards:queue:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="ابزارهای تکمیلی",callback_data="admin:v77:home")])
    text=f"<b>صف صدور کد هدیه</b> · {total} تعیین‌تکلیف‌نشده\n\nابتدا در بخش مدیریت تخفیف‌ها، هدیهٔ شخصیِ سازگار با پنل‌های واجد شرایط را ایجاد کنید و سپس آن را اینجا تخصیص دهید. ارسال موفق فقط پس از تأیید تلگرام ثبت می‌شود."
    if not items: text += "\n\nپروندهٔ تعیین‌تکلیف‌نشده‌ای وجود ندارد."
    await _show(c,text,_kb(rows))


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:view:\d+$"))
async def admin_reward_view(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    await _clear_v77_state(state)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        issue=await session.get(RewardIssue,iid)
        code=await session.get(DiscountCode,issue.discount_code_id) if issue and issue.discount_code_id else None
    if not issue: return await c.answer("پروندهٔ هدیه پیدا نشد.",show_alert=True)
    text=f"<b>پروندهٔ صدور هدیه #{iid}</b>\n\nمنبع: {escape(admin_status_display_label(issue.source_type))} #{issue.source_id}\nدریافت‌کننده: <code>{issue.telegram_id}</code>\nسطح تخفیف: {issue.discount_percent}%\nوضعیت: {escape(admin_status_display_label(issue.status))}\nوضعیت تحویل: {escape(admin_status_display_label(issue.delivery_state))}\nاطلاع‌رسانی به مدیر: {escape(admin_status_display_label(issue.admin_notification_status))} (تعداد تلاش: {int(issue.admin_notification_attempts or 0)})"
    if issue.admin_notification_error: text += f"\nآخرین خطای اطلاع‌رسانی به مدیر: {escape(issue.admin_notification_error)}"
    if code: text += f"\nهدیهٔ شخصی تخصیص‌یافته: #{code.id} · {escape(code.label or 'هدیهٔ شخصی')} · {'فعال' if code.active else 'غیرفعال'} · پنل‌های واجد شرایط {int(await _reward_code_event_count(code.id))}"
    rows=[]
    if issue.status=="awaiting_code": rows.append([InlineKeyboardButton(text="تخصیص هدیهٔ شخصی موجود",callback_data=f"admin:v77:rewards:assign:{iid}")])
    if issue.status=="ready_to_deliver": rows += [[InlineKeyboardButton(text="📨 تحویل از طریق تلگرام",callback_data=f"admin:v77:rewards:deliver:{iid}")],[InlineKeyboardButton(text="✅ ثبت تحویل دستی",callback_data=f"admin:v77:rewards:manual:{iid}")]]
    if issue.status=="delivery_failed": rows += [[InlineKeyboardButton(text="↻ تلاش دوباره برای تحویل تلگرامی",callback_data=f"admin:v77:rewards:deliver:{iid}")],[InlineKeyboardButton(text="✅ ثبت تحویل دستی",callback_data=f"admin:v77:rewards:manual:{iid}")]]
    sending_stale = issue.status == "sending" and issue.updated_at is not None and utc_now_naive() - issue.updated_at > timedelta(minutes=5)
    if issue.status=="sending":
        text += "\n\nوضعیت تحویل در حال ارسال یا نامشخص است. بدون بررسی گفت‌وگوی کاربر دوباره ارسال نکنید."
        if sending_stale:
            rows.append([InlineKeyboardButton(text="بررسی نتیجهٔ تحویل",callback_data=f"admin:v77:rewards:resolve:{iid}")])
    if issue.status=="delivery_uncertain":
        text += "\n\n⚠️ پاسخ تلگرام قطعی نیست. پیش از ثبت نتیجه با دریافت‌کننده بررسی کنید. تا روشن‌شدن وضعیت، ارسال دوباره یا بازپرداخت خودکار مجاز نیست."
        rows.append([InlineKeyboardButton(text="بررسی نتیجهٔ تحویل",callback_data=f"admin:v77:rewards:resolve:{iid}")])
    if issue.source_type=="shop" and issue.status in {"awaiting_code","ready_to_deliver","delivery_failed"} and issue.delivery_state not in {"sent","manually_delivered","sending"}:
        rows.append([InlineKeyboardButton(text="بازگرداندن XP کسرشده (با ذکر دلیل)",callback_data=f"admin:v77:rewards:refund:{iid}")])
    rows.append([InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")])
    await _show(c,text,_kb(rows))


async def _reward_code_event_count(code_id: int) -> int:
    from app.db.models import DiscountCodeEvent
    async with SessionLocal() as session:
        return int(await session.scalar(select(func.count(DiscountCodeEvent.id)).where(DiscountCodeEvent.discount_code_id==int(code_id))) or 0)


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:assign:\d+$"))
async def admin_reward_assign_start(c: CallbackQuery,state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        issue=await session.get(RewardIssue,iid)
        if not issue or issue.status!="awaiting_code": return await c.answer("این پرونده دیگر در انتظار تخصیص کد نیست.",show_alert=True)
    if not await _can_start_v77_form(c, state): return
    await state.update_data(v77_reward_issue_id=iid); await state.set_state(V77AdminStates.reward_code)
    await c.message.edit_text(f"پروندهٔ هدیهٔ شمارهٔ {iid} به یک کد تخفیف شخصیِ موجود و سازگار برای کاربر {issue.telegram_id} با مقدار دقیق {issue.discount_percent}% نیاز دارد.\n\nشناسهٔ عددی تخفیف (برای نمونه <code>#123</code>) یا کد دقیق آن را وارد کنید. هدیه باید فعال، شخصی، مختص همین دریافت‌کننده، یک‌بارمصرف، استفاده‌نشده و مرتبط با دست‌کم یک پنل باشد. ابتدا آن را در بخش مدیریت تخفیف‌ها ایجاد و تنظیم کنید.\n\n/cancel to stop.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data="admin:v77:rewards:queue:0")]]))
    await c.answer()


@router.message(V77AdminStates.reward_code)
async def admin_reward_assign_save(message: Message,state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    raw=(message.text or "").strip(); data=await state.get_data(); iid=int(data.get("v77_reward_issue_id") or 0)
    if raw.lower() in {"/cancel","cancel"}:
        await state.clear(); return await message.answer("تخصیص لغو شد.",reply_markup=_kb([[InlineKeyboardButton(text="صف پرونده‌های هدیه",callback_data="admin:v77:rewards:queue:0")]]))
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if not issue or issue.status!="awaiting_code": await state.clear(); return await message.answer("این پرونده دیگر در انتظار تخصیص کد نیست.")
        from app.db.models import DiscountCodeEvent
        if raw.startswith("#"): raw=raw[1:].strip()
        code=None
        if raw.isdigit(): code=(await session.execute(select(DiscountCode).where(DiscountCode.id==int(raw)).with_for_update())).scalar_one_or_none()
        else: code=(await session.execute(select(DiscountCode).where(DiscountCode.code==raw).with_for_update())).scalar_one_or_none()
        if not code: return await message.answer("کد تخفیف سازگاری پیدا نشد. شناسهٔ موجود یا کد دقیق را وارد کنید.")
        if not code.active or code.kind!="personal" or int(code.recipient_telegram_id or 0)!=int(issue.telegram_id):
            return await message.answer("هدیه باید فعال، شخصی و دقیقاً مختص همین کاربر باشد.")
        if code.discount_type!="percent" or int(code.discount_value)!=int(issue.discount_percent):
            return await message.answer(f"هدیه باید دقیقاً شامل {issue.discount_percent}% تخفیف درصدی باشد.")
        if int(code.max_redemptions or 0)!=1 or code.usage_policy!="once_total" or code.accepted_at is not None:
            return await message.answer("هدیهٔ شخصی باید یک‌بارمصرف، دارای سقف استفادهٔ کلی یک‌بار و هنوز پذیرفته‌نشده باشد.")
        event_count=int(await session.scalar(select(func.count(DiscountCodeEvent.id)).where(DiscountCodeEvent.discount_code_id==code.id)) or 0)
        if event_count<1: return await message.answer("این هدیه به هیچ پنل واجد شرایطی اختصاص ندارد. ابتدا پنل‌های مجاز را در بخش مدیریت تخفیف‌ها مشخص کنید.")
        used_elsewhere=(await session.execute(select(RewardIssue.id).where(RewardIssue.discount_code_id==code.id,RewardIssue.id!=iid).limit(1))).scalar_one_or_none()
        if used_elsewhere is not None: return await message.answer("این هدیهٔ شخصی قبلاً به پروندهٔ دیگری از فروشگاه یا Giveaways تخصیص یافته است.")
        issue.discount_code_id=int(code.id); issue.assigned_by_telegram_id=int(message.from_user.id); issue.assigned_at=utc_now_naive(); issue.status="ready_to_deliver"; issue.updated_at=utc_now_naive()
        reward_recipient=int(issue.telegram_id); reward_percent=int(issue.discount_percent)
        await write_admin_action(session,actor_telegram_id=message.from_user.id,action="v77_reward_code_assigned",entity_type="reward_issue",entity_id=iid,details={"source_type":issue.source_type,"source_id":issue.source_id,"discount_code_id":code.id,"telegram_id":issue.telegram_id,"discount_percent":issue.discount_percent})
        try:
            await session.commit()
        except IntegrityError:
            await session.rollback()
            return await message.answer("این کد تخفیف هم‌زمان به پروندهٔ دیگری تخصیص یافته است. کد سازگار دیگری انتخاب کنید.")
    try:
        await message.bot.send_message(reward_recipient,f"🎁 هدیهٔ تخفیف {reward_percent}% برای شما آماده‌سازی شده است و هنوز تحویل نشده. پس از ارسال یا ثبت تحویل، وضعیت آن در XP شاپ به‌روزرسانی می‌شود.")
    except Exception:
        logger.info("Could not notify reward recipient that a code was prepared; issue_id=%s",iid)
    await state.clear(); await message.answer("✅ هدیهٔ شخصی سازگار تخصیص یافت. تلاش شد به کاربر اطلاع داده شود؛ اما هدیه هنوز تحویل نشده است.",reply_markup=_kb([[InlineKeyboardButton(text="مشاهدهٔ هدیه",callback_data=f"admin:v77:rewards:view:{iid}")],[InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:deliver:\d+$"))
async def admin_reward_deliver(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1]); tg_id=None; code_id=None; source_type=None; percent=None
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if not issue or issue.status not in {"ready_to_deliver","delivery_failed"} or issue.delivery_state in {"sending","sent","manually_delivered"}:
            return await c.answer("در وضعیت فعلی، تلاش مجدد برای تحویل ایمن نیست.",show_alert=True)
        code=await session.get(DiscountCode,issue.discount_code_id) if issue.discount_code_id else None
        if not code or not code.active or code.kind!="personal" or int(code.recipient_telegram_id or 0)!=int(issue.telegram_id):
            return await c.answer("هدیهٔ شخصی تخصیص‌یافته دیگر معتبر نیست؛ تخصیص کد را بررسی کنید.",show_alert=True)
        if code.accepted_at is not None:
            return await c.answer("این هدیهٔ شخصی قبلاً پذیرفته شده است؛ آن را دوباره ارسال نکنید.",show_alert=True)
        issue.delivery_state="sending"; issue.status="sending"; issue.delivery_error=None; issue.updated_at=utc_now_naive()
        tg_id=int(issue.telegram_id); code_id=int(code.id); source_type=issue.source_type; percent=int(issue.discount_percent)
        await session.commit()
    try:
        me=await c.bot.get_me()
        if not me.username: raise RuntimeError("نام کاربری ربات در دسترس نیست")
        from app.db.models import DiscountCode
        async with SessionLocal() as session:
            code=await session.get(DiscountCode,code_id)
            label=(code.label if code else None) or f"{int((await c.bot.get_me()).id)}"
        link=f"https://t.me/{me.username}?start=reward_{code_id}"
        await c.bot.send_message(tg_id,
            f"🎁 <b>هدیهٔ شخصی {percent}% تخفیف آماده است.</b>\n\nبرای فعال‌کردن آن و دیدن پنل‌های واجد شرایط، دکمهٔ زیر را بزنید. محدودیت‌ها و تعداد استفاده مطابق تنظیمات همین هدیه است.",
            reply_markup=_kb([[InlineKeyboardButton(text="🎟 دریافت هدیه",url=link)]]))
        delivery_state="sent"; new_status="delivered"; error=None
    except Exception as exc:
        logger.info("V77 reward delivery attempt did not complete normally; issue_id=%s exception=%s",iid,type(exc).__name__)
        error=type(exc).__name__[:200]
        exc_name=type(exc).__name__
        # A clear Bot API rejection means no message was accepted; network/server
        # timeouts are ambiguous and must not be blindly retried (duplicate risk).
        definitive_rejections={"TelegramForbiddenError","TelegramBadRequest","TelegramNotFound","TelegramUnauthorizedError","TelegramRetryAfter","TelegramMigrateToChat"}
        if exc_name in definitive_rejections:
            delivery_state="delivery_failed"; new_status="delivery_failed"
        else:
            delivery_state="uncertain"; new_status="delivery_uncertain"
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if issue and issue.status=="sending":
            issue.delivery_state=delivery_state; issue.status=new_status; issue.delivery_error=error; issue.delivered_at=utc_now_naive() if new_status=="delivered" else None; issue.updated_at=utc_now_naive()
            if issue.source_type=="shop" and new_status=="delivered":
                req=await session.get(ShopRequest,issue.source_id)
                if req and req.status=="awaiting_code": req.status="delivered"; req.updated_at=utc_now_naive()
            await write_admin_action(session,actor_telegram_id=c.from_user.id,action="v77_reward_delivery_result",entity_type="reward_issue",entity_id=iid,details={"status":new_status,"source_type":issue.source_type,"telegram_id":tg_id,"error_type":error})
            await session.commit()
    if new_status == "delivered":
        outcome_text = "✅ تلگرام پیام تحویل را پذیرفت."
    elif new_status == "delivery_uncertain":
        outcome_text = "⚠️ پاسخ تلگرام قطعی نیست. هدیه به‌عنوان تحویل‌شده ثبت نشده است؛ پیش از تلاش مجدد یا بازپرداخت، وضعیت را با دریافت‌کننده بررسی کنید."
    else:
        outcome_text = "⚠️ تلگرام تلاش برای تحویل را نپذیرفت. هدیه به‌عنوان تحویل‌شده ثبت نشده است؛ پیش از تلاش مجدد یا ثبت تحویل دستی، پرونده را بررسی کنید."
    await _show(c, outcome_text, _kb([[InlineKeyboardButton(text="جزئیات پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{iid}")],[InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:manual:\d+$"))
async def admin_reward_manual_delivered(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if not issue or issue.status not in {"ready_to_deliver","delivery_failed"} or issue.delivery_state in {"sending","sent","manually_delivered"}:
            return await c.answer("در وضعیت فعلی نمی‌توان تحویل دستی این هدیه را ثبت کرد.",show_alert=True)
        issue.status="delivered"; issue.delivery_state="manually_delivered"; issue.delivered_at=utc_now_naive(); issue.updated_at=utc_now_naive()
        if issue.source_type=="shop":
            req=await session.get(ShopRequest,issue.source_id)
            if req and req.status=="awaiting_code": req.status="delivered"; req.updated_at=utc_now_naive()
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="v77_reward_manually_marked_delivered",entity_type="reward_issue",entity_id=iid,details={"source_type":issue.source_type,"telegram_id":issue.telegram_id})
        await session.commit()
    await _show(c,"✅ تحویل دستی ثبت شد. این وضعیت بر اساس تأیید مدیر ثبت شده و به معنی ارسال پیام از طریق تلگرام نیست.",_kb([[InlineKeyboardButton(text="جزئیات پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{iid}")],[InlineKeyboardButton(text="صف پرونده‌ها",callback_data="admin:v77:rewards:queue:0")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:resolve:\d+$"))
async def admin_reward_resolve_preview(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session: issue=await session.get(RewardIssue,iid)
    if not issue or not (issue.status == "delivery_uncertain" or (issue.status == "sending" and issue.updated_at and utc_now_naive() - issue.updated_at > timedelta(minutes=5))):
        return await c.answer("این پرونده در انتظار بررسی ایمن وضعیت تحویل نیست.",show_alert=True)
    await _show(c,"<b>تعیین وضعیت نهایی تحویل</b>\n\nابتدا از دریافت‌کننده یا مدرکی معتبر وضعیت را بررسی کنید و سپس نتیجهٔ تأییدشده را انتخاب کنید. این اقدام بر اساس تأیید مدیر ثبت می‌شود و رسید تحویل پیام را از تلگرام دریافت نمی‌کند.",_kb([
        [InlineKeyboardButton(text="✅ تحویل‌شدن تأیید شد",callback_data=f"admin:v78:rewards:resolve-delivered:{iid}")],
        [InlineKeyboardButton(text="❌ تحویل‌نشدن تأیید شد",callback_data=f"admin:v77:rewards:resolve-confirm:{iid}")],
        [InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:rewards:view:{iid}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v78:rewards:resolve-delivered:\d+$"))
async def admin_reward_resolve_delivered_preview(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session: issue=await session.get(RewardIssue,iid)
    if not issue or not (issue.status == "delivery_uncertain" or (issue.status == "sending" and issue.updated_at and utc_now_naive() - issue.updated_at > timedelta(minutes=5))):
        return await c.answer("این پرونده در انتظار بررسی ایمن وضعیت تحویل نیست.",show_alert=True)
    await _show(c,f"<b>تأیید دریافت هدیهٔ شمارهٔ {iid}</b>\n\nدریافت‌کننده: <code>{issue.telegram_id}</code>\n\nفقط زمانی تأیید کنید که دریافت واقعی پیام یا پیوند هدیه را بررسی کرده‌اید. پرونده و درخواست فروشگاه مرتبط تحویل‌شده ثبت می‌شوند؛ مقدار XP تغییری نمی‌کند.",_kb([
        [InlineKeyboardButton(text="✅ تأیید تحویل",callback_data=f"admin:v78:rewards:resolve-delivered-confirm:{iid}")],
        [InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:rewards:view:{iid}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v78:rewards:resolve-delivered-confirm:\d+$"))
async def admin_reward_resolve_delivered_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1]); now=utc_now_naive()
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        stale_sending=bool(issue and issue.status=="sending" and issue.updated_at and now-issue.updated_at>timedelta(minutes=5))
        if not issue or not (issue.status=="delivery_uncertain" or stale_sending):
            return await c.answer("این پرونده دیگر در انتظار تعیین وضعیت تحویل نیست.",show_alert=True)
        issue.status="delivered"; issue.delivery_state="verified_delivered"; issue.delivered_at=now; issue.updated_at=now
        if issue.source_type=="shop":
            req=(await session.execute(select(ShopRequest).where(ShopRequest.id==int(issue.source_id)).with_for_update())).scalar_one_or_none()
            if req and req.status=="awaiting_code": req.status="delivered"; req.updated_at=now
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="v78_reward_delivery_verified_delivered",entity_type="reward_issue",entity_id=iid,details={"source_type":issue.source_type,"source_id":issue.source_id,"telegram_id":issue.telegram_id,"verification":"administrator_confirmed"})
        await session.commit()
    await _show(c,"✅ تحویل تأییدشده ثبت شد. هیچ پیامی دوباره ارسال نشد و مقدار XP تغییری نکرد.",_kb([[InlineKeyboardButton(text="جزئیات پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{iid}")],[InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]]))


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:resolve-confirm:\d+$"))
async def admin_reward_resolve_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if not issue or not (issue.status == "delivery_uncertain" or (issue.status == "sending" and issue.updated_at and utc_now_naive() - issue.updated_at > timedelta(minutes=5))):
            return await c.answer("این پرونده در انتظار بررسی ایمن وضعیت تحویل نیست.",show_alert=True)
        issue.status="delivery_failed"; issue.delivery_state="verified_not_delivered"; issue.updated_at=utc_now_naive()
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="v77_reward_delivery_nonreceipt_verified",entity_type="reward_issue",entity_id=iid,details={"source_type":issue.source_type,"source_id":issue.source_id,"telegram_id":issue.telegram_id})
        await session.commit()
    await _show(c,"✅ تحویل‌نشدن ثبت شد. اکنون امکان تلاش دوباره یا (فقط برای XP شاپ) بازپرداخت وجود دارد.",_kb([[InlineKeyboardButton(text="جزئیات پروندهٔ هدیه",callback_data=f"admin:v77:rewards:view:{iid}")],[InlineKeyboardButton(text="صف صدور هدایا",callback_data="admin:v77:rewards:queue:0")]]))


async def _refund_blocked_by_accepted_code(session, issue: RewardIssue) -> bool:
    """Do not credit XP back if the assigned code has already been accepted by its recipient."""
    if issue.discount_code_id is None:
        return False
    assigned = await session.get(DiscountCode, issue.discount_code_id, with_for_update=True)
    return bool(assigned and assigned.accepted_at is not None)


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:refund:\d+$"))
async def admin_reward_refund_start(c: CallbackQuery,state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    iid=int(c.data.rsplit(":",1)[1])
    async with SessionLocal() as session:
        issue=await session.get(RewardIssue,iid)
        if not issue or issue.source_type!="shop" or issue.status not in {"awaiting_code","ready_to_deliver","delivery_failed"} or issue.delivery_state in {"sending","sent","manually_delivered"}:
            return await c.answer("پس از تحویل یا تا زمانی که وضعیت تحویل نامشخص است، بازپرداخت امکان‌پذیر نیست.",show_alert=True)
        if await _refund_blocked_by_accepted_code(session, issue):
            return await c.answer("کد شخصی تخصیص‌یافته قبلاً پذیرفته شده است. پیش از تعیین تکلیف درخواست، استفاده از آن را بررسی کنید؛ بازپرداخت خودکار مسدود است.",show_alert=True)
    if not await _can_start_v77_form(c, state): return
    await state.update_data(v77_refund_issue_id=iid); await state.set_state(V77AdminStates.refund_reason)
    await c.message.edit_text(f"پروندهٔ صدور هدیه #{iid}: دلیل کوتاه و قابل پیگیری برای بازپرداخت را وارد کنید. دقیقاً همان مقدار XP ثبت‌شده برای این درخواست، فقط یک بار به سوابق XP بازگردانده می‌شود. برای انصراف بدون تغییر /cancel را بفرستید.",reply_markup=_kb([[InlineKeyboardButton(text="انصراف",callback_data="admin:v77:rewards:queue:0")]]))
    await c.answer()


@router.message(V77AdminStates.refund_reason)
async def admin_reward_refund_save(message: Message,state: FSMContext):
    if not await _is_admin(message.from_user.id): return await state.clear()
    reason=(message.text or "").strip()
    if reason.lower() in {"/cancel", "cancel", "لغو"}:
        await state.clear(); return await message.answer("بازپرداخت لغو شد؛ موجودی XP تغییری نکرد.",reply_markup=_kb([[InlineKeyboardButton(text="صف پرونده‌های هدیه",callback_data="admin:v77:rewards:queue:0")]]))
    data=await state.get_data(); iid=int(data.get("v77_refund_issue_id") or 0)
    if not reason or reason.startswith("/") or len(reason)>500: return await message.answer("دلیل بازپرداخت حداکثر در ۵۰۰ نویسه الزامی است؛ یا /cancel را بفرستید.")
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if not issue or issue.source_type!="shop" or issue.status not in {"awaiting_code", "ready_to_deliver", "delivery_failed"} or issue.delivery_state in {"sending", "sent", "manually_delivered"}:
            await state.clear(); return await message.answer("این پرونده دیگر واجد شرایط بازپرداخت نیست.")
        if await _refund_blocked_by_accepted_code(session, issue):
            await state.clear(); return await message.answer("کد شخصی تخصیص‌یافته قبلاً پذیرفته شده است؛ بازپرداخت خودکار تا بررسی دستی مسدود است.")
        req=(await session.execute(select(ShopRequest).where(ShopRequest.id==issue.source_id).with_for_update())).scalar_one_or_none()
        if not req or req.status != "awaiting_code":
            await state.clear(); return await message.answer("درخواست فروشگاه واجد شرایط بازپرداخت نیست.")
    await state.update_data(v77_refund_reason=reason)
    await state.set_state(V77AdminStates.refund_confirm)
    await message.answer(f"<b>تأیید بازپرداخت XP برای پروندهٔ هدیهٔ {iid}</b>\n\nمقدار XP قابل بازگشت: <b>{int(req.xp_cost)}</b>\nدلیل: {escape(reason)}\n\nثبت بازگشت در سوابق تکرارناپذیر است؛ هدیهٔ تخصیص‌یافته‌ای که هنوز پذیرفته نشده باشد غیرفعال خواهد شد.", reply_markup=_kb([
        [InlineKeyboardButton(text="✅ تأیید بازپرداخت",callback_data=f"admin:v77:rewards:refund-confirm:{iid}")],
        [InlineKeyboardButton(text="انصراف",callback_data=f"admin:v77:rewards:view:{iid}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:v77:rewards:refund-confirm:\d+$"))
async def admin_reward_refund_confirm(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id): return await c.answer("دسترسی مجاز نیست.",show_alert=True)
    data=await state.get_data()
    try: iid=int(c.data.rsplit(":",1)[1]); expected=int(data.get("v77_refund_issue_id") or 0)
    except (TypeError,ValueError): return await c.answer("مهلت تأیید بازپرداخت پایان یافته است؛ پروندهٔ هدیه را دوباره باز کنید.",show_alert=True)
    reason=str(data.get("v77_refund_reason") or "").strip()
    if iid != expected or not reason: return await c.answer("مهلت تأیید بازپرداخت پایان یافته است؛ پروندهٔ هدیه را دوباره باز کنید.",show_alert=True)
    async with SessionLocal() as session:
        issue=(await session.execute(select(RewardIssue).where(RewardIssue.id==iid).with_for_update())).scalar_one_or_none()
        if not issue or issue.source_type!="shop" or issue.status not in {"awaiting_code", "ready_to_deliver", "delivery_failed"} or issue.delivery_state in {"sending", "sent", "manually_delivered"}:
            await state.clear(); return await c.answer("این پرونده دیگر واجد شرایط بازپرداخت نیست.",show_alert=True)
        if await _refund_blocked_by_accepted_code(session, issue):
            await state.clear(); return await c.answer("کد شخصی تخصیص‌یافته قبلاً پذیرفته شده است؛ بازپرداخت خودکار تا بررسی دستی مسدود است.",show_alert=True)
        req=(await session.execute(select(ShopRequest).where(ShopRequest.id==issue.source_id).with_for_update())).scalar_one_or_none()
        if not req or req.status != "awaiting_code":
            await state.clear(); return await c.answer("درخواست فروشگاه واجد شرایط بازپرداخت نیست.",show_alert=True)
        credit=await _create_ledger_award(session,telegram_id=int(req.telegram_id),points=int(req.xp_cost),award_type="shop_redemption_refund",award_key=f"my-shop-request:{req.id}:refund",source_id=str(req.id),note="Refund for unfulfilled My Shop reward")
        if not credit: await state.clear(); return await c.answer("رکورد بازپرداخت از قبل وجود دارد؛ اعتبار تکراری اضافه نشد.",show_alert=True)
        assigned_code_deactivated = False
        if issue.discount_code_id is not None:
            assigned_code = await session.get(DiscountCode, issue.discount_code_id, with_for_update=True)
            if assigned_code and assigned_code.accepted_at is None:
                assigned_code.active = False
                assigned_code.disabled_at = utc_now_naive()
                assigned_code.disabled_reason = "My Shop reward refunded before delivery"
                assigned_code_deactivated = True
        req.status="refunded"; req.updated_at=utc_now_naive(); issue.status="refunded"; issue.delivery_state="refunded"; issue.updated_at=utc_now_naive()
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="my_shop_xp_refunded",entity_type="shop_request",entity_id=req.id,details={"reward_issue_id":iid,"xp_credited":req.xp_cost,"assigned_code_deactivated":assigned_code_deactivated,"reason":reason[:300]})
        target=req.telegram_id; points=req.xp_cost; await session.commit()
    await state.clear()
    try: await c.bot.send_message(target,f"بابت عدم امکان صدور/تحویل هدیه، {points} XP به دفتر امتیاز شما بازگردانده شد.")
    except Exception: logger.info("Could not notify user about shop refund; issue_id=%s",iid)
    await _show(c,f"✅ مقدار {points} XP برای پروندهٔ هدیهٔ {iid} بازگردانده شد و سابقهٔ مالی و مدیریتی ثبت شد.",_kb([[InlineKeyboardButton(text="صف پرونده‌های هدیه",callback_data="admin:v77:rewards:queue:0")]]))

