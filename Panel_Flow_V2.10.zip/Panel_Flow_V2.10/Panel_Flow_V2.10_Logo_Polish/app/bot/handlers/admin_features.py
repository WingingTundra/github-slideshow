"""Operational dashboard and admin settings utilities."""
from __future__ import annotations

from html import escape
from io import BytesIO
from pathlib import Path
import logging
import shutil
import asyncio

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, CopyTextButton, InlineKeyboardButton, InlineKeyboardMarkup
from sqlalchemy import func, select

from app.bot.keyboards import admin_menu
from app.config import settings
from app.db.models import (
    AdminAnnouncement, Booking, BlockedUser, Event, EventStatus, Payment,
    PaymentStatus, RegistrationStatus, RewardIssue, ShopRequest, User, UserModerationRecord, UserRole, WaitlistEntry,
    DiscountRedemption, ModerationStatus, Question, Review, TopicSuggestion,
)
from app.db.session import SessionLocal
from app.services.upload_quota import upload_storage_usage_bytes
from app.time_utils import utc_now_naive

router = Router()
logger = logging.getLogger(__name__)


async def _admin(tg_id: int) -> bool:
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(tg_id)


@router.callback_query(F.data == "admin:attention")
async def admin_attention_center(c: CallbackQuery, state: FSMContext):
    """One place for actionable user-submitted work; every count uses live DB state."""
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    async with SessionLocal() as session:
        pending_receipts = int(await session.scalar(
            select(func.count(Payment.id)).join(Booking).where(
                Payment.status == PaymentStatus.PENDING,
                Booking.status == RegistrationStatus.PENDING_VERIFICATION,
            )
        ) or 0)
        pending_discounts = int(await session.scalar(
            select(func.count(DiscountRedemption.id)).where(DiscountRedemption.status == "pending")
        ) or 0)
        pending_panel_submissions = int(await session.scalar(
            select(func.count(Event.id)).where(
                Event.submission_status == "submitted", Event.status == EventStatus.DRAFT,
                Event.archived.is_(False),
            )
        ) or 0)
        pending_questions = int(await session.scalar(
            select(func.count(Question.id)).where(
                Question.status == ModerationStatus.PENDING,
                Question.category == "question",
            )
        ) or 0)
        pending_topics = int(await session.scalar(
            select(func.count(TopicSuggestion.id)).where(TopicSuggestion.status == "pending")
        ) or 0)
        pending_reviews = int(await session.scalar(
            select(func.count(Review.id)).where(Review.status == ModerationStatus.PENDING)
        ) or 0)
        pending_shop = int(await session.scalar(
            select(func.count(ShopRequest.id)).where(ShopRequest.status == "pending")
        ) or 0)
        open_rewards = int(await session.scalar(
            select(func.count(RewardIssue.id)).where(RewardIssue.status.in_(
                ("awaiting_code", "ready_to_deliver", "delivery_failed", "delivery_uncertain", "sending")
            ))
        ) or 0)
        host_alerts = int(await session.scalar(
            select(func.count(Event.id)).where(
                Event.submission_status.in_(("approved", "rejected")),
                Event.submission_notification_status.in_(("pending", "failed", "sending")),
            )
        ) or 0)
        active_broadcasts = int(await session.scalar(
            select(func.count(AdminAnnouncement.id)).where(AdminAnnouncement.status.in_(("sending", "partial")))
        ) or 0)
    items = [
        ("🧾 رسیدهای پرداخت", pending_receipts, "admin:pending_payments:page:0"),
        ("🎟 درخواست‌های تخفیف", pending_discounts, "admin:discount:requests:page:0"),
        ("📋 پنل‌های ارسالی", pending_panel_submissions, "admin:console:reviews"),
        ("❓ سؤال‌های پیشنهادی", pending_questions, "admin:questions"),
        ("🗳 پیشنهاد موضوع‌ها", pending_topics, "admin:topics"),
        ("📝 بازخوردهای کاربران", pending_reviews, "admin:reviews"),
        ("🛍 درخواست‌های XP شاپ", pending_shop, "admin:v77:shop:queue:0"),
        ("🎁 جوایز نیازمند اقدام", open_rewards, "admin:v77:rewards:queue:0"),
        ("🔔 اطلاع‌رسانی‌های میزبان", host_alerts, "admin:console:host-notifications:page:0"),
        ("📣 اعلان‌های نیمه‌تمام", active_broadcasts, "admin:announcements"),
    ]
    total = sum(count for _, count, _ in items)
    def fa(value: int) -> str:
        return f"{int(value):,}".replace(",", "٬").translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))
    rows = []
    for label, count, callback in items:
        rows.append([InlineKeyboardButton(text=f"{label} · {fa(count)}", callback_data=callback)])
    rows.append([InlineKeyboardButton(text="🔄 به‌روزرسانی", callback_data="admin:attention")])
    rows.append([InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")])
    body = (
        "<b>📥 مرکز رسیدگی</b>\n"
        "<i>مواردی که برای بررسی یا اقدام مدیر در صف هستند.</i>\n\n"
        f"موارد در انتظار رسیدگی: <b>{fa(total)}</b>\n\n"
        + "\n".join(f"• {label}: <b>{fa(count)}</b>" for label, count, _ in items)
    )
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data == "admin:settings:about_qr")
async def admin_about_deep_link_qr(c: CallbackQuery):
    """Create the public About deep link and QR on demand, without storing a file."""
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not c.message or getattr(c.message.chat, "type", None) != "private":
        return await c.answer("برای جلوگیری از انتشار ناخواسته، لینک و QR را در گفت‌وگوی خصوصی ربات باز کنید.", show_alert=True)
    try:
        bot_user = await c.bot.get_me()
    except Exception:
        return await c.answer("دریافت نام کاربری ربات ممکن نشد؛ دوباره تلاش کنید.", show_alert=True)
    username = str(getattr(bot_user, "username", "") or "").strip().lstrip("@")
    if not username:
        return await c.answer("برای ساخت لینک عمومی، ربات باید نام کاربری داشته باشد.", show_alert=True)
    deep_link = f"https://t.me/{username}?start=about"
    try:
        import qrcode
        qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=4)
        qr.add_data(deep_link)
        qr.make(fit=True)
        image = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        image.save(buffer, format="PNG")
        photo = BufferedInputFile(buffer.getvalue(), filename="panel-flow-about-qr.png")
    except Exception:
        logger.exception("Could not generate About deep-link QR for admin")
        return await c.answer("ساخت QR ناموفق بود؛ لینک مستقیم را از تنظیمات دوباره باز کنید.", show_alert=True)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 کپی لینک About", copy_text=CopyTextButton(text=deep_link)),
         InlineKeyboardButton(text="🔗 باز کردن About", url=deep_link)],
        [InlineKeyboardButton(text="⚙️ تنظیمات ربات", callback_data="admin:settings")],
    ])
    await c.message.answer_photo(
        photo=photo,
        caption=("<b>لینک عمومی About Panel Flow</b>\n\n"
                 f"<code>{escape(deep_link)}</code>\n\n"
                 "این لینک پیش از ثبت‌نام، معرفی Panel Flow و لینک‌های رسمی را نمایش می‌دهد. "
                 "QR به‌صورت موقت ساخته شده و روی سرور ذخیره نمی‌شود."),
        reply_markup=keyboard,
    )
    await c.answer("لینک و QR آماده شد.")


@router.callback_query(F.data == "admin:dashboard")
async def operational_dashboard(c: CallbackQuery, state: FSMContext):
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    async with SessionLocal() as session:
        now = utc_now_naive()
        registered_users = int(await session.scalar(select(func.count(User.id)).where(User.is_bot.is_(False))) or 0)
        admin_count = int(await session.scalar(select(func.count(User.id)).where(User.role == UserRole.SUPER_ADMIN, User.is_bot.is_(False))) or 0)
        host_count = int(await session.scalar(select(func.count(User.id)).where(User.role == UserRole.HOST, User.is_bot.is_(False))) or 0)
        published = int((await session.execute(select(func.count(Event.id)).where(
            Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)))).scalar_one())
        pending_reviews = int(await session.scalar(select(func.count(Event.id)).where(
            Event.submission_status == "submitted", Event.status == EventStatus.DRAFT, Event.archived.is_(False))) or 0)
        pending_receipts = int((await session.execute(select(func.count(Payment.id)).join(Booking)
            .where(Payment.status == PaymentStatus.PENDING,
                   Booking.status == RegistrationStatus.PENDING_VERIFICATION))).scalar_one())
        unresolved_cases = int((await session.execute(select(func.count(Booking.id)).where(
            Booking.cancellation_resolution == "action_required"))).scalar_one())
        waitlisted_people = int((await session.execute(
            select(func.count(WaitlistEntry.id)).where(WaitlistEntry.status.in_(("waiting", "invited", "inviting")))
        )).scalar_one())
        needs_attention = int((await session.execute(select(func.count(Booking.id)).where(
            Booking.status == RegistrationStatus.PENDING_PAYMENT))).scalar_one())
        blocked_count = int(await session.scalar(select(func.count(BlockedUser.telegram_id))) or 0)
        suspended_count = int(await session.scalar(select(func.count(func.distinct(UserModerationRecord.target_telegram_id))).where(
            UserModerationRecord.action == "suspension", UserModerationRecord.scope == "account",
            UserModerationRecord.active.is_(True),
            (UserModerationRecord.expires_at.is_(None) | (UserModerationRecord.expires_at > now)))) or 0)
        announcements_attention = int(await session.scalar(select(func.count(AdminAnnouncement.id)).where(
            AdminAnnouncement.status.in_(("sending", "partial")))) or 0)
        pending_shop_requests = int(await session.scalar(select(func.count(ShopRequest.id)).where(ShopRequest.status == "pending")) or 0)
        pending_reward_issues = int(await session.scalar(select(func.count(RewardIssue.id)).where(
            RewardIssue.status.in_(("awaiting_code", "ready_to_deliver", "delivery_failed", "delivery_uncertain", "sending")))) or 0)
        uncertain_reward_deliveries = int(await session.scalar(select(func.count(RewardIssue.id)).where(
            RewardIssue.status.in_(("delivery_uncertain", "sending")))) or 0)
        host_notification_issues = int(await session.scalar(select(func.count(Event.id)).where(
            Event.submission_status.in_(("approved", "rejected")),
            Event.submission_notification_status.in_(("pending", "failed", "sending")))) or 0)
        recent_users = (await session.execute(select(User).where(User.is_bot.is_(False)).order_by(
            User.created_at.desc(), User.id.desc()).limit(4))).scalars().all()
        recent_moderation = (await session.execute(select(UserModerationRecord).order_by(
            UserModerationRecord.created_at.desc(), UserModerationRecord.id.desc()).limit(3))).scalars().all()
    root = Path(settings.upload_dir)
    # The snapshot includes active uploads' reservations and reclaims stale crash
    # artifacts under the same lock used by upload creation/publication.
    used_bytes = await asyncio.to_thread(upload_storage_usage_bytes, root)
    try:
        disk_free = shutil.disk_usage(root).free if root.exists() and root.is_dir() else None
    except OSError:
        disk_free = None
    quota_mb = max(0, int(settings.max_upload_storage_mb))

    def fa_number(value) -> str:
        raw = f"{int(value):,}".replace(",", "٬")
        return raw.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))

    def fa_decimal(value: float, places: int = 1) -> str:
        raw = f"{float(value):,.{places}f}".replace(",", "٬")
        return raw.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))

    used_mb = fa_decimal(used_bytes / 1024 / 1024)
    if quota_mb:
        storage_percent = used_bytes / (quota_mb * 1024 * 1024) * 100
        if storage_percent >= float(settings.upload_storage_critical_percent):
            storage_state = "بحرانی"
        elif storage_percent >= float(settings.upload_storage_warning_percent):
            storage_state = "نیازمند توجه"
        else:
            storage_state = "عادی"
        quota_text = f"{fa_number(quota_mb)} مگابایت · {fa_number(round(storage_percent))}٪ مصرف · وضعیت {storage_state}"
    else:
        quota_text = "غیرفعال"
    free_text = f"{fa_number(round(disk_free / 1024 / 1024))} مگابایت" if disk_free is not None else "در دسترس نیست"
    recent_registration_text = "\n".join(
        f"• {escape(str(u.display_name or ' '.join(x for x in (u.first_name, u.last_name) if x) or '—')[:45])} · {u.created_at.strftime('%Y-%m-%d') if u.created_at else '—'}"
        for u in recent_users
    ) or "• هنوز ثبت‌نامی ثبت نشده است."
    moderation_labels = {
        "suspension": "تعلیق حساب",
        "restriction": "محدودیت دسترسی",
        "block": "مسدودسازی کاربر",
        "unblock": "رفع مسدودیت کاربر",
        "restriction_removed": "رفع محدودیت دسترسی",
        "restriction_applied": "اعمال محدودیت دسترسی",
    }
    recent_moderation_text = "\n".join(
        f"• {escape(moderation_labels.get(str(r.action), 'اقدام مدیریتی'))} · شناسه <code>{int(r.target_telegram_id)}</code> · {r.created_at.strftime('%Y-%m-%d') if r.created_at else '—'}"
        for r in recent_moderation
    ) or "• هنوز اقدامی در بخش نظارت ثبت نشده است."
    body = (
        "<b>داشبورد مدیریتی Panel Flow</b>\n"
        "<i>نمای کلی کاربران، پنل‌ها، پرداخت‌ها و موارد نیازمند رسیدگی.</i>\n\n"
        f"👥 کاربران ثبت‌شده: <b>{fa_number(registered_users)}</b> · مدیران: {fa_number(admin_count)} · میزبان‌ها: {fa_number(host_count)}\n"
        f"🚫 کاربران مسدود: {fa_number(blocked_count)} · تعلیق‌های فعال: {fa_number(suspended_count)}\n"
        f"📣 پنل‌های منتشرشده: {fa_number(published)} · درخواست‌های ارسالیِ در انتظار بررسی: {fa_number(pending_reviews)}\n"
        f"🧾 رسیدهای در انتظار بررسی: {fa_number(pending_receipts)} · رزروهای در انتظار پرداخت: {fa_number(needs_attention)}\n"
        f"🕒 پرونده‌های مالیِ لغوهای حل‌نشده: {fa_number(unresolved_cases)} · افراد حاضر در صف انتظار: {fa_number(waitlisted_people)}\n"
        f"📬 اطلاع‌رسانی‌های در حال اجرا یا دارای خطا: {fa_number(announcements_attention)}\n"
        f"🎟 درخواست‌های فروشگاه: {fa_number(pending_shop_requests)} · هدایا در انتظار صدور یا تحویل: {fa_number(pending_reward_issues)} · تحویل‌های نامطمئن: {fa_number(uncertain_reward_deliveries)}\n"
        f"🔔 اطلاع‌رسانی‌های میزبانِ نیازمند بررسی: {fa_number(host_notification_issues)}\n\n"
        f"<b>ثبت‌نام‌های اخیر</b>\n{recent_registration_text}\n\n"
        f"<b>آخرین اقدامات نظارتی</b>\n{recent_moderation_text}\n\n"
        "<b>فضای ذخیره‌سازی</b>\n"
        f"💾 فضای مصرف‌شدهٔ فایل‌ها: {used_mb} مگابایت · سقف سختِ فضای ذخیره‌سازی: {quota_text} · فضای خالی دیسک: {free_text}\n\n"
        "زمان آخرین فعالیت کاربران به‌طور قابل اتکا ذخیره نمی‌شود؛ بنابراین تعداد کاربران فعال نمایش داده نمی‌شود.\n"
        "تاریخ پنل‌ها فقط متن نمایشی است و برای تشخیص آینده یا گذشته به کار نمی‌رود.\n"
        "وضعیت نسخه‌های پشتیبان از این سرویس قابل دریافت نیست."
    )
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧾 بررسی رسیدها", callback_data="admin:pending_payments:page:0"),
         InlineKeyboardButton(text="💸 پرونده‌های مالی", callback_data="admin:cancellation_cases")],
        [InlineKeyboardButton(text="📝 بررسی پنل‌های ارسالی", callback_data="admin:console:reviews"),
         InlineKeyboardButton(text="🔔 اطلاع‌رسانی‌های میزبان", callback_data="admin:console:host-notifications:page:0")],
        [InlineKeyboardButton(text="⏳ مدیریت صف انتظار پنل‌ها", callback_data="admin:events"),
         InlineKeyboardButton(text="🎟 صف صدور و تحویل هدایا", callback_data="admin:v77:rewards:queue:0")],
        [InlineKeyboardButton(text="🔁 تلاش دوباره برای هشدارهای مدیر", callback_data="admin:v78:notifications:retry"),
         InlineKeyboardButton(text="🧰 ابزارهای تکمیلی", callback_data="admin:v77:home")],
        [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
    ]))
    await c.answer()


