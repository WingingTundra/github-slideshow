from __future__ import annotations

from html import escape
from decimal import Decimal
import asyncio
import json
import logging
import io
import os
import secrets
import hashlib
from pathlib import Path
from weakref import WeakValueDictionary

from aiogram import F, Router
from aiogram.filters import BaseFilter, Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, Message, ReplyKeyboardRemove
from sqlalchemy import and_, func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import selectinload

from app.bot.keyboards import (
    booking_cancel_confirm_keyboard,
    booking_count_keyboard,
    available_events_keyboard,
    admin_menu,
    back_menu,
    booking_confirmation_keyboard,
    booking_pricing_keyboard,
    booking_edit_keyboard,
    booking_edit_participants_keyboard,
    profile_phone_keyboard,
    community_keyboard,
    duplicate_registration_keyboard,
    event_buttons,
    main_menu,
    profile_edit_cancel_keyboard,
    profile_keyboard,
    referral_choice_keyboard,
    referral_code_input_keyboard,
    referral_code_display_keyboard,
    questions_keyboard,
    review_confirm_keyboard,
    review_rating_keyboard,
    user_discount_prompt_keyboard,
    discount_request_user_keyboard,
    personal_reward_keyboard,
    payment_card_keyboard,
    receipt_upload_keyboard,
    suggestions_keyboard,
    persistent_main_keyboard,
    hide_reply_keyboard,
)
from app.bot.states import BookingStates, NavigationStates, ProfileEditStates, ProfileStates, QuestionStates, ReviewStates, WaitlistStates
from app.bot.validation import normalize_iranian_mobile, normalize_person_name, parse_full_name, parse_integer
from app.bot.content import (
    about_text, main_menu_welcome_text, user_help_text, support_link_html,
    onboarding_full_name_prompt, invalid_full_name_prompt,
    accepted_name_phone_prompt, phone_number_prompt,
)
from app.bot.command_validation import is_unrouted_telegram_command
from app.bot.admin_notifications import format_receipt_stage_cancel_notice
from app.bot.profile import apply_profile_name, apply_profile_phone
from app.config import settings
from app.display_utils import has_end_time_label, volume_label, status_display_label, rtl_isolate, panel_detail_line
from app.db.models import (
    Booking,
    AttendanceStatus,
    Participant,
    DiscountCode,
    DiscountCodeEvent,
    DiscountRedemption,
    Event,
    EventStatus,
    Payment,
    Question,
    RegistrationStatus,
    Review,
    User,
    UserRole,
    WaitlistEntry, WebsiteLoginChallenge,
)
from app.db.session import SessionLocal
from app.services.app_settings import get_bot_settings, get_setting
from app.services.pricing import (
    BASE_OPTION, WITHOUT_CAFE_ORDER, calculate_price_components,
    panel_price_label, booking_option_detail_label,
)
from app.services.user_access import has_active_feature_restriction
from app.services.booking import (
    MAX_ACTIVE_SEATS_PER_USER_PER_PANEL,
    MAX_PARTICIPANTS_PER_BOOKING,
    active_seats_for_owner,
    cancel_booking,
    create_booking,
    expire_old_bookings,
    retry_payment,
    expire_booking_if_due,
    user_can_cancel_booking,
)
from app.services.events import ACTIVE_BOOKING_STATUSES, participant_events_query, participant_events_statement, registration_is_open, seats_used, waitlist_is_available
from app.services.channel_status import reconcile_event_channel_status
from app.services.booking_pass import booking_pass_payload, verify_booking_pass_signature
from app.services.seat_disclosure import (
    public_catalogue_availability_label,
    should_disclose_remaining_seats,
    should_show_capacity_filling_message,
)
from app.services.waitlist import notify_waitlist_capacity_available
from app.services.referrals import attribute_referral, count_referrals_for_telegram_id, skip_referral_prompt
from app.services.discounts import (
    accepted_personal_reward, calculate_discount, eligible_public_codes_exist,
    validate_code_for_user, discount_display,
)
from app.bot.handlers.admin_utils import download_file, resolve_upload_path, within_upload_limit
from app.bot.file_validation import file_content_matches, receipt_extension
from app.bot.text_limits import DEFAULT_SAFE_TEXT_LIMIT, limit_telegram_html, telegram_html_visible_units
from app.time_utils import utc_now_naive

router = Router()
logger = logging.getLogger(__name__)
_CONFIRMATION_LOCKS: WeakValueDictionary[int, asyncio.Lock] = WeakValueDictionary()


def _confirmation_lock_for(telegram_id: int) -> asyncio.Lock:
    """Serialize duplicate confirmation taps for one Telegram account."""
    lock = _CONFIRMATION_LOCKS.get(int(telegram_id))
    if lock is None:
        lock = asyncio.Lock()
        _CONFIRMATION_LOCKS[int(telegram_id)] = lock
    return lock


def _fa_digits(value) -> str:
    return str(value).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _compact_toman(value) -> str:
    """Format catalogue prices compactly without rounding a price users must pay."""
    amount = max(0, int(value or 0))
    if amount >= 1_000_000 and amount % 1_000 == 0:
        label = f"{amount / 1_000_000:.3f}".rstrip("0").rstrip(".")
        return f"{label}m toman"
    if amount >= 1_000 and amount % 1_000 == 0:
        return f"{amount // 1_000:,}k toman"
    return f"{amount:,} toman"


def _ltr_display(value) -> str:
    """HTML-escape a short Latin/mixed-direction value and isolate it from Persian text."""
    return f"\u2066{escape(str(value))}\u2069"


async def _payment_details() -> tuple[str, str]:
    """Read the latest persisted payment instructions; never log their contents."""
    async with SessionLocal() as session:
        values = await get_bot_settings(session)
    return values["payment_card_number"], values["payment_account_name"]

async def _payment_configuration_ready() -> bool:
    card_number, account_name = await _payment_details()
    return bool(card_number and account_name)


def _payment_setup_user_message() -> str:
    return (
        "⚠️ پرداخت این پنل موقتاً در دسترس نیست. اطلاعات پرداخت هنوز کامل تنظیم نشده است.\n\n"
        "رزروی ایجاد نشده و صندلی‌ای برای شما رزرو نشده است. اطلاعات ثبت‌نام شما حفظ شده؛ "
        f"لطفاً پس از رفع مشکل دوباره تلاش کنید یا با پشتیبانی تماس بگیرید: {support_link_html()}"
    )


async def _notify_payment_configuration_missing(bot, event_label: str, amount: int) -> None:
    notice = (
        "⚠️ <b>تنظیمات پرداخت ناقص است</b>\n\n"
        f"پنل: {escape(event_label)}\nمبلغ قابل پرداخت: {int(amount):,} تومان\n"
        "شماره کارت یا نام صاحب حساب تنظیم نشده است؛ ایجاد رزرو پولی مسدود شد."
    )
    for admin_id in settings.super_admin_id_set:
        try:
            await bot.send_message(int(admin_id), notice)
        except Exception:
            logger.exception("Could not notify admin about incomplete payment configuration")


def _booking_summary_panel_label(event) -> str:
    """Keep a trailing question mark visually attached to a panel's English title in RTL text.

    In the Persian-labelled confirmation summary, a question mark at the end of an
    isolated LTR title can appear at the wrong visual edge on some Telegram clients.
    Move only that terminal mark outside the LTR isolate, before the title, so bidi
    layout places it at the visual end of the English title.
    """
    title = str(event.title or "").strip()
    label = f"{volume_label(event.volume)} – {title}"
    if title.endswith("?"):
        return f"?{_ltr_display(label[:-1])}"
    return _ltr_display(label)


class UnsupportedTelegramCommand(BaseFilter):
    """Catch commands that did not match an earlier command handler before FSM input."""

    async def __call__(self, message: Message) -> bool:
        text = (message.text or "").strip()
        if not text.startswith("/"):
            return False
        token = text.split(maxsplit=1)[0]
        raw = token[1:]
        command = raw.split("@", 1)[0]
        if command.casefold() == "checkin":
            return False
        if command.casefold() == "admin":
            # Route every /admin variant to the early command handler below so an
            # active user FSM can never consume it as a name/review/suggestion.
            return True
        # Registered /start, /help and /cancel handlers appear before this filter.
        # If one did not match (including an incorrect @bot mention or casing),
        # never let the slash command fall through as an ordinary FSM answer.
        return is_unrouted_telegram_command(text)


async def get_or_create_user(tg_user):
    """Create/refresh an account idempotently under concurrent first /start calls.

    Existing profile fields, referral attribution, and non-owner role assignments are
    never overwritten by this upsert. Only the configured owner allow-list can elevate
    the stored role to SUPER_ADMIN.
    """
    telegram_id = int(tg_user.id)
    owner = telegram_id in settings.super_admin_id_set
    values = {
        "telegram_id": telegram_id,
        "telegram_username": tg_user.username,
        "is_bot": bool(getattr(tg_user, "is_bot", False)),
        "display_name": None,
        "role": UserRole.SUPER_ADMIN if owner else UserRole.PARTICIPANT,
    }
    stmt = pg_insert(User).values(**values)
    updates = {
        "telegram_username": stmt.excluded.telegram_username,
        "is_bot": stmt.excluded.is_bot,
    }
    if owner:
        updates["role"] = UserRole.SUPER_ADMIN
    stmt = stmt.on_conflict_do_update(index_elements=[User.telegram_id], set_=updates)
    async with SessionLocal() as session:
        await session.execute(stmt)
        from app.services.community import record_user_onboarding
        await record_user_onboarding(session, telegram_id)
        await session.commit()
        user = (await session.execute(select(User).where(User.telegram_id == telegram_id))).scalar_one()
        return user


async def continue_onboarding(message: Message, state: FSMContext, user: User) -> bool:
    if not user.first_name or not user.last_name:
        await message.answer(onboarding_full_name_prompt(), reply_markup=hide_reply_keyboard())
        await state.set_state(ProfileStates.waiting_full_name)
        return True
    if not user.phone_number:
        await message.answer(phone_number_prompt(), reply_markup=profile_phone_keyboard())
        await state.set_state(ProfileStates.waiting_phone)
        return True
    if not bool(getattr(user, "referral_prompt_completed", False)):
        await ask_referral_choice(message, state)
        return True
    return False


async def ask_referral_choice(message: Message, state: FSMContext) -> None:
    """Ask once after first-time profile fields are complete and retain its message ID."""
    await state.set_state(ProfileStates.waiting_referral_choice)
    prompt = await message.answer(
        "🤝 آیا دوستی شما را به Panel Flow معرفی کرده است؟\n\n"
        "اگر کد معرفی دارید، می‌توانید آن را وارد کنید؛ این مرحله اختیاری است.",
        reply_markup=referral_choice_keyboard(),
    )
    # After the referral step, reuse this bot-authored message for the requested
    # panel/registration flow instead of leaving an obsolete prompt in the chat.
    await state.update_data(referral_prompt_message_id=int(prompt.message_id))



async def event_is_bookable(event: Event) -> bool:
    return registration_is_open(event)


def event_text(event: Event, used: int) -> str:
    """Render the panel description first and reserve the message bottom for logistics."""
    heading = (
        f"<b>{escape(volume_label(event.volume))} – {_ltr_display(event.title)}</b>"
    )

    # Keep all practical details together at the bottom in one predictable,
    # compact block. These details are important even when a description is long.
    details: list[str] = []
    if event.language:
        details.append(panel_detail_line("زبان پنل", escape(event.language), icon="🌐"))
    details.append(panel_detail_line("روز و تاریخ", f"{escape(event.event_day_label)} – {escape(event.event_date_label)}", icon="📅"))
    time_value = escape(event.start_time_label) + (f"–{escape(event.end_time_label)}" if has_end_time_label(event.end_time_label) else "")
    details.append(panel_detail_line("ساعت", time_value, icon="⏰"))
    details.append(panel_detail_line("مکان", escape(event.venue), icon="📍"))
    details.append(panel_detail_line("هزینه", escape(panel_price_label(event.price_per_person, event.price_without_cafe_order)), icon="💰"))
    if event.host_name:
        details.append(panel_detail_line("میزبان", escape(event.host_name), icon="👤"))
    # Public visitors see total capacity, never an early signup counter.
    # Exact remaining seats are disclosed only when availability is genuinely low.
    capacity = max(0, int(event.capacity or 0))
    remaining = max(0, capacity - int(used or 0))
    details.append(panel_detail_line("ظرفیت", f"{_fa_digits(capacity)} نفر", icon="👥"))
    if registration_is_open(event):
        if should_disclose_remaining_seats(capacity, remaining):
            details.append(rtl_isolate(f"فقط {_fa_digits(remaining)} جای خالی باقی مانده است."))
        elif should_show_capacity_filling_message(capacity, used, remaining):
            # Keep the requested wording exact: no emoji or explanatory add-on.
            details.append(rtl_isolate("ظرفیت پنل در حال تکمیل است."))

    if event.address and event.address.strip() != event.venue.strip():
        details.extend(["", panel_detail_line("آدرس", escape(event.address), icon="📌")])
    if not registration_is_open(event):
        details.extend(["", "⛔ ثبت‌نام این پنل بسته است."])
    if remaining <= 0:
        details.extend(["", "⚠️ ظرفیت پنل تکمیل شده است."])

    details_block = "\n\n" + "\n".join(details)
    if not event.description:
        return limit_telegram_html(heading + details_block)

    description_heading = "\n\n📝 <b>توضیحات</b>\n"
    escaped_description = escape(event.description)
    # If the description nearly fills Telegram's message limit, shorten that
    # section first so the title and key logistics/address still remain visible
    # at the bottom. Count Telegram-visible UTF-16 units (not HTML source chars).
    description_budget = (
        DEFAULT_SAFE_TEXT_LIMIT
        - telegram_html_visible_units(heading)
        - telegram_html_visible_units(description_heading)
        - telegram_html_visible_units(details_block)
    )
    if description_budget > 0:
        description = limit_telegram_html(escaped_description, max_units=description_budget)
    else:
        description = "…"

    text = heading + description_heading + description + details_block
    return limit_telegram_html(text)


async def dispatch_start_payload(
    message: Message, state: FSMContext, payload: str, *, allow_duplicate: bool = False,
    telegram_user=None, replace_message_id: int | None = None,
) -> bool:
    """Process a recognized deep link after onboarding while retaining the actual user identity."""
    if payload.casefold() in {"reviews", "review"}:
        # Public channel/group archive posts link directly to the existing review
        # list. That list is personalized and exposes only this user's eligible panels.
        await render_reviews(message)
        return True
    if payload.startswith("bookingverify_"):
        parts = payload.split("_")
        if len(parts) == 3 and parts[1].isdigit() and parts[2].isalnum():
            await show_booking_verification_from_message(
                message, int(parts[1]), parts[2],
                telegram_user=telegram_user or message.from_user,
            )
        else:
            await message.answer("پیوند بررسی رزرو نامعتبر است.")
        return True
    if payload.startswith("pfcontact_"):
        try:
            event_id = int(payload.removeprefix("pfcontact_"))
        except ValueError:
            event_id = 0
        if event_id > 0:
            from app.bot.handlers.admin_console import show_panel_communications_from_message
            await show_panel_communications_from_message(message, event_id)
        else:
            await message.answer("پیوند ارتباط با پنل نامعتبر است.")
        return True
    if payload.startswith("checkin_"):
        parts = payload.split("_")
        if len(parts) == 3 and parts[1].isdigit() and parts[2].isalnum():
            from app.bot.handlers.attendance import show_checkin_from_message
            await show_checkin_from_message(message, int(parts[1]), parts[2])
            return True
    if payload.startswith("reward_"):
        try:
            reward_id = int(payload.removeprefix("reward_"))
        except ValueError:
            reward_id = None
        if reward_id is not None:
            await show_personal_reward_offer(message, reward_id, telegram_id=int(telegram_user.id) if telegram_user else None)
            return True
    if payload.startswith("challenge_"):
        try:
            challenge_id = int(payload.removeprefix("challenge_"))
        except ValueError:
            challenge_id = None
        if challenge_id is not None and challenge_id > 0:
            from app.bot.handlers.community import show_challenge_from_message
            await show_challenge_from_message(message, state, challenge_id, telegram_user=telegram_user)
            return True
    if payload.startswith("panel_"):
        try:
            event_id = int(payload.removeprefix("panel_"))
        except ValueError:
            event_id = None
        if event_id is not None:
            await show_event_details_from_message(
                message, event_id, telegram_user=telegram_user,
                replace_message_id=replace_message_id,
            )
            return True
    if payload.startswith("reg_") or payload.startswith("event_"):
        prefix = "reg_" if payload.startswith("reg_") else "event_"
        try:
            event_id = int(payload.removeprefix(prefix))
        except ValueError:
            event_id = None
        if event_id is not None:
            if replace_message_id is not None:
                # The first registration prompt can replace the completed
                # onboarding prompt, keeping the deep-link flow in one message.
                await state.update_data(booking_flow_message_id=int(replace_message_id))
            await begin_register_from_message(message, state, event_id, allow_duplicate=allow_duplicate, telegram_user=telegram_user)
            return True
    return False


@router.message(CommandStart())
async def start(message: Message, state: FSMContext, command: CommandObject | None = None):
    payload = (command.args or "").strip() if command else ""

    # Browser login handoff: the user explicitly opens a short-lived, one-time
    # deep link in this bot. Do not clear or alter any in-progress FSM flow.
    if payload.startswith("web_"):
        raw_token = payload.removeprefix("web_").strip()
        if 30 <= len(raw_token) <= 100:
            digest = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
            async with SessionLocal() as session:
                challenge = (await session.execute(
                    select(WebsiteLoginChallenge).where(WebsiteLoginChallenge.token_hash == digest)
                    .with_for_update().execution_options(populate_existing=True)
                )).scalar_one_or_none()
                now = utc_now_naive()
                if challenge is None or challenge.status != "pending" or challenge.expires_at <= now:
                    challenge = None
                else:
                    existing_user = (await session.execute(
                        select(User).where(User.telegram_id == int(message.from_user.id))
                    )).scalar_one_or_none()
                    if existing_user is None:
                        challenge = None
                    else:
                        challenge.user_id = int(existing_user.id)
                        challenge.telegram_id = int(message.from_user.id)
                        challenge.status = "authenticated"
                        challenge.authenticated_at = now
                        await session.commit()
            if challenge is None:
                await message.answer("لینک ورود معتبر نیست، منقضی شده یا حساب شما هنوز در ربات ثبت نشده است. ابتدا ربات Panel Flow را راه‌اندازی کنید و دوباره از وب‌سایت اقدام کنید.")
            else:
                await message.answer("✅ ورود شما به وب‌سایت Panel Flow تأیید شد. به مرورگر برگردید؛ صفحه به‌صورت خودکار وارد حساب می‌شود.")
            return
        await message.answer("لینک ورود وب‌سایت معتبر نیست. لطفاً از صفحه ورود وب‌سایت یک لینک تازه دریافت کنید.")
        return

    prior_state = await state.get_state()
    prior_data = await state.get_data()

    # The public About deep link must work before registration. It deliberately
    # runs before FSM handling and never clears or mutates an active user flow.
    if payload.casefold() in {"about", "community", "community_about"}:
        await render_community_links(message)
        return

    # /start must not silently abandon the receipt step while a pending booking
    # still exists. Keep the FSM intact so the next photo/file/text is handled as
    # a receipt and /cancel can release this exact reservation.
    if prior_state == BookingStates.waiting_receipt.state and prior_data.get("booking_id"):
        existing_user = await get_or_create_user(message.from_user)
        booking_id = int(prior_data["booking_id"])
        expired_event_id = None
        async with SessionLocal() as session:
            active_booking = await session.get(Booking, booking_id, with_for_update=True)
            if active_booking and active_booking.booked_by_user_id == existing_user.id and active_booking.status == RegistrationStatus.PENDING_PAYMENT:
                if expire_booking_if_due(active_booking, now=utc_now_naive()):
                    expired_event_id = int(active_booking.event_id)
                    await session.commit()
                else:
                    await _show_receipt_cancel_confirmation(message, state, booking_id)
                    return
        if expired_event_id is None:
            # The reservation was removed, changed by an administrator, or no
            # longer belongs to this user; proceed with normal /start behavior.
            await state.clear()
        else:
            await state.clear()
            await message.answer("مهلت پرداخت رزرو قبلی به پایان رسیده و صندلی آن آزاد شد.")
            try:
                await reconcile_event_channel_status(message.bot, expired_event_id)
            except Exception:
                logger.exception("Could not reconcile panel after /start discovered expired booking_id=%s", booking_id)
            try:
                await notify_waitlist_capacity_available(message.bot, expired_event_id)
            except Exception:
                logger.exception("Could not notify waitlist after /start discovered expired booking_id=%s", booking_id)
            if await dispatch_start_payload(message, state, payload):
                return
            return
    else:
        if prior_state:
            await _show_navigation_discard_prompt(message, state, prior_state)
            return
        await state.clear()
    user = await get_or_create_user(message.from_user)
    if await continue_onboarding(message, state, user):
        # Do not lose a panel/registration deep link while the user completes onboarding.
        if payload.startswith(("panel_", "reg_", "event_", "reward_", "challenge_", "checkin_", "bookingverify_", "pfcontact_")) or payload.casefold() in {"reviews", "review"}:
            await state.update_data(pending_start_payload=payload)
        return

    if await dispatch_start_payload(message, state, payload):
        return

    # Send the welcome copy and the main inline keyboard together. This avoids
    # the previous two-message fallback when Telegram refuses a markup edit.
    await message.answer(
        main_menu_welcome_text(),
        reply_markup=main_menu(),
        disable_web_page_preview=True,
    )


@router.message(Command("quickmenu"))
async def enable_quick_menu(message: Message, state: FSMContext):
    """Explicitly opt into the native reply keyboard, only outside active forms."""
    if await state.get_state():
        return await message.answer("برای جلوگیری از قطع‌شدن فرایند فعلی، منوی سریع را پس از پایان یا لغو این مرحله فعال کنید.")
    await message.answer("⌨️ منوی سریع فعال شد. برای پنهان‌کردنش /hidekeyboard را بزنید.", reply_markup=persistent_main_keyboard())


@router.message(Command("hidekeyboard"))
async def disable_quick_menu(message: Message, state: FSMContext):
    """Remove the optional native keyboard and restore the inline home menu."""
    if await state.get_state():
        return await message.answer("هنگام تکمیل مرحلهٔ فعلی، از دکمه‌های همان مرحله استفاده کنید. پس از پایان می‌توانید منوی سریع را پنهان کنید.")
    home_message = await message.answer("منوی سریع پنهان شد.", reply_markup=hide_reply_keyboard())
    try:
        await home_message.edit_reply_markup(reply_markup=main_menu())
    except Exception:
        await message.answer(main_menu_welcome_text(), reply_markup=main_menu())


@router.message(Command("help"))
async def help_command(message: Message, state: FSMContext):
    # Keep receipt collection focused. Commands must never be mistaken for the
    # text receipt or move the user away from the pending-payment workflow.
    if await state.get_state() == BookingStates.waiting_receipt.state and (await state.get_data()).get("booking_id"):
        return await message.answer(
            "لطفاً رسید را به‌صورت عکس، فایل یا متن ارسال کنید. برای لغو همین رزرو، /cancel را بزنید."
        )
    # Role-neutral and state-preserving: help is informational only.
    await message.answer(user_help_text(), disable_web_page_preview=True)


async def _cancel_receipt_stage_booking(target, state: FSMContext, booking_id: int) -> None:
    """Cancel the exact pending-payment reservation and release held seats.

    Shared by /cancel and the inline action beside receipt upload so both paths use
    the same booking service, admin notice, panel reconciliation, and waitlist path.
    """
    is_callback = isinstance(target, CallbackQuery)
    telegram_user = target.from_user
    bot = target.bot
    user = await get_or_create_user(telegram_user)
    event_id = None
    event_label = f"رزرو #{booking_id}"
    participant_count = 0
    try:
        async with SessionLocal() as session:
            candidate = await session.get(Booking, int(booking_id))
            if not candidate or candidate.booked_by_user_id != user.id:
                await state.clear()
                error = "رزرو این گفت‌وگو پیدا نشد؛ فرایند لغو شد."
                if is_callback:
                    await target.answer(error, show_alert=True)
                else:
                    await target.answer(error, reply_markup=main_menu())
                return
            event = await session.get(Event, candidate.event_id)
            event_id = int(candidate.event_id)
            event_label = f"{volume_label(event.volume)} — {event.title}" if event else event_label
            participant_count = int(candidate.participant_count or 0)
            await cancel_booking(session, user.id, int(booking_id))
    except ValueError as exc:
        logger.info("Receipt-stage cancellation rejected for booking_id=%s: %s", booking_id, exc)
        await state.clear()
        error = "گفت‌وگو لغو شد، اما وضعیت رزرو تغییر نکرد؛ اگر رزرو هنوز فعال است از «ثبت‌نام‌های من» آن را لغو کنید."
        if is_callback:
            await target.answer(error, show_alert=True)
        else:
            await target.answer(error, reply_markup=main_menu())
        return
    except Exception:
        logger.exception("Could not cancel reservation from receipt stage; booking_id=%s", booking_id)
        error = "به‌دلیل خطای فنی رزرو لغو نشد. وضعیت تغییر نکرده است؛ لطفاً دوباره تلاش کنید."
        if is_callback:
            await target.answer(error, show_alert=True)
        else:
            await target.answer(error, reply_markup=main_menu())
        return

    await state.clear()
    success = f"✅ فرایند ثبت‌نام و رزرو #{booking_id} لغو شد. صندلی آزاد شده است و رسیدی ارسال نخواهد شد."
    if is_callback:
        await target.message.answer(success, reply_markup=hide_reply_keyboard())
        await target.message.answer(main_menu_welcome_text(), reply_markup=main_menu())
        await target.answer("رزرو لغو شد؛ صندلی آزاد شد.")
    else:
        await target.answer(success, reply_markup=hide_reply_keyboard())
        await target.answer(main_menu_welcome_text(), reply_markup=main_menu())

    for admin_id in settings.super_admin_id_set - {int(telegram_user.id)}:
        try:
            await bot.send_message(
                int(admin_id),
                format_receipt_stage_cancel_notice(
                    event_label=event_label, booking_id=int(booking_id),
                    participant_count=participant_count, telegram_id=int(telegram_user.id),
                    username=telegram_user.username,
                    cancellation_method="button" if is_callback else "command",
                ),
            )
        except Exception:
            logger.info("Could not notify admin about receipt-stage cancellation; booking_id=%s", booking_id, exc_info=True)
    if event_id is not None:
        try:
            await reconcile_event_channel_status(bot, event_id)
        except Exception:
            logger.exception("Could not reconcile event after receipt-stage cancellation; event_id=%s", event_id)
        try:
            await notify_waitlist_capacity_available(bot, event_id)
        except Exception:
            logger.exception("Could not notify waitlist after receipt-stage cancellation; event_id=%s", event_id)


async def _show_receipt_cancel_confirmation(target, state: FSMContext, booking_id: int, *, edit_existing: bool = False) -> None:
    token = secrets.token_hex(4)
    await state.update_data(receipt_cancel_confirmation_for=int(booking_id), receipt_cancel_confirmation_token=token)
    prompt_text = (
        "آیا از لغو این پرداخت مطمئن هستید؟\n\n"
        "تا زمان تأیید، رزرو و اطلاعات پرداخت شما بدون تغییر باقی می‌ماند."
    )
    prompt_markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید لغو پرداخت", callback_data=f"user:payment:cancel_confirm:{int(booking_id)}:{token}")],
        [InlineKeyboardButton(text="↩️ بازگشت به پرداخت", callback_data=f"user:payment:cancel_back:{int(booking_id)}:{token}")],
    ])
    if edit_existing and hasattr(target, "edit_text"):
        try:
            await target.edit_text(prompt_text, reply_markup=prompt_markup)
            return
        except Exception as exc:
            logger.debug("Could not replace receipt prompt with cancellation confirmation: %s", exc)
    await target.answer(prompt_text, reply_markup=prompt_markup)


@router.callback_query(F.data.regexp(r"^user:payment:cancel_receipt:\d+$"))
async def cancel_receipt_button(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.waiting_receipt.state:
        return await c.answer("این مرحلهٔ ارسال رسید دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    try:
        active_booking_id = int(data.get("booking_id") or 0)
        target_booking_id = int((c.data or "").rsplit(":", 1)[1])
    except (TypeError, ValueError, IndexError):
        return await c.answer("شناسهٔ رزرو معتبر نیست.", show_alert=True)
    if target_booking_id <= 0 or target_booking_id != active_booking_id:
        return await c.answer("این دکمه مربوط به رزرو فعال شما نیست؛ وضعیت رزرو تغییر نکرده است.", show_alert=True)
    await _show_receipt_cancel_confirmation(c.message, state, target_booking_id, edit_existing=True)
    await c.answer()


async def _restore_receipt_payment_prompt(c: CallbackQuery, state: FSMContext, booking_id: int) -> None:
    """Rebuild the active receipt prompt without changing the booking or FSM context."""
    if await state.get_state() != BookingStates.waiting_receipt.state:
        return await c.answer("مرحلهٔ پرداخت دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    try:
        active_id = int(data.get("booking_id") or 0)
    except (TypeError, ValueError):
        active_id = 0
    if active_id != int(booking_id) or active_id <= 0:
        return await c.answer("این دکمه مربوط به پرداخت فعال شما نیست.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        booking = await session.get(Booking, active_id)
        if not booking or booking.booked_by_user_id != user.id or booking.status != RegistrationStatus.PENDING_PAYMENT:
            return await c.answer("رزرو دیگر در انتظار پرداخت نیست.", show_alert=True)
        amount = int(booking.total_amount or 0)
    payment_card_number, payment_account_name = await _payment_details()
    await state.update_data(receipt_cancel_confirmation_for=None, receipt_cancel_confirmation_token=None)
    await c.message.edit_text(
        f"ارسال رسید برای رزرو #{active_id}.\n\n"
        f"💳 مبلغ قابل پرداخت: <b>{amount:,} تومان</b>\n\n"
        f"شماره کارت: {payment_card_number}\n"
        f"به نام: {payment_account_name}\n\n"
        "📄 رسید را به‌صورت عکس، فایل یا متن ارسال کنید.",
        reply_markup=receipt_upload_keyboard(payment_card_number, active_id),
    )
    await c.answer("به مرحلهٔ پرداخت برگشتید.")


@router.callback_query(F.data.regexp(r"^user:payment:cancel_confirm:\d+:[0-9a-f]{8}$"))
async def confirm_receipt_cancellation(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.waiting_receipt.state:
        return await c.answer("مرحلهٔ پرداخت دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    try:
        active_id = int(data.get("booking_id") or 0)
        _user, _payment, _action, target_raw, token = (c.data or "").split(":")
        target_id = int(target_raw)
    except (TypeError, ValueError, IndexError):
        return await c.answer("شناسهٔ رزرو معتبر نیست.", show_alert=True)
    if active_id <= 0 or target_id != active_id:
        return await c.answer("این دکمه مربوط به رزرو فعال شما نیست.", show_alert=True)
    confirmation_for = data.get("receipt_cancel_confirmation_for")
    active_token = data.get("receipt_cancel_confirmation_token")
    if confirmation_for != target_id or not active_token or not secrets.compare_digest(str(active_token), token):
        return await c.answer("این تأیید منقضی شده است؛ برای لغو دوباره اقدام کنید.", show_alert=True)
    await _cancel_receipt_stage_booking(c, state, target_id)


@router.callback_query(F.data.regexp(r"^user:payment:cancel_back:\d+:[0-9a-f]{8}$"))
async def back_to_receipt_payment(c: CallbackQuery, state: FSMContext):
    try:
        _user, _payment, _action, target_raw, token = (c.data or "").split(":")
        target_id = int(target_raw)
    except (TypeError, ValueError, IndexError):
        return await c.answer("شناسهٔ رزرو معتبر نیست.", show_alert=True)
    data = await state.get_data()
    if data.get("receipt_cancel_confirmation_for") != target_id or not data.get("receipt_cancel_confirmation_token") or not secrets.compare_digest(str(data["receipt_cancel_confirmation_token"]), token):
        return await c.answer("این دکمه منقضی شده است.", show_alert=True)
    await _restore_receipt_payment_prompt(c, state, target_id)


async def _show_navigation_discard_prompt(message: Message, state: FSMContext, current_state: str) -> None:
    """Show one explicit continue/cancel decision without an extra warning message."""
    if current_state != NavigationStates.confirm_discard.state:
        await state.update_data(_navigation_saved_state=current_state)
        await state.set_state(NavigationStates.confirm_discard)
    await message.answer(
        "یک فرایند ناتمام دارید. ادامه می‌دهید یا آن را لغو می‌کنید؟ اطلاعات قبلی حفظ شده است.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="↩️ ادامهٔ فرایند", callback_data="navigation:discard:continue")],
            [InlineKeyboardButton(text="لغو فرایند", callback_data="navigation:discard:confirm")],
        ]),
    )


@router.message(Command("cancel"))
async def cancel_interaction(message: Message, state: FSMContext):
    current_state = await state.get_state()
    state_data = await state.get_data()

    if current_state == NavigationStates.confirm_discard.state:
        return await _show_navigation_discard_prompt(message, state, current_state)

    if current_state == BookingStates.waiting_receipt.state and state_data.get("booking_id"):
        try:
            booking_id = int(state_data["booking_id"])
        except (TypeError, ValueError):
            await state.clear()
            return await message.answer("شناسهٔ رزرو معتبر نیست؛ گفت‌وگو لغو شد.", reply_markup=main_menu())
        if state_data.get("receipt_cancel_confirmation_for") == booking_id and state_data.get("receipt_cancel_confirmation_token"):
            return await message.answer("تأیید لغو در پیام قبلی نمایش داده شده است.")
        return await _show_receipt_cancel_confirmation(message, state, booking_id)

    if current_state in {
        ProfileStates.waiting_referral_choice.state,
        ProfileStates.waiting_referral_code.state,
    }:
        try:
            async with SessionLocal() as session:
                await skip_referral_prompt(session, int(message.from_user.id))
                await session.commit()
        except Exception:
            logger.exception("Could not skip referral onboarding for telegram_id=%s", message.from_user.id)
        await state.clear()
        return await message.answer(
            "✅ مرحلهٔ فعلی لغو شد.\n\n"
            "رزروهای ثبت‌شده تغییر نکردند. برای مدیریت آن‌ها، «ثبت‌نام‌های من» را باز کنید.",
            reply_markup=main_menu(),
        )

    # A stray /cancel from a menu should restore the correct role-specific menu.
    if not current_state:
        await state.clear()
        from app.services.authorization import is_admin_telegram_id
        is_admin_actor = await is_admin_telegram_id(message.from_user.id)
        return await message.answer(
            "ℹ️ هیچ فرایند فعالی برای لغو وجود ندارد.",
            reply_markup=admin_menu() if is_admin_actor else main_menu(),
        )

    # Preserve the unfinished form until the user makes an explicit choice.
    await _show_navigation_discard_prompt(message, state, current_state)


@router.callback_query(F.data.in_({"navigation:discard:continue", "navigation:discard:confirm"}))
async def confirm_navigation_discard(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != NavigationStates.confirm_discard.state:
        return await c.answer("این تأیید دیگر فعال نیست؛ وضعیت گفت‌وگو تغییر نکرد.", show_alert=True)
    data = await state.get_data()
    previous_state = data.get("_navigation_saved_state")
    if not isinstance(previous_state, str) or not previous_state or previous_state == NavigationStates.confirm_discard.state:
        await state.clear()
        await c.message.answer("کنترل‌های فرایند قبلی بسته شد.", reply_markup=ReplyKeyboardRemove())
        return await c.answer("وضعیت قبلی معتبر نبود؛ فرم موقت پاک شد. برای شروع دوباره /start را بزنید.", show_alert=True)
    if c.data == "navigation:discard:continue":
        data.pop("_navigation_saved_state", None)
        await state.set_data(data)
        await state.set_state(previous_state)
        try:
            await c.message.edit_text("✅ فرایند قبلی حفظ شد. به پیام قبلی برگردید و همان مرحله را ادامه دهید.")
        except Exception:
            pass
        return await c.answer("فرایند حفظ شد.")

    await state.clear()
    # A wizard may have installed a persistent Reply Keyboard. Remove it before
    # showing the destination menu so stale Back/Cancel labels cannot leak into
    # the next FSM.
    await c.message.answer("کنترل‌های فرایند قبلی بسته شد.", reply_markup=ReplyKeyboardRemove())
    from app.services.authorization import is_admin_telegram_id, is_host_telegram_id
    if await is_admin_telegram_id(c.from_user.id):
        text = "✅ فرم ناتمام کنار گذاشته شد. هیچ رزرو، پرداخت یا پنلی حذف نشده است."
        markup = admin_menu()
    elif await is_host_telegram_id(c.from_user.id):
        text = "✅ فرم ناتمام کنار گذاشته شد. پنل‌های ثبت‌شده و سوابق مالی تغییر نکردند."
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🎤 پنل‌های من", callback_data="host:home")],
            [InlineKeyboardButton(text="🏠 منوی اصلی", callback_data="user:home")],
        ])
    else:
        text = "✅ فرم ناتمام کنار گذاشته شد. رزروها و پرداخت‌های ثبت‌شده تغییر نکردند."
        markup = main_menu()
    try:
        await c.message.edit_text(text, reply_markup=markup)
    except Exception:
        await c.message.answer(text, reply_markup=markup)
    await c.answer("فرم کنار گذاشته شد.")


@router.message(UnsupportedTelegramCommand())
async def unsupported_command(message: Message, state: FSMContext):
    text = (message.text or "").strip()
    token = text.split(maxsplit=1)[0] if text else ""
    raw = token[1:] if token.startswith("/") else ""
    command, _, mention = raw.partition("@")

    if command.casefold() == "admin":
        # A mention for another bot must not open this bot's admin menu. Still
        # consume it here so it cannot be captured by an active FSM text handler.
        if mention:
            try:
                bot_user = await message.bot.me()
                if not bot_user.username or mention.casefold() != bot_user.username.casefold():
                    return await message.answer(
                        "این دستور شناخته‌شده نیست. برای راهنمای امکانات ربات /help را بزنید؛ "
                        "برای لغو مرحلهٔ فعلی /cancel را ارسال کنید."
                    )
            except Exception:
                logger.exception("Could not resolve bot username while handling /admin")
                return await message.answer("امکان بررسی دستور وجود ندارد؛ لطفاً دوباره تلاش کنید.")

        from app.bot.handlers.admin import is_admin, _request_admin_navigation_confirmation
        if not await is_admin(message.from_user.id):
            return await message.answer("دسترسی مجاز نیست.")
        if await _request_admin_navigation_confirmation(message, state):
            return
        return await message.answer("<b>داشبورد مدیریتی Panel Flow</b>", reply_markup=admin_menu())

    await message.answer(
        "این دستور شناخته‌شده نیست. برای راهنمای امکانات ربات /help را بزنید؛ "
        "برای لغو مرحلهٔ فعلی /cancel را ارسال کنید."
    )


async def _user_is_waitlisted(session, event_id: int, telegram_id: int) -> bool:
    result = await session.execute(
        select(WaitlistEntry.id)
        .join(User, User.id == WaitlistEntry.user_id)
        .where(
            WaitlistEntry.event_id == int(event_id),
            User.telegram_id == int(telegram_id),
            WaitlistEntry.status.in_(("waiting", "invited", "inviting")),
        )
        .limit(1)
    )
    return result.scalar_one_or_none() is not None


async def _render_booking_prompt(message: Message, state: FSMContext, text: str, reply_markup=None, *, new_message: bool = False):
    """Render booking progress; send a new message when chronology matters."""
    data = await state.get_data()
    target_id = data.get("booking_flow_message_id")
    if target_id and not new_message:
        try:
            await message.bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=int(target_id),
                text=text,
                reply_markup=reply_markup,
                disable_web_page_preview=True,
            )
            return int(target_id)
        except Exception as exc:
            if "message is not modified" in str(exc).lower():
                return int(target_id)
            logger.debug("Could not edit booking prompt message_id=%s: %s", target_id, exc)
    sent = await message.answer(text, reply_markup=reply_markup, disable_web_page_preview=True)
    await state.update_data(booking_flow_message_id=int(sent.message_id))
    return int(sent.message_id)


async def _booking_count_prompt(message: Message, state: FSMContext, event: Event):
    data = await state.get_data()
    max_count = int(data.get("max_count") or 1)
    await state.set_state(BookingStates.waiting_count)
    if data.get("allow_duplicate"):
        text = (
            f"🧾 <b>مرحلهٔ ۱ از ۳ – تعداد و مشخصات</b>\n\n"
            f"چند نفر جدید را برای پنل {escape(volume_label(event.volume))} ثبت‌نام می‌کنید؟\n\n"
            "چون قبلاً برای این پنل ثبت‌نام کرده‌اید، در این رزرو فقط نام افراد جدید را وارد کنید."
        )
    else:
        text = (
            f"🧾 <b>مرحلهٔ ۱ از ۳ – تعداد و مشخصات</b>\n\n"
            f"چند نفر را برای پنل {escape(volume_label(event.volume))} ثبت‌نام می‌کنید؟\n\n"
            "<i>اطلاعات تماس شما از پروفایل ذخیره می‌شود و در فهرست عمومی نمایش داده نمی‌شود.</i>"
        )
    await _render_booking_prompt(message, state, text, booking_count_keyboard(max_count))


async def show_event_details_from_message(
    message: Message, event_id: int, *, telegram_user=None, replace_message_id: int | None = None,
):
    # Callback-driven onboarding resumes from a bot-authored message; use the
    # actual Telegram user for user-specific state such as waitlist membership.
    # When requested, replace the completed onboarding prompt instead of
    # leaving an obsolete referral question above the panel details.
    viewer = telegram_user or message.from_user

    async def render(text: str, reply_markup=None) -> None:
        if replace_message_id is not None:
            try:
                await message.bot.edit_message_text(
                    chat_id=message.chat.id,
                    message_id=int(replace_message_id),
                    text=text,
                    reply_markup=reply_markup,
                    disable_web_page_preview=True,
                )
                return
            except Exception as exc:
                if "message is not modified" in str(exc).lower():
                    return
                logger.debug(
                    "Could not replace onboarding prompt message_id=%s: %s",
                    replace_message_id, exc,
                )
                # Best-effort removal avoids leaving a stale question above the
                # fallback message when Telegram refuses the edit.
                try:
                    await message.bot.delete_message(
                        chat_id=message.chat.id, message_id=int(replace_message_id)
                    )
                except Exception:
                    logger.debug("Could not remove stale onboarding prompt message_id=%s", replace_message_id)
        await message.answer(text, reply_markup=reply_markup, disable_web_page_preview=True)

    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if event is None:
            await render("این پنل دیگر در دسترس نیست.", reply_markup=main_menu())
            return
        if event.archived:
            await render("این پنل برگزار شده و آرشیو شده است.", reply_markup=main_menu())
            return
        if event.status.value != "published":
            await render("این پنل دیگر برای کاربران فعال نیست.", reply_markup=main_menu())
            return
        used = await seats_used(session, event.id)
        waitlisted = await _user_is_waitlisted(session, event.id, int(viewer.id))
    can_register = registration_is_open(event) and used < event.capacity
    waitlist = waitlist_is_available(event, used)
    await render(
        event_text(event, used),
        reply_markup=event_buttons(event.id, can_register, waitlist, event.map_url, waitlisted=waitlisted),
    )


async def begin_register_from_message(
    message: Message,
    state: FSMContext,
    event_id: int,
    *,
    allow_duplicate: bool = False,
    telegram_user=None,
):
    # When called from an inline keyboard, message.from_user is the bot that
    # authored the message. Always use callback.from_user for the real registrant.
    identity = telegram_user or message.from_user
    user = await get_or_create_user(identity)
    if not user.first_name or not user.last_name or not user.phone_number:
        await state.clear()
        await state.update_data(
            pending_start_payload=f"reg_{event_id}",
            pending_allow_duplicate=bool(allow_duplicate),
        )
        if not user.first_name or not user.last_name:
            await state.set_state(ProfileStates.waiting_full_name)
            await message.answer(onboarding_full_name_prompt(), reply_markup=hide_reply_keyboard())
        else:
            await state.set_state(ProfileStates.waiting_phone)
            await message.answer(phone_number_prompt(), reply_markup=profile_phone_keyboard())
        return
    if not bool(getattr(user, "referral_prompt_completed", False)):
        await state.clear()
        await state.update_data(
            pending_start_payload=f"reg_{event_id}",
            pending_allow_duplicate=bool(allow_duplicate),
        )
        await ask_referral_choice(message, state)
        return
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if event is None:
            await message.answer("این پنل دیگر در دسترس نیست.", reply_markup=main_menu())
            return
        if event.archived:
            await message.answer("این پنل برگزار شده و آرشیو شده است.", reply_markup=main_menu())
            return
        # A restricted-code application persists independently of Telegram's FSM.
        # Re-entering the same panel must resume that request instead of creating
        # a second checkout or asking the user to submit the same code again.
        if not allow_duplicate:
            prior_request = (await session.execute(
                select(DiscountRedemption).where(
                    DiscountRedemption.event_id == event.id,
                    DiscountRedemption.user_telegram_id == int(identity.id),
                    DiscountRedemption.status.in_(("pending", "approved", "rejected")),
                    DiscountRedemption.draft_json.is_not(None),
                ).order_by(DiscountRedemption.created_at.desc()).limit(1)
            )).scalar_one_or_none()
            if prior_request is not None:
                status_note = {
                    "pending": "درخواست تخفیف قبلی شما هنوز در انتظار بررسی مدیر است.",
                    "approved": "درخواست تخفیف قبلی شما تأیید شده و می‌توانید ادامه دهید.",
                    "rejected": "درخواست تخفیف قبلی شما تأیید نشده است؛ می‌توانید با قیمت عادی ادامه دهید.",
                }[prior_request.status]
                await state.clear()
                await message.answer(
                    f"{status_note} هیچ صندلی‌ای برای این درخواست رزرو نشده است.",
                    reply_markup=discount_request_user_keyboard(
                        int(prior_request.id), approved=prior_request.status == "approved"
                    ),
                )
                return
        if not await event_is_bookable(event):
            await message.answer("ثبت‌نام این پنل در حال حاضر باز نیست.", reply_markup=main_menu())
            return
        await expire_old_bookings(session)
        used = await seats_used(session, event.id)
        remaining = max(0, event.capacity - used)
        active_user_seats = await active_seats_for_owner(session, event.id, user.id)
        if not allow_duplicate:
            active = (await session.execute(
                select(Booking.id).where(
                    Booking.event_id == event.id,
                    Booking.booked_by_user_id == user.id,
                    Booking.status.in_((
                        RegistrationStatus.PENDING_PAYMENT,
                        RegistrationStatus.PENDING_VERIFICATION,
                        RegistrationStatus.CONFIRMED,
                    )),
                ).limit(1)
            )).scalar_one_or_none()
        else:
            active = None
    if active is not None:
        await state.clear()
        await message.answer(
            "شما برای این پنل یک رزرو فعال دارید.\n\n"
            "اگر می‌خواهید یک ثبت‌نام جداگانه و رزرو جدید برای همین پنل ایجاد کنید، گزینهٔ زیر را بزنید.",
            reply_markup=duplicate_registration_keyboard(event_id),
        )
        return
    if remaining <= 0:
        await message.answer("ظرفیت این پنل تکمیل شده است.", reply_markup=main_menu())
        return
    remaining_for_user = MAX_ACTIVE_SEATS_PER_USER_PER_PANEL - active_user_seats
    if remaining_for_user <= 0:
        await message.answer(
            f"❌ شما در حال حاضر {MAX_ACTIVE_SEATS_PER_USER_PER_PANEL} صندلی فعال/در انتظار بررسی برای این پنل دارید."
        )
        return
    await state.clear()
    async with SessionLocal() as session:
        # A personal reward is only usable when the recipient is attending this
        # reservation. Additional bookings intentionally contain new attendees.
        personal_reward = None if allow_duplicate else await accepted_personal_reward(session, int(identity.id), event_id)
    max_count = min(remaining, MAX_PARTICIPANTS_PER_BOOKING, remaining_for_user)
    await state.update_data(
        event_id=event_id,
        user_id=user.id,
        participants=[],
        current_index=0,
        booker_phone=user.phone_number,
        booker_telegram_id=int(identity.id),
        booker_first_name=user.first_name,
        booker_last_name=user.last_name,
        allow_duplicate=allow_duplicate,
        personal_reward_id=int(personal_reward.id) if personal_reward else None,
        discount_code_id=int(personal_reward.id) if personal_reward else None,
        discount_prompt_skipped=bool(personal_reward),
        max_count=max_count,
        pricing_option=BASE_OPTION,
        # Callback entry originates from a bot-authored panel message; reuse it
        # as the first registration prompt. A /start message from the user itself
        # must remain untouched, so the renderer will send a fresh bot prompt.
        booking_flow_message_id=(
            int(message.message_id)
            if bool(getattr(getattr(message, "from_user", None), "is_bot", False))
            else None
        ),
    )
    if int(event.price_per_person or 0) > 0 and event.price_without_cafe_order and int(event.price_without_cafe_order) > int(event.price_per_person):
        await state.set_state(BookingStates.selecting_pricing)
        await _render_booking_prompt(
            message, state, "روش ثبت‌نام را انتخاب کنید:",
            booking_pricing_keyboard(int(event.price_per_person), int(event.price_without_cafe_order)),
        )
        return
    # A zero base price means entirely free; no cafe-waiver choice or discount.
    if int(event.price_per_person or 0) == 0:
        await state.update_data(discount_code_id=None, personal_reward_id=None, discount_prompt_skipped=True, pricing_option=BASE_OPTION)
    await _booking_count_prompt(message, state, event)


async def _event_details_for_callback(c: CallbackQuery, event_id: int, return_page: int = 0):
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if event is None:
            await c.answer("این پنل دیگر در دسترس نیست.", show_alert=True)
            await show_events(c, return_page)
            return
        if event.archived:
            await c.message.edit_text("این پنل برگزار شده و آرشیو شده است.", reply_markup=main_menu())
            return await c.answer()
        if event.status.value != "published":
            await c.answer("این پنل دیگر برای کاربران فعال نیست.", show_alert=True)
            await show_events(c, return_page)
            return
        used = await seats_used(session, event.id)
        waitlisted = await _user_is_waitlisted(session, event.id, c.from_user.id)
    can_register = registration_is_open(event) and used < event.capacity
    waitlist = waitlist_is_available(event, used)
    await c.message.edit_text(
        event_text(event, used),
        reply_markup=event_buttons(event.id, can_register, waitlist, event.map_url, waitlisted=waitlisted, return_page=return_page),
        disable_web_page_preview=True,
    )
    await c.answer()


async def _continue_profile_after_name(message: Message, state: FSMContext) -> None:
    """Continue onboarding after both name fields have been validated and persisted."""
    state_data = await state.get_data()
    async with SessionLocal() as session:
        saved_user = (await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )).scalar_one()
        has_phone = bool(saved_user.phone_number)
        needs_referral = not bool(saved_user.referral_prompt_completed)

    pending_payload = str(state_data.get("pending_start_payload") or "")
    pending_allow_duplicate = bool(state_data.get("pending_allow_duplicate"))
    if not has_phone:
        await message.answer(accepted_name_phone_prompt(), reply_markup=profile_phone_keyboard())
        await state.set_state(ProfileStates.waiting_phone)
        return
    if needs_referral:
        await state.update_data(
            pending_start_payload=pending_payload,
            pending_allow_duplicate=pending_allow_duplicate,
        )
        await ask_referral_choice(message, state)
        return

    await state.clear()
    if pending_payload and await dispatch_start_payload(
        message, state, pending_payload, allow_duplicate=pending_allow_duplicate, telegram_user=message.from_user
    ):
        return
    await message.answer("✅ اطلاعات پروفایل شما به‌روزرسانی شد.", reply_markup=main_menu())


@router.message(ProfileStates.waiting_full_name)
@router.message(ProfileStates.waiting_first_name)
@router.message(ProfileStates.waiting_last_name)
async def save_full_name(message: Message, state: FSMContext):
    """Collect first and last name in one validated message during initial onboarding."""
    parsed = parse_full_name(message.text or "")
    if parsed is None:
        await message.answer(invalid_full_name_prompt())
        return

    first_name, last_name = parsed
    async with SessionLocal() as session:
        user = (await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )).scalar_one()
        user.first_name = first_name
        user.last_name = last_name
        user.display_name = f"{first_name} {last_name}".strip()
        await session.commit()

    await _continue_profile_after_name(message, state)


@router.message(ProfileStates.waiting_phone)
async def save_phone(message: Message, state: FSMContext):
    if message.contact and message.contact.user_id != message.from_user.id:
        return await message.answer("لطفاً شمارهٔ خودتان را از دکمهٔ ارسال شماره بفرستید یا شماره را دستی وارد کنید.", reply_markup=profile_phone_keyboard())
    phone = (message.contact.phone_number if message.contact else (message.text or "")).strip()
    normalized_phone = normalize_iranian_mobile(phone)
    if normalized_phone is None:
        await message.answer("شماره نامعتبر است. یک شماره موبایل معتبر، مثل 09151118888، وارد کنید.")
        return
    async with SessionLocal() as session:
        user = (await session.execute(select(User).where(User.telegram_id == message.from_user.id))).scalar_one()
        user.phone_number = normalized_phone
        await session.commit()
        needs_referral = not bool(user.referral_prompt_completed)
    state_data = await state.get_data()
    pending_payload = str(state_data.get("pending_start_payload") or "")
    pending_allow_duplicate = bool(state_data.get("pending_allow_duplicate"))
    if needs_referral:
        await state.update_data(
            pending_start_payload=pending_payload,
            pending_allow_duplicate=pending_allow_duplicate,
        )
        await message.answer("✅ شماره ذخیره شد.", reply_markup=hide_reply_keyboard())
        await ask_referral_choice(message, state)
        return
    await message.answer("✅ شماره ذخیره شد.", reply_markup=hide_reply_keyboard())
    await state.clear()
    if pending_payload and await dispatch_start_payload(
        message, state, pending_payload, allow_duplicate=pending_allow_duplicate, telegram_user=message.from_user
    ):
        return
    home_message = await message.answer("✅ اطلاعات شما با موفقیت ثبت شد.\n\n" + main_menu_welcome_text(), reply_markup=hide_reply_keyboard())
    try:
        await home_message.edit_reply_markup(reply_markup=main_menu())
    except Exception:
        await message.answer(main_menu_welcome_text(), reply_markup=main_menu())


EVENT_LIST_PAGE_SIZE = 7


async def show_events(message_or_query, page: int = 0):
    """Render a database-paginated public panel catalogue with one grouped seat query."""
    async with SessionLocal() as session:
        base_query = participant_events_statement()
        total = int(await session.scalar(select(func.count()).select_from(base_query.order_by(None).subquery())) or 0)
        if total:
            page_count = max(1, (total + EVENT_LIST_PAGE_SIZE - 1) // EVENT_LIST_PAGE_SIZE)
            page = min(max(0, int(page)), page_count - 1)
            events = (await session.execute(
                base_query.offset(page * EVENT_LIST_PAGE_SIZE).limit(EVENT_LIST_PAGE_SIZE)
            )).scalars().all()
            event_ids = [int(event.id) for event in events]
            if event_ids:
                # Use the same authoritative seat-holding statuses as capacity
                # validation and channel/group status reconciliation.
                grouped = (await session.execute(
                    select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
                    .where(Booking.event_id.in_(event_ids), Booking.status.in_(ACTIVE_BOOKING_STATUSES))
                    .group_by(Booking.event_id)
                )).all()
                used_by_event = {int(event_id): int(count or 0) for event_id, count in grouped}
            else:
                used_by_event = {}
        else:
            events, used_by_event, page_count = [], {}, 1
    if not events:
        text = "در حال حاضر پنلی برای نمایش در بخش «پنل‌های پیش‌رو» وجود ندارد."
        if isinstance(message_or_query, CallbackQuery):
            await message_or_query.message.edit_text(text, reply_markup=main_menu())
        else:
            await message_or_query.answer(text, reply_markup=main_menu())
        return

    text = (
        "<b>🏠 پنل‌های پیش‌رو</b>\n"
        "پنل‌ها به‌صورت خلاصه نمایش داده شده‌اند.\n"
        "برای جزئیات و ثبت‌نام، پنل را انتخاب کنید.\n"
        + (f"<i>صفحهٔ {_fa_digits(page + 1)} از {_fa_digits(page_count)} · {_fa_digits(total)} پنل</i>\n\n" if page_count > 1 else f"<i>{_fa_digits(total)} پنل</i>\n\n")
    )
    event_blocks = []
    for event in events:
        used = int(used_by_event.get(int(event.id), 0))
        remaining = max(0, int(event.capacity or 0) - used)
        start = str(event.start_time_label or "—")
        end = str(event.end_time_label or "—")
        time_label = start if not has_end_time_label(end) else f"{start}–{end}"
        seats_label = public_catalogue_availability_label(
            int(event.capacity or 0),
            remaining,
            registration_open=registration_is_open(event),
            waitlist_available=waitlist_is_available(event, used),
        )
        # Compact Persian metadata keeps public catalogue cards consistent while
        # preserving the same capacity-aware disclosure policy.
        base_price = int(event.price_per_person or 0)
        alternative_price = int(event.price_without_cafe_order) if event.price_without_cafe_order else 0
        if base_price == 0:
            list_price = "رایگان"
        elif alternative_price > base_price:
            list_price = f"{_compact_toman(base_price)} + کافه / {_compact_toman(alternative_price)} بدون سفارش"
        else:
            list_price = _compact_toman(base_price)
        # The level-two copy is intentionally rendered verbatim, as requested;
        # ordinary capacity/remaining-seat labels keep the existing chair marker.
        availability_line = (
            seats_label
            if seats_label == "ظرفیت پنل در حال تکمیل است."
            else f"🪑 {seats_label}"
        )
        event_blocks.append(
            f"<b>{escape(volume_label(event.volume))} – {escape(str(event.title)[:80])}</b>\n"
            + panel_detail_line("روز و تاریخ", f"{escape(str(event.event_day_label or '—')[:35])} · {escape(str(event.event_date_label or '—')[:55])}", icon="📅") + "\n"
            + panel_detail_line("ساعت", escape(time_label), icon="⏰") + "\n"
            + panel_detail_line("هزینه", escape(list_price), icon="💰") + "\n"
            + rtl_isolate(availability_line)
        )
    # The inline keyboard is attached to this exact catalogue message. Avoid a
    # trailing blank paragraph after the last panel, which visually separates it.
    text += "\n\n".join(event_blocks)
    keyboard = available_events_keyboard(events, page=page)
    # Insert paging controls above the final Main Menu row. Each page contains at
    # most seven panels, with exactly one full-width button row per panel.
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"user:events:page:{page - 1}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"user:events:page:{page + 1}"))
    if nav:
        keyboard.inline_keyboard.insert(len(keyboard.inline_keyboard) - 1, nav)
    if isinstance(message_or_query, CallbackQuery):
        await message_or_query.message.edit_text(limit_telegram_html(text), reply_markup=keyboard, disable_web_page_preview=True)
    else:
        await message_or_query.answer(limit_telegram_html(text), reply_markup=keyboard, disable_web_page_preview=True)


async def _protect_active_user_flow(c: CallbackQuery, state: FSMContext) -> bool:
    """Prevent stale navigation keyboards from silently clearing an active FSM."""
    if await state.get_state():
        await c.answer(
            "مرحلهٔ فعلی شما هنوز فعال است. آن را تکمیل کنید یا برای لغو /cancel را بزنید.",
            show_alert=True,
        )
        return True
    return False


@router.callback_query(F.data == "user:events")
async def events_callback(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await c.answer()
    await show_events(c)


@router.callback_query(F.data.regexp(r"^user:events:page:\d+$"))
async def events_page_callback(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    try:
        page = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await show_events(c, page)
    await c.answer()


@router.callback_query(F.data.startswith("event:open:"))
async def open_event(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    try:
        parts = c.data.split(":")
        event_id = int(parts[2])
        return_page = int(parts[3]) if len(parts) > 3 else 0
    except (ValueError, IndexError):
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    await _event_details_for_callback(c, event_id, return_page=max(0, return_page))


@router.callback_query(F.data == "user:home")
async def home(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await c.answer()
    await c.message.edit_text(main_menu_welcome_text(), reply_markup=main_menu())


@router.callback_query(F.data.startswith("event:register:"))
async def begin_register(c: CallbackQuery, state: FSMContext):
    await get_or_create_user(c.from_user)
    try:
        event_id = int(c.data.split(":")[2])
    except (ValueError, IndexError):
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    await begin_register_from_message(c.message, state, event_id, telegram_user=c.from_user)
    await c.answer()


async def _process_booking_count(count: int, message: Message, state: FSMContext, telegram_id: int):
    data = await state.get_data()
    user_id = int(data.get("user_id") or 0)
    if count < 1 or count > MAX_PARTICIPANTS_PER_BOOKING:
        return await message.answer(f"لطفاً تعداد را بین ۱ تا {MAX_PARTICIPANTS_PER_BOOKING} انتخاب کنید.")

    async with SessionLocal() as session:
        event = await session.get(Event, int(data.get("event_id") or 0))
        owner = await session.get(User, user_id)
        if owner is None or int(owner.telegram_id) != int(telegram_id):
            await state.clear()
            return await message.answer("اطلاعات ثبت‌نام پیدا نشد. لطفاً دوباره از صفحه پنل اقدام کنید.", reply_markup=main_menu())
        if event is None or not await event_is_bookable(event):
            await state.clear()
            return await message.answer("ثبت‌نام این پنل دیگر باز نیست.", reply_markup=main_menu())
        if not owner.first_name or not owner.last_name or not owner.phone_number:
            await state.update_data(
                pending_start_payload=f"reg_{event.id}",
                pending_allow_duplicate=bool(data.get("allow_duplicate")),
            )
            return await continue_onboarding(message, state, owner)
        await expire_old_bookings(session)
        used = await seats_used(session, event.id)
        available = max(0, int(event.capacity) - used)
        active_user_seats = await active_seats_for_owner(session, event.id, user_id)

    max_allowed = min(
        int(data.get("max_count") or MAX_PARTICIPANTS_PER_BOOKING),
        available,
        MAX_PARTICIPANTS_PER_BOOKING,
        max(0, MAX_ACTIVE_SEATS_PER_USER_PER_PANEL - active_user_seats),
    )
    if count > max_allowed:
        await message.answer(
            f"در حال حاضر برای این ثبت‌نام حداکثر {max_allowed} نفر ظرفیت دارید. لطفاً تعداد را دوباره انتخاب کنید.",
            reply_markup=booking_count_keyboard(max_allowed) if max_allowed > 0 else main_menu(),
        )
        if max_allowed <= 0:
            await state.clear()
        return

    # On an initial booking, participant one is the account holder and their
    # saved profile is reused. On an explicit additional booking, every attendee
    # is a new person, so even a one-person booking must collect that person's name.
    additional_booking = bool(data.get("allow_duplicate"))
    participants = [] if additional_booking else [{
        "first_name": owner.first_name,
        "last_name": owner.last_name,
    }]
    current_index = 0 if additional_booking else 1
    await state.update_data(
        count=count,
        current_index=current_index,
        participants=participants,
        booker_phone=owner.phone_number,
        booker_telegram_id=int(owner.telegram_id),
        booker_first_name=owner.first_name,
        booker_last_name=owner.last_name,
    )
    if count == 1 and not additional_booking:
        await show_booking_summary(message, state)
        return

    await state.set_state(BookingStates.waiting_participant_name)
    if additional_booking and count == 1:
        prompt = "🧾 مرحلهٔ ۱ از ۳ – مشخصات شرکت‌کنندگان\n\nنام و نام خانوادگی نفر جدید را یکجا وارد کنید:"
    elif additional_booking:
        prompt = "🧾 مرحلهٔ ۱ از ۳ – مشخصات شرکت‌کنندگان\n\nنام و نام خانوادگی نفر ۱ از ثبت‌نام جدید را یکجا وارد کنید:"
    else:
        prompt = "🧾 مرحلهٔ ۱ از ۳ – مشخصات شرکت‌کنندگان\n\nنام و نام خانوادگی نفر ۲ را یکجا وارد کنید:"
    await _render_booking_prompt(message, state, prompt)


@router.callback_query(F.data.regexp(r"^booking:pricing:(base|without_cafe)$"))
async def booking_pricing_select(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_pricing.state:
        return await c.answer("این انتخاب دیگر فعال نیست؛ لطفاً ثبت‌نام را دوباره آغاز کنید.", show_alert=True)
    data = await state.get_data()
    if int(data.get("booker_telegram_id") or 0) != int(c.from_user.id):
        return await c.answer("این ثبت‌نام متعلق به حساب شما نیست؛ لطفاً دوباره اقدام کنید.", show_alert=True)
    option = WITHOUT_CAFE_ORDER if c.data.endswith(":without_cafe") else BASE_OPTION
    async with SessionLocal() as session:
        event = await session.get(Event, int(data.get("event_id") or 0))
        if event is None or not await event_is_bookable(event):
            await state.clear()
            await c.answer("ثبت‌نام این پنل دیگر باز نیست.", show_alert=True)
            if c.message:
                await c.message.edit_text("ثبت‌نام این پنل دیگر باز نیست.", reply_markup=main_menu())
            return
        if option == WITHOUT_CAFE_ORDER and (
            int(event.price_per_person or 0) <= 0
            or not event.price_without_cafe_order
            or int(event.price_without_cafe_order) <= int(event.price_per_person)
        ):
            return await c.answer("این گزینه دیگر در دسترس نیست؛ گزینهٔ پایه را انتخاب کنید.", show_alert=True)
    await state.update_data(pricing_option=option)
    await c.answer()
    if data.get("pricing_return_to_summary"):
        await state.update_data(pricing_return_to_summary=False)
        await show_booking_summary(c.message, state)
        return
    await _booking_count_prompt(c.message, state, event)


@router.callback_query(F.data.regexp(r"^booking:count:[123]$"))
async def booking_count_callback(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.waiting_count.state:
        return await c.answer("این مرحله دیگر فعال نیست. لطفاً ثبت‌نام را دوباره آغاز کنید.", show_alert=True)
    try:
        count = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("تعداد نامعتبر است.", show_alert=True)
    await c.answer()
    if not c.message:
        return
    await _process_booking_count(count, c.message, state, int(c.from_user.id))


@router.message(BookingStates.waiting_count)
async def booking_count(message: Message, state: FSMContext):
    count = parse_integer(message.text or "", minimum=1, maximum=MAX_PARTICIPANTS_PER_BOOKING)
    if count is None:
        data = await state.get_data()
        maximum = max(1, min(MAX_PARTICIPANTS_PER_BOOKING, int(data.get("max_count") or MAX_PARTICIPANTS_PER_BOOKING)))
        await message.answer("لطفاً تعداد نفرات را با انتخاب یکی از گزینه‌ها مشخص کنید.", reply_markup=booking_count_keyboard(maximum))
        return
    await _process_booking_count(count, message, state, int(message.from_user.id))


@router.message(BookingStates.waiting_participant_name)
async def participant_name(message: Message, state: FSMContext):
    parsed = parse_full_name(message.text or "")
    if parsed is None:
        return await message.answer(
            "لطفاً نام و نام خانوادگی را یکجا و با فاصله وارد کنید.\nمثال: سینا ضیائی"
        )

    first, last = parsed
    data = await state.get_data()
    await state.update_data(current_first_name=first, current_last_name=last)
    # The account phone is collected once during onboarding/profile setup. Do not
    # ask for it again during each booking; proceed directly to the next attendee.
    await _append_current_non_booker_and_continue(message, state)


async def _append_current_non_booker_and_continue(message: Message, state: FSMContext):
    data = await state.get_data()
    participants = list(data.get("participants", []))
    participants.append({
        "first_name": data["current_first_name"],
        "last_name": data["current_last_name"],
    })
    index = int(data["current_index"]) + 1
    count = int(data["count"])
    await state.update_data(participants=participants, current_index=index)
    if index < count:
        await _render_booking_prompt(message, state, f"🧾 مرحلهٔ ۱ از ۳ – مشخصات شرکت‌کنندگان\n\nنام و نام خانوادگی نفر {_fa_digits(index + 1)} را یکجا وارد کنید:")
        await state.set_state(BookingStates.waiting_participant_name)
        return
    await show_booking_summary(message, state, new_message=True)


@router.message(BookingStates.waiting_booker_phone)
async def booking_booker_phone(message: Message, state: FSMContext):
    if message.contact and message.contact.user_id != message.from_user.id:
        return await message.answer("لطفاً شمارهٔ خودتان را ارسال کنید یا شماره را دستی وارد کنید.", reply_markup=profile_phone_keyboard())
    phone = message.contact.phone_number if message.contact else (message.text or "")
    normalized_phone = normalize_iranian_mobile(phone)
    if normalized_phone is None:
        return await message.answer(
            "شماره نامعتبر است. لطفاً یک شماره موبایل معتبر، مثل 09151118888، وارد کنید."
        )

    data = await state.get_data()
    participants = list(data.get("participants", []))
    participants.append({
        "first_name": data["current_first_name"],
        "last_name": data["current_last_name"],
    })
    count = int(data["count"])
    await state.update_data(participants=participants, current_index=1, booker_phone=normalized_phone)
    if count > 1:
        await message.answer("🧾 مرحلهٔ ۱ از ۳ – مشخصات شرکت‌کنندگان\n\nنام و نام خانوادگی نفر ۲ را یکجا وارد کنید:")
        await state.set_state(BookingStates.waiting_participant_name)
        return
    await show_booking_summary(message, state)


async def show_booking_summary(message: Message, state: FSMContext, *, new_message: bool = False):
    data = await state.get_data()
    async with SessionLocal() as session:
        event = await session.get(Event, int(data["event_id"]))
        if event is None or not await event_is_bookable(event):
            await state.clear()
            return await message.answer("این پنل دیگر قابل ثبت‌نام نیست.", reply_markup=main_menu())

        option = str(data.get("pricing_option") or BASE_OPTION)
        option_notice = ""
        if int(event.price_per_person or 0) == 0:
            # Free panels never ask for a price option or apply any discount.
            # If an approved restricted-code request was attached to this draft,
            # withdraw it when the free booking is ultimately committed so it
            # does not consume the code's shared cap indefinitely.
            option = BASE_OPTION
            existing_redemption = data.get("discount_redemption_id")
            updates = {
                "pricing_option": BASE_OPTION, "discount_code_id": None,
                "personal_reward_id": None, "discount_redemption_id": None,
                "discount_prompt_skipped": True, "discount_amount": 0,
            }
            if existing_redemption:
                updates["continue_full_price_redemption_id"] = int(existing_redemption)
            await state.update_data(**updates)
            data = await state.get_data()
        elif option == WITHOUT_CAFE_ORDER and (
            not event.price_without_cafe_order
            or int(event.price_without_cafe_order) <= int(event.price_per_person)
        ):
            option = BASE_OPTION
            option_notice = "⚠️ گزینهٔ بدون سفارش کافه دیگر در دسترس نیست؛ گزینهٔ پایه انتخاب شد.\n\n"
            await state.update_data(pricing_option=BASE_OPTION, discount_unavailable_notice=False)
            data = await state.get_data()
        await state.update_data(
            checkout_base_price=str(event.price_per_person),
            checkout_alternative_price=(str(event.price_without_cafe_order) if event.price_without_cafe_order is not None else ""),
        )

        code = None
        code_id = data.get("discount_code_id") if int(event.price_per_person or 0) > 0 else None
        if code_id:
            code = await session.get(DiscountCode, int(code_id))
            linked = (await session.execute(select(DiscountCodeEvent.id).where(
                DiscountCodeEvent.discount_code_id == int(code_id),
                DiscountCodeEvent.event_id == event.id,
            ))).scalar_one_or_none()
            if not code or not code.active or linked is None:
                code = None
                updates = {
                    "discount_code_id": None, "personal_reward_id": None,
                    "discount_redemption_id": None, "discount_prompt_skipped": True,
                    "discount_amount": 0,
                }
                if data.get("discount_redemption_id"):
                    updates["continue_full_price_redemption_id"] = int(data["discount_redemption_id"])
                await state.update_data(**updates)
                data = await state.get_data()

        if int(event.price_per_person or 0) > 0 and code is None and not data.get("discount_prompt_skipped"):
            reward = None
            if not data.get("allow_duplicate") and not data.get("skip_personal_reward_once"):
                reward = await accepted_personal_reward(
                    session, int(data.get("booker_telegram_id") or message.from_user.id), event.id
                )
            if reward:
                code = reward
                await state.update_data(
                    discount_code_id=int(reward.id), personal_reward_id=int(reward.id),
                    discount_prompt_skipped=True,
                )
                data = await state.get_data()
            elif await eligible_public_codes_exist(session, event.id, int(data.get("booker_telegram_id") or message.from_user.id)):
                await state.set_state(BookingStates.waiting_discount_choice)
                return await _render_booking_prompt(
                    message, state,
                    "🎟 <b>کد تخفیف دارید؟</b>",
                    user_discount_prompt_keyboard(),
                )

    participants = list(data.get("participants", []))
    count = int(data.get("count", len(participants)))
    components = calculate_price_components(
        event.price_per_person, event.price_without_cafe_order, option, count
    )
    original_total = components.gross_total
    discount_amount = Decimal(0)
    final_total = original_total
    discount_line = ""
    waiver_discount_notice = ""
    if code is not None and int(event.price_per_person or 0) > 0:
        scope = "total" if code.kind == "public" else "single"
        discount_amount = calculate_discount(
            components.discountable_base_total, Decimal(event.price_per_person), count,
            code.discount_type, code.discount_value, scope=scope,
        )
        final_total = max(Decimal(0), original_total - discount_amount)
        scope_note = "برای کل ثبت‌نام" if code.kind == "public" else "برای یک نفر"
        discount_line = (
            f"\nکد/هدیه: <b>{escape(code.code or code.label or 'هدیه شخصی')}</b>"
            f"\nتخفیف ({scope_note}): <b>{int(discount_amount):,}− تومان</b>"
            f"\nمبلغ قبل از تخفیف: <s>{int(original_total):,} تومان</s>"
        )
        if option == WITHOUT_CAFE_ORDER:
            waiver_discount_notice = "\n<i>تخفیف فقط از هزینهٔ پایه کم می‌شود؛ مبلغ مربوط به عدم سفارش از کافه شامل تخفیف نمی‌شود.</i>"
        await state.update_data(discount_code_id=int(code.id), discount_amount=int(discount_amount))
    else:
        await state.update_data(discount_amount=0)
    time_text = str(event.start_time_label or "—")
    if has_end_time_label(event.end_time_label):
        time_text += f"–{event.end_time_label}"
    lines = "\n".join(
        f"\u200f{i + 1}. \u2066{escape(p['first_name'] + ' ' + p['last_name'])}\u2069"
        for i, p in enumerate(participants)
    )
    notice = ""
    if data.get("pricing_changed_notice"):
        notice = "⚠️ قیمت پنل تغییر کرده است؛ مبلغ جدید را بررسی کنید.\n\n"
        await state.update_data(pricing_changed_notice=False)
    if data.get("discount_unavailable_notice"):
        notice += "⚠️ تخفیف دیگر قابل استفاده نیست؛ مبلغ عادی محاسبه شده است.\n\n"
        await state.update_data(discount_unavailable_notice=False)
    reward_acknowledgement = ""
    if code is not None and code.kind == "personal":
        reward_acknowledgement = (
            "\n\n🎁 با تأیید این رزرو، تأیید می‌کنید که خودتان یکی از شرکت‌کنندگان هستید؛ "
            "هدیه فقط هزینه یک نفر را پوشش می‌دهد."
        )
    pricing_detail = ""
    if int(event.price_per_person or 0) == 0:
        pricing_detail = rtl_isolate("💵 <b>هزینه: رایگان</b>") + "\n"
    elif event.price_without_cafe_order and int(event.price_without_cafe_order) > int(event.price_per_person):
        if option == WITHOUT_CAFE_ORDER:
            pricing_detail = (
                rtl_isolate("شیوهٔ ثبت‌نام: بدون سفارش اجباری از منوی کافه") + "\n"
                + panel_detail_line("هزینه هر نفر", f"{int(event.price_without_cafe_order):,} تومان", icon="💵") + "\n"
            )
        else:
            pricing_detail = (
                rtl_isolate("شیوهٔ ثبت‌نام: پایه + سفارش از منوی کافه") + "\n"
                + panel_detail_line("هزینه هر نفر", f"{int(event.price_per_person):,} تومان + سفارش از منوی کافه", icon="💵") + "\n"
            )
    else:
        pricing_detail = panel_detail_line("هزینه هر نفر", f"{int(event.price_per_person):,} تومان", icon="💵") + "\n" if int(event.price_per_person or 0) else rtl_isolate("💵 <b>هزینه: رایگان</b>") + "\n"
    await state.set_state(BookingStates.confirm)
    panel_label = _booking_summary_panel_label(event)
    summary = (
        "<b>🧾 مرحلهٔ ۲ از ۳ – بررسی و تأیید ثبت‌نام</b>\n\n"
        + f"🎟 <b>پنل:</b> {panel_label}\n"
        + (panel_detail_line("زبان پنل", escape(event.language), icon="🌐") + "\n" if event.language else "")
        + panel_detail_line("روز و تاریخ", f"{escape(event.event_day_label)} – {escape(event.event_date_label)}", icon="📅") + "\n"
        + panel_detail_line("ساعت", escape(time_text), icon="⏰") + "\n\n"
        + f"👥 <b>شرکت‌کنندگان</b>\n{lines}\n\n"
        + panel_detail_line("شماره تماس ثبت‌کننده", escape(data['booker_phone']), icon="📱") + "\n"
        + panel_detail_line("تعداد نفرات", count, icon="👤") + "\n"
        + pricing_detail
        + f"{option_notice}{notice}{discount_line}{waiver_discount_notice}\n"
        + rtl_isolate(f"💳 <b>مبلغ قابل پرداخت: {int(final_total):,} تومان</b>")
        + f"{reward_acknowledgement}\n\n"
        + "برای ثبت نهایی، دکمهٔ «تأیید و ثبت‌نام» را بزنید؛ برای خروج از این فرایند، «انصراف» را انتخاب کنید."
    )
    await _render_booking_prompt(message, state, summary, booking_confirmation_keyboard(), new_message=new_message)


@router.callback_query(F.data == "booking:discount:enter")
async def booking_discount_enter(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.waiting_discount_choice.state:
        return await c.answer("این مرحله دیگر فعال نیست؛ دوباره از ثبت‌نام پنل اقدام کنید.", show_alert=True)
    await state.set_state(BookingStates.waiting_discount_code)
    await c.message.edit_text(
        "🧾 <b>مرحلهٔ ۲ از ۳ – بررسی و تأیید</b>\n\n🎟 کد تخفیف خود را وارد کنید.\n\n"
        "کد را دقیقاً همان‌طور که دریافت کرده‌اید وارد کنید.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="ادامه بدون کد", callback_data="booking:discount:skip")
        ]]),
    )
    await c.answer()


@router.callback_query(F.data == "booking:discount:skip")
async def booking_discount_skip(c: CallbackQuery, state: FSMContext):
    current = await state.get_state()
    if current not in (BookingStates.waiting_discount_choice.state, BookingStates.waiting_discount_code.state):
        return await c.answer("این مرحله دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    updates = {
        "discount_prompt_skipped": True, "discount_code_id": None,
        "personal_reward_id": None, "discount_redemption_id": None,
        "skip_personal_reward_once": False, "discount_amount": 0,
    }
    # If the participant is replacing an approved restricted-code request,
    # withdraw it only when the new booking is committed. Cancelling checkout
    # must leave the previous approval recoverable.
    if data.get("discount_redemption_id"):
        updates["continue_full_price_redemption_id"] = int(data["discount_redemption_id"])
    await state.update_data(**updates)
    await c.answer()
    await show_booking_summary(c.message, state)


@router.message(BookingStates.waiting_discount_code, F.text)
async def booking_discount_code_receive(message: Message, state: FSMContext):
    raw = (message.text or "").strip()
    if not raw or raw.startswith("/"):
        return await _render_booking_prompt(message, state, "لطفاً کد تخفیف را وارد کنید یا «ادامه بدون کد» را بزنید.", InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="ادامه بدون کد", callback_data="booking:discount:skip")
        ]]))
    data = await state.get_data()
    user = await get_or_create_user(message.from_user)
    event_id = int(data.get("event_id") or 0)
    try:
        async with SessionLocal() as session:
            code = await validate_code_for_user(
                session, raw_code=raw, telegram_id=int(message.from_user.id), event_id=event_id
            )
            event = await session.get(Event, event_id)
            if event is None or not await event_is_bookable(event):
                return await message.answer("ثبت‌نام این پنل دیگر باز نیست.", reply_markup=main_menu())
            if code.kind == "restricted" or code.requires_approval:
                # When a user replaces an approved request with a new restricted
                # request, release the previous approval in the same transaction
                # that creates the new pending request.
                old_redemption_id = data.get("continue_full_price_redemption_id")
                old_redemption = None
                if old_redemption_id:
                    old_redemption = (await session.execute(
                        select(DiscountRedemption).where(
                            DiscountRedemption.id == int(old_redemption_id),
                        ).with_for_update()
                    )).scalar_one_or_none()
                    if (
                        not old_redemption
                        or old_redemption.user_telegram_id != int(message.from_user.id)
                        or old_redemption.event_id != event_id
                        or old_redemption.status not in ("pending", "approved", "rejected")
                        or old_redemption.id == int(data.get("discount_redemption_id") or 0)
                    ):
                        raise ValueError("DISCOUNT_REQUEST_NOT_APPROVED")
                participants = list(data.get("participants", []))
                draft = {
                    "event_id": event_id,
                    "participants": participants,
                    "booker_phone": data.get("booker_phone"),
                    "allow_duplicate": bool(data.get("allow_duplicate")),
                    "pricing_option": str(data.get("pricing_option") or BASE_OPTION),
                }
                count = max(1, len(participants))
                components = calculate_price_components(
                    event.price_per_person, event.price_without_cafe_order,
                    str(data.get("pricing_option") or BASE_OPTION), count,
                )
                original = components.gross_total
                amount = calculate_discount(
                    components.discountable_base_total, Decimal(event.price_per_person), count,
                    code.discount_type, code.discount_value, scope="single",
                )
                now = utc_now_naive()
                redemption = DiscountRedemption(
                    discount_code_id=code.id,
                    code_snapshot=code.code or "",
                    event_id=event.id,
                    event_label_snapshot=f"{volume_label(event.volume)} — {event.title}",
                    user_telegram_id=int(message.from_user.id),
                    status="pending",
                    draft_json=json.dumps(draft, ensure_ascii=False),
                    contact_phone=data.get("booker_phone"),
                    participant_count=count,
                    allow_duplicate=bool(data.get("allow_duplicate")),
                    original_total=original,
                    discount_amount=amount,
                    final_total=max(Decimal(0), original - amount),
                    created_at=now,
                    updated_at=now,
                )
                session.add(redemption)
                if old_redemption is not None:
                    old_redemption.status = "withdrawn"
                    old_redemption.draft_json = None
                    old_redemption.contact_phone = None
                    old_redemption.updated_at = now
                await session.commit()
                redemption_id = int(redemption.id)
                event_label = f"{volume_label(event.volume)} — {event.title}"
                code_label_text = code.code or ""
            elif code.kind == "public" and not code.requires_approval:
                await state.update_data(
                    discount_code_id=int(code.id), discount_redemption_id=None,
                    personal_reward_id=None, discount_prompt_skipped=True,
                )
                await show_booking_summary(message, state)
                return
            else:
                raise ValueError("CODE_INVALID")
    except ValueError as exc:
        message_text = {
            "CODE_ALREADY_USED": "این کد قبلاً توسط حساب شما استفاده شده یا درخواست آن رد شده است.",
            "CODE_UNAVAILABLE": "ظرفیت استفاده از این کد تکمیل شده است.",
            "CODE_INACTIVE": "این کد دیگر فعال نیست. می‌توانید کد دیگری وارد کنید یا بدون تخفیف ادامه دهید.",
            "CODE_NOT_FOR_PANEL": "این کد برای پنل انتخاب‌شده تعریف نشده است. کد مربوط به همین پنل را وارد کنید یا بدون تخفیف ادامه دهید.",
            "CODE_NOT_APPLICABLE": "این کد برای ورود دستی قابل استفاده نیست. اگر هدیه‌ای برای شما ثبت شده، از بخش مربوط به هدیه اقدام کنید؛ در غیر این صورت بدون کد ادامه دهید.",
        }.get(str(exc), "کد پیدا نشد یا معتبر نیست. املای کد را بررسی کنید، کد دیگری وارد کنید یا بدون تخفیف ادامه دهید.")
        return await _render_booking_prompt(
            message, state,
            f"❌ {message_text}\nاطلاعات ثبت‌نام شما حفظ شده است.",
            InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="ادامه بدون کد", callback_data="booking:discount:skip")
            ]]),
        )
    except Exception:
        logger.exception("Could not create discount approval request for user_id=%s", message.from_user.id)
        return await _render_booking_prompt(
            message, state, "ثبت درخواست تخفیف انجام نشد. دوباره تلاش کنید یا بدون کد ادامه دهید.",
            InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="ادامه بدون کد", callback_data="booking:discount:skip")
            ]]),
        )

    flow_message_id = data.get("booking_flow_message_id")
    await state.clear()
    pending_text = (
        f"⏳ درخواست استفاده از کد تخفیف <b>{escape(code_label_text)}</b> برای پنل <b>{escape(event_label)}</b> ثبت شد.\n\n"
        "تا زمان بررسی، صندلی‌ای رزرو نمی‌شود.\n"
        "لطفاً تا بررسی درخواست و اعلام نتیجه توسط مدیر منتظر بمانید."
    )
    try:
        if flow_message_id:
            sent = await message.bot.edit_message_text(
                chat_id=message.chat.id, message_id=int(flow_message_id),
                text=pending_text, reply_markup=discount_request_user_keyboard(redemption_id),
            )
        else:
            sent = await message.answer(pending_text, reply_markup=discount_request_user_keyboard(redemption_id))
    except Exception:
        sent = await message.answer(pending_text, reply_markup=discount_request_user_keyboard(redemption_id))
    try:
        async with SessionLocal() as session:
            stored_request = await session.get(DiscountRedemption, redemption_id, with_for_update=True)
            if stored_request and stored_request.status == "pending":
                stored_request.request_message_id = int(sent.message_id)
                await session.commit()
    except Exception:
        logger.exception("Could not store request message id for discount redemption_id=%s", redemption_id)


async def finalize_booking(message: Message, state: FSMContext, telegram_user=None):
    if await state.get_state() != BookingStates.confirm.state:
        return await message.answer("فرآیند ثبت‌نام منقضی شده است.", reply_markup=main_menu())
    data = await state.get_data()
    user = await get_or_create_user(telegram_user or message.from_user)
    payment_card_number, payment_account_name = await _payment_details()
    async with SessionLocal() as session:
        try:
            booking = await create_booking(
                session,
                user.id,
                int(data["event_id"]),
                data["participants"],
                allow_duplicate=bool(data.get("allow_duplicate")),
                contact_phone=data.get("booker_phone"),
                discount_code_id=int(data["discount_code_id"]) if data.get("discount_code_id") else None,
                discount_redemption_id=int(data["discount_redemption_id"]) if data.get("discount_redemption_id") else None,
                cancel_discount_redemption_id=(
                    int(data["continue_full_price_redemption_id"])
                    if data.get("continue_full_price_redemption_id") else None
                ),
                pricing_option=str(data.get("pricing_option") or BASE_OPTION),
                expected_base_price=data.get("checkout_base_price"),
                expected_alternative_price=data.get("checkout_alternative_price"),
                payment_details_configured=bool(payment_card_number and payment_account_name),
            )
        except ValueError as exc:
            reason = str(exc)
            if reason == "PRICE_CHANGED":
                await session.rollback()
                await state.update_data(pricing_changed_notice=True)
                return await show_booking_summary(message, state)
            if reason in {
                "CODE_INVALID", "CODE_UNAVAILABLE", "CODE_ALREADY_USED",
                "CODE_NEEDS_APPROVAL", "PERSONAL_REWARD_NOT_ACCEPTED",
                "DISCOUNT_REQUEST_NOT_APPROVED",
            } and data.get("discount_code_id"):
                await session.rollback()
                redemption_id = data.get("discount_redemption_id")
                if redemption_id:
                    redemption = await session.get(DiscountRedemption, int(redemption_id), with_for_update=True)
                    if redemption and redemption.status == "approved":
                        redemption.status = "rejected"
                        redemption.reviewed_at = utc_now_naive()
                        redemption.updated_at = utc_now_naive()
                        await session.commit()
                await state.update_data(
                    discount_code_id=None, personal_reward_id=None,
                    discount_redemption_id=None, discount_amount=0,
                    discount_prompt_skipped=True, discount_unavailable_notice=True,
                )
                return await show_booking_summary(message, state)
            if reason == "DISCOUNT_REQUEST_NOT_APPROVED" and data.get("continue_full_price_redemption_id"):
                await session.rollback()
                await state.clear()
                return await message.answer(
                    "درخواست تخفیف شما در همین فاصله لغو یا نهایی شده است؛ این رزرو ثبت نشد. "
                    "لطفاً از پنل دوباره اقدام کنید.",
                    reply_markup=main_menu(),
                )
            if reason == "PAYMENT_CONFIGURATION_MISSING":
                await session.rollback()
                event = await session.get(Event, int(data.get("event_id") or 0))
                event_label = f"{volume_label(event.volume)} — {event.title}" if event else f"پنل #{data.get('event_id', '—')}"
                amount = 0
                if event:
                    components = calculate_price_components(
                        event.price_per_person, event.price_without_cafe_order,
                        str(data.get("pricing_option") or BASE_OPTION),
                        max(1, len(list(data.get("participants") or []))),
                    )
                    amount = max(0, int(components.gross_total) - int(data.get("discount_amount") or 0))
                await _notify_payment_configuration_missing(message.bot, event_label, amount)
                return await message.answer(_payment_setup_user_message(), disable_web_page_preview=True)
            if reason == "FULL":
                event = await session.get(Event, int(data["event_id"]))
                used_now = await seats_used(session, int(data["event_id"])) if event else 0
                waitlist_available = bool(event and waitlist_is_available(event, used_now))
                await state.clear()
                if event and waitlist_available:
                    return await message.answer(
                        "ظرفیت این پنل در همین لحظه تکمیل شد؛ صندلی رزرو نشده است. می‌توانید در لیست انتظار قرار بگیرید.",
                        reply_markup=event_buttons(event.id, False, True, event.map_url),
                    )
                return await message.answer(
                    "متأسفیم، ظرفیت این پنل تکمیل شده و لیست انتظار آن فعال نیست؛ در حال حاضر صندلی‌ای در دسترس نیست.",
                    reply_markup=main_menu(),
                )
            await state.clear()
            error = {
                "DUPLICATE": "شما برای این پنل یک رزرو فعال دارید.",
                "EVENT_NOT_OPEN": "ثبت‌نام این پنل در حال حاضر باز نیست.",
                "TOO_MANY": "تعداد انتخاب‌شده از ظرفیت پنل بیشتر است.",
                "MAX_PARTICIPANTS_PER_BOOKING": f"در هر ثبت‌نام حداکثر {MAX_PARTICIPANTS_PER_BOOKING} نفر می‌توانند ثبت شوند.",
                "USER_SEAT_LIMIT": f"حداکثر {MAX_ACTIVE_SEATS_PER_USER_PER_PANEL} صندلی با یک حساب برای این پنل قابل رزرو است.",
                "USER_BOOKING_RESTRICTED": "امکان ثبت رزرو برای حساب شما به‌طور موقت محدود شده است. سایر بخش‌های ربات در دسترس می‌مانند.",
                "PARTICIPANT_NAME_REQUIRED": "نام و نام خانوادگی همه شرکت‌کننده‌ها الزامی است.",
            }.get(reason, "مشکلی در ثبت رزرو پیش آمد.")
            return await message.answer(error, reply_markup=main_menu())

        event_id = booking.event_id
        if booking.status == RegistrationStatus.CONFIRMED:
            event = await session.get(Event, booking.event_id)
            flow_message_id = data.get("booking_flow_message_id")
            await state.clear()
            try:
                if flow_message_id and int(flow_message_id) == int(message.message_id):
                    await message.edit_text("✅ رزرو شما با موفقیت تأیید شد. منتظرتون هستیم!", reply_markup=main_menu())
                else:
                    await message.answer("✅ رزرو شما با موفقیت تأیید شد. منتظرتون هستیم!", reply_markup=main_menu())
            except Exception:
                logger.info("Could not replace free booking summary for booking_id=%s", booking.id, exc_info=True)
                await message.answer("✅ رزرو شما با موفقیت تأیید شد. منتظرتون هستیم!", reply_markup=main_menu())
            if event and event.questions_pdf_path:
                await message.answer("📄 فایل سؤالات این پنل از بخش «سؤالات پنل‌ها» در دسترس است.", reply_markup=questions_keyboard(booking.id))
            if booking.discount_amount and int(booking.total_amount) == 0:
                participant_names = ", ".join(
                    getattr(p, "full_name", "") for p in (getattr(booking, "participants", None) or [])
                    if getattr(p, "full_name", "")
                ) or "—"
                owner_display = user.display_name or " ".join(x for x in [user.first_name, user.last_name] if x) or "کاربر"
                admin_notice = (
                    "🎁 <b>رزرو رایگان تأیید شد</b>\n\n"
                    f"پنل: {escape(f'{volume_label(event.volume)} — {event.title}' if event else str(event_id))}\n"
                    f"رزروکننده: {escape(owner_display)} | ID: <code>{user.telegram_id}</code>\n"
                    f"شرکت‌کنندگان: {escape(participant_names)}\n"
                    f"تخفیف: {int(booking.discount_amount):,} تومان | مبلغ پرداختی: ۰ تومان\n"
                    f"شناسه رزرو: <code>{booking.id}</code>"
                )
                for admin_id in settings.super_admin_id_set:
                    try:
                        await message.bot.send_message(int(admin_id), admin_notice)
                    except Exception:
                        logger.info("Could not notify admin about free confirmed booking_id=%s", booking.id, exc_info=True)
            await reconcile_event_channel_status(message.bot, event_id)
            return

    # Persist the checkout FSM transition before network side effects. If a
    # Telegram edit/reconcile/send fails after the booking transaction commits,
    # an old confirmation button must not be able to attempt a second booking.
    await state.update_data(booking_id=booking.id)
    await state.set_state(BookingStates.waiting_receipt)
    try:
        await reconcile_event_channel_status(message.bot, event_id)
    except Exception:
        logger.exception("Could not reconcile channel status after booking_id=%s was created", booking.id)
    payment_card_number, payment_account_name = await _payment_details()
    await _render_booking_prompt(
        message, state,
        "💳 <b>مرحلهٔ ۳ از ۳ – پرداخت و ارسال رسید</b>\n\n"
        f"مبلغ قابل پرداخت: <b>{int(booking.total_amount):,} تومان</b>\n\n"
        f"شماره کارت: {payment_card_number}\n"
        f"به نام: {payment_account_name}\n\n"
        "📄 رسید را به‌صورت عکس، فایل یا متن ارسال کنید.",
        reply_markup=receipt_upload_keyboard(payment_card_number, int(booking.id)),
    )


@router.callback_query(F.data == "booking:confirm")
async def confirm_booking_callback(c: CallbackQuery, state: FSMContext):
    lock = _confirmation_lock_for(int(c.from_user.id))
    async with lock:
        if await state.get_state() != BookingStates.confirm.state:
            # Stale buttons should only show Telegram's popup. Do not send a new
            # chat message or clear a newer state such as waiting_receipt.
            return await c.answer("ثبت‌نام قبلی دیگر فعال نیست.", show_alert=True)
        await c.answer()
        await finalize_booking(c.message, state, c.from_user)


@router.callback_query(F.data == "booking:cancel")
async def cancel_booking_callback(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.confirm.state:
        # Preserve any current operation (especially receipt submission).
        return await c.answer("ثبت‌نام قبلی دیگر فعال نیست.", show_alert=True)
    await state.clear()
    await c.answer("ثبت‌نام لغو شد.")
    await c.message.edit_text("ثبت‌نام لغو شد.", reply_markup=main_menu())


@router.callback_query(F.data == "booking:edit:start")
async def booking_edit_start(c: CallbackQuery, state: FSMContext):
    current_state = await state.get_state()
    if current_state not in (BookingStates.confirm.state, BookingStates.selecting_edit_participant.state):
        return await c.answer("ویرایش فقط پیش از تأیید ثبت‌نام امکان‌پذیر است.", show_alert=True)
    data = await state.get_data()
    async with SessionLocal() as session:
        event = await session.get(Event, int(data.get("event_id") or 0))
    if event is None or not await event_is_bookable(event):
        return await c.answer("این پنل دیگر قابل ثبت‌نام نیست.", show_alert=True)
    await state.set_state(BookingStates.selecting_edit_field)
    await c.message.edit_text(
        "کدام مورد را می‌خواهید ویرایش کنید؟",
        reply_markup=booking_edit_keyboard(
            has_alternative_price=bool(event.price_without_cafe_order and int(event.price_without_cafe_order) > int(event.price_per_person)),
            has_discount=int(event.price_per_person or 0) > 0,
        ),
    )
    await c.answer()


@router.callback_query(F.data == "booking:edit:summary")
async def booking_edit_return_summary(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_edit_field.state:
        return await c.answer("این گزینه دیگر فعال نیست.", show_alert=True)
    await c.answer()
    await show_booking_summary(c.message, state)


@router.callback_query(F.data == "booking:edit:names")
async def booking_edit_names(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_edit_field.state:
        return await c.answer("این گزینه دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    participants = list(data.get("participants") or [])
    if not participants:
        return await c.answer("شرکت‌کننده‌ای برای ویرایش پیدا نشد.", show_alert=True)
    await state.set_state(BookingStates.selecting_edit_participant)
    await c.message.edit_text("نام کدام شرکت‌کننده را می‌خواهید تغییر دهید؟", reply_markup=booking_edit_participants_keyboard(participants))
    await c.answer()


@router.callback_query(F.data.regexp(r"^booking:edit:name:\d+$"))
async def booking_edit_name_select(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_edit_participant.state:
        return await c.answer("این گزینه دیگر فعال نیست.", show_alert=True)
    try:
        index = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شرکت‌کننده نامعتبر است.", show_alert=True)
    data = await state.get_data()
    participants = list(data.get("participants") or [])
    if not 0 <= index < len(participants):
        return await c.answer("اطلاعات شرکت‌کننده تغییر کرده است؛ دوباره انتخاب کنید.", show_alert=True)
    await state.update_data(edit_participant_index=index)
    await state.set_state(BookingStates.editing_participant_name)
    current = " ".join((participants[index].get("first_name", ""), participants[index].get("last_name", ""))).strip()
    await c.message.edit_text(f"نام و نام خانوادگی جدید را وارد کنید.\nنام فعلی: {escape(current)}")
    await c.answer()


@router.message(BookingStates.editing_participant_name, F.text)
async def booking_edit_name_receive(message: Message, state: FSMContext):
    parsed = parse_full_name(message.text or "")
    if parsed is None:
        return await _render_booking_prompt(message, state, "لطفاً نام و نام خانوادگی معتبر را یکجا وارد کنید.")
    data = await state.get_data()
    participants = list(data.get("participants") or [])
    index = int(data.get("edit_participant_index", -1))
    if not 0 <= index < len(participants):
        await state.set_state(BookingStates.confirm)
        return await show_booking_summary(message, state)
    participants[index] = {**participants[index], "first_name": parsed[0], "last_name": parsed[1]}
    await state.update_data(participants=participants, edit_participant_index=None)
    await show_booking_summary(message, state)


@router.callback_query(F.data == "booking:edit:phone")
async def booking_edit_phone(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_edit_field.state:
        return await c.answer("این گزینه دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    await state.set_state(BookingStates.editing_booker_phone)
    await c.message.edit_text(
        "شمارهٔ تماس جدید را وارد کنید.\nبرای حفظ شمارهٔ فعلی، «-» بفرستید."
    )
    await c.answer()


@router.message(BookingStates.editing_booker_phone, F.text)
async def booking_edit_phone_receive(message: Message, state: FSMContext):
    raw = (message.text or "").strip()
    data = await state.get_data()
    if raw == "-":
        await show_booking_summary(message, state)
        return
    normalized = normalize_iranian_mobile(raw)
    if normalized is None:
        return await _render_booking_prompt(message, state, "شماره نامعتبر است؛ شمارهٔ معتبر وارد کنید یا برای حفظ شمارهٔ فعلی «-» بفرستید.")
    await state.update_data(booker_phone=normalized)
    await show_booking_summary(message, state)


@router.callback_query(F.data == "booking:edit:price")
async def booking_edit_price(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_edit_field.state:
        return await c.answer("این گزینه دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    async with SessionLocal() as session:
        event = await session.get(Event, int(data.get("event_id") or 0))
    if event is None or not event.price_without_cafe_order or int(event.price_without_cafe_order) <= int(event.price_per_person):
        return await c.answer("برای این پنل گزینهٔ جایگزین قیمت وجود ندارد.", show_alert=True)
    await state.update_data(pricing_return_to_summary=True)
    await state.set_state(BookingStates.selecting_pricing)
    await c.message.edit_text("روش ثبت‌نام را انتخاب کنید:", reply_markup=booking_pricing_keyboard(int(event.price_per_person), int(event.price_without_cafe_order)))
    await c.answer()


@router.callback_query(F.data == "booking:edit:discount")
async def booking_edit_discount(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != BookingStates.selecting_edit_field.state:
        return await c.answer("این گزینه دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    updates = {
        "discount_code_id": None, "personal_reward_id": None, "discount_redemption_id": None,
        "discount_amount": 0, "discount_prompt_skipped": False, "skip_personal_reward_once": True,
    }
    if data.get("discount_redemption_id"):
        updates["continue_full_price_redemption_id"] = int(data["discount_redemption_id"])
    await state.update_data(**updates)
    await c.answer()
    await show_booking_summary(c.message, state)


@router.callback_query(F.data.startswith("event:register_again:"))
async def register_again(c: CallbackQuery, state: FSMContext):
    try:
        event_id = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    await begin_register_from_message(c.message, state, event_id, allow_duplicate=True, telegram_user=c.from_user)
    await c.answer()


@router.message(BookingStates.confirm)
async def confirm_booking_text(message: Message, state: FSMContext):
    await message.answer("برای ثبت نهایی یا لغو، از دکمه‌های زیر استفاده کنید.", reply_markup=booking_confirmation_keyboard())


async def _save_receipt(
    message: Message,
    state: FSMContext,
    file_id: str | None = None,
    extension: str | None = None,
    file_size: int | None = None,
    original_name: str | None = None,
    receipt_text: str | None = None,
):
    if file_id and not within_upload_limit(file_size):
        return await message.answer(f"حجم فایل نباید بیشتر از {settings.max_upload_mb} مگابایت باشد.")
    if await state.get_state() != BookingStates.waiting_receipt.state:
        return await message.answer("فرایند دریافت رسید فعال نیست. از بخش ثبت‌نام‌های من دوباره اقدام کنید.", reply_markup=main_menu())
    data = await state.get_data()
    try:
        booking_id = int(data.get("booking_id") or 0)
    except (TypeError, ValueError):
        booking_id = 0
    if booking_id <= 0:
        await state.clear()
        return await message.answer("اطلاعات رزرو پیدا نشد؛ لطفاً از بخش ثبت‌نام‌های من دوباره تلاش کنید.")

    expired_event_id = None
    async with SessionLocal() as session:
        booking = await session.get(Booking, int(booking_id), with_for_update=True)
        owner = (await session.execute(select(User).where(User.telegram_id == message.from_user.id))).scalar_one_or_none()
        if not booking or not owner or booking.booked_by_user_id != owner.id:
            return await message.answer("رزرو پیدا نشد.")
        if booking.status not in (RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.REJECTED):
            return await message.answer("این رزرو در وضعیت دریافت رسید نیست.")

        # The periodic expiry task is best-effort. Enforce the reservation deadline
        # at the point of receipt submission as well, under the booking row lock.
        if expire_booking_if_due(booking, now=utc_now_naive()):
            expired_event_id = int(booking.event_id)
            await session.commit()
        else:
            # Match the booking -> event lock order used by payment review. A panel
            # that was cancelled/completed/archived must not accept a new receipt.
            event = (await session.execute(
                select(Event).where(Event.id == booking.event_id).with_for_update()
                .execution_options(populate_existing=True)
            )).scalar_one_or_none()
            if event is None:
                return await message.answer("پنل مرتبط با این رزرو پیدا نشد.")
            if event.status != EventStatus.PUBLISHED or event.archived:
                await state.clear()
                await message.answer("این پنل لغو شده، برگزار شده یا آرشیو شده است؛ دریافت رسید جدید ممکن نیست.", reply_markup=hide_reply_keyboard())
                return await message.answer(main_menu_welcome_text(), reply_markup=main_menu())

            stored_path = None
            if file_id:
                filename = f"booking_{booking_id}_{os.urandom(6).hex()}{extension or '.bin'}"
                try:
                    stored_path = await download_file(message.bot, file_id, filename, file_size=file_size)
                except Exception:
                    return await message.answer("دریافت فایل ناموفق بود. دوباره تلاش کنید.")
                if Path(stored_path).stat().st_size > settings.max_upload_mb * 1024 * 1024:
                    Path(stored_path).unlink(missing_ok=True)
                    return await message.answer(f"حجم فایل نباید بیشتر از {settings.max_upload_mb} مگابایت باشد.")
                if not file_content_matches(stored_path, extension or ""):
                    Path(stored_path).unlink(missing_ok=True)
                    return await message.answer("محتوای فایل با فرمت اعلام‌شده مطابقت ندارد؛ لطفاً یک رسید معتبر ارسال کنید.")

            payment = (await session.execute(select(Payment).where(Payment.booking_id == booking.id))).scalar_one_or_none()
            if payment is None:
                payment = Payment(booking_id=booking.id, amount=booking.total_amount)
                session.add(payment)
            payment.amount = booking.total_amount
            payment.receipt_file = stored_path
            payment.receipt_file_name = original_name or (Path(stored_path).name if stored_path else None)
            payment.receipt_text = receipt_text.strip() if receipt_text else None
            payment.receipt_uploaded_at = utc_now_naive()
            payment.status = "pending"
            payment.reviewed_at = None
            payment.reviewed_by = None
            booking.status = RegistrationStatus.PENDING_VERIFICATION
            booking.expires_at = None
            await session.commit()

    if expired_event_id is not None:
        await state.clear()
        try:
            await reconcile_event_channel_status(message.bot, expired_event_id)
        except Exception:
            logger.exception("Failed to reconcile channel status after late receipt for event_id=%s", expired_event_id)
        await message.answer(
            "مهلت پرداخت این رزرو به پایان رسیده و رزرو منقضی شده است. برای ثبت‌نام دوباره، پنل‌های پیش‌رو را بررسی کنید.",
            reply_markup=hide_reply_keyboard(),
        )
        return await message.answer(main_menu_welcome_text(), reply_markup=main_menu())

    await state.clear()
    await message.answer(
        "✅ رسید شما دریافت شد.\n\n"
        "پس از بررسی، نتیجه را به شما اطلاع می‌دهیم. تا آن زمان نیازی به ارسال مجدد رسید نیست.",
        reply_markup=hide_reply_keyboard(),
    )
    await message.answer(main_menu_welcome_text(), reply_markup=main_menu())


@router.message(BookingStates.waiting_receipt, F.photo)
async def receipt_photo(message: Message, state: FSMContext):
    await _save_receipt(message, state, message.photo[-1].file_id, ".jpg", message.photo[-1].file_size)


@router.message(BookingStates.waiting_receipt, F.document)
async def receipt_document(message: Message, state: FSMContext):
    document = message.document
    ext = receipt_extension(document)
    if ext is None:
        return await message.answer("فقط رسیدهای PDF، JPG/JPEG یا PNG پذیرفته می‌شوند و نام/نوع فایل باید معتبر باشد.")
    await _save_receipt(message, state, document.file_id, ext, document.file_size, document.file_name)


@router.message(BookingStates.waiting_receipt, F.text == "❌ لغو ارسال رسید")
async def cancel_receipt_reply_button(message: Message, state: FSMContext):
    """Start the same explicit two-step cancellation from the native reply keyboard."""
    data = await state.get_data()
    try:
        booking_id = int(data.get("booking_id") or 0)
    except (TypeError, ValueError):
        return await message.answer("اطلاعات رزرو معتبر نیست. برای ادامه از «ثبت‌نام‌های من» اقدام کنید.")
    if booking_id <= 0:
        return await message.answer("رزروی برای لغو پیدا نشد.")
    if data.get("receipt_cancel_confirmation_for") == booking_id and data.get("receipt_cancel_confirmation_token"):
        return await message.answer("تأیید لغو در پیام قبلی نمایش داده شده است.")
    await _show_receipt_cancel_confirmation(message, state, booking_id)


@router.message(BookingStates.waiting_receipt, F.text)
async def receipt_text_message(message: Message, state: FSMContext):
    text = (message.text or "").strip()
    if text.startswith("/"):
        return await message.answer(
            "لطفاً رسید را به‌صورت عکس، فایل یا متن ارسال کنید. برای لغو همین رزرو، /cancel را بزنید."
        )
    if not text:
        return await message.answer("لطفاً متن رسید را ارسال کنید.")
    if len(text) > 4000:
        return await message.answer("متن رسید خیلی طولانی است. لطفاً حداکثر ۴۰۰۰ کاراکتر ارسال کنید.")
    await _save_receipt(message, state, receipt_text=text)


@router.message(BookingStates.waiting_receipt)
async def receipt_wrong_content_type(message: Message):
    await message.answer("برای رسید، عکس، فایل PDF یا متن رسید ارسال کنید. سایر انواع پیام پذیرفته نمی‌شوند.")


@router.callback_query(F.data.startswith("user:payment:upload:"))
async def continue_receipt_upload(c: CallbackQuery, state: FSMContext):
    try:
        booking_id = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("رزرو نامعتبر است.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        booking = await session.get(Booking, booking_id)
        if not booking or booking.booked_by_user_id != user.id:
            return await c.answer("رزرو پیدا نشد.", show_alert=True)
        if booking.status != RegistrationStatus.PENDING_PAYMENT:
            return await c.answer("این رزرو در وضعیت دریافت رسید نیست.", show_alert=True)
        amount = int(booking.total_amount)
        event = await session.get(Event, booking.event_id)
        event_label = f"{volume_label(event.volume)} — {event.title}" if event else f"پنل رزرو #{booking.id}"
    payment_card_number, payment_account_name = await _payment_details()
    if amount > 0 and not (payment_card_number and payment_account_name):
        await _notify_payment_configuration_missing(c.bot, event_label, amount)
        await c.message.answer(_payment_setup_user_message(), disable_web_page_preview=True)
        return await c.answer("پرداخت موقتاً در دسترس نیست.", show_alert=True)
    current_state = await state.get_state()
    current_data = await state.get_data()
    if current_state and current_state != BookingStates.waiting_receipt.state:
        return await c.answer("یک فرایند دیگر در حال انجام است؛ ابتدا آن را تکمیل یا لغو کنید.", show_alert=True)
    if current_state == BookingStates.waiting_receipt.state:
        try:
            active_booking_id = int(current_data.get("booking_id") or 0)
        except (TypeError, ValueError):
            return await c.answer("اطلاعات فرایند ارسال رسید معتبر نیست. آن را با /cancel لغو و دوباره شروع کنید.", show_alert=True)
        if active_booking_id != booking_id:
            return await c.answer(
                f"ارسال رسید برای رزرو #{active_booking_id} هنوز فعال است. ابتدا همان فرایند را تکمیل یا لغو کنید.",
                show_alert=True,
            )
    else:
        await state.update_data(booking_id=booking_id)
        await state.set_state(BookingStates.waiting_receipt)
    await c.message.answer(
        f"ارسال رسید برای رزرو #{booking_id}.\n\n"
        f"💳 مبلغ قابل پرداخت: <b>{amount:,} تومان</b>\n\n"
        f"شماره کارت: {payment_card_number}\n"
        f"به نام: {payment_account_name}\n\n"
        "📄 رسید را به‌صورت عکس، PDF یا متن ارسال کنید.",
        reply_markup=receipt_upload_keyboard(payment_card_number, int(booking_id)),
    )
    await c.answer()


@router.callback_query(F.data.startswith("user:payment:retry:"))
async def retry_receipt(c: CallbackQuery, state: FSMContext):
    try:
        booking_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("رزرو نامعتبر است.", show_alert=True)
    current_state = await state.get_state()
    current_data = await state.get_data()
    if current_state and current_state != BookingStates.waiting_receipt.state:
        return await c.answer("یک فرایند دیگر در حال انجام است؛ ابتدا آن را تکمیل یا لغو کنید.", show_alert=True)
    if current_state == BookingStates.waiting_receipt.state:
        try:
            active_booking_id = int(current_data.get("booking_id") or 0)
        except (TypeError, ValueError):
            return await c.answer("اطلاعات فرایند ارسال رسید معتبر نیست. آن را با /cancel لغو و دوباره شروع کنید.", show_alert=True)
        if active_booking_id != booking_id:
            return await c.answer(
                f"ارسال رسید برای رزرو #{active_booking_id} هنوز فعال است. ابتدا همان فرایند را تکمیل یا لغو کنید.",
                show_alert=True,
            )
    user = await get_or_create_user(c.from_user)
    payment_card_number, payment_account_name = await _payment_details()
    blocked_amount = 0
    event_label = ""
    booking = None
    async with SessionLocal() as session:
        existing_booking = await session.get(Booking, booking_id)
        if (
            existing_booking and existing_booking.booked_by_user_id == user.id
            and int(existing_booking.total_amount or 0) > 0 and not (payment_card_number and payment_account_name)
        ):
            event = await session.get(Event, existing_booking.event_id)
            event_label = f"{volume_label(event.volume)} — {event.title}" if event else f"پنل رزرو #{booking_id}"
            blocked_amount = int(existing_booking.total_amount or 0)
        else:
            try:
                booking = await retry_payment(session, user.id, booking_id)
            except ValueError as exc:
                msg = {
                    "NOT_FOUND": "رزرو پیدا نشد.",
                    "NOT_RETRYABLE": "این رزرو قابل ارسال مجدد نیست.",
                    "EVENT_NOT_OPEN": "ثبت‌نام این پنل دیگر باز نیست.",
                    "FULL": "ظرفیت پنل در حال حاضر تکمیل شده است.",
                    "MAX_PARTICIPANTS_PER_BOOKING": f"این رزرو بیشتر از {MAX_PARTICIPANTS_PER_BOOKING} نفر دارد و قابل ارسال مجدد نیست.",
                    "USER_SEAT_LIMIT": f"سقف رزرو فعال شما برای این پنل {MAX_ACTIVE_SEATS_PER_USER_PER_PANEL} نفر است.",
                }.get(str(exc), "ارسال مجدد رسید ممکن نیست.")
                return await c.answer(msg, show_alert=True)
    if blocked_amount:
        await _notify_payment_configuration_missing(c.bot, event_label, blocked_amount)
        await c.message.answer(_payment_setup_user_message(), disable_web_page_preview=True)
        return await c.answer("پرداخت موقتاً در دسترس نیست.", show_alert=True)
    if booking is None:
        return await c.answer("ارسال مجدد رسید ممکن نیست.", show_alert=True)
    await reconcile_event_channel_status(c.bot, booking.event_id)
    if await state.get_state() != BookingStates.waiting_receipt.state:
        await state.update_data(booking_id=booking.id)
        await state.set_state(BookingStates.waiting_receipt)
    await c.message.answer(
        f"ارسال مجدد رسید برای رزرو #{booking.id}.\n\n"
        f"💳 مبلغ قابل پرداخت: <b>{int(booking.total_amount):,} تومان</b>\n\n"
        f"شماره کارت: {payment_card_number}\n"
        f"به نام: {payment_account_name}\n\n"
        "📄 رسید را می‌توانید به‌صورت عکس/فایل یا متن ارسال کنید.",
        reply_markup=receipt_upload_keyboard(payment_card_number, int(booking.id)),
    )
    await c.answer()


async def _render_menu_target(target: Message | CallbackQuery, text: str, *, reply_markup=None, **kwargs):
    """Share one screen renderer between inline callbacks and persistent reply buttons."""
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=reply_markup, **kwargs)
        await target.answer()
    else:
        await target.answer(text, reply_markup=reply_markup, **kwargs)


MY_BOOKINGS_PAGE_SIZE = 4


async def render_my_bookings(target: Message | CallbackQuery, page: int = 0):
    """Render a bounded page of the user's current signups and unresolved follow-ups."""
    user = await get_or_create_user(target.from_user)
    async with SessionLocal() as session:
        expired_event_ids = await expire_old_bookings(session, user_id=user.id)
        if expired_event_ids:
            await session.commit()
        current_statuses = (
            RegistrationStatus.PENDING_PAYMENT,
            RegistrationStatus.PENDING_VERIFICATION,
            RegistrationStatus.CONFIRMED,
            RegistrationStatus.REJECTED,
        )
        filters = (
            Booking.booked_by_user_id == user.id,
            or_(
                and_(
                    Event.archived.is_(False),
                    Booking.status.in_(current_statuses),
                    Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED)),
                ),
                # Financial reconciliation remains reachable even if a cancelled
                # panel is later archived; archive status never resolves money.
                and_(
                    Booking.cancellation_resolution == "action_required",
                    Event.status == EventStatus.CANCELLED,
                ),
            ),
        )
        total = int(await session.scalar(
            select(func.count()).select_from(
                select(Booking.id).join(Event, Booking.event_id == Event.id).where(*filters).subquery()
            )
        ) or 0)
        page_count = max(1, (total + MY_BOOKINGS_PAGE_SIZE - 1) // MY_BOOKINGS_PAGE_SIZE)
        page = min(max(0, int(page)), page_count - 1)
        bookings = (await session.execute(
            select(Booking).join(Event, Booking.event_id == Event.id)
            .options(selectinload(Booking.event), selectinload(Booking.payment), selectinload(Booking.participants))
            .where(*filters)
            .order_by(Booking.created_at.desc(), Booking.id.desc())
            .offset(page * MY_BOOKINGS_PAGE_SIZE).limit(MY_BOOKINGS_PAGE_SIZE)
        )).scalars().all()

    for expired_event_id in expired_event_ids:
        try:
            await reconcile_event_channel_status(target.bot, expired_event_id)
        except Exception:
            logging.getLogger(__name__).exception("Failed to reconcile capacity after expiring booking for event_id=%s", expired_event_id)

    if not bookings:
        return await _render_menu_target(
            target,
            "در حال حاضر ثبت‌نامی برای نمایش ندارید. برای مشاهدهٔ پنل‌های قابل ثبت‌نام، بخش «پنل‌های پیش‌رو» را باز کنید.",
            reply_markup=main_menu(),
        )

    rows = []
    chunks = [f"<b>ثبت‌نام‌های من</b> · {_fa_digits(total)} مورد · صفحهٔ {_fa_digits(page + 1)}/{_fa_digits(page_count)}"]
    for booking in bookings:
        event = booking.event
        start = str(event.start_time_label or "—")
        end = str(event.end_time_label or "—")
        time_label = start if not has_end_time_label(end) else f"{start}–{end}"
        if event.status == EventStatus.CANCELLED:
            if getattr(booking, "cancellation_resolution", "not_required") == "action_required":
                next_step = "پنل لغو شده است؛ پروندهٔ پرداخت برای پیگیری باز است و به معنی انجام بازپرداخت نیست. برای پیگیری با پشتیبانی تماس بگیرید."
            elif getattr(booking, "cancellation_resolution", "not_required") not in ("not_required", "action_required"):
                next_step = "پنل لغو شده است. نتیجهٔ پیگیری مالی ثبت شده است."
            else:
                next_step = "پنل لغو شده است؛ این رزرو دیگر فعال نیست."
        elif booking.status == RegistrationStatus.PENDING_PAYMENT:
            next_step = "قدم بعدی: رسید پرداخت را ارسال کنید."
        elif booking.status == RegistrationStatus.PENDING_VERIFICATION:
            next_step = "رسید دریافت شده و در انتظار بررسی مدیر است؛ نیازی به ارسال دوباره نیست."
        elif booking.status == RegistrationStatus.REJECTED:
            next_step = "رسید اصلاح‌شده را دوباره ارسال کنید یا رزرو را لغو کنید."
        elif booking.status == RegistrationStatus.CANCELLED:
            next_step = "این رزرو لغو شده و دیگر فعال نیست."
        else:
            next_step = "ثبت‌نام شما نهایی شده است."
        event_label = _ltr_display(f"{volume_label(event.volume)} – {str(event.title)[:80]}")
        chunks.append(
            f"<b>رزرو #{int(booking.id)}</b>\n"
            f"{event_label}\n"
            + panel_detail_line("روز و تاریخ", f"{escape(str(event.event_day_label or '—')[:35])} · {escape(str(event.event_date_label or '—')[:55])}", icon="📅") + "\n"
            + panel_detail_line("ساعت", escape(time_label[:15]), icon="⏰") + "\n"
            + panel_detail_line("مکان", escape(str(event.venue or '—')[:80]), icon="📍") + "\n"
            + panel_detail_line("تعداد نفرات", int(booking.participant_count), icon="👥") + "\n"
            + panel_detail_line("مبلغ", f"{int(booking.total_amount):,} تومان", icon="💰") + "\n"
            + (f"شیوهٔ ثبت‌نام: {escape(booking_option_detail_label(booking.pricing_option, base_price=booking.base_price_snapshot, alternative_price=booking.alternative_price_snapshot))}\n" if booking.pricing_option is not None else "")
            + f"وضعیت: <b>{booking_status_label(booking.status)}</b>\n{next_step}"
        )
        actions = []
        if (event.status == EventStatus.CANCELLED
                and getattr(booking, "cancellation_resolution", "not_required") == "action_required"
                and settings.support_url):
            actions.append(InlineKeyboardButton(text=f"🧑‍💻 پیگیری مالی #{booking.id}", url=settings.support_url))
        if booking.status == RegistrationStatus.CONFIRMED and event.status == EventStatus.PUBLISHED and not event.archived:
            # A signed registration pass makes verification at the venue clearer than
            # asking the attendee to scroll through a long My Signups message.
            actions.append(InlineKeyboardButton(text=f"🎫 کارت ثبت‌نام #{booking.id}", callback_data=f"user:booking:pass:{booking.id}"))
        if booking.status == RegistrationStatus.CONFIRMED and event.questions_pdf_path:
            actions.append(InlineKeyboardButton(text=f"📄 سؤالات #{booking.id}", callback_data=f"user:questions:file:{booking.id}"))
        if booking.status == RegistrationStatus.PENDING_PAYMENT:
            actions.append(InlineKeyboardButton(text=f"📤 ارسال رسید #{booking.id}", callback_data=f"user:payment:upload:{booking.id}"))
        elif booking.status == RegistrationStatus.REJECTED:
            actions.append(InlineKeyboardButton(text=f"🔁 ارسال مجدد #{booking.id}", callback_data=f"user:payment:retry:{booking.id}"))
        if user_can_cancel_booking(booking, getattr(booking, "payment", None), event):
            actions.append(InlineKeyboardButton(text=f"❌ لغو رزرو #{booking.id}", callback_data=f"user:booking:cancel:{booking.id}"))
        # Keep all actions reachable when a confirmed free booking has a pass,
        # questions file, and cancellation option at the same time.
        for action_offset in range(0, len(actions), 2):
            rows.append(actions[action_offset:action_offset + 2])

    if page > 0 or page + 1 < page_count:
        navigation = []
        if page > 0:
            navigation.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"user:bookings:page:{page - 1}"))
        navigation.append(InlineKeyboardButton(text=f"صفحهٔ {page + 1}/{page_count}", callback_data=f"user:bookings:page:{page}"))
        if page + 1 < page_count:
            navigation.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"user:bookings:page:{page + 1}"))
        rows.append(navigation)
    rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="user:home")])
    return await _render_menu_target(
        target,
        "\n\n".join(chunks),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data.regexp(r"^user:booking:pass:\d+$"))
async def booking_registration_pass(c: CallbackQuery):
    """Send the current account-holder a QR pass an Admin can verify in the bot."""
    try:
        booking_id = int((c.data or "").rsplit(":", 1)[1])
    except (TypeError, ValueError, IndexError):
        return await c.answer("شناسهٔ رزرو نامعتبر است.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        booking = (await session.execute(
            select(Booking).options(
                selectinload(Booking.event), selectinload(Booking.participants)
            ).where(Booking.id == booking_id, Booking.booked_by_user_id == user.id)
        )).scalar_one_or_none()
        if (not booking or booking.status != RegistrationStatus.CONFIRMED
                or not booking.event or booking.event.status != EventStatus.PUBLISHED
                or booking.event.archived):
            return await c.answer("کارت ثبت‌نام فقط برای رزرو تأییدشدهٔ پنل فعال در دسترس است.", show_alert=True)
        title = f"{volume_label(booking.event.volume)} — {booking.event.title}"
        participant_names = [str(person.full_name or "").strip() for person in booking.participants if str(person.full_name or "").strip()]
    try:
        bot_info = await c.bot.get_me()
        if not bot_info.username:
            raise RuntimeError("BOT_USERNAME_UNAVAILABLE")
        payload = booking_pass_payload(booking_id)
        url = f"https://t.me/{bot_info.username}?start={payload}"
        import qrcode
        image = qrcode.make(url)
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        photo = BufferedInputFile(buffer.getvalue(), filename=f"panel-flow-registration-{booking_id}.png")
    except Exception:
        logger.exception("Could not create registration pass for booking_id=%s", booking_id)
        return await c.answer("ساخت کارت ثبت‌نام موقتاً ممکن نیست؛ دوباره تلاش کنید.", show_alert=True)
    names = ", ".join(participant_names[:3]) or "—"
    caption = (
        "<b>🎫 کارت ثبت‌نام تأییدشده</b>\n\n"
        f"پنل: {escape(title[:180])}\n"
        f"شناسهٔ رزرو: <code>#{booking_id}</code>\n"
        f"شرکت‌کنندگان: {escape(names[:250])}\n\n"
        "برای بررسی، این QR را به مدیر یا میزبان همین پنل نشان دهید تا با حساب خود آن را اسکن کند. "
        "این کارت به‌تنهایی حضور را ثبت نمی‌کند."
    )
    await c.message.answer_photo(photo=photo, caption=caption)
    await c.answer("کارت ثبت‌نام ارسال شد.")


async def show_booking_verification_from_message(
    message: Message, booking_id: int, signature: str, *, telegram_user=None,
) -> None:
    """Admin-only, read-only verification of the live booking state from a signed pass."""
    actor = telegram_user or message.from_user
    if actor is None:
        return await message.answer("حساب برگزارکننده شناسایی نشد.")
    from app.services.authorization import is_admin_telegram_id, is_host_telegram_id
    is_admin = await is_admin_telegram_id(int(actor.id))
    is_host = not is_admin and await is_host_telegram_id(int(actor.id))
    if not is_admin and not is_host:
        return await message.answer("این کارت فقط توسط مدیر یا میزبان همان پنل قابل بررسی است.")
    if not verify_booking_pass_signature(booking_id, signature):
        return await message.answer("کارت ثبت‌نام نامعتبر است؛ از کاربر بخواهید کارت را دوباره از «ثبت‌نام‌های من» بسازد.")
    async with SessionLocal() as session:
        verify_options = [selectinload(Booking.event)]
        if is_admin:
            # Only authorized Admin verification loads the participant names;
            # the scoped Host check needs only the booking and its event.
            verify_options.append(selectinload(Booking.participants))
        booking = (await session.execute(
            select(Booking).options(*verify_options).where(Booking.id == int(booking_id))
        )).scalar_one_or_none()
        if not booking or not booking.event:
            if is_host:
                return await message.answer("این کارت برای پنل‌های تحت میزبانی شما قابل تأیید نیست.")
            return await message.answer("رزرو در سامانه پیدا نشد؛ این کارت را معتبر در نظر نگیرید.")
        event = booking.event
        status = booking.status
        event_label = f"{volume_label(event.volume)} — {event.title}"
        archived = bool(event.archived)
        # Hosts get a narrow verification capability for their own panel only.
        # They do not receive the participant roster, names, contact data, or a
        # way to enumerate attendee identities. Admins retain the full verifier.
        if is_host:
            host_user_id = await session.scalar(select(User.id).where(
                User.telegram_id == int(actor.id), User.role == UserRole.HOST
            ).limit(1))
            if not host_user_id or int(event.host_id or 0) != int(host_user_id):
                return await message.answer("این کارت برای پنل‌های تحت میزبانی شما قابل بررسی نیست.")
        if status != RegistrationStatus.CONFIRMED:
            if is_host:
                return await message.answer("❌ این رزرو در حال حاضر تأییدشده نیست؛ برای پذیرش آن اقدام نکنید.")
            return await message.answer(
                "❌ <b>رزرو تأییدشده نیست</b>\n\n"
                f"پنل: {escape(event_label)}\nشناسهٔ رزرو: <code>#{booking_id}</code>\n"
                f"وضعیت فعلی: {escape(booking_status_label(status))}\n"
                "برای ورود به این پنل، ثبت‌نام تأییدشده پیدا نشد."
            )
        if event.status != EventStatus.PUBLISHED or archived:
            if is_host:
                return await message.answer("⚠️ این رزرو تأیید شده است، اما پنل شما برای ورود فعال نیست.")
            return await message.answer(
                "⚠️ <b>این رزرو سابقهٔ تأیید دارد، اما پنل دیگر برای ورود فعال نیست.</b>\n\n"
                f"پنل: {escape(event_label)}\nشناسهٔ رزرو: <code>#{booking_id}</code>\n"
                "قبل از پذیرش، وضعیت پنل را بررسی کنید."
            )
        participant_count = int(booking.participant_count)
        if not is_host:
            names = [str(person.full_name or "").strip() for person in booking.participants if str(person.full_name or "").strip()]
    if is_host:
        # Re-check immediately before responding so an account restriction or role
        # revocation during the lookup does not leave a stale permission in effect.
        if not await is_host_telegram_id(int(actor.id)):
            return await message.answer("دسترسی میزبان تغییر کرده است؛ این کارت قابل بررسی نیست.")
        await message.answer(
            "✅ <b>رزرو معتبر برای پنل شماست</b>\n\n"
            f"پنل: {escape(event_label)}\nشناسهٔ رزرو: <code>#{booking_id}</code>\n"
            f"تعداد نفرات این رزرو: {participant_count}\n"
            "اطلاعات هویتی شرکت‌کنندگان در این بررسی نمایش داده نمی‌شود. این بررسی فقط ثبت‌نام را تأیید می‌کند؛ ثبت حضور از دفتر حضور و غیاب انجام می‌شود."
        )
        return
    await message.answer(
        "✅ <b>رزرو معتبر است</b>\n\n"
        f"پنل: {escape(event_label)}\nشناسهٔ رزرو: <code>#{booking_id}</code>\n"
        f"تعداد نفرات: {participant_count}\n"
        f"شرکت‌کنندگان: {escape(', '.join(names[:3]) or '—')}\n"
        "وضعیت: تأییدشده\n"
        "این بررسی فقط ثبت‌نام را تأیید می‌کند؛ ثبت حضور از دفتر حضور و غیاب انجام می‌شود."
    )


@router.callback_query(F.data == "user:bookings")
async def my_bookings(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await render_my_bookings(c, page=0)


@router.callback_query(F.data.regexp(r"^user:bookings:page:\d+$"))
async def my_bookings_page(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    try:
        page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    except (TypeError, ValueError, IndexError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await render_my_bookings(c, page=page)


@router.callback_query(F.data.startswith("user:booking:cancel:confirm:"))
async def booking_cancel_confirm(c: CallbackQuery, state: FSMContext):
    try:
        booking_id = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("رزرو نامعتبر است.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        try:
            # Capture display-only details before committing the state change.
            # No additional database read is needed after cancel_booking commits.
            candidate = await session.get(Booking, booking_id)
            if not candidate or candidate.booked_by_user_id != user.id:
                return await c.answer("رزرو پیدا نشد.", show_alert=True)
            candidate_event = await session.get(Event, candidate.event_id)
            event_label = (
                f"{volume_label(candidate_event.volume)} — {candidate_event.title}" if candidate_event
                else f"پنل مربوط به رزرو #{candidate.id}"
            )
            participant_count = int(candidate.participant_count or 0)
            booking = await cancel_booking(session, user.id, booking_id)
        except ValueError as exc:
            reason = str(exc)
            msg = {"NOT_FOUND": "رزرو پیدا نشد.", "NOT_CANCELLABLE": "این رزرو دیگر در وضعیت قابل لغو نیست."}.get(reason, "لغو رزرو ممکن نیست.")
            if reason == "CONFIRMED_CANCELLATION_FORBIDDEN":
                return await c.answer("این رزرو تأیید شده است و امکان لغو آن از طریق ربات وجود ندارد.", show_alert=True)
            return await c.answer(msg, show_alert=True)
        except Exception:
            logger.exception("Participant reservation cancellation failed")
            return await c.answer("لغو رزرو به دلیل خطای فنی انجام نشد. وضعیت رزرو تغییر داده نشده است؛ کمی بعد دوباره تلاش کنید.", show_alert=True)
    # The database change is already committed. Notify configured admins as a
    # separate best-effort operation so Telegram delivery cannot undo or repeat
    # the cancellation.
    for admin_telegram_id in settings.super_admin_id_set - {int(c.from_user.id)}:
        try:
            await c.bot.send_message(
                admin_telegram_id,
                f"ℹ️ یک رزرو توسط کاربر لغو شد.\nپنل: {escape(event_label)}\n"
                f"شناسه رزرو: #{booking.id} | تعداد نفرات: {participant_count}\n"
                f"شناسه تلگرام کاربر: {c.from_user.id}",
            )
        except Exception:
            logger.exception("Could not notify admin after booking cancellation; booking_id=%s", booking.id)
    active_data = await state.get_data()
    try:
        active_booking_id = int(active_data.get("booking_id") or 0)
    except (TypeError, ValueError):
        active_booking_id = 0
    if active_booking_id == booking.id:
        await state.clear()
    try:
        await reconcile_event_channel_status(c.bot, booking.event_id)
    except Exception:
        logger.exception("Failed to reconcile panel status after booking cancellation for event_id=%s", booking.event_id)
    try:
        await notify_waitlist_capacity_available(c.bot, booking.event_id)
    except Exception:
        logger.exception("Failed to notify waitlist after booking cancellation for event_id=%s", booking.event_id)
    await c.answer("رزرو لغو شد.")
    await c.message.edit_text("رزرو انتخاب‌شده لغو شد و ظرفیت آن آزاد شد.", reply_markup=main_menu())


@router.callback_query(F.data.startswith("user:booking:cancel:"))
async def booking_cancel(c: CallbackQuery):
    # Selecting a reservation is not itself destructive. The confirmation callback
    # carries the same specific booking ID and revalidates ownership/state in service.
    try:
        booking_id = int(c.data.rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("رزرو نامعتبر است.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        booking = (await session.execute(
            select(Booking).options(
                selectinload(Booking.event), selectinload(Booking.payment)
            ).where(
                Booking.id == booking_id, Booking.booked_by_user_id == user.id
            )
        )).scalar_one_or_none()
        if not booking:
            return await c.answer("رزرو پیدا نشد.", show_alert=True)
        if (not user_can_cancel_booking(booking, booking.payment, booking.event)
                or (booking.status == RegistrationStatus.CONFIRMED
                    and (booking.event is None or booking.event.status != EventStatus.PUBLISHED or booking.event.archived))):
            return await c.answer("این رزرو در وضعیت فعلی قابل لغو نیست.", show_alert=True)
        label = f"{volume_label(booking.event.volume)} — {booking.event.title}" if booking.event else f"رزرو #{booking.id}"
        is_confirmed_free = booking.status == RegistrationStatus.CONFIRMED
    cancellation_note = (
        "\nاین رزرو مبلغ قابل پرداختی ندارد؛ با لغو آن صندلی‌ها آزاد می‌شوند. کد تخفیف مصرف‌شده به‌طور خودکار بازگردانده نمی‌شود."
        if is_confirmed_free else ""
    )
    await c.message.edit_text(
        f"آیا مطمئن هستید که فقط رزرو زیر لغو شود؟\n\n<b>{escape(label)}</b>\nشناسه رزرو: #{booking_id}\n\nسایر رزروهای شما تغییری نمی‌کنند.{cancellation_note}",
        reply_markup=booking_cancel_confirm_keyboard(booking_id),
    )
    await c.answer()


async def render_user_questions(target: Message | CallbackQuery):
    user = await get_or_create_user(target.from_user)
    async with SessionLocal() as session:
        result = await session.execute(
            select(Booking).options(selectinload(Booking.event)).where(
                Booking.booked_by_user_id == user.id,
                Booking.status == RegistrationStatus.CONFIRMED,
            ).order_by(Booking.created_at.desc())
        )
        bookings = [
            b for b in result.scalars().all()
            if b.event and b.event.questions_pdf_path and not b.event.archived
            and b.event.status in (EventStatus.PUBLISHED, EventStatus.COMPLETED)
        ]
    if not bookings:
        return await _render_menu_target(
            target, "هنوز فایل سؤالی برای رزروهای تأییدشده شما در دسترس نیست.", reply_markup=back_menu()
        )
    rows = [[InlineKeyboardButton(text=f"📄 {volume_label(b.event.volume)} — {b.event.title[:28]}", callback_data=f"user:questions:file:{b.id}")] for b in bookings]
    rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="user:home")])
    return await _render_menu_target(
        target,
        "فایل سؤالات فقط برای پنل‌هایی که رزرو شما در آن‌ها تأیید شده است در دسترس است:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data == "user:questions")
async def user_questions(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await render_user_questions(c)


@router.callback_query(F.data.startswith("user:questions:file:"))
async def retrieve_questions_pdf(c: CallbackQuery):
    try:
        booking_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("رزرو معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        booking = (
            await session.execute(
                select(Booking).options(selectinload(Booking.event)).where(
                    Booking.id == booking_id,
                    Booking.status == RegistrationStatus.CONFIRMED,
                )
            )
        ).scalar_one_or_none()
        owner = (await session.execute(select(User).where(User.telegram_id == c.from_user.id))).scalar_one_or_none()
        if (
            not booking or not owner or booking.booked_by_user_id != owner.id
            or not booking.event
            or booking.event.archived or booking.event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED)
        ):
            return await c.answer("فایل فقط برای صاحب رزرو تأییدشده در پنل جاری در دسترس است.", show_alert=True)
        configured_path = booking.event.questions_pdf_path
        if not configured_path:
            return await c.answer("برای این پنل فایل سؤالاتی منتشر نشده است.", show_alert=True)
        path = resolve_upload_path(configured_path)
        caption = f"📄 سؤالات {volume_label(booking.event.volume)} — {escape(booking.event.title)}"
    if not path:
        logger.warning("Configured question file is missing on disk for booking_id=%s", booking_id)
        await c.answer("فایل این پنل فعلاً در دسترس نیست؛ موضوع به مدیران گزارش شد.", show_alert=True)
        for admin_id in settings.super_admin_id_set:
            try:
                await c.bot.send_message(
                    int(admin_id),
                    f"⚠️ فایل سؤالات تنظیم‌شده برای رزرو #{booking_id} روی سرور پیدا نشد.",
                )
            except Exception:
                logger.warning("Could not notify admin_id=%s about missing configured question file", admin_id, exc_info=True)
        return
    await c.answer()
    await c.bot.send_document(c.from_user.id, FSInputFile(path), caption=caption)


@router.callback_query(F.data.regexp(r"^user:waitlist:leave:\d+$"))
async def leave_waitlist(c: CallbackQuery):
    try:
        event_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شناسه پنل نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        user = (await session.execute(select(User).where(User.telegram_id == int(c.from_user.id)))).scalar_one_or_none()
        if not user:
            return await c.answer("حساب کاربری پیدا نشد.", show_alert=True)
        entry = (await session.execute(
            select(WaitlistEntry).where(
                WaitlistEntry.event_id == event_id,
                WaitlistEntry.user_id == user.id,
                WaitlistEntry.status.in_(("waiting", "invited", "inviting")),
            ).with_for_update()
        )).scalar_one_or_none()
        if not entry:
            return await c.answer("درخواست فعالی در لیست انتظار این پنل ندارید.", show_alert=True)
        entry.status = "closed"
        entry.invitation_expires_at = None
        entry.next_invite_after = None
        event = await session.get(Event, event_id)
        if event:
            used = await seats_used(session, event_id)
            can_register = registration_is_open(event) and used < event.capacity
            waitlist_available = waitlist_is_available(event, used)
        else:
            can_register = waitlist_available = False
        await session.commit()
    await c.answer("از لیست انتظار خارج شدید.")
    if event and event.status == EventStatus.PUBLISHED and not event.archived:
        await c.message.edit_reply_markup(
            reply_markup=event_buttons(event.id, can_register, waitlist_available, event.map_url, waitlisted=False)
        )
    else:
        await c.message.edit_text("درخواست شما از لیست انتظار حذف شد.", reply_markup=main_menu())
    try:
        await notify_waitlist_capacity_available(c.bot, event_id)
    except Exception:
        logger.exception("Could not notify next eligible waitlist users after a user left; event_id=%s", event_id)


@router.callback_query(F.data.startswith("event:waitlist:"))
async def waitlist_start(c: CallbackQuery, state: FSMContext):
    try:
        event_id = int(c.data.split(":")[2])
    except ValueError:
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event or not event.waitlist_enabled or event.archived or event.status != EventStatus.PUBLISHED:
            return await c.answer("لیست انتظار این پنل در دسترس نیست.", show_alert=True)
        used = await seats_used(session, event.id)
        if not waitlist_is_available(event, used):
            if registration_is_open(event) and used < event.capacity:
                return await c.answer("ظرفیت خالی شده است؛ از دکمهٔ ثبت‌نام استفاده کنید.", show_alert=True)
            return await c.answer("در حال حاضر امکان ثبت درخواست در لیست انتظار وجود ندارد.", show_alert=True)
        duplicate = (await session.execute(select(WaitlistEntry).where(
            WaitlistEntry.event_id == event_id,
            WaitlistEntry.user_id == user.id,
            WaitlistEntry.status.in_(["waiting", "invited", "inviting"]),
        ))).scalar_one_or_none()
        if duplicate:
            return await c.answer("شما قبلاً در لیست انتظار این پنل هستید.", show_alert=True)
    await state.clear()
    await state.update_data(waitlist_event_id=event_id)
    await c.message.answer("چند نفر را در لیست انتظار این پنل می‌خواهید؟\n\nتعداد نفرات را وارد کنید.")
    await state.set_state(WaitlistStates.waiting_count)
    await c.answer()


@router.message(WaitlistStates.waiting_count)
async def waitlist_count(message: Message, state: FSMContext):
    count = parse_integer(message.text or "", minimum=1, maximum=MAX_PARTICIPANTS_PER_BOOKING)
    if count is None:
        return await message.answer(f"لطفاً تعداد صحیحی بین ۱ تا {MAX_PARTICIPANTS_PER_BOOKING} نفر وارد کنید.")
    data = await state.get_data()
    user = await get_or_create_user(message.from_user)
    async with SessionLocal() as session:
        event = await session.get(Event, int(data["waitlist_event_id"]), with_for_update=True)
        if not event or event.archived or event.status != EventStatus.PUBLISHED or not event.waitlist_enabled:
            await state.clear()
            return await message.answer("لیست انتظار این پنل دیگر در دسترس نیست. پنل‌ها را دوباره بررسی کنید.", reply_markup=main_menu())
        used = await seats_used(session, event.id)
        if not waitlist_is_available(event, used):
            await state.clear()
            if registration_is_open(event) and used < event.capacity:
                return await message.answer("ظرفیت خالی شده است؛ برای ثبت‌نام از بخش «پنل‌های پیش‌رو» اقدام کنید.", reply_markup=main_menu())
            return await message.answer("در حال حاضر امکان ثبت درخواست در لیست انتظار وجود ندارد.", reply_markup=main_menu())
        if count > event.capacity:
            return await message.answer(f"تعداد درخواستی از ظرفیت کل پنل ({event.capacity}) بیشتر است؛ عدد دیگری وارد کنید.")
        duplicate = (await session.execute(select(WaitlistEntry).where(
            WaitlistEntry.event_id == event.id,
            WaitlistEntry.user_id == user.id,
            WaitlistEntry.status.in_(["waiting", "invited", "inviting"]),
        ))).scalar_one_or_none()
        if duplicate:
            await state.clear()
            return await message.answer("شما قبلاً در صف هستید.", reply_markup=main_menu())
        active_queue_count = int((await session.execute(select(func.count(WaitlistEntry.id)).where(
            WaitlistEntry.event_id == event.id,
            WaitlistEntry.status.in_(["waiting", "invited", "inviting"]),
        ))).scalar_one() or 0)
        max_position = int((await session.execute(select(func.coalesce(func.max(WaitlistEntry.position), 0)).where(
            WaitlistEntry.event_id == event.id,
            WaitlistEntry.status.in_(["waiting", "invited", "inviting"]),
        ))).scalar_one())
        # Keep the stored position increasing for FIFO ordering, but show the user
        # their current rank among active entries (positions can contain gaps).
        queue_position = max_position + 1
        queue_rank = active_queue_count + 1
        session.add(WaitlistEntry(
            event_id=event.id,
            user_id=user.id,
            requested_participant_count=count,
            position=queue_position,
        ))
        try:
            await session.commit()
        except IntegrityError:
            await session.rollback()
            await state.clear()
            return await message.answer("شما قبلاً در لیست انتظار این پنل هستید.", reply_markup=main_menu())
    await state.clear()
    await message.answer(
        f"✅ درخواست شما برای لیست انتظار ثبت شد.\n\nجایگاه فعلی شما: <b>{_fa_digits(queue_rank)}</b>.\n"
        "اگر ظرفیت خالی شود، برای ادامهٔ ثبت‌نام به شما اطلاع می‌دهیم. عضویت در لیست انتظار به معنی رزرو قطعی نیست.",
        reply_markup=main_menu(),
    )


def booking_status_label(status: RegistrationStatus) -> str:
    labels = {
        RegistrationStatus.INITIATED: "در حال تکمیل",
        RegistrationStatus.WAITLISTED: "در صف انتظار",
        RegistrationStatus.PENDING_PAYMENT: "در انتظار پرداخت",
        RegistrationStatus.PENDING_VERIFICATION: "در انتظار بررسی رسید",
        RegistrationStatus.CONFIRMED: "تأییدشده",
        RegistrationStatus.REJECTED: "رسید رد شده؛ امکان ارسال مجدد وجود دارد",
        RegistrationStatus.EXPIRED: "مهلت پرداخت به پایان رسیده",
        RegistrationStatus.CANCELLED: "لغوشده",
    }
    return labels.get(status, status_display_label(status))


@router.callback_query(F.data == "user:referral:yes")
async def referral_prompt_yes(c: CallbackQuery, state: FSMContext):
    if await state.get_state() != ProfileStates.waiting_referral_choice.state:
        return await c.answer("این مرحله دیگر فعال نیست.", show_alert=True)
    await state.set_state(ProfileStates.waiting_referral_code)
    await c.message.edit_text(
        "🤝 <b>کد معرفی</b>\n\nکد معرف دوستی را که شما را به Panel Flow معرفی کرده وارد کنید. "
        "اگر کدی ندارید، می‌توانید بدون کد ادامه دهید.",
        reply_markup=referral_code_input_keyboard(),
    )
    await c.answer()


async def _finish_referral_callback(c: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    payload = str(data.get("pending_start_payload") or "")
    allow_duplicate = bool(data.get("pending_allow_duplicate"))
    try:
        async with SessionLocal() as session:
            await skip_referral_prompt(session, int(c.from_user.id))
            await session.commit()
    except Exception:
        logger.exception("Could not mark referral onboarding complete for telegram_id=%s", c.from_user.id)
        return await c.answer("ذخیره‌سازی انجام نشد؛ لطفاً دوباره تلاش کنید.", show_alert=True)
    await state.clear()
    if payload:
        handled = await dispatch_start_payload(
            c.message, state, payload, allow_duplicate=allow_duplicate,
            telegram_user=c.from_user, replace_message_id=int(c.message.message_id),
        )
        if not handled:
            await c.message.edit_text(main_menu_welcome_text(), reply_markup=main_menu())
    else:
        await c.message.edit_text(main_menu_welcome_text(), reply_markup=main_menu())
    await c.answer("انجام شد.")


@router.callback_query(F.data.in_({"user:referral:no", "user:referral:skip"}))
async def referral_prompt_skip(c: CallbackQuery, state: FSMContext):
    if await state.get_state() not in {
        ProfileStates.waiting_referral_choice.state,
        ProfileStates.waiting_referral_code.state,
    }:
        return await c.answer("این مرحله دیگر فعال نیست.", show_alert=True)
    await _finish_referral_callback(c, state)


async def _prompt_missing_profile_field(target: Message | CallbackQuery, state: FSMContext, user: User | None) -> bool:
    """Continue profile completion at the next missing field, without asking users to restart."""
    if not user or not user.first_name or not user.last_name:
        await state.set_state(ProfileStates.waiting_full_name)
        prompt = onboarding_full_name_prompt()
    elif not user.phone_number:
        await state.set_state(ProfileStates.waiting_phone)
        prompt = phone_number_prompt()
    else:
        return False

    reply_markup = profile_phone_keyboard() if user and user.first_name and user.last_name and not user.phone_number else None
    if isinstance(target, Message):
        await target.answer(prompt, reply_markup=reply_markup)
    else:
        await target.message.answer(prompt, reply_markup=reply_markup)
        await target.answer()
    return True


@router.message(ProfileStates.waiting_referral_code, F.text, ~F.text.startswith("/"))
async def referral_code_received(message: Message, state: FSMContext):
    try:
        async with SessionLocal() as session:
            await attribute_referral(
                session, invitee_telegram_id=int(message.from_user.id), referral_code=message.text or ""
            )
            await session.commit()
    except ValueError as exc:
        if str(exc) == "INVITEE_NOT_FOUND":
            current_user = await get_or_create_user(message.from_user)
            if await _prompt_missing_profile_field(message, state, current_user):
                return
        messages = {
            "INVALID_CODE": "این کد معتبر نیست یا هنوز قابل استفاده نیست. لطفاً آن را بررسی کنید یا بدون کد ادامه دهید.",
            "SELF_REFERRAL": "نمی‌توانید کد معرفی خودتان را وارد کنید.",
            "UNKNOWN_REFERRER": "این کد معتبر نیست یا هنوز قابل استفاده نیست. لطفاً آن را بررسی کنید یا بدون کد ادامه دهید.",
            "INCOMPLETE_REFERRER": "این کد معتبر نیست یا هنوز قابل استفاده نیست. لطفاً آن را بررسی کنید یا بدون کد ادامه دهید.",
            "ALREADY_COMPLETED": "مرحلهٔ کد معرفی قبلاً تکمیل شده است.",
            "ALREADY_REFERRED": "برای این حساب قبلاً کد معرفی ثبت شده است.",
            "INVITEE_NOT_FOUND": "ثبت کد معرفی انجام نشد. لطفاً دوباره تلاش کنید یا بدون کد ادامه دهید.",
        }
        return await message.answer(
            messages.get(str(exc), "ثبت کد معرفی انجام نشد. دوباره تلاش کنید."),
            reply_markup=referral_code_input_keyboard(),
        )
    except Exception:
        logger.exception("Could not attribute referral for telegram_id=%s", message.from_user.id)
        return await message.answer("ثبت کد معرفی به مشکل خورد. دوباره تلاش کنید یا بدون کد ادامه دهید.", reply_markup=referral_code_input_keyboard())

    state_data = await state.get_data()
    payload = str(state_data.get("pending_start_payload") or "")
    allow_duplicate = bool(state_data.get("pending_allow_duplicate"))
    referral_prompt_message_id = state_data.get("referral_prompt_message_id")
    await state.clear()
    if payload:
        handled = await dispatch_start_payload(
            message, state, payload, allow_duplicate=allow_duplicate,
            telegram_user=message.from_user,
            replace_message_id=(int(referral_prompt_message_id) if referral_prompt_message_id else None),
        )
        if handled:
            return
    completion_text = (
        "✅ کد معرفی ثبت شد.\n\n" + main_menu_welcome_text()
    )
    if referral_prompt_message_id:
        try:
            await message.bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=int(referral_prompt_message_id),
                text=completion_text,
                reply_markup=main_menu(),
                disable_web_page_preview=True,
            )
            return
        except Exception as exc:
            if "message is not modified" in str(exc).lower():
                return
            logger.debug("Could not replace completed referral prompt: %s", exc)
    await message.answer(completion_text, reply_markup=main_menu())


@router.callback_query(F.data == "user:profile:referral")
async def show_my_referral_code(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    user = await get_or_create_user(c.from_user)
    if await _prompt_missing_profile_field(c, state, user):
        return
    async with SessionLocal() as session:
        telegram_id = int(user.telegram_id)
        referral_count = await count_referrals_for_telegram_id(session, telegram_id)
    await c.message.edit_text(
        "🤝 <b>کد معرفی من</b>\n\n"
        f"کد شما: <code>{telegram_id}</code>\n\n"
        "این عدد را برای دوستانتان بفرستید. آن‌ها می‌توانند هنگام اولین ثبت‌نام آن را وارد کنند.\n\n"
        f"👥 تعداد معرفی‌های موفق شما: <b>{referral_count}</b>\n\n"
        "🎁 با معرفی‌های موفق، از طرف Panel Flow پاداشی برای شما در نظر گرفته می‌شود. "
        "نوع و مقدار پاداش ممکن است متفاوت باشد و پس از مشخص‌شدن، به شما اطلاع داده می‌شود.",
        reply_markup=referral_code_display_keyboard(telegram_id),
    )
    await c.answer()


def profile_text(user: User) -> str:
    full_name = f"{user.first_name or ''} {user.last_name or ''}".strip() or "—"
    return (
        f"<b>پروفایل من</b>\n\nنام و نام خانوادگی: {escape(full_name)}\n"
        f"شماره موبایل: {escape(user.phone_number or '—')}\n\n"
        "شمارهٔ موبایل برای هماهنگی ثبت‌نام و پرداخت استفاده می‌شود و در فهرست عمومی شرکت‌کنندگان نمایش داده نمی‌شود.\n\n"
        "برای اصلاح اشتباه تایپی یا به‌روزرسانی اطلاعات، گزینهٔ موردنظر را انتخاب کنید."
    )


async def show_profile(c: CallbackQuery, user: User | None = None):
    if user is None:
        user = await get_or_create_user(c.from_user)
    await c.message.edit_text(profile_text(user), reply_markup=profile_keyboard())


@router.callback_query(F.data == "user:profile")
async def profile(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await show_profile(c)
    await c.answer()


@router.callback_query(F.data == "user:profile:edit_name")
async def begin_profile_name_edit(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    user = await get_or_create_user(c.from_user)
    current_name = f"{user.first_name or ''} {user.last_name or ''}".strip() or "—"
    await state.set_state(ProfileEditStates.waiting_full_name)
    await c.message.edit_text(
        f"نام فعلی: {escape(current_name)}\n\n"
        "نام و نام خانوادگی جدید را در یک پیام وارد کنید.\n"
        "مثال: سینا ضیائی",
        reply_markup=profile_edit_cancel_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data == "user:profile:edit_phone")
async def begin_profile_phone_edit(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    user = await get_or_create_user(c.from_user)
    await state.set_state(ProfileEditStates.waiting_phone)
    await c.message.edit_text(
        f"شماره موبایل فعلی: {escape(user.phone_number or '—')}\n\n"
        "شماره موبایل جدید را وارد کنید (مثلاً 09151118888).",
        reply_markup=profile_edit_cancel_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data == "user:profile:cancel")
async def cancel_profile_edit(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await show_profile(c)
    await c.answer("تغییر لغو شد.")


@router.message(ProfileEditStates.waiting_full_name)
async def save_profile_full_name(message: Message, state: FSMContext):
    async with SessionLocal() as session:
        user = (await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )).scalar_one_or_none()
        if user is None:
            await state.clear()
            await message.answer("حساب کاربری پیدا نشد. لطفاً /start را بزنید.", reply_markup=main_menu())
            return
        if not apply_profile_name(user, message.text or ""):
            await message.answer(
                "نام معتبر نیست. لطفاً نام و نام خانوادگی را با هم وارد کنید.\n"
                "مثال: سینا ضیائی",
                reply_markup=profile_edit_cancel_keyboard(),
            )
            return
        await session.commit()
        updated_profile = profile_text(user)

    await state.clear()
    await message.answer(updated_profile, reply_markup=profile_keyboard())


@router.message(ProfileEditStates.waiting_phone)
async def save_profile_phone(message: Message, state: FSMContext):
    if message.contact and message.contact.user_id != message.from_user.id:
        return await message.answer(
            "لطفاً شمارهٔ خودتان را وارد کنید یا شماره را دستی بنویسید.",
            reply_markup=profile_edit_cancel_keyboard(),
        )
    raw_phone = message.contact.phone_number if message.contact else (message.text or "")
    normalized_phone = normalize_iranian_mobile(raw_phone)
    if normalized_phone is None:
        await message.answer(
            "شماره نامعتبر است. یک شماره موبایل معتبر، مثل 09151118888، وارد کنید.",
            reply_markup=profile_edit_cancel_keyboard(),
        )
        return

    async with SessionLocal() as session:
        user = (await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )).scalar_one_or_none()
        if user is None:
            await state.clear()
            await message.answer("حساب کاربری پیدا نشد. لطفاً /start را بزنید.", reply_markup=main_menu())
            return
        if not apply_profile_phone(user, normalized_phone):
            await message.answer(
                "شماره نامعتبر است. یک شماره موبایل معتبر، مثل 09151118888، وارد کنید.",
                reply_markup=profile_edit_cancel_keyboard(),
            )
            return
        await session.commit()
        updated_profile = profile_text(user)

    await state.clear()
    response = await message.answer(updated_profile, reply_markup=hide_reply_keyboard())
    try:
        await response.edit_reply_markup(reply_markup=profile_keyboard())
    except Exception:
        logger.debug("Could not attach profile controls after replacing phone keyboard", exc_info=True)
        await message.answer("مدیریت پروفایل:", reply_markup=profile_keyboard())


async def render_community_links(target: Message | CallbackQuery):
    """Combined About + official links screen; legacy callbacks remain compatible."""
    text = about_text()
    async with SessionLocal() as session:
        community_values = await get_bot_settings(session)
    return await _render_menu_target(target, text, reply_markup=community_keyboard(community_values), disable_web_page_preview=True)


@router.callback_query(F.data.in_({"user:community", "user:about", "user:community_about"}))
async def community_about(c: CallbackQuery):
    await render_community_links(c)


async def render_suggestions_menu(target: Message | CallbackQuery):
    async with SessionLocal() as session:
        question_enabled = str(await get_setting(session, "question_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"}
        topics_enabled = str(await get_setting(session, "topic_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"}
    available = []
    if topics_enabled:
        available.append("پیشنهاد موضوع و رأی‌گیری")
    else:
        available.append("رأی‌گیری موضوع‌ها")
    if question_enabled:
        available.append("پیشنهاد سؤال")
    text = "💡 <b>پیشنهادها</b>\n\n" + "، ".join(available) + " از این بخش در دسترس است."
    await _render_menu_target(target, text, reply_markup=suggestions_keyboard(question_enabled=question_enabled, topics_enabled=topics_enabled))


@router.callback_query(F.data == "user:suggestions")
async def suggestions_menu(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await render_suggestions_menu(c)


async def render_question_center(target: Message | CallbackQuery):
    user = await get_or_create_user(target.from_user)
    async with SessionLocal() as session:
        questions = (await session.execute(
            select(Question).where(Question.submitted_by == user.id)
            .order_by(Question.created_at.desc(), Question.id.desc()).limit(5)
        )).scalars().all()
    lines = ["<b>❓ پیشنهاد سؤال و پاسخ‌ها</b>", "اینجا می‌توانید سؤال‌های قبلی خود و پاسخ‌های ثبت‌شده را ببینید."]
    if questions:
        lines.append("")
        for question in questions:
            lines.append(f"<b>سؤال #{question.id}</b> — {question.created_at:%Y-%m-%d}")
            question_preview = question.question_text if len(question.question_text) <= 500 else question.question_text[:497] + "..."
            lines.append(escape(question_preview))
            if question.answer_text:
                answer_preview = question.answer_text if len(question.answer_text) <= 500 else question.answer_text[:497] + "..."
                lines.append(f"<b>✅ پاسخ مدیریت:</b>\n{escape(answer_preview)}")
            else:
                lines.append("<i>⏳ هنوز پاسخی ثبت نشده است.</i>")
            lines.append("")
    else:
        lines.extend(["", "هنوز سؤالی ارسال نکرده‌اید."])
    async with SessionLocal() as session:
        question_intake_enabled = str(await get_setting(session, "question_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"}
    question_rows = []
    if question_intake_enabled:
        question_rows.append([InlineKeyboardButton(text="➕ ارسال سؤال جدید", callback_data="user:submit_question:new")])
    else:
        lines.append("\nامکان ثبت سؤال جدید موقتاً غیرفعال است؛ پاسخ‌های قبلی همچنان در دسترس‌اند.")
    question_rows.append([InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=question_rows)
    return await _render_menu_target(target, limit_telegram_html("\n".join(lines)), reply_markup=keyboard)


@router.callback_query(F.data == "user:submit_question")
async def question_start(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    await render_question_center(c)


@router.callback_query(F.data == "user:submit_question:new")
async def question_new_start(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    async with SessionLocal() as session:
        enabled = str(await get_setting(session, "question_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"}
    if not enabled:
        return await c.answer("امکان ثبت سؤال جدید موقتاً غیرفعال است.", show_alert=True)
    await state.update_data(question_category="question")
    await state.set_state(QuestionStates.waiting_text)
    await c.message.edit_text(
        "❓ <b>پیشنهاد سؤال</b>\n\nسؤالی را که دوست دارید در یکی از پنل‌های Panel Flow مطرح شود بنویسید.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="↩️ بازگشت به سؤال‌ها و پاسخ‌ها", callback_data="user:submit_question")
        ]]),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^user:suggestion:category:(topic|question|feedback)$"))
async def suggestion_category(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    category = c.data.rsplit(":", 1)[1]
    setting_key = "question_suggestions_enabled" if category == "question" else ("topic_suggestions_enabled" if category == "topic" else None)
    if setting_key:
        async with SessionLocal() as session:
            enabled = str(await get_setting(session, setting_key, "true")).lower() in {"1", "true", "yes", "on", "enabled"}
        if not enabled:
            return await c.answer("ثبت این نوع پیشنهاد موقتاً غیرفعال است.", show_alert=True)
    await state.update_data(question_category=category)
    await state.set_state(QuestionStates.waiting_text)
    prompt = {
        "topic": "موضوع یا ایدهٔ پیشنهادی برای پنل را بنویسید:",
        "question": "سؤالی را که دوست دارید در یکی از پنل‌ها مطرح شود بنویسید:",
        "feedback": "بازخورد یا پیشنهاد خود را دربارهٔ جامعهٔ Panel Flow بنویسید:",
    }[category]
    await c.message.edit_text(prompt, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="↩️ بازگشت", callback_data="user:submit_question:new")
    ]]))
    await c.answer()


@router.message(QuestionStates.waiting_text)
async def submit_question(message: Message, state: FSMContext):
    text = (message.text or "").strip()
    if not text:
        return await message.answer("لطفاً متن سؤال را ارسال کنید.")
    if len(text) > 4000:
        return await message.answer("متن سؤال خیلی طولانی است؛ لطفاً حداکثر ۴۰۰۰ کاراکتر ارسال کنید.")
    user = await get_or_create_user(message.from_user)
    state_data = await state.get_data()
    category = state_data.get("question_category")
    if category not in {"topic", "question", "feedback"}:
        category = "question"
    async with SessionLocal() as session:
        if await has_active_feature_restriction(session, int(message.from_user.id), "suggestions"):
            await state.clear()
            return await message.answer("ارسال پیشنهاد یا بازخورد برای حساب شما به‌طور موقت محدود شده است.", reply_markup=main_menu())
        setting_key = "question_suggestions_enabled" if category == "question" else ("topic_suggestions_enabled" if category == "topic" else None)
        if setting_key and str(await get_setting(session, setting_key, "true")).lower() not in {"1", "true", "yes", "on", "enabled"}:
            await state.clear()
            return await message.answer("ثبت این نوع پیشنهاد در حال حاضر غیرفعال است؛ متن شما ثبت نشد.", reply_markup=main_menu())
        session.add(Question(question_text=text, submitted_by=user.id, category=category))
        await session.commit()
    await state.clear()
    await message.answer(
        {
            "question": "✅ پیشنهاد سؤال شما ثبت شد. برای پیگیری پاسخ، بعداً به بخش «پیشنهاد سؤال» مراجعه کنید.",
            "topic": "✅ پیشنهاد موضوع شما ثبت شد. برای پیگیری پاسخ، بعداً به بخش «پیشنهاد سؤال» مراجعه کنید.",
            "feedback": "✅ بازخورد شما ثبت شد. برای پیگیری پاسخ، بعداً به بخش «پیشنهاد سؤال» مراجعه کنید.",
        }[category],
        reply_markup=main_menu(),
    )


async def _review_attendance_eligible(session, event: Event, booking: Booking, user: User) -> bool:
    """Require the account holder to have been marked present for new reviews.

    Historical completed panels explicitly grandfathered by migration 055 remain
    reviewable, since attendance identity cannot be reconstructed retroactively.
    """
    if not bool(getattr(event, "feedback_attendance_required", True)):
        return True
    if booking.registrant_attends is False:
        return False
    participant_id = await session.scalar(select(Participant.id).where(
        Participant.booking_id == booking.id,
        Participant.user_telegram_id == user.telegram_id,
        Participant.attendance_status == AttendanceStatus.ATTENDED,
    ).limit(1))
    return participant_id is not None


async def render_reviews(target: Message | CallbackQuery):
    user = await get_or_create_user(target.from_user)
    async with SessionLocal() as session:
        events = (await session.execute(
            select(Event).join(Booking, Booking.event_id == Event.id).where(
                Booking.booked_by_user_id == user.id,
                Booking.status == RegistrationStatus.CONFIRMED,
                Event.archived.is_(True),
                Event.status == EventStatus.COMPLETED,
                Event.feedback_enabled.is_(True),
            ).distinct().order_by(Event.id.desc())
        )).scalars().all()
        eligible_event_ids = set((await session.execute(
            select(Booking.event_id).join(Participant, Participant.booking_id == Booking.id)
            .join(Event, Event.id == Booking.event_id)
            .where(Booking.booked_by_user_id == user.id,
                   Booking.status == RegistrationStatus.CONFIRMED,
                   Booking.registrant_attends.is_not(False),
                   Participant.user_telegram_id == user.telegram_id,
                   Participant.attendance_status == AttendanceStatus.ATTENDED,
                   Event.feedback_attendance_required.is_(True))
            .distinct()
        )).scalars().all())
        events = [event for event in events
                  if not bool(getattr(event, "feedback_attendance_required", True))
                  or event.id in eligible_event_ids]
        event_ids = [e.id for e in events]
        reviewed_ids = set()
        if event_ids:
            reviewed_ids = set((await session.execute(
                select(Review.event_id).where(Review.user_id == user.id, Review.event_id.in_(event_ids))
            )).scalars().all())

    if not events:
        return await _render_menu_target(
            target, "در حال حاضر پنلی برای ثبت نظر در دسترس شما نیست.", reply_markup=back_menu()
        )

    rows = []
    for event in events:
        marker = "✅ قبلاً ثبت شده" if event.id in reviewed_ids else "📝 ثبت نظر"
        rows.append([InlineKeyboardButton(
            text=f"{volume_label(event.volume)} — {event.title[:28]} | {marker}",
            callback_data=f"user:review:event:{event.id}",
        )])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="user:home")])
    return await _render_menu_target(
        target,
        "پنل‌های آرشیوشده‌ای که از طریق رزرو شما قابل بررسی هستند. برای هر پنل فقط یک نظر ثبت می‌شود و نظرها فقط برای مدیران نمایش داده می‌شوند:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data == "user:reviews")
async def reviews(c: CallbackQuery):
    await render_reviews(c)


@router.callback_query(F.data.startswith("user:review:event:"))
async def review_select_event(c: CallbackQuery, state: FSMContext):
    if await _protect_active_user_flow(c, state):
        return
    try:
        event_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        eligible = (await session.execute(
            select(Booking).where(
                Booking.event_id == event_id,
                Booking.booked_by_user_id == user.id,
                Booking.status == RegistrationStatus.CONFIRMED,
            ).order_by(Booking.created_at.desc()).limit(1)
        )).scalar_one_or_none()
        existing = (await session.execute(select(Review).where(Review.event_id == event_id, Review.user_id == user.id))).scalar_one_or_none()
        if not event or not event.archived or event.status != EventStatus.COMPLETED or not event.feedback_enabled or not eligible:
            return await c.answer("شما برای این پنل واجد شرایط ثبت نظر نیستید.", show_alert=True)
        if not await _review_attendance_eligible(session, event, eligible, user):
            return await c.answer("ثبت نظر فقط برای شرکت‌کننده‌ای فعال است که حضورش در پنل تأیید شده باشد.", show_alert=True)
        if existing:
            return await c.answer("شما قبلاً برای این پنل نظر ثبت کرده‌اید.", show_alert=True)
    await state.update_data(review_event_id=event_id, review_booking_id=eligible.id, review_rating=None)
    await c.message.edit_text(
        f"نظر شما درباره {_ltr_display(f'{volume_label(event.volume)} – {event.title}')}\n\nامتیاز شما چقدر است؟",
        reply_markup=review_rating_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data.startswith("review:rating:"))
async def review_rating(c: CallbackQuery, state: FSMContext):
    if await state.get_state() not in (None, ReviewStates.waiting_comment.state, ReviewStates.confirm.state):
        return await c.answer("فرآیند ثبت نظر منقضی شده است.", show_alert=True)
    raw = c.data.rsplit(":", 1)[1]
    rating = None if raw == "none" else int(raw) if raw.isdigit() and 1 <= int(raw) <= 5 else None
    if raw != "none" and rating is None:
        return await c.answer("امتیاز نامعتبر است.", show_alert=True)
    data = await state.get_data()
    if not data.get("review_event_id"):
        return await c.answer("فرآیند ثبت نظر منقضی شده است.", show_alert=True)
    await state.update_data(review_rating=rating)
    await state.set_state(ReviewStates.waiting_comment)
    await c.message.edit_text("لطفاً نظر یا بازخورد خود را بنویسید. این نظر فقط برای مدیران نمایش داده می‌شود.")
    await c.answer()


@router.message(ReviewStates.waiting_comment)
async def review_comment(message: Message, state: FSMContext):
    text = (message.text or "").strip()
    if not text:
        return await message.answer("لطفاً متن نظر را ارسال کنید.")
    if len(text) > 3500:
        return await message.answer("متن نظر خیلی طولانی است. لطفاً حداکثر ۳۵۰۰ کاراکتر بنویسید.")
    await state.update_data(review_text=text)
    data = await state.get_data()
    rating_text = f"⭐ {data['review_rating']}/5" if data.get("review_rating") else "بدون امتیاز"
    await message.answer(
        limit_telegram_html(
            f"<b>نظر شما</b>\nامتیاز: {rating_text}\n\n{escape(text)}\n\nآیا ارسال شود؟"
        ),
        reply_markup=review_confirm_keyboard(),
    )
    await state.set_state(ReviewStates.confirm)


@router.message(ReviewStates.confirm)
async def review_confirmation_text(message: Message):
    await message.answer("برای ارسال یا لغو نظر، از دکمه‌های نمایش‌داده‌شده استفاده کنید.")


@router.callback_query(F.data == "review:confirm")
async def review_confirm(c: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    event_id = data.get("review_event_id")
    booking_id = data.get("review_booking_id")
    review_text = (data.get("review_text") or "").strip()
    rating = data.get("review_rating")
    if not event_id or not booking_id or not review_text:
        await state.clear()
        return await c.answer("اطلاعات نظر ناقص است. دوباره از ثبت نظر شروع کنید.", show_alert=True)
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        event = await session.get(Event, int(event_id))
        booking = await session.get(Booking, int(booking_id))
        existing = (await session.execute(select(Review).where(Review.event_id == event_id, Review.user_id == user.id))).scalar_one_or_none()
        if not event or not event.archived or event.status != EventStatus.COMPLETED or not event.feedback_enabled or not booking or booking.booked_by_user_id != user.id or booking.status != RegistrationStatus.CONFIRMED:
            await state.clear()
            return await c.answer("برای این پنل واجد شرایط ثبت نظر نیستید.", show_alert=True)
        if not await _review_attendance_eligible(session, event, booking, user):
            await state.clear()
            return await c.answer("ثبت نظر فقط برای شرکت‌کننده‌ای فعال است که حضورش در پنل تأیید شده باشد.", show_alert=True)
        if existing:
            await state.clear()
            return await c.answer("شما قبلاً برای این پنل نظر ثبت کرده‌اید.", show_alert=True)
        session.add(Review(
            user_id=user.id,
            reviewer_telegram_id=user.telegram_id,
            event_id=event.id,
            booking_id=booking.id,
            rating=rating,
            text=review_text,
        ))
        try:
            from app.services.community import award_once, get_or_create_profile, xp_value
            awarded = await award_once(
                session, telegram_id=user.telegram_id,
                points=await xp_value(session, "archived_review"),
                award_type="archived_review",
                award_key=f"archived-review:{user.telegram_id}:{event.id}",
                event_id=event.id, source_id=str(event.id),
            )
            # The unique review (event_id, user_id) is the idempotency boundary.
            # Record the activity even while XP issuance is paused.
            profile = await get_or_create_profile(session, user.telegram_id)
            profile.reviews_submitted += 1
            await session.commit()
        except IntegrityError:
            await session.rollback()
            await state.clear()
            return await c.answer("شما قبلاً برای این پنل نظر ثبت کرده‌اید.", show_alert=True)
    await state.clear()
    await c.message.edit_text("✅ نظر شما با موفقیت و به‌صورت خصوصی برای مدیران ارسال شد.", reply_markup=main_menu())
    await c.answer()


@router.callback_query(F.data == "review:cancel")
async def review_cancel(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.message.edit_text("ثبت نظر لغو شد.", reply_markup=main_menu())
    await c.answer()


async def show_personal_reward_offer(message: Message, reward_id: int, *, telegram_id: int | None = None) -> None:
    """Display an assigned reward (also used by /start reward_<id> deep links)."""
    recipient_telegram_id = int(telegram_id if telegram_id is not None else message.from_user.id)
    async with SessionLocal() as session:
        reward = await session.get(DiscountCode, reward_id)
        if (
            not reward or reward.kind != "personal" or not reward.active
            or reward.recipient_telegram_id != recipient_telegram_id
        ):
            return await message.answer("این هدیه معتبر نیست یا دیگر قابل استفاده نیست.", reply_markup=main_menu())
        event_rows = (await session.execute(
            select(Event).join(DiscountCodeEvent, DiscountCodeEvent.event_id == Event.id).where(
                DiscountCodeEvent.discount_code_id == reward.id,
                Event.archived.is_(False),
                Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED)),
            ).order_by(Event.id)
        )).scalars().all()
        if not event_rows:
            return await message.answer("این هدیه دیگر پنل واجد شرایطی ندارد.", reply_markup=main_menu())
        event_names = [
            f"{volume_label(event.volume)} — {event.title}"
            + (" (پنل آینده · پیش‌نویس)" if event.status == EventStatus.DRAFT else " (منتشرشده)")
            for event in event_rows
        ]
        accepted = reward.accepted_at is not None
        reward_label = discount_display(reward)
        reward_reason = reward.reason
    if accepted:
        return await message.answer(
            "✅ هدیه شما قبلاً پذیرفته شده است. این هدیه فقط برای پنل‌های فهرست‌شده قابل استفاده است و صندلی رزرو نمی‌کند. "
            "در ثبت‌نام چندنفره، فقط هزینهٔ یک نفر را پوشش می‌دهد؛ تخفیف هنگام ثبت‌نام و در صورت وجود ظرفیت اعمال می‌شود.",
            reply_markup=main_menu(),
        )
    shown_events = "\n".join(f"• {escape(name)}" for name in event_names[:8])
    if len(event_names) > 8:
        shown_events += f"\nو {len(event_names) - 8} پنل دیگر"
    await message.answer(
        f"🎁 <b>یک هدیه ویژه برای شما!</b>\n\n"
        f"میزان تخفیف: <b>{escape(reward_label)}</b>\n"
        + (f"علت هدیه: {escape(reward_reason)}\n" if reward_reason else "")
        + f"پنل‌های مجاز: \n{shown_events}\n\n"
        "با پذیرش هدیه، این تخفیف به حساب تلگرام شما و پنل‌های بالا اختصاص می‌یابد. برای استفاده، باید خودتان رزروکننده باشید. "
        "پذیرش هدیه صندلی رزرو نمی‌کند؛ تخفیف هنگام ثبت‌نام و در صورت باز بودن ثبت‌نام اعمال می‌شود. "
        "برای رزرو گروهی، تخفیف فقط هزینه یک نفر را پوشش می‌دهد.",
        reply_markup=personal_reward_keyboard(reward_id),
    )


@router.callback_query(F.data.regexp(r"^user:reward:accept:\d+$"))
async def accept_personal_reward(c: CallbackQuery):
    try:
        reward_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شناسه هدیه نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        reward = (await session.execute(
            select(DiscountCode).where(DiscountCode.id == reward_id).with_for_update()
        )).scalar_one_or_none()
        if (
            not reward or reward.kind != "personal" or not reward.active
            or reward.recipient_telegram_id != c.from_user.id
        ):
            return await c.answer("این هدیه معتبر نیست یا دیگر فعال نیست.", show_alert=True)
        has_events = (await session.execute(select(DiscountCodeEvent.id).join(
            Event, Event.id == DiscountCodeEvent.event_id
        ).where(
            DiscountCodeEvent.discount_code_id == reward.id,
            Event.archived.is_(False),
            Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED)),
        ).limit(1))).scalar_one_or_none()
        if has_events is None:
            return await c.answer("این هدیه دیگر پنل واجد شرایطی ندارد.", show_alert=True)
        if reward.accepted_at is None:
            reward.accepted_at = utc_now_naive()
            await session.commit()
        else:
            await session.rollback()
        label = discount_display(reward)
    await c.message.edit_text(
        f"✅ هدیه شما پذیرفته شد. تخفیف <b>{escape(label)}</b> برای پنل‌های مشخص‌شده فعال است.\n\n"
        "هنگام ثبت‌نام در یکی از آن پنل‌ها، تخفیف به‌طور خودکار اعمال می‌شود. اگر ثبت‌نام تک‌نفره با تخفیف ۱۰۰٪ باشد، نیازی به ارسال رسید ندارید. "
        "هدیه پس از آرشیو پنل قابل استفاده نخواهد بود.",
        reply_markup=main_menu(),
    )
    await c.answer("هدیه پذیرفته شد.")


async def _restore_discount_draft(c: CallbackQuery, state: FSMContext, redemption_id: int, *, use_discount: bool) -> None:
    user = await get_or_create_user(c.from_user)
    no_seat_keyboard = None
    capacity_message = None
    async with SessionLocal() as session:
        redemption = (await session.execute(
            select(DiscountRedemption).where(DiscountRedemption.id == redemption_id).with_for_update()
        )).scalar_one_or_none()
        if not redemption or redemption.user_telegram_id != c.from_user.id:
            return await c.answer("درخواست ثبت‌نام پیدا نشد.", show_alert=True)
        if not redemption.draft_json:
            return await c.answer("اطلاعات این درخواست دیگر قابل بازیابی نیست. لطفاً از پنل دوباره ثبت‌نام کنید.", show_alert=True)
        try:
            draft = json.loads(redemption.draft_json)
        except (TypeError, json.JSONDecodeError):
            return await c.answer("اطلاعات ثبت‌نام قابل بازیابی نیست؛ از پنل دوباره اقدام کنید.", show_alert=True)
        event = await session.get(Event, int(redemption.event_id or draft.get("event_id") or 0))
        if not event:
            return await c.answer("پنل دیگر در دسترس نیست.", show_alert=True)

        code = await session.get(DiscountCode, int(redemption.discount_code_id or 0)) if use_discount else None
        if use_discount:
            linked = (await session.execute(select(DiscountCodeEvent.id).where(
                DiscountCodeEvent.discount_code_id == redemption.discount_code_id,
                DiscountCodeEvent.event_id == event.id,
            ))).scalar_one_or_none() if code else None
            if redemption.status != "approved" or not code or not code.active or linked is None:
                # Preserve an easy fallback when an admin disabled the promotion.
                can_fallback = redemption.status in ("approved", "rejected", "pending")
                if can_fallback:
                    redemption.status = "rejected"
                    redemption.reviewed_at = utc_now_naive()
                    redemption.updated_at = utc_now_naive()
                    await session.commit()
                else:
                    await session.rollback()
                await c.answer("کد دیگر قابل استفاده نیست.")
                return await c.message.answer(
                    "این کد دیگر فعال یا قابل استفاده نیست. می‌توانید با قیمت عادی ادامه دهید یا ثبت‌نام را لغو کنید.",
                    reply_markup=discount_request_user_keyboard(redemption_id),
                )
        elif redemption.status not in ("pending", "approved", "rejected"):
            return await c.answer("این درخواست قبلاً نهایی شده است.", show_alert=True)

        # Neither approval nor choosing the full-price fallback reserves seats.
        # Check the panel state before restoring checkout, and leave the request
        # intact if capacity/registration has changed so the user can retry later.
        used = await seats_used(session, event.id)
        participants = list(draft.get("participants", []))
        requested_count = max(1, len(participants) or int(redemption.participant_count or 1))
        remaining = max(0, int(event.capacity) - int(used))
        open_for_registration = await event_is_bookable(event)
        enough_capacity = used + requested_count <= int(event.capacity)
        if event.archived or event.status in (EventStatus.CANCELLED, EventStatus.COMPLETED):
            redemption.status = "cancelled"
            redemption.draft_json = None
            redemption.contact_phone = None
            redemption.updated_at = utc_now_naive()
            await session.commit()
            await c.answer()
            return await c.message.answer("این پنل دیگر قابل ثبت‌نام نیست؛ درخواست تخفیف بسته شد و صندلی‌ای رزرو نشده بود.", reply_markup=main_menu())
        if not open_for_registration or not enough_capacity:
            waitlist_available = bool(event.waitlist_enabled and used >= event.capacity)
            rows = []
            if waitlist_available:
                rows.append([InlineKeyboardButton(text="⏳ عضویت در لیست انتظار", callback_data=f"event:waitlist:{event.id}")])
                capacity_message = "ظرفیت این پنل تکمیل شده است. هیچ صندلی‌ای برای درخواست تخفیف رزرو نشده؛ اگر مایلید می‌توانید به لیست انتظار بپیوندید. درخواست تخفیف شما برای تلاش دوباره حفظ می‌شود."
            elif remaining > 0 and open_for_registration:
                capacity_message = (
                    f"در حال حاضر فقط {remaining} صندلی باقی مانده و برای گروه {requested_count} نفرهٔ شما کافی نیست. "
                    "هیچ صندلی‌ای رزرو نشده است. درخواست را حفظ کرده‌ایم؛ می‌توانید بعداً دوباره تلاش کنید یا آن را لغو کنید."
                )
            else:
                capacity_message = "ثبت‌نام این پنل بسته است یا ظرفیت کافی ندارد. هیچ صندلی‌ای رزرو نشده است؛ درخواست شما حفظ شده و می‌توانید آن را لغو کنید."
            if use_discount:
                rows.append([InlineKeyboardButton(text="🔄 بررسی دوباره ظرفیت و ادامه", callback_data=f"user:discount:continue:{redemption_id}")])
            else:
                rows.append([InlineKeyboardButton(text="🔄 بررسی دوباره ظرفیت و ادامه", callback_data=f"user:discount:normal:{redemption_id}")])
            rows.append([InlineKeyboardButton(text="❌ لغو درخواست تخفیف", callback_data=f"user:discount:cancel:{redemption_id}")])
            rows.append([InlineKeyboardButton(text="🏠 منوی اصلی", callback_data="user:home")])
            no_seat_keyboard = InlineKeyboardMarkup(inline_keyboard=rows)
            await session.rollback()
        else:
            if not use_discount:
                # Defer withdrawing the approval/request until a normal-price booking
                # is actually committed by create_booking. This avoids losing a
                # pending request if capacity vanishes during the final confirmation.
                pass
            await state.clear()
            await state.update_data(
                event_id=int(event.id), user_id=int(user.id), participants=participants,
                count=len(participants), current_index=len(participants),
                booker_phone=draft.get("booker_phone"), allow_duplicate=bool(draft.get("allow_duplicate")),
                pricing_option=str(draft.get("pricing_option") or BASE_OPTION),
                booking_flow_message_id=int(c.message.message_id),
                discount_code_id=int(code.id) if use_discount and code else None,
                discount_redemption_id=int(redemption.id) if use_discount else None,
                continue_full_price_redemption_id=(int(redemption.id) if not use_discount else None),
                personal_reward_id=None, discount_prompt_skipped=True,
            )
    if capacity_message:
        try:
            await c.message.edit_reply_markup(reply_markup=None)
        except Exception:
            logger.debug("Could not remove stale discount action keyboard; redemption_id=%s", redemption_id, exc_info=True)
        await c.answer()
        return await c.message.answer(capacity_message, reply_markup=no_seat_keyboard or main_menu())
    try:
        await c.message.edit_reply_markup(reply_markup=None)
    except Exception:
        logger.debug("Could not remove used discount action keyboard; redemption_id=%s", redemption_id, exc_info=True)
    await c.answer()
    await show_booking_summary(c.message, state)


@router.callback_query(F.data.regexp(r"^user:discount:continue:\d+$"))
async def continue_discounted_registration(c: CallbackQuery, state: FSMContext):
    try:
        redemption_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("درخواست نامعتبر است.", show_alert=True)
    await _restore_discount_draft(c, state, redemption_id, use_discount=True)


@router.callback_query(F.data.regexp(r"^user:discount:normal:\d+$"))
async def continue_full_price_registration(c: CallbackQuery, state: FSMContext):
    try:
        redemption_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("درخواست نامعتبر است.", show_alert=True)
    await _restore_discount_draft(c, state, redemption_id, use_discount=False)


@router.callback_query(F.data.regexp(r"^user:discount:cancel:\d+$"))
async def cancel_discount_request(c: CallbackQuery, state: FSMContext):
    try:
        redemption_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("درخواست نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        redemption = (await session.execute(
            select(DiscountRedemption).where(DiscountRedemption.id == redemption_id).with_for_update()
        )).scalar_one_or_none()
        if not redemption or redemption.user_telegram_id != c.from_user.id:
            return await c.answer("درخواست ثبت‌نام پیدا نشد.", show_alert=True)
        if redemption.status not in ("pending", "approved", "rejected"):
            return await c.answer("این درخواست قبلاً نهایی شده است.", show_alert=True)
        redemption.status = "cancelled"
        redemption.draft_json = None
        redemption.contact_phone = None
        redemption.updated_at = utc_now_naive()
        await session.commit()
    await state.clear()
    await c.message.edit_text("درخواست تخفیف و ثبت‌نام مربوط به آن لغو شد. هیچ صندلی‌ای رزرو نشده بود.", reply_markup=main_menu())
    await c.answer("لغو شد.")


@router.callback_query(F.data.startswith("user:") | F.data.startswith("event:") | F.data.startswith("booking:") | F.data.startswith("review:"))
async def stale_user_callback(c: CallbackQuery):
    await c.answer("این دکمه منقضی شده یا دیگر در دسترس نیست. لطفاً از منوی اصلی دوباره انتخاب کنید.", show_alert=True)
