"""Persistent public reply-keyboard navigation.

This router is registered before the feature routers so an exact menu-button tap
cannot be consumed as the text of an active FSM form.
"""
from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app.bot.keyboards import persistent_main_keyboard
from app.bot.states import BookingStates, ProfileStates
from app.config import settings
from app.db.session import SessionLocal

router = Router(name="persistent-reply-menu")

# Keep these labels in sync with persistent_main_keyboard(). Button text is
# deliberately stable because Telegram reply keyboards send the label as text.
@router.message(F.text.in_({"⬅️ مرحلهٔ قبل", "❌ لغو ایجاد"}))
async def panel_creation_reply_keyboard_action(message: Message, state: FSMContext) -> None:
    """Handle wizard controls before any user FSM can consume them as form text."""
    current_state = await state.get_state()
    from app.bot.handlers.admin import (
        admin_event_creation_reply_actions,
        expired_panel_creation_reply_actions,
    )
    if current_state and current_state.startswith("AdminEventStates:"):
        await admin_event_creation_reply_actions(message, state)
    else:
        # This fallback also handles a host/admin who has another active form
        # (for example a receipt): it removes only the stale keyboard and keeps
        # that unrelated FSM/data intact.
        await expired_panel_creation_reply_actions(message, state)


REPLY_MENU_ACTIONS = {
    "🏠 پنل‌های پیش‌رو": "events",
    "🎟 ثبت‌نام‌های من": "bookings",
    "👤 پروفایل من": "profile",
    "📄 سؤالات پنل‌ها": "questions",
    "📚 پنل‌های گذشته": "past_panels",
    "💡 پیشنهادها": "suggestions",
    "📝 ثبت نظر": "reviews",
    "📝 ثبت نظر و تیکت": "reviews",  # legacy label from previously opened Telegram keyboards
    "🗳 رأی‌گیری موضوع‌ها": "topics",  # legacy label
    "🏆 لیدربورد و چالش‌ها": "community_features",
    "🎮 سرگرمی و چالش‌ها": "community_features",  # legacy label
    "💬 جامعه و دربارهٔ ما": "community_about",
}

_ADMIN_FORM_PREFIXES = (
    "Admin",
    "CommunityAdmin",
    "BulkReward",
    "CancellationCase",
    "DiscountAdmin",
    "V77AdminStates",
)


@router.message(F.text.in_(tuple(REPLY_MENU_ACTIONS)))
async def persistent_menu_action(message: Message, state: FSMContext) -> None:
    action = REPLY_MENU_ACTIONS.get((message.text or "").strip())
    if action is None:
        return

    current_state = await state.get_state()
    state_data = await state.get_data()

    # Navigation sent from the optional keyboard must never be interpreted as a
    # free-text answer, break signup, skip onboarding, or replace a receipt.
    if current_state:
        if current_state == BookingStates.waiting_receipt.state and state_data.get("booking_id"):
            reason = "ارسال رسید برای رزرو فعال است. عکس، فایل یا متن رسید را ارسال کنید؛ برای لغو همین رزرو /cancel را بزنید."
        elif int(message.from_user.id) in settings.super_admin_id_set and current_state.startswith(_ADMIN_FORM_PREFIXES):
            reason = "فرایند مدیریتی فعالی دارید. برای حفظ اطلاعات، آن را تکمیل کنید یا /cancel بزنید."
        else:
            reason = "فرایند فعلی هنوز فعال است. برای ادامه از دکمه‌های همان مرحله استفاده کنید یا در صورت انصراف /cancel بزنید."
        await message.answer(reason)
        return

    # Imports are intentionally lazy to avoid a router import cycle. Screen and
    # business logic are shared with the existing inline-menu handlers.
    from app.bot.handlers.user import (
        about_text,
        get_or_create_user,
        profile_text,
        render_my_bookings,
        render_question_center,
        render_reviews,
        render_suggestions_menu,
        render_user_questions,
        show_events,
    )
    from app.bot.keyboards import back_menu, profile_keyboard

    if action == "events":
        await show_events(message)
    elif action == "bookings":
        await render_my_bookings(message)
    elif action == "profile":
        user = await get_or_create_user(message.from_user)
        await message.answer(profile_text(user), reply_markup=profile_keyboard())
    elif action == "questions":
        await render_user_questions(message)
    elif action == "suggestions":
        await render_suggestions_menu(message)
    elif action == "reviews":
        await render_reviews(message)
    elif action == "topics":
        from app.bot.handlers.topics import _render_topic_voting
        await _render_topic_voting(message, answer=False)
    elif action == "community_features":
        from app.bot.handlers.community import render_community_home
        await render_community_home(message)
    elif action == "community_about":
        from app.bot.handlers.user import render_community_links
        await render_community_links(message)
    elif action == "past_panels":
        from app.bot.handlers.v77_features import render_past_panels
        await render_past_panels(message)

