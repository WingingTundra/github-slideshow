"""Optional per-panel attendance management and secure QR/manual check-in."""
from __future__ import annotations

import hashlib
import io
import logging
import secrets
from datetime import timedelta
from html import escape

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import BufferedInputFile, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

from app.config import settings
from app.db.models import (
    AttendanceAudit, AttendanceStatus, Booking, Event, EventStatus,
    Participant, RegistrationStatus, User,
)
from app.db.session import SessionLocal
from app.display_utils import volume_label
from app.services.admin_audit import write_admin_action
from app.services.attendance_security import checkin_proof_is_valid
from app.time_utils import utc_now_naive

router = Router()
logger = logging.getLogger(__name__)
ROSTER_PAGE_SIZE = 10
CHECKIN_PAGE_SIZE = 15


async def _is_admin(telegram_id: int) -> bool:
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(telegram_id)


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _status_value(value) -> str:
    return str(getattr(value, "value", value) or "unmarked")


def _status_label(value) -> str:
    return {"unmarked": "⬜ Not marked", "attended": "✅ Attended", "no_show": "❌ No-show"}.get(_status_value(value), "⬜ Not marked")


def _attendance_screen_keyboard(event: Event) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(
        text=("🟢 حضور و غیاب: فعال" if event.attendance_enabled else "⚪ حضور و غیاب: غیرفعال"),
        callback_data=f"admin:attendance:toggle:{event.id}",
    )]]
    if event.attendance_enabled:
        rows += [
            [InlineKeyboardButton(text="📋 دفتر حضور و غیاب", callback_data=f"admin:attendance:roster:{event.id}:1")],
            [InlineKeyboardButton(text="📷 ساخت / نوسازی QR و کد ورود", callback_data=f"admin:attendance:qr:{event.id}")],
            [InlineKeyboardButton(text="🕘 سابقهٔ اصلاح حضورها", callback_data=f"admin:attendance:history:{event.id}")],
        ]
    rows += [
        [InlineKeyboardButton(text="💬 بازخورد پس از پنل: " + ("روشن" if event.feedback_enabled else "خاموش"), callback_data=f"admin:event:feedback:{event.id}")],
        [InlineKeyboardButton(text="🔙 بازگشت به مدیریت پنل", callback_data=f"admin:event:view:{event.id}")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _render_attendance_screen(c: CallbackQuery, event_id: int):
    async with SessionLocal() as session:
        event = await session.get(Event, int(event_id))
        if event is None:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        counts = (await session.execute(
            select(Participant.attendance_status, func.count(Participant.id))
            .join(Booking, Participant.booking_id == Booking.id)
            .where(Booking.event_id == event.id, Booking.status == RegistrationStatus.CONFIRMED)
            .group_by(Participant.attendance_status)
        )).all()
    parts = { _status_value(status): int(count) for status, count in counts }
    text = (
        f"<b>حضور و غیاب — {escape(volume_label(event.volume))} · {escape(event.title)}</b>\n\n"
        f"وضعیت: {'فعال' if event.attendance_enabled else 'غیرفعال'}\n"
        f"حاضر: {parts.get('attended', 0)} · غایب: {parts.get('no_show', 0)} · ثبت‌نشده: {parts.get('unmarked', 0)}\n\n"
        "حضور و غیاب اختیاری است. تا وقتی آن را فعال نکنید، QR، کد ورود و دفتر حضور در دسترس نیستند."
    )
    await c.message.edit_text(text, reply_markup=_attendance_screen_keyboard(event))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:attendance:\d+$"))
async def attendance_screen(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_attendance_screen(c, int((c.data or "").rsplit(":", 1)[1]))


@router.callback_query(F.data.regexp(r"^admin:attendance:toggle:\d+$"))
async def attendance_toggle(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        event = await session.get(Event, event_id, with_for_update=True)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        event.attendance_enabled = not bool(event.attendance_enabled)
        if not event.attendance_enabled:
            # Revoke both entry methods immediately. Existing attendance records stay intact.
            event.attendance_checkin_token_hash = None
            event.attendance_checkin_code_hash = None
            event.attendance_checkin_session_id = None
            event.attendance_checkin_token_expires_at = None
            event.attendance_checkin_code_expires_at = None
        await write_admin_action(
            session, actor_telegram_id=c.from_user.id,
            action="attendance_enabled" if event.attendance_enabled else "attendance_disabled",
            entity_type="event", entity_id=event.id,
            details={"enabled": bool(event.attendance_enabled)},
        )
        await session.commit()
    await _render_attendance_screen(c, event_id)


@router.callback_query(F.data.regexp(r"^admin:event:feedback:\d+$"))
async def feedback_toggle(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        event = await session.get(Event, event_id, with_for_update=True)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        event.feedback_enabled = not bool(event.feedback_enabled)
        await write_admin_action(session, actor_telegram_id=c.from_user.id,
            action="event_feedback_enabled" if event.feedback_enabled else "event_feedback_disabled",
            entity_type="event", entity_id=event_id, details={"enabled": bool(event.feedback_enabled)})
        await session.commit()
    await c.answer("بازخورد پس از پنل فعال شد." if event.feedback_enabled else "بازخورد پس از پنل غیرفعال شد.")
    from app.bot.handlers.admin import render_event
    await render_event(c, event_id, answer_callback=False)


@router.callback_query(F.data.regexp(r"^admin:attendance:qr:\d+$"))
async def attendance_qr(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = int((c.data or "").rsplit(":", 1)[1])

    # Verify Telegram identity and render the QR before changing the currently
    # valid credentials. A transient getMe/qrcode failure must not invalidate a
    # working code that the host has already shared.
    try:
        me = await c.bot.get_me()
    except Exception:
        logger.exception("Could not get bot identity for attendance QR, event_id=%s", event_id)
        return await c.answer("ارتباط با تلگرام برقرار نشد؛ کد فعلی تغییری نکرد. دوباره تلاش کنید.", show_alert=True)
    if not me.username:
        return await c.answer("نام کاربری ربات تنظیم نشده؛ کد فعلی تغییری نکرد.", show_alert=True)

    token = secrets.token_hex(12)
    link = f"https://t.me/{me.username}?start=checkin_{event_id}_{token}"
    try:
        import qrcode
        image = qrcode.make(link)
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        photo = BufferedInputFile(buffer.getvalue(), filename=f"panel-flow-checkin-{event_id}.png")
    except Exception:
        logger.exception("Failed to render attendance QR for event_id=%s", event_id)
        return await c.answer("ساخت تصویر QR ناموفق بود؛ کد فعلی تغییری نکرد.", show_alert=True)

    session_id = secrets.token_hex(8)
    saved_code = None
    title = ""
    # A unique index protects against two admins generating the same six-digit
    # code for different events at the same moment. Retry that extremely rare
    # collision rather than surfacing an IntegrityError to Telegram.
    for _attempt in range(10):
        code = f"{secrets.randbelow(1_000_000):06d}"
        try:
            async with SessionLocal() as session:
                event = await session.get(Event, event_id, with_for_update=True)
                if not event:
                    return await c.answer("پنل پیدا نشد.", show_alert=True)
                if not event.attendance_enabled:
                    return await c.answer("ابتدا حضور و غیاب این پنل را فعال کنید.", show_alert=True)
                if event.archived or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED):
                    return await c.answer("برای پنل پیش‌نویس، لغوشده یا بایگانی‌شده نمی‌توان کد ورود ساخت.", show_alert=True)
                code_hash = _digest(code)
                if secrets.compare_digest(event.attendance_checkin_code_hash or "", code_hash):
                    continue
                duplicate = (await session.execute(select(Event.id).where(
                    Event.attendance_checkin_code_hash == code_hash, Event.id != event.id
                ).limit(1))).scalar_one_or_none()
                if duplicate is not None:
                    continue
                expires_at = utc_now_naive() + timedelta(hours=12)
                event.attendance_checkin_token_hash = _digest(token)
                event.attendance_checkin_code_hash = code_hash
                event.attendance_checkin_session_id = session_id
                event.attendance_checkin_token_expires_at = expires_at
                event.attendance_checkin_code_expires_at = expires_at
                await write_admin_action(session, actor_telegram_id=c.from_user.id,
                    action="attendance_checkin_credentials_rotated", entity_type="event", entity_id=event_id,
                    details={"credentials_rotated": True})
                await session.commit()
                title = f"{volume_label(event.volume)} — {event.title}"
                saved_code = code
                break
        except IntegrityError:
            logger.info("Attendance code collided during concurrent creation; retrying event_id=%s", event_id)
            continue
    if saved_code is None:
        return await c.answer("ساخت کد یکتا ناموفق بود؛ کد قبلی همچنان معتبر است. دوباره تلاش کنید.", show_alert=True)

    try:
        await c.message.answer_photo(
            photo,
            caption=(f"<b>QR حضور و غیاب</b>\n{escape(title)}\n\n"
                     f"کد دستی: <code>{saved_code}</code>\n"
                     "شرکت‌کننده باید با همان حساب تلگرامی که رزرو را انجام داده، QR را باز کند یا دستور زیر را بفرستد:\n"
                     f"<code>/checkin {saved_code}</code>\n\n"
                     "با ساخت QR جدید، QR و کد قبلی فوراً از اعتبار می‌افتند."),
        )
    except Exception:
        logger.exception("Attendance credentials saved but QR could not be delivered, event_id=%s", event_id)
        return await c.answer("کد جدید ذخیره شد، اما ارسال تصویر ناموفق بود. دوباره ساخت QR را بزنید؛ کد قبلی منقضی می‌شود.", show_alert=True)
    await c.answer("QR و کد ورود ساخته شد؛ کد قبلی دیگر معتبر نیست.")


async def show_checkin_from_message(message: Message, event_id: int, token: str):
    await _show_checkin(message, event_id, token, "token")


async def _checkin_view(user_id: int, event_id: int, proof: str, proof_kind: str, page: int = 1):
    """Build one page of check-in choices after revalidating the QR/code proof."""
    async with SessionLocal() as session:
        event = await session.get(Event, int(event_id))
        if (not event or not event.attendance_enabled or event.archived
            or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED)):
            return None, None, "unavailable"
        if not checkin_proof_is_valid(event, proof, proof_kind):
            return None, None, "invalid"
        # New QR flows put only a short, event-scoped nonce in callback_data.
        # Legacy credentials from before the nonce rollout remain supported until
        # their one-time migration grace expiry.
        callback_ref = event.attendance_checkin_session_id or proof
        bookings = (await session.execute(
            select(Booking).options(selectinload(Booking.participants))
            .where(Booking.event_id == event.id, Booking.booked_by_user_id == int(user_id),
                   Booking.status == RegistrationStatus.CONFIRMED)
            .order_by(Booking.id)
        )).scalars().all()
        choices = [(booking, participant) for booking in bookings for participant in booking.participants]
        label = f"{volume_label(event.volume)} — {event.title}"
    if not choices:
        return None, None, "no_booking"

    page_count = max(1, (len(choices) + CHECKIN_PAGE_SIZE - 1) // CHECKIN_PAGE_SIZE)
    page = min(max(1, int(page)), page_count)
    prefix = ("t" if proof_kind == "token" else "c") + callback_ref
    rows = []
    for booking, person in choices[(page - 1) * CHECKIN_PAGE_SIZE:page * CHECKIN_PAGE_SIZE]:
        rows.append([InlineKeyboardButton(
            text=f"{person.full_name[:38]} · {_status_label(person.attendance_status)}",
            callback_data=f"user:checkin:mark:{event_id}:{person.id}:{prefix}",
        )])
    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton(
            text="◀️ قبلی", callback_data=f"user:checkin:page:{event_id}:{page-1}:{prefix}"
        ))
    if page < page_count:
        nav.append(InlineKeyboardButton(
            text="بعدی ▶️", callback_data=f"user:checkin:page:{event_id}:{page+1}:{prefix}"
        ))
    if nav:
        rows.append(nav)
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    text = (
        f"<b>ثبت حضور</b>\n{escape(label)}\n\n"
        "نام خود را انتخاب کنید. این عملیات فقط روی رزرو تأییدشدهٔ حساب شما اعمال می‌شود.\n"
        f"صفحه {page}/{page_count}"
    )
    return text, markup, None


async def _show_checkin(message: Message, event_id: int, proof: str, proof_kind: str):
    from app.bot.handlers.user import get_or_create_user
    user = await get_or_create_user(message.from_user)
    text, markup, error = await _checkin_view(user.id, event_id, proof, proof_kind)
    if error == "unavailable":
        return await message.answer("حضور و غیاب این پنل در دسترس نیست یا غیرفعال شده است.")
    if error == "invalid":
        return await message.answer("QR یا کد ورود منقضی یا نامعتبر است. از میزبان کد جدید بگیرید.")
    if error == "no_booking":
        return await message.answer("رزرو تأییدشده‌ای برای این پنل روی حساب شما پیدا نشد. لطفاً با میزبان بررسی کنید.")
    await message.answer(text, reply_markup=markup)


@router.callback_query(F.data.regexp(r"^user:checkin:page:\d+:\d+:[tc][A-Za-z0-9]+$"))
async def checkin_choices_page(c: CallbackQuery):
    parts = (c.data or "").split(":")
    try:
        event_id, page = int(parts[3]), int(parts[4])
        prefix = parts[5]
        proof_kind, proof = ("token" if prefix[0] == "t" else "code"), prefix[1:]
    except (ValueError, IndexError):
        return await c.answer("پیوند ورود معتبر نیست.", show_alert=True)
    if page < 1 or (proof_kind == "code" and not ((len(proof) == 6 and proof.isdigit()) or (len(proof) == 16 and proof.isalnum()))):
        return await c.answer("درخواست صفحه معتبر نیست.", show_alert=True)
    from app.bot.handlers.user import get_or_create_user
    user = await get_or_create_user(c.from_user)
    text, markup, error = await _checkin_view(user.id, event_id, proof, proof_kind, page)
    if error:
        messages = {
            "unavailable": "حضور و غیاب این پنل غیرفعال است.",
            "invalid": "کد ورود منقضی شده است. QR یا کد تازه بگیرید.",
            "no_booking": "رزرو تأییدشده‌ای برای این پنل روی حساب شما پیدا نشد.",
        }
        return await c.answer(messages.get(error, "امکان نمایش این صفحه وجود ندارد."), show_alert=True)
    await c.message.edit_text(text, reply_markup=markup)
    await c.answer()


@router.message(Command("checkin"))
async def manual_checkin(message: Message, command: CommandObject):
    code = (getattr(command, "args", None) or "").strip()
    if len(code) != 6 or not code.isdigit():
        return await message.answer("کد ۶ رقمی را به این شکل وارد کنید: <code>/checkin 123456</code>")
    async with SessionLocal() as session:
        event_id = (await session.execute(select(Event.id).where(
            Event.attendance_enabled.is_(True), Event.attendance_checkin_code_hash == _digest(code),
            Event.attendance_checkin_code_expires_at > utc_now_naive(), Event.archived.is_(False), Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED)),
        ).limit(1))).scalar_one_or_none()
    if not event_id:
        return await message.answer("کد ورود نامعتبر یا منقضی است. از میزبان کد جدید بگیرید.")
    await _show_checkin(message, int(event_id), code, "code")


@router.callback_query(F.data.regexp(r"^user:checkin:mark:\d+:\d+:[tc][A-Za-z0-9]+$"))
async def mark_self_checkin(c: CallbackQuery):
    parts = (c.data or "").split(":")
    try:
        event_id, participant_id = int(parts[3]), int(parts[4])
        proof_kind, proof = parts[5][0], parts[5][1:]
    except (ValueError, IndexError):
        return await c.answer("دکمهٔ ورود معتبر نیست.", show_alert=True)
    if proof_kind == "c" and not ((len(proof) == 6 and proof.isdigit()) or (len(proof) == 16 and proof.isalnum())):
        return await c.answer("کد ورود معتبر نیست.", show_alert=True)
    from app.bot.handlers.user import get_or_create_user
    user = await get_or_create_user(c.from_user)
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update()
            .execution_options(populate_existing=True))).scalar_one_or_none()
        if (not event or not event.attendance_enabled or event.archived
            or event.status not in (EventStatus.PUBLISHED, EventStatus.COMPLETED)):
            return await c.answer("حضور و غیاب این پنل غیرفعال است.", show_alert=True)
        if not checkin_proof_is_valid(event, proof, "token" if proof_kind == "t" else "code"):
            return await c.answer("کد ورود منقضی شده است. QR یا کد تازه بگیرید.", show_alert=True)
        participant = (await session.execute(
            select(Participant).join(Booking, Participant.booking_id == Booking.id)
            .where(Participant.id == participant_id, Booking.event_id == event_id,
                   Booking.booked_by_user_id == user.id, Booking.status == RegistrationStatus.CONFIRMED)
            .with_for_update().execution_options(populate_existing=True)
        )).scalar_one_or_none()
        if not participant:
            return await c.answer("نام انتخابی با رزرو تأییدشدهٔ حساب شما مطابقت ندارد.", show_alert=True)
        old_status = _status_value(participant.attendance_status)
        if old_status == "attended":
            return await c.answer("حضور شما قبلاً ثبت شده است.", show_alert=True)
        participant.attendance_status = AttendanceStatus.ATTENDED
        session.add(AttendanceAudit(event_id=event_id, participant_id=participant_id,
            actor_telegram_id=int(c.from_user.id), old_status=old_status, new_status="attended", source="qr" if proof_kind == "t" else "code"))
        await session.commit()
    await c.message.edit_text("✅ حضور شما ثبت شد. اگر نام اشتباهی را انتخاب کرده‌اید، از میزبان بخواهید آن را اصلاح کند.")
    await c.answer("حضور ثبت شد.")


@router.callback_query(F.data.regexp(r"^admin:attendance:roster:\d+:\d+$"))
async def attendance_roster(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    await _render_attendance_roster(c, int(parts[3]), max(1, int(parts[4])))


async def _render_attendance_roster(c: CallbackQuery, event_id: int, page: int):
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event or not event.attendance_enabled:
            return await c.answer("ابتدا حضور و غیاب را فعال کنید.", show_alert=True)
        total = int((await session.execute(select(func.count(Participant.id)).join(Booking)
            .where(Booking.event_id == event_id, Booking.status == RegistrationStatus.CONFIRMED))).scalar_one())
        page_count = max(1, (total + ROSTER_PAGE_SIZE - 1) // ROSTER_PAGE_SIZE)
        page = min(max(1, int(page)), page_count)
        offset = (page - 1) * ROSTER_PAGE_SIZE
        people = (await session.execute(select(Participant).join(Booking)
            .options(selectinload(Participant.booking))
            .where(Booking.event_id == event_id, Booking.status == RegistrationStatus.CONFIRMED)
            .order_by(Participant.id).offset(offset).limit(ROSTER_PAGE_SIZE))).scalars().all()
        counts = (await session.execute(select(Participant.attendance_status, func.count(Participant.id))
            .join(Booking).where(Booking.event_id == event_id, Booking.status == RegistrationStatus.CONFIRMED)
            .group_by(Participant.attendance_status))).all()
    count_map = {_status_value(status): int(count) for status, count in counts}
    lines = [f"<b>دفتر حضور — {escape(volume_label(event.volume))} · {escape(event.title)}</b>",
             f"✅ {count_map.get('attended',0)} حاضر · ❌ {count_map.get('no_show',0)} غایب · ⬜ {count_map.get('unmarked',0)} ثبت‌نشده",
             f"صفحه {page}/{page_count} · {total} نفر", "", "برای تغییر وضعیت، روی نام فرد بزنید:"]
    rows=[]
    for person in people:
        status=_status_value(person.attendance_status)
        lines.append(f"• {escape(person.full_name)} — {_status_label(status)}")
        next_status = {"unmarked":"attended", "attended":"no_show", "no_show":"unmarked"}[status]
        rows.append([InlineKeyboardButton(text=f"{person.full_name[:34]} · {_status_label(status)}", callback_data=f"admin:attendance:mark:{event_id}:{person.id}:{next_status}")])
    rows.append([
        InlineKeyboardButton(text="✅ همه حاضر", callback_data=f"admin:attendance:bulk:{event_id}:attended"),
        InlineKeyboardButton(text="❌ همه غایب", callback_data=f"admin:attendance:bulk:{event_id}:no_show"),
    ])
    rows.append([InlineKeyboardButton(text="⬜ پاک‌کردن همه", callback_data=f"admin:attendance:bulk:{event_id}:unmarked")])
    nav=[]
    if page>1: nav.append(InlineKeyboardButton(text="◀️ قبلی", callback_data=f"admin:attendance:roster:{event_id}:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"صفحه {page}/{page_count}", callback_data=f"admin:attendance:roster:{event_id}:{page}"))
    if page<page_count: nav.append(InlineKeyboardButton(text="بعدی ▶️", callback_data=f"admin:attendance:roster:{event_id}:{page+1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton(text="🕘 سابقهٔ اصلاح‌ها", callback_data=f"admin:attendance:history:{event_id}")])
    rows.append([InlineKeyboardButton(text="🔙 تنظیمات حضور", callback_data=f"admin:attendance:{event_id}")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:attendance:mark:\d+:\d+:(attended|no_show|unmarked)$"))
async def admin_mark_attendance(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts=(c.data or "").split(":")
    event_id, participant_id, new_status=int(parts[3]), int(parts[4]), parts[5]
    async with SessionLocal() as session:
        event=await session.get(Event,event_id,with_for_update=True)
        if not event or not event.attendance_enabled:
            return await c.answer("حضور و غیاب غیرفعال است.", show_alert=True)
        participant=(await session.execute(select(Participant).join(Booking)
            .where(Participant.id==participant_id,Booking.event_id==event_id,Booking.status==RegistrationStatus.CONFIRMED)
            .with_for_update().execution_options(populate_existing=True))).scalar_one_or_none()
        if not participant: return await c.answer("شرکت‌کنندهٔ تأییدشده پیدا نشد.",show_alert=True)
        old=_status_value(participant.attendance_status)
        if old == new_status:
            await session.rollback()
            return await _render_attendance_roster(c, event_id, 1)
        participant.attendance_status=AttendanceStatus(new_status)
        session.add(AttendanceAudit(event_id=event_id,participant_id=participant_id,actor_telegram_id=c.from_user.id,
            old_status=old,new_status=new_status,source="admin"))
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="attendance_corrected",entity_type="participant",entity_id=participant_id,
            details={"event_id":event_id,"old_status":old,"new_status":new_status})
        await session.commit()
    # Re-render the same page so the next action reflects the saved status.
    page = 1
    if c.message.reply_markup:
        for row in c.message.reply_markup.inline_keyboard:
            for button in row:
                if button.callback_data and button.callback_data.startswith("admin:attendance:roster:") and button.text.startswith("صفحه "):
                    try: page = int(button.callback_data.rsplit(":", 1)[1])
                    except ValueError: pass
    await _render_attendance_roster(c, event_id, page)


@router.callback_query(F.data.regexp(r"^admin:attendance:bulk:\d+:(attended|no_show|unmarked)$"))
async def attendance_bulk_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts=(c.data or "").split(":"); event_id=int(parts[3]); status=parts[4]
    label=_status_label(status)
    await c.message.edit_text(
        f"تأیید گروهی: وضعیت همهٔ شرکت‌کنندگان تأییدشدهٔ این پنل به «{label}» تغییر کند؟\n\nاین تغییر در سابقه ثبت می‌شود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأیید تغییر گروهی",callback_data=f"admin:attendance:bulk:confirm:{event_id}:{status}")],
            [InlineKeyboardButton(text="↩️ انصراف",callback_data=f"admin:attendance:roster:{event_id}:1")],
        ]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:attendance:bulk:confirm:\d+:(attended|no_show|unmarked)$"))
async def attendance_bulk_apply(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts=(c.data or "").split(":"); event_id=int(parts[4]); new_status=parts[5]
    async with SessionLocal() as session:
        event=await session.get(Event,event_id,with_for_update=True)
        if not event or not event.attendance_enabled:
            return await c.answer("حضور و غیاب غیرفعال است.",show_alert=True)
        people=(await session.execute(select(Participant).join(Booking)
            .where(Booking.event_id==event_id,Booking.status==RegistrationStatus.CONFIRMED)
            .with_for_update().execution_options(populate_existing=True))).scalars().all()
        for person in people:
            old=_status_value(person.attendance_status)
            if old != new_status:
                person.attendance_status=AttendanceStatus(new_status)
                session.add(AttendanceAudit(event_id=event_id,participant_id=person.id,actor_telegram_id=c.from_user.id,
                    old_status=old,new_status=new_status,source="admin_bulk"))
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="attendance_bulk_updated",entity_type="event",entity_id=event_id,
            details={"new_status":new_status,"participants":len(people)})
        await session.commit()
    await _render_attendance_roster(c, event_id, 1)


@router.callback_query(F.data.regexp(r"^admin:attendance:history:\d+$"))
async def attendance_history(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id=int((c.data or "").rsplit(":",1)[1])
    async with SessionLocal() as session:
        event=await session.get(Event,event_id)
        audits=(await session.execute(select(AttendanceAudit).where(AttendanceAudit.event_id==event_id)
            .order_by(AttendanceAudit.created_at.desc()).limit(30))).scalars().all()
    if not event: return await c.answer("پنل پیدا نشد.",show_alert=True)
    lines=[f"<b>سابقه حضور — {escape(volume_label(event.volume))} · {escape(event.title)}</b>"]
    if not audits: lines.append("هنوز تغییری ثبت نشده است.")
    for row in audits:
        lines.append(f"\n{row.created_at:%Y-%m-%d %H:%M} · شرکت‌کننده #{row.participant_id}\n{_status_label(row.old_status)} ← {_status_label(row.new_status)} · مدیر/روش: {row.actor_telegram_id} / {escape(row.source)}")
    await c.message.edit_text("\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 دفتر حضور",callback_data=f"admin:attendance:roster:{event_id}:1")],
        [InlineKeyboardButton(text="🔙 تنظیمات حضور",callback_data=f"admin:attendance:{event_id}")],
    ]))
    await c.answer()
