from __future__ import annotations

import os
import re
import uuid
import asyncio
from contextlib import suppress
from pathlib import Path
from aiogram import Bot
from sqlalchemy import select

from app.services.upload_quota import (
    cleanup_stale_upload_artifacts_unlocked, managed_upload_bytes, reservation_bytes, upload_quota_lock,
)

from app.config import settings
from app.bot.validation import is_valid_http_url
from app.db.models import User

def is_valid_url(value: str) -> bool:
    return is_valid_http_url(value)


def safe_pdf_filename(title: str) -> str:
    base = re.sub(r"[^A-Za-z0-9_-]+", "_", title)[:60].strip("_") or "event"
    return f"{base}_{uuid.uuid4().hex[:16]}.pdf"



def within_upload_limit(file_size: int | None) -> bool:
    """Unknown Telegram metadata is checked again against the downloaded bytes."""
    if file_size is None:
        return True
    return 0 <= int(file_size) <= settings.max_upload_mb * 1024 * 1024


async def _refresh_upload_reservation(reservation: Path, interval_seconds: int = 120) -> None:
    """Keep a live upload's quota lease fresh during slow network downloads."""
    while True:
        await asyncio.sleep(max(30, int(interval_seconds)))
        try:
            # utime does not recreate a reservation removed during final promotion.
            os.utime(reservation, None)
        except FileNotFoundError:
            return
        except OSError:
            # A temporary metadata failure should not cancel a useful upload;
            # a later refresh can recover if the file still exists.
            continue


async def download_file(bot: Bot, file_id: str, filename: str, *, file_size: int | None = None) -> str:
    """Download safely, reserving aggregate quota atomically across concurrent uploads.

    A reservation is held while the network download runs. The quota lock is
    released during I/O, so uploads are not serialized for their whole duration;
    the final capacity check + promotion are atomic with respect to other uploads.
    """
    import shutil
    root = Path(settings.upload_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("Upload storage is unavailable")
    ext = Path(filename).suffix.lower()
    if ext not in {".pdf", ".jpg", ".jpeg", ".png"}:
        ext = ".bin"
    quota = max(0, int(settings.max_upload_storage_mb)) * 1024 * 1024
    limit = max(1, int(settings.max_upload_mb)) * 1024 * 1024
    if file_size is not None and int(file_size) > limit:
        raise ValueError("Upload exceeds configured file limit")
    reserve_bytes = min(limit, max(0, int(file_size))) if file_size is not None else limit
    free_floor = max(0, int(settings.upload_min_free_mb)) * 1024 * 1024
    upload_id = uuid.uuid4().hex
    temp_name = f".upload-{upload_id}.part"
    final_name = f"{uuid.uuid4().hex}{ext}"
    temp_path = root / temp_name
    final_path = root / final_name
    reservation_dir = root / ".quota-reservations"
    reservation_dir.mkdir(mode=0o700, exist_ok=True)
    reservation = reservation_dir / f"{upload_id}.reserve"
    heartbeat_task = None
    if temp_path.parent.resolve() != root or final_path.parent.resolve() != root:
        raise ValueError("Unsafe upload destination")
    try:
        with upload_quota_lock(root):
            cleanup_stale_upload_artifacts_unlocked(root)
            used = managed_upload_bytes(root)
            reserved = reservation_bytes(root)
            if quota and used + reserved + reserve_bytes > quota:
                raise OSError("Upload storage quota reached")
            if shutil.disk_usage(root).free < free_floor + reserved + reserve_bytes:
                raise OSError("Upload storage is low")
            reservation.write_text(str(reserve_bytes), encoding="ascii")
        heartbeat_task = asyncio.create_task(_refresh_upload_reservation(reservation))
        await bot.download(file_id, destination=str(temp_path))
        if temp_path.is_symlink() or not temp_path.is_file():
            raise OSError("Upload did not produce a regular file")
        actual = temp_path.stat().st_size
        if actual > limit:
            raise ValueError("Upload exceeds configured file limit")
        with upload_quota_lock(root):
            cleanup_stale_upload_artifacts_unlocked(root)
            # A Telegram size estimate may be wrong. Recheck with real bytes under
            # the same lock used to claim reservations and publish completed files.
            used = managed_upload_bytes(root)
            reserved_other = reservation_bytes(root, exclude=reservation)
            if quota and used + reserved_other + actual > quota:
                raise OSError("Upload storage quota reached")
            if shutil.disk_usage(root).free < free_floor + reserved_other:
                raise OSError("Upload storage is low")
            if final_path.parent.resolve() != root:
                raise ValueError("Unsafe upload destination")
            os.replace(temp_path, final_path)
            reservation.unlink(missing_ok=True)
        return str(final_path)
    except BaseException:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        try:
            final_path.unlink(missing_ok=True)
        except OSError:
            pass
        try:
            reservation.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    finally:
        if heartbeat_task is not None:
            heartbeat_task.cancel()
            with suppress(asyncio.CancelledError):
                await heartbeat_task



def resolve_upload_path(stored_path: str) -> str | None:
    if not stored_path:
        return None
    upload_root = Path(settings.upload_dir).resolve()
    raw = Path(stored_path)
    candidates = [raw] if raw.is_absolute() else [upload_root / raw.name]
    # Legacy absolute paths are still supported, but relative filenames are constrained to upload_dir.
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
            if resolved.exists() and (resolved == candidate.resolve() if candidate.is_absolute() else upload_root in resolved.parents):
                return str(resolved)
        except OSError:
            continue
    return None


async def all_bot_users(session) -> list[User]:
    result = await session.execute(select(User).order_by(User.id))
    return list(result.scalars().all())
