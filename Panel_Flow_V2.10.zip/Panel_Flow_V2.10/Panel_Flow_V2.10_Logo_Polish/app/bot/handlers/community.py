from __future__ import annotations

from datetime import datetime, timedelta
from html import escape
import asyncio
import hashlib
import logging
import re

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, CopyTextButton, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import case, delete, func, select, update
from sqlalchemy.exc import IntegrityError

from app.bot.keyboards import admin_community_menu, community_menu_keyboard, main_menu, back_menu
from app.bot.states import CommunityAdminStates, CommunityStates, ProfileStates
from app.bot.text_limits import limit_telegram_html
from app.config import settings
from app.db.models import (
    AchievementUnlock, ChallengeResultNotification, ChallengeSubmission, CommunityChallenge, CommunityProfile,
    Event, Question, ShopRequest, User, WrappedReport, XPAward,
)
from app.db.session import SessionLocal
from app.time_utils import tehran_now
from app.services.app_settings import get_setting, set_setting
from app.services.xp_shop import shop_is_enabled, set_shop_enabled, reserved_shop_xp, available_shop_xp
from app.services.excel_export import build_leaderboard_workbook
from app.services.community import (
    CHALLENGE_MILESTONES, PANEL_MILESTONES, STREAK_MILESTONES, XP_DEFAULTS,
    award_once, get_or_create_profile, leaderboard_enabled, leaderboard_opted_in,
    admin_leaderboard_rows, leaderboard_rows, public_leaderboard_position, make_wrapped_text, paid_panel_count, record_user_onboarding,
    set_leaderboard_enabled, set_leaderboard_opt_in, total_xp, unlock_eligible_achievements,
    user_community_stats, xp_value, xp_earning_enabled, set_xp_earning_enabled,
)
from app.time_utils import utc_now_naive
from app.display_utils import admin_status_display_label, status_display_label, rtl_isolate, ltr_isolate
from app.services.user_access import has_active_feature_restriction

router = Router()
logger = logging.getLogger(__name__)
MAX_CHALLENGE_ANSWER = 1000
MAX_CHALLENGE_PROMPT = 2600
MAX_CHALLENGE_REFERENCE = 1000


async def _is_admin(telegram_id: int) -> bool:
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(telegram_id)


def _back_to_community() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏆 لیدربورد و چالش‌ها", callback_data="community:home")],
        [InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")],
    ])


async def _show_pending_achievement_popup(c: CallbackQuery) -> bool:
    """Show queued achievements as one Telegram alert, without adding chat messages."""
    async with SessionLocal() as session:
        pending = (await session.execute(select(AchievementUnlock).where(
            AchievementUnlock.telegram_id == int(c.from_user.id),
            AchievementUnlock.celebrated_at.is_(None),
        ).order_by(AchievementUnlock.unlocked_at, AchievementUnlock.id))).scalars().all()
        if not pending:
            return False
        # Achievement records, not titles, are the unit of acknowledgement. Identical
        # titles may belong to distinct records and must not acknowledge hidden rows.
        visible = pending[:4]
        visible_ids = [int(row.id) for row in visible]
        remainder = len(pending) - len(visible)
        message = "🏆 نشان جدید دریافت کردید!\n" + "\n".join(
            f"• {str(row.title or 'نشان جدید')[:30]}" for row in visible
        )
        if remainder:
            message += f"\nو {remainder} نشان دیگر"
        # Build a safe final alert length without cutting a rendered title in half.
        while len(message) > 195 and visible:
            visible.pop()
            visible_ids.pop()
            remainder = len(pending) - len(visible)
            message = "🏆 نشان جدید دریافت کردید!\n" + "\n".join(
                f"• {str(row.title or 'نشان جدید')[:24]}" for row in visible
            )
            if remainder:
                message += f"\nو {remainder} نشان دیگر"
        if not visible:
            return False
        pending_ids = visible_ids
    # Answer before marking these as shown; on an expired callback the unlocks remain queued.
    try:
        await c.answer(message, show_alert=True)
    except Exception:
        logger.debug("Could not display achievement popup for user_id=%s", c.from_user.id, exc_info=True)
        return False
    # Mark only the achievements actually included in this popup. A concurrent unlock
    # arriving after the first query must remain queued for the next user interaction.
    async with SessionLocal() as session:
        rows = (await session.execute(select(AchievementUnlock).where(
            AchievementUnlock.id.in_(pending_ids),
            AchievementUnlock.telegram_id == int(c.from_user.id),
            AchievementUnlock.celebrated_at.is_(None),
        ))).scalars().all()
        for row in rows:
            row.celebrated_at = utc_now_naive()
        await session.commit()
    return True


async def _challenge_by_id(session, challenge_id: int):
    if challenge_id <= 0:
        return None
    return await session.get(CommunityChallenge, challenge_id)


async def _challenge_copy_button(bot, challenge_id: int, label: str = "📋 کپی لینک چالش"):
    """Build a link only for a currently public challenge lifecycle state."""
    async with SessionLocal() as session:
        challenge = await _challenge_by_id(session, int(challenge_id))
        if not challenge or challenge.status not in {"open", "closed", "published"} or not challenge.prompt:
            return None
    try:
        me = await bot.get_me()
    except Exception:
        logger.warning("Could not resolve bot identity for challenge link; challenge_id=%s", challenge_id, exc_info=True)
        return None
    if not me.username:
        return None
    url = f"https://t.me/{me.username}?start=challenge_{int(challenge_id)}"
    return InlineKeyboardButton(text=label, copy_text=CopyTextButton(text=url))


async def _challenge_created_keyboard(bot, challenge_id: int) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="مدیریت چالش‌ها", callback_data="admin:community:challenges")]]
    copy_button = await _challenge_copy_button(bot, challenge_id)
    if copy_button:
        rows.append([copy_button])
    else:
        rows.append([InlineKeyboardButton(text="دریافت لینک چالش", callback_data=f"admin:community:challenge:link:{challenge_id}")])
    rows.append([InlineKeyboardButton(text="مدیریت چالش‌ها", callback_data="admin:community")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def show_challenge_from_message(message: Message, state: FSMContext, challenge_id: int, *, telegram_user=None) -> None:
    """Deep-link entry point; preserves the visitor identity after button-based onboarding."""
    identity = telegram_user or message.from_user
    identity_id = int(identity.id)
    async with SessionLocal() as session:
        user = (await session.execute(select(User).where(User.telegram_id == identity_id))).scalar_one_or_none()
        challenge = await _challenge_by_id(session, challenge_id)
        # Validate the destination before prompting an unregistered visitor for personal data.
        if challenge is None or challenge.status not in {"open", "closed", "published"} or not challenge.prompt:
            return await message.answer("این چالش دیگر در دسترس نیست.", reply_markup=_back_to_community())
        if not user or not user.first_name or not user.last_name or not user.phone_number:
            await state.clear()
            await state.update_data(pending_start_payload=f"challenge_{challenge_id}")
            if not user or not user.first_name or not user.last_name:
                await state.set_state(ProfileStates.waiting_full_name)
                from app.bot.content import onboarding_full_name_prompt, phone_number_prompt
                return await message.answer(onboarding_full_name_prompt())
            await state.set_state(ProfileStates.waiting_phone)
            return await message.answer(phone_number_prompt())
        submission = (await session.execute(select(ChallengeSubmission).where(
            ChallengeSubmission.challenge_id == challenge_id,
            ChallengeSubmission.telegram_id == identity_id,
        ))).scalar_one_or_none()
        body = f"🧠 <b>{escape(challenge.title or 'چالش')}</b>\n\n{escape(challenge.prompt)}\n\n"
        rows = []
        if challenge.status == "open":
            if submission:
                body += "✅ پاسخ شما قبلاً ثبت شده است و قابل ویرایش نیست."
            else:
                body += f"یک پاسخ خصوصی ارسال کنید. حداکثر {MAX_CHALLENGE_ANSWER} کاراکتر؛ پاسخ فقط یک‌بار ثبت می‌شود."
                rows.append([InlineKeyboardButton(text="✍️ ارسال پاسخ", callback_data=f"community:challenge:submit:{challenge_id}")])
        elif challenge.status == "closed":
            body += "🔒 این چالش بسته شده و دیگر پاسخ جدید نمی‌پذیرد.\n"
            body += "پاسخ شما در انتظار بررسی مدیر است؛ پس از پایان بررسی می‌توانید نتیجه را همین‌جا ببینید." if submission else "نتیجه پس از پایان بررسی مدیر نمایش داده می‌شود."
        elif challenge.status == "published":
            body += "✅ نتایج منتشر شده‌اند.\n"
            if submission:
                if challenge.challenge_type == "knowledge":
                    result = "درست" if submission.judging_status == "correct" else "نادرست"
                    body += f"وضعیت پاسخ شما: <b>{result}</b>. مشارکت شما ثبت شده است."
                else:
                    body += f"وضعیت پاسخ شما: <b>{'رتبه ' + str(submission.selected_place) if submission.selected_place else 'شرکت‌کننده'}</b>."
            else:
                body += "برای این چالش پاسخی از حساب شما ثبت نشده است."
            if challenge.challenge_type == "knowledge" and challenge.reference_answer:
                body += f"\n\n<b>پاسخ مرجع</b>\n{escape(challenge.reference_answer)}"
            if challenge.challenge_type == "creative":
                winners = (await session.execute(select(ChallengeSubmission, User).outerjoin(
                    User, User.telegram_id == ChallengeSubmission.telegram_id
                ).where(ChallengeSubmission.challenge_id == challenge_id,
                        ChallengeSubmission.selected_place.is_not(None)).order_by(ChallengeSubmission.selected_place))).all()
                if winners:
                    body += "\n\n<b>🏅 برگزیدگان</b>"
                    for winner, winner_user in winners:
                        full_name = " ".join(x for x in ((winner_user.first_name if winner_user else None), (winner_user.last_name if winner_user else None)) if x)
                        body += f"\n{['🥇','🥈','🥉'][max(0, min(2, int(winner.selected_place or 1)-1))]} {escape(full_name or 'شرکت‌کننده')}"
        rows += [
            [InlineKeyboardButton(text="🪪 پاسپورت من", callback_data="community:passport")],
            [InlineKeyboardButton(text="🔙 چالش‌ها", callback_data="community:challenges")],
        ]
    await message.answer(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)


async def render_community_home(target: Message | CallbackQuery):
    text = (
        rtl_isolate("🏆 <b>لیدربورد و چالش‌ها</b>") + "\n\n"
        + rtl_isolate("لیدربورد " + ltr_isolate("Panel Flow") + "، چالش‌ها، " + ltr_isolate("XP") + " شاپ، " + ltr_isolate("Giveaways") + " و پاسپورت خود را از این بخش دنبال کنید.")
    )
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=community_menu_keyboard())
    else:
        await target.answer(text, reply_markup=community_menu_keyboard())


@router.callback_query(F.data == "community:home")
async def community_home(c: CallbackQuery):
    await render_community_home(c)
    if not await _show_pending_achievement_popup(c):
        await c.answer()


@router.callback_query(F.data == "community:leaderboard")
async def community_leaderboard(c: CallbackQuery):
    async with SessionLocal() as session:
        # Enforced here, not just in the menu; all public rank data stays behind this gate.
        if not await leaderboard_enabled(session):
            await c.message.edit_text(
                rtl_isolate("🏆 لیدربورد " + ltr_isolate("Panel Flow") + " فعلاً غیرفعال است."),
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")
                ]]),
            )
            return await c.answer()
        rows = await leaderboard_rows(session, 10)
        opted_in = await leaderboard_opted_in(session, c.from_user.id)
        # A privacy opt-out masks the name, but never removes the user's rank slot.
        personal_position = await public_leaderboard_position(session, c.from_user.id)
    if not rows:
        text = rtl_isolate("🏆 <b>لیدربورد " + ltr_isolate("Panel Flow") + "</b>") + "\n\nهنوز اطلاعاتی برای نمایش در لیدربورد وجود ندارد."
    else:
        sections = []
        for index, row in enumerate(rows, start=1):
            medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(index, f"{index}.")
            # Only escaped plain names; never a profile link, username, or numeric identifier.
            sections.append(rtl_isolate(f"{medal} <b>{escape(row['name'])}</b>\nشرکت در {row['panels']} پنل · {row['xp']} " + ltr_isolate("XP")))
        text = rtl_isolate("🏆 <b>لیدربورد " + ltr_isolate("Panel Flow") + " · ۱۰ نفر برتر</b>") + "\n\n" + "\n\n".join(sections)
        text += "\n\n" + rtl_isolate("رتبه ابتدا بر اساس تعداد پنل‌های شرکت‌شده و در صورت برابری بر اساس " + ltr_isolate("XP") + " تعیین می‌شود.")
    if personal_position and not opted_in:
        text += (
            f"\n\n🙈 جایگاه شما حفظ شده است: <b>{personal_position['position']} از "
            f"{personal_position['total']}</b>. نام شما برای دیگر کاربران به‌صورت <code>••••••••</code> نمایش داده می‌شود."
        )
    elif personal_position:
        text += f"\n\n📍 جایگاه فعلی شما: <b>{personal_position['position']} از {personal_position['total']}</b> شرکت‌کننده."
    elif not opted_in:
        text += "\n\n🙈 نام شما در لیدربورد پنهان است؛ جایگاهتان با ثبت مشارکت یا XP محاسبه می‌شود."
    else:
        text += "\n\n📍 جایگاه شما فعلاً قابل محاسبه نیست؛ برای ورود به لیدربورد باید مشارکت یا XP ثبت‌شده داشته باشید."
    privacy_label = "🙈 پنهان‌کردن نام من" if opted_in else "👁 نمایش نام من"
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=privacy_label, callback_data="community:leaderboard:privacy")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")],
    ])
    await c.message.edit_text(text, reply_markup=keyboard)
    await c.answer()


@router.callback_query(F.data == "community:leaderboard:privacy")
async def leaderboard_privacy(c: CallbackQuery):
    async with SessionLocal() as session:
        current = await leaderboard_opted_in(session, c.from_user.id)
        await set_leaderboard_opt_in(session, c.from_user.id, not current)
        await session.commit()
    # Re-enter the real handler so the global disable gate applies after changing preference.
    return await community_leaderboard(c)


@router.callback_query(F.data == "community:passport")
async def community_passport(c: CallbackQuery):
    async with SessionLocal() as session:
        stats = await user_community_stats(session, c.from_user.id)
        await unlock_eligible_achievements(session, c.from_user.id)
        await session.commit()
        # Refresh badges after recording any newly eligible unlocks.
        badges = (await session.execute(select(AchievementUnlock).where(
            AchievementUnlock.telegram_id == c.from_user.id
        ).order_by(AchievementUnlock.unlocked_at))).scalars().all()
        recent_submissions = (await session.execute(
            select(ChallengeSubmission, CommunityChallenge)
            .join(CommunityChallenge, CommunityChallenge.id == ChallengeSubmission.challenge_id)
            .where(ChallengeSubmission.telegram_id == c.from_user.id)
            .order_by(ChallengeSubmission.submitted_at.desc(), ChallengeSubmission.id.desc())
            .limit(5)
        )).all()
    next_panel = next((n for n, _, _ in PANEL_MILESTONES if stats['attended_panels'] < n), None)
    next_challenge = next((n for n, _, _ in CHALLENGE_MILESTONES if stats['challenge_participations'] < n), None)
    next_streak = next((n for n, _, _ in STREAK_MILESTONES if stats['best_streak'] < n), None)
    title = "عضو جامعه"
    if stats["attended_panels"] >= 60:
        title = "پیشکسوت جامعه"
    elif stats["attended_panels"] >= 5:
        title = "عضو فعال"
    elif stats["attended_panels"] >= 1:
        title = "تازه‌وارد"
    body = (
        f"🪪 <b>پاسپورت من · {title}</b>\n\n"
        f"✨ مجموع XP: <b>{stats['xp']}</b>\n"
        f"🎟 تعداد پنل‌های شرکت‌شده: <b>{stats['attended_panels']}</b>\n"
        f"🤝 دوستان معرفی‌شده: <b>{stats['referrals']}</b>\n"
        f"🧠 تعداد مشارکت در چالش‌ها: <b>{stats['challenge_participations']}</b>\n"
        f"✅ پاسخ‌های دانشی درست: <b>{stats['correct_answers']}</b>\n"
        f"🥇/🥈/🥉 رتبه‌های خلاقانه: <b>{stats['creative_first']}/{stats['creative_second']}/{stats['creative_third']}</b>\n"
        f"📝 نظرها: <b>{stats['reviews']}</b> · 🤝 مشارکت‌های تقدیرشده: <b>{stats['recognized']}</b>\n"
        f"🔥 پیوستگی فعلی/بهترین پیوستگی: <b>{stats['current_streak']}/{stats['best_streak']}</b>\n\n"
        f"🎯 هدف بعدی پنل: {next_panel if next_panel else 'همهٔ هدف‌های پنل باز شده‌اند'}\n\n"
        f"🎯 هدف بعدی چالش: {next_challenge if next_challenge else 'همهٔ هدف‌های چالش باز شده‌اند'}\n\n"
        f"🎯 هدف بعدی پیوستگی: {next_streak if next_streak else 'همهٔ هدف‌های پیوستگی باز شده‌اند'}\n\n"
        "رتبهٔ عمومی ابتدا بر اساس تعداد پنل‌های شرکت‌شده و در صورت برابری بر اساس XP تعیین می‌شود."
    )
    if recent_submissions:
        body += "\n\n<b>آخرین چالش‌ها</b>"
        for submission, challenge in recent_submissions:
            challenge_title = (challenge.title or "چالش پیشین").strip()
            if challenge.status == "published":
                if submission.selected_place is not None:
                    result_label = f"رتبهٔ {int(submission.selected_place)}"
                elif submission.judging_status == "correct":
                    result_label = "پاسخ درست"
                elif submission.judging_status == "incorrect":
                    result_label = "پاسخ نادرست"
                else:
                    result_label = "نتیجه نهایی شده"
            elif challenge.status == "closed":
                result_label = "در انتظار نتیجه"
            elif challenge.status == "open":
                result_label = "ارسال شده"
            else:
                result_label = "سابقه ثبت شده"
            body += f"\n• {escape(challenge_title[:70])} — {escape(result_label)}"
    if badges:
        body += "\n\n<b>نشان‌های دریافت‌شده</b>\n" + "\n".join(f"🏅 {escape(row.title)}" for row in badges)
    else:
        body += "\n\nاولین نشان شما منتظر دریافت است!"
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✨ تاریخچهٔ امتیازهای من", callback_data="community:passport:xp:0")],
        [InlineKeyboardButton(text="🎉 گزارش سالانه (Wrapped)", callback_data="community:wrapped")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")],
    ]))
    if not await _show_pending_achievement_popup(c):
        await c.answer()


_XP_AWARD_LABELS = {
    "paid_panel": "مشارکت مالی در پنل", "paid_panel_reversal": "اصلاح امتیاز پنل",
    "challenge_participation": "مشارکت در چالش", "knowledge_correct": "پاسخ درست در چالش",
    "creative_first": "رتبهٔ اول چالش خلاقانه", "creative_second": "رتبهٔ دوم چالش خلاقانه",
    "creative_third": "رتبهٔ سوم چالش خلاقانه", "archived_review": "ثبت نظر برای پنل گذشته",
    "recognized_contribution": "مشارکت ارزشمند", "external_competition": "برندهٔ رقابت بیرونی",
    "shop_redemption": "خرید پاداش از XP شاپ", "shop_redemption_refund": "بازپرداخت XP شاپ",
    "admin_manual_adjustment": "اصلاح دستی مدیریت",
}


@router.callback_query(F.data.regexp(r"^community:passport:xp:\d+$"))
async def community_xp_history(c: CallbackQuery):
    try:
        requested_page = max(0, int(c.data.rsplit(":", 1)[1]))
    except (TypeError, ValueError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    page_size = 8
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(XPAward.id)).where(XPAward.telegram_id == int(c.from_user.id))) or 0)
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(requested_page, pages - 1)
        awards = (await session.execute(select(XPAward).where(
            XPAward.telegram_id == int(c.from_user.id)
        ).order_by(XPAward.created_at.desc(), XPAward.id.desc()).offset(page * page_size).limit(page_size))).scalars().all()
        balance = await total_xp(session, c.from_user.id)
        reserved = await reserved_shop_xp(session, c.from_user.id)
    available = available_shop_xp(balance, reserved)
    lines = ["<b>✨ تاریخچهٔ امتیازهای من</b>",
             f"موجودی فعلی: <b>{balance} XP</b> · رزروشده: <b>{reserved} XP</b> · قابل استفاده: <b>{available} XP</b>", ""]
    if awards:
        for item in awards:
            title = _XP_AWARD_LABELS.get(str(item.award_type), str(item.note or item.award_type))
            date_label = item.created_at.strftime("%Y-%m-%d %H:%M") if item.created_at else "تاریخ نامشخص"
            lines.append(f"<b>{int(item.points):+d} XP</b> · {escape(title)}\n{escape(date_label)}")
    else:
        lines.append("هنوز تراکنشی برای نمایش ثبت نشده است.")
    lines.append("\nامتیازهای رزروشده در درخواست‌های در انتظار هنوز از دفترکل کسر نشده‌اند و در این فهرست تراکنش محسوب نمی‌شوند.")
    rows = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"community:passport:xp:{page-1}"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"community:passport:xp:{page+1}"))
    if nav:
        rows.append(nav)
    rows += [[InlineKeyboardButton(text="🪪 بازگشت به پاسپورت", callback_data="community:passport")],
             [InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")]]
    await c.message.edit_text("\n\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


async def _render_user_challenges(target, page: int = 0):
    page_size = 10
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(CommunityChallenge.id)).where(
            CommunityChallenge.status.in_(("open", "closed", "published")),
            CommunityChallenge.prompt.is_not(None),
        )) or 0)
        page_count = max(1, (total + page_size - 1) // page_size)
        page = min(max(0, int(page)), page_count - 1)
        challenges = (await session.execute(select(CommunityChallenge).where(
            CommunityChallenge.status.in_(("open", "closed", "published")),
            CommunityChallenge.prompt.is_not(None),
        ).order_by(CommunityChallenge.created_at.desc(), CommunityChallenge.id.desc())
          .offset(page * page_size).limit(page_size))).scalars().all()
    rows = []
    for challenge in challenges:
        state_label = {"open": "🟢 فعال", "closed": "🔒 بسته", "published": "✅ نتایج"}.get(challenge.status, status_display_label(challenge.status))
        rows.append([InlineKeyboardButton(text=f"{state_label} · {(challenge.title or 'چالش')[:32]}",
                                          callback_data=f"community:challenge:view:{challenge.id}")])
    if total == 0:
        body = "🧠 <b>چالش‌ها</b>\n\nدر حال حاضر چالش فعالی برای نمایش وجود ندارد."
    else:
        body = f"🧠 <b>چالش‌ها</b> · صفحهٔ {page + 1}/{page_count}\nبرای مشاهدهٔ وضعیت یا نتیجهٔ خود، یک چالش را انتخاب کنید."
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"community:challenges:page:{page-1}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"community:challenges:page:{page+1}"))
    if nav:
        rows.append(nav)
    rows += [[InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")]]
    await target.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data == "community:challenges")
async def community_challenges(c: CallbackQuery, state: FSMContext):
    # This button is also the Cancel destination shown during answer entry.
    # Clear only this flow, never an unrelated registration/profile FSM.
    active_state = await state.get_state()
    if active_state in {
        CommunityStates.waiting_challenge_answer.state,
        CommunityStates.confirming_challenge_answer.state,
    }:
        await state.clear()
    elif active_state:
        return await c.answer("یک فرایند ناتمام دارید. ابتدا آن را ادامه دهید یا /cancel را بزنید.", show_alert=True)
    await c.message.edit_text(
        "🧠 <b>چالش‌های رسمی</b>\n\nچالش‌ها بر اساس وضعیت واقعی مشارکت شما دسته‌بندی شده‌اند.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🟢 آمادهٔ شرکت", callback_data="community:challenges:category:available:0")],
            [InlineKeyboardButton(text="⏳ در انتظار اعلام نتایج", callback_data="community:challenges:category:awaiting:0")],
            [InlineKeyboardButton(text="✅ پایان‌یافته", callback_data="community:challenges:category:completed:0")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^community:challenges:category:(available|awaiting|completed):\d+$"))
async def community_challenges_category(c: CallbackQuery, state: FSMContext):
    active_state = await state.get_state()
    if active_state in {
        CommunityStates.waiting_challenge_answer.state,
        CommunityStates.confirming_challenge_answer.state,
    }:
        await state.clear()
    elif active_state:
        return await c.answer("یک فرایند ناتمام دارید. ابتدا آن را ادامه دهید یا /cancel را بزنید.", show_alert=True)
    parts = c.data.split(":")
    category = parts[3]
    try: page = max(0, int(parts[4]))
    except (ValueError, IndexError): return await c.answer("صفحه نامعتبر است.", show_alert=True)
    telegram_id = int(c.from_user.id)
    page_size = 8
    async with SessionLocal() as session:
        if category == "available":
            # Restrictions are part of eligibility, not just a rejection at submit time.
            if await has_active_feature_restriction(session, telegram_id, "challenges"):
                query = select(CommunityChallenge).where(CommunityChallenge.id == -1)
            else:
                submitted = select(ChallengeSubmission.challenge_id).where(ChallengeSubmission.telegram_id == telegram_id)
                query = select(CommunityChallenge).where(
                    CommunityChallenge.status == "open", CommunityChallenge.prompt.is_not(None),
                    CommunityChallenge.id.not_in(submitted),
                )
        else:
            query = select(CommunityChallenge).join(
                ChallengeSubmission, ChallengeSubmission.challenge_id == CommunityChallenge.id
            ).where(
                ChallengeSubmission.telegram_id == telegram_id,
                CommunityChallenge.prompt.is_not(None),
                CommunityChallenge.status.in_(("open", "closed") if category == "awaiting" else ("published",)),
            )
        total = int(await session.scalar(select(func.count()).select_from(query.order_by(None).subquery())) or 0)
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(page, pages - 1)
        challenges = (await session.execute(query.order_by(CommunityChallenge.created_at.desc(), CommunityChallenge.id.desc())
              .offset(page * page_size).limit(page_size))).scalars().unique().all()
    labels = {"available": "آمادهٔ شرکت", "awaiting": "در انتظار اعلام نتایج", "completed": "پایان‌یافته"}
    rows = []
    for ch in challenges:
        kind = "🧠 دانشی" if ch.challenge_type == "knowledge" else "🎨 خلاقانه"
        rows.append([InlineKeyboardButton(text=f"{kind} · {(ch.title or 'چالش')[:28]}", callback_data=f"community:challenge:view:{ch.id}")])
    nav=[]
    if page > 0: nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"community:challenges:category:{category}:{page-1}"))
    if page + 1 < pages: nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"community:challenges:category:{category}:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 دسته‌بندی چالش‌ها", callback_data="community:challenges")])
    rows.append([InlineKeyboardButton(text="🏠 منوی اصلی", callback_data="user:home")])
    body = f"<b>{labels[category]}</b> · {total} چالش"
    if total: body += f"\nصفحهٔ {page+1} از {pages}. برای دیدن پرسش و وضعیت ثبت‌شده، یک چالش را انتخاب کنید."
    else: body += "\n\nدر این دسته‌بندی چالشی برای نمایش وجود ندارد."
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^community:challenges:page:\d+$"))
async def community_challenges_page(c: CallbackQuery, state: FSMContext):
    active_state = await state.get_state()
    if active_state in {
        CommunityStates.waiting_challenge_answer.state,
        CommunityStates.confirming_challenge_answer.state,
    }:
        await state.clear()
    elif active_state:
        return await c.answer("یک فرایند ناتمام دارید. ابتدا آن را ادامه دهید یا /cancel را بزنید.", show_alert=True)
    try:
        page = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await _render_user_challenges(c.message, page)
    await c.answer()


@router.callback_query(F.data.startswith("community:challenge:view:"))
async def challenge_view_callback(c: CallbackQuery):
    try:
        challenge_id = int(c.data.rsplit(":", 1)[1])
        if challenge_id <= 0:
            raise ValueError
    except ValueError:
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        challenge = await _challenge_by_id(session, challenge_id)
        if not challenge or challenge.status not in {"open", "closed", "published"} or not challenge.prompt:
            return await c.answer("این چالش دیگر در دسترس نیست.", show_alert=True)
        submission = (await session.execute(select(ChallengeSubmission).where(
            ChallengeSubmission.challenge_id == challenge_id, ChallengeSubmission.telegram_id == c.from_user.id
        ))).scalar_one_or_none()
        text = f"🧠 <b>{escape(challenge.title or 'چالش')}</b>\n\n{escape(challenge.prompt)}\n\n"
        rows = []
        if challenge.status == "open":
            if submission:
                text += "✅ پاسخ شما قبلاً ثبت شده است و قابل ویرایش نیست."
            else:
                text += f"یک پاسخ خصوصی ارسال کنید. حداکثر {MAX_CHALLENGE_ANSWER} کاراکتر."
                rows.append([InlineKeyboardButton(text="✍️ ارسال پاسخ", callback_data=f"community:challenge:submit:{challenge_id}")])
        elif challenge.status == "closed":
            text += "🔒 این چالش بسته شده و پاسخ جدید نمی‌پذیرد.\n"
            text += "پاسخ شما در انتظار بررسی مدیر است؛ پس از پایان بررسی دوباره همین‌جا نتیجه را ببینید." if submission else "نتیجه پس از پایان بررسی مدیر نمایش داده می‌شود."
        elif challenge.status == "published":
            text += "✅ نتایج منتشر شده‌اند.\n"
            if submission:
                if challenge.challenge_type == "knowledge":
                    text += f"پاسخ شما: <b>{'درست' if submission.judging_status == 'correct' else 'نادرست'}</b>."
                else:
                    text += f"نتیجهٔ شما: <b>{'رتبهٔ ' + str(submission.selected_place) if submission.selected_place else 'شرکت‌کننده'}</b>."
            else:
                text += "شما پاسخی برای این چالش ثبت نکرده‌اید."
            if challenge.challenge_type == "knowledge" and challenge.reference_answer:
                text += f"\n\n<b>پاسخ مرجع</b>\n{escape(challenge.reference_answer)}"
            if challenge.challenge_type == "creative":
                winners = (await session.execute(select(ChallengeSubmission, User).outerjoin(
                    User, User.telegram_id == ChallengeSubmission.telegram_id
                ).where(ChallengeSubmission.challenge_id == challenge_id,
                        ChallengeSubmission.selected_place.is_not(None)).order_by(ChallengeSubmission.selected_place))).all()
                if winners:
                    text += "\n\n<b>🏅 برگزیدگان</b>"
                    for sub, user in winners:
                        name = " ".join(x for x in ((user.first_name if user else None), (user.last_name if user else None)) if x)
                        text += f"\n{['🥇','🥈','🥉'][max(0, min(2, int(sub.selected_place or 1)-1))]} {escape(name or 'شرکت‌کننده')}"
        else:
            return await c.answer("این چالش در حال حاضر قابل نمایش نیست.", show_alert=True)
        rows.append([InlineKeyboardButton(text="🔙 چالش‌ها", callback_data="community:challenges")])
    await c.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^community:challenge:submit:\d+$"))
async def challenge_submit_start(c: CallbackQuery, state: FSMContext):
    if await state.get_state():
        return await c.answer("یک فرایند ناتمام دارید. ابتدا آن را ادامه دهید یا /cancel را بزنید.", show_alert=True)
    try:
        challenge_id = int(c.data.rsplit(":", 1)[1])
        if challenge_id <= 0:
            raise ValueError
    except ValueError:
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        if await has_active_feature_restriction(session, int(c.from_user.id), "challenges"):
            return await c.answer("مشارکت در چالش‌ها برای حساب شما به‌طور موقت محدود شده است.", show_alert=True)
        challenge = await _challenge_by_id(session, challenge_id)
        if not challenge or challenge.status != "open" or not challenge.prompt:
            return await c.answer("این چالش در حال حاضر پاسخ جدید نمی‌پذیرد.", show_alert=True)
        existing = (await session.execute(select(ChallengeSubmission.id).where(
            ChallengeSubmission.challenge_id == challenge_id,
            ChallengeSubmission.telegram_id == c.from_user.id,
        ))).scalar_one_or_none()
        if existing:
            return await c.answer("شما قبلاً پاسخ خود را ثبت کرده‌اید.", show_alert=True)
    await state.update_data(active_challenge_id=challenge_id)
    await state.set_state(CommunityStates.waiting_challenge_answer)
    try:
        await c.message.edit_text(f"✍️ پاسخ خود را در یک پیام ارسال کنید. پاسخ خصوصی است، قابل ویرایش نیست و حداکثر {MAX_CHALLENGE_ANSWER} کاراکتر می‌تواند باشد.",
                                  reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                                      InlineKeyboardButton(text="❌ انصراف", callback_data="community:challenges")
                                  ]]))
    except Exception:
        # Keep the cancel path available when Telegram won't edit the source message.
        await c.message.answer(
            f"✍️ پاسخ خود را در یک پیام ارسال کنید. پاسخ خصوصی است، قابل ویرایش نیست و حداکثر {MAX_CHALLENGE_ANSWER} کاراکتر می‌تواند باشد.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="❌ انصراف", callback_data="community:challenges")
            ]]),
        )
    await c.answer()


@router.message(CommunityStates.waiting_challenge_answer, F.text, ~F.text.startswith("/"))
async def challenge_submit_answer(message: Message, state: FSMContext):
    """Validate and preview a private challenge answer without committing it yet."""
    answer = (message.text or "").strip()
    if not answer:
        return await message.answer("لطفاً پاسخ خود را بنویسید.")
    if len(answer) > MAX_CHALLENGE_ANSWER:
        return await message.answer(f"پاسخ شما بیش از حد طولانی است. حداکثر طول مجاز {MAX_CHALLENGE_ANSWER} کاراکتر است.")
    if answer.startswith("/") or re.match(r"^/(start|admin|cancel)(?:@\w+)?(?:\s|$)", answer, re.I):
        return await message.answer("دستورهای ربات به‌عنوان پاسخ پذیرفته نمی‌شوند. پاسخ را به‌صورت متن معمولی ارسال کنید.")
    data = await state.get_data()
    try:
        challenge_id = int(data.get("active_challenge_id", 0))
    except (TypeError, ValueError):
        challenge_id = 0
    async with SessionLocal() as session:
        if await has_active_feature_restriction(session, int(message.from_user.id), "challenges"):
            await state.clear()
            return await message.answer("مشارکت در چالش‌ها برای حساب شما به‌طور موقت محدود شده است.", reply_markup=_back_to_community())
        challenge = await session.get(CommunityChallenge, challenge_id)
        if not challenge or challenge.status != "open" or not challenge.prompt:
            await state.clear()
            return await message.answer("این چالش بسته شده یا در دسترس نیست.", reply_markup=_back_to_community())
        existing = (await session.execute(select(ChallengeSubmission.id).where(
            ChallengeSubmission.challenge_id == challenge_id,
            ChallengeSubmission.telegram_id == message.from_user.id,
        ))).scalar_one_or_none()
        if existing:
            await state.clear()
            return await message.answer("پاسخ شما قبلاً ثبت شده است و قابل ویرایش نیست.", reply_markup=_back_to_community())
        title = challenge.title or "چالش"
    await state.update_data(pending_challenge_answer=answer, active_challenge_id=challenge_id)
    await state.set_state(CommunityStates.confirming_challenge_answer)
    preview = (
        f"<b>پیش‌نمایش پاسخ · {escape(title)}</b>\n\n{escape(answer)}\n\n"
        "پاسخ فقط برای مدیرانِ بررسی‌کننده نمایش داده می‌شود. پس از تأیید قابل ویرایش نیست."
    )
    await message.answer(limit_telegram_html(preview), reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ ثبت نهایی پاسخ", callback_data="community:challenge:submit:confirm")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data="community:challenges")],
    ]))


@router.callback_query(F.data == "community:challenge:submit:confirm")
async def challenge_submit_confirm(c: CallbackQuery, state: FSMContext):
    """Commit the confirmed answer under a challenge row lock, preserving award idempotency."""
    if await state.get_state() != CommunityStates.confirming_challenge_answer.state:
        return await c.answer("پیش‌نمایش پاسخ منقضی شده است؛ دوباره از صفحهٔ چالش اقدام کنید.", show_alert=True)
    data = await state.get_data()
    answer = str(data.get("pending_challenge_answer") or "").strip()
    try:
        challenge_id = int(data.get("active_challenge_id") or 0)
    except (TypeError, ValueError):
        challenge_id = 0
    if not answer or len(answer) > MAX_CHALLENGE_ANSWER or challenge_id <= 0:
        await state.clear()
        return await c.answer("پیش‌نمایش پاسخ نامعتبر یا منقضی شده است.", show_alert=True)
    async with SessionLocal() as session:
        if await has_active_feature_restriction(session, int(c.from_user.id), "challenges"):
            await state.clear()
            return await c.answer("مشارکت در چالش‌ها برای حساب شما به‌طور موقت محدود شده است.", show_alert=True)
        # Serialize confirmation against an admin's Close submissions transaction.
        challenge = await session.get(CommunityChallenge, challenge_id, with_for_update=True)
        if not challenge or challenge.status != "open" or not challenge.prompt:
            await state.clear()
            return await c.answer("این چالش بسته شده و پاسخ شما ثبت نشد.", show_alert=True)
        try:
            async with session.begin_nested():
                session.add(ChallengeSubmission(
                    challenge_id=challenge_id, telegram_id=c.from_user.id,
                    answer_text=answer, judging_status="unmarked",
                ))
                await session.flush()
        except IntegrityError:
            await state.clear()
            return await c.answer("پاسخ شما قبلاً ثبت شده است و قابل ویرایش نیست.", show_alert=True)
        profile = await get_or_create_profile(session, c.from_user.id)
        participation_xp = await xp_value(session, "challenge_participation")
        earning_enabled = await xp_earning_enabled(session)
        awarded = await award_once(
            session, telegram_id=c.from_user.id,
            points=participation_xp,
            award_type="challenge_participation",
            award_key=f"challenge-participation:{challenge_id}:{c.from_user.id}",
            challenge_id=challenge_id, source_id=str(challenge_id),
        )
        # The unique ChallengeSubmission is the idempotency boundary for activity
        # progression. XP pause must not suppress Passport statistics/achievements.
        profile.challenge_participations = int(profile.challenge_participations or 0) + 1
        await unlock_eligible_achievements(session, c.from_user.id)
        await session.commit()
        title = challenge.title or "چالش"
    if awarded and participation_xp > 0:
        xp_feedback = f"\n✨ {participation_xp} XP دریافت کردید."
    elif not earning_enabled:
        xp_feedback = "\nکسب امتیاز XP در حال حاضر موقتاً متوقف است؛ پاسخ شما ثبت شده است."
    else:
        xp_feedback = "\nبرای این فعالیت در حال حاضر امتیازی تعریف نشده است."
    await state.clear()
    try:
        await c.message.edit_text(
            f"✅ پاسخ شما برای <b>{escape(title)}</b> به‌صورت خصوصی ثبت شد. "
            f"نتیجه پس از بررسی مدیر اعلام می‌شود.{xp_feedback}",
            reply_markup=_back_to_community(),
        )
    except Exception:
        await c.message.answer(
            f"✅ پاسخ شما برای <b>{escape(title)}</b> به‌صورت خصوصی ثبت شد. "
            f"نتیجه پس از بررسی مدیر اعلام می‌شود.{xp_feedback}", reply_markup=_back_to_community(),
        )
    await c.answer("پاسخ ثبت شد.")


@router.callback_query(F.data == "community:wrapped")
async def wrapped_list(c: CallbackQuery):
    async with SessionLocal() as session:
        reports = (await session.execute(select(WrappedReport).where(
            WrappedReport.telegram_id == c.from_user.id, WrappedReport.status == "delivered"
        ).order_by(WrappedReport.report_year.desc()))).scalars().all()
    rows = [[InlineKeyboardButton(text=f"🎉 گزارش سالانه {report.report_year}",
                                  callback_data=f"community:wrapped:view:{report.report_year}")]
            for report in reports]
    if not reports:
        text = "🎉 <b>مرور سالانهٔ Panel Flow (Wrapped)</b>\n\nپس از آماده‌شدن گزارش توسط مدیر، جمع‌بندی فعالیت‌های شما اینجا نمایش داده می‌شود."
        rows = []
    else:
        text = "🎉 <b>گزارش‌های سالانه (Wrapped) در دسترس</b>\nبرای مشاهدهٔ مرور شخصی خود، سال موردنظر را انتخاب کنید."
    rows += [[InlineKeyboardButton(text="🔙 بازگشت", callback_data="community:home")]]
    await c.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.startswith("community:wrapped:view:"))
async def wrapped_view(c: CallbackQuery):
    try:
        year = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("سال انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        report = (await session.execute(select(WrappedReport).where(
            WrappedReport.telegram_id == c.from_user.id, WrappedReport.report_year == year,
            WrappedReport.status == "delivered",
        ))).scalar_one_or_none()
    if not report:
        return await c.answer("این گزارش Wrapped در دسترس نیست.", show_alert=True)
    await c.message.edit_text(report.report_text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🔙 گزارش‌های سالانه", callback_data="community:wrapped")
    ]]))
    await c.answer()


# --------------------------- Administrator community tools ---------------------------

@router.callback_query(F.data == "admin:community")
async def admin_community_home(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        enabled = await leaderboard_enabled(session)
    await c.message.edit_text("🎯 <b>مدیریت چالش‌ها</b>\n\nایجاد و مدیریت چالش‌ها، بررسی پاسخ‌ها، تنظیم امتیازها، مشاهدهٔ لیدربورد و ثبت نتایج مسابقه‌ها.",
                              reply_markup=admin_community_menu(enabled))
    await c.answer()


@router.callback_query(F.data == "admin:community:settings")
async def admin_community_settings(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        switches = {
            "xp": await xp_earning_enabled(session),
            "leaderboard": await leaderboard_enabled(session),
            "shop": await shop_is_enabled(session),
            "question": str(await get_setting(session, "question_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"},
            "topics": str(await get_setting(session, "topic_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"},
        }
    labels = {"xp": "کسب امتیاز XP", "leaderboard": "لیدربورد عمومی", "shop": "XP شاپ", "question": "پیشنهاد سؤال", "topics": "پیشنهاد موضوع"}
    rows = [[InlineKeyboardButton(text=f"{'🟢 فعال' if switches[key] else '🔴 غیرفعال'} · {labels[key]}",
                                  callback_data=f"admin:community:settings:toggle:{key}")] for key in labels]
    rows += [[InlineKeyboardButton(text="🛍 مدیریت پیشنهادها و سقف فروشگاه", callback_data="admin:v77:shop:manage")],
             [InlineKeyboardButton(text="⚙️ تنظیم امتیازهای هر فعالیت", callback_data="admin:community:xp")],
             [InlineKeyboardButton(text="🔙 مدیریت جامعه", callback_data="admin:community")]]
    await c.message.edit_text("<b>⚙️ تنظیمات امکانات جامعه</b>\n\nهر کنترل مستقل است. توقف کسب XP موجودی قبلی را تغییر نمی‌دهد؛ غیرفعال‌کردن فروشگاه نیز درخواست‌ها و پاداش‌های قبلی را متوقف نمی‌کند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:settings:toggle:(xp|leaderboard|shop|question|topics)$"))
async def admin_community_setting_toggle(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    key = c.data.rsplit(":", 1)[1]
    async with SessionLocal() as session:
        if key == "xp":
            setting_key = "community_xp_earning_enabled"; current = await xp_earning_enabled(session)
            await set_xp_earning_enabled(session, not current)
        elif key == "leaderboard":
            setting_key = "community_public_leaderboard_enabled"; current = await leaderboard_enabled(session)
            await set_leaderboard_enabled(session, not current)
        elif key == "shop":
            setting_key = "xp_shop_enabled"; current = await shop_is_enabled(session)
            await set_shop_enabled(session, not current)
        else:
            setting_key = "question_suggestions_enabled" if key == "question" else "topic_suggestions_enabled"
            raw = await get_setting(session, setting_key, "true")
            current = str(raw).lower() in {"1", "true", "yes", "on", "enabled"}
            await set_setting(session, setting_key, "false" if current else "true")
        from app.services.admin_audit import write_admin_action
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="community_setting_changed",
            entity_type="app_setting", details={"key": setting_key, "old_value": bool(current), "new_value": not bool(current)})
        await session.commit()
    await admin_community_settings(c)


@router.callback_query(F.data.regexp(r"^admin:community:leaderboard:view:\d+$"))
async def admin_view_full_leaderboard(c: CallbackQuery):
    """Admin-only ranking that deliberately ignores public leaderboard privacy choices."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = max(0, int(c.data.rsplit(":", 1)[1]))
    except (TypeError, ValueError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)

    page_size = 10
    async with SessionLocal() as session:
        records = await admin_leaderboard_rows(session, limit=page_size + 1, offset=page * page_size)
    # If the participant count changed while an old page was open, avoid an empty dead-end screen.
    if not records and page > 0:
        page = 0
        async with SessionLocal() as session:
            records = await admin_leaderboard_rows(session, limit=page_size + 1, offset=0)
    has_next = len(records) > page_size
    records = records[:page_size]

    if not records:
        text = "🏆 <b>لیدربورد مدیریتی Panel Flow</b>\n\nهنوز امتیاز یا سابقهٔ مشارکت در پنل برای هیچ کاربری ثبت نشده است."
    else:
        sections = []
        for index, record in enumerate(records, start=page * page_size + 1):
            medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(index, f"{index}.")
            name = escape(record["name"])
            profile_link = f'<a href="tg://user?id={int(record["telegram_id"])}">{name}</a>'
            visibility = "🙈 پنهان از رتبه‌بندی عمومی" if record["hidden"] else "🌐 نمایش در رتبه‌بندی عمومی"
            panels = int(record["panels"])
            panel_label = "پنل" if panels == 1 else "پنل"
            sections.append(
                f"{medal} <b>{profile_link}</b> · {visibility}\n"
                f"مشارکت در {panels} {panel_label} · {int(record['xp'])} امتیاز XP"
            )
        text = "🏆 <b>لیدربورد مدیریتی Panel Flow · همهٔ شرکت‌کنندگان</b>\n\n" + "\n\n".join(sections)
        text += "\n\nاین نمای مدیریتی پروفایل‌های پنهان را نیز شامل می‌شود و از تنظیمات رتبه‌بندی عمومی مستقل است."

    rows = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:community:leaderboard:view:{page-1}"))
    if has_next:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:community:leaderboard:view:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")])
    await c.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data == "admin:community:leaderboard:export")
async def admin_export_full_leaderboard(c: CallbackQuery):
    """Send the complete unfiltered leaderboard to authorized administrators only."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.answer("در حال آماده‌سازی فایل Excel…")
    try:
        records = []
        offset = 0
        batch_size = 1000
        while True:
            async with SessionLocal() as session:
                batch = await admin_leaderboard_rows(session, limit=batch_size, offset=offset)
            records.extend(batch)
            if len(batch) < batch_size:
                break
            offset += batch_size
        payload = build_leaderboard_workbook(records)
        from datetime import datetime
        filename = f"Panel_Flow_Leaderboard_{tehran_now().strftime('%Y%m%d_%H%M')}.xlsx"
        await c.message.answer_document(
            BufferedInputFile(payload, filename=filename),
            caption=(
                f"📊 خروجی کامل رتبه‌بندی ساخته شد: {len(records)} نفر.\n"
                "این فایل خصوصی است و وضعیت نمایش عمومی همهٔ کاربران، از جمله پروفایل‌های مخفی، را شامل می‌شود."
            ),
        )
    except Exception:
        logger.exception("Admin leaderboard workbook export failed for admin_id=%s", c.from_user.id)
        return await c.message.answer("ساخت فایل رتبه‌بندی ناموفق بود. لطفاً دوباره تلاش کنید.")


@router.callback_query(F.data == "admin:community:leaderboard:toggle")
async def admin_toggle_leaderboard(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        current = await leaderboard_enabled(session)
        await set_leaderboard_enabled(session, not current)
        await session.commit()
    return await admin_community_home(c)


@router.callback_query(F.data == "admin:community:challenge:create")
async def admin_challenge_create(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    await c.message.edit_text("نوع چالش را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧠 چالش دانشی", callback_data="admin:community:create:type:knowledge")],
        [InlineKeyboardButton(text="🎨 چالش خلاقانه", callback_data="admin:community:create:type:creative")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:community")],
    ]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:create:type:(knowledge|creative)$"))
async def admin_challenge_create_type(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    from app.bot.handlers.admin import _request_admin_navigation_confirmation
    if await _request_admin_navigation_confirmation(c, state):
        return
    challenge_type = c.data.rsplit(":", 1)[1]
    await state.update_data(challenge_type=challenge_type, community_creator=c.from_user.id)
    await state.set_state(CommunityAdminStates.challenge_title)
    await c.message.edit_text("عنوان کوتاهی برای چالش بفرستید (حداکثر ۱۸۰ نویسه). برای لغو از /cancel استفاده کنید.")
    await c.answer()


@router.message(CommunityAdminStates.challenge_title, F.text)
async def admin_challenge_title(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    title = (message.text or "").strip()
    if not title or title.startswith("/") or len(title) > 180:
        return await message.answer("عنوانی غیرخالی و حداکثر ۱۸۰ نویسه بفرستید؛ دستور قابل قبول نیست.")
    await state.update_data(challenge_title=title)
    await state.set_state(CommunityAdminStates.challenge_prompt)
    await message.answer("متن چالش را به انگلیسی بفرستید (حداکثر ۲۶۰۰ نویسه). پاسخ‌ها می‌توانند به هر زبانی باشند.")


@router.message(CommunityAdminStates.challenge_prompt, F.text)
async def admin_challenge_prompt(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    prompt = (message.text or "").strip()
    if not prompt or prompt.startswith("/") or len(prompt) > MAX_CHALLENGE_PROMPT:
        return await message.answer("متن چالش باید غیرخالی و حداکثر ۲۶۰۰ نویسه باشد؛ دستور قابل قبول نیست.")
    await state.update_data(challenge_prompt=prompt)
    data = await state.get_data()
    if data.get("challenge_type") == "knowledge":
        await state.set_state(CommunityAdminStates.challenge_reference)
        await message.answer("پاسخ مرجع یا یادداشت داوری خصوصی را بفرستید، یا گزینهٔ رد کردن را بزنید. این متن به شرکت‌کنندگان نمایش داده نمی‌شود.",
                             reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                                 InlineKeyboardButton(text="رد کردن پاسخ مرجع", callback_data="admin:community:create:reference:skip")
                             ]]))
    else:
        # Prevent further text messages from being interpreted as a replacement prompt
        # while the admin is choosing how many placements to configure.
        await state.set_state(CommunityAdminStates.challenge_winner_count)
        await message.answer("چند جایگاه برای برگزیدگان این چالش خلاقانه در نظر گرفته شود؟", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🥇 یک برنده", callback_data="admin:community:create:winners:1")],
            [InlineKeyboardButton(text="🏆 سه نفر برتر", callback_data="admin:community:create:winners:3")],
        ]))


async def _save_new_challenge(message_or_callback, state: FSMContext, reference: str | None, winner_count: int = 1):
    data = await state.get_data()
    creator = int(data.get("community_creator") or getattr(getattr(message_or_callback, "from_user", None), "id", 0))
    if not await _is_admin(creator):
        raise PermissionError("admin authorization required")
    async with SessionLocal() as session:
        challenge = CommunityChallenge(
            title=str(data["challenge_title"]), prompt=str(data["challenge_prompt"]),
            challenge_type=str(data["challenge_type"]), reference_answer=reference,
            winner_count=max(1, min(3, int(winner_count))), status="open", created_by_telegram_id=creator,
        )
        session.add(challenge)
        await session.commit()
        challenge_id = challenge.id
    await state.clear()
    return challenge_id


@router.callback_query(F.data == "admin:community:create:reference:skip")
async def admin_challenge_reference_skip(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != CommunityAdminStates.challenge_reference.state:
        return await c.answer("این مرحله از فرایند ایجاد منقضی شده است.", show_alert=True)
    cid = await _save_new_challenge(c, state, None)
    await c.message.edit_text(
        f"✅ چالش شمارهٔ {cid} اکنون فعال است.\nهر کاربر می‌تواند یک پاسخ ارسال کند؛ پس از بستن ارسال‌ها، بررسی مدیریتی را نهایی کنید.",
        reply_markup=await _challenge_created_keyboard(c.bot, cid),
    )
    await c.answer()


@router.message(CommunityAdminStates.challenge_reference, F.text)
async def admin_challenge_reference(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    value = (message.text or "").strip()
    if value.startswith("/") or len(value) > MAX_CHALLENGE_REFERENCE:
        return await message.answer("یادداشت مرجع را حداکثر در ۱٬۰۰۰ نویسه بفرستید یا گزینهٔ ردکردن را انتخاب کنید.")
    cid = await _save_new_challenge(message, state, value or None)
    await message.answer(
        f"✅ چالش دانشی شمارهٔ {cid} فعال شد. پاسخ‌های متنی به‌صورت خودکار ارزیابی نمی‌شوند.",
        reply_markup=await _challenge_created_keyboard(message.bot, cid),
    )


@router.callback_query(F.data.regexp(r"^admin:community:create:winners:[13]$"))
async def admin_challenge_create_winners(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != CommunityAdminStates.challenge_winner_count.state:
        return await c.answer("این مرحله از فرایند ایجاد منقضی شده است.", show_alert=True)
    data = await state.get_data()
    if data.get("challenge_type") != "creative" or not data.get("challenge_title") or not data.get("challenge_prompt"):
        await state.clear()
        return await c.answer("اطلاعات ایجاد چالش کامل نیست. فرایند را از ابتدا شروع کنید.", show_alert=True)
    winner_count = int(c.data.rsplit(":", 1)[1])
    cid = await _save_new_challenge(c, state, None, winner_count=winner_count)
    await c.message.edit_text(
        f"✅ چالش خلاقانهٔ شمارهٔ {cid} فعال شد. پیش از انتشار نتایج می‌توانید حداکثر {winner_count} برگزیده را انتخاب کنید.",
        reply_markup=await _challenge_created_keyboard(c.bot, cid),
    )
    await c.answer()


async def _render_admin_challenges(target, page: int = 0):
    page_size = 10
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(CommunityChallenge.id)).where(
            CommunityChallenge.status.in_(("open", "closed", "published")),
            CommunityChallenge.prompt.is_not(None),
        )) or 0)
        page_count = max(1, (total + page_size - 1) // page_size)
        page = min(max(0, int(page)), page_count - 1)
        challenges = (await session.execute(select(CommunityChallenge).where(
            CommunityChallenge.status.in_(("open", "closed", "published")),
            CommunityChallenge.prompt.is_not(None),
        ).order_by(CommunityChallenge.created_at.desc(), CommunityChallenge.id.desc())
          .offset(page * page_size).limit(page_size))).scalars().all()
    rows = []
    for ch in challenges:
        label = {"open": "🟢 فعال", "closed": "🔒 در انتظار اعلام نتایج", "published": "✅ نتایج منتشرشده"}.get(ch.status, admin_status_display_label(ch.status))
        rows.append([InlineKeyboardButton(text=f"{label} · #{ch.id} {(ch.title or '')[:30]}", callback_data=f"admin:community:challenge:view:{ch.id}")])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:community:challenges:page:{page-1}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:community:challenges:page:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")])
    text = f"🧠 <b>مدیریت چالش‌ها</b> · صفحهٔ {page + 1}/{page_count} · {total} چالش\nیک چالش را انتخاب کنید. محتوای پاک‌شده فقط برای حفظ سوابق امتیازدهی نگهداری می‌شود و در این فهرست نمایش داده نمی‌شود."
    await target.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data == "admin:community:challenges")
async def admin_challenges_list(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_admin_challenges(c.message)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:challenges:page:\d+$"))
async def admin_challenges_list_page(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await _render_admin_challenges(c.message, page)
    await c.answer()


@router.callback_query(F.data.startswith("admin:community:challenge:view:"))
async def admin_challenge_view(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        cid = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        challenge = await _challenge_by_id(session, cid)
        if not challenge or challenge.status == "cleared":
            return await c.answer("چالش در دسترس نیست.", show_alert=True)
        count = int(await session.scalar(select(func.count(ChallengeSubmission.id)).where(ChallengeSubmission.challenge_id == cid)) or 0)
        ch_type = challenge.challenge_type
        status = challenge.status
        title = challenge.title or f"چالش شمارهٔ {cid}"
        prompt = challenge.prompt or ""
        reference = challenge.reference_answer
        notification_total = int(await session.scalar(select(func.count(ChallengeResultNotification.id)).where(ChallengeResultNotification.challenge_id == cid)) or 0)
        notification_sent = int(await session.scalar(select(func.count(ChallengeResultNotification.id)).where(ChallengeResultNotification.challenge_id == cid, ChallengeResultNotification.status == "sent")) or 0)
        notification_failed = notification_total - notification_sent
    rows = []
    if status == "open":
        rows += [[InlineKeyboardButton(text="🔒 بستن ارسال پاسخ‌ها", callback_data=f"admin:community:challenge:close:{cid}")],
                 [InlineKeyboardButton(text="👁 بررسی پاسخ‌ها", callback_data=f"admin:community:submissions:{cid}:0")]]
    elif status == "closed":
        rows.append([InlineKeyboardButton(text="👁 بررسی پاسخ‌ها", callback_data=f"admin:community:submissions:{cid}:0")])
        if ch_type == "knowledge":
            rows.append([InlineKeyboardButton(text="✅ نهایی‌کردن بررسی", callback_data=f"admin:community:challenge:finish:{cid}:0")])
        else:
            rows.append([InlineKeyboardButton(text="🎯 بررسی برگزیدگان و انتشار نتایج", callback_data=f"admin:community:challenge:publish:preview:{cid}:0")])
    else:
        rows += [[InlineKeyboardButton(text="👁 بررسی پاسخ‌ها", callback_data=f"admin:community:submissions:{cid}:0")],
                 [InlineKeyboardButton(text="🧹 پاک‌کردن محتوای چالش", callback_data=f"admin:community:clear:one:{cid}")]]
        if notification_failed:
            rows.append([InlineKeyboardButton(text=f"🔔 تلاش دوباره برای اعلان نتایج ({notification_failed})", callback_data=f"admin:community:challenge:notifications:retry:{cid}")])
    copy_button = await _challenge_copy_button(c.bot, cid)
    if copy_button:
        rows.append([copy_button])
    rows.append([InlineKeyboardButton(text="🔙 فهرست چالش‌ها", callback_data="admin:community:challenges")])
    reference_line = f"\n\n<b>یادداشت مرجع و ارزیابی (فقط مدیر)</b>\n{escape(reference)}" if reference else ""
    notification_line = (f"\nاعلان نتایج: {notification_sent}/{notification_total} ارسال‌شده" if status == "published" else "")
    await c.message.edit_text(f"<b>#{cid} · {escape(title)}</b>\nنوع: {escape(admin_status_display_label(ch_type))} · وضعیت: {escape(admin_status_display_label(status))} · پاسخ‌ها: {count}{notification_line}\n\n{escape(prompt)}{reference_line}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.startswith("admin:community:challenge:close:"))
async def admin_challenge_close(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        cid = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        challenge = await session.get(CommunityChallenge, cid, with_for_update=True)
        if not challenge or challenge.status != "open":
            return await c.answer("مهلت ارسال پاسخ این چالش پایان یافته است.", show_alert=True)
        challenge.status = "closed"
        challenge.closed_at = utc_now_naive()
        await session.commit()
    await c.answer("ارسال پاسخ‌ها بسته شد.")
    return await admin_challenge_view_after(c, cid)


async def admin_challenge_view_after(c: CallbackQuery, cid: int):
    async with SessionLocal() as session:
        challenge = await _challenge_by_id(session, cid)
        if not challenge:
            return await c.message.edit_text("چالش در دسترس نیست.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="مدیریت چالش‌ها", callback_data="admin:community:challenges")
            ]]))
        total = int(await session.scalar(select(func.count(ChallengeSubmission.id)).where(ChallengeSubmission.challenge_id == cid)) or 0)
        status = challenge.status
        title = challenge.title or f"چالش شمارهٔ {cid}"
        notification_total = int(await session.scalar(select(func.count(ChallengeResultNotification.id)).where(ChallengeResultNotification.challenge_id == cid)) or 0)
        notification_sent = int(await session.scalar(select(func.count(ChallengeResultNotification.id)).where(ChallengeResultNotification.challenge_id == cid, ChallengeResultNotification.status == "sent")) or 0)
        notification_failed = notification_total - notification_sent
    rows = []
    if status == "open":
        rows.append([InlineKeyboardButton(text="🔒 بستن ارسال پاسخ‌ها", callback_data=f"admin:community:challenge:close:{cid}")])
    if status in ("open", "closed"):
        rows.append([InlineKeyboardButton(text="👁 بررسی پاسخ‌ها", callback_data=f"admin:community:submissions:{cid}:0")])
    if status == "closed":
        async with SessionLocal() as session:
            ch_type = (await _challenge_by_id(session, cid)).challenge_type
        if ch_type == "knowledge":
            rows.append([InlineKeyboardButton(text="✅ نهایی‌کردن بررسی", callback_data=f"admin:community:challenge:finish:{cid}:0")])
        else:
            rows.append([InlineKeyboardButton(text="🎯 بررسی برگزیدگان و انتشار نتایج", callback_data=f"admin:community:challenge:publish:preview:{cid}:0")])
    if status == "published":
        rows.append([InlineKeyboardButton(text="🧹 پاک‌کردن محتوای چالش", callback_data=f"admin:community:clear:one:{cid}")])
        rows.append([InlineKeyboardButton(text="👁 بررسی پاسخ‌ها", callback_data=f"admin:community:submissions:{cid}:0")])
        if notification_failed:
            rows.append([InlineKeyboardButton(text=f"🔔 تلاش دوباره برای اعلان نتایج ({notification_failed})", callback_data=f"admin:community:challenge:notifications:retry:{cid}")])
    copy_button = await _challenge_copy_button(c.bot, cid)
    if copy_button:
        rows.append([copy_button])
    rows.append([InlineKeyboardButton(text="🔙 فهرست چالش‌ها", callback_data="admin:community:challenges")])
    notification_line = (f" · اعلان نتایج: {notification_sent}/{notification_total}" if status == "published" else "")
    await c.message.edit_text(f"<b>#{cid} · {escape(title)}</b>\nوضعیت: {escape(admin_status_display_label(status))} · پاسخ‌ها: {total}{notification_line}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    return None


@router.callback_query(F.data.startswith("admin:community:challenge:link:"))
async def admin_challenge_link(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        cid = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        challenge = await _challenge_by_id(session, cid)
        if not challenge or challenge.status not in {"open", "closed", "published"} or not challenge.prompt:
            return await c.answer("پیوند چالش در دسترس نیست.", show_alert=True)
    try:
        me = await c.bot.get_me()
    except Exception:
        logger.exception("Could not resolve bot identity while building challenge link")
        return await c.answer("هویت ربات در تنظیمات تلگرام قابل شناسایی نیست.", show_alert=True)
    if not me.username:
        return await c.answer("نام کاربری ربات در تلگرام تنظیم نشده است.", show_alert=True)
    url = f"https://t.me/{me.username}?start=challenge_{cid}"
    await c.message.answer(
        f"<b>پیوند چالش شمارهٔ {cid}</b>\n{escape(url)}\n\nبرای اشتراک‌گذاری این چالش، پیوند بالا را کپی کنید.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 کپی پیوند چالش", copy_text=CopyTextButton(text=url))],
            [InlineKeyboardButton(text="🔙 چالش", callback_data=f"admin:community:challenge:view:{cid}")],
        ]),
    )
    await c.answer()


async def _render_submission_page(c: CallbackQuery, cid: int, page: int):
    page = max(0, int(page))
    async with SessionLocal() as session:
        challenge = await _challenge_by_id(session, cid)
        if not challenge or challenge.status == "cleared":
            return await c.answer("چالش در دسترس نیست.", show_alert=True)
        total = int(await session.scalar(select(func.count(ChallengeSubmission.id)).where(ChallengeSubmission.challenge_id == cid)) or 0)
        page_count = max(1, (total + 2) // 3)
        page = min(page, page_count - 1)
        records = (await session.execute(select(ChallengeSubmission, User).outerjoin(
            User, User.telegram_id == ChallengeSubmission.telegram_id
        ).where(ChallengeSubmission.challenge_id == cid).order_by(ChallengeSubmission.id).offset(page * 3).limit(3))).all()
        status = challenge.status
        challenge_type = challenge.challenge_type
        winner_count = int(challenge.winner_count or 1)
        title = challenge.title or f"چالش شمارهٔ {cid}"
    lines = [f"<b>پاسخ‌های چالش · {escape(title)}</b>", f"صفحهٔ {page+1}/{page_count} · مجموع {total}",
             "در هر صفحه سه پاسخ نمایش داده می‌شود. پاسخ‌ها فقط برای مدیران قابل مشاهده‌اند."]
    rows = []
    for sub, user in records:
        name = " ".join(x for x in ((user.first_name if user else None), (user.last_name if user else None)) if x) or f"کاربر شمارهٔ {sub.id}"
        profile_url = f"tg://user?id={int(sub.telegram_id)}"
        answer = sub.answer_text or "[پاسخ پاک شده]"
        if challenge_type == "knowledge":
            if sub.judging_status == "correct":
                marker = "درست ارزیابی‌شده"
            elif sub.judging_status == "incorrect" or status == "published":
                marker = "نادرست ارزیابی‌شده"
            else:
                marker = "در انتظار بررسی"
        else:
            marker = f"رتبهٔ {sub.selected_place}" if sub.selected_place else "انتخاب‌نشده"
        lines.append(f"\n<b>#{sub.id} · {escape(name)}</b> · {escape(marker)}\n{escape(answer[:MAX_CHALLENGE_ANSWER])}")
        if status == "closed" and challenge_type == "knowledge":
            rows.append([
                InlineKeyboardButton(text=f"#{sub.id} درست", callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:correct"),
                InlineKeyboardButton(text=f"#{sub.id} نادرست", callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:incorrect"),
            ])
            rows.append([
                InlineKeyboardButton(text=f"#{sub.id} پاک‌کردن ارزیابی", callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:clear"),
                InlineKeyboardButton(text=f"پروفایل · #{sub.id}", url=profile_url),
            ])
        elif status == "closed" and challenge_type == "creative":
            # Keep the primary winner action and profile link on one compact row.
            if sub.selected_place:
                action_button = InlineKeyboardButton(
                    text=f"#{sub.id} رتبهٔ {sub.selected_place} · حذف انتخاب",
                    callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:clear",
                )
            else:
                action_button = InlineKeyboardButton(
                    text=f"#{sub.id} انتخاب برگزیدهٔ بعدی",
                    callback_data=f"admin:community:judge:{cid}:{page}:{sub.id}:next",
                )
            rows.append([action_button, InlineKeyboardButton(text=f"👤 پروفایل · #{sub.id}", url=profile_url)])
        else:
            rows.append([InlineKeyboardButton(text=f"پروفایل · #{sub.id}", url=profile_url)])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:community:submissions:{cid}:{page-1}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:community:submissions:{cid}:{page+1}"))
    if nav:
        rows.append(nav)
    if status == "closed" and challenge_type == "knowledge":
        rows.append([InlineKeyboardButton(text="✅ نهایی‌کردن بررسی", callback_data=f"admin:community:challenge:finish:{cid}:{page}")])
    elif status == "closed" and challenge_type == "creative":
        rows.append([InlineKeyboardButton(text="🎯 بررسی برگزیدگان و انتشار نتایج", callback_data=f"admin:community:challenge:publish:preview:{cid}:{page}")])
    rows.append([InlineKeyboardButton(text="🔙 جزئیات چالش", callback_data=f"admin:community:challenge:view:{cid}")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)


async def _render_submission_challenge_list(target, page: int = 0, filter_name: str = "pending"):
    """Review dashboard with type/status filters and accurate progress summaries."""
    allowed_filters = {"all", "knowledge", "creative", "pending"}
    filter_name = filter_name if filter_name in allowed_filters else "pending"
    page_size = 6
    base_conditions = [CommunityChallenge.status != "cleared", CommunityChallenge.prompt.is_not(None)]
    if filter_name == "knowledge":
        base_conditions.append(CommunityChallenge.challenge_type == "knowledge")
    elif filter_name == "creative":
        base_conditions.append(CommunityChallenge.challenge_type == "creative")
    elif filter_name == "pending":
        base_conditions.append(CommunityChallenge.status == "closed")
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(CommunityChallenge.id)).where(*base_conditions)) or 0)
        page_count = max(1, (total + page_size - 1) // page_size)
        page = min(max(0, int(page)), page_count - 1)
        challenges = (await session.execute(select(CommunityChallenge).where(
            *base_conditions
        ).order_by(CommunityChallenge.closed_at.asc().nullsfirst(), CommunityChallenge.created_at.desc(), CommunityChallenge.id.desc())
          .offset(page * page_size).limit(page_size))).scalars().all()
        challenge_ids = [int(ch.id) for ch in challenges]
        submission_stats = {}
        if challenge_ids:
            stat_rows = (await session.execute(select(
                ChallengeSubmission.challenge_id,
                func.count(ChallengeSubmission.id).label("total"),
                func.sum(case((ChallengeSubmission.judging_status.in_(("correct", "incorrect")), 1), else_=0)).label("judged"),
                func.sum(case((ChallengeSubmission.selected_place.is_not(None), 1), else_=0)).label("winners"),
            ).where(ChallengeSubmission.challenge_id.in_(challenge_ids))
                .group_by(ChallengeSubmission.challenge_id))).all()
            submission_stats = {
                int(row.challenge_id): {
                    "total": int(row.total or 0), "judged": int(row.judged or 0),
                    "winners": int(row.winners or 0),
                }
                for row in stat_rows
            }
    rows = []
    descriptions = []
    status_labels = {"open": "فعال", "closed": "در انتظار بررسی", "published": "نهایی‌شده"}
    type_labels = {"knowledge": "دانشی", "creative": "خلاقانه"}
    for ch in challenges:
        stats = submission_stats.get(int(ch.id), {"total": 0, "judged": 0, "winners": 0})
        submitted = stats["total"]
        if ch.challenge_type == "knowledge":
            reviewed = submitted if ch.status == "published" else stats["judged"]
            progress = f"{reviewed}/{submitted} بررسی‌شده"
        elif ch.status == "published":
            progress = "نتایج منتشرشده"
        else:
            places = int(ch.winner_count or 1)
            progress = f"{stats['winners']}/{places} جایگاه برگزیدگان انتخاب‌شده"
        descriptions.append(
            f"<b>#{ch.id} · {escape(ch.title or 'چالش')}</b> · {type_labels.get(ch.challenge_type, 'چالش')}\n"
            f"{submitted} پاسخ · {progress} · {status_labels.get(ch.status, admin_status_display_label(ch.status))}"
        )
        short_title = (ch.title or "چالش")[:27].rstrip()
        rows.append([InlineKeyboardButton(
            text=f"👁 #{ch.id} · {short_title}"[:64],
            callback_data=f"admin:community:submissions:{ch.id}:0",
        )])
    filter_rows = [
        [InlineKeyboardButton(text=("✅ " if filter_name == "all" else "") + "همه", callback_data="admin:community:submissions:list:all:0"),
         InlineKeyboardButton(text=("✅ " if filter_name == "knowledge" else "") + "🧠 دانشی", callback_data="admin:community:submissions:list:knowledge:0")],
        [InlineKeyboardButton(text=("✅ " if filter_name == "creative" else "") + "🎨 خلاقانه", callback_data="admin:community:submissions:list:creative:0"),
         InlineKeyboardButton(text=("✅ " if filter_name == "pending" else "") + "⏳ در انتظار بررسی", callback_data="admin:community:submissions:list:pending:0")],
    ]
    rows = filter_rows + rows
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:community:submissions:list:{filter_name}:{page-1}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:community:submissions:list:{filter_name}:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")])
    if not total:
        descriptions = ["چالشی با این فیلتر پیدا نشد."]
    description = "\n\n".join(descriptions)
    await target.edit_text(
        f"<b>👁 بررسی پاسخ‌ها</b> · {total} چالش · صفحهٔ {page + 1}/{page_count}\n"
        "ابتدا فیلتر را انتخاب کنید و سپس وارد چالش شوید. پیشرفت چالش‌های دانشی بر اساس پاسخ‌های ارزیابی‌شده و چالش‌های خلاقانه بر اساس جایگاه‌های برگزیدگان محاسبه می‌شود.\n\n" + description,
                           reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:community:submissions:list:\d+$"))
async def admin_submission_challenge_list(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    # Older V48 buttons are accepted and map to the default awaiting-review queue.
    await _render_submission_challenge_list(c.message, page, "pending")
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:submissions:list:(all|knowledge|creative|pending):\d+$"))
async def admin_submission_challenge_list_filtered(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _, _, _, _, filter_name, page_text = c.data.split(":")
        page = int(page_text)
    except (ValueError, AttributeError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await _render_submission_challenge_list(c.message, page, filter_name)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:submissions:\d+:\d+$"))
async def admin_challenge_submissions(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _, _, _, cid, page = c.data.split(":")
        cid, page = int(cid), int(page)
    except ValueError:
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await _render_submission_page(c, cid, page)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:judge:\d+:\d+:\d+:(correct|incorrect|next|place[123]|clear)$"))
async def admin_judge_submission(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _, _, _, cid, page, sid, action = c.data.split(":")
        cid, page, sid = int(cid), int(page), int(sid)
    except ValueError:
        return await c.answer("پاسخ انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        challenge = await session.get(CommunityChallenge, cid, with_for_update=True)
        submission = await session.get(ChallengeSubmission, sid, with_for_update=True)
        if not challenge or challenge.status != "closed" or not submission or submission.challenge_id != cid:
            return await c.answer("این پاسخ قدیمی است یا چالش هنوز بسته نشده است.", show_alert=True)
        if action in {"correct", "incorrect"}:
            if challenge.challenge_type != "knowledge":
                return await c.answer("ارزیابی درست یا نادرست فقط برای چالش‌های دانشی امکان‌پذیر است.", show_alert=True)
            submission.judging_status = action
            submission.selected_place = None
        elif action == "next":
            if challenge.challenge_type != "creative":
                return await c.answer("انتخاب برگزیده فقط برای چالش‌های خلاقانه امکان‌پذیر است.", show_alert=True)
            if submission.selected_place is not None:
                return await c.answer("برای این فرد قبلاً رتبه‌ای ثبت شده است. ابتدا آن را حذف کنید.", show_alert=True)
            selected_places = (await session.execute(select(ChallengeSubmission.selected_place).where(
                ChallengeSubmission.challenge_id == cid,
                ChallengeSubmission.selected_place.is_not(None),
            ))).scalars().all()
            place = max((int(value) for value in selected_places), default=0) + 1
            if place > int(challenge.winner_count or 1):
                return await c.answer("همهٔ جایگاه‌های برگزیدگان تکمیل شده‌اند. برای انتخاب فرد دیگر، ابتدا یکی از انتخاب‌ها را حذف کنید.", show_alert=True)
            # Selection order defines placement: first selected is first place, then second, then third.
            submission.selected_place = place
            submission.judging_status = "winner"
        elif action.startswith("place"):
            # Legacy callback compatibility for an old review keyboard already on screen.
            if challenge.challenge_type != "creative":
                return await c.answer("تعیین رتبه فقط برای چالش‌های خلاقانه امکان‌پذیر است.", show_alert=True)
            place = int(action[-1])
            if place > int(challenge.winner_count or 1):
                return await c.answer("این جایگاه برای این چالش تعریف نشده است.", show_alert=True)
            await session.execute(
                __import__("sqlalchemy").update(ChallengeSubmission)
                .where(ChallengeSubmission.challenge_id == cid, ChallengeSubmission.selected_place == place)
                .values(selected_place=None, judging_status="unmarked")
            )
            submission.selected_place = place
            submission.judging_status = "winner"
        else:
            previous_place = submission.selected_place
            submission.selected_place = None
            submission.judging_status = "unmarked"
            if challenge.challenge_type == "creative" and previous_place is not None:
                # Close any gap left by removing a provisional winner, retaining selection order.
                await session.flush()
                remaining = (await session.execute(select(ChallengeSubmission).where(
                    ChallengeSubmission.challenge_id == cid,
                    ChallengeSubmission.selected_place.is_not(None),
                ).order_by(ChallengeSubmission.selected_place, ChallengeSubmission.id))).scalars().all()
                for new_place, selected in enumerate(remaining, start=1):
                    selected.selected_place = new_place
        await session.commit()
    await c.answer("ارزیابی ذخیره شد.")
    await _render_submission_page(c, cid, page)


@router.callback_query(F.data.regexp(r"^admin:community:challenge:publish:preview:\d+:\d+$"))
async def admin_preview_challenge_results(c: CallbackQuery):
    """Preview creative placements; no XP is awarded until the admin confirms."""
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        parts = c.data.split(":")
        cid, page = int(parts[-2]), int(parts[-1])
    except (ValueError, IndexError):
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        challenge = await session.get(CommunityChallenge, cid)
        if not challenge or challenge.status != "closed" or challenge.challenge_type != "creative":
            return await c.answer("پیش‌نمایش نتایج فقط برای چالش خلاقانه‌ای که ارسال پاسخ‌های آن بسته شده باشد امکان‌پذیر است.", show_alert=True)
        winners = (await session.execute(select(ChallengeSubmission, User).outerjoin(
            User, User.telegram_id == ChallengeSubmission.telegram_id
        ).where(ChallengeSubmission.challenge_id == cid,
                ChallengeSubmission.selected_place.is_not(None))
          .order_by(ChallengeSubmission.selected_place))).all()
        title = challenge.title or f"چالش شمارهٔ {cid}"
        winner_count = int(challenge.winner_count or 1)
    lines = [f"<b>تأیید نتایج چالش خلاقانه · {escape(title)}</b>",
             "پیش از انتشار، رتبه‌های پیشنهادی را بررسی کنید. امتیازها فقط پس از تأیید نهایی ثبت می‌شوند."]
    if winners:
        for sub, user in winners:
            name = " ".join(x for x in ((user.first_name if user else None), (user.last_name if user else None)) if x) or f"کاربر شمارهٔ {sub.id}"
            place = int(sub.selected_place or 1)
            medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(place, "🏅")
            lines.append(f"\n{medal} <b>Place {place}:</b> {escape(name)}")
    else:
        lines.append("\n⚠️ هنوز برگزیده‌ای انتخاب نشده است. پیش از انتشار، به فهرست پاسخ‌ها برگردید و دست‌کم یک برگزیده انتخاب کنید.")
    lines.append(f"\nتعداد جایگاه‌های قابل انتخاب: {winner_count}.")
    rows = []
    async with SessionLocal() as session:
        submission_count = int(await session.scalar(select(func.count(ChallengeSubmission.id)).where(ChallengeSubmission.challenge_id == cid)) or 0)
    if winners or submission_count == 0:
        rows.append([InlineKeyboardButton(text="✅ تأیید و انتشار", callback_data=f"admin:community:challenge:publish:confirm:{cid}:{page}")])
    rows.append([InlineKeyboardButton(text="↩️ بازگشت به بررسی پاسخ‌ها", callback_data=f"admin:community:submissions:{cid}:{page}")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


async def _deliver_challenge_result_notification(bot, notification_id: int) -> bool:
    """Deliver one published-result message and persist the Telegram outcome."""
    async with SessionLocal() as session:
        row = (await session.execute(select(ChallengeResultNotification).where(
            ChallengeResultNotification.id == int(notification_id)
        ).with_for_update())).scalar_one_or_none()
        if not row:
            return False
        if row.status == "sent":
            return True
        # A retry must not race a notification currently being delivered. If the
        # process crashed after claiming it, the stale claim becomes retryable.
        if row.status == "sending" and row.updated_at and (utc_now_naive() - row.updated_at) < timedelta(minutes=5):
            return False
        row.status = "sending"
        row.attempts = int(row.attempts or 0) + 1
        row.last_error = None
        row.updated_at = utc_now_naive()
        telegram_id = int(row.telegram_id)
        challenge_id = int(row.challenge_id)
        title = str(row.challenge_title_snapshot or "چالش")
        await session.commit()
    try:
        await bot.send_message(
            telegram_id,
            f"🎉 نتایج چالش «{escape(title)}» منتشر شده است.\nبرای مشاهدهٔ نتیجه و جزئیات، از دکمهٔ زیر استفاده کنید.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="مشاهدهٔ نتیجهٔ چالش", callback_data=f"community:challenge:view:{challenge_id}")
            ]]),
        )
        delivered, error = True, None
    except Exception as exc:
        delivered, error = False, f"{type(exc).__name__}: {str(exc)[:220]}"
        logger.info("Challenge result notification failed for challenge_id=%s telegram_id=%s", challenge_id, telegram_id, exc_info=True)
    async with SessionLocal() as session:
        row = (await session.execute(select(ChallengeResultNotification).where(
            ChallengeResultNotification.id == int(notification_id)
        ).with_for_update())).scalar_one_or_none()
        if row and row.status != "sent":
            row.status = "sent" if delivered else "failed"
            row.sent_at = utc_now_naive() if delivered else None
            row.last_error = error
            row.updated_at = utc_now_naive()
            await session.commit()
    return delivered


async def _send_challenge_result_notifications(bot, challenge_id: int) -> tuple[int, int]:
    async with SessionLocal() as session:
        notification_ids = list((await session.execute(select(ChallengeResultNotification.id).where(
            ChallengeResultNotification.challenge_id == int(challenge_id),
            ChallengeResultNotification.status != "sent",
        ).order_by(ChallengeResultNotification.id))).scalars().all())
    semaphore = asyncio.Semaphore(6)

    async def deliver(notification_id: int) -> bool:
        async with semaphore:
            return await _deliver_challenge_result_notification(bot, int(notification_id))

    outcomes = await asyncio.gather(*(deliver(int(item)) for item in notification_ids), return_exceptions=True)
    sent = sum(1 for outcome in outcomes if outcome is True)
    failed = len(outcomes) - sent
    return sent, failed


async def _finalize_challenge_review(c: CallbackQuery, cid: int, expected_type: str, success_message: str):
    """Finalize one closed challenge under row lock, awarding result XP exactly once."""
    async with SessionLocal() as session:
        challenge = await session.get(CommunityChallenge, cid, with_for_update=True)
        if not challenge or challenge.status != "closed":
            return await c.answer("این بررسی قبلاً نهایی شده یا دیگر در دسترس نیست.", show_alert=True)
        if challenge.challenge_type != expected_type:
            return await c.answer("این عملیات با نوع چالش مطابقت ندارد.", show_alert=True)
        submissions = (await session.execute(select(ChallengeSubmission).where(
            ChallengeSubmission.challenge_id == cid
        ).order_by(ChallengeSubmission.id))).scalars().all()
        if expected_type == "creative" and submissions and not any(sub.selected_place for sub in submissions):
            return await c.answer("پیش از انتشار، دست‌کم یک برگزیده انتخاب کنید.", show_alert=True)
        if expected_type == "knowledge":
            # Once review is finished, every unanswered judgement is a final incorrect result.
            for sub in submissions:
                if sub.judging_status != "correct":
                    sub.judging_status = "incorrect"
                sub.selected_place = None
        from app.db.models import AppSetting
        lock_row = (await session.execute(select(AppSetting).where(
            AppSetting.key == "community_challenge_publish_lock"
        ).with_for_update())).scalar_one_or_none()
        if lock_row is None:
            lock_row = AppSetting(key="community_challenge_publish_lock", value="0")
            session.add(lock_row)
            await session.flush()
        next_seq = int(await session.scalar(select(func.max(CommunityChallenge.published_sequence)).where(
            CommunityChallenge.published_sequence.is_not(None)
        )) or 0) + 1
        challenge.published_sequence = next_seq
        challenge.results_finalized_at = utc_now_naive()
        challenge.status = "published"
        participant_ids = {int(sub.telegram_id) for sub in submissions}
        for sub in submissions:
            tg_id = int(sub.telegram_id)
            if expected_type == "knowledge":
                if sub.judging_status == "correct":
                    added = await award_once(
                        session, telegram_id=tg_id,
                        points=await xp_value(session, "knowledge_correct"),
                        award_type="knowledge_correct",
                        award_key=f"challenge-correct:{cid}:{tg_id}", challenge_id=cid,
                    )
                    profile = await get_or_create_profile(session, tg_id)
                    # Challenge result finalization is idempotent; progression is
                    # independent of whether the XP ledger is paused/already awarded.
                    profile.correct_answers += 1
            elif sub.selected_place:
                place = int(sub.selected_place)
                if place in (1, 2, 3) and place <= int(challenge.winner_count or 1):
                    award_type = {1: "creative_first", 2: "creative_second", 3: "creative_third"}[place]
                    points_key = {1: "creative_first", 2: "creative_second", 3: "creative_third"}[place]
                    added = await award_once(
                        session, telegram_id=tg_id,
                        points=await xp_value(session, points_key),
                        award_type=award_type,
                        award_key=f"challenge-placement:{cid}:{tg_id}:{place}", challenge_id=cid,
                    )
                    profile = await get_or_create_profile(session, tg_id)
                    if place == 1:
                        profile.creative_first += 1
                    elif place == 2:
                        profile.creative_second += 1
                    elif place == 3:
                        profile.creative_third += 1
        # Finalization sequence drives streaks. Preserve the historical rule (all
        # eligible profiles that have not seen this sequence reset unless they submitted)
        # while using two set-based UPDATE statements instead of materializing and
        # explicitly locking every ORM profile row in Python.
        eligible_profile = (
            CommunityProfile.onboarding_sequence < next_seq,
            CommunityProfile.last_finalized_sequence < next_seq,
        )
        if participant_ids:
            await session.execute(
                update(CommunityProfile)
                .where(*eligible_profile, CommunityProfile.telegram_id.in_(participant_ids))
                .values(
                    current_streak=CommunityProfile.current_streak + 1,
                    best_streak=case(
                        (CommunityProfile.best_streak < CommunityProfile.current_streak + 1,
                         CommunityProfile.current_streak + 1),
                        else_=CommunityProfile.best_streak,
                    ),
                    last_finalized_sequence=next_seq,
                )
            )
            await session.execute(
                update(CommunityProfile)
                .where(*eligible_profile, CommunityProfile.telegram_id.not_in(participant_ids))
                .values(current_streak=0, last_finalized_sequence=next_seq)
            )
        else:
            await session.execute(
                update(CommunityProfile)
                .where(*eligible_profile)
                .values(current_streak=0, last_finalized_sequence=next_seq)
            )
        for tg_id in participant_ids:
            await get_or_create_profile(session, tg_id)
            await unlock_eligible_achievements(session, tg_id)
        existing_notification_ids = set((await session.execute(select(
            ChallengeResultNotification.telegram_id
        ).where(ChallengeResultNotification.challenge_id == cid))).scalars().all())
        for tg_id in participant_ids - {int(value) for value in existing_notification_ids}:
            session.add(ChallengeResultNotification(
                challenge_id=cid, telegram_id=int(tg_id),
                challenge_title_snapshot=str(challenge.title or f"چالش شمارهٔ {cid}")[:180],
                status="pending",
            ))
        await session.commit()
    # Results and XP are durable before any outbound Telegram message is attempted.
    # A failed delivery is tracked and can be retried from the administrator view.
    await c.answer(success_message)
    await _send_challenge_result_notifications(c.bot, cid)
    # Milestones are left queued for a single popup at the user's next community
    # interaction, rather than sending an unsolicited message into their chat.
    return await admin_challenge_view_after(c, cid)


@router.callback_query(F.data.regexp(r"^admin:community:challenge:finish:\d+:\d+$"))
async def admin_finish_knowledge_review(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        cid = int(c.data.split(":")[-2])
    except (ValueError, IndexError):
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    return await _finalize_challenge_review(c, cid, "knowledge", "بررسی نهایی شد")


@router.callback_query(F.data.regexp(r"^admin:community:challenge:publish:confirm:\d+:\d+$"))
async def admin_publish_challenge(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        cid = int(c.data.split(":")[-2])
    except (ValueError, IndexError):
        return await c.answer("چالش انتخاب‌شده معتبر نیست.", show_alert=True)
    return await _finalize_challenge_review(c, cid, "creative", "نتایج منتشر شد")


@router.callback_query(F.data.regexp(r"^admin:community:challenge:notifications:retry:\d+$"))
async def admin_retry_challenge_result_notifications(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    challenge_id = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        challenge = await session.get(CommunityChallenge, challenge_id)
        if not challenge or challenge.status != "published":
            return await c.answer("نتایج این چالش منتشر نشده یا در دسترس نیست.", show_alert=True)
    sent, failed = await _send_challenge_result_notifications(c.bot, challenge_id)
    await c.answer(f"تلاش مجدد انجام شد؛ موفق: {sent} · ناموفق: {failed}", show_alert=bool(failed))
    return await admin_challenge_view_after(c, challenge_id)


@router.callback_query(F.data == "admin:community:clear")
async def admin_clear_menu(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        eligible = (await session.execute(select(CommunityChallenge).where(
            CommunityChallenge.status == "published", CommunityChallenge.prompt.is_not(None)
        ).order_by(CommunityChallenge.id.desc()).limit(30))).scalars().all()
        total = int(await session.scalar(select(func.count(CommunityChallenge.id)).where(
            CommunityChallenge.status == "published", CommunityChallenge.prompt.is_not(None)
        )) or 0)
    rows = [[InlineKeyboardButton(text=f"پاک‌سازی #{ch.id} · {(ch.title or 'چالش')[:30]}", callback_data=f"admin:community:clear:one:{ch.id}")] for ch in eligible]
    rows.append([InlineKeyboardButton(text=f"🧹 پاک‌سازی همهٔ موارد نهایی‌شده ({total})", callback_data="admin:community:clear:all:confirm")])
    rows.append([InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")])
    await c.message.edit_text("فقط محتوای چالش‌هایی که نتایج آن‌ها منتشر شده است قابل پاک‌کردن است. متن پرسش و پاسخ‌های خام حذف می‌شوند؛ سوابق امتیاز و ترتیب مشارکت حفظ خواهد شد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


async def _clear_finalized(session, challenge_ids: list[int]) -> int:
    count = 0
    for cid in challenge_ids:
        challenge = await session.get(CommunityChallenge, cid, with_for_update=True)
        if not challenge or challenge.status != "published" or challenge.prompt is None:
            continue
        await session.execute(delete(ChallengeSubmission).where(ChallengeSubmission.challenge_id == cid))
        challenge.title = None
        challenge.prompt = None
        challenge.reference_answer = None
        challenge.status = "cleared"
        challenge.cleared_at = utc_now_naive()
        count += 1
    return count


@router.callback_query(F.data.regexp(r"^admin:community:clear:one:\d+$"))
async def admin_clear_one_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    cid = int(c.data.rsplit(":", 1)[1])
    await c.message.edit_text(f"محتوای چالش نهایی‌شدهٔ شمارهٔ {cid} پاک شود؟ پرسش و پاسخ‌های خام برای همیشه حذف می‌شوند؛ سوابق XP، جوایز و زنجیرهٔ مشارکت باقی می‌مانند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید پاک‌سازی", callback_data=f"admin:community:clear:one:confirm:{cid}")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:community:clear")],
    ]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:community:clear:one:confirm:\d+$"))
async def admin_clear_one(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    cid = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        count = await _clear_finalized(session, [cid])
        await session.commit()
    await c.answer(f"{count} مورد پاک شد.")
    return await admin_clear_menu(c)


@router.callback_query(F.data == "admin:community:clear:all:confirm")
async def admin_clear_all_confirm(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(CommunityChallenge.id)).where(
            CommunityChallenge.status == "published", CommunityChallenge.prompt.is_not(None)
        )) or 0)
    await c.message.edit_text(f"آیا از پاک‌سازی همهٔ {total} چالش نهایی‌شده مطمئن هستید؟ چالش‌های فعال یا بررسی‌نشده تغییری نمی‌کنند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ پاک‌سازی همهٔ موارد نهایی‌شده", callback_data="admin:community:clear:all:execute")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:community:clear")],
    ]))
    await c.answer()


@router.callback_query(F.data == "admin:community:clear:all:execute")
async def admin_clear_all_execute(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        ids = list((await session.execute(select(CommunityChallenge.id).where(
            CommunityChallenge.status == "published", CommunityChallenge.prompt.is_not(None)
        ).with_for_update())).scalars().all())
        count = await _clear_finalized(session, [int(x) for x in ids])
        await session.commit()
    await c.answer(f"محتوای {count} چالش پاک شد.")
    await c.message.edit_text(f"✅ محتوای {count} چالش نهایی‌شده پاک شد. سوابق جوایز و زنجیره‌های مشارکت حفظ شدند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")
    ]]))


@router.callback_query(F.data == "admin:community:xp")
async def admin_xp_settings(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        values = {key: await xp_value(session, key) for key in XP_DEFAULTS}
    labels = {
        "paid_panel": "مشارکت در پنل", "challenge_participation": "مشارکت در چالش",
        "knowledge_correct": "امتیاز پاسخ درست", "creative_first": "رتبهٔ اول چالش خلاقانه",
        "creative_second": "رتبهٔ دوم چالش خلاقانه", "creative_third": "رتبهٔ سوم چالش خلاقانه",
        "archived_review": "ثبت نظر برای پنل گذشته", "recognized_contribution": "مشارکت ارزشمند",
        "external_competition": "برندهٔ رقابت بیرونی",
    }
    rows = [[InlineKeyboardButton(text=f"{labels[k]} · {values[k]} XP", callback_data=f"admin:community:xp:set:{k}")] for k in XP_DEFAULTS]
    rows.append([InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")])
    await c.message.edit_text("⚙️ <b>تنظیم امتیازهای XP</b>\nاین مقادیر فقط بر امتیازهای آینده اثر می‌گذارند و سوابق قبلی تغییر نمی‌کنند.", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.startswith("admin:community:xp:set:"))
async def admin_xp_setting_edit(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    key = c.data.rsplit(":", 1)[1]
    if key not in XP_DEFAULTS:
        return await c.answer("دسته‌بندی امتیاز XP معتبر نیست.", show_alert=True)
    await state.clear()
    await state.update_data(xp_key=key)
    await state.set_state(CommunityAdminStates.xp_value)
    labels = {
        "paid_panel": "مشارکت در پنل", "challenge_participation": "مشارکت در چالش",
        "knowledge_correct": "امتیاز پاسخ درست", "creative_first": "رتبهٔ اول چالش خلاقانه",
        "creative_second": "رتبهٔ دوم چالش خلاقانه", "creative_third": "رتبهٔ سوم چالش خلاقانه",
        "archived_review": "ثبت نظر برای پنل گذشته", "recognized_contribution": "مشارکت ارزشمند",
        "external_competition": "برندهٔ رقابت بیرونی",
    }
    label = labels.get(key, "این فعالیت")
    await c.message.answer(f"مقدار جدید XP برای «{label}» را به‌صورت عدد صحیح بین ۰ تا ۱۰۰۰ وارد کنید. امتیازهای قبلی تغییر نمی‌کنند.")
    await c.answer()


@router.message(CommunityAdminStates.xp_value, F.text)
async def admin_xp_setting_save(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    try:
        value = int((message.text or "").strip())
        if not 0 <= value <= 1000:
            raise ValueError
    except ValueError:
        return await message.answer("یک عدد صحیح بین ۰ تا ۱۰۰۰ وارد کنید.")
    key = str((await state.get_data()).get("xp_key") or "")
    if key not in XP_DEFAULTS:
        await state.clear()
        return await message.answer("مهلت این مرحلهٔ تنظیم به پایان رسیده است.")
    async with SessionLocal() as session:
        await set_setting(session, f"community_xp_{key}", str(value))
        await session.commit()
    labels = {
        "paid_panel": "مشارکت در پنل", "challenge_participation": "مشارکت در چالش",
        "knowledge_correct": "امتیاز پاسخ درست", "creative_first": "رتبهٔ اول چالش خلاقانه",
        "creative_second": "رتبهٔ دوم چالش خلاقانه", "creative_third": "رتبهٔ سوم چالش خلاقانه",
        "archived_review": "ثبت نظر برای پنل گذشته", "recognized_contribution": "مشارکت ارزشمند",
        "external_competition": "برندهٔ رقابت بیرونی",
    }
    label = labels.get(key, "این فعالیت")
    await state.clear()
    await message.answer(f"✅ از این پس برای «{label}» مقدار {value} XP ثبت می‌شود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⚙️ تنظیم امتیازهای XP", callback_data="admin:community:xp")
    ], [InlineKeyboardButton(text="🎮 مدیریت چالش‌ها", callback_data="admin:community")]]))


@router.callback_query(F.data == "admin:community:competition")
async def admin_competition_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.set_state(CommunityAdminStates.competition_telegram_id)
    await c.message.edit_text("شناسهٔ عددی تلگرام فرد برنده را وارد کنید. تکمیل ثبت‌نام ربات برای دریافت این امتیاز الزامی نیست.")
    await c.answer()


@router.message(CommunityAdminStates.competition_telegram_id, F.text)
async def admin_competition_user_id(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    raw = (message.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0 or int(raw) > 9_223_372_036_854_775_807:
        return await message.answer("یک شناسهٔ عددی معتبر و مثبت تلگرام وارد کنید.")
    await state.update_data(competition_user_id=int(raw))
    await state.set_state(CommunityAdminStates.competition_title)
    await message.answer("عنوان کوتاه یا شناسهٔ یکتای رقابت را وارد کنید (حداکثر ۱۲۰ نویسه).")


@router.message(CommunityAdminStates.competition_title, F.text)
async def admin_competition_title(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    title = (message.text or "").strip()
    if not title or title.startswith("/") or len(title) > 120:
        return await message.answer("عنوان رقابت را در حداکثر ۱۲۰ نویسه وارد کنید.")
    await state.update_data(competition_title=title)
    await state.set_state(CommunityAdminStates.competition_note)
    await message.answer("در صورت نیاز یادداشت داخلی را وارد کنید؛ برای ردکردن این مرحله فقط خط تیره (-) بفرستید.")


@router.message(CommunityAdminStates.competition_note, F.text)
async def admin_competition_finish(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    data = await state.get_data()
    note = (message.text or "").strip()
    if len(note) > 250:
        return await message.answer("یادداشت داخلی نباید بیشتر از ۲۵۰ نویسه باشد.")
    tg_id, title = int(data["competition_user_id"]), str(data["competition_title"])
    normalized_title = re.sub(r"\s+", " ", title).strip().casefold()
    digest = hashlib.sha256(normalized_title.encode("utf-8")).hexdigest()[:40]
    async with SessionLocal() as session:
        awarded = await award_once(session, telegram_id=tg_id, points=await xp_value(session, "external_competition"),
                                   award_type="external_competition", award_key=f"external-competition:{tg_id}:{digest}",
                                   source_id=digest, note=(title + (f" | {note}" if note and note != "-" else ""))[:300])
        await session.commit()
    await state.clear()
    await message.answer(("✅ امتیاز ثبت شد: ۶ XP یا مقدار تنظیم‌شده." if awarded else "ℹ️ این امتیاز قبلاً برای همین برنده و رقابت ثبت شده است؛ XP تکراری اضافه نشد."), reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🏅 ثبت برندهٔ دیگر", callback_data="admin:community:competition")
    ], [InlineKeyboardButton(text="🎮 مدیریت چالش‌ها", callback_data="admin:community")]]))
    if awarded:
        try:
            await message.bot.send_message(tg_id, f"🏅 به‌عنوان برندهٔ رقابت «<b>{escape(title)}</b>» شناخته شدید و XP جامعه دریافت کردید.")
        except Exception:
            logger.info("Competition award notification could not be delivered; telegram_id=%s", tg_id, exc_info=True)


@router.callback_query(F.data == "admin:community:wrapped")
async def admin_wrapped_start(c: CallbackQuery, state: FSMContext):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.set_state(CommunityAdminStates.wrapped_year)
    await c.message.edit_text("سال گزارش را بین ۲۰۰۰ تا ۲۱۰۰ وارد کنید. بازهٔ گزارش از ابتدای اول ژانویه تا ابتدای اول ژانویهٔ سال بعد محاسبه می‌شود. پیش از ارسال، پیش‌نمایش نمایش داده خواهد شد.")
    await c.answer()


@router.message(CommunityAdminStates.wrapped_year, F.text)
async def admin_wrapped_preview(message: Message, state: FSMContext):
    if not await _is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    try:
        year = int((message.text or "").strip())
        if not 2000 <= year <= 2100:
            raise ValueError
    except ValueError:
        return await message.answer("سال را بین ۲۰۰۰ تا ۲۱۰۰ وارد کنید.")
    await state.clear()
    await message.answer(f"در حال آماده‌سازی پیش‌نمایش کارنامهٔ سالانهٔ Panel Flow برای {year}…")
    async with SessionLocal() as session:
        ids = list((await session.execute(select(User.telegram_id).order_by(User.telegram_id))).scalars().all())
        sample_text = None
        for tg_id in ids[:1]:
            sample_text = await make_wrapped_text(session, int(tg_id), year)
    preview = sample_text or f"🎉 <b>گزارش سالانهٔ Panel Flow · {year}</b>\n\nدر حال حاضر کاربری برای تهیهٔ این گزارش در دسترس نیست."
    await message.answer(f"<b>پیش‌نمایش مدیریتی · {year}</b>\nدریافت‌کنندگان دارای حساب کاربری: {len(ids)}\n\n{preview}\n\nهنوز پیامی ارسال نشده است. گزارش‌ها ساخته شوند؟", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ ساخت و ارسال گزارش‌ها", callback_data=f"admin:community:wrapped:generate:{year}")],
        [InlineKeyboardButton(text="♻️ ارسال دوبارهٔ گزارش‌های موجود", callback_data=f"admin:community:wrapped:resend:{year}")],
        [InlineKeyboardButton(text="🔙 مدیریت چالش‌ها", callback_data="admin:community")],
    ]))


async def _deliver_wrapped(bot, year: int, *, resend: bool = False) -> dict:
    async with SessionLocal() as session:
        user_ids = [int(x) for x in (await session.execute(select(User.telegram_id).order_by(User.telegram_id))).scalars().all()]
    generated = delivered = failed = skipped = 0
    for tg_id in user_ids:
        text = None
        report_id = None
        try:
            async with SessionLocal() as session:
                report = (await session.execute(select(WrappedReport).where(
                    WrappedReport.telegram_id == tg_id, WrappedReport.report_year == year
                ).with_for_update())).scalar_one_or_none()
                if report and not resend:
                    skipped += 1
                    continue
                if resend and not report:
                    skipped += 1
                    continue
                if report and resend:
                    text = report.report_text
                    report_id = report.id
                else:
                    text = await make_wrapped_text(session, tg_id, year)
                    report = WrappedReport(telegram_id=tg_id, report_year=year, report_text=text, status="generated")
                    session.add(report)
                    await session.commit()
                    report_id = report.id
                    generated += 1
            # Do network I/O only after any generation transaction has been committed.
            try:
                await bot.send_message(tg_id, text)
                async with SessionLocal() as session:
                    report = await session.get(WrappedReport, report_id, with_for_update=True)
                    if report:
                        report.status = "delivered"
                        report.delivered_at = utc_now_naive()
                        report.last_error = None
                        await session.commit()
                delivered += 1
            except Exception as exc:
                async with SessionLocal() as session:
                    report = await session.get(WrappedReport, report_id, with_for_update=True)
                    if report:
                        report.status = "failed"
                        report.last_error = type(exc).__name__[:300]
                        await session.commit()
                failed += 1
        except Exception:
            logger.exception("Wrapped report generation failed for telegram_id=%s year=%s", tg_id, year)
            failed += 1
    return {"generated": generated, "delivered": delivered, "failed": failed, "skipped": skipped}


@router.callback_query(F.data.regexp(r"^admin:community:wrapped:generate:\d{4}$"))
async def admin_wrapped_generate(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    year = int(c.data.rsplit(":", 1)[1])
    await c.answer("ساخت گزارش‌ها آغاز شد.")
    result = await _deliver_wrapped(c.bot, year)
    await c.message.edit_text(f"<b>گزارش ارسال کارنامهٔ سال {year}</b>\nساخته‌شده: {result['generated']}\nتحویل‌شده: {result['delivered']}\nناموفق: {result['failed']}\nردشده (از قبل ساخته شده): {result['skipped']}\n\nگزارش‌های ناموفق ذخیره شده‌اند و در صورت نیاز می‌توان آن‌ها را دوباره ارسال کرد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="♻️ ارسال دوبارهٔ گزارش‌های موجود", callback_data=f"admin:community:wrapped:resend:{year}")
    ], [InlineKeyboardButton(text="🎮 مدیریت چالش‌ها", callback_data="admin:community")]]))


@router.callback_query(F.data.regexp(r"^admin:community:wrapped:resend:\d{4}$"))
async def admin_wrapped_resend(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    year = int(c.data.rsplit(":", 1)[1])
    await c.answer("ارسال دوبارهٔ گزارش‌های موجود آغاز شد.")
    result = await _deliver_wrapped(c.bot, year, resend=True)
    await c.message.edit_text(f"<b>گزارش ارسال دوبارهٔ کارنامهٔ سال {year}</b>\nتحویل‌شده: {result['delivered']}\nناموفق: {result['failed']}\nگزارش‌های ساخته‌شده در این نوبت: {result['generated']}\n", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🎮 مدیریت چالش‌ها", callback_data="admin:community")
    ]]))


@router.callback_query(F.data.startswith("admin:community:recognize:"))
async def admin_recognize_contribution(c: CallbackQuery):
    if not await _is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        question_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("رکورد مبدأ معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        question = await session.get(Question, question_id, with_for_update=True)
        if not question or not question.submitted_by:
            return await c.answer("پیشنهاد در دسترس نیست.", show_alert=True)
        user = await session.get(User, question.submitted_by)
        if not user:
            return await c.answer("ثبت‌کنندهٔ پیشنهاد در دسترس نیست.", show_alert=True)
        added = await award_once(session, telegram_id=user.telegram_id,
                                 points=await xp_value(session, "recognized_contribution"),
                                 award_type="recognized_contribution",
                                 award_key=f"recognized-question:{question.id}", source_id=str(question.id),
                                 note="پیشنهاد مفید تأییدشده توسط مدیر")
        if added:
            profile = await get_or_create_profile(session, user.telegram_id)
            profile.recognized_contributions += 1
        await session.commit()
    await c.answer("امتیاز ثبت شد." if added else "این امتیاز قبلاً ثبت شده است.")
    try:
        await c.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ امتیاز ثبت شد" if added else "✅ امتیاز قبلاً ثبت شده", callback_data="admin:community")],
            [InlineKeyboardButton(text="🔙 بازگشت به پیشنهادها", callback_data="admin:questions")],
        ]))
    except Exception:
        pass

