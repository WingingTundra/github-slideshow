from __future__ import annotations

from html import escape
from decimal import Decimal
import json
from urllib.parse import quote
import hashlib
import logging
import secrets
import csv
import asyncio
from datetime import timedelta
from pathlib import Path

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, CopyTextButton, FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import selectinload

from app.bot.handlers.admin_utils import (
    all_bot_users,
    download_file,
    is_valid_url,
    resolve_upload_path,
    safe_pdf_filename,
)
from app.bot.file_validation import file_content_matches, is_pdf_document, is_text_document
from app.bot.callback_validation import positive_callback_id
from app.bot.text_limits import limit_telegram_html
from app.bot.keyboards import (
    admin_event_menu,
    admin_event_field_edit_keyboard,
    admin_event_field_edit_confirm_keyboard,
    admin_event_creation_step_keyboard,
    admin_menu,
    admin_user_access_keyboard,
    admin_block_input_keyboard,
    admin_block_user_confirmation_keyboard,
    admin_unblock_user_confirmation_keyboard,
    back_menu,
    archive_confirm_keyboard,
    channel_updates_keyboard,
    event_creation_choice_keyboard,
    alternative_price_keyboard,
    host_event_creation_choice_keyboard,
    final_panel_state_keyboard,
    payment_review_keyboard,
    questions_input_keyboard,
    questions_replace_keyboard,
    discount_manage_keyboard,
    discount_cancel_keyboard,
    discount_event_picker_keyboard,
    discount_usage_policy_keyboard,
    discount_max_uses_keyboard,
    admin_discount_request_keyboard,
    admin_discount_disable_keyboard,
    discount_request_user_keyboard,
    personal_reward_keyboard,
    channel_link_replacement_keyboard,
    group_link_session_keyboard,
    group_link_replacement_keyboard,
    bulk_reward_entry_keyboard,
    bulk_reward_preview_keyboard,
    bulk_reward_result_keyboard,
    admin_settings_keyboard, admin_settings_hub_keyboard, admin_content_hub_keyboard,
    admin_reports_hub_keyboard, admin_settings_cancel_keyboard,
    admin_settings_link_confirm_keyboard, admin_settings_card_confirm_keyboard,
)
from app.bot.states import AdminBlockStates, AdminChannelStates, BookingStates, NavigationStates, DiscountAdminStates, AdminEditStates, AdminQuickEditStates, AdminEventStates, AdminManageStates, BulkRewardStates, AdminSettingsStates, CancellationCaseStates
from app.bot.validation import is_link_like_text, normalize_display_time, normalize_panel_language, normalize_volume_label, parse_full_name, parse_integer
from app.config import settings
from app.display_utils import has_end_time_label, volume_label, admin_status_display_label, panel_detail_line
from app.services.host_submission_review import bump_submission_revision
from app.db.models import (
    AdminAction,
    AttendanceStatus,
    AnnouncementBroadcast,
    AnnouncementDelivery,
    AdminAnnouncement,
    PanelAnnouncementPost,
    BlockedUser,
    DiscountCode,
    DiscountCodeEvent,
    DiscountRedemption,
    Booking,
    ChannelAnnouncement,
    PanelPostLinkSession,
    RewardBatch,
    RewardBatchRecipient,
    Event,
    EventStatus,
    Payment,
    PaymentStatus,
    Participant,
    Question,
    Review,
    RegistrationStatus,
    User,
    UserRole,
    WaitlistEntry,
    XPAward,
)
from app.db.session import SessionLocal
from app.services.announcements import broadcast, send_announcement_to_user
from app.services.referral_export import build_referral_report_xlsx
from app.services.booking import booking_contact_phone, expire_old_bookings
from app.services.pricing import panel_price_label, booking_option_detail_label
from app.services.excel_export import build_attendee_workbook
from app.services.registered_users_export import (
    build_completed_user_profiles_workbook, completed_user_profiles_statement,
)
from app.services.app_settings import (CHANNEL_UPDATE_THRESHOLD, CHANNEL_UPDATES_ENABLED, get_channel_updates_config, set_setting, get_bot_settings, validate_admin_setting_value)
from app.services.channel_status import reconcile_all_channel_statuses, reconcile_event_channel_status, connect_event_post, validate_post_destination
from app.services.payment_review import receipt_review_token
from app.services.admin_panel_display import format_manage_event_text
from app.services.events import (
    announcement_events_statement,
    apply_capacity_change,
    display_status,
    publish_event,
    registration_is_open,
    seats_used,
)
from app.services.waitlist import (
    WAITLIST_INVITATION_TTL, next_waitlist_candidate, notify_waitlist_capacity_available,
    record_waitlist_invitation_result,
)
from app.time_utils import utc_now_naive
from app.services.user_access import parse_telegram_numeric_id, is_telegram_id_blocked
from app.services.admin_audit import write_admin_action, format_admin_action_log
from app.services.financial_reconciliation_export import build_financial_reconciliation_workbook
from app.services.bulk_rewards import parse_manual_recipients, parse_uploaded_recipients, MAX_BULK_FILE_BYTES
from app.services.discounts import (
    summarize_redemption_counts,
    code_format_help, code_label, discount_display, normalize_code,
    parse_public_code_definition, parse_personal_discount_value,
    detach_event_discount_codes, reactivate_inactive_discount_code,
    purge_inactive_discount_codes,
)

router = Router()
logger = logging.getLogger(__name__)
EVENT_ADMIN_PAGE_SIZE = 7
ANNOUNCEMENT_PAGE_SIZE = 7
REVIEW_LIST_PAGE_SIZE = 7


def _discount_event_label(event: Event) -> str:
    """Describe a code's eligible panel and make unpublished rewards clear as upcoming."""
    label = f"{volume_label(event.volume)} — {event.title}"
    if event.status == EventStatus.DRAFT:
        return f"{label} (پنل آینده · پیش‌نویس)"
    return f"{label} (منتشرشده)"


def booking_status_label(status: RegistrationStatus) -> str:
    """Concise English label for an internal booking state in admin views."""
    labels = {
        RegistrationStatus.INITIATED: "در حال تکمیل",
        RegistrationStatus.WAITLISTED: "در صف انتظار",
        RegistrationStatus.PENDING_PAYMENT: "در انتظار پرداخت",
        RegistrationStatus.PENDING_VERIFICATION: "در انتظار بررسی رسید",
        RegistrationStatus.CONFIRMED: "تأییدشده",
        RegistrationStatus.REJECTED: "رسید ردشده",
        RegistrationStatus.EXPIRED: "مهلت پرداخت به پایان رسیده",
        RegistrationStatus.CANCELLED: "لغوشده",
    }
    return labels.get(status, admin_status_display_label(status))


async def read_callback_id(c: CallbackQuery, label: str = "شناسه") -> int | None:
    value = positive_callback_id(c.data)
    if value is None:
        await c.answer(f"{label} نامعتبر است؛ دوباره از منو انتخاب کنید.", show_alert=True)
    return value


async def expire_event_bookings_best_effort(session, event_id: int) -> set[int]:
    """Refresh expired holds without allowing a maintenance error to hide valid rows."""
    try:
        affected = await expire_old_bookings(session, event_id=event_id)
        if affected:
            await session.commit()
        return affected
    except Exception:
        await session.rollback()
        logger.exception("Could not refresh expired reservations before admin event view; event_id=%s", event_id)
        return set()


# Authorization is deliberately checked server-side on every admin callback.
def is_super_admin(tg_id: int) -> bool:
    return tg_id in settings.super_admin_id_set


async def ensure_admin_user(tg_id: int, telegram_username: str | None = None) -> User:
    async with SessionLocal() as session:
        user = (await session.execute(select(User).where(User.telegram_id == tg_id))).scalar_one_or_none()
        if user is None:
            user = User(telegram_id=tg_id, telegram_username=telegram_username, role=UserRole.SUPER_ADMIN)
            session.add(user)
        else:
            user.role = UserRole.SUPER_ADMIN
            if telegram_username:
                user.telegram_username = telegram_username
        await session.commit()
        await session.refresh(user)
        return user


async def is_admin(tg_id: int) -> bool:
    """Canonical no-cache owner/Admin authorization with block/suspension enforcement."""
    tg_id = int(tg_id)
    if tg_id in settings.super_admin_id_set:
        # Keep the legacy owner-account repair behavior, but avoid a write/commit on
        # every authorized callback when the protected owner row is already correct.
        async with SessionLocal() as session:
            role = await session.scalar(select(User.role).where(User.telegram_id == tg_id))
        if role != UserRole.SUPER_ADMIN:
            await ensure_admin_user(tg_id)
        return True
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(tg_id)




async def is_host(tg_id: int) -> bool:
    """Canonical host-role check with current restrictions applied."""
    from app.services.authorization import is_host_telegram_id
    return await is_host_telegram_id(int(tg_id))


async def get_event(event_id: int) -> Event | None:
    async with SessionLocal() as session:
        return await session.get(Event, event_id)



async def render_event(c: CallbackQuery, event_id: int, *, answer_callback: bool = True):
    event = await get_event(event_id)
    if not event:
        if answer_callback:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        return
    async with SessionLocal() as session:
        used = await seats_used(session, event.id)
        booking_count = int((await session.execute(
            select(func.count(Booking.id)).where(Booking.event_id == event.id)
        )).scalar_one())
    status = display_status(event, used)
    registration_ready = registration_is_open(event)
    text = format_manage_event_text(event, used)
    keyboard = admin_event_menu(
        event.id, event.status.value, status.value, registration_ready,
        bool(event.archived), bool(event.waitlist_enabled), bool(booking_count),
    )
    if event.map_url:
        keyboard.inline_keyboard.insert(0, [InlineKeyboardButton(text="📍 مشاهده موقعیت", url=event.map_url)])
    await c.message.edit_text(limit_telegram_html(text), reply_markup=keyboard, disable_web_page_preview=True)
    if answer_callback:
        await c.answer()


async def _request_admin_navigation_confirmation(target: Message | CallbackQuery, state: FSMContext) -> bool:
    """Do not let a stale admin-menu action erase an unfinished multi-step form."""
    current_state = await state.get_state()
    if not current_state:
        return False
    data = await state.get_data()
    if current_state == BookingStates.waiting_receipt.state and data.get("booking_id"):
        text = "رسید رزرو همچنان منتظر دریافت است. برای ادامه، رسید را ارسال کنید؛ برای لغو همان رزرو /cancel را بزنید."
        markup = None
    else:
        if current_state != NavigationStates.confirm_discard.state:
            await state.update_data(_navigation_saved_state=current_state)
            await state.set_state(NavigationStates.confirm_discard)
        text = (
            "⚠️ یک فرایند ناتمام دارید. ادامهٔ فرایند را انتخاب کنید یا با تأیید صریح، فقط اطلاعات موقت فرم را کنار بگذارید.\n"
            "رزروها، پرداخت‌ها، XP و پنل‌های ثبت‌شده حذف نمی‌شوند."
        )
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="↩️ ادامهٔ فرایند", callback_data="navigation:discard:continue")],
            [InlineKeyboardButton(text="لغو فرایند", callback_data="navigation:discard:confirm")],
        ])
    if isinstance(target, CallbackQuery):
        if target.message:
            await target.message.edit_text(text, reply_markup=markup)
        await target.answer()
    else:
        await target.answer(text, reply_markup=markup)
    return True


@router.message(Command("admin"))
async def admin_cmd(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    if await _request_admin_navigation_confirmation(message, state):
        return
    await message.answer("<b>داشبورد مدیریتی Panel Flow</b>", reply_markup=admin_menu())


@router.callback_query(F.data == "admin:settings:hub")
async def admin_settings_hub(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text("<b>⚙️ تنظیمات و مدیریت ربات</b>\n\nتنظیمات اجرایی، نقش‌ها و دسترسی‌ها در بخش‌های زیر گروه‌بندی شده‌اند.", reply_markup=admin_settings_hub_keyboard())
    await c.answer()


@router.callback_query(F.data == "admin:content:hub")
async def admin_content_hub(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text("<b>👥 مشارکت و بازخورد کاربران</b>", reply_markup=admin_content_hub_keyboard())
    await c.answer()


@router.callback_query(F.data == "admin:reports:hub")
async def admin_reports_hub(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text("<b>📊 گزارش‌ها و خروجی‌ها</b>", reply_markup=admin_reports_hub_keyboard())
    await c.answer()


@router.callback_query(F.data == "admin:home")
async def admin_home(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await _request_admin_navigation_confirmation(c, state):
        return
    await c.message.edit_text("<b>داشبورد مدیریتی Panel Flow</b>", reply_markup=admin_menu())
    await c.answer()


# --- Admin-only user access moderation ---------------------------------------

BLOCKED_USERS_PAGE_SIZE = 6


async def _protected_admin_target(telegram_id: int) -> bool:
    """Never let legacy access controls block the owner or a persistent Admin."""
    telegram_id = int(telegram_id)
    if telegram_id in settings.super_admin_id_set:
        return True
    async with SessionLocal() as session:
        role = await session.scalar(select(User.role).where(User.telegram_id == telegram_id))
        return role == UserRole.SUPER_ADMIN


def _registered_user_summary(user: User | None, telegram_id: int) -> str:
    lines = [f"شناسه تلگرام: <code>{telegram_id}</code>"]
    if user is None:
        lines.append("این شناسه هنوز در کاربران ثبت‌شدهٔ ربات دیده نمی‌شود؛ می‌توانید پیشاپیش مسدودش کنید.")
        return "\n".join(lines)
    name = user.display_name or " ".join(part for part in (user.first_name, user.last_name) if part) or "—"
    lines.append(f"نام ثبت‌شده: {escape(name)}")
    if user.telegram_username:
        lines.append(f"نام کاربری: @{escape(user.telegram_username)}")
    return "\n".join(lines)


async def _render_blocked_users(c: CallbackQuery, page: int) -> None:
    page = max(0, page)
    async with SessionLocal() as session:
        total = int((await session.execute(select(func.count()).select_from(BlockedUser))).scalar_one())
        last_page = max(0, (total - 1) // BLOCKED_USERS_PAGE_SIZE)
        page = min(page, last_page)
        rows = (await session.execute(
            select(BlockedUser)
            .order_by(BlockedUser.blocked_at.desc(), BlockedUser.telegram_id.desc())
            .offset(page * BLOCKED_USERS_PAGE_SIZE)
            .limit(BLOCKED_USERS_PAGE_SIZE)
        )).scalars().all()

    if not rows:
        await c.message.edit_text(
            "📋 <b>کاربران مسدودشده</b>\n\nفعلاً کاربری مسدود نشده است.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🚫 مسدود کردن با شناسه تلگرام", callback_data="admin:users:block")],
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:users:manage")],
            ]),
        )
        await c.answer()
        return

    text_lines = ["📋 <b>کاربران مسدودشده</b>", f"صفحه {page + 1} از {last_page + 1}", ""]
    buttons = []
    for blocked in rows:
        stamp = blocked.blocked_at.strftime("%Y-%m-%d %H:%M") if blocked.blocked_at else "—"
        text_lines.append(f"• <code>{blocked.telegram_id}</code> · {stamp} · مدیر <code>{blocked.blocked_by_telegram_id}</code>")
        buttons.append([InlineKeyboardButton(
            text=f"✅ رفع مسدودیت · {blocked.telegram_id}",
            callback_data=f"admin:users:unblock:{blocked.telegram_id}:{page}",
        )])
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:users:blocked:page:{page - 1}"))
    if page < last_page:
        navigation.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:users:blocked:page:{page + 1}"))
    if navigation:
        buttons.append(navigation)
    buttons.append([InlineKeyboardButton(text="🚫 مسدود کردن کاربر", callback_data="admin:users:block")])
    buttons.append([InlineKeyboardButton(text="🔙 بازگشت به مدیریت دسترسی", callback_data="admin:users:manage")])
    await c.message.edit_text("\n".join(text_lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
    await c.answer()


@router.callback_query(F.data == "admin:users:manage")
async def admin_user_access_menu(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text(
        "🚫 <b>مدیریت دسترسی کاربران</b>\n\n"
        "با شناسهٔ عددی تلگرام می‌توانید دسترسی یک حساب را مسدود یا بعداً آزاد کنید.\n"
        "مسدودسازی، رزروها و سوابق پرداخت را حذف نمی‌کند. برای شناسایی دقیق کاربر، از شناسهٔ عددی استفاده کنید؛ نام کاربری به‌تنهایی کافی نیست.",
        reply_markup=admin_user_access_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data == "admin:users:block")
async def admin_block_user_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.set_state(AdminBlockStates.waiting_telegram_id)
    await c.message.edit_text(
        "🚫 <b>مسدود کردن کاربر</b>\n\n"
        "شناسهٔ عددی تلگرام کاربر را ارسال کنید. اعداد فارسی و انگلیسی پذیرفته می‌شوند.\n"
        "نام کاربری مثل <code>@username</code> را وارد نکنید؛ فقط شناسهٔ عددی معتبر است.",
        reply_markup=admin_block_input_keyboard(),
    )
    await c.answer()


@router.message(AdminBlockStates.waiting_telegram_id)
async def admin_block_user_receive_id(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    target_id = parse_telegram_numeric_id(m.text)
    if target_id is None:
        return await m.answer(
            "شناسه معتبر نیست. لطفاً فقط یک شناسهٔ عددی مثبت تلگرام ارسال کنید؛ مثلاً <code>123456789</code>.",
            reply_markup=admin_block_input_keyboard(),
        )
    if await _protected_admin_target(target_id):
        return await m.answer(
            "⛔ این شناسه در فهرست مدیران مجاز است و برای جلوگیری از قفل‌شدن پنل، قابل مسدودشدن نیست. شناسهٔ دیگری وارد کنید.",
            reply_markup=admin_block_input_keyboard(),
        )

    async with SessionLocal() as session:
        existing = await session.get(BlockedUser, target_id)
        target_user = (await session.execute(select(User).where(User.telegram_id == target_id))).scalar_one_or_none()
    await state.clear()
    if existing:
        await m.answer(
            f"ℹ️ این شناسه از قبل مسدود است.\n\n{_registered_user_summary(target_user, target_id)}",
            reply_markup=admin_user_access_keyboard(),
        )
        return
    await m.answer(
        "⚠️ <b>تأیید مسدودسازی</b>\n\n"
        f"{_registered_user_summary(target_user, target_id)}\n\n"
        "این حساب از تعامل با ربات منع می‌شود؛ اطلاعات رزرو یا پرداخت آن حذف نخواهد شد. آیا ادامه می‌دهید؟",
        reply_markup=admin_block_user_confirmation_keyboard(target_id),
    )


@router.callback_query(F.data.regexp(r"^admin:users:block:confirm:\d+$"))
async def admin_block_user_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    target_id = parse_telegram_numeric_id(c.data.rsplit(":", 1)[1] if c.data else None)
    if target_id is None:
        return await c.answer("شناسه نامعتبر است؛ از منو دوباره اقدام کنید.", show_alert=True)
    if await _protected_admin_target(target_id):
        return await c.answer("شناسه مدیران مجاز قابل مسدودشدن نیست.", show_alert=True)
    try:
        async with SessionLocal() as session:
            result = await session.execute(
                pg_insert(BlockedUser).values(
                    telegram_id=target_id,
                    blocked_by_telegram_id=c.from_user.id,
                    blocked_at=utc_now_naive(),
                ).on_conflict_do_nothing(index_elements=[BlockedUser.telegram_id])
            )
            inserted = bool(result.rowcount)
            if inserted:
                await write_admin_action(session, actor_telegram_id=c.from_user.id, action="user_blocked", entity_type="user", entity_id=None, details={"target_telegram_id": target_id})
            await session.commit()
    except Exception:
        logger.exception("Failed to block Telegram user through admin panel")
        return await c.answer("مسدودسازی انجام نشد. اتصال پایگاه داده را بررسی و دوباره تلاش کنید.", show_alert=True)

    if inserted:
        result_text = (
            f"✅ دسترسی شناسهٔ <code>{target_id}</code> مسدود شد.\n\n"
            "این کار در تعامل بعدی کاربر با ربات اعمال می‌شود و هیچ رزرو یا سابقهٔ پرداختی حذف نشده است."
        )
    else:
        result_text = f"ℹ️ شناسهٔ <code>{target_id}</code> از قبل مسدود بوده است؛ تغییری لازم نبود."
    await c.message.edit_text(result_text, reply_markup=admin_user_access_keyboard())
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:users:blocked:page:\d+$"))
async def admin_blocked_users_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    raw_page = c.data.rsplit(":", 1)[1] if c.data else "0"
    await _render_blocked_users(c, int(raw_page))


@router.callback_query(F.data.regexp(r"^admin:users:unblock:\d+:\d+$"))
async def admin_unblock_user_start(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    target_id = parse_telegram_numeric_id(parts[-2])
    page = int(parts[-1])
    if target_id is None:
        return await c.answer("شناسه نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        record = await session.get(BlockedUser, target_id)
    if record is None:
        return await c.answer("این شناسه دیگر در فهرست مسدودها نیست.", show_alert=True)
    await c.message.edit_text(
        "✅ <b>تأیید رفع مسدودیت</b>\n\n"
        f"شناسهٔ تلگرام: <code>{target_id}</code>\n"
        "با تأیید، کاربر می‌تواند دوباره از ربات استفاده کند. ادامه می‌دهید؟",
        reply_markup=admin_unblock_user_confirmation_keyboard(target_id, page),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:users:unblock:confirm:\d+:\d+$"))
async def admin_unblock_user_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    target_id = parse_telegram_numeric_id(parts[-2])
    page = int(parts[-1])
    if target_id is None:
        return await c.answer("شناسه نامعتبر است.", show_alert=True)
    try:
        async with SessionLocal() as session:
            result = await session.execute(delete(BlockedUser).where(BlockedUser.telegram_id == target_id))
            deleted = bool(result.rowcount)
            if deleted:
                await write_admin_action(session, actor_telegram_id=c.from_user.id, action="user_unblocked", entity_type="user", entity_id=None, details={"target_telegram_id": target_id})
            await session.commit()
    except Exception:
        logger.exception("Failed to unblock Telegram user through admin panel")
        return await c.answer("رفع مسدودیت انجام نشد. لطفاً دوباره تلاش کنید.", show_alert=True)
    if deleted:
        message = f"✅ مسدودیت شناسهٔ <code>{target_id}</code> برداشته شد."
    else:
        message = f"ℹ️ شناسهٔ <code>{target_id}</code> از قبل در فهرست مسدودها نبود."
    await c.message.edit_text(message, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 بازگشت به فهرست مسدودها", callback_data=f"admin:users:blocked:page:{page}")],
        [InlineKeyboardButton(text="🚫 مدیریت دسترسی کاربران", callback_data="admin:users:manage")],
    ]))
    await c.answer()


async def _creation_prompt(message: Message, state: FSMContext, text: str, reply_markup=None):
    """Send each wizard step as a fresh message with instance-bound controls."""
    current = await state.get_state()
    data = await state.get_data()
    wizard_id = str(data.get("event_creation_token") or secrets.token_hex(16))
    if not data.get("event_creation_token"):
        await state.update_data(event_creation_token=wizard_id)
        data["event_creation_token"] = wizard_id
    if current == AdminEventStates.questions_pdf.state:
        markup = questions_input_keyboard(wizard_id)
    elif current == AdminEventStates.confirm.state:
        # Keep the Reply Keyboard Back/Cancel controls visible while the preview
        # carries only the primary Draft/Publish actions as inline buttons.
        creator_id = data.get("creator_telegram_id")
        is_host_creator = bool(creator_id and await is_host(int(creator_id)))
        markup = host_event_creation_choice_keyboard(wizard_id) if is_host_creator else event_creation_choice_keyboard(wizard_id)
    else:
        markup = admin_event_creation_step_keyboard(
            show_back=current != AdminEventStates.volume.state, wizard_id=wizard_id
        )
    sent = await message.answer(text, reply_markup=markup, disable_web_page_preview=True)
    await state.update_data(event_creation_prompt_message_id=int(sent.message_id))
    return int(sent.message_id)


async def _creation_retry(message: Message, state: FSMContext, text: str):
    """Keep current-step Back/Cancel controls after invalid input."""
    return await _creation_prompt(message, state, text)


async def _validate_creation_callback(c: CallbackQuery, state: FSMContext) -> bool:
    token = str((c.data or "").rsplit(":", 1)[-1])
    data = await state.get_data()
    if data.get("event_creation_token") != token:
        await c.answer("این دکمه مربوط به یک فرایند قبلی است؛ از آخرین پیام ربات استفاده کنید.", show_alert=True)
        return False
    expected_message_id = int(data.get("event_creation_prompt_message_id") or 0)
    clicked_message_id = int(getattr(c.message, "message_id", 0) or 0)
    if not expected_message_id or clicked_message_id != expected_message_id:
        await c.answer("این دکمه مربوط به مرحلهٔ قبلی است؛ از آخرین پیام ربات استفاده کنید.", show_alert=True)
        return False
    creator_id = int(data.get("creator_telegram_id") or 0)
    if creator_id and creator_id != int(c.from_user.id):
        await c.answer("این فرایند متعلق به حساب دیگری است.", show_alert=True)
        return False
    current = await state.get_state()
    if not current or not current.startswith("AdminEventStates:"):
        await c.answer("فرایند ایجاد پنل دیگر فعال نیست.", show_alert=True)
        return False
    return True


@router.callback_query(F.data == "admin:event:create")
async def create_event_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state():
        return await c.answer("یک فرایند فعال دارید؛ ابتدا آن را تکمیل یا با /cancel لغو کنید.", show_alert=True)
    await state.clear()
    await state.update_data(event_creation_token=secrets.token_hex(16))
    await state.set_state(AdminEventStates.volume)
    prompt = (
        "شماره یا نام Volume را به انگلیسی وارد کنید.\n\n"
        "مثال: 21، Movie Night یا Nature.\n\n"
        "فقط حروف انگلیسی، عدد، فاصله و خط تیره بین کلمات مجاز است."
    )
    await _creation_prompt(c.message, state, prompt)
    await c.answer()


async def _creation_step_back(target: Message, state: FSMContext) -> bool:
    """Move one step back without discarding any previously entered wizard values."""
    current = await state.get_state()
    data = await state.get_data()
    previous = {
        AdminEventStates.title.state: AdminEventStates.volume,
        AdminEventStates.language.state: AdminEventStates.title,
        AdminEventStates.description.state: AdminEventStates.language,
        AdminEventStates.day_name.state: AdminEventStates.description,
        AdminEventStates.date_text.state: AdminEventStates.day_name,
        AdminEventStates.start_time.state: AdminEventStates.date_text,
        AdminEventStates.end_time.state: AdminEventStates.start_time,
        AdminEventStates.venue.state: AdminEventStates.end_time,
        AdminEventStates.address.state: AdminEventStates.venue,
        AdminEventStates.map_url.state: AdminEventStates.address,
        AdminEventStates.capacity.state: AdminEventStates.map_url,
        AdminEventStates.price.state: AdminEventStates.capacity,
        AdminEventStates.alternative_price.state: AdminEventStates.price,
        AdminEventStates.waitlist.state: AdminEventStates.alternative_price if int(data.get("price") or 0) > 0 else AdminEventStates.price,
        AdminEventStates.host.state: AdminEventStates.waitlist,
        AdminEventStates.questions_pdf.state: AdminEventStates.waitlist if data.get("creator_telegram_id") else AdminEventStates.host,
        AdminEventStates.confirm.state: AdminEventStates.questions_pdf,
    }
    destination = previous.get(current)
    if destination is None:
        return False
    prompts = {
        AdminEventStates.volume.state: ("شماره یا نام Volume را به انگلیسی وارد کنید. مثال: 21، Movie Night یا Nature.", "volume"),
        AdminEventStates.title.state: ("عنوان انگلیسی پنل را وارد کنید:", "title"),
        AdminEventStates.language.state: ("زبان پنل را وارد کنید. مثال: English، فارسی یا Français.", "language"),
        AdminEventStates.description.state: ("توضیحات پنل را وارد کنید؛ برای نداشتن توضیحات - بفرستید:", "description"),
        AdminEventStates.day_name.state: ("نام روز نمایشی پنل را وارد کنید؛ مانند «پنجشنبه» یا Thursday.", "day_name"),
        AdminEventStates.date_text.state: ("تاریخ نمایشی را وارد کنید. مثال: 15 October 2026", "date_text"),
        AdminEventStates.start_time.state: ("زمان شروع را با فرمت HH:MM وارد کنید. مثال: 16:30", "start_time"),
        AdminEventStates.end_time.state: ("چه زمانی پنل تمام می‌شود؟\nفرمت: HH:MM\nمثال: 18:30\nاگر زمان پایان مشخص نیست، فقط - بفرستید.", "end_time"),
        AdminEventStates.venue.state: ("نام محل برگزاری را وارد کنید:", "venue"),
        AdminEventStates.address.state: ("آدرس متنی محل را وارد کنید یا - بفرستید:", "address"),
        AdminEventStates.map_url.state: ("لینک نقشهٔ HTTP(S) را وارد کنید یا - بفرستید:", "map_url"),
        AdminEventStates.capacity.state: ("ظرفیت را به تعداد نفرات وارد کنید:", "capacity"),
        AdminEventStates.price.state: ("قیمت پایه هر نفر را به تومان وارد کنید؛ برای رایگان 0 بفرستید:", "price"),
        AdminEventStates.alternative_price.state: ("قیمت کامل ثبت‌نام بدون سفارش اجباری از منوی کافه را به تومان وارد کنید. مبلغ باید از قیمت پایه بیشتر باشد.\n\nبرای غیرفعال‌کردن این گزینه، فقط «-» یا «0» بفرستید.", "price_without_cafe_order"),
        AdminEventStates.waitlist.state: ("لیست انتظار فعال باشد؟ «بله» یا «خیر»:", "waitlist"),
        AdminEventStates.host.state: ("نام و نام خانوادگی میزبان را وارد کنید:", "host_name"),
        AdminEventStates.questions_pdf.state: ("فایل سؤالات پنل را به‌صورت PDF یا TXT ارسال کنید.\nاگر فایلی ندارید، فقط علامت «-» را بفرستید.", "questions_file_name"),
    }
    prompt, key = prompts[destination.state]
    current_value = data.get(key)
    if current_value not in (None, ""):
        shown = str(current_value).replace("\n", " ")
        if len(shown) > 80:
            shown = shown[:77] + "…"
        prompt += f"\n\nمقدار ثبت‌شده: <code>{escape(shown)}</code>"
    await state.set_state(destination)
    await _creation_prompt(target, state, prompt)
    return True


async def _cancel_creation_flow(target: Message, state: FSMContext, actor_id: int) -> None:
    data = await state.get_data()
    creator_id = int(data.get("creator_telegram_id") or 0)
    if creator_id and creator_id != int(actor_id):
        await target.answer("این فرایند متعلق به حساب دیگری است.")
        return
    admin_actor = await is_admin(actor_id)
    await state.clear()
    from aiogram.types import ReplyKeyboardRemove
    await target.answer("ایجاد پنل لغو شد؛ هیچ پنلی ذخیره یا منتشر نشد." if admin_actor else "ایجاد پیش‌نویس لغو شد؛ هیچ پنلی ذخیره یا ارسال نشد.", reply_markup=ReplyKeyboardRemove())
    if admin_actor:
        await target.answer("منوی مدیریت", reply_markup=admin_menu())
    else:
        await target.answer("پنل‌های من", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🎤 پنل‌های من", callback_data="host:home")]]))


async def admin_event_creation_reply_actions(message: Message, state: FSMContext):
    """Handle native Reply Keyboard Back/Cancel controls in the panel wizard."""
    actor_id = int(message.from_user.id)
    if not (await is_admin(actor_id) or await is_host(actor_id)):
        return await message.answer("دسترسی مجاز نیست.")
    data = await state.get_data()
    creator_id = int(data.get("creator_telegram_id") or 0)
    if creator_id and creator_id != actor_id:
        return await message.answer("این فرایند متعلق به حساب دیگری است.")
    if message.text == "⬅️ مرحلهٔ قبل":
        if not await _creation_step_back(message, state):
            await message.answer("برای این مرحله، مرحلهٔ قبلی موجود نیست.")
        return
    await _cancel_creation_flow(message, state, actor_id)


async def expired_panel_creation_reply_actions(message: Message, state: FSMContext):
    """Consume stale panel-wizard Reply Keyboard text without corrupting another FSM."""
    actor_id = int(message.from_user.id)
    if not (await is_admin(actor_id) or await is_host(actor_id)):
        return
    current_state = await state.get_state()
    if current_state and current_state.startswith("AdminEventStates:"):
        # An active wizard should have been handled by the state-specific route above.
        # Do not clear it if router ordering or a future state addition reaches here.
        return await message.answer("فرایند ایجاد پنل همچنان فعال است؛ از آخرین پیام ربات استفاده کنید.")
    from aiogram.types import ReplyKeyboardRemove
    await message.answer(
        "کنترل‌های ایجاد پنل قبلی منقضی شده‌اند. اطلاعات فرایند دیگری، در صورت فعال‌بودن، حفظ شده است.",
        reply_markup=ReplyKeyboardRemove(),
    )
    if current_state:
        return
    if await is_admin(actor_id):
        await message.answer("منوی مدیریت", reply_markup=admin_menu())
    else:
        await message.answer("برای مشاهدهٔ پیش‌نویس‌های خود، دستور /host را ارسال کنید.")


@router.callback_query(F.data.regexp(r"^admin:event:create:back:[0-9a-f]{32}$"))
async def create_event_step_back(c: CallbackQuery, state: FSMContext):
    """Compatibility path for old inline prompts; new prompts use Reply Keyboard."""
    if not (await is_admin(c.from_user.id) or await is_host(c.from_user.id)):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _validate_creation_callback(c, state):
        return
    moved = await _creation_step_back(c.message, state)
    await c.answer("به مرحلهٔ قبل برگشتید." if moved else "برای این مرحله، مرحلهٔ قبلی موجود نیست.", show_alert=not moved)

@router.callback_query(F.data.regexp(r"^admin:event:create:cancel:[0-9a-f]{32}$"))
async def create_event_cancel(c: CallbackQuery, state: FSMContext):
    if not (await is_admin(c.from_user.id) or await is_host(c.from_user.id)):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if not await _validate_creation_callback(c, state):
        return
    await _cancel_creation_flow(c.message, state, int(c.from_user.id))
    await c.answer("لغو شد.")

@router.message(AdminEventStates.volume)
async def create_volume(m: Message, state: FSMContext):
    value = normalize_volume_label(m.text or "")
    if value is None:
        return await _creation_retry(
            m, state,
            "ورودی معتبر نیست. شماره یا نام Volume را به انگلیسی وارد کنید؛ مانند 21، Movie Night یا Nature.\n\n"
            "فقط حروف انگلیسی، عدد، فاصله و خط تیره بین کلمات مجاز است."
        )
    await state.update_data(volume=value)
    await state.set_state(AdminEventStates.title)
    await _creation_prompt(m, state, "عنوان انگلیسی پنل را وارد کنید:")


@router.message(AdminEventStates.title)
async def create_title(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if not value:
        return await _creation_retry(m, state, "عنوان الزامی است؛ لطفاً عنوان را وارد کنید.")
    if value.startswith("/") or "@" in value or is_link_like_text(value):
        return await _creation_retry(m, state, "این ورودی برای عنوان پنل معتبر نیست. دستورها، نام کاربری و لینک را وارد نکنید؛ فقط عنوان پنل را بنویسید.")
    if len(value) > 255:
        return await _creation_retry(m, state, "عنوان حداکثر ۲۵۵ کاراکتر می‌تواند باشد.")
    await state.update_data(title=value)
    await state.set_state(AdminEventStates.language)
    await _creation_prompt(m, state, "زبان پنل را وارد کنید.\nمثال: English، فارسی یا Français.")


@router.message(AdminEventStates.language)
async def create_language(m: Message, state: FSMContext):
    value = normalize_panel_language(m.text or "")
    if value is None:
        return await _creation_retry(
            m, state,
            "زبان پنل معتبر نیست. نام زبان را وارد کنید؛ مانند English، فارسی یا Français.\n"
            "دستور، لینک یا متن دارای نمادهای نامعتبر پذیرفته نمی‌شود."
        )
    await state.update_data(language=value)
    await state.set_state(AdminEventStates.description)
    await _creation_prompt(m, state, "توضیحات پنل را وارد کنید. اگر توضیحی ندارید، - بفرستید:")


@router.message(AdminEventStates.description)
async def create_description(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if not value:
        return await _creation_retry(m, state, "توضیحات نمی‌تواند خالی باشد؛ برای نداشتن توضیحات، - بفرستید:")
    if value != "-" and len(value) > 4000:
        return await _creation_retry(m, state, "توضیحات حداکثر ۴۰۰۰ کاراکتر می‌تواند باشد.")
    await state.update_data(description="" if value == "-" else value)
    await state.set_state(AdminEventStates.day_name)
    await _creation_prompt(m, state, "نام روز نمایشی پنل را وارد کنید؛ مانند «پنجشنبه» یا Thursday.")


@router.message(AdminEventStates.day_name)
async def create_day_name(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if not value:
        return await _creation_retry(m, state, "نام روز الزامی است؛ مانند «پنجشنبه» یا Thursday.")
    if len(value) > 100:
        return await _creation_retry(m, state, "نام روز حداکثر ۱۰۰ کاراکتر می‌تواند باشد.")
    await state.update_data(day_name=value)
    await state.set_state(AdminEventStates.date_text)
    await _creation_prompt(m, state, "تاریخ را همان‌طور که می‌خواهید به کاربران نمایش داده شود وارد کنید. مثال: 15 October 2026")


@router.message(AdminEventStates.date_text)
async def create_date_text(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if not value:
        return await _creation_retry(m, state, "تاریخ نمایشی الزامی است.")
    if len(value) > 255:
        return await _creation_retry(m, state, "متن تاریخ حداکثر ۲۵۵ کاراکتر می‌تواند باشد.")
    await state.update_data(date_text=value)
    await state.set_state(AdminEventStates.start_time)
    await _creation_prompt(m, state, "زمان شروع پنل را وارد کنید.\nفرمت: HH:MM\nمثال: 16:30")


@router.message(AdminEventStates.start_time)
async def create_start_time(m: Message, state: FSMContext):
    value = normalize_display_time((m.text or "").strip())
    if value is None:
        return await _creation_retry(m, state, "زمان شروع نامعتبر است. لطفاً با فرمت HH:MM وارد کنید؛ مثلاً 16:30.")
    await state.update_data(start_time=value)
    await state.set_state(AdminEventStates.end_time)
    await _creation_prompt(m, state, "چه زمانی پنل تمام می‌شود؟\nفرمت: HH:MM\nمثال: 18:30\nاگر نمی‌خواهید زمان پایان مشخص شود، فقط - بفرستید.")


@router.message(AdminEventStates.end_time)
async def create_end_time(m: Message, state: FSMContext):
    raw = (m.text or "").strip()
    if raw == "-":
        value = "-"
    else:
        value = normalize_display_time(raw)
        if value is None:
            return await _creation_retry(m, state, "زمان پایان نامعتبر است. لطفاً با فرمت HH:MM وارد کنید؛ مثلاً 18:30، یا برای بدون زمان پایان - بفرستید.")
    await state.update_data(end_time=value)
    await state.set_state(AdminEventStates.venue)
    await _creation_prompt(m, state, "نام محل برگزاری را وارد کنید:")


@router.message(AdminEventStates.venue)
async def create_venue(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if not value:
        return await _creation_retry(m, state, "نام محل الزامی است.")
    if len(value) > 255:
        return await _creation_retry(m, state, "نام محل حداکثر ۲۵۵ کاراکتر می‌تواند باشد.")
    if is_link_like_text(value):
        return await _creation_retry(
            m, state,
            "❌ این قسمت برای نام و آدرس متنی محل برگزاری است، نه لینک.\n"
            "لطفاً آدرس یا نام محل را به‌صورت متنی وارد کنید.\n"
            "لینک مکان در مرحله بعد از شما دریافت می‌شود."
        )
    await state.update_data(venue=value)
    await state.set_state(AdminEventStates.address)
    await _creation_prompt(m, state, "آدرس کامل را وارد کنید یا - بفرستید:")


@router.message(AdminEventStates.address)
async def create_address(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-" and not value:
        return await _creation_retry(m, state, "آدرس نمی‌تواند خالی باشد؛ آدرس کامل را وارد کنید یا - بفرستید.")
    if value != "-" and len(value) > 500:
        return await _creation_retry(m, state, "آدرس حداکثر ۵۰۰ کاراکتر می‌تواند باشد.")
    if value != "-" and is_link_like_text(value):
        return await _creation_retry(
            m, state,
            "❌ این قسمت برای نام و آدرس متنی محل برگزاری است، نه لینک.\n"
            "لطفاً آدرس یا نام محل را به‌صورت متنی وارد کنید.\n"
            "لینک مکان در مرحله بعد از شما دریافت می‌شود."
        )
    await state.update_data(address="" if value == "-" else value)
    await state.set_state(AdminEventStates.map_url)
    await _creation_prompt(m, state, "لینک نقشه را وارد کنید (https://...) یا - بفرستید:")


@router.message(AdminEventStates.map_url)
async def create_map_url(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-" and not is_valid_url(value):
        return await _creation_retry(m, state, "یک URL معتبر و کامل با http یا https وارد کنید؛ مثال: https://maps.google.com/...")
    if value != "-" and len(value) > 1000:
        return await _creation_retry(m, state, "لینک نقشه بیش از حد طولانی است؛ لطفاً لینک کوتاه‌تری وارد کنید.")
    await state.update_data(map_url="" if value == "-" else value)
    await state.set_state(AdminEventStates.capacity)
    await _creation_prompt(m, state, "ظرفیت را به تعداد نفرات وارد کنید:")


@router.message(AdminEventStates.capacity)
async def create_capacity(m: Message, state: FSMContext):
    value = parse_integer(m.text or "", minimum=1, maximum=100000)
    if value is None:
        return await _creation_retry(m, state, "ظرفیت باید عدد صحیحی بین ۱ تا ۱۰۰٬۰۰۰ باشد.")
    await state.update_data(capacity=value)
    await state.set_state(AdminEventStates.price)
    await _creation_prompt(m, state, "قیمت هر نفر به تومان را وارد کنید؛ برای رایگان 0 بفرستید:")


@router.message(AdminEventStates.price)
async def create_price(m: Message, state: FSMContext):
    value = parse_integer(m.text or "", minimum=0, maximum=1000000000)
    if value is None:
        return await _creation_retry(m, state, "قیمت باید عدد صحیحی بین صفر تا ۱٬۰۰۰٬۰۰۰٬۰۰۰ تومان باشد.")
    await state.update_data(price=value, price_without_cafe_order=None)
    if value > 0:
        await state.set_state(AdminEventStates.alternative_price)
        await _creation_prompt(
            m, state,
            "قیمت کامل ثبت‌نام بدون سفارش اجباری از منوی کافه را به تومان وارد کنید. مبلغ باید از قیمت پایه بیشتر باشد.\n\n"
            "برای غیرفعال‌کردن این گزینه، فقط «-» یا «0» بفرستید.",
            reply_markup=admin_event_creation_step_keyboard(show_back=True),
        )
        return
    await state.set_state(AdminEventStates.waitlist)
    await _creation_prompt(m, state, "پنل رایگان است؛ گزینهٔ بدون سفارش کافه برای پنل رایگان فعال نمی‌شود.\nلیست انتظار فعال باشد؟ «بله» یا «خیر»:")


@router.message(AdminEventStates.alternative_price)
async def create_alternative_price(m: Message, state: FSMContext):
    raw = (m.text or "").strip()
    data = await state.get_data()
    base = int(data.get("price") or 0)
    if raw in {"—", "-", "–", "0", "۰"}:
        alternative = None
    else:
        parsed = parse_integer(raw, minimum=0, maximum=1000000000)
        if parsed is None:
            return await _creation_retry(m, state, "قیمت را به‌صورت عدد وارد کنید یا برای غیرفعال‌کردن گزینه «-» یا «0» بفرستید.")
        alternative = parsed or None
        if alternative is not None and alternative <= base:
            return await _creation_retry(m, state, "این مبلغ باید از قیمت پایه بیشتر باشد. عدد دیگری وارد کنید یا برای غیرفعال‌کردن «-» یا «0» بفرستید.")
    await state.update_data(price_without_cafe_order=alternative)
    await state.set_state(AdminEventStates.waitlist)
    await _creation_prompt(m, state, "لیست انتظار فعال باشد؟ «بله» یا «خیر»:")


@router.message(AdminEventStates.waitlist)
async def create_waitlist(m: Message, state: FSMContext):
    answer = (m.text or "").strip().lower()
    if answer not in {"بله", "خیر", "yes", "no"}:
        return await _creation_retry(m, state, "«بله» یا «خیر» وارد کنید.")
    await state.update_data(waitlist=answer in {"بله", "yes"})
    if await is_host(m.from_user.id):
        async with SessionLocal() as session:
            host_user = (await session.execute(select(User).where(User.telegram_id == int(m.from_user.id)))).scalar_one_or_none()
            host_label = (host_user.display_name or " ".join(x for x in (host_user.first_name, host_user.last_name) if x) or m.from_user.full_name) if host_user else m.from_user.full_name
        await state.update_data(host_name=host_label, creator_telegram_id=int(m.from_user.id))
        await state.set_state(AdminEventStates.questions_pdf)
        await _creation_prompt(m, state, "فایل سؤالات پنل را به‌صورت PDF یا TXT ارسال کنید.\nاگر فایلی ندارید، فقط علامت «-» را بفرستید.", reply_markup=questions_input_keyboard())
        return
    await state.set_state(AdminEventStates.host)
    await _creation_prompt(m, state, "نام و نام خانوادگی میزبان را وارد کنید.\nمثال: سینا ضیائی یا Sarah Williams")


@router.message(AdminEventStates.host)
async def create_host(m: Message, state: FSMContext):
    parsed_host = parse_full_name(m.text or "")
    if parsed_host is None:
        return await _creation_retry(m, state, "لطفاً نام و نام خانوادگی معتبر وارد کنید.\nمثال: سینا ضیائی یا Sarah Williams")
    host_name = " ".join(parsed_host)
    if len(host_name) > 255:
        return await _creation_retry(m, state, "نام میزبان خیلی طولانی است؛ حداکثر ۲۵۵ کاراکتر وارد کنید.")
    await state.update_data(host_name=host_name)
    await state.set_state(AdminEventStates.questions_pdf)
    await _creation_prompt(
        m, state,
        "فایل سؤالات پنل را به‌صورت PDF یا TXT ارسال کنید.\n"
        "اگر فایلی ندارید، فقط علامت «-» را بفرستید.",
        reply_markup=questions_input_keyboard(),
    )


async def _show_creation_confirmation(message: Message, state: FSMContext):
    data = await state.get_data()
    file_label = data.get("questions_file_name") or "ندارد"
    volume = str(data.get("volume") or "—").strip()
    if volume[:1].upper() == "V":
        volume = volume[1:].strip()
    title = escape(str(data.get("title") or "—"))
    description = str(data.get("description") or "").strip()
    end = str(data.get("end_time") or "—")
    time_label = escape(str(data.get("start_time") or "—"))
    if has_end_time_label(end):
        time_label += "–" + escape(end)
    lines = [
        f"<b>{escape(volume_label(volume))}</b>",
        "",
        f"<b>⁦{title}⁩</b>",
    ]
    if description:
        lines.extend(["", "📝 <b>توضیحات</b>", escape(description)])
    lines.extend([
        "",
        panel_detail_line("زبان پنل", escape(str(data.get('language') or '—')), icon="🌐"),
        panel_detail_line("روز و تاریخ", f"{escape(str(data.get('day_name') or '—'))} – {escape(str(data.get('date_text') or '—'))}", icon="📅"),
        panel_detail_line("ساعت", time_label, icon="⏰"),
        panel_detail_line("محل برگزاری", escape(str(data.get('venue') or '—')), icon="📍"),
        panel_detail_line("هزینه", escape(panel_price_label(data.get('price', 0), data.get('price_without_cafe_order'))), icon="💰"),
        panel_detail_line("میزبان", escape(str(data.get('host_name') or '—')), icon="👤"),
        panel_detail_line("ظرفیت", f"۰ / {escape(str(data.get('capacity') or '—'))}", icon="👥"),
    ])
    address = str(data.get("address") or "").strip()
    if address:
        lines.append(panel_detail_line("آدرس", escape(address), icon="📌"))
    map_url = str(data.get("map_url") or "").strip()
    if map_url:
        lines.extend(["", f"🔗 <a href=\"{escape(map_url, quote=True)}\">لینک موقعیت</a>"])
    lines.extend(["", f"📄 <b>فایل سؤالات:</b> {escape(file_label)}", "", "وضعیت اولیه را انتخاب کنید:"])
    preview_text = "\n".join(lines)
    data_actor_id = data.get("creator_telegram_id")
    is_host_creator = bool(data_actor_id and await is_host(int(data_actor_id)))
    await state.set_state(AdminEventStates.confirm)
    await _creation_prompt(
        message, state, limit_telegram_html(preview_text),
        reply_markup=host_event_creation_choice_keyboard() if is_host_creator else event_creation_choice_keyboard(),
    )


@router.message(AdminEventStates.questions_pdf, F.document)
async def create_questions_file(m: Message, state: FSMContext):
    document = m.document
    file_name = (document.file_name or "").lower()
    if not (is_pdf_document(document) or is_text_document(document)):
        return await _creation_retry(m, state, "فقط فایل PDF یا TXT پذیرفته می‌شود؛ برای ادامه بدون فایل، علامت «-» را بفرستید.")
    if document.file_size and document.file_size > settings.max_upload_mb * 1024 * 1024:
        return await _creation_retry(m, state, f"حجم فایل نباید بیشتر از {settings.max_upload_mb} مگابایت باشد.")
    extension = ".pdf" if is_pdf_document(document) else ".txt"
    try:
        stored = await download_file(m.bot, document.file_id, safe_pdf_filename(m.from_user.full_name or "questions").removesuffix(".pdf") + extension, file_size=document.file_size)
    except Exception:
        return await _creation_retry(m, state, "بارگذاری فایل ناموفق بود؛ دوباره تلاش کنید.")
    if Path(stored).stat().st_size > settings.max_upload_mb * 1024 * 1024:
        Path(stored).unlink(missing_ok=True)
        return await _creation_retry(m, state, f"حجم فایل نباید بیشتر از {settings.max_upload_mb} مگابایت باشد.")
    if not file_content_matches(stored, extension):
        Path(stored).unlink(missing_ok=True)
        return await _creation_retry(m, state, "محتوای فایل با فرمت اعلام‌شده مطابقت ندارد؛ PDF یا TXT معتبر ارسال کنید.")
    await state.update_data(questions_path=stored, questions_file_name=document.file_name or Path(stored).name)
    await _show_creation_confirmation(m, state)


@router.message(AdminEventStates.questions_pdf)
async def create_questions_text_or_skip(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        return await _creation_retry(m, state, "فایل PDF یا TXT ارسال کنید؛ برای ایجاد پنل بدون فایل، فقط «-» بفرستید.")
    await state.update_data(questions_path=None, questions_file_name=None)
    await _show_creation_confirmation(m, state)


@router.callback_query(F.data == "admin:event:create:questions:skip")
async def create_questions_skip(c: CallbackQuery, state: FSMContext):
    # Legacy button retained only to fail safely on old Telegram messages.
    return await c.answer("برای ادامه بدون فایل، در مرحلهٔ فعلی فقط علامت «-» را ارسال کنید.", show_alert=True)


async def _finish_event_creation(
    message: Message,
    state: FSMContext,
    action: str,
    actor_telegram_id: int,
    actor_username: str | None,
):
    data = await state.get_data()
    # The caller is already inside the authenticated admin wizard. Do not
    # perform a second role/ownership authorization here. Ensure the acting
    # Telegram account has a concrete User row so host_id is persistable.
    # CallbackQuery.message is authored by the bot; use the clicking admin's identity passed by the callback handler.
    actor = await ensure_admin_user(actor_telegram_id, actor_username)
    creation_token = str(data.get("event_creation_token") or secrets.token_hex(16))
    if not data.get("event_creation_token"):
        await state.update_data(event_creation_token=creation_token)
    async with SessionLocal() as session:
        event = Event(
            volume=str(data["volume"]),
            creation_token=creation_token,
            title=data["title"],
            language=data["language"],
            description=data.get("description") or None,
            event_day_label=data["day_name"],
            event_date_label=data["date_text"],
            start_time_label=data["start_time"],
            end_time_label=data["end_time"],
            venue=data["venue"],
            address=data.get("address") or None,
            map_url=data.get("map_url") or None,
            capacity=int(data["capacity"]),
            price_per_person=int(data["price"]),
            price_without_cafe_order=(int(data["price_without_cafe_order"]) if data.get("price_without_cafe_order") else None),
            status=EventStatus.DRAFT,
            registration_open=False,
            waitlist_enabled=bool(data["waitlist"]),
            questions_pdf_path=data.get("questions_path") or None,
            questions_file_name=data.get("questions_file_name") or None,
            host_name=data["host_name"],
            host_id=actor.id,
        )
        session.add(event)
        if action == "publish":
            try:
                publish_event(event)
            except ValueError:
                return await message.answer("این پنل با اطلاعات فعلی قابل انتشار نیست. برای اصلاح، از دکمهٔ «مرحلهٔ قبل» در کیبورد پایین استفاده کنید.")
        try:
            event_id = int(event.id)
            if action == "publish":
                from app.services.notification_outbox import enqueue_notification_outbox
                await enqueue_notification_outbox(
                    session, dedupe_key=f"panel-published:{event_id}",
                    event_type="panel.published", payload={"event_id": event_id},
                )
            await session.commit()
        except IntegrityError:
            # Two rapid callbacks from the same final wizard prompt can race.
            # The unique creation_token index guarantees only one panel is created.
            await session.rollback()
            token = creation_token
            existing = await session.scalar(select(Event).where(Event.creation_token == token)) if token else None
            if existing is None:
                raise
            from aiogram.types import ReplyKeyboardRemove
            await message.answer("کنترل‌های ایجاد پنل بسته شد.", reply_markup=ReplyKeyboardRemove())
            await state.clear()
            await message.edit_text(
                f"این فرایند قبلاً ثبت شده است؛ پنل #{int(existing.id)} ایجاد شده و از تکرار آن جلوگیری شد.",
                reply_markup=admin_menu(),
            )
            return
    if action == "publish":
        # Follow notifications are durably queued in the publication transaction.
        await reconcile_event_channel_status(message.bot, event_id)
    from aiogram.types import ReplyKeyboardRemove
    await message.answer("کنترل‌های ایجاد پنل بسته شد.", reply_markup=ReplyKeyboardRemove())
    await state.clear()
    state_text = "منتشر شد و ثبت‌نام برای کاربران باز است" if action == "publish" else "به‌صورت پیش‌نویس ذخیره شد"
    await message.edit_text(f"✅ پنل {volume_label(data['volume'])} با شماره #{event_id} {state_text}.", reply_markup=admin_menu())


@router.message(AdminEventStates.confirm)
async def create_event_confirmation_text(m: Message):
    await m.answer("برای ذخیرهٔ پیش‌نویس یا انتشار پنل، از دکمه‌های نمایش‌داده‌شده استفاده کنید.")


@router.callback_query(F.data.regexp(r"^admin:event:create:draft:[0-9a-f]{32}$"))
async def create_event_save_draft(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != AdminEventStates.confirm.state or not await _validate_creation_callback(c, state):
        return
    await c.answer()
    await _finish_event_creation(c.message, state, "draft", c.from_user.id, c.from_user.username)


@router.message(AdminManageStates.announcement_confirm)
@router.message(AdminManageStates.reminder_confirm)
async def admin_confirmation_text(m: Message):
    await m.answer("برای تأیید یا لغو عملیات، از دکمه‌های نمایش‌داده‌شده استفاده کنید؛ برای خروج از گفت‌وگو /cancel را بفرستید.")


@router.callback_query(F.data.regexp(r"^admin:event:create:publish:[0-9a-f]{32}$"))
async def create_event_publish(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != AdminEventStates.confirm.state or not await _validate_creation_callback(c, state):
        return
    await c.answer()
    await _finish_event_creation(c.message, state, "publish", c.from_user.id, c.from_user.username)


async def _render_admin_event_list(c: CallbackQuery, page: int = 0):
    async with SessionLocal() as session:
        total = int((await session.execute(
            select(func.count(Event.id)).where(Event.archived.is_(False))
        )).scalar_one())
        last_page = max(0, (total - 1) // EVENT_ADMIN_PAGE_SIZE)
        page = min(max(0, int(page)), last_page)
        events = (await session.execute(
            select(Event).where(Event.archived.is_(False)).order_by(Event.id.desc())
            .offset(page * EVENT_ADMIN_PAGE_SIZE).limit(EVENT_ADMIN_PAGE_SIZE)
        )).scalars().all()
        usage_rows = (await session.execute(
            select(Booking.event_id, func.coalesce(func.sum(Booking.participant_count), 0))
            .where(
                Booking.event_id.in_([int(e.id) for e in events]) if events else text("1=0"),
                Booking.status.in_((RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.PENDING_VERIFICATION, RegistrationStatus.CONFIRMED)),
            ).group_by(Booking.event_id)
        )).all() if events else []
    if total == 0:
        await c.message.edit_text("پنلی وجود ندارد.", reply_markup=admin_menu())
        return
    used_by_event = {int(event_id): int(count or 0) for event_id, count in usage_rows}
    rows = []
    for event in events:
        used = used_by_event.get(int(event.id), 0)
        shown = display_status(event, used)
        if event.status == EventStatus.DRAFT:
            lifecycle = "📝 پیش‌نویس"
        elif event.status == EventStatus.PUBLISHED:
            lifecycle = "📣 منتشرشده"
        elif event.status == EventStatus.CANCELLED:
            lifecycle = "❌ لغوشده"
        elif event.status == EventStatus.COMPLETED:
            lifecycle = "✅ برگزارشده"
        else:
            lifecycle = shown.value
        reg_state = "ثبت‌نام: باز" if registration_is_open(event) else "ثبت‌نام: بسته"
        first_line = f"{volume_label(event.volume)} — {event.title}"
        max_first = max(1, 63 - len(lifecycle) - len(reg_state) - 2)
        first_line = first_line[:max_first]
        rows.append([InlineKeyboardButton(
            text=f"{first_line}\n{lifecycle}\n{reg_state}",
            callback_data=f"admin:event:view:{event.id}",
        )])
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ پنل‌های جدیدتر", callback_data=f"admin:events:page:{page-1}"))
    if page < last_page:
        navigation.append(InlineKeyboardButton(text="پنل‌های قدیمی‌تر ➡️", callback_data=f"admin:events:page:{page+1}"))
    if navigation:
        rows.append(navigation)
    rows.append([InlineKeyboardButton(text=f"صفحه {page + 1} از {last_page + 1} · {total} پنل", callback_data=f"admin:events:page:{page}")])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")])
    await c.message.edit_text(
        "پنل موردنظر را انتخاب کنید. هر پنل وضعیت چرخه و ثبت‌نام را نشان می‌دهد؛ برای پنل‌های قدیمی‌تر از دکمهٔ صفحهٔ بعد استفاده کنید:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data == "admin:events")
async def event_list(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await _request_admin_navigation_confirmation(c, state):
        return
    await state.clear()
    await _render_admin_event_list(c, 0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:events:page:\d+$"))
async def event_list_page(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await _request_admin_navigation_confirmation(c, state):
        return
    try:
        page = int((c.data or "").rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("صفحه نامعتبر است.", show_alert=True)
    await _render_admin_event_list(c, page)
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:view:"))
async def event_view(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await _request_admin_navigation_confirmation(c, state):
        return
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    await state.clear()
    await render_event(c, eid)


@router.callback_query(F.data.startswith("admin:event:final:"))
async def final_panel_state(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        has_bookings = bool((await session.execute(
            select(func.count(Booking.id)).where(Booking.event_id == eid)
        )).scalar_one())
    body = (
        f"<b>وضعیت نهایی پنل — {volume_label(event.volume)} | {escape(event.title)}</b>\n\n"
        "ابتدا پنل برگزارشده را صریحاً علامت بزنید؛ سپس «آرشیو + بازخورد» را جداگانه اجرا کنید. لغو و حذف کامل عملیات جداگانه‌اند.\n\n"
        + ("⚠️ حذف کامل، سوابق رزرو و رسیدهای این پنل را نیز حذف می‌کند؛ شمارندهٔ مادام‌العمر تأییدهای کاربران حفظ می‌شود. برای نگه‌داشتن سوابق، آرشیو را انتخاب کنید." if has_bookings else "این پنل سابقهٔ ثبت‌نام ندارد؛ حذف کامل فقط اطلاعات خود پنل و فایل‌های وابسته را حذف می‌کند.")
    )
    await c.message.edit_text(body, reply_markup=final_panel_state_keyboard(
        eid, event.status.value, bool(event.archived), has_bookings
    ))
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:publish:"))
async def event_publish(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid, with_for_update=True)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        try:
            publish_event(event)
        except ValueError:
            return await c.answer("این پنل قابل انتشار نیست.", show_alert=True)
        event.submission_status = "approved"
        event.submission_feedback = None
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="panel_published", entity_type="event", entity_id=eid, details={"volume": str(event.volume)})
        from app.services.notification_outbox import enqueue_notification_outbox
        await enqueue_notification_outbox(
            session, dedupe_key=f"panel-published:{eid}",
            event_type="panel.published", payload={"event_id": eid},
        )
        await session.commit()
    await reconcile_event_channel_status(c.bot, eid)
    await c.answer("پنل منتشر شد و ثبت‌نام باز است.")
    await render_event(c, eid)


@router.callback_query(F.data.startswith("admin:event:reopen:"))
async def event_reopen(c: CallbackQuery):
    return await _set_registration(c, True)


@router.callback_query(F.data.startswith("admin:event:close:"))
async def event_close(c: CallbackQuery):
    return await _set_registration(c, False)


async def _set_registration(c: CallbackQuery, opening: bool):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid, with_for_update=True)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        if opening:
            if event.status != EventStatus.PUBLISHED or event.archived:
                return await c.answer("فقط پنل منتشرشده و غیرآرشیوی قابل بازگشایی است.", show_alert=True)
            used = await seats_used(session, eid)
            if used >= event.capacity:
                return await c.answer("ظرفیت پنل هنوز کامل است و ثبت‌نام قابل بازگشایی نیست.", show_alert=True)
        event.registration_open = opening
        event.registration_closed_reason = None if opening else "manual"
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="registration_reopened" if opening else "registration_manually_closed", entity_type="event", entity_id=eid)
        await session.commit()
    await reconcile_event_channel_status(c.bot, eid)
    await c.answer("ثبت‌نام باز شد." if opening else "ثبت‌نام بسته شد.")
    await render_event(c, eid)


@router.callback_query(F.data.regexp(r"^admin:event:cancel:\d+$"))
async def event_cancel(c: CallbackQuery):
    """Show an impact preview; no event state changes before explicit confirmation."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        if event.archived:
            return await c.answer("پنل آرشیوشده است و وضعیت آن قابل لغو مجدد نیست.", show_alert=True)
        if event.status == EventStatus.CANCELLED:
            return await c.answer("این پنل قبلاً لغو شده است.", show_alert=True)
        active = (RegistrationStatus.INITIATED, RegistrationStatus.PENDING_PAYMENT,
                  RegistrationStatus.PENDING_VERIFICATION, RegistrationStatus.CONFIRMED,
                  RegistrationStatus.REJECTED, RegistrationStatus.WAITLISTED)
        booking_count = int((await session.execute(
            select(func.count(Booking.id)).where(Booking.event_id == eid, Booking.status.in_(active))
        )).scalar_one())
        financial_count = int((await session.execute(
            select(func.count(Booking.id)).outerjoin(Payment, Payment.booking_id == Booking.id)
            .where(Booking.event_id == eid, Booking.status.in_(active),
                   (Booking.status.in_((RegistrationStatus.CONFIRMED, RegistrationStatus.PENDING_VERIFICATION)) |
                    (Payment.status == PaymentStatus.APPROVED) |
                    Payment.receipt_uploaded_at.is_not(None) |
                    Payment.receipt_file.is_not(None) |
                    Payment.receipt_text.is_not(None)))
        )).scalar_one())
        waitlist_count = int((await session.execute(
            select(func.count(WaitlistEntry.id)).where(WaitlistEntry.event_id == eid,
                WaitlistEntry.status.in_(("waiting", "invited", "inviting")))
        )).scalar_one())
        label = f"{volume_label(event.volume)} — {event.title}"
    await c.message.edit_text(
        f"<b>⚠️ تأیید لغو پنل</b>\n\n<b>{escape(label)}</b>\n\n"
        f"رزروهای فعال/قابل پیگیری که لغو می‌شوند: <b>{booking_count}</b>\n"
        f"موارد پرداختی نیازمند بررسی پس از لغو: <b>{financial_count}</b>\n"
        f"اعضای لیست انتظار که مطلع می‌شوند: <b>{waitlist_count}</b>\n\n"
        "رزروها از وضعیت فعال خارج می‌شوند، اما سوابق و وضعیت تاریخی پرداخت پاک یا بازنویسی نمی‌شوند. "
        "موارد مالی نیازمند پیگیری در بخش «پیگیری مالی پنل‌های لغوشده» ثبت خواهند شد. "
        "لغو پنل به‌خودی‌خود به معنی انجام بازپرداخت نیست.\n\nآیا ادامه می‌دهید؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ بله، لغو پنل و ثبت موارد پیگیری", callback_data=f"admin:event:cancel:confirm:{eid}")],
            [InlineKeyboardButton(text="↩️ انصراف", callback_data=f"admin:event:cancel:abort:{eid}")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:cancel:abort:\d+$"))
async def event_cancel_abort(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = positive_callback_id(c.data)
    if eid is None:
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    await render_event(c, eid, answer_callback=False)
    await c.answer("لغو پنل انجام نشد.")


@router.callback_query(F.data.regexp(r"^admin:event:cancel:confirm:\d+$"))
async def event_cancel_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = positive_callback_id(c.data)
    if eid is None:
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    try:
        async with SessionLocal() as session:
            from app.services.event_cancellation import cancel_event_in_transaction
            result = await cancel_event_in_transaction(session, eid, c.from_user.id)
            await session.commit()
    except ValueError as exc:
        messages = {
            "EVENT_NOT_FOUND": "پنل پیدا نشد.",
            "EVENT_ARCHIVED": "پنل آرشیوشده است و وضعیت آن قابل لغو مجدد نیست.",
            "EVENT_ALREADY_CANCELLED": "این پنل قبلاً لغو شده است.",
        }
        return await c.answer(messages.get(str(exc), "لغو پنل انجام نشد."), show_alert=True)
    except Exception:
        logger.exception("Transactional event cancellation failed for event_id=%s", eid)
        return await c.answer("لغو پنل انجام نشد؛ هیچ تغییری تأیید نشده است. دوباره تلاش کنید.", show_alert=True)
    booking_recipients = result["booking_recipients"]
    waiting_recipients = result["waiting_recipients"]
    financial_recipients = result["financial_recipients"]
    unresolved_count = result["unresolved_count"]
    cancelled_booking_count = result["cancelled_booking_count"]
    panel_label = result["panel_label"]
    try:
        await reconcile_event_channel_status(c.bot, eid)
    except Exception:
        logger.exception("Failed to reconcile channel after panel cancellation; event_id=%s", eid)
    for telegram_id in sorted(booking_recipients | waiting_recipients):
        if telegram_id in settings.super_admin_id_set:
            continue
        if telegram_id in financial_recipients:
            notice = (
                f"⚠️ پنل <b>{escape(panel_label)}</b> توسط مدیریت لغو شد.\n\n"
                "رزرو شما لغو شده و وضعیت رسید/پرداخت قبلی حفظ شده است. مورد مالی برای پیگیری مدیریت ثبت شده؛ "
                f"این پیام تأیید بازپرداخت نیست. در صورت نیاز از {escape(settings.support_display_username)} پیگیری کنید."
            )
        elif telegram_id in booking_recipients:
            notice = (
                f"⚠️ پنل <b>{escape(panel_label)}</b> توسط مدیریت لغو شد.\n\n"
                "رزرو شما غیرفعال شده است و نیازی به ارسال رسید یا اقدام دیگری برای این پنل ندارید."
            )
        else:
            notice = f"⚠️ پنل <b>{escape(panel_label)}</b> توسط مدیریت لغو شد.\n\nدرخواست شما در لیست انتظار این پنل بسته شده است."
        try:
            await c.bot.send_message(telegram_id, notice)
        except Exception:
            logger.exception("Could not notify user about panel cancellation; event_id=%s", eid)
    await render_event(c, eid, answer_callback=False)
    await c.answer(f"پنل لغو شد؛ {unresolved_count} مورد مالی برای پیگیری ثبت شد.", show_alert=True)


CANCELLATION_CASE_PAGE_SIZE = 8


@router.callback_query(F.data == "admin:cancellation_cases")
@router.callback_query(F.data.regexp(r"^admin:cancellation_cases:page:\d+$"))
async def cancellation_cases_list(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int((c.data or "").rsplit(":", 1)[1]) if ":page:" in (c.data or "") else 0
        if page < 0 or page > 100000:
            raise ValueError
    except ValueError:
        return await c.answer("شماره صفحه نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        bookings = (await session.execute(
            select(Booking).join(Event, Booking.event_id == Event.id)
            .options(selectinload(Booking.event), selectinload(Booking.payment), selectinload(Booking.booked_by))
            .where(Event.status == EventStatus.CANCELLED, Booking.cancellation_resolution == "action_required")
            .order_by(Booking.created_at.asc(), Booking.id.asc())
            .offset(page * CANCELLATION_CASE_PAGE_SIZE).limit(CANCELLATION_CASE_PAGE_SIZE)
        )).scalars().all()
        total = int((await session.execute(
            select(func.count(Booking.id)).join(Event, Booking.event_id == Event.id)
            .where(Event.status == EventStatus.CANCELLED, Booking.cancellation_resolution == "action_required")
        )).scalar_one())
    rows = []
    body = [f"<b>💸 پیگیری مالی پنل‌های لغوشده</b>\n\nموارد حل‌نشده: <b>{total}</b>"]
    for booking in bookings:
        event = booking.event
        payment = booking.payment
        owner = booking.booked_by
        body.append(
            f"#{booking.id} · {escape(volume_label(event.volume))} — {escape(event.title)}\n"
            f"صاحب رزرو: {escape(owner.display_name or str(owner.telegram_id))} · "
            f"مبلغ: {int(payment.amount if payment else booking.total_amount):,} تومان · "
            f"وضعیت پرداخت: {escape(admin_status_display_label(payment.status) if payment else 'رکورد پرداختی وجود ندارد')}"
        )
        rows.append([InlineKeyboardButton(text=f"باز کردن پرونده رزرو #{booking.id}", callback_data=f"admin:cancellation_case:view:{booking.id}")])
    if total > CANCELLATION_CASE_PAGE_SIZE:
        body.append(f"\nصفحهٔ {page + 1} از {(total + CANCELLATION_CASE_PAGE_SIZE - 1) // CANCELLATION_CASE_PAGE_SIZE}")
        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton(text="⬅️ موارد جدیدتر", callback_data=f"admin:cancellation_cases:page:{page - 1}"))
        if (page + 1) * CANCELLATION_CASE_PAGE_SIZE < total:
            nav.append(InlineKeyboardButton(text="➡️ موارد قدیمی‌تر", callback_data=f"admin:cancellation_cases:page:{page + 1}"))
        if nav:
            rows.append(nav)
    if not bookings:
        body.append("\nپروندهٔ مالی حل‌نشده‌ای وجود ندارد.")
    rows.append([InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")])
    await c.message.edit_text(limit_telegram_html("\n\n".join(body)), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:cancellation_case:view:\d+$"))
async def cancellation_case_view(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    bid = positive_callback_id(c.data)
    if bid is None:
        return await c.answer("شناسهٔ رزرو نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        booking = (await session.execute(
            select(Booking).where(Booking.id == bid)
            .options(selectinload(Booking.event), selectinload(Booking.payment), selectinload(Booking.booked_by))
        )).scalar_one_or_none()
    if not booking or booking.cancellation_resolution != "action_required" or booking.event.status != EventStatus.CANCELLED:
        return await c.answer("این پرونده دیگر در صف پیگیری نیست.", show_alert=True)
    payment = booking.payment
    owner = booking.booked_by
    event = booking.event
    receipt = "رسید ثبت شده" if payment and (payment.receipt_file or payment.receipt_text or payment.receipt_uploaded_at) else "رسید ثبت نشده/در دسترس نیست"
    text = (
        f"<b>پرونده مالی رزرو #{booking.id}</b>\n\n"
        f"پنل: {escape(volume_label(event.volume))} — {escape(event.title)}\n"
        f"صاحب رزرو: {escape(owner.display_name or str(owner.telegram_id))}\n"
        f"شناسه تلگرام: <code>{owner.telegram_id}</code>\n"
        f"تعداد نفرات: {booking.participant_count}\n"
        f"مبلغ رزرو: {int(payment.amount if payment else booking.total_amount):,} تومان\n"
        f"وضعیت تاریخی رزرو: {escape(admin_status_display_label(booking.status))}\n"
        f"وضعیت تاریخی پرداخت: {escape(admin_status_display_label(payment.status) if payment else 'رکورد پرداختی وجود ندارد')}\n"
        f"رسید: {receipt}\n\n"
        "با انتخاب نتیجه، وضعیت پرداخت تاریخی تغییر نمی‌کند؛ فقط پروندهٔ پیگیری بسته و نتیجه در لاگ مدیر ثبت می‌شود."
    )
    rows = [
        [InlineKeyboardButton(text="✅ بازپرداخت انجام شد", callback_data=f"admin:cancellation_case:resolve:refunded:{bid}")],
        [InlineKeyboardButton(text="🎟 اعتبار/تخفیف جبرانی داده شد", callback_data=f"admin:cancellation_case:resolve:credited:{bid}")],
        [InlineKeyboardButton(text="🔁 به پنل دیگری منتقل شد", callback_data=f"admin:cancellation_case:resolve:transferred:{bid}")],
        [InlineKeyboardButton(text="📝 بستن پرونده با توضیح (مثلاً بدون بازپرداخت)", callback_data=f"admin:cancellation_case:note:{bid}")],
        [InlineKeyboardButton(text="🔙 فهرست پرونده‌ها", callback_data="admin:cancellation_cases")],
    ]
    await c.message.edit_text(limit_telegram_html(text), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()
    if payment and payment.receipt_text:
        await c.message.answer("<b>متن رسید ثبت‌شده:</b>\n" + escape(payment.receipt_text))
    receipt_path = resolve_upload_path(payment.receipt_file or "") if payment else None
    if receipt_path:
        try:
            await c.bot.send_document(c.from_user.id, FSInputFile(receipt_path), caption=f"رسید ذخیره‌شده برای پروندهٔ لغو پنل — رزرو #{booking.id}")
        except Exception:
            logger.exception("Could not send receipt attachment for cancellation case; booking_id=%s", booking.id)
    elif payment and payment.receipt_file:
        await c.message.answer("فایل رسید در مسیر ذخیره‌سازی فعلی پیدا نشد؛ وضعیت تاریخی رسید حفظ شده است.")


@router.callback_query(F.data.regexp(r"^admin:cancellation_case:resolve:(refunded|credited|transferred):\d+$"))
async def cancellation_case_resolve(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        resolution, bid = parts[3], int(parts[4])
        if bid <= 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("اطلاعات پرونده نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        booking = await session.get(Booking, bid, with_for_update=True)
        if not booking or booking.cancellation_resolution != "action_required":
            return await c.answer("این پرونده قبلاً بسته شده یا وجود ندارد.", show_alert=True)
        booking.cancellation_resolution = resolution
        booking.cancellation_resolution_note = {"refunded": "Administrator marked refund completed.", "credited": "Administrator marked compensating credit issued.", "transferred": "Administrator marked transfer to another panel."}[resolution]
        booking.cancellation_resolved_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action=f"cancellation_case_{resolution}", entity_type="booking", entity_id=bid, details={"event_id": booking.event_id, "resolution": resolution})
        await session.commit()
    await cancellation_cases_list(c)


@router.callback_query(F.data.regexp(r"^admin:cancellation_case:note:\d+$"))
async def cancellation_case_note_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    bid = positive_callback_id(c.data)
    if bid is None:
        return await c.answer("شناسهٔ رزرو نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        booking = await session.get(Booking, bid)
        if not booking or booking.cancellation_resolution != "action_required":
            return await c.answer("این پرونده دیگر در صف پیگیری نیست.", show_alert=True)
    await state.clear()
    await state.update_data(cancellation_case_booking_id=bid)
    await state.set_state(CancellationCaseStates.waiting_note)
    await c.message.answer("نتیجهٔ نهایی و علت بستن پرونده را در ۱۰ تا ۵۰۰ نویسه بنویسید. این توضیح در تاریخچهٔ مدیریت ذخیره می‌شود.")
    await c.answer()


@router.message(CancellationCaseStates.waiting_note)
async def cancellation_case_note_save(message: Message, state: FSMContext):
    if not message.from_user or not await is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    note = (message.text or "").strip()
    if not 10 <= len(note) <= 500:
        return await message.answer("توضیح باید بین ۱۰ تا ۵۰۰ نویسه باشد؛ دوباره بنویسید.")
    data = await state.get_data()
    try:
        bid = int(data.get("cancellation_case_booking_id", 0))
    except (TypeError, ValueError):
        bid = 0
    if bid <= 0:
        await state.clear()
        return await message.answer("پروندهٔ در انتظار توضیح پیدا نشد؛ از منوی مدیریت دوباره شروع کنید.", reply_markup=admin_menu())
    async with SessionLocal() as session:
        booking = await session.get(Booking, bid, with_for_update=True)
        if not booking or booking.cancellation_resolution != "action_required":
            await state.clear()
            return await message.answer("این پرونده قبلاً بسته شده یا وجود ندارد.", reply_markup=admin_menu())
        booking.cancellation_resolution = "other"
        booking.cancellation_resolution_note = note
        booking.cancellation_resolved_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=message.from_user.id, action="cancellation_case_other_resolution", entity_type="booking", entity_id=bid, details={"event_id": booking.event_id, "resolution": "other", "note": note})
        await session.commit()
    await state.clear()
    await message.answer(f"✅ پروندهٔ رزرو #{bid} بسته شد و توضیح در لاگ مدیریت ثبت شد.", reply_markup=admin_menu())


@router.callback_query(F.data.regexp(r"^admin:event:complete:\d+$"))
async def event_mark_completed(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid, with_for_update=True)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        if event.archived or event.status != EventStatus.PUBLISHED:
            return await c.answer("فقط پنل منتشرشده و غیرآرشیوی را می‌توان برگزارشده علامت زد.", show_alert=True)
        from app.services.event_lifecycle import transition_event
        transition_event(event, EventStatus.COMPLETED)
        await session.execute(
            WaitlistEntry.__table__.update()
            .where(WaitlistEntry.event_id == eid, WaitlistEntry.status.in_(["waiting", "invited", "inviting"]))
            .values(status="closed", invitation_expires_at=None, next_invite_after=None)
        )
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="panel_marked_completed", entity_type="event", entity_id=eid)
        from app.services.notification_outbox import enqueue_event_notification
        change_key = f"bot-completed-{utc_now_naive().isoformat(timespec='microseconds')}"
        await enqueue_event_notification(session, event_id=eid, event_type="panel.changed", change_key=change_key)
        await session.commit()
    try:
        await reconcile_event_channel_status(c.bot, eid)
    except Exception:
        logger.exception("Could not reconcile panel status after completion event_id=%s", eid)
    await c.answer("پنل برگزارشده ثبت شد. برای نگه‌داشتن سوابق، آرشیو + بازخورد را جداگانه اجرا کنید.", show_alert=True)
    await render_event(c, eid)


@router.callback_query(F.data.regexp(r"^admin:event:archive:\d+$"))
async def event_archive(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        if event.archived:
            return await c.answer("این پنل قبلاً آرشیو شده است.", show_alert=True)
        if event.status != EventStatus.COMPLETED:
            return await c.answer("ابتدا پنل را با اقدام «اعلام برگزاری / پایان پنل» برگزارشده کنید؛ سپس آرشیو + بازخورد را اجرا کنید.", show_alert=True)
    await c.message.edit_text(
        "<b>این پنل آرشیو می‌شود.</b>\n\n"
        "• در فهرست عادی کاربران نمایش داده نمی‌شود.\n"
        "• ثبت‌نام جدید بسته خواهد شد.\n"
        "• بازخورد این پنل فعال می‌شود تا افراد واجد شرایط بتوانند نظر خود را ثبت کنند.\n\n"
        "آیا مطمئن هستید؟",
        reply_markup=archive_confirm_keyboard(eid),
    )
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:archive:confirm:"))
async def event_archive_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid, with_for_update=True)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        # Revalidate the selected panel under a lock. Archiving closes registration
        # as part of the same transaction so an open panel cannot become stranded.
        if event.archived:
            return await c.answer("این پنل قبلاً آرشیو شده است.", show_alert=True)
        if event.status != EventStatus.COMPLETED:
            return await c.answer("فقط پنل برگزارشده و تکمیل‌شده قابل آرشیو است.", show_alert=True)
        from app.services.event_lifecycle import archive_completed_event
        try:
            archive_completed_event(event)
        except ValueError as exc:
            return await c.answer("فقط پنل تکمیل‌شده قابل آرشیو است.", show_alert=True)
        # Keep explicit persisted-state assignments visible at this boundary for
        # audit/readability; the helper owns the lifecycle invariant.
        event.archived = True
        event.registration_open = False
        # Announcement history is panel-scoped and is no longer retained after archival.
        await session.execute(delete(AdminAnnouncement).where(AdminAnnouncement.event_id == eid))
        # Clear both current channel-post history and legacy per-recipient
        # broadcasts for this panel; delivery rows cascade from their parent.
        await session.execute(delete(PanelAnnouncementPost).where(PanelAnnouncementPost.event_id == eid))
        await session.execute(delete(AnnouncementBroadcast).where(AnnouncementBroadcast.event_id == eid))
        # The explicit "Archive + Reviews" action enables the review flow that
        # the archived channel/group post will invite eligible registrants to use.
        event.feedback_enabled = True
        if event.archived_at is None:
            from app.time_utils import utc_now_naive
            event.archived_at = utc_now_naive()
        discount_cleanup = await detach_event_discount_codes(session, eid)
        await session.execute(
            WaitlistEntry.__table__.update()
            .where(WaitlistEntry.event_id == eid, WaitlistEntry.status.in_(["waiting", "invited", "inviting"]))
            .values(status="closed")
        )
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="panel_archived", entity_type="event", entity_id=eid, details={"preserved_booking_history": True, "feedback_enabled": True})
        await session.commit()
    try:
        await reconcile_event_channel_status(c.bot, eid)
    except Exception:
        # The database transition is already committed; a Telegram/channel issue
        # must not make a successful archive appear to have failed.
        logger.exception("Could not reconcile channel status after archiving event_id=%s", eid)
    for telegram_id in discount_cleanup.get("telegram_ids", []):
        try:
            await c.bot.send_message(
                telegram_id,
                "ℹ️ پنلی که برای تخفیف شما انتخاب شده بود آرشیو شد؛ درخواست/هدیه مرتبط دیگر برای آن قابل استفاده نیست. اگر کد برای پنل دیگری هم معتبر باشد، آن پنل همچنان قابل استفاده است.",
            )
        except Exception:
            logger.info("Could not notify user about archived discount scope; event_id=%s", eid)
    await c.answer("پنل آرشیو شد؛ کدهای وابسته نیز به‌روزرسانی شدند.", show_alert=True)
    # Move straight to the dedicated archived view after the lifecycle transition.
    # The callback has already been answered with the success alert, so do not answer twice.
    await _render_archived_panel_detail(c, eid, answer_callback=False)


@router.callback_query(F.data.startswith("admin:event:archive:cancel:"))
async def event_archive_cancel(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.")
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    await render_event(c, eid)


@router.callback_query(F.data.regexp(r"^admin:archive:delete:\d+$"))
async def archived_event_delete(c: CallbackQuery):
    """Start the existing permanent-delete flow only for a panel in the archive."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived:
            return await c.answer("پنل آرشیوشده پیدا نشد.", show_alert=True)
    return await event_delete(c)


@router.callback_query(F.data.regexp(r"^admin:event:delete:\d+$"))
async def event_delete(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        booking_count = int((await session.execute(
            select(func.count(Booking.id)).where(Booking.event_id == eid)
        )).scalar_one())
        payment_count = int((await session.execute(
            select(func.count(Payment.id)).join(Booking, Payment.booking_id == Booking.id)
            .where(Booking.event_id == eid)
        )).scalar_one())
    if event.archived:
        warning = (
            "این پنل از قبل آرشیو شده است. با حذف کامل، پنل آرشیوشده و تمام سوابق وابستهٔ آن، "
            f"از جمله {booking_count} رزرو و {payment_count} رکورد پرداخت/رسید، برای همیشه حذف می‌شوند.\n"
            "شمارندهٔ مادام‌العمر رزروهای تأییدشدهٔ کاربران حفظ می‌شود. این عملیات قابل بازگشت نیست.\n\n"
            "آیا حذف کامل پنل آرشیوشده را تأیید می‌کنید؟"
        )
        confirm_callback = f"admin:archive:delete:confirm:{eid}"
        cancel_callback = f"admin:archive:delete:cancel:{eid}"
    else:
        warning = (
            f"این پنل <b>{booking_count}</b> رزرو و <b>{payment_count}</b> رکورد پرداخت دارد.\n"
            "با حذف کامل، خود پنل، ثبت‌نام‌ها، نام شرکت‌کنندگان، سوابق پرداخت/رسید و ورودی‌های لیست انتظار حذف می‌شوند.\n"
            "شمارندهٔ مادام‌العمر رزروهای تأییدشدهٔ کاربران حفظ می‌شود. این عملیات قابل بازگشت نیست.\n\n"
            "برای نگه‌داشتن موضوع پنل و سوابق آن، به‌جای حذف از «آرشیو + بازخورد» استفاده کنید.\n\n"
            "آیا حذف کامل را تأیید می‌کنید؟"
        )
        confirm_callback = f"admin:event:delete:confirm:{eid}"
        cancel_callback = f"admin:event:delete:cancel:{eid}"
    await c.message.edit_text(
        f"<b>⚠️ تأیید حذف کامل پنل {volume_label(event.volume)} — {escape(event.title)}</b>\n\n{warning}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🗑 بله، پنل و سوابقش حذف شوند", callback_data=confirm_callback)],
            [InlineKeyboardButton(text="↩️ انصراف", callback_data=cancel_callback)],
        ]),
    )
    await c.answer()


@router.callback_query(F.data.startswith("admin:archive:delete:confirm:"))
async def archived_event_delete_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived:
            return await c.answer("پنل آرشیوشده پیدا نشد یا دیگر در آرشیو نیست.", show_alert=True)
    return await event_delete_confirm(c)


@router.callback_query(F.data.startswith("admin:event:delete:confirm:"))
async def event_delete_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    paths_to_cleanup: set[str] = set()
    async with SessionLocal() as session:
        try:
            event = await session.get(Event, eid, with_for_update=True)
            if not event:
                return await c.answer("پنل قبلاً حذف شده است.", show_alert=True)
            if str(c.data or "").startswith("admin:archive:delete:confirm:") and not event.archived:
                return await c.answer("این پنل دیگر در آرشیو نیست؛ برای حذف دوباره از فهرست مدیریت اقدام کنید.", show_alert=True)
            if event.questions_pdf_path:
                paths_to_cleanup.add(str(event.questions_pdf_path))
            # Lock the panel first, then gather all dependent records. All dependent
            # rows are removed in the same transaction, while the confirmation
            # ledger is deliberately untouched and has no booking foreign key.
            bookings = (await session.execute(
                select(Booking).where(Booking.event_id == eid).with_for_update()
            )).scalars().all()
            booking_ids = [int(booking.id) for booking in bookings]
            if booking_ids:
                receipt_paths = (await session.execute(
                    select(Payment.receipt_file).where(
                        Payment.booking_id.in_(booking_ids), Payment.receipt_file.is_not(None)
                    )
                )).scalars().all()
                paths_to_cleanup.update(str(path) for path in receipt_paths if path)
                # A permanent panel deletion also removes its private reviews.
                # Archival is the non-destructive route for retaining feedback/history.
                await session.execute(
                    Review.__table__.delete().where(Review.booking_id.in_(booking_ids))
                )
                await session.execute(
                    Payment.__table__.delete().where(Payment.booking_id.in_(booking_ids))
                )
                await session.execute(
                    Participant.__table__.delete().where(Participant.booking_id.in_(booking_ids))
                )
                await session.execute(
                    Booking.__table__.delete().where(Booking.id.in_(booking_ids))
                )
            discount_cleanup = await detach_event_discount_codes(session, eid)
            await session.execute(Question.__table__.delete().where(Question.event_id == eid))
            await session.execute(delete(AdminAnnouncement).where(AdminAnnouncement.event_id == eid))
            # Keep permanent deletion consistent with archival: remove both
            # current channel-post records and legacy per-recipient broadcasts.
            await session.execute(delete(PanelAnnouncementPost).where(PanelAnnouncementPost.event_id == eid))
            await session.execute(delete(AnnouncementBroadcast).where(AnnouncementBroadcast.event_id == eid))
            await session.execute(Review.__table__.delete().where(Review.event_id == eid))
            await session.execute(WaitlistEntry.__table__.delete().where(WaitlistEntry.event_id == eid))
            await session.execute(ChannelAnnouncement.__table__.delete().where(ChannelAnnouncement.event_id == eid))
            await write_admin_action(session, actor_telegram_id=c.from_user.id, action="panel_permanently_deleted", entity_type="event", entity_id=eid, details={"booking_count": len(booking_ids), "archived": bool(event.archived)})
            await session.delete(event)
            await session.commit()
        except Exception:
            await session.rollback()
            logger.exception("Permanent panel deletion failed for event_id=%s", eid)
            return await c.answer("حذف کامل پنل انجام نشد؛ هیچ موفقیتی گزارش نشده است. خطا ثبت شد و می‌توانید دوباره بررسی کنید.", show_alert=True)

    # Uploaded files are removed only after the database commit, and only if no
    # remaining event/payment row references the same stored path.
    try:
        async with SessionLocal() as session:
            event_paths = set((await session.execute(
                select(Event.questions_pdf_path).where(Event.questions_pdf_path.is_not(None))
            )).scalars().all())
            receipt_paths = set((await session.execute(
                select(Payment.receipt_file).where(Payment.receipt_file.is_not(None))
            )).scalars().all())
        still_referenced = {str(path) for path in event_paths | receipt_paths if path}
        for stored_path in paths_to_cleanup - still_referenced:
            safe_path = resolve_upload_path(stored_path)
            if safe_path:
                Path(safe_path).unlink(missing_ok=True)
    except Exception:
        logger.exception("Panel rows were deleted, but an upload cleanup check failed for event_id=%s", eid)

    for telegram_id in discount_cleanup.get("telegram_ids", []):
        try:
            await c.bot.send_message(telegram_id, "ℹ️ پنلی که برای تخفیف یا هدیه شما انتخاب شده بود کاملاً حذف شد؛ این هدیه/درخواست دیگر برای آن پنل قابل استفاده نیست.")
        except Exception:
            logger.info("Could not notify about discount scope after permanent panel deletion; event_id=%s", eid, exc_info=True)
    await c.answer("پنل و سوابق وابسته حذف شدند؛ آمار مادام‌العمر کاربران حفظ شد.", show_alert=True)
    await c.message.edit_text("✅ پنل و سوابق وابسته حذف شدند.", reply_markup=admin_menu())


@router.callback_query(F.data.startswith("admin:event:delete:cancel:"))
async def event_delete_cancel(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    await render_event(c, eid)


@router.callback_query(F.data.startswith("admin:event:pdf:skip:"))
async def event_pdf_replace_skip(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid, with_for_update=True)
        if not event:
            await state.clear()
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        event.questions_pdf_path = None
        event.questions_file_name = None
        if event.status == EventStatus.DRAFT and event.submission_status == "submitted":
            bump_submission_revision(event)
        await session.commit()
    await state.clear()
    await c.message.answer("✅ فایل سؤالات حذف شد.", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:pdf:"))
async def event_pdf_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    if not await get_event(eid):
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    await state.clear()
    await state.update_data(manage_event_id=eid)
    await state.set_state(AdminManageStates.waiting_pdf)
    await c.message.answer("PDF یا TXT جدید سؤالات را ارسال کنید؛ برای حذف فایل فعلی - بفرستید یا دکمه را بزنید.", reply_markup=questions_replace_keyboard(eid))
    await c.answer()


@router.message(AdminManageStates.waiting_pdf, F.document)
async def event_pdf_replace(m: Message, state: FSMContext):
    # Revalidate current permissions at submission time: persistent FSM state may
    # outlive an Admin role revocation or suspension.
    if not m.from_user or not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    document = m.document
    name = (document.file_name or "").lower()
    if not (is_pdf_document(document) or is_text_document(document)):
        return await m.answer("فقط PDF یا TXT پذیرفته می‌شود.")
    if document.file_size and document.file_size > settings.max_upload_mb * 1024 * 1024:
        return await m.answer(f"حجم فایل نباید بیشتر از {settings.max_upload_mb} مگابایت باشد.")
    data = await state.get_data()
    event_id = int(data["manage_event_id"])
    event = await get_event(event_id)
    if not event:
        await state.clear()
        return await m.answer("پنل پیدا نشد.")
    ext = ".pdf" if is_pdf_document(document) else ".txt"
    try:
        path = await download_file(m.bot, document.file_id, safe_pdf_filename(event.title).removesuffix(".pdf") + ext, file_size=document.file_size)
    except Exception:
        return await m.answer("بارگذاری فایل ناموفق بود؛ لطفاً دوباره تلاش کنید.")
    if Path(path).stat().st_size > settings.max_upload_mb * 1024 * 1024:
        Path(path).unlink(missing_ok=True)
        return await m.answer(f"حجم فایل نباید بیشتر از {settings.max_upload_mb} مگابایت باشد.")
    if not file_content_matches(path, ext):
        Path(path).unlink(missing_ok=True)
        return await m.answer("محتوای فایل با فرمت اعلام‌شده مطابقت ندارد؛ PDF یا TXT معتبر ارسال کنید.")
    async with SessionLocal() as session:
        event = await session.get(Event, event_id, with_for_update=True)
        if not event or event.archived:
            Path(path).unlink(missing_ok=True)
            await state.clear()
            return await m.answer("پنل پیدا نشد یا آرشیو شده است.", reply_markup=admin_menu())
        event.questions_pdf_path = path
        event.questions_file_name = document.file_name or Path(path).name
        if event.status == EventStatus.DRAFT and event.submission_status == "submitted":
            bump_submission_revision(event)
        await session.commit()
    await state.clear()
    await m.answer("✅ فایل سؤالات جایگزین شد.", reply_markup=admin_menu())


@router.message(AdminManageStates.waiting_pdf)
async def event_pdf_replace_wrong(m: Message, state: FSMContext):
    # Do not let a stale privileged FSM remove a file after role revocation.
    if not m.from_user or not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    if (m.text or "").strip() != "-":
        await m.answer("PDF یا TXT ارسال کنید، یا - برای حذف فایل.", reply_markup=questions_replace_keyboard(int((await state.get_data())["manage_event_id"])))
        return
    data = await state.get_data()
    event_id = int(data["manage_event_id"])
    async with SessionLocal() as session:
        event = await session.get(Event, event_id, with_for_update=True)
        if not event:
            await state.clear()
            return await m.answer("پنل پیدا نشد.")
        event.questions_pdf_path = None
        event.questions_file_name = None
        if event.status == EventStatus.DRAFT and event.submission_status == "submitted":
            bump_submission_revision(event)
        await session.commit()
    await state.clear()
    await m.answer("✅ فایل سؤالات حذف شد.", reply_markup=admin_menu())


async def _start_edit(c: CallbackQuery, state: FSMContext, event_id: int):
    """Legacy full edit wizard, retained as an explicit secondary option."""
    event = await get_event(event_id)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if event.archived:
        return await c.answer("پنل آرشیوشده از این مسیر قابل ویرایش نیست.", show_alert=True)
    await state.clear()
    await state.update_data(edit_event_id=event_id)
    await state.set_state(AdminEditStates.title)
    await c.message.answer(f"عنوان فعلی: {escape(event.title)}\nعنوان جدید را بفرستید یا - برای حفظ مقدار فعلی:")
    await c.answer()


_QUICK_EDIT_LABELS = {
    "title": "عنوان", "description": "توضیحات", "host_name": "نام میزبان",
    "questions_pdf": "فایل سؤالات", "language": "زبان",
    "day_name": "روز نمایشی", "date_text": "تاریخ نمایشی", "start_time": "ساعت شروع",
    "end_time": "ساعت پایان", "venue": "محل برگزاری", "address": "آدرس",
    "map_url": "لینک نقشه", "capacity": "ظرفیت", "price": "قیمت پایه",
    "alternative_price": "قیمت بدون سفارش اجباری از منوی کافه",
}


def _quick_edit_current_value(event: Event, field: str):
    attrs = {
        "title": "title", "description": "description", "host_name": "host_name", "language": "language",
        "day_name": "event_day_label", "date_text": "event_date_label",
        "start_time": "start_time_label", "end_time": "end_time_label",
        "venue": "venue", "address": "address", "map_url": "map_url",
        "capacity": "capacity", "price": "price_per_person",
        "alternative_price": "price_without_cafe_order",
    }
    if field == "questions_pdf":
        return event.questions_file_name or (Path(event.questions_pdf_path).name if event.questions_pdf_path else None)
    return getattr(event, attrs[field])


def _quick_edit_display(value, field: str) -> str:
    if value is None or value == "":
        return "—"
    if field in {"price", "alternative_price"}:
        return f"{int(value):,} تومان" if value is not None else "غیرفعال"
    if field == "questions_pdf":
        return str(value)
    if field == "capacity":
        return str(int(value))
    return str(value)


@router.callback_query(F.data.regexp(r"^admin:event:edit:\d+$"))
async def edit_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    event_id = await read_callback_id(c, "پنل")
    if event_id is None:
        return
    event = await get_event(event_id)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if event.archived:
        return await c.answer("پنل آرشیوشده از این مسیر قابل ویرایش نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text(
        f"<b>ویرایش پنل #{event_id} · {escape(event.title)}</b>\n\n"
        "فقط همان فیلدی را انتخاب کنید که می‌خواهید تغییر دهید. برای اصلاح چندین مورد، ویرایش کامل را باز کنید.",
        reply_markup=admin_event_field_edit_keyboard(event_id),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:editall:\d+$"))
async def edit_all_fields(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        event_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شناسه پنل معتبر نیست.", show_alert=True)
    await _start_edit(c, state, event_id)


@router.callback_query(F.data.regexp(r"^admin:event:fieldedit:\d+:[a-z_]+$"))
async def quick_edit_field_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        event_id = int(parts[3])
        field = parts[4]
    except (ValueError, IndexError):
        return await c.answer("فیلد و شناسه پنل معتبر نیست.", show_alert=True)
    if field not in _QUICK_EDIT_LABELS:
        return await c.answer("این فیلد قابل ویرایش نیست.", show_alert=True)
    event = await get_event(event_id)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if event.archived:
        return await c.answer("پنل آرشیوشده از این مسیر قابل ویرایش نیست.", show_alert=True)
    if field == "alternative_price" and int(event.price_per_person or 0) == 0:
        # Free panels have no separate café-waiver price.
        prompt = "قیمت پایهٔ این پنل رایگان است؛ گزینهٔ قیمت بدون سفارش کافه در این حالت غیرفعال می‌ماند."
        return await c.answer(prompt, show_alert=True)
    if field == "questions_pdf":
        current_file = _quick_edit_display(_quick_edit_current_value(event, field), field)
        await c.message.edit_text(
            f"<b>فایل سؤالات · پنل #{event_id}</b>\n\n"
            f"فایل فعلی: {escape(current_file or 'ثبت نشده')}\n\n"
            "می‌توانید فایل PDF/TXT را جایگزین کنید یا فایل فعلی را حذف کنید. فایل قبلی از دیسک خودکار پاک نمی‌شود.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📤 جایگزینی فایل", callback_data=f"admin:event:pdf:{event_id}")],
                [InlineKeyboardButton(text="🗑 حذف فایل فعلی", callback_data=f"admin:event:fieldedit:pdfremove:confirm:{event_id}")],
                [InlineKeyboardButton(text="🔙 بازگشت به ویرایش پنل", callback_data=f"admin:event:edit:{event_id}")],
            ]),
            disable_web_page_preview=True,
        )
        await c.answer()
        return
    await state.clear()
    await state.update_data(quick_edit_event_id=event_id, quick_edit_field=field)
    await state.set_state(AdminQuickEditStates.waiting_value)
    current = _quick_edit_display(_quick_edit_current_value(event, field), field)
    clear_help = " برای پاک‌کردن مقدار اختیاری «—» بفرستید؛ «-» مقدار فعلی را حفظ و از ویرایش خارج می‌شود." if field in {"description", "language", "end_time", "address", "map_url", "alternative_price"} else " برای خروج /cancel را بزنید."
    prompts = {
        "title": "عنوان جدید (حداکثر ۲۵۵ نویسه):",
        "description": "توضیحات جدید (حداکثر ۴۰۰۰ نویسه):",
        "host_name": "نام و نام خانوادگی میزبان را وارد کنید:",
        "language": "زبان پنل (حداکثر ۸۰ نویسه):",
        "day_name": "نام روز نمایشی (حداکثر ۱۰۰ نویسه):",
        "date_text": "تاریخ نمایشی (حداکثر ۲۵۵ نویسه):",
        "start_time": "ساعت شروع را به‌شکل HH:MM وارد کنید:",
        "end_time": "ساعت پایان را به‌شکل HH:MM وارد کنید:",
        "venue": "محل برگزاری (حداکثر ۲۵۵ نویسه):",
        "address": "آدرس (حداکثر ۵۰۰ نویسه):",
        "map_url": "لینک کامل http(s) نقشه (حداکثر ۱۰۰۰ نویسه):",
        "capacity": "ظرفیت جدید را وارد کنید. از تعداد صندلی‌های رزروشده کمتر نمی‌تواند باشد:",
        "price": "قیمت پایه به تومان را وارد کنید (۰ برای پنل رایگان):",
        "alternative_price": "قیمت بدون سفارش کافه را وارد کنید؛ باید از قیمت پایه بیشتر باشد. «۰» یا «—» گزینه را غیرفعال می‌کند:",
    }
    await c.message.edit_text(
        f"<b>ویرایش { _QUICK_EDIT_LABELS[field] } · پنل #{event_id}</b>\n"
        f"مقدار فعلی: {escape(current)}\n\n{prompts[field]}{clear_help}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:event:fieldedit:cancel:{event_id}")]]),
        disable_web_page_preview=True,
    )
    await c.answer()


@router.message(AdminQuickEditStates.waiting_value)
async def quick_edit_field_value(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    data = await state.get_data()
    try:
        event_id = int(data.get("quick_edit_event_id") or 0)
        field = str(data.get("quick_edit_field") or "")
    except (TypeError, ValueError):
        return await message.answer("مرحلهٔ ویرایش معتبر نیست؛ دوباره از مدیریت پنل شروع کنید.")
    if event_id <= 0 or field not in _QUICK_EDIT_LABELS:
        await state.clear()
        return await message.answer("مرحلهٔ ویرایش منقضی شده است.")
    raw = (message.text or "").strip()
    if not raw:
        return await message.answer("مقدار خالی پذیرفته نمی‌شود؛ مقدار معتبر وارد کنید یا /cancel بزنید.")
    if raw == "-":
        await state.clear()
        return await message.answer("ویرایش انجام نشد؛ مقدار فعلی حفظ شد.", reply_markup=admin_menu())
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event or event.archived:
            await state.clear()
            return await message.answer("پنل پیدا نشد یا آرشیو شده است.", reply_markup=admin_menu())
        old_capacity = int(event.capacity)
        used = await seats_used(session, event_id)
        base_price = int(event.price_per_person or 0)
        current_alt = int(event.price_without_cafe_order) if event.price_without_cafe_order else None
    clear_optional = raw in {"—", "–"} and field in {"description", "language", "end_time", "address", "map_url", "alternative_price"}
    value = None
    if clear_optional:
        value = None
    elif field == "title":
        if len(raw) > 255: return await message.answer("عنوان حداکثر ۲۵۵ نویسه می‌تواند باشد.")
        value = raw
    elif field == "description":
        if len(raw) > 4000: return await message.answer("توضیحات حداکثر ۴۰۰۰ نویسه می‌تواند باشد.")
        value = raw
    elif field == "host_name":
        parsed_host = parse_full_name(raw)
        if parsed_host is None: return await message.answer("نام و نام خانوادگی معتبر وارد کنید.")
        value = " ".join(parsed_host)
        if len(value) > 255: return await message.answer("نام میزبان حداکثر ۲۵۵ نویسه می‌تواند باشد.")
    elif field == "questions_pdf":
        return await message.answer("برای تغییر فایل، دکمهٔ «جایگزینی فایل» را بزنید؛ «—» برای حذف فایل به کار می‌رود.")
    elif field == "language":
        if len(raw) > 80: return await message.answer("زبان حداکثر ۸۰ نویسه می‌تواند باشد.")
        value = raw
    elif field == "day_name":
        if len(raw) > 100: return await message.answer("روز نمایشی حداکثر ۱۰۰ نویسه می‌تواند باشد.")
        value = raw
    elif field == "date_text":
        if len(raw) > 255: return await message.answer("تاریخ نمایشی حداکثر ۲۵۵ نویسه می‌تواند باشد.")
        value = raw
    elif field in {"start_time", "end_time"}:
        normalized = normalize_display_time(raw)
        if normalized is None: return await message.answer("زمان را به‌شکل معتبر HH:MM وارد کنید؛ زمان‌ها فقط متن نمایشی هستند.")
        value = normalized
    elif field == "venue":
        if len(raw) > 255: return await message.answer("محل برگزاری حداکثر ۲۵۵ نویسه می‌تواند باشد.")
        value = raw
    elif field == "address":
        if len(raw) > 500: return await message.answer("آدرس حداکثر ۵۰۰ نویسه می‌تواند باشد.")
        value = raw
    elif field == "map_url":
        if len(raw) > 1000: return await message.answer("لینک حداکثر ۱۰۰۰ نویسه می‌تواند باشد.")
        if not is_valid_url(raw): return await message.answer("لینک کامل معتبر با http:// یا https:// وارد کنید، یا «—» برای پاک‌کردن.")
        value = raw
    elif field == "capacity":
        value = parse_integer(raw, minimum=1, maximum=100000)
        if value is None: return await message.answer("ظرفیت باید عدد صحیحی بین ۱ تا ۱۰۰٬۰۰۰ باشد.")
        if value < used: return await message.answer(f"ظرفیت نمی‌تواند از تعداد صندلی‌های رزروشده ({used}) کمتر باشد.")
    elif field == "price":
        value = parse_integer(raw, minimum=0, maximum=1000000000)
        if value is None: return await message.answer("قیمت باید عدد صحیحی بین صفر تا ۱٬۰۰۰٬۰۰۰٬۰۰۰ تومان باشد.")
    elif field == "alternative_price":
        if raw in {"0", "۰"}:
            value = None
        else:
            value = parse_integer(raw, minimum=1, maximum=1000000000)
            if value is None: return await message.answer("قیمت معتبر وارد کنید یا ۰/— برای غیرفعال‌کردن.")
            if base_price <= 0 or value <= base_price:
                return await message.answer("این گزینه باید فعال باشد و قیمت آن از قیمت پایه بیشتر باشد.")
    if field == "price" and value == 0:
        await state.update_data(quick_edit_clears_alt=True)
    elif field == "price" and current_alt is not None and current_alt <= int(value):
        await state.update_data(quick_edit_clears_alt=True)
    elif field == "price":
        await state.update_data(quick_edit_clears_alt=False)
    await state.update_data(quick_edit_pending_value=value, quick_edit_token=secrets.token_hex(8), quick_edit_old_capacity=old_capacity)
    await state.set_state(AdminQuickEditStates.confirming)
    display = _quick_edit_display(value, field)
    extra = "\nقیمت گزینهٔ بدون سفارش کافه نیز به‌طور خودکار غیرفعال می‌شود، چون با قیمت پایهٔ جدید سازگار نیست." if data.get("quick_edit_clears_alt") else ""
    await message.answer(
        f"<b>پیش‌نمایش تغییر پنل #{event_id}</b>\n"
        f"فیلد: {escape(_QUICK_EDIT_LABELS[field])}\n"
        f"مقدار جدید: {escape(display)}{extra}\n\n"
        "برای ذخیره تأیید کنید؛ وضعیت انتشار و باز/بسته‌بودن ثبت‌نام تغییر نمی‌کند.",
        reply_markup=admin_event_field_edit_confirm_keyboard(event_id, str((await state.get_data()).get("quick_edit_token"))),
    )


@router.callback_query(F.data.regexp(r"^admin:event:fieldedit:pdfremove:confirm:\d+$"))
async def quick_edit_questions_file_remove_confirm(c: CallbackQuery):
    """Ask explicitly before detaching the question-file reference from a panel."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        event_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل معتبر نیست.", show_alert=True)
    event = await get_event(event_id)
    if not event or event.archived:
        return await c.answer("پنل پیدا نشد یا آرشیو شده است.", show_alert=True)
    if not event.questions_pdf_path:
        return await c.answer("فایلی برای حذف ثبت نشده است.", show_alert=True)
    old_name = event.questions_file_name or Path(event.questions_pdf_path).name
    await c.message.edit_text(
        f"<b>جداکردن فایل سؤالات از پنل #{event_id}</b>\n\n"
        f"فایل: {escape(old_name)}\n\n"
        "با تأیید، فایل از این پنل جدا می‌شود؛ فایل فیزیکی روی دیسک حذف نخواهد شد. ادامه می‌دهید؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأیید و جداکردن فایل", callback_data=f"admin:event:fieldedit:pdfremove:commit:{event_id}")],
            [InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:event:fieldedit:{event_id}:questions_pdf")],
        ]),
        disable_web_page_preview=True,
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:fieldedit:pdfremove:commit:\d+$"))
async def quick_edit_questions_file_remove_commit(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        event_id = int((c.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if not event or event.archived:
            return await c.answer("پنل پیدا نشد یا آرشیو شده است.", show_alert=True)
        if not event.questions_pdf_path:
            await c.message.edit_text("فایلی برای جداکردن ثبت نشده است.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🔙 بازگشت به پنل", callback_data=f"admin:event:view:{event_id}")]]))
            return await c.answer()
        old_name = event.questions_file_name or Path(event.questions_pdf_path).name
        event.questions_pdf_path = None
        event.questions_file_name = None
        if event.status == EventStatus.DRAFT and event.submission_status == "submitted":
            bump_submission_revision(event)
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="panel_questions_file_reference_removed", entity_type="event", entity_id=event_id, details={"previous_file_name": old_name, "physical_file_deleted": False})
        await session.commit()
    await render_event(c, event_id, answer_callback=False)
    await c.answer("فایل از پنل جدا شد؛ فایل فیزیکی پاک نشده است.")


@router.callback_query(F.data.regexp(r"^admin:event:fieldedit:cancel:\d+$"))
async def quick_edit_cancel(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try: event_id = int((c.data or "").rsplit(":", 1)[1])
    except (TypeError, ValueError, IndexError): return await c.answer("شناسه پنل معتبر نیست.", show_alert=True)
    await state.clear()
    await render_event(c, event_id, answer_callback=False)
    await c.answer("ویرایش لغو شد.")


@router.callback_query(F.data.regexp(r"^admin:event:fieldedit:confirm:\d+:[a-f0-9]+$"))
async def quick_edit_confirm(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try: event_id, token = int(parts[4]), parts[5]
    except (ValueError, IndexError): return await c.answer("تأیید ویرایش معتبر نیست.", show_alert=True)
    data = await state.get_data()
    if (await state.get_state()) != AdminQuickEditStates.confirming.state or data.get("quick_edit_token") != token or int(data.get("quick_edit_event_id") or 0) != event_id:
        return await c.answer("این پیش‌نمایش منقضی شده است؛ فیلد را دوباره انتخاب کنید.", show_alert=True)
    field = str(data.get("quick_edit_field") or "")
    if field not in _QUICK_EDIT_LABELS:
        await state.clear()
        return await c.answer("فیلد ویرایش معتبر نیست.", show_alert=True)
    value = data.get("quick_edit_pending_value")
    capacity_increased = False
    async with SessionLocal() as session:
        event = (await session.execute(select(Event).where(Event.id == event_id).with_for_update())).scalar_one_or_none()
        if not event or event.archived:
            await state.clear()
            return await c.answer("پنل پیدا نشد یا آرشیو شده است.", show_alert=True)
        was_published = event.status == EventStatus.PUBLISHED
        changed_fields = [field]
        used = await seats_used(session, event_id)
        if field == "capacity":
            new_capacity = int(value)
            if new_capacity < used:
                return await c.answer(f"ظرفیت رزروشده هم‌زمان تغییر کرده است ({used} صندلی). پیش‌نمایش را دوباره بسازید.", show_alert=True)
            old_capacity = int(event.capacity)
            try:
                apply_capacity_change(event, old_capacity, new_capacity, used)
            except ValueError:
                return await c.answer("ظرفیت جدید دیگر معتبر نیست؛ دوباره ویرایش کنید.", show_alert=True)
            capacity_increased = new_capacity > old_capacity
        elif field == "title": event.title = str(value)
        elif field == "description": event.description = value
        elif field == "host_name": event.host_name = str(value)
        elif field == "questions_pdf":
            return await c.answer("برای مدیریت فایل سؤالات از گزینهٔ اختصاصی آن استفاده کنید.", show_alert=True)
        elif field == "language": event.language = value
        elif field == "day_name": event.event_day_label = str(value)
        elif field == "date_text": event.event_date_label = str(value)
        elif field == "start_time": event.start_time_label = str(value)
        elif field == "end_time": event.end_time_label = str(value) if value else "—"
        elif field == "venue": event.venue = str(value)
        elif field == "address": event.address = value
        elif field == "map_url": event.map_url = value
        elif field == "price":
            event.price_per_person = int(value)
            if int(value) == 0 or (event.price_without_cafe_order is not None and int(event.price_without_cafe_order) <= int(value)):
                if event.price_without_cafe_order is not None:
                    event.price_without_cafe_order = None
                    if "price_without_cafe_order" not in changed_fields: changed_fields.append("price_without_cafe_order")
        elif field == "alternative_price":
            if value is not None and (int(event.price_per_person) <= 0 or int(value) <= int(event.price_per_person)):
                return await c.answer("قیمت پایه هم‌زمان تغییر کرده است؛ پیش‌نمایش را دوباره بسازید.", show_alert=True)
            event.price_without_cafe_order = value
        if event.status == EventStatus.DRAFT and event.submission_status == "submitted":
            bump_submission_revision(event)
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="panel_field_edited", entity_type="event", entity_id=event_id,
            details={"field": field, "cleared_alternative_price": "price_without_cafe_order" in changed_fields and field == "price"})
        if was_published and field in {"title", "description", "language", "day_name", "date_text", "start_time", "end_time", "venue", "address", "map_url", "capacity", "price", "alternative_price"}:
            from app.services.notification_outbox import enqueue_event_notification
            change_key = f"bot-update-{utc_now_naive().isoformat(timespec='microseconds')}"
            await enqueue_event_notification(session, event_id=event_id, event_type="panel.changed", change_key=change_key)
        await session.commit()
    await state.clear()
    try:
        await reconcile_event_channel_status(c.bot, event_id)
    except Exception:
        logger.exception("Could not reconcile channel status after one-field edit event_id=%s", event_id)
    if capacity_increased:
        try: await notify_waitlist_capacity_available(c.bot, event_id)
        except Exception: logger.exception("Could not notify waitlist after field-based capacity increase event_id=%s", event_id)
    await render_event(c, event_id, answer_callback=False)
    await c.answer("تغییر ذخیره شد.")


@router.message(AdminEditStates.title)
async def edit_title(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        if not value: return await m.answer("عنوان نمی‌تواند خالی باشد؛ عنوان جدید را وارد کنید یا - برای حفظ مقدار فعلی.")
        if len(value) > 255: return await m.answer( "عنوان حداکثر ۲۵۵ کاراکتر می‌تواند باشد.")
        await state.update_data(title=value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(limit_telegram_html(f"توضیحات فعلی: {escape(event.description or '—')}\nمقدار جدید یا -:"))
    await state.set_state(AdminEditStates.description)


@router.message(AdminEditStates.description)
async def edit_description(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        if not value: return await m.answer("توضیحات نمی‌تواند خالی باشد؛ متن جدید را وارد کنید یا - برای حفظ مقدار فعلی.")
        if len(value) > 4000: return await m.answer( "توضیحات حداکثر ۴۰۰۰ کاراکتر می‌تواند باشد.")
        await state.update_data(description=value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(
        panel_detail_line("زبان فعلی پنل", escape(event.language or 'ثبت نشده'), icon="🌐") + "\n"
        "زبان جدید را وارد کنید یا - برای حفظ مقدار فعلی:"
    )
    await state.set_state(AdminEditStates.language)


@router.message(AdminEditStates.language)
async def edit_language(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        normalized = normalize_panel_language(value)
        if normalized is None:
            return await m.answer("نام زبان معتبر نیست؛ مانند English، فارسی یا Français وارد کنید، یا - برای حفظ مقدار فعلی.")
        await state.update_data(language=normalized)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(panel_detail_line("نام روز فعلی", escape(event.event_day_label), icon="📅") + "\nنام روز جدید یا -:")
    await state.set_state(AdminEditStates.day_name)


@router.message(AdminEditStates.day_name)
async def edit_day_name(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        if not value: return await m.answer("نام روز نمی‌تواند خالی باشد.")
        if len(value) > 100: return await m.answer( "نام روز حداکثر ۱۰۰ کاراکتر می‌تواند باشد.")
        await state.update_data(day_name=value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(panel_detail_line("تاریخ فعلی", escape(event.event_date_label), icon="📆") + "\nتاریخ جدید یا - برای حفظ مقدار فعلی:")
    await state.set_state(AdminEditStates.date_text)


@router.message(AdminEditStates.date_text)
async def edit_date_text(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        if not value: return await m.answer("تاریخ نمی‌تواند خالی باشد.")
        if len(value) > 255: return await m.answer( "متن تاریخ حداکثر ۲۵۵ کاراکتر می‌تواند باشد.")
        await state.update_data(date_text=value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(panel_detail_line("محل فعلی", escape(event.venue), icon="📍") + "\nنام جدید یا -:")
    await state.set_state(AdminEditStates.venue)


@router.message(AdminEditStates.venue)
async def edit_venue(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-" and not value:
        return await m.answer("نام محل نمی‌تواند خالی باشد؛ نام جدید یا - برای حفظ مقدار فعلی.")
    if value != "-" and len(value) > 255:
        return await m.answer( "نام محل حداکثر ۲۵۵ کاراکتر می‌تواند باشد.")
    if value != "-" and is_link_like_text(value):
        return await m.answer(
            "❌ این قسمت برای نام و آدرس متنی محل برگزاری است، نه لینک.\n"
            "لطفاً آدرس یا نام محل را به‌صورت متنی وارد کنید.\n"
            "لینک مکان در مرحله بعد از شما دریافت می‌شود."
        )
    if value != "-": await state.update_data(venue=value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(panel_detail_line("آدرس فعلی", escape(event.address or '—'), icon="📌") + "\nآدرس جدید یا - برای خالی:")
    await state.set_state(AdminEditStates.address)


@router.message(AdminEditStates.address)
async def edit_address(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-" and not value:
        return await m.answer("آدرس خالی است؛ آدرس را وارد کنید یا - برای حذف آن.")
    if value != "-" and len(value) > 500:
        return await m.answer( "آدرس حداکثر ۵۰۰ کاراکتر می‌تواند باشد.")
    if value != "-" and is_link_like_text(value):
        return await m.answer(
            "❌ این قسمت برای نام و آدرس متنی محل برگزاری است، نه لینک.\n"
            "لطفاً آدرس یا نام محل را به‌صورت متنی وارد کنید.\n"
            "لینک مکان در مرحله بعد از شما دریافت می‌شود."
        )
    await state.update_data(address=None if value == "-" else value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(f"لینک فعلی: {escape(event.map_url or '—')}\nURL جدید یا - برای حذف:")
    await state.set_state(AdminEditStates.map_url)


@router.message(AdminEditStates.map_url)
async def edit_map(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-" and not is_valid_url(value): return await m.answer("URL معتبر و کامل http(s) وارد کنید؛ مثال: https://maps.google.com/...")
    if value != "-" and len(value) > 1000: return await m.answer("لینک نقشه حداکثر ۱۰۰۰ کاراکتر می‌تواند باشد.")
    await state.update_data(map_url=None if value == "-" else value)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(panel_detail_line("ظرفیت فعلی", event.capacity, icon="👥") + "\nظرفیت جدید یا -:")
    await state.set_state(AdminEditStates.capacity)


@router.message(AdminEditStates.capacity)
async def edit_capacity(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    if value != "-":
        n = parse_integer(value, minimum=1, maximum=100000)
        if n is None: return await m.answer( "ظرفیت باید عدد صحیحی بین ۱ تا ۱۰۰٬۰۰۰ باشد.")
        await state.update_data(capacity=n)
    data = await state.get_data(); event = await get_event(data["edit_event_id"])
    await m.answer(panel_detail_line("قیمت فعلی", f"{int(event.price_per_person):,} تومان", icon="💰") + "\nقیمت جدید یا -:")
    await state.set_state(AdminEditStates.price)


@router.message(AdminEditStates.price)
async def edit_price(m: Message, state: FSMContext):
    value = (m.text or "").strip()
    data = await state.get_data()
    eid = int(data["edit_event_id"])
    async with SessionLocal() as session:
        current_event = await session.get(Event, eid)
        if current_event is None:
            await state.clear()
            return await m.answer("پنل پیدا نشد؛ دوباره از مدیریت پنل‌ها اقدام کنید.", reply_markup=admin_menu())
        base_value = int(current_event.price_per_person)
    if value != "-":
        n = parse_integer(value, minimum=0, maximum=1000000000)
        if n is None:
            return await m.answer("قیمت باید عدد صحیحی بین صفر تا ۱٬۰۰۰٬۰۰۰٬۰۰۰ تومان باشد یا - برای حفظ قیمت فعلی.")
        base_value = n
        await state.update_data(price=n)
    if base_value > 0:
        current_alternative = int(current_event.price_without_cafe_order) if current_event.price_without_cafe_order else None
        can_keep_alternative = current_alternative is not None and current_alternative > base_value
        if current_alternative is None:
            current_label = "گزینهٔ بدون سفارش کافه فعلاً غیرفعال است."
        elif can_keep_alternative:
            current_label = f"قیمت فعلی گزینه: {current_alternative:,} تومان"
        else:
            current_label = (
                f"قیمت فعلی گزینه ({current_alternative:,} تومان) با قیمت پایهٔ جدید سازگار نیست؛ "
                "قیمت این گزینه باید از قیمت پایه بیشتر باشد."
            )
        await state.update_data(alternative_price_prompt_base=base_value)
        await state.set_state(AdminEditStates.alternative_price)
        await m.answer(
            f"{current_label}\n\nقیمت گزینهٔ «بدون سفارش اجباری از منوی کافه» را به تومان وارد کنید.\n"
            "برای غیرفعال‌کردن این گزینه، دکمهٔ زیر را بزنید. "
            + ("برای حفظ قیمت فعلی، دکمهٔ «حفظ قیمت فعلی» را بزنید." if can_keep_alternative else ""),
            reply_markup=alternative_price_keyboard(include_keep=can_keep_alternative, for_edit=True),
        )
        return
    # A zero base price means the panel is free; the alternative option is disabled.
    await state.update_data(price_without_cafe_order=None)
    return await _finish_event_edit(m, state, eid)


@router.callback_query(F.data == "admin:event:alternative:disable")
async def disable_create_alternative_price(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != AdminEventStates.alternative_price.state:
        return await c.answer("این مرحله دیگر فعال نیست.", show_alert=True)
    await state.update_data(price_without_cafe_order=None)
    await state.set_state(AdminEventStates.waitlist)
    await _creation_prompt(c.message, state, "گزینهٔ بدون سفارش کافه غیرفعال شد.\nلیست انتظار فعال باشد؟ «بله» یا «خیر»:")
    await c.answer("گزینه غیرفعال شد.")


@router.callback_query(F.data.regexp(r"^admin:event:edit:alternative:(keep|disable)$"))
async def edit_alternative_price_quick_action(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != AdminEditStates.alternative_price.state:
        return await c.answer("این مرحله دیگر فعال نیست.", show_alert=True)
    data = await state.get_data()
    eid = int(data.get("edit_event_id") or 0)
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        current_alternative = int(event.price_without_cafe_order) if event and event.price_without_cafe_order else None
    if not event:
        await state.clear()
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if c.data.endswith(":keep"):
        base_value = int(data.get("price", data.get("alternative_price_prompt_base", event.price_per_person)) or 0)
        if current_alternative is None or current_alternative <= base_value:
            return await c.answer("قیمت فعلی برای قیمت پایهٔ جدید معتبر نیست؛ قیمت دیگری وارد کنید یا گزینه را غیرفعال کنید.", show_alert=True)
        alternative = current_alternative
    else:
        alternative = None
    await state.update_data(price_without_cafe_order=alternative)
    await _finish_event_edit(c.message, state, eid)
    await c.answer("قیمت فعلی حفظ شد." if alternative else "گزینه غیرفعال شد.")


@router.message(AdminEditStates.alternative_price)
async def edit_alternative_price(m: Message, state: FSMContext):
    raw = (m.text or "").strip()
    data = await state.get_data()
    eid = int(data["edit_event_id"])
    base_value = int(data.get("price", data.get("alternative_price_prompt_base", 0)))
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        current_alternative = int(event.price_without_cafe_order) if event and event.price_without_cafe_order else None
    if raw == "-":
        alternative = current_alternative
        if alternative is not None and alternative <= base_value:
            return await m.answer(
                "قیمت پایهٔ جدید از گزینهٔ فعلی بیشتر است. قیمت جایگزین جدیدی وارد کنید که از قیمت پایه بیشتر باشد، یا «—»/۰ برای غیرفعال کردن بفرستید."
            )
    elif raw in {"—", "–", "0", "۰"}:
        alternative = None
    else:
        parsed = parse_integer(raw, minimum=0, maximum=1000000000)
        if parsed is None:
            return await m.answer("قیمت معتبر وارد کنید یا یکی از دکمه‌های زیر را بزنید.", reply_markup=alternative_price_keyboard(include_keep=bool(current_alternative and current_alternative > base_value), for_edit=True))
        alternative = parsed or None
        if alternative is not None and alternative <= base_value:
            return await m.answer("قیمت این گزینه باید از قیمت پایه بیشتر باشد. عدد دیگری وارد کنید یا گزینه را با دکمه غیرفعال کنید.", reply_markup=alternative_price_keyboard(include_keep=bool(current_alternative and current_alternative > base_value), for_edit=True))
    await state.update_data(price_without_cafe_order=alternative)
    return await _finish_event_edit(m, state, eid)


async def _finish_event_edit(m: Message, state: FSMContext, eid: int):
    data = await state.get_data()
    was_published = False
    async with SessionLocal() as session:
        event = await session.get(Event, eid, with_for_update=True)
        if event is None:
            await state.clear()
            return await m.answer("پنل پیدا نشد؛ دوباره از مدیریت پنل‌ها اقدام کنید.", reply_markup=admin_menu())
        was_published = event.status == EventStatus.PUBLISHED
        actor = (await session.execute(select(User).where(User.telegram_id == int(m.from_user.id)))).scalar_one_or_none()
        actor_is_admin = int(m.from_user.id) in settings.super_admin_id_set or bool(actor and actor.role == UserRole.SUPER_ADMIN)
        if not actor_is_admin:
            if not actor or actor.role != UserRole.HOST or event.host_id != actor.id or event.status != EventStatus.DRAFT or event.submission_status not in {"draft", "rejected"}:
                await state.clear()
                return await m.answer("اجازهٔ ویرایش این پنل وجود ندارد؛ میزبان‌ها فقط پیش‌نویس‌های خود را که در حال بررسی نیستند ویرایش می‌کنند.", reply_markup=admin_menu())
            if event.submission_status == "rejected":
                event.submission_status = "draft"
                event.submission_feedback = None
        used = await seats_used(session, eid)
        old_capacity = int(event.capacity)
        new_capacity = int(data["capacity"]) if "capacity" in data else old_capacity
        if new_capacity < used:
            await state.set_state(AdminEditStates.capacity)
            return await m.answer(f"ظرفیت جدید نمی‌تواند از ظرفیت رزروشده فعلی ({used}) کمتر باشد. ظرفیت دیگری وارد کنید یا - بفرستید:")
        if "day_name" in data:
            event.event_day_label = data["day_name"]
        if "date_text" in data:
            event.event_date_label = data["date_text"]
        for field in ("title", "description", "language", "venue", "address", "map_url", "price", "price_without_cafe_order"):
            if field in data:
                setattr(event, "price_per_person" if field == "price" else field, data[field])
        if "capacity" in data:
            try:
                apply_capacity_change(event, old_capacity, new_capacity, used)
            except ValueError:
                await state.set_state(AdminEditStates.capacity)
                return await m.answer("ظرفیت جدید برای تعداد رزروهای فعلی معتبر نیست. دوباره وارد کنید:")
        if int(event.price_per_person) == 0:
            event.price_without_cafe_order = None
        elif event.price_without_cafe_order is not None and int(event.price_without_cafe_order) <= int(event.price_per_person):
            # Do not retain an alternative price that is no longer higher after the base price edit.
            event.price_without_cafe_order = None
        capacity_increased = new_capacity > old_capacity
        changed_fields = sorted(k for k in ("title", "description", "language", "venue", "address", "map_url", "price", "price_without_cafe_order", "capacity", "day_name", "date_text") if k in data)
        if actor_is_admin and changed_fields and event.status == EventStatus.DRAFT and event.submission_status == "submitted":
            bump_submission_revision(event)
        if actor_is_admin:
            from app.services.admin_audit import write_admin_action
            await write_admin_action(session, actor_telegram_id=int(m.from_user.id), action="panel_edited", entity_type="event", entity_id=eid, details={"changed_fields": changed_fields})
        else:
            session.add(AdminAction(actor_user_id=int(actor.id), action="host_panel_edited", entity_type="event", entity_id=eid, details=json.dumps({"changed_fields": changed_fields}, ensure_ascii=False), created_at=utc_now_naive()))
        public_change_fields = {"title", "description", "language", "venue", "address", "map_url", "price", "price_without_cafe_order", "capacity", "day_name", "date_text"}
        if was_published and public_change_fields.intersection(changed_fields):
            from app.services.notification_outbox import enqueue_event_notification
            change_key = f"bot-update-{utc_now_naive().isoformat(timespec='microseconds')}"
            await enqueue_event_notification(session, event_id=eid, event_type="panel.changed", change_key=change_key)
        await session.commit()
    await reconcile_event_channel_status(m.bot, eid)
    if capacity_increased:
        try:
            await notify_waitlist_capacity_available(m.bot, eid)
        except Exception:
            logger.exception("Failed to notify waitlist after capacity increase for event_id=%s", eid)
    await state.clear()
    if actor_is_admin:
        await m.answer("✅ پنل ویرایش شد.", reply_markup=admin_menu())
    else:
        await m.answer("✅ پیش‌نویس پنل ویرایش شد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🎤 پنل‌های من", callback_data="host:home")], [InlineKeyboardButton(text="مشاهده پنل", callback_data=f"host:panel:view:{eid}")]]))


async def _payment_rows(event_id: int | None = None):
    async with SessionLocal() as session:
        stmt = (
            select(Payment)
            .join(Payment.booking)
            .options(
                selectinload(Payment.booking).selectinload(Booking.booked_by),
                selectinload(Payment.booking).selectinload(Booking.event),
                selectinload(Payment.booking).selectinload(Booking.participants),
            )
            .where(
                Payment.status == PaymentStatus.PENDING,
                Booking.status == RegistrationStatus.PENDING_VERIFICATION,
                (
                    (Payment.receipt_file.is_not(None) & (Payment.receipt_file != ""))
                    | (Payment.receipt_text.is_not(None) & (Payment.receipt_text != ""))
                ),
            )
            .order_by(Payment.created_at, Payment.id)
        )
        if event_id:
            stmt = stmt.where(Booking.event_id == event_id)
        return (await session.execute(stmt)).scalars().all()


async def _show_payment(
    c: CallbackQuery, payment: Payment, event_id: int | None = None, *, receipt_count: int | None = None,
):
    path = resolve_upload_path(payment.receipt_file or "")
    current_token = receipt_review_token(payment)
    booking = payment.booking
    owner = booking.booked_by
    text = (
        f"<b>پرداخت #{payment.id}</b>\n"
        f"{volume_label(booking.event.volume)} — {escape(booking.event.title)}\n"
        f"صاحب رزرو: {escape(owner.display_name or str(owner.telegram_id))}\n"
        f"تعداد نفرات: {booking.participant_count}\n"
        f"مبلغ: {int(payment.amount):,} تومان\n"
        + f"شیوهٔ ثبت‌نام: {escape(booking_option_detail_label(getattr(booking, 'pricing_option', None), base_price=getattr(booking, 'base_price_snapshot', None), alternative_price=getattr(booking, 'alternative_price_snapshot', None)))}\n"
        + (f"🎟 کد تخفیف اعمال‌شده: <code>{escape(booking.discount_code_snapshot)}</code> (تخفیف {int(booking.discount_amount or 0):,} تومان)\n" if booking.discount_code_snapshot else "")
        + f"زمان: {payment.created_at:%Y-%m-%d %H:%M}\n"
        + f"وضعیت: {admin_status_display_label(payment.status)}\n"
        + f"نوع رسید: {'متن' if payment.receipt_text else 'فایل/تصویر'}"
    )
    if payment.receipt_text:
        text += f"\n\n<b>متن رسید:</b>\n{escape(payment.receipt_text)}"
    if receipt_count is None:
        receipt_count = len(await _payment_rows(event_id))
    can_navigate = int(receipt_count) > 1
    if not can_navigate:
        text += "\n\nℹ️ این تنها رسید موجود برای بررسی است؛ رسید دیگری در صف نیست."
    await c.message.edit_text(
        limit_telegram_html(text),
        reply_markup=payment_review_keyboard(payment.id, current_token, event_id, can_navigate=can_navigate),
    )
    if path:
        await c.bot.send_document(c.from_user.id, FSInputFile(path), caption=f"🧾 رسید پرداخت #{payment.id}")
    if not path and not payment.receipt_text:
        await c.message.answer("رسید ذخیره‌شده پیدا نشد.")


@router.callback_query(F.data == "admin:payments")
async def payments(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text(
        "صف سراسری پرداخت‌ها حذف شده است. برای بررسی رسید، از بخش «مدیریت پنل‌ها» وارد پنل موردنظر شوید و «پرداخت‌های این پنل» را انتخاب کنید.",
        reply_markup=admin_menu(),
    )
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:payments:"))
async def event_payments(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    payments = await _payment_rows(eid)
    if not payments:
        await c.message.edit_text("پرداخت در انتظار بررسی برای این پنل وجود ندارد.", reply_markup=admin_menu())
        return await c.answer()
    await _show_payment(c, payments[0], eid, receipt_count=len(payments))
    await c.answer()


@router.callback_query(F.data.startswith("admin:payment:next:"))
@router.callback_query(F.data.startswith("admin:payment:prev:"))
async def navigate_payment_receipt(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        direction = parts[2]
        current_id = int(parts[3])
        scope_id = int(parts[4])
        if current_id <= 0 or scope_id < 0 or direction not in {"next", "prev"}:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("دکمهٔ جابه‌جایی نامعتبر است؛ صف پرداخت‌ها را دوباره باز کنید.", show_alert=True)
    event_id = scope_id or None
    rows = await _payment_rows(event_id)
    if not rows:
        await c.message.edit_text("پرداخت در انتظار بررسی دیگری وجود ندارد.", reply_markup=admin_menu())
        return await c.answer()
    if len(rows) <= 1:
        return await c.answer("این تنها رسید موجود است؛ رسید دیگری برای نمایش وجود ندارد.", show_alert=True)
    ids = [int(p.id) for p in rows]
    if current_id in ids:
        pos = ids.index(current_id)
        target_pos = (pos + (1 if direction == "next" else -1)) % len(rows)
    else:
        candidates = [i for i, pid in enumerate(ids) if pid > current_id]
        if direction == "next":
            target_pos = candidates[0] if candidates else 0
        else:
            candidates = [i for i, pid in enumerate(ids) if pid < current_id]
            target_pos = candidates[-1] if candidates else len(rows) - 1
    await _show_payment(c, rows[target_pos], event_id, receipt_count=len(rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:participants_page:\d+:\d+$"))
async def participants_page(c: CallbackQuery):
    """Navigate the compact, paginated roster without overfilling a Telegram message."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        eid, page = int(parts[3]), int(parts[4])
        if eid <= 0 or page <= 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل یا صفحه نامعتبر است.", show_alert=True)
    await _render_participants(c, eid, page)


@router.callback_query(F.data.startswith("admin:event:participants:"))
async def participants(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    await _render_participants(c, eid, 1)


async def _render_participants(c: CallbackQuery, eid: int, requested_page: int = 1):
    async with SessionLocal() as session:
        expired_event_ids = await expire_event_bookings_best_effort(session, eid)
        bookings = (await session.execute(
            select(Booking).options(
                selectinload(Booking.participants),
                selectinload(Booking.booked_by),
                selectinload(Booking.payment),
            ).where(Booking.event_id == eid).order_by(Booking.created_at, Booking.id)
        )).scalars().all()
        event = await session.get(Event, eid)
        waitlist_rows = (await session.execute(
            select(WaitlistEntry, User)
            .outerjoin(User, WaitlistEntry.user_id == User.id)
            .where(WaitlistEntry.event_id == eid, WaitlistEntry.status.in_(["waiting", "invited", "inviting"]))
            .order_by(WaitlistEntry.position, WaitlistEntry.created_at)
        )).all()
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if eid in expired_event_ids:
        try:
            await reconcile_event_channel_status(c.bot, eid)
        except Exception:
            logger.exception("Failed to reconcile capacity after expiring bookings for event_id=%s", eid)

    active_statuses = {
        RegistrationStatus.PENDING_PAYMENT,
        RegistrationStatus.PENDING_VERIFICATION,
        RegistrationStatus.CONFIRMED,
    }
    active_bookings = [booking for booking in bookings if booking.status in active_statuses]
    active_seats = sum(int(booking.participant_count or 0) for booking in active_bookings)

    # Keep bookings together so names registered by the same person are visually
    # grouped beneath a single, compact set of booker/contact details. Include old
    # and cancelled rows too: this screen is an administrative roster, not just a
    # live-seat counter, and the status columns explain whether each reservation is active.
    roster = []
    running_number = 1
    for booking in bookings:
        people = list(booking.participants or [])
        if not people:
            continue
        roster.append((booking, people, running_number))
        running_number += len(people)

    # Aim for about 12 attendees per page without splitting group reservations.
    roster_pages = []
    current_page = []
    current_people = 0
    for item in roster:
        people_count = len(item[1])
        if current_page and current_people >= 12:
            roster_pages.append(current_page)
            current_page = []
            current_people = 0
        current_page.append(item)
        current_people += people_count
    if current_page:
        roster_pages.append(current_page)

    total_people = running_number - 1
    page_count = max(1, len(roster_pages))
    page = min(max(1, requested_page), page_count)
    page_roster = roster_pages[page - 1] if roster_pages else []
    lines = [
        f"<b>{volume_label(event.volume)} — {escape(event.title)}</b>",
        f"ظرفیت: {event.capacity} | رزروشده/در انتظار: {active_seats}",
        f"شرکت‌کنندگان: {total_people} | صفحه {page}/{page_count}",
        "",
    ]
    if not page_roster:
        lines.append("هنوز نامی در رزروهای این پنل ثبت نشده است.")
    else:
        for booking, people, start_no in page_roster:
            booker = booking.booked_by
            owner_name = (
                getattr(booker, "display_name", None)
                or " ".join(x for x in [getattr(booker, "first_name", None), getattr(booker, "last_name", None)] if x)
                or "—"
            )
            username = f" | @{escape(str(booker.telegram_username).lstrip('@'))}" if booker and booker.telegram_username else ""
            telegram_id = str(booker.telegram_id) if booker and booker.telegram_id is not None else "—"
            phone = escape(booking_contact_phone(booking) or "—")
            payment_obj = getattr(booking, "payment", None)
            payment_value = getattr(payment_obj, "status", None)
            payment_status = escape(admin_status_display_label(payment_value)) if payment_value is not None else "رکورد پرداختی وجود ندارد"
            reservation_value = getattr(booking, "status", None)
            reservation_status = escape(admin_status_display_label(reservation_value))
            first_name = escape(str(getattr(people[0], "full_name", None) or "—"))
            lines.append(f"<b>{start_no}. {first_name}</b>")
            lines.append(
                f"   📱 تلفن: {phone} | 👤 رزروکننده: {escape(str(owner_name))}{username} | ID: <code>{escape(telegram_id)}</code>"
            )
            lines.append(f"   💳 پرداخت: {payment_status} | 🧾 رزرو: {reservation_status}")
            for offset, person in enumerate(people[1:], start=1):
                name = escape(str(getattr(person, "full_name", None) or "—"))
                lines.append(f"   ↳ {start_no + offset}. {name}")
            lines.append("")

    if page == 1 and waitlist_rows:
        lines.append(f"<b>لیست انتظار ({len(waitlist_rows)})</b>")
        for entry, user in waitlist_rows[:3]:
            display_name = (
                getattr(user, "display_name", None)
                or " ".join(x for x in [getattr(user, "first_name", None), getattr(user, "last_name", None)] if x)
                or (f"@{user.telegram_username}" if user and user.telegram_username else f"ID {user.telegram_id}" if user else "کاربر ناشناس")
            )
            waitlist_status = {"invited": "دعوت‌شده", "inviting": "در حال ارسال دعوت", "waiting": "در انتظار"}.get(str(entry.status), admin_status_display_label(entry.status))
            lines.append(f"{entry.position}. {escape(str(display_name)[:55])} — {entry.requested_participant_count} نفر — {waitlist_status}")
        if len(waitlist_rows) > 3:
            lines.append(f"… {len(waitlist_rows) - 3} درخواست دیگر در لیست انتظار")

    action_rows = [[InlineKeyboardButton(text="📊 خروجی شرکت‌کنندگان (Excel)", callback_data=f"admin:event:export:{eid}")]]
    if event.waitlist_enabled and event.status == EventStatus.PUBLISHED and not event.archived:
        action_rows[0].append(InlineKeyboardButton(text="📨 دعوت نفر بعدی از لیست انتظار", callback_data=f"admin:event:waitlist:invite:{eid}"))
    action_rows.append([InlineKeyboardButton(text="⏳ رزروهای در انتظار پرداخت", callback_data=f"admin:event:pending:{eid}")])
    if page_count > 1:
        nav = []
        if page > 1:
            nav.append(InlineKeyboardButton(text="◀️ قبلی", callback_data=f"admin:event:participants_page:{eid}:{page - 1}"))
        if page < page_count:
            nav.append(InlineKeyboardButton(text="بعدی ▶️", callback_data=f"admin:event:participants_page:{eid}:{page + 1}"))
        action_rows.append(nav)
    action_rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data=f"admin:event:view:{eid}")])
    await c.message.edit_text(limit_telegram_html("\n".join(lines)), reply_markup=InlineKeyboardMarkup(inline_keyboard=action_rows), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:pending:\d+$"))
async def pending_reservations(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        expired = await expire_event_bookings_best_effort(session, eid)
        event = await session.get(Event, eid)
        rows = (await session.execute(
            select(Booking).options(
                selectinload(Booking.booked_by),
                selectinload(Booking.participants),
                selectinload(Booking.payment),
            ).where(
                Booking.event_id == eid,
                Booking.status == RegistrationStatus.PENDING_PAYMENT,
            ).order_by(Booking.created_at, Booking.id)
        )).scalars().all()
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    lines = [
        f"<b>رزروهای در انتظار پرداخت — {volume_label(event.volume)} | {escape(event.title)}</b>",
        "این افراد هنوز رسیدی برای بررسی نفرستاده‌اند. لغو فقط پس از تأیید شما انجام می‌شود.",
        "",
    ]
    buttons = []
    for booking in rows[:40]:
        owner = booking.booked_by
        owner_name = owner.display_name or " ".join(filter(None, [owner.first_name, owner.last_name])) or f"ID {owner.telegram_id}"
        people = ", ".join(p.full_name for p in booking.participants[:3]) or "نام شرکت‌کننده ثبت نشده"
        expires = booking.expires_at.strftime("%Y-%m-%d %H:%M") if booking.expires_at else "بدون مهلت ثبت‌شده"
        lines.append(
            f"<b>رزرو #{booking.id}</b> — {booking.participant_count} نفر — {int(booking.total_amount):,} تومان\n"
            f"ثبت‌کننده: {escape(owner_name)} | شناسه تلگرام: <code>{owner.telegram_id}</code>\n"
            f"شرکت‌کنندگان: {escape(people)}\nمهلت پرداخت: {escape(expires)}"
        )
        buttons.append([InlineKeyboardButton(
            text=f"❌ لغو رزرو #{booking.id} ({str(owner_name)[:20]})",
            callback_data=f"admin:event:pending:cancel:{eid}:{booking.id}",
        )])
    if not rows:
        lines.append("✅ رزرو در انتظار پرداختی برای این پنل وجود ندارد.")
    elif len(rows) > 40:
        lines.append(f"\nفقط ۴۰ رزرو نخست نمایش داده شد؛ {len(rows) - 40} مورد دیگر وجود دارد.")
    buttons.append([InlineKeyboardButton(text="🔙 بازگشت به ثبت‌نام‌شده‌ها", callback_data=f"admin:event:participants:{eid}")])
    await c.message.edit_text(limit_telegram_html("\n\n".join(lines)), reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:pending:cancel:\d+:\d+$"))
async def confirm_cancel_pending_reservation(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        eid, bid = int(parts[4]), int(parts[5])
        if eid <= 0 or bid <= 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل یا رزرو نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        row = (await session.execute(
            select(Booking, Event, User).join(Event, Event.id == Booking.event_id)
            .join(User, User.id == Booking.booked_by_user_id)
            .where(Booking.id == bid, Booking.event_id == eid)
        )).one_or_none()
    if not row:
        return await c.answer("رزرو پیدا نشد یا به این پنل تعلق ندارد.", show_alert=True)
    booking, event, user = row
    if booking.status != RegistrationStatus.PENDING_PAYMENT:
        return await c.answer("این رزرو دیگر در انتظار پرداخت نیست؛ فهرست را تازه کنید.", show_alert=True)
    name = user.display_name or f"کاربر {user.telegram_id}"
    await c.message.edit_text(
        f"<b>لغو دستی رزرو</b>\n\nپنل: {volume_label(event.volume)} — {escape(event.title)}\n"
        f"رزرو: #{booking.id} | ثبت‌کننده: {escape(name)} | {booking.participant_count} نفر\n\n"
        "با تأیید شما فقط همین رزرو لغو و صندلی‌های آن آزاد می‌شود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله، لغو شود", callback_data=f"admin:event:pending:cancel:confirm:{eid}:{bid}")],
            [InlineKeyboardButton(text="↩️ بازگشت", callback_data=f"admin:event:pending:{eid}")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:pending:cancel:confirm:"))
async def cancel_pending_reservation(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        eid, bid = int(parts[5]), int(parts[6])
        if eid <= 0 or bid <= 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ پنل یا رزرو نامعتبر است.", show_alert=True)
    from app.services.booking import admin_cancel_pending_payment
    async with SessionLocal() as session:
        try:
            booking = await admin_cancel_pending_payment(session, bid, eid, commit=False)
            await write_admin_action(session, actor_telegram_id=c.from_user.id, action="reservation_cancelled_by_admin", entity_type="booking", entity_id=int(booking.id), details={"event_id": eid, "booking_status": "cancelled"})
            await session.commit()
            owner = await session.get(User, booking.booked_by_user_id)
            event = await session.get(Event, eid)
            owner_tg_id = int(owner.telegram_id) if owner else None
            panel_label = f"{volume_label(event.volume)} — {event.title}" if event else f"پنل #{eid}"
            booking_id = booking.id
        except ValueError as exc:
            await session.rollback()
            message = {
                "NOT_FOUND": "رزرو پیدا نشد یا به این پنل تعلق ندارد.",
                "NOT_PENDING_PAYMENT": "وضعیت رزرو تغییر کرده است؛ فهرست را تازه کنید.",
            }.get(str(exc), "لغو رزرو انجام نشد.")
            return await c.answer(message, show_alert=True)
        except Exception:
            await session.rollback()
            logger.exception("Admin cancellation failed for pending booking_id=%s", bid)
            return await c.answer("لغو رزرو به دلیل خطای فنی انجام نشد.", show_alert=True)
    if owner_tg_id:
        try:
            await c.bot.send_message(
                owner_tg_id,
                f"⚠️ رزرو #{booking_id} برای <b>{escape(panel_label)}</b> به دلیل پرداخت‌نشدن، توسط مدیریت لغو شد.\n"
                "صندلی‌های رزرو آزاد شده‌اند. در صورت تمایل می‌توانید از فهرست پنل‌های پیش‌رو دوباره اقدام کنید.",
            )
        except Exception:
            logger.exception("Could not notify user about admin-cancelled pending booking_id=%s", booking_id)
    try:
        await reconcile_event_channel_status(c.bot, eid)
    except Exception:
        logger.exception("Could not reconcile capacity after admin cancellation; event_id=%s", eid)
    try:
        await notify_waitlist_capacity_available(c.bot, eid)
    except Exception:
        logger.exception("Could not notify waitlist after admin cancellation; event_id=%s", eid)
    await c.answer("رزرو لغو شد و ظرفیت آزاد شد.")
    await c.message.edit_text(
        "✅ رزرو در انتظار پرداخت لغو شد و ظرفیت آزاد شد.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⏳ بازگشت به رزروهای در انتظار پرداخت", callback_data=f"admin:event:pending:{eid}")],
            [InlineKeyboardButton(text="👥 ثبت‌نام‌شده‌ها", callback_data=f"admin:event:participants:{eid}")],
            [InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{eid}")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:event:reconciliation:\d+$"))
async def export_financial_reconciliation(c: CallbackQuery):
    """Admin-only financial ledger with a matching audit entry."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    try:
        async with SessionLocal() as session:
            event = await session.get(Event, eid)
            if not event:
                return await c.answer("پنل پیدا نشد.", show_alert=True)
            bookings = (await session.execute(
                select(Booking).options(
                    selectinload(Booking.participants),
                    selectinload(Booking.booked_by),
                    selectinload(Booking.payment),
                ).where(Booking.event_id == eid).order_by(Booking.created_at, Booking.id)
            )).scalars().all()
            reviewer_ids = {
                int(booking.payment.reviewed_by)
                for booking in bookings
                if booking.payment is not None and booking.payment.reviewed_by is not None
            }
            reviewed_by_telegram_ids = {}
            if reviewer_ids:
                reviewers = (await session.execute(
                    select(User.id, User.telegram_id).where(User.id.in_(reviewer_ids))
                )).all()
                reviewed_by_telegram_ids = {int(user_id): int(tg_id) for user_id, tg_id in reviewers}
            payload = build_financial_reconciliation_workbook(event, bookings, reviewed_by_telegram_ids)
            await write_admin_action(
                session,
                actor_telegram_id=c.from_user.id,
                action="financial_reconciliation_export",
                entity_type="event",
                entity_id=eid,
                details={"booking_count": len(bookings)},
            )
            await session.commit()
    except Exception:
        logger.exception("Financial reconciliation export failed for event_id=%s admin_id=%s", eid, c.from_user.id)
        return await c.answer("تهیهٔ گزارش تطبیق مالی ناموفق بود؛ گزارش ساخته یا ارسال نشد.", show_alert=True)

    filename = f"financial_reconciliation_event_{eid}.xlsx"
    await c.answer("گزارش تطبیق مالی آماده شد.")
    try:
        await c.message.answer_document(
            BufferedInputFile(payload, filename=filename),
            caption=(
                f"📊 گزارش تطبیق مالی — {escape(volume_label(event.volume))} — {escape(event.title)}\n"
                "این گزارش بر اساس رکوردهای ربات است؛ برای تأیید انتقال وجه، وضعیت بانک/درگاه را جداگانه بررسی کنید."
            ),
        )
    except Exception:
        logger.exception("Could not deliver financial reconciliation export for event_id=%s", eid)
        try:
            await c.bot.send_message(c.from_user.id, "گزارش ساخته شد، اما ارسال فایل ناموفق بود. دوباره تلاش کنید.")
        except Exception:
            logger.exception("Could not notify admin about reconciliation delivery failure")


@router.callback_query(F.data.startswith("admin:event:export:"))
async def export_participants(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        expired_event_ids = await expire_event_bookings_best_effort(session, eid)
        bookings = (await session.execute(
            select(Booking).options(
                selectinload(Booking.participants),
                selectinload(Booking.booked_by),
                selectinload(Booking.payment),
            ).where(Booking.event_id == eid).order_by(Booking.created_at, Booking.id)
        )).scalars().all()
        # Newer bookings snapshot discount type directly. This lookup also lets
        # exports correctly allocate old bookings whose linked code still exists.
        discount_code_ids = {
            int(booking.discount_code_id) for booking in bookings
            if getattr(booking, "discount_code_id", None) is not None
        }
        discount_code_kinds = {}
        if discount_code_ids:
            code_rows = (await session.execute(
                select(DiscountCode.id, DiscountCode.kind).where(DiscountCode.id.in_(discount_code_ids))
            )).all()
            discount_code_kinds = {int(code_id): str(kind) for code_id, kind in code_rows}
        waitlist_entries = (await session.execute(
            select(WaitlistEntry, User)
            .outerjoin(User, WaitlistEntry.user_id == User.id)
            .where(WaitlistEntry.event_id == eid, WaitlistEntry.status.in_(["waiting", "invited", "inviting"]))
            .order_by(WaitlistEntry.position, WaitlistEntry.created_at)
        )).all()

    if eid in expired_event_ids:
        try:
            await reconcile_event_channel_status(c.bot, eid)
        except Exception:
            logger.exception("Failed to reconcile capacity after expiring bookings for event_id=%s", eid)

    try:
        payload = build_attendee_workbook(event, bookings, waitlist_entries, discount_code_kinds=discount_code_kinds)
    except Exception:
        logger.exception("Failed to build attendee workbook for event_id=%s", eid)
        return await c.answer("ساخت فایل Excel ناموفق بود. لطفاً دوباره تلاش کنید.", show_alert=True)

    filename = f"participants_{volume_label(event.volume)}_{event.id}.xlsx"
    await c.answer("فایل Excel آماده شد.")
    try:
        await c.bot.send_document(
            c.from_user.id,
            BufferedInputFile(payload, filename=filename),
            caption=f"📊 خروجی شرکت‌کنندگان — {volume_label(event.volume)} {escape(event.title)}",
        )
    except Exception:
        logger.exception("Failed to send attendee workbook for event_id=%s to admin_id=%s", eid, c.from_user.id)
        try:
            await c.bot.send_message(c.from_user.id, "فایل ساخته شد، اما ارسال آن ناموفق بود. لطفاً چند لحظه بعد دوباره تلاش کنید.")
        except Exception:
            logger.exception("Could not notify admin about failed workbook delivery; event_id=%s", eid)


@router.callback_query(F.data.startswith("admin:event:waitlist:invite:"))
async def invite_next_waitlisted_user(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return

    # Claim and commit the candidate before Telegram I/O. A Telegram API delay or
    # failure must never keep a PostgreSQL row lock open.
    try:
        async with SessionLocal() as session:
            event, entry, invitee, free_seats = await next_waitlist_candidate(session, eid)
            entry.status = "inviting"
            entry.invitation_expires_at = utc_now_naive() + WAITLIST_INVITATION_TTL
            entry.next_invite_after = None
            event_id = int(event.id)
            entry_id = int(entry.id)
            invitee_telegram_id = int(invitee.telegram_id)
            requested_count = int(entry.requested_participant_count)
            event_title = str(event.title)
            event_volume = event.volume
            await session.commit()
    except ValueError as exc:
        reason = str(exc)
        messages = {
            "EVENT_NOT_FOUND": "پنل پیدا نشد.",
            "WAITLIST_UNAVAILABLE": "لیست انتظار این پنل فعال نیست.",
            "REGISTRATION_CLOSED": "ثبت‌نام این پنل بسته است. ابتدا از منوی پنل، ثبت‌نام را باز کنید.",
            "NO_CAPACITY": "در حال حاضر ظرفیت خالی وجود ندارد.",
            "NO_ELIGIBLE_WAITLIST": "در لیست انتظار، درخواست واجد شرایطی برای ظرفیت فعلی وجود ندارد.",
            "INVITATIONS_ALREADY_SENT": "برای ظرفیت فعلی دعوت‌های فعالی ارسال شده‌اند؛ پس از ثبت‌نام یا پایان مهلت دعوت‌ها می‌توانید نفر بعدی را دعوت کنید.",
        }
        return await c.answer(messages.get(reason, "ارسال دعوت ممکن نشد."), show_alert=True)
    except Exception:
        logger.exception("Could not claim next waitlisted user for event_id=%s", eid)
        return await c.answer("انتخاب درخواست لیست انتظار ناموفق بود؛ دوباره تلاش کنید.", show_alert=True)

    # A host may have paused the waitlist after the claim was committed. Recheck
    # before sending so an already-queued manual admin invitation cannot bypass it.
    async with SessionLocal() as session:
        current_event = await session.get(Event, event_id)
        current_entry = await session.get(WaitlistEntry, entry_id, with_for_update=True)
        if (not current_event or current_event.archived or current_event.status != EventStatus.PUBLISHED
            or not current_event.waitlist_enabled or not current_entry or current_entry.status != "inviting"):
            if current_entry and current_entry.status == "inviting":
                current_entry.status = "waiting" if current_event and not current_event.waitlist_enabled else "closed"
                current_entry.invitation_expires_at = None
                current_entry.next_invite_after = None
                await session.commit()
            else:
                await session.rollback()
            return await c.answer("فهرست انتظار این پنل غیرفعال شده است؛ دعوت ارسال نشد.", show_alert=True)
        await session.commit()

    try:
        bot_info = await c.bot.get_me()
        if not bot_info.username:
            raise ValueError("BOT_USERNAME_UNAVAILABLE")
        invite_url = f"https://t.me/{bot_info.username}?start=event_{event_id}"
        await c.bot.send_message(
            invitee_telegram_id,
            f"📨 برای پنل <b>{volume_label(event_volume)} — {escape(event_title)}</b> ظرفیت خالی وجود دارد.\n\n"
            f"درخواست لیست انتظار شما برای {requested_count} نفر است و اکنون {free_seats} صندلی خالی وجود دارد. "
            "می‌توانید تا ۲۴ ساعت آینده برای ثبت‌نام اقدام کنید.\n\n"
            "این پیام رزرو یا نگه‌داشتن ظرفیت محسوب نمی‌شود؛ ظرفیت هنگام ثبت‌نام دوباره بررسی می‌شود.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🎟 ادامهٔ ثبت‌نام", url=invite_url)
            ]]),
            disable_web_page_preview=True,
        )
    except ValueError as exc:
        try:
            await record_waitlist_invitation_result(entry_id, False)
        except Exception:
            logger.exception("Could not restore failed manual waitlist invitation; entry_id=%s", entry_id)
        if str(exc) == "BOT_USERNAME_UNAVAILABLE":
            return await c.answer("نام کاربری ربات در دسترس نیست؛ دعوت ارسال نشد و درخواست برای تلاش بعدی در صف می‌ماند.", show_alert=True)
        logger.exception("Manual waitlist invitation failed for event_id=%s entry_id=%s", event_id, entry_id)
        return await c.answer("ارسال دعوت ناموفق بود؛ درخواست برای تلاش بعدی در صف می‌ماند.", show_alert=True)
    except Exception:
        logger.exception("Manual waitlist invitation failed for event_id=%s entry_id=%s", event_id, entry_id)
        try:
            await record_waitlist_invitation_result(entry_id, False)
        except Exception:
            logger.exception("Could not restore failed manual waitlist invitation; entry_id=%s", entry_id)
        return await c.answer("ارسال دعوت ناموفق بود؛ درخواست به صف بازگشت.", show_alert=True)

    try:
        await record_waitlist_invitation_result(entry_id, True)
    except Exception:
        logger.exception("Invitation was delivered but its state could not be updated; entry_id=%s", entry_id)
        return await c.answer("دعوت ارسال شد، اما ثبت وضعیت آن ناموفق بود؛ سیستم در نوبت بعد وضعیت را بازیابی می‌کند.", show_alert=True)

    await c.answer("دعوت ارسال شد.")
    await c.message.answer(
        f"✅ دعوت برای نفر بعدی از لیست انتظار پنل {volume_label(event_volume)} ارسال شد. "
        "این دعوت ظرفیت را رزرو نمی‌کند؛ برای دعوت نفر بعدی دوباره از همین گزینه استفاده کنید."
    )


@router.callback_query(F.data.startswith("admin:event:questions:"))
async def event_questions(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    event = await get_event(eid)
    if not event or not event.questions_pdf_path:
        return await c.answer("فایل سؤالات برای این پنل ثبت نشده است.", show_alert=True)
    path = resolve_upload_path(event.questions_pdf_path)
    if not path:
        return await c.answer("فایل سؤالات این پنل فعلاً در دسترس نیست؛ در صورت نیاز آن را دوباره بارگذاری کنید.", show_alert=True)
    await c.answer()
    await c.bot.send_document(c.from_user.id, FSInputFile(path), caption=f"📄 سؤالات {volume_label(event.volume)} — {escape(event.title)}")


async def _deliver_question_answer_notification(bot, question_id: int) -> bool:
    """Lease-claim an answer notification; stale claims are recoverable after five minutes."""
    now = utc_now_naive()
    async with SessionLocal() as session:
        question = (await session.execute(select(Question).where(Question.id == int(question_id)).with_for_update())).scalar_one_or_none()
        if not question or not question.answer_text:
            return False
        claimed_at = question.answer_notification_claimed_at
        if question.answer_notification_status == "sent":
            return True
        if question.answer_notification_status == "sending" and claimed_at and claimed_at > now - timedelta(minutes=5):
            return False
        recipient = await session.scalar(select(User.telegram_id).where(User.id == question.submitted_by)) if question.submitted_by else None
        answer_text = str(question.answer_text)
        answered_at = question.answered_at
        revision = int(question.answer_revision or 1)
        question.answer_notification_status = "sending"
        question.answer_notification_claimed_at = now
        question.answer_notification_attempts = int(question.answer_notification_attempts or 0) + 1
        question.answer_notification_error = None
        await session.commit()
    if not recipient:
        delivered, error = False, "No linked submitter account"
    else:
        try:
            # Keep the notification short and direct users to the saved answer; this
            # avoids Telegram's UTF-16 message-length edge cases for long/emoji answers.
            await bot.send_message(
                int(recipient),
                "💬 <b>پاسخ سؤال شما آماده است!</b>\n\nمدیران Panel Flow به سؤال پیشنهادی شما پاسخ داده‌اند.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="مشاهدهٔ پاسخ", callback_data="user:submit_question")
                ]]),
            )
            delivered, error = True, None
        except Exception as exc:
            delivered, error = False, f"{type(exc).__name__}: {str(exc)}"[:255]
            logger.info("Question answer notification failed question_id=%s", question_id, exc_info=True)
    async with SessionLocal() as session:
        question = (await session.execute(select(Question).where(Question.id == int(question_id)).with_for_update())).scalar_one_or_none()
        if question and int(question.answer_revision or 1) == revision and question.answered_at == answered_at and question.answer_text == answer_text:
            question.answer_notification_status = "sent" if delivered else "failed"
            question.answer_notification_claimed_at = None
            question.answer_notified_at = utc_now_naive() if delivered else None
            question.answer_notification_error = error
            await session.commit()
    return delivered


async def _render_admin_questions(c: CallbackQuery, page: int = 0):
    page_size = 7
    async with SessionLocal() as session:
        total = int((await session.execute(select(func.count(Question.id)))).scalar_one())
        last_page = max(0, (total - 1) // page_size)
        page = min(max(0, int(page)), last_page)
        rows = (await session.execute(
            select(Question, User, Event)
            .outerjoin(User, Question.submitted_by == User.id)
            .outerjoin(Event, Question.event_id == Event.id)
            .order_by(Question.id.desc())
            .offset(page * page_size).limit(page_size)
        )).all()
    buttons = []
    for question, user, event in rows:
        preview = " ".join(question.question_text.split())[:42]
        answered = "✅ پاسخ داده‌شده" if question.answer_text else "⏳ بی‌پاسخ"
        buttons.append([InlineKeyboardButton(text=f"❓ #{question.id} — {preview} | {answered}", callback_data=f"admin:question:view:{question.id}")])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:questions:page:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:questions:page:{page+1}"))
    if nav:
        buttons.append(nav)
    if total:
        buttons.append([InlineKeyboardButton(text=f"صفحه {page+1} از {last_page+1} · {total} سؤال", callback_data=f"admin:questions:page:{page}")])
    buttons.append([InlineKeyboardButton(text="🧹 پاک‌سازی همه سؤال‌ها", callback_data="admin:questions:clear")])
    buttons.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")])
    body = (f"سؤال‌های پیشنهادی اخیر ({total} مورد): برای پاسخ‌دادن، هر سؤال را باز کنید. برای سؤال‌های قدیمی‌تر از صفحهٔ بعد استفاده کنید." if total else "سؤال پیشنهادی ثبت نشده است.")
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))


@router.callback_query(F.data == "admin:questions")
async def admin_questions(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_admin_questions(c, 0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:questions:page:\d+$"))
async def admin_questions_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_admin_questions(c, int((c.data or "").rsplit(":", 1)[1]))
    await c.answer()


@router.callback_query(F.data == "admin:questions:clear")
async def confirm_clear_questions(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text(
        "<b>پاک‌سازی همه سؤال‌های پیشنهادی</b>\n\nاین کار تمام سؤال‌های پیشنهادی و پاسخ‌های ذخیره‌شدهٔ آن‌ها را حذف می‌کند و قابل بازگشت نیست. ادامه می‌دهید؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🧹 بله، همه حذف شوند", callback_data="admin:questions:clear:confirm")],
            [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:questions")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data == "admin:questions:clear:confirm")
async def clear_questions(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        result = await session.execute(Question.__table__.delete())
        deleted = int(result.rowcount or 0)
        await session.commit()
    await c.message.edit_text(
        f"✅ پاک‌سازی انجام شد؛ {deleted} سؤال حذف شد.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❓ بازگشت به سؤالات پیشنهادی", callback_data="admin:questions")],
            [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data.startswith("admin:question:view:"))
async def admin_question_view(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        question_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("سؤال نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        row = (await session.execute(
            select(Question, User, Event)
            .outerjoin(User, Question.submitted_by == User.id)
            .outerjoin(Event, Question.event_id == Event.id)
            .where(Question.id == question_id)
        )).first()
    if not row:
        return await c.answer("سؤال پیدا نشد.", show_alert=True)
    question, user, event = row
    sender = "—"
    if user:
        display_name = escape(user.display_name or " ".join(x for x in [user.first_name, user.last_name] if x) or str(user.telegram_id))
        username = f"@{escape(user.telegram_username)}" if user.telegram_username else "—"
        sender = f'<a href="tg://user?id={user.telegram_id}">{display_name}</a> | {username} | ID: {user.telegram_id}'
    text = (
        f"<b>سؤال پیشنهادی #{question.id}</b>\n\n"
        f"❓ {escape(question.question_text)}\n\n"
        f"👤 ارسال‌کننده: {sender}\n"
        f"📌 پنل مرتبط: {escape(event.title) if event else 'بدون پنل'}\n"
        f"🕒 {question.created_at:%Y-%m-%d %H:%M}"
    )
    if question.answer_text:
        text += f"\n\n<b>✅ پاسخ ذخیره‌شده:</b>\n{escape(question.answer_text)}"
        notification_labels = {"sent": "ارسال‌شده", "failed": "ناموفق", "pending": "در حال ارسال", "not_attempted": "ارسال‌نشده"}
        text += f"\n\nوضعیت اعلان به کاربر: {notification_labels.get(str(question.answer_notification_status), 'نامشخص')} · تلاش‌ها: {int(question.answer_notification_attempts or 0)}"
    async with SessionLocal() as session:
        already_awarded = (await session.execute(select(XPAward.id).where(
            XPAward.award_key == f"recognized-question:{question.id}"
        ))).scalar_one_or_none() is not None
    recognition_button = InlineKeyboardButton(
        text="✅ Awarded" if already_awarded else "🤝 Recognize contribution (+3 XP)",
        callback_data="admin:community" if already_awarded else f"admin:community:recognize:{question.id}",
    )
    question_rows = [
        [InlineKeyboardButton(text="✍️ ثبت / ویرایش پاسخ", callback_data=f"admin:question:answer:{question.id}")],
    ]
    if question.answer_text and question.answer_notification_status == "failed":
        question_rows.append([InlineKeyboardButton(text="🔔 تلاش دوباره برای اطلاع‌رسانی", callback_data=f"admin:question:notify:{question.id}")])
    question_rows += [
        [recognition_button],
        [InlineKeyboardButton(text="🔙 بازگشت به سؤالات", callback_data="admin:questions")],
    ]
    kb = InlineKeyboardMarkup(inline_keyboard=question_rows)
    await c.message.edit_text(limit_telegram_html(text), reply_markup=kb)
    await c.answer()


@router.callback_query(F.data.startswith("admin:question:answer:"))
async def question_answer_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        question_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("شناسه سؤال نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        question = await session.get(Question, question_id)
    if not question:
        return await c.answer("سؤال پیدا نشد؛ شاید پاک شده باشد.", show_alert=True)
    await state.clear()
    await state.update_data(question_id=question_id)
    await state.set_state(AdminManageStates.question_answer)
    await c.message.edit_text(
        f"پاسخ سؤال #{question_id} را ارسال کنید. پس از ذخیره، برای ارسال‌کننده اعلان خصوصی فرستاده می‌شود؛ در صورت خطای ارسال، پاسخ همچنان ذخیره می‌ماند و امکان تلاش مجدد وجود دارد.\n\n"
        f"سؤال: {escape(question.question_text)}\n\nبرای لغو، دستور /cancel را بفرستید."
    )
    await c.answer()


@router.message(AdminManageStates.question_answer)
async def question_answer_save(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    answer = (m.text or "").strip()
    if not answer:
        return await m.answer("لطفاً متن پاسخ را ارسال کنید.")
    if len(answer) > 4000:
        return await m.answer("پاسخ حداکثر ۴۰۰۰ کاراکتر می‌تواند باشد.")
    data = await state.get_data()
    try:
        question_id = int(data.get("question_id") or 0)
    except (TypeError, ValueError):
        question_id = 0
    async with SessionLocal() as session:
        question = await session.get(Question, question_id, with_for_update=True) if question_id else None
        if not question:
            await state.clear()
            return await m.answer("این سؤال دیگر وجود ندارد؛ احتمالاً پاک شده است.", reply_markup=admin_menu())
        question.answer_text = answer
        question.answer_revision = int(question.answer_revision or 1) + 1
        question.answered_at = utc_now_naive()
        question.answer_notification_status = "pending"
        question.answer_notification_error = None
        await session.commit()
    delivered = await _deliver_question_answer_notification(m.bot, question_id)
    await state.clear()
    if delivered:
        outcome = "✅ پاسخ ذخیره و اعلان خصوصی برای کاربر ارسال شد."
    else:
        outcome = "✅ پاسخ ذخیره شد؛ ارسال اعلان به کاربر ناموفق بود و خطا برای بررسی ثبت شد. پاسخ همچنان در بخش پیشنهاد سؤال در دسترس است."
    await m.answer(outcome, reply_markup=admin_menu())


@router.callback_query(F.data.regexp(r"^admin:question:notify:\d+$"))
async def admin_question_notify_retry(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    question_id = int(c.data.rsplit(":", 1)[1])
    async with SessionLocal() as session:
        question = await session.get(Question, question_id)
        if not question or not question.answer_text:
            return await c.answer("پاسخ ذخیره‌شده‌ای برای این سؤال وجود ندارد.", show_alert=True)
        if question.answer_notification_status not in {"failed", "pending", "sending"}:
            return await c.answer("وضعیت اعلان قابل تلاش مجدد نیست؛ ابتدا وضعیت فعلی را بررسی کنید.", show_alert=True)
        if question.answer_notification_status == "sending" and question.answer_notification_claimed_at and question.answer_notification_claimed_at > utc_now_naive() - timedelta(minutes=5):
            return await c.answer("ارسال اعلان هنوز در حال انجام است.", show_alert=True)
    delivered = await _deliver_question_answer_notification(c.bot, question_id)
    await c.answer("اعلان ارسال شد." if delivered else "ارسال اعلان ناموفق بود؛ خطا ثبت شد.", show_alert=not delivered)


@router.callback_query(F.data.startswith("admin:archives:page:"))
async def archived_panels_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int(c.data.rsplit(":", 1)[1])
        if page < 0:
            raise ValueError
    except ValueError:
        return await c.answer("شماره صفحه نامعتبر است.", show_alert=True)
    page_size = 6
    async with SessionLocal() as session:
        total = int((await session.execute(
            select(func.count(Event.id)).where(Event.archived.is_(True))
        )).scalar_one())
        events = (await session.execute(
            select(Event).where(Event.archived.is_(True))
            .order_by(Event.updated_at.desc(), Event.id.desc())
            .offset(page * page_size).limit(page_size)
        )).scalars().all()
    max_pages = max(1, (total + page_size - 1) // page_size)
    if page >= max_pages and total:
        page = max_pages - 1
        async with SessionLocal() as session:
            events = (await session.execute(
                select(Event).where(Event.archived.is_(True))
                .order_by(Event.updated_at.desc(), Event.id.desc())
                .offset(page * page_size).limit(page_size)
            )).scalars().all()
    buttons = []
    for event in events:
        buttons.append([InlineKeyboardButton(
            text=f"📦 {volume_label(event.volume)} — {event.title[:35]}",
            callback_data=f"admin:archive:view:{event.id}",
        )])
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:archives:page:{page - 1}"))
    if (page + 1) * page_size < total:
        navigation.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:archives:page:{page + 1}"))
    if navigation:
        buttons.append(navigation)
    buttons.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")])
    body = (f"<b>آرشیو پنل‌های برگزارشده</b>\nصفحه {page + 1} از {max_pages} | مجموع: {total} پنل\n\n"
            "پنل‌ها از جدیدترین به قدیمی‌ترین مرتب شده‌اند. هر پنل را باز کنید تا اطلاعات و فایل سؤالات آن را ببینید.")
    if not events:
        body += "\n\nهنوز پنلی آرشیو نشده است."
    await c.message.edit_text(body, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
    await c.answer()


async def _render_archived_panel_detail(c: CallbackQuery, eid: int, *, answer_callback: bool = True):
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived:
            return await c.answer("پنل آرشیوشده پیدا نشد.", show_alert=True)
        booking_count = int((await session.execute(
            select(func.count(Booking.id)).where(Booking.event_id == eid)
        )).scalar_one())
        review_count = int((await session.execute(
            select(func.count(Review.id)).where(Review.event_id == eid)
        )).scalar_one())
    body = (
        f"<b>📚 پنل آرشیوشده – {volume_label(event.volume)} | {escape(event.title)}</b>\n\n"
        + (panel_detail_line("زبان پنل", escape(event.language), icon="🌐") + "\n" if event.language else "")
        + panel_detail_line("روز و تاریخ", f"{escape(event.event_day_label)} – {escape(event.event_date_label)}", icon="📅") + "\n"
        + panel_detail_line("ساعت", escape(event.start_time_label) + (f"–{escape(event.end_time_label)}" if has_end_time_label(event.end_time_label) else ""), icon="⏰") + "\n"
        + panel_detail_line("مکان", escape(event.venue), icon="📍") + "\n"
        + panel_detail_line("میزبان", escape(event.host_name or '—'), icon="👤") + "\n"
        + panel_detail_line("ظرفیت", event.capacity, icon="👥") + "\n"
        + panel_detail_line("هزینه هر نفر", escape(panel_price_label(event.price_per_person, event.price_without_cafe_order)), icon="💰") + "\n"
        f"📝 موضوع/توضیحات: {escape(event.description or '—')}\n"
        f"📄 فایل سؤالات: {escape(event.questions_file_name or Path(event.questions_pdf_path).name) if event.questions_pdf_path else 'ثبت نشده'}\n"
        f"🧾 تعداد رزروهای نگه‌داری‌شده: {booking_count}\n⭐ تعداد نظرها: {review_count}"
    )
    buttons = []
    if event.questions_pdf_path:
        buttons.append([InlineKeyboardButton(text="📄 دریافت فایل سؤالات پنل", callback_data=f"admin:archive:file:{eid}")])
    buttons.append([InlineKeyboardButton(text="📝 ویرایش محتوای عمومی آرشیو", callback_data=f"admin:v77:archive:view:{eid}:0")])
    buttons.append([InlineKeyboardButton(text="⭐ مشاهده نظرات این پنل", callback_data=f"admin:reviews:event:{eid}")])
    buttons.append([InlineKeyboardButton(text="🗑 حذف کامل پنل و سوابق", callback_data=f"admin:archive:delete:{eid}")])
    buttons.append([InlineKeyboardButton(text="🗂 سایر پنل‌های آرشیوشده", callback_data="admin:archives:page:0")])
    buttons.append([InlineKeyboardButton(text="🔙 مدیریت پنل‌ها", callback_data="admin:events")])
    await c.message.edit_text(limit_telegram_html(body), reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
    if answer_callback:
        await c.answer()


@router.callback_query(F.data.startswith("admin:archive:view:"))
async def archived_panel_detail(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        eid = int(c.data.rsplit(":", 1)[1])
        if eid <= 0:
            raise ValueError
    except ValueError:
        return await c.answer("شناسه پنل نامعتبر است.", show_alert=True)
    await _render_archived_panel_detail(c, eid)


@router.callback_query(F.data.regexp(r"^admin:archive:delete:cancel:\d+$"))
async def archived_event_delete_cancel(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event or not event.archived:
            return await c.answer("پنل آرشیوشده پیدا نشد.", show_alert=True)
    await _render_archived_panel_detail(c, eid)


@router.callback_query(F.data.startswith("admin:archive:file:"))
async def archived_panel_questions_file(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        eid = int(c.data.rsplit(":", 1)[1])
        if eid <= 0:
            raise ValueError
    except ValueError:
        return await c.answer("شناسه پنل نامعتبر است.", show_alert=True)
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
    if not event or not event.archived:
        return await c.answer("پنل آرشیوشده پیدا نشد.", show_alert=True)
    path = resolve_upload_path(event.questions_pdf_path or "")
    if not path:
        return await c.answer("فایل سؤالات این پنل فعلاً در دسترس نیست؛ در صورت نیاز آن را دوباره بارگذاری کنید.", show_alert=True)
    await c.answer("فایل آماده ارسال است.")
    try:
        await c.bot.send_document(
            c.from_user.id, FSInputFile(path),
            caption=f"📄 فایل سؤالات پنل آرشیوشده — {volume_label(event.volume)} | {escape(event.title)}",
        )
    except Exception:
        logger.exception("Could not deliver archived questions file; event_id=%s", eid)
        await c.message.answer("ارسال فایل ناموفق بود. لطفاً دوباره تلاش کنید.")


@router.callback_query(F.data == "admin:users:export")
async def export_completed_bot_users(c: CallbackQuery):
    """Send admins a workbook of fully onboarded bot profiles, not booking rows."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)

    try:
        async with SessionLocal() as session:
            users = (await session.execute(completed_user_profiles_statement())).scalars().all()
        payload = build_completed_user_profiles_workbook(users)
    except Exception:
        logger.exception("Failed to build completed-profile export for admin_id=%s", c.from_user.id)
        return await c.answer("ساخت فایل کاربران ناموفق بود. لطفاً دوباره تلاش کنید.", show_alert=True)

    count = len(users)
    filename = "panel_flow_completed_users.xlsx"
    await c.answer(f"فایل آماده شد؛ {count:,} پروفایل کامل.")
    try:
        await c.bot.send_document(
            c.from_user.id,
            BufferedInputFile(payload, filename=filename),
            caption=(
                f"👥 خروجی کاربران تکمیل‌کننده ثبت‌نام اولیه ربات\n"
                f"تعداد پروفایل‌های کامل: {count:,}\n"
                "فقط افرادی شمرده شده‌اند که نام، نام خانوادگی و شماره موبایل ثبت کرده‌اند."
            ),
        )
    except Exception:
        logger.exception("Failed to send completed-profile export to admin_id=%s", c.from_user.id)
        try:
            await c.bot.send_message(
                c.from_user.id,
                "فایل کاربران ساخته شد، اما ارسال آن ناموفق بود. لطفاً دوباره از منوی مدیریت تلاش کنید.",
            )
        except Exception:
            logger.exception("Could not notify admin about completed-profile export failure; admin_id=%s", c.from_user.id)


ADMIN_AUDIT_PAGE_SIZE = 6


@router.callback_query(F.data.regexp(r"^admin:audit:page:\d+$"))
async def admin_audit_log(c: CallbackQuery):
    """Browse concise audit summaries; open a specific entry to inspect details."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = int((c.data or "").rsplit(":", 1)[1])
        if page < 0 or page > 100000:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("شماره صفحه نامعتبر است.", show_alert=True)
    try:
        async with SessionLocal() as session:
            records = (await session.execute(
                select(AdminAction, User.telegram_id)
                .join(User, AdminAction.actor_user_id == User.id)
                .order_by(AdminAction.created_at.desc(), AdminAction.id.desc())
                .offset(page * ADMIN_AUDIT_PAGE_SIZE)
                .limit(ADMIN_AUDIT_PAGE_SIZE + 1)
            )).all()
    except Exception:
        logger.exception("Could not load admin audit log for admin_id=%s", c.from_user.id)
        return await c.answer("بارگذاری تاریخچه مدیریت ناموفق بود.", show_alert=True)

    has_older = len(records) > ADMIN_AUDIT_PAGE_SIZE
    records = records[:ADMIN_AUDIT_PAGE_SIZE]
    rows = []
    if not records:
        text = "<b>📜 تاریخچه اقدامات مدیریت</b>\n\nبرای این صفحه موردی ثبت نشده است."
    else:
        chunks = ["<b>📜 تاریخچه اقدامات مدیریت</b>", "خلاصهٔ اقدامات؛ برای جزئیات هر مورد، دکمهٔ همان ردیف را بزنید.", ""]
        for action, actor_telegram_id in records:
            moment = action.created_at.strftime("%Y-%m-%d %H:%M UTC") if action.created_at else "زمان نامشخص"
            entity_label = str(action.entity_type or "—")[:40]
            entity_id_text = f" #{int(action.entity_id)}" if action.entity_id is not None else ""
            chunks.append(
                f"🕒 <code>{escape(moment)}</code> · <a href=\"tg://user?id={int(actor_telegram_id)}\">{int(actor_telegram_id)}</a>\n"
                f"<b>{escape(str(action.action or '—')[:70])}</b> · {escape(entity_label)}{entity_id_text}"
            )
            rows.append([InlineKeyboardButton(
                text=f"🔎 جزئیات اقدام #{int(action.id)}",
                callback_data=f"admin:audit:detail:{int(action.id)}:{page}",
            )])
        text = "\n\n".join(chunks)

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:audit:page:{page - 1}"))
    if has_older:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:audit:page:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به منوی مدیریت", callback_data="admin:home")])
    await c.message.edit_text(limit_telegram_html(text), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:audit:detail:\d+:\d+$"))
async def admin_audit_detail(c: CallbackQuery):
    """Render one audit payload on demand, keeping the default history screen compact."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        action_id, page = int(parts[3]), int(parts[4])
        if action_id <= 0 or page < 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("شناسهٔ اقدام معتبر نیست.", show_alert=True)
    try:
        async with SessionLocal() as session:
            row = (await session.execute(
                select(AdminAction, User.telegram_id)
                .join(User, AdminAction.actor_user_id == User.id)
                .where(AdminAction.id == action_id)
            )).one_or_none()
    except Exception:
        logger.exception("Could not load audit detail action_id=%s admin_id=%s", action_id, c.from_user.id)
        return await c.answer("بارگذاری جزئیات ناموفق بود.", show_alert=True)
    if row is None:
        return await c.answer("این مورد در تاریخچه پیدا نشد.", show_alert=True)
    action, actor_telegram_id = row
    when = action.created_at.strftime("%Y-%m-%d %H:%M UTC") if action.created_at else "زمان نامشخص"
    details = str(action.details or "").strip()
    if details:
        try:
            parsed = json.loads(details)
            sensitive_key_fragments = (
                "token", "secret", "password", "credential", "receipt", "card_number", "card",
                "phone", "telephone", "email", "authorization", "api_key", "payload", "content",
                "upload_path", "file_path", "raw_body",
            )
            def redact_sensitive(value):
                if isinstance(value, dict):
                    safe = {}
                    for key, item in value.items():
                        key_text = str(key)
                        if any(fragment in key_text.casefold() for fragment in sensitive_key_fragments):
                            safe[key_text] = "[redacted]"
                        else:
                            safe[key_text] = redact_sensitive(item)
                    return safe
                if isinstance(value, list):
                    return [redact_sensitive(item) for item in value[:100]]
                if isinstance(value, str):
                    return value[:500]
                if value is None or isinstance(value, (bool, int, float)):
                    return value
                return str(value)[:300]
            if not isinstance(parsed, (dict, list)):
                parsed = "[non-structured historical detail redacted]"
            details = json.dumps(redact_sensitive(parsed), ensure_ascii=False, indent=2, sort_keys=True)
        except (json.JSONDecodeError, TypeError, ValueError):
            # Historical non-JSON detail strings cannot be reliably redacted by key;
            # do not echo them raw into the admin UI.
            details = "جزئیات تاریخی به‌صورت ساختاریافته ذخیره نشده است و برای جلوگیری از نمایش دادهٔ حساس، مخفی نگه داشته شد."
        details = details[:2300] + ("\n… (جزئیات کوتاه شده است)" if len(details) > 2300 else "")
        details_block = f"<pre>{escape(details)}</pre>"
    else:
        details_block = "جزئیاتی برای این اقدام ثبت نشده است."
    entity = str(action.entity_type or "—")[:80]
    entity_id = f" #{int(action.entity_id)}" if action.entity_id is not None else ""
    text = (
        "<b>📜 جزئیات اقدام مدیریت</b>\n\n"
        f"شناسهٔ اقدام: <code>{int(action.id)}</code>\n"
        f"زمان: <code>{escape(when)}</code>\n"
        f"مدیر: <code>{int(actor_telegram_id)}</code>\n"
        f"اقدام: <code>{escape(str(action.action or '—')[:100])}</code>\n"
        f"مورد: {escape(entity + entity_id)}\n\n{details_block}"
    )
    await c.message.edit_text(limit_telegram_html(text), reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ بازگشت به تاریخچه", callback_data=f"admin:audit:page:{page}")],
        [InlineKeyboardButton(text="🏠 منوی مدیریت", callback_data="admin:home")],
    ]), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data == "admin:stats")
async def admin_stats(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        users = int((await session.execute(select(func.count(User.id)))).scalar_one())
        events = int((await session.execute(select(func.count(Event.id)))).scalar_one())
        archived_events = int((await session.execute(select(func.count(Event.id)).where(Event.archived.is_(True)))).scalar_one())
        bookings = int((await session.execute(select(func.count(Booking.id)).where(Booking.status == RegistrationStatus.CONFIRMED))).scalar_one())
        current_confirmed = int((await session.execute(
            select(func.count(Booking.id)).join(Event, Booking.event_id == Event.id).where(
                Booking.status == RegistrationStatus.CONFIRMED,
                Event.archived.is_(False),
                Event.status.in_((EventStatus.PUBLISHED, EventStatus.COMPLETED)),
            )
        )).scalar_one())
    await c.message.edit_text(
        f"<b>آمار</b>\nکاربران: {users}\nپنل‌ها: {events}\n"
        f"پنل‌های آرشیوشده: {archived_events}\nرزروهای تأییدشده در رکوردها: {bookings}\n"
        f"رزروهای تأییدشده در پنل‌های جاری: {current_confirmed}",
        reply_markup=admin_menu(),
    )
    await c.answer()


def announcement_text(event: Event) -> str:
    lines = [
        "🎉 <b>اطلاعیه Panel Flow</b>",
        "",
        f"<b>{volume_label(event.volume)} — {escape(event.title)}</b>",
    ]
    if event.language:
        lines += [panel_detail_line("زبان پنل", escape(event.language), icon="🌐")]
    if event.description:
        lines += ["", f"📝 {escape(event.description)}"]
    lines += [
        "",
        panel_detail_line("روز", escape(event.event_day_label), icon="📅"),
        panel_detail_line("تاریخ", escape(event.event_date_label), icon="📆"),
        panel_detail_line("زمان", escape(event.start_time_label) + (f"–{escape(event.end_time_label)}" if has_end_time_label(event.end_time_label) else ""), icon="⏰"),
        panel_detail_line("مکان", escape(event.venue), icon="📍"),
        panel_detail_line("آدرس", escape(event.address or '—'), icon="📌"),
        panel_detail_line("لینک موقعیت", escape(event.map_url or '—'), icon="🔗"),
        panel_detail_line("میزبان", escape(event.host_name or '—'), icon="👤"),
        panel_detail_line("هزینه", escape(panel_price_label(event.price_per_person, event.price_without_cafe_order)), icon="💰"),
        panel_detail_line("ظرفیت", event.capacity, icon="👥"),
        "",
        f"وضعیت ثبت‌نام: {'باز' if registration_is_open(event) else 'بسته'}",
        "برای ثبت‌نام روی دکمه زیر بزنید.",
    ]
    return limit_telegram_html("\n".join(lines))


async def announcement_keyboard(bot, event_id: int):
    username = (await bot.me()).username
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎟 ثبت‌نام در این پنل", url=f"https://t.me/{quote(username or '')}?start=event_{event_id}")],
    ])


@router.callback_query(F.data.regexp(r"^admin:event:linkpost:\d+$"))
async def link_channel_post_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    if not await get_event(eid):
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    await state.clear()
    await state.update_data(channel_link_event_id=eid, channel_link_actor_id=int(c.from_user.id))
    await state.set_state(AdminChannelStates.waiting_poster)
    await c.message.edit_text(
        "پست اصلی پنل را از کانال Panel Flow همین‌جا فوروارد کنید. پیش از جابه‌جایی اتصال فعلی، تأیید جداگانه گرفته می‌شود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ لغو اتصال", callback_data="admin:linkchannel:cancel")]]),
    )
    await c.answer()


async def _post_link_error_text(exc: Exception) -> str:
    code = str(exc)
    messages = {
        "TARGET_CHAT_INACCESSIBLE": "ربات به کانال/گروه دسترسی ندارد یا عضویت و دسترسی‌های آن کافی نیست.",
        "TARGET_NOT_CHANNEL": "پیام انتخاب‌شده از یک کانال معتبر نیست.",
        "BOT_NEEDS_CHANNEL_ADMIN": "ربات باید در کانال مدیر باشد.",
        "BOT_CANNOT_POST_TO_CHANNEL": "ربات در کانال اجازهٔ ارسال پست ندارد.",
        "TARGET_NOT_GROUP": "پیام انتخاب‌شده از گروه یا سوپرگروه نیست.",
        "BOT_NOT_IN_GROUP": "ربات در این گروه عضو نیست.",
        "BOT_CANNOT_SEND_TO_GROUP": "ربات اجازهٔ ارسال پیام در این گروه را ندارد.",
        "TARGET_POST_REPLY_FAILED": "ربات نتوانست پیام وضعیت را دقیقاً زیر پست انتخاب‌شده قرار دهد. اتصال قبلی حفظ شد؛ دسترسی‌ها یا خود پست را بررسی کنید.",
        "INVALID_POST_REFERENCE": "شناسهٔ پست نامعتبر است.",
        "EVENT_NOT_FOUND": "پنل دیگر وجود ندارد.",
    }
    return messages.get(code, "اتصال انجام نشد؛ تلگرام پست را نپذیرفت یا دسترسی کافی نیست. اتصال قبلی تغییر نکرد.")


async def _connect_post_and_report(target, *, event_id: int, chat_id: int, poster_message_id: int, destination_type: str, volume: str):
    try:
        result = await connect_event_post(
            target.bot, event_id, chat_id, poster_message_id, destination_type,
            actor_telegram_id=int(target.from_user.id),
        )
    except Exception as exc:
        detail = await _post_link_error_text(exc)
        if isinstance(target, CallbackQuery):
            await target.message.edit_text(f"❌ {detail}", reply_markup=admin_menu())
            await target.answer("اتصال انجام نشد.", show_alert=True)
        else:
            await target.answer(f"❌ {detail}", reply_markup=admin_menu())
        return False
    cleanup = ""
    if not result["old_cleanup_succeeded"]:
        cleanup = "\n⚠️ پیام وضعیت قبلی هنوز در تلگرام باقی مانده است؛ ربات اجازهٔ حذف آن را نداشت. اتصال جدید فعال است."
    text = f"✅ وضعیت پویای Volume {escape(str(volume))} به پست انتخاب‌شده متصل شد.\nمقصد: {escape(result['chat_title'])}{cleanup}"
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=admin_menu())
        await target.answer("اتصال ثبت شد.")
    else:
        await target.answer(text, reply_markup=admin_menu())
    return True


@router.message(AdminChannelStates.waiting_poster)
async def link_channel_post(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    origin = getattr(message, "forward_origin", None)
    if origin is None or getattr(origin, "type", None) != "channel":
        return await message.answer("لطفاً خودِ پست اصلی کانال را با گزینهٔ Forward همین‌جا ارسال کنید.")
    data = await state.get_data()
    try:
        eid = int(data.get("channel_link_event_id") or 0)
    except (TypeError, ValueError):
        eid = 0
    if eid <= 0 or int(data.get("channel_link_actor_id") or 0) != int(message.from_user.id):
        await state.clear()
        return await message.answer("فرآیند اتصال منقضی شده است؛ از مدیریت پنل دوباره شروع کنید.", reply_markup=admin_menu())
    chat_id = int(origin.chat.id)
    poster_message_id = int(origin.message_id)
    configured_channel_id = settings.panel_flow_channel_id
    if configured_channel_id is not None and int(configured_channel_id) != chat_id:
        return await message.answer("این پست از کانال تنظیم‌شدهٔ Panel Flow نیست.")
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        row = (await session.execute(select(ChannelAnnouncement).where(ChannelAnnouncement.event_id == eid))).scalar_one_or_none()
        if not event:
            await state.clear()
            return await message.answer("پنل پیدا نشد.", reply_markup=admin_menu())
        if row and int(row.channel_id) == chat_id and int(row.poster_message_id or 0) == poster_message_id and row.status_message_id:
            await state.clear()
            return await message.answer("این پست از قبل به همین پنل متصل است.", reply_markup=admin_menu())
        replacing = bool(row and (row.status_message_id or row.poster_message_id) and (int(row.channel_id) != chat_id or int(row.poster_message_id or 0) != poster_message_id))
        volume = event.volume
    if replacing:
        await state.update_data(channel_link_target_chat_id=chat_id, channel_link_target_message_id=poster_message_id, channel_link_target_type="channel", channel_link_volume=volume)
        await state.set_state(AdminChannelStates.confirming_replacement)
        return await message.answer(
            f"⚠️ این پنل هم‌اکنون به پست دیگری متصل است. آیا اتصال Volume {escape(str(volume))} به این پست کانال جایگزین شود؟\n\nاتصال فعلی تا زمان موفقیت اتصال جدید حفظ می‌شود.",
            reply_markup=channel_link_replacement_keyboard(),
        )
    succeeded = await _connect_post_and_report(message, event_id=eid, chat_id=chat_id, poster_message_id=poster_message_id, destination_type="channel", volume=volume)
    if succeeded:
        await state.clear()


@router.callback_query(F.data == "admin:linkchannel:confirm")
async def confirm_channel_replacement(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != AdminChannelStates.confirming_replacement.state:
        return await c.answer("تأیید اتصال منقضی شده است؛ دوباره شروع کنید.", show_alert=True)
    data = await state.get_data()
    eid = int(data.get("channel_link_event_id") or 0)
    chat_id = int(data.get("channel_link_target_chat_id") or 0)
    poster_id = int(data.get("channel_link_target_message_id") or 0)
    volume = str(data.get("channel_link_volume") or eid)
    ok = await _connect_post_and_report(c, event_id=eid, chat_id=chat_id, poster_message_id=poster_id, destination_type="channel", volume=volume)
    if ok:
        await state.clear()


@router.callback_query(F.data == "admin:linkchannel:cancel")
async def cancel_channel_link(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() in (AdminChannelStates.waiting_poster.state, AdminChannelStates.confirming_replacement.state):
        await state.clear()
    await c.message.edit_text("اتصال پست لغو شد؛ اتصال قبلی دست‌نخورده باقی ماند.", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:event:linkgroup:\d+$"))
async def link_group_post_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد.", show_alert=True)
        token = secrets.token_hex(6)
        session.add(PanelPostLinkSession(
            token=token, event_id=eid, admin_telegram_id=int(c.from_user.id), destination_type="group",
            expires_at=utc_now_naive() + timedelta(minutes=10),
        ))
        volume = str(event.volume)
        title = str(event.title)
        await session.commit()
    await state.clear()
    try:
        me = await c.bot.get_me()
        mention = f"@{me.username}" if me.username else ""
    except Exception:
        mention = ""
    await c.message.edit_text(
        f"👥 <b>اتصال پست گروه به Volume {escape(volume)}</b>\n\n"
        f"در گروه Panel Flow روی همان پست پوستر، یک پیام ریپلای کنید و بنویسید:\n"
        f"<code>/linkpanel{mention} {token}</code>\n\n"
        "ربات باید عضو گروه و مجاز به ارسال پیام باشد. این درخواست تا ۱۰ دقیقه معتبر است؛ اتصال قبلی تا تأیید موفق پست جدید حفظ می‌شود.",
        reply_markup=group_link_session_keyboard(token),
    )
    await c.answer()


@router.message(Command("linkpanel"))
async def link_group_post_command(message: Message):
    if not await is_admin(message.from_user.id):
        return await message.answer("دسترسی مجاز نیست.")
    chat_type = str(getattr(getattr(message.chat, "type", None), "value", getattr(message.chat, "type", ""))).lower()
    if chat_type not in {"group", "supergroup"}:
        return await message.answer("این دستور را در گروه و در پاسخ مستقیم به پست پوستر اجرا کنید.")
    if not message.reply_to_message:
        return await message.answer("برای اتصال دقیق، دستور باید با Reply به همان پست پوستر ارسال شود.")
    parts = (message.text or "").split()
    if len(parts) != 2:
        return await message.answer("فرمت درست: <code>/linkpanel TOKEN</code> در پاسخ به پست پوستر.")
    token = parts[1].strip()
    async with SessionLocal() as session:
        link_session = (await session.execute(
            select(PanelPostLinkSession).where(PanelPostLinkSession.token == token).with_for_update()
        )).scalar_one_or_none()
        if (not link_session or link_session.admin_telegram_id != int(message.from_user.id)
                or link_session.consumed_at is not None or link_session.expires_at <= utc_now_naive()):
            return await message.answer("این نشست اتصال نامعتبر یا منقضی شده است؛ از مدیریت پنل نشست تازه بسازید.")
        event = await session.get(Event, int(link_session.event_id))
        if not event:
            return await message.answer("پنل این نشست دیگر وجود ندارد؛ اتصال انجام نشد.")
        old = (await session.execute(select(ChannelAnnouncement).where(ChannelAnnouncement.event_id == event.id))).scalar_one_or_none()
        target_chat = int(message.chat.id)
        target_message = int(message.reply_to_message.message_id)
        replacing = bool(old and (old.status_message_id or old.poster_message_id) and (
            int(old.channel_id) != target_chat or int(old.poster_message_id or 0) != target_message
        ))
        if replacing:
            link_session.pending_chat_id = target_chat
            link_session.pending_message_id = target_message
            volume, event_id = str(event.volume), int(event.id)
            await session.commit()
        else:
            link_session.consumed_at = utc_now_naive()
            volume, event_id = str(event.volume), int(event.id)
            await session.commit()
    if replacing:
        try:
            await message.bot.send_message(
                int(message.from_user.id),
                f"⚠️ Volume {escape(volume)} از قبل به پست دیگری متصل است. این جابه‌جایی را تأیید می‌کنید؟\n\n"
                f"گروه هدف: <code>{target_chat}</code>، شناسهٔ پست: <code>{target_message}</code>\n"
                "اتصال قبلی تا موفقیت اتصال جدید باقی می‌ماند.",
                reply_markup=group_link_replacement_keyboard(token),
            )
            await message.reply("برای تأیید جابه‌جایی، پیام خصوصی ربات را بررسی کنید؛ هنوز اتصالی تغییر نکرده است.")
        except Exception:
            await message.reply("ربات نتوانست پیام تأیید خصوصی را ارسال کند. نشست هنوز معتبر است؛ ابتدا گفت‌وگوی خصوصی ربات را باز کنید.")
        return
    try:
        result = await connect_event_post(
            message.bot, event_id, target_chat, target_message, "group",
            actor_telegram_id=int(message.from_user.id),
        )
    except Exception as exc:
        async with SessionLocal() as session:
            row = await session.get(PanelPostLinkSession, token, with_for_update=True)
            if row and row.admin_telegram_id == int(message.from_user.id):
                row.consumed_at = None
                await session.commit()
        return await message.reply("❌ " + await _post_link_error_text(exc) + " نشست اتصال حفظ شده است؛ پس از رفع مشکل دوباره دستور را اجرا کنید.")
    cleanup = "" if result["old_cleanup_succeeded"] else " پیام وضعیت قدیمی باقی مانده و نیاز به پاک‌سازی دستی دارد."
    await message.reply(f"✅ پست گروه به Volume {escape(volume)} متصل شد.{cleanup}")
    try:
        await message.bot.send_message(int(message.from_user.id), f"✅ اتصال پست گروه برای Volume {escape(volume)} ثبت شد.{cleanup}")
    except Exception:
        logger.info("Could not DM group-post link result to admin_id=%s", message.from_user.id)


@router.callback_query(F.data.regexp(r"^admin:linkgroup:confirm:[a-f0-9]{12}$"))
async def confirm_group_post_replacement(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    token = str(c.data).rsplit(":", 1)[1]
    async with SessionLocal() as session:
        link_session = (await session.execute(select(PanelPostLinkSession).where(
            PanelPostLinkSession.token == token
        ).with_for_update())).scalar_one_or_none()
        if (not link_session or link_session.admin_telegram_id != int(c.from_user.id)
                or link_session.consumed_at is not None or link_session.expires_at <= utc_now_naive()
                or link_session.pending_chat_id is None or link_session.pending_message_id is None):
            return await c.answer("نشست جابه‌جایی منقضی یا نامعتبر است؛ از ابتدا شروع کنید.", show_alert=True)
        event = await session.get(Event, int(link_session.event_id))
        if not event:
            return await c.answer("پنل دیگر وجود ندارد.", show_alert=True)
        eid, volume = int(event.id), str(event.volume)
        chat_id, poster_id = int(link_session.pending_chat_id), int(link_session.pending_message_id)
        link_session.consumed_at = utc_now_naive()
        await session.commit()
    try:
        result = await connect_event_post(
            c.bot, eid, chat_id, poster_id, "group", actor_telegram_id=int(c.from_user.id),
        )
    except Exception as exc:
        async with SessionLocal() as session:
            row = await session.get(PanelPostLinkSession, token, with_for_update=True)
            if row and row.admin_telegram_id == int(c.from_user.id):
                row.consumed_at = None
                await session.commit()
        return await c.answer(await _post_link_error_text(exc), show_alert=True)
    cleanup = "" if result["old_cleanup_succeeded"] else "\n⚠️ پیام وضعیت قدیمی قابل حذف نبود و باید دستی پاک شود."
    await c.message.edit_text(f"✅ پست گروه برای Volume {escape(volume)} جایگزین شد.{cleanup}", reply_markup=admin_menu())
    await c.answer("اتصال جدید ثبت شد.")


@router.callback_query(F.data.regexp(r"^admin:linkgroup:cancel:[a-f0-9]{12}$"))
async def cancel_group_link_session(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    token = str(c.data).rsplit(":", 1)[1]
    async with SessionLocal() as session:
        row = await session.get(PanelPostLinkSession, token, with_for_update=True)
        if row and row.admin_telegram_id == int(c.from_user.id) and row.consumed_at is None:
            row.consumed_at = utc_now_naive()
            await session.commit()
    await c.message.edit_text("نشست اتصال گروه لغو شد؛ اتصال قبلی تغییری نکرد.", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data == "admin:channel_updates")
async def channel_updates_menu(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        enabled, threshold = await get_channel_updates_config(session)
        await c.message.edit_text(
            f"<b>به‌روزرسانی‌های کانال</b>\n\nوضعیت: {'روشن' if enabled else 'خاموش'}\nآستانهٔ شروع پیام وضعیت: {threshold} صندلی خالی\nعدد واقعی از ظرفیت منهای رزروهای فعال محاسبه می‌شود (تأییدشده، در انتظار پرداخت و رسید در انتظار بررسی).",
            reply_markup=channel_updates_keyboard(enabled, threshold),
        )
    await c.answer()


@router.callback_query(F.data == "admin:channel_updates:toggle")
async def channel_updates_toggle(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        enabled, threshold = await get_channel_updates_config(session)
        await set_setting(session, CHANNEL_UPDATES_ENABLED, "false" if enabled else "true")
        await session.commit()
        enabled = not enabled
    if enabled:
        await reconcile_all_channel_statuses(c.bot)
    await c.message.edit_text(
        f"<b>به‌روزرسانی‌های کانال</b>\n\nوضعیت: {'روشن' if enabled else 'خاموش'}\nآستانهٔ شروع پیام وضعیت: {threshold} صندلی خالی\nعدد واقعی از ظرفیت منهای رزروهای فعال محاسبه می‌شود.",
        reply_markup=channel_updates_keyboard(enabled, threshold),
    )
    await c.answer()


@router.callback_query(F.data == "admin:channel_updates:threshold")
async def channel_updates_threshold_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.set_state(AdminManageStates.channel_threshold)
    await c.message.edit_text("تعداد صندلی خالی‌ای را وارد کنید که در آن پیام وضعیت برای اولین بار منتشر شود:")
    await c.answer()


@router.message(AdminManageStates.channel_threshold)
async def channel_updates_threshold_save(m: Message, state: FSMContext):
    # Persistent FSM state is not an authorization grant; check the live role.
    if not m.from_user or not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    raw = (m.text or "").strip()
    threshold = parse_integer(raw, minimum=1, maximum=100000)
    if threshold is None:
        return await m.answer("آستانه باید عدد صحیحی بین ۱ تا ۱۰۰٬۰۰۰ باشد.")
    async with SessionLocal() as session:
        await set_setting(session, CHANNEL_UPDATE_THRESHOLD, str(threshold))
        enabled, _ = await get_channel_updates_config(session)
        await session.commit()
    await state.clear()
    await m.answer(f"✅ آستانه روی {threshold} صندلی تنظیم شد.", reply_markup=admin_menu())
    if enabled:
        await reconcile_all_channel_statuses(m.bot)


async def _admin_reviews_panel(c: CallbackQuery, event_id: int | None = None, page: int = 0):
    page = max(0, int(page))
    if event_id is None:
        async with SessionLocal() as session:
            total = int((await session.execute(
                select(func.count(func.distinct(Review.event_id)))
                .join(Event, Event.id == Review.event_id)
            )).scalar_one())
            last_page = max(0, (total - 1) // REVIEW_LIST_PAGE_SIZE)
            page = min(page, last_page)
            rows = (await session.execute(
                select(Event.id, Event.volume, Event.title, func.count(Review.id).label("count"), func.max(Review.created_at).label("latest"))
                .join(Review, Review.event_id == Event.id)
                .group_by(Event.id, Event.volume, Event.title)
                .order_by(func.max(Review.created_at).desc(), Event.id.desc())
                .offset(page * REVIEW_LIST_PAGE_SIZE).limit(REVIEW_LIST_PAGE_SIZE)
            )).all()
        buttons = [[InlineKeyboardButton(text=f"{volume_label(volume)} — {title[:30]} ({count})", callback_data=f"admin:reviews:event:{eid}")] for eid, volume, title, count, _ in rows]
        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:reviews:page:{page-1}"))
        if page < last_page:
            nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:reviews:page:{page+1}"))
        if nav:
            buttons.append(nav)
        if total:
            buttons.append([InlineKeyboardButton(text=f"صفحه {page+1} از {last_page+1} · {total} پنل", callback_data=f"admin:reviews:page:{page}")])
        buttons.append([InlineKeyboardButton(text="🕘 آخرین نظرات", callback_data="admin:reviews:all")])
        buttons.append([InlineKeyboardButton(text="🧹 پاک‌سازی همه نظرات", callback_data="admin:reviews:clear")])
        buttons.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")])
        return await c.message.edit_text("پنل موردنظر برای مشاهده نظرات را انتخاب کنید؛ پنل‌های قدیمی‌تر در صفحه‌های بعد هستند:", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))

    async with SessionLocal() as session:
        event = await session.get(Event, int(event_id))
        total = int((await session.execute(select(func.count(Review.id)).where(Review.event_id == int(event_id)))).scalar_one())
        last_page = max(0, (total - 1) // REVIEW_LIST_PAGE_SIZE)
        page = min(page, last_page)
        rows = (await session.execute(
            select(Review, Event, User)
            .join(Event, Event.id == Review.event_id)
            .join(User, User.id == Review.user_id)
            .where(Review.event_id == int(event_id))
            .order_by(Review.created_at.desc(), Review.id.desc())
            .offset(page * REVIEW_LIST_PAGE_SIZE).limit(REVIEW_LIST_PAGE_SIZE)
        )).all()
    if not event or not rows:
        return await c.message.edit_text("برای این پنل نظری در این صفحه وجود ندارد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 بازگشت به فهرست پنل‌ها", callback_data="admin:reviews")]
        ]))
    buttons = []
    for review, _event, user in rows:
        reviewer = user.display_name or user.telegram_username or str(user.telegram_id)
        rating = f"⭐{review.rating}" if review.rating else "—"
        buttons.append([InlineKeyboardButton(
            text=f"{rating} | {reviewer[:24]} | {review.created_at:%m/%d %H:%M}",
            callback_data=f"admin:review:view:{review.id}",
        )])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:reviews:eventpage:{event_id}:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:reviews:eventpage:{event_id}:{page+1}"))
    if nav:
        buttons.append(nav)
    buttons.append([InlineKeyboardButton(text=f"صفحه {page+1} از {last_page+1} · {total} نظر", callback_data=f"admin:reviews:eventpage:{event_id}:{page}")])
    buttons.append([InlineKeyboardButton(text="🔙 بازگشت به فهرست پنل‌ها", callback_data="admin:reviews")])
    await c.message.edit_text("نظرات این پنل را برای مشاهده جزئیات انتخاب کنید:", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))


async def _admin_review_detail(c: CallbackQuery, review_id: int):
    async with SessionLocal() as session:
        row = (await session.execute(
            select(Review, Event, User)
            .join(Event, Event.id == Review.event_id)
            .join(User, User.id == Review.user_id)
            .where(Review.id == review_id)
        )).one_or_none()
    if not row:
        return await c.answer("نظر پیدا نشد.", show_alert=True)
    review, event, user = row
    reviewer = user.display_name or user.telegram_username or str(user.telegram_id)
    rating = f"⭐ {review.rating}/5" if review.rating else "بدون امتیاز"
    text = (
        f"<b>{volume_label(event.volume)} – {escape(event.title)}</b>\n"
        f"👤 {escape(reviewer)}\n"
        f"🕘 {review.created_at:%Y-%m-%d %H:%M}\n"
        f"{rating}\n\n"
        f"{escape(review.text or '—')}"
    )
    await c.message.edit_text(
        limit_telegram_html(text),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 بازگشت به فهرست نظرات", callback_data=f"admin:reviews:event:{event.id}")]
        ]),
    )


@router.callback_query(F.data == "admin:reviews")
async def admin_reviews(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _admin_reviews_panel(c)
    await c.answer()


@router.callback_query(F.data == "admin:reviews:clear")
async def confirm_clear_reviews(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.message.edit_text(
        "<b>پاک‌سازی همه نظرات کاربران</b>\n\nتمام نظرها و امتیازهای ذخیره‌شده حذف می‌شوند. این کار قابل بازگشت نیست. ادامه می‌دهید؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🧹 بله، همه نظرات حذف شوند", callback_data="admin:reviews:clear:confirm")],
            [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:reviews")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data == "admin:reviews:clear:confirm")
async def clear_reviews(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        result = await session.execute(Review.__table__.delete())
        deleted = int(result.rowcount or 0)
        await session.commit()
    await c.message.edit_text(
        f"✅ پاک‌سازی انجام شد؛ {deleted} نظر حذف شد.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📝 بازگشت به نظرات کاربران", callback_data="admin:reviews")],
            [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
        ]),
    )
    await c.answer()


async def _render_all_admin_reviews(c: CallbackQuery, page: int = 0):
    async with SessionLocal() as session:
        total = int((await session.execute(select(func.count(Review.id)))).scalar_one())
        last_page = max(0, (total - 1) // REVIEW_LIST_PAGE_SIZE)
        page = min(max(0, int(page)), last_page)
        rows = (await session.execute(
            select(Review, Event, User)
            .join(Event, Event.id == Review.event_id)
            .join(User, User.id == Review.user_id)
            .order_by(Review.created_at.desc(), Review.id.desc())
            .offset(page * REVIEW_LIST_PAGE_SIZE).limit(REVIEW_LIST_PAGE_SIZE)
        )).all()
    buttons = []
    for review, event, user in rows:
        reviewer = user.display_name or user.telegram_username or str(user.telegram_id)
        rating = f"⭐{review.rating}" if review.rating else "—"
        buttons.append([InlineKeyboardButton(
            text=f"{volume_label(event.volume)} | {rating} | {reviewer[:20]}",
            callback_data=f"admin:review:view:{review.id}",
        )])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:reviews:all:page:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:reviews:all:page:{page+1}"))
    if nav:
        buttons.append(nav)
    if total:
        buttons.append([InlineKeyboardButton(text=f"صفحه {page+1} از {last_page+1} · {total} نظر", callback_data=f"admin:reviews:all:page:{page}")])
    buttons.append([InlineKeyboardButton(text="🧹 پاک‌سازی همه نظرات", callback_data="admin:reviews:clear")])
    buttons.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:reviews")])
    await c.message.edit_text("آخرین نظرات را برای مشاهده متن کامل انتخاب کنید:" if rows else "هنوز نظری ثبت نشده است.", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))


@router.callback_query(F.data == "admin:reviews:all")
async def admin_reviews_all(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_all_admin_reviews(c, 0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:reviews:all:page:\d+$"))
async def admin_reviews_all_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_all_admin_reviews(c, int((c.data or "").rsplit(":", 1)[1]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:reviews:page:\d+$"))
async def admin_reviews_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _admin_reviews_panel(c, page=int((c.data or "").rsplit(":", 1)[1]))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:reviews:eventpage:\d+:\d+$"))
async def admin_reviews_event_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _prefix, _admin, _reviews, _eventpage, event_id, page = (c.data or "").split(":")
        event_id, page = int(event_id), int(page)
        if event_id <= 0 or page < 0:
            raise ValueError
    except ValueError:
        return await c.answer("صفحه نامعتبر است.", show_alert=True)
    await _admin_reviews_panel(c, event_id, page)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:reviews:event:\d+$"))
async def admin_reviews_event(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        event_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("پنل نامعتبر است.", show_alert=True)
    await _admin_reviews_panel(c, event_id)
    await c.answer()


@router.callback_query(F.data.startswith("admin:review:view:"))
async def admin_review_detail(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        review_id = int(c.data.rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("نظر نامعتبر است.", show_alert=True)
    await _admin_review_detail(c, review_id)
    await c.answer()


async def _render_announcement_picker(c: CallbackQuery, page: int = 0):
    async with SessionLocal() as session:
        total = int((await session.execute(select(func.count(Event.id)).where(
            Event.status == EventStatus.PUBLISHED, Event.archived.is_(False)
        ))).scalar_one())
        last_page = max(0, (total - 1) // ANNOUNCEMENT_PAGE_SIZE)
        page = min(max(0, int(page)), last_page)
        events = (await session.execute(announcement_events_statement().offset(page * ANNOUNCEMENT_PAGE_SIZE).limit(ANNOUNCEMENT_PAGE_SIZE))).scalars().all()
    if not events:
        return await c.message.edit_text("پنل منتشرشده‌ای برای اطلاع‌رسانی وجود ندارد.", reply_markup=admin_menu())
    rows = [[InlineKeyboardButton(text=f"{volume_label(e.volume)} — {e.title[:30]}", callback_data=f"admin:event:announce:{e.id}")] for e in events]
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ پنل‌های جدیدتر", callback_data=f"admin:announcements:page:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="پنل‌های قدیمی‌تر ➡️", callback_data=f"admin:announcements:page:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text=f"صفحه {page + 1} از {last_page + 1} · {total} پنل", callback_data=f"admin:announcements:page:{page}")])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")])
    await c.message.edit_text("پنلی را برای اطلاع‌رسانی انتخاب کنید:", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data == "admin:announcements")
async def announcements_menu(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_announcement_picker(c, 0)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:announcements:page:\d+$"))
async def announcements_menu_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_announcement_picker(c, int((c.data or "").rsplit(":", 1)[1]))
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:announce:"))
async def announcement_preview(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    event = await get_event(eid)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if event.status != EventStatus.PUBLISHED or event.archived:
        return await c.answer("فقط پنل منتشرشده و غیرآرشیوی قابل اعلام است.", show_alert=True)
    await state.clear()
    await state.update_data(announcement_event_id=eid)
    preview = announcement_text(event)
    kb = await announcement_keyboard(c.bot, eid)
    confirm = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ ارسال برای همه کاربران", callback_data=f"admin:event:announce_send:{eid}")],
        [InlineKeyboardButton(text="❌ لغو", callback_data="admin:announce_cancel")],
    ])
    await c.message.edit_text(f"<b>پیش‌نمایش اطلاع‌رسانی:</b>\n\n{preview}\n\nارسال برای همه کاربران؟", reply_markup=confirm)
    await c.message.answer("پیش‌نمایش دکمه ثبت‌نام:", reply_markup=kb)
    await state.set_state(AdminManageStates.announcement_confirm)
    await c.answer()


@router.callback_query(F.data == "admin:announce_cancel")
async def announcement_cancel(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text("اطلاع‌رسانی لغو شد.", reply_markup=admin_menu())
    await c.answer()


async def _announcement_status_counts(session, batch_id: int) -> dict[str, int]:
    rows = (await session.execute(
        select(AnnouncementDelivery.status, func.count(AnnouncementDelivery.id))
        .where(AnnouncementDelivery.broadcast_id == int(batch_id))
        .group_by(AnnouncementDelivery.status)
    )).all()
    result = {"pending": 0, "sending": 0, "sent": 0, "failed": 0, "unknown": 0}
    for status, count in rows:
        result[str(status)] = int(count)
    return result


async def _process_announcement_batch(
    bot, batch_id: int, *, recovering: bool = False, actor_telegram_id: int | None = None,
) -> None:
    async with SessionLocal() as session:
        batch = await session.get(AnnouncementBroadcast, int(batch_id), with_for_update=True)
        if not batch or batch.status == "completed":
            return
        if recovering:
            # A crash after the send request may mean Telegram accepted it. Never blindly resend.
            await session.execute(
                AnnouncementDelivery.__table__.update()
                .where(AnnouncementDelivery.broadcast_id == batch_id, AnnouncementDelivery.status == "sending")
                .values(status="unknown", last_error="فرآیند قبلی هنگام ارسال متوقف شد؛ برای جلوگیری از پیام تکراری دوباره ارسال نشد.", updated_at=utc_now_naive())
            )
        batch.status = "processing"
        batch.updated_at = utc_now_naive()
        await session.commit()

    async with SessionLocal() as session:
        delivery_ids = (await session.execute(
            select(AnnouncementDelivery.id).where(
                AnnouncementDelivery.broadcast_id == batch_id,
                AnnouncementDelivery.status == "pending",
            ).order_by(AnnouncementDelivery.id)
        )).scalars().all()
        batch = await session.get(AnnouncementBroadcast, int(batch_id))
        event_id_for_keyboard = int(batch.event_id) if batch else 0
    panel_markup = await announcement_keyboard(bot, event_id_for_keyboard) if event_id_for_keyboard else None

    for delivery_id in delivery_ids:
        async with SessionLocal() as session:
            delivery = (await session.execute(
                select(AnnouncementDelivery).where(AnnouncementDelivery.id == delivery_id).with_for_update()
            )).scalar_one_or_none()
            batch = await session.get(AnnouncementBroadcast, int(batch_id))
            if not delivery or not batch or delivery.status != "pending":
                continue
            delivery.status = "sending"
            delivery.attempts = int(delivery.attempts or 0) + 1
            delivery.updated_at = utc_now_naive()
            telegram_id = int(delivery.telegram_id)
            announcement_text_value = str(batch.message_text)
            event_id = int(batch.event_id)
            await session.commit()

        try:
            result = await send_announcement_to_user(
                bot, telegram_id, announcement_text_value,
                panel_markup, max_attempts=4, delay_seconds=0.05,
            )
        except Exception as exc:
            logger.exception("Broadcast send adapter failed for telegram_id=%s", telegram_id)
            result_status = "unknown"
            result_error = f"delivery_uncertain: {type(exc).__name__}"[:255]
            result_attempts = 1
        else:
            result_status = result.status
            result_error = (result.error or "")[:255] or None
            result_attempts = int(result.attempts)

        async with SessionLocal() as session:
            delivery = (await session.execute(
                select(AnnouncementDelivery).where(AnnouncementDelivery.id == delivery_id).with_for_update()
            )).scalar_one_or_none()
            if delivery and delivery.status == "sending":
                delivery.status = result_status
                delivery.last_error = result_error
                # Count both this execution's claim and any retries performed within it.
                delivery.attempts = max(1, int(delivery.attempts or 0)) + max(0, result_attempts - 1)
                delivery.updated_at = utc_now_naive()
                await session.commit()
        await asyncio.sleep(0.05)

    async with SessionLocal() as session:
        batch = (await session.execute(
            select(AnnouncementBroadcast).where(AnnouncementBroadcast.id == int(batch_id)).with_for_update()
        )).scalar_one_or_none()
        if not batch:
            return
        counts = await _announcement_status_counts(session, batch_id)
        if counts["pending"] == 0 and counts["sending"] == 0:
            batch.status = "completed"
            batch.completed_at = utc_now_naive()
        else:
            batch.status = "partial"
        batch.updated_at = utc_now_naive()
        if actor_telegram_id is not None:
            await write_admin_action(
                session, actor_telegram_id=actor_telegram_id,
                action="announcement_broadcast_completed" if batch.status == "completed" else "announcement_broadcast_partial",
                entity_type="announcement_broadcast", entity_id=int(batch.id),
                details={"status": batch.status, **counts},
            )
        await session.commit()


async def _render_announcement_batch_report(target, batch_id: int, page: int = 0):
    page_size = 10
    async with SessionLocal() as session:
        batch = await session.get(AnnouncementBroadcast, int(batch_id))
        if not batch:
            return await target.answer("گزارش این اطلاع‌رسانی پیدا نشد.")
        counts = await _announcement_status_counts(session, batch_id)
        total_pages = max(1, (int(batch.total_recipient_count or 0) + page_size - 1) // page_size)
        page = min(max(0, int(page)), total_pages - 1)
        deliveries = (await session.execute(
            select(AnnouncementDelivery).where(AnnouncementDelivery.broadcast_id == batch_id)
            .order_by(AnnouncementDelivery.id).offset(page * page_size).limit(page_size)
        )).scalars().all()
        is_complete = batch.status == "completed"
    labels = {"sent": "✅ ارسال‌شده", "failed": "❌ ناموفق", "unknown": "⚠️ وضعیت تحویل نامشخص؛ دوباره ارسال نشد", "pending": "⏳ در انتظار", "sending": "🔄 در حال ارسال"}
    lines = [
        "📣 <b>گزارش اطلاع‌رسانی</b>",
        f"Status: {'Completed' if is_complete else 'Incomplete / resumable'}",
        f"ارسال موفق: <b>{counts['sent']}</b> | ناموفق: <b>{counts['failed']}</b>",
        f"نتیجه نامشخص: <b>{counts['unknown']}</b> | در انتظار/در حال ارسال: <b>{counts['pending'] + counts['sending']}</b>",
        f"مجموع دریافت‌کنندگان: <b>{sum(counts.values())}</b>",
        "", f"جزئیات · صفحه {page + 1} از {total_pages}"
    ]
    for row in deliveries:
        label = labels.get(row.status, escape(admin_status_display_label(row.status)))
        error = f" — {escape((row.last_error or '')[:80])}" if row.last_error else ""
        lines.append(f"<code>{int(row.telegram_id)}</code> · {label}{error}")
    rows = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:announce:report:{batch_id}:{page-1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:announce:report:{batch_id}:{page+1}"))
    if nav:
        rows.append(nav)
    if counts["pending"] or counts["sending"] or not is_complete:
        rows.append([InlineKeyboardButton(text="🔁 ادامهٔ ارسال‌های باقی‌مانده", callback_data=f"admin:announce:resume:{batch_id}")])
    rows.append([InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    output = limit_telegram_html("\n".join(lines))
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(output, reply_markup=markup)
    else:
        await target.answer(output, reply_markup=markup)


@router.callback_query(F.data.startswith("admin:event:announce_send:"))
async def announcement_send(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    data = await state.get_data()
    if data.get("announcement_event_id") != eid:
        return await c.answer("این پیش‌نمایش منقضی شده است.", show_alert=True)
    event = await get_event(eid)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    announcement_body = announcement_text(event)
    identity = hashlib.sha256(f"event:{eid}\0{announcement_body}".encode("utf-8")).hexdigest()
    created = False
    async with SessionLocal() as session:
        current_event = await session.get(Event, eid)
        if not current_event or current_event.status != EventStatus.PUBLISHED or current_event.archived:
            await state.clear()
            return await c.answer("این پنل دیگر قابل اعلام نیست.", show_alert=True)
        batch = (await session.execute(
            select(AnnouncementBroadcast).where(AnnouncementBroadcast.idempotency_key == identity).with_for_update()
        )).scalar_one_or_none()
        if batch is None:
            batch = AnnouncementBroadcast(
                idempotency_key=identity, event_id=eid, created_by_telegram_id=int(c.from_user.id),
                message_text=announcement_body, status="processing", total_recipient_count=0,
            )
            session.add(batch)
            await session.flush()
            users = await all_bot_users(session)
            unique_recipients = sorted({int(u.telegram_id) for u in users if not bool(getattr(u, "is_bot", False)) and int(u.telegram_id) > 0})
            for telegram_id in unique_recipients:
                session.add(AnnouncementDelivery(broadcast_id=batch.id, telegram_id=telegram_id, status="pending"))
            batch.total_recipient_count = len(unique_recipients)
            await write_admin_action(
                session, actor_telegram_id=c.from_user.id, action="announcement_broadcast_started",
                entity_type="announcement_broadcast", entity_id=int(batch.id),
                details={"event_id": eid, "recipient_count": len(unique_recipients), "idempotency_key": identity},
            )
            created = True
        batch_id = int(batch.id)
        await session.commit()
    await state.clear()
    if not created:
        await c.answer("این اطلاع‌رسانی قبلاً ثبت شده است؛ برای جلوگیری از ارسال تکراری، اجرای دوم آغاز نشد.", show_alert=True)
        await _render_announcement_batch_report(c, batch_id, 0)
        return
    await c.answer("ارسال پایدار ثبت شد؛ نتیجه هر دریافت‌کننده جداگانه ذخیره می‌شود.")
    await c.message.edit_text("📣 اطلاع‌رسانی شروع شد. نتیجهٔ هر ارسال در گزارش قابل پیگیری است…")
    await _process_announcement_batch(c.bot, batch_id, recovering=False, actor_telegram_id=c.from_user.id)
    await _render_announcement_batch_report(c, batch_id, 0)


@router.callback_query(F.data.regexp(r"^admin:announce:resume:\d+$"))
async def announcement_resume(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        batch_id = int((c.data or "").rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("گزارش نامعتبر است.", show_alert=True)
    await c.answer("نتیجه‌های نامشخص دوباره ارسال نمی‌شوند؛ موارد باقی‌مانده ادامه می‌یابند.")
    await _process_announcement_batch(c.bot, batch_id, recovering=True, actor_telegram_id=c.from_user.id)
    await _render_announcement_batch_report(c, batch_id, 0)


@router.callback_query(F.data.regexp(r"^admin:announce:report:\d+:\d+$"))
async def announcement_report_page(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        _, _, _, batch_id, page = (c.data or "").split(":")
        batch_id, page = int(batch_id), int(page)
    except (ValueError, TypeError):
        return await c.answer("صفحهٔ گزارش نامعتبر است.", show_alert=True)
    await _render_announcement_batch_report(c, batch_id, page)
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:today:"))
async def reminder_preview(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    event = await get_event(eid)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if event.status != EventStatus.PUBLISHED or event.archived:
        return await c.answer("یادآوری فقط برای پنل منتشرشده و غیرآرشیوی قابل ارسال است.", show_alert=True)
    async with SessionLocal() as session:
        recipient_count = int(await session.scalar(select(func.count(func.distinct(Booking.booked_by_user_id))).where(
            Booking.event_id == eid,
            Booking.status == RegistrationStatus.CONFIRMED,
        )) or 0)
    await state.clear(); await state.update_data(reminder_event_id=eid)
    text = (
        f"🔔 <b>یادآوری Panel Flow</b>\n\nیادآوری برای پنل <b>{escape(event.title)}</b>\n\n"
        + (panel_detail_line("زبان پنل", escape(event.language), icon="🌐") + "\n" if event.language else "")
        + panel_detail_line("روز و تاریخ", f"{escape(event.event_day_label)} – {escape(event.event_date_label)}", icon="📅")
    )
    panel_time = escape(event.start_time_label) + (f"–{escape(event.end_time_label)}" if has_end_time_label(event.end_time_label) else "")
    text += "\n" + panel_detail_line("زمان", panel_time, icon="⏰") + "\n" + panel_detail_line("مکان", escape(event.venue), icon="📍") + "\n\nامروز روز برگزاری پنل است!\nمنتظرتون هستیم!"
    rows = []
    if event.map_url:
        rows.append([InlineKeyboardButton(text="📍 مشاهده موقعیت", url=event.map_url)])
    rows.append([InlineKeyboardButton(text="✅ ارسال به ثبت‌نام‌شده‌ها", callback_data=f"admin:event:today_send:{eid}")])
    rows.append([InlineKeyboardButton(text="❌ لغو", callback_data="admin:today_cancel")])
    await c.message.edit_text(
        f"<b>پیش‌نمایش یادآوری دستی</b>\n"
        f"این پیام فقط برای ثبت‌نام‌کنندگان تأییدشده ارسال می‌شود؛ تعداد دریافت‌کنندگان فعلی: <b>{recipient_count}</b>.\n\n{text}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )
    await state.set_state(AdminManageStates.reminder_confirm)
    await c.answer()


@router.callback_query(F.data == "admin:today_cancel")
async def today_cancel(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text("یادآوری لغو شد.", reply_markup=admin_menu())
    await c.answer()


@router.callback_query(F.data.startswith("admin:event:today_send:"))
async def reminder_send(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    data = await state.get_data()
    if data.get("reminder_event_id") != eid:
        return await c.answer("این پیش‌نمایش منقضی شده است.", show_alert=True)
    event = await get_event(eid)
    if not event:
        return await c.answer("پنل پیدا نشد.", show_alert=True)
    if event.status != EventStatus.PUBLISHED or event.archived:
        return await c.answer("این پنل دیگر منتشرشده و قابل یادآوری نیست.", show_alert=True)
    async with SessionLocal() as session:
        bookings = (await session.execute(
            select(Booking).options(selectinload(Booking.booked_by)).where(
                Booking.event_id == eid,
                Booking.status == RegistrationStatus.CONFIRMED,
            )
        )).scalars().all()
        users_by_id = {b.booked_by.telegram_id: b.booked_by for b in bookings}
        recipients = list(users_by_id.values())
    text = (
        f"🔔 <b>یادآوری Panel Flow</b>\n\nیادآوری برای پنل <b>{escape(event.title)}</b>\n\n"
        + (panel_detail_line("زبان پنل", escape(event.language), icon="🌐") + "\n" if event.language else "")
        + panel_detail_line("روز و تاریخ", f"{escape(event.event_day_label)} – {escape(event.event_date_label)}", icon="📅")
    )
    panel_time = escape(event.start_time_label) + (f"–{escape(event.end_time_label)}" if has_end_time_label(event.end_time_label) else "")
    text += "\n" + panel_detail_line("زمان", panel_time, icon="⏰") + "\n" + panel_detail_line("مکان", escape(event.venue), icon="📍") + "\n\nامروز روز برگزاری پنل است!\nمنتظرتون هستیم!"
    rows = []
    if event.map_url:
        rows.append([InlineKeyboardButton(text="📍 مشاهده موقعیت", url=event.map_url)])
    sent, failed = await broadcast(c.bot, recipients, text, InlineKeyboardMarkup(inline_keyboard=rows))
    await state.clear()
    await c.message.edit_text(f"یادآوری ارسال شد.\nارسال‌شده: {sent}\nناموفق: {failed}\nمجموع: {len(recipients)}", reply_markup=admin_menu())
    await c.answer()


# --- Discount codes and personal rewards --------------------------------------

DISCOUNT_PAGE_SIZE = 6


def _discount_admin_rows(rows, page: int, has_prev: bool, has_next: bool, scope: str):
    buttons = []
    for code in rows:
        label = code.code or code.label or f"هدیه #{code.id}"
        value = discount_display(code)
        kind = {"public": "عادی", "restricted": "ویژه با تأیید", "personal": "هدیه شخصی"}.get(code.kind, code.kind)
        text = f"{label[:24]} · {value} · {kind}"
        buttons.append([InlineKeyboardButton(
            text=text[:64],
            callback_data=f"admin:discount:code:view:{code.id}:{page}:{scope}",
        )])
    nav = []
    if has_prev:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:discount:list:{scope}:{page-1}"))
    if has_next:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:discount:list:{scope}:{page+1}"))
    if nav:
        buttons.append(nav)
    if scope == "inactive":
        buttons.append([InlineKeyboardButton(
            text="🗑 پاک‌سازی همه کدهای غیرفعال",
            callback_data="admin:discount:clear-inactive:start",
        )])
    buttons.append([InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


async def _render_discount_list(c: CallbackQuery, scope: str, page: int = 0):
    active = scope == "active"
    async with SessionLocal() as session:
        total = int((await session.execute(
            select(func.count(DiscountCode.id)).where(DiscountCode.active.is_(active))
        )).scalar_one())
        last_page = max(0, (total - 1) // DISCOUNT_PAGE_SIZE)
        page = min(max(0, page), last_page)
        rows = (await session.execute(
            select(DiscountCode).where(DiscountCode.active.is_(active))
            .order_by(DiscountCode.created_at.desc(), DiscountCode.id.desc())
            .offset(page * DISCOUNT_PAGE_SIZE).limit(DISCOUNT_PAGE_SIZE)
        )).scalars().all()
    if not rows:
        return await c.message.edit_text(
            f"📋 <b>{'کدهای فعال' if active else 'کدهای غیرفعال'}</b>\n\n" + ("کد فعالی وجود ندارد." if active else "کد غیرفعالی ثبت نشده است."),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")]
            ]),
        )
    title = "کدهای فعال" if active else "کدهای غیرفعال"
    lines = [f"📋 <b>{title}</b>", f"صفحه {page + 1} از {last_page + 1}", ""]
    for code in rows:
        async with SessionLocal() as session:
            event_names = (await session.execute(
                select(Event.volume, Event.title).join(
                    DiscountCodeEvent, DiscountCodeEvent.event_id == Event.id
                ).where(DiscountCodeEvent.discount_code_id == code.id)
                .order_by(Event.id.desc())
            )).all()
            status_counts = (await session.execute(
                select(DiscountRedemption.status, func.count(DiscountRedemption.id))
                .where(DiscountRedemption.discount_code_id == code.id)
                .group_by(DiscountRedemption.status)
            )).all()
        target_label = ", ".join(f"{volume_label(vol)} {name}" for vol, name in event_names[:3]) or "بدون پنل واجد شرایط"
        if len(event_names) > 3:
            target_label += f" و {len(event_names)-3} پنل دیگر"
        occupied, redeemed, pending, approved = summarize_redemption_counts(status_counts)
        limit = str(code.max_redemptions) if code.max_redemptions is not None else "بدون محدودیت"
        kind_label = {"public": "عادی – بدون تأیید مدیر", "restricted": "ویژه – با تأیید مدیر", "personal": "هدیه شخصی"}.get(code.kind, code.kind)
        lines.append(
            f"• <b>{escape(code.code or code.label or f'هدیه #{code.id}')}</b> — {escape(discount_display(code))}\n"
            f"  نوع: {escape(kind_label)}\n"
            f"  سهمیه اشغال‌شده: {occupied}/{limit} | استفاده نهایی‌شده: {redeemed}\n"
            f"  در انتظار بررسی مدیر: {pending} | تأییدشده، منتظر ادامه کاربر: {approved}\n"
            f"  پنل‌ها: {escape(target_label)}"
        )
    await c.message.edit_text(
        limit_telegram_html("\n\n".join(lines)),
        reply_markup=_discount_admin_rows(rows, page, page > 0, page < last_page, scope),
    )


async def _render_discount_event_picker(target, state: FSMContext, page: int = 0):
    page = max(0, page)
    async with SessionLocal() as session:
        total = int((await session.execute(select(func.count(Event.id)).where(
            Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ))).scalar_one())
        last_page = max(0, (total - 1) // DISCOUNT_PAGE_SIZE)
        page = min(page, last_page)
        selectable_ids = set((await session.execute(select(Event.id).where(
            Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ))).scalars().all())
        events = (await session.execute(select(Event).where(
            Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ).order_by(Event.id.desc()).offset(page * DISCOUNT_PAGE_SIZE).limit(DISCOUNT_PAGE_SIZE))).scalars().all()
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    selected = sorted({int(x) for x in draft.get("selected_event_ids", [])} & selectable_ids)
    if selected != sorted({int(x) for x in draft.get("selected_event_ids", [])}):
        draft["selected_event_ids"] = selected
        await state.update_data(discount_draft=draft)
    if not events:
        text = "هنوز پنل پیش‌نویس یا منتشرشده‌ای وجود ندارد. ابتدا پنل را بسازید؛ سپس می‌توانید کد را ایجاد کنید."
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 بازگشت برای ساخت پنل", callback_data="admin:home")],
            [InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")],
        ])
    else:
        text = (
            "🗂 <b>انتخاب پنل‌های مشمول کد تخفیف</b>\n\n"
            "یک یا چند پنل را انتخاب کنید. روی دکمهٔ هر پنل بزنید تا انتخاب یا از انتخاب خارج شود.\n"
            "پنل‌های پیش‌نویس نیز قابل انتخاب‌اند و پس از انتشار، مشمول همین کد خواهند بود.\n"
            f"✅ انتخاب‌شده: <b>{len(selected)}</b> | صفحه {page + 1} از {last_page + 1}\n"
            "کد فقط برای پنل‌های انتخاب‌شده معتبر است. «انتخاب همهٔ پنل‌های فعلی» شامل پنل‌های آینده‌ای که بعداً ساخته می‌شوند نیست."
        )
        keyboard = discount_event_picker_keyboard(events, selected, page, page > 0, page < last_page)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=keyboard)
    else:
        await target.answer(text, reply_markup=keyboard)


# --- Idempotent bulk personal rewards -------------------------------------------------

def _bulk_parse_dict(value) -> dict:
    return {
        "ids": [int(x) for x in value.ids],
        "duplicates": list(value.duplicates),
        "invalid": list(value.invalid),
        "submitted_entries": int(value.submitted_entries),
    }


def _bulk_value_label(discount_type: str, discount_value: str | Decimal) -> str:
    value = Decimal(str(discount_value))
    return f"{int(value)}٪" if discount_type == "percent" else f"{int(value):,} تومان"


def _bulk_batch_key(admin_id: int, config: dict) -> str:
    # Semantic idempotency: importing the same unique recipients with the same
    # reward and scope again resolves to the same durable batch.
    identity = {
        "admin_id": int(admin_id),
        "recipients": sorted(int(x) for x in config.get("recipient_ids", [])),
        "discount_type": str(config.get("discount_type")),
        "discount_value": str(config.get("discount_value")),
        "reason": str(config.get("reason") or "").strip(),
        "event_ids": sorted(int(x) for x in config.get("event_ids", [])),
    }
    return hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


async def _render_bulk_batch_preview(target, batch_id: int):
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, int(batch_id))
        if batch is None:
            text = "این پیش‌نمایش پیدا نشد یا منقضی شده است."
            rows = None
            config = {}
        else:
            config = json.loads(batch.config_json)
            batch_status = str(batch.status)
            rows = (await session.execute(select(RewardBatchRecipient).where(
                RewardBatchRecipient.batch_id == batch_id
            ).order_by(RewardBatchRecipient.telegram_id))).scalars().all()
            event_rows = (await session.execute(select(Event).where(Event.id.in_(config.get("event_ids", []))))).scalars().all() if config.get("event_ids") else []
            event_labels = [f"{volume_label(e.volume)} — {e.title}" for e in event_rows]
            statuses = [r.creation_status for r in rows]
            eligible = sum(x == "pending" for x in statuses)
            unknown = sum(x == "skipped" and (r.outcome_reason or "").startswith("شناسه در ربات ثبت نشده") for r in rows)
            bot_users = sum(x == "skipped" and (r.outcome_reason or "").startswith("حساب ربات") for x, r in zip(statuses, rows))
            blocked = sum(x == "skipped" and (r.outcome_reason or "").startswith("حساب مسدود") for x, r in zip(statuses, rows))
            conflict = sum(x == "skipped" and (r.outcome_reason or "").startswith("هدیه فعال") for x, r in zip(statuses, rows))
            parse_data = config.get("parse", {})
            duplicate_examples = "، ".join(
                f"{item.get('telegram_id')} ({item.get('entry')})"
                for item in parse_data.get("duplicates", [])[:5]
            ) or "—"
            invalid_examples = "، ".join(
                f"{str(item.get('value', ''))[:35]} ({item.get('entry')})"
                for item in parse_data.get("invalid", [])[:5]
            ) or "—"
            text = (
                "🎁 <b>پیش‌نمایش هدیه‌های گروهی</b>\n\n"
                f"موارد ورودی: <b>{int(parse_data.get('submitted_entries', 0))}</b>\n"
                f"شناسه‌های معتبر و یکتا: <b>{len(config.get('recipient_ids', []))}</b>\n"
                f"تکراری: <b>{len(parse_data.get('duplicates', []))}</b> | نامعتبر: <b>{len(parse_data.get('invalid', []))}</b>\n"
                f"نمونهٔ تکراری‌ها: {escape(duplicate_examples)}\n"
                f"نمونهٔ نامعتبرها: {escape(invalid_examples)}\n"
                f"شناسه ثبت‌نشده: <b>{unknown}</b> | حساب ربات: <b>{bot_users}</b>\n"
                f"مسدود: <b>{blocked}</b> | دارای هدیهٔ متداخل: <b>{conflict}</b>\n"
                f"واجد شرایط فعلی / هدیهٔ مورد انتظار: <b>{eligible}</b>\n\n"
                f"میزان تخفیف: <b>{escape(_bulk_value_label(config['discount_type'], config['discount_value']))}</b>\n"
                f"علت: {escape(str(config.get('reason') or '—'))}\n"
                f"پنل‌های مجاز: {escape('; '.join(event_labels)[:700] or '—')}\n\n"
                "موارد نامعتبر، تکراری، ناشناخته، ربات، مسدود و دارای هدیهٔ متداخل هدیه دریافت نمی‌کنند.\n"
                "امکان ارسال پیام خصوصی از پیش قابل تضمین نیست؛ نتیجهٔ ایجاد هدیه و نتیجهٔ ارسال جداگانه ثبت می‌شود."
            )
    if rows is None:
        keyboard = discount_manage_keyboard()
    elif config.get("recipient_ids"):
        if batch_status == "preview":
            keyboard = bulk_reward_preview_keyboard(batch_id)
        else:
            text, resumable = await _bulk_reward_summary(batch_id)
            keyboard = bulk_reward_result_keyboard(batch_id, resumable=resumable)
    else:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ لغو", callback_data=f"admin:discount:bulk:cancel:{batch_id}")]])
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(limit_telegram_html(text), reply_markup=keyboard)
    else:
        await target.answer(limit_telegram_html(text), reply_markup=keyboard)


@router.callback_query(F.data == "admin:discount:bulk:start")
async def admin_bulk_reward_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.update_data(bulk_input_mode=None)
    await c.message.edit_text(
        "🎁 <b>هدیهٔ شخصی برای چند دریافت‌کننده</b>\n\n"
        "ابتدا فهرست شناسه‌های عددی تلگرام را وارد کنید. پیش از ایجاد هدیه‌ها، یک پیش‌نمایش کامل برای بررسی نمایش داده می‌شود.",
        reply_markup=bulk_reward_entry_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data == "admin:discount:bulk:manual")
async def admin_bulk_reward_manual_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.update_data(bulk_input_mode="manual")
    await state.set_state(BulkRewardStates.waiting_recipients)
    await c.message.edit_text(
        "شناسه‌های عددی تلگرام را ارسال کنید؛ ترجیحاً هر شناسه در یک خط. جداکردن با ویرگول هم پذیرفته می‌شود.\n"
        "عددهای فارسی و عربی پشتیبانی می‌شوند. حداکثر ۵۰۰ ورودی و ۲۰٬۰۰۰ نویسه. متن دلخواه یا نام کاربری پذیرفته نیست.",
        reply_markup=discount_cancel_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data == "admin:discount:bulk:upload")
async def admin_bulk_reward_upload_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.update_data(bulk_input_mode="upload")
    await state.set_state(BulkRewardStates.waiting_recipients)
    await c.message.edit_text(
        "یک فایل <code>.txt</code> یا <code>.csv</code> بارگذاری کنید؛ هر ردیف باید یک شناسهٔ عددی تلگرام داشته باشد."
        " در CSV عنوان‌هایی مانند <code>telegram_id</code> در سطر اول پذیرفته می‌شود.\n"
        "حداکثر حجم فایل ۱۰۰ کیلوبایت و حداکثر تعداد ردیف ۵۰۰ است. پشتیبانی XLSX در این نسخه فعال نیست.",
        reply_markup=discount_cancel_keyboard(),
    )
    await c.answer()


async def _bulk_accept_parsed(m: Message, state: FSMContext, parsed, source: str):
    if not parsed.ids:
        samples = ", ".join(escape(str(item.get("value", ""))) for item in parsed.invalid[:5]) or "—"
        return await m.answer(
            "هیچ شناسهٔ معتبر و یکتایی در ورودی پیدا نشد؛ هنوز هیچ هدیه‌ای ساخته نشده است.\n"
            f"تعداد موارد نامعتبر: {len(parsed.invalid)}\nنمونه: {samples}\nلطفاً فهرست را اصلاح و دوباره ارسال کنید.",
            reply_markup=discount_cancel_keyboard(),
        )
    await state.update_data(bulk_parse=_bulk_parse_dict(parsed), bulk_source=source)
    await state.set_state(BulkRewardStates.waiting_value)
    await m.answer(
        f"✅ فهرست خوانده شد: {len(parsed.ids)} شناسهٔ یکتا، {len(parsed.duplicates)} مورد تکراری و {len(parsed.invalid)} مورد نامعتبر.\n\n"
        "میزان تخفیف مشترک را وارد کنید: درصد مانند <code>80%</code> یا مبلغ ثابت مانند <code>100K</code> برای ۱۰۰٬۰۰۰ تومان.",
        reply_markup=discount_cancel_keyboard(),
    )


@router.message(BulkRewardStates.waiting_recipients, F.text)
async def admin_bulk_reward_receive_manual(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    data = await state.get_data()
    if data.get("bulk_input_mode") != "manual":
        return await m.answer("در این مرحله فایل TXT/CSV انتظار می‌رود.", reply_markup=discount_cancel_keyboard())
    try:
        parsed = parse_manual_recipients(m.text or "")
    except ValueError as exc:
        messages = {
            "INPUT_TOO_LARGE": "متن بیش از حد مجاز است؛ حداکثر ۲۰٬۰۰۰ نویسه.",
            "TOO_MANY_ROWS": "تعداد ورودی‌ها بیشتر از ۵۰۰ است.",
        }
        return await m.answer(messages.get(str(exc), "فهرست شناسه‌ها قابل پردازش نیست."), reply_markup=discount_cancel_keyboard())
    if parsed.submitted_entries == 0:
        return await m.answer("فهرست خالی است؛ یک یا چند شناسهٔ عددی ارسال کنید.", reply_markup=discount_cancel_keyboard())
    await _bulk_accept_parsed(m, state, parsed, "manual")


@router.message(BulkRewardStates.waiting_recipients, F.document)
async def admin_bulk_reward_receive_file(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    data = await state.get_data()
    if data.get("bulk_input_mode") != "upload":
        return await m.answer("ابتدا گزینهٔ بارگذاری فایل را انتخاب کنید.", reply_markup=discount_cancel_keyboard())
    document = m.document
    suffix = Path(document.file_name or "").suffix.lower()
    if suffix not in {".txt", ".csv"}:
        return await m.answer("فقط فایل‌های TXT و CSV پشتیبانی می‌شوند؛ فایل XLSX پذیرفته نمی‌شود.", reply_markup=discount_cancel_keyboard())
    if document.file_size is not None and document.file_size > MAX_BULK_FILE_BYTES:
        return await m.answer("حجم فایل از سقف ۱۰۰ کیلوبایت بیشتر است.", reply_markup=discount_cancel_keyboard())
    temp_name = f"bulk_{secrets.token_hex(10)}{suffix}"
    path = None
    try:
        path = await download_file(m.bot, document.file_id, temp_name, file_size=document.file_size)
        content = Path(path).read_bytes()
        parsed = parse_uploaded_recipients(content, suffix)
    except ValueError as exc:
        messages = {
            "FILE_TOO_LARGE": "حجم فایل از سقف ۱۰۰ کیلوبایت بیشتر است.",
            "UNSUPPORTED_FILE": "فقط TXT و CSV پشتیبانی می‌شوند.",
            "INVALID_ENCODING": "فایل باید متن UTF-8 باشد.",
            "INVALID_TEXT": "فایل حاوی نویسه‌های نامعتبر است.",
            "INVALID_CSV": "ساختار CSV معتبر نیست.",
            "INPUT_TOO_LARGE": "متن فایل بیش از حد مجاز است.",
            "TOO_MANY_ROWS": "فایل بیش از ۵۰۰ ورودی دارد.",
        }
        return await m.answer(messages.get(str(exc), "فایل قابل پردازش نیست."), reply_markup=discount_cancel_keyboard())
    except Exception:
        logger.exception("Could not read bulk reward recipient file", extra={"admin_id": m.from_user.id})
        return await m.answer("خواندن فایل ممکن نشد؛ فایل TXT/CSV دیگری بارگذاری کنید.", reply_markup=discount_cancel_keyboard())
    finally:
        if path:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                logger.warning("Could not remove temporary bulk reward file")
    if parsed.submitted_entries == 0:
        return await m.answer("فایل هیچ شناسه‌ای ندارد.", reply_markup=discount_cancel_keyboard())
    await _bulk_accept_parsed(m, state, parsed, "file")


@router.message(BulkRewardStates.waiting_value, F.text)
async def admin_bulk_reward_receive_value(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    try:
        discount_type, discount_value = parse_personal_discount_value(m.text)
    except ValueError:
        return await m.answer("مقدار نامعتبر است. نمونه: <code>80%</code> یا <code>100K</code>.", reply_markup=discount_cancel_keyboard())
    await state.update_data(bulk_discount_type=discount_type, bulk_discount_value=str(discount_value))
    await state.set_state(BulkRewardStates.waiting_reason)
    await m.answer("علت مشترک هدیه را وارد کنید (۱ تا ۵۰۰ نویسه). این توضیح همراه پیام هدیه برای دریافت‌کننده فرستاده می‌شود.", reply_markup=discount_cancel_keyboard())


@router.message(BulkRewardStates.waiting_reason, F.text, ~F.text.startswith("/"))
async def admin_bulk_reward_receive_reason(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    reason = (m.text or "").strip()
    if not reason or len(reason) > 500:
        return await m.answer("علت باید بین ۱ تا ۵۰۰ نویسه باشد.", reply_markup=discount_cancel_keyboard())
    data = await state.get_data()
    parsed = dict(data.get("bulk_parse") or {})
    if not parsed.get("ids"):
        await state.clear()
        return await m.answer("فهرست شناسه‌ها منقضی شده است؛ از منوی مدیریت هدیهٔ گروهی را دوباره شروع کنید.", reply_markup=discount_manage_keyboard())
    draft = {
        "kind": "personal_bulk",
        "selected_event_ids": [],
        "discount_type": str(data.get("bulk_discount_type")),
        "discount_value": str(data.get("bulk_discount_value")),
        "reason": reason,
    }
    await state.update_data(discount_draft=draft)
    await state.set_state(DiscountAdminStates.selecting_events)
    await _render_discount_event_picker(m, state, 0)


async def _create_bulk_reward_preview(c: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    parse_data = dict(data.get("bulk_parse") or {})
    recipient_ids = sorted({int(x) for x in parse_data.get("ids", [])})
    event_ids = sorted({int(x) for x in draft.get("selected_event_ids", [])})
    if not recipient_ids or not event_ids:
        return await c.answer("فهرست شناسه و حداقل یک پنل لازم است.", show_alert=True)
    async with SessionLocal() as session:
        eligible_events = (await session.execute(select(Event.id).where(
            Event.id.in_(event_ids), Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ))).scalars().all()
        if set(int(x) for x in eligible_events) != set(event_ids):
            return await c.answer("یکی از پنل‌ها دیگر واجد شرایط نیست؛ انتخاب پنل‌ها را دوباره بررسی کنید.", show_alert=True)
        config = {
            "recipient_ids": recipient_ids,
            "parse": parse_data,
            "event_ids": event_ids,
            "discount_type": str(draft.get("discount_type")),
            "discount_value": str(draft.get("discount_value")),
            "reason": str(draft.get("reason") or "").strip(),
        }
        batch_key = _bulk_batch_key(c.from_user.id, config)
        existing = (await session.execute(
            select(RewardBatch).where(RewardBatch.batch_key == batch_key).with_for_update()
        )).scalar_one_or_none()
        if existing:
            batch_id = int(existing.id)
            # A cancelled batch never created rewards (cancellation is only allowed
            # at preview time). Reopening it is safe and lets admins correct/retry
            # the workflow without bypassing semantic idempotency.
            if existing.status == "cancelled":
                existing.status = "preview"
                existing.completed_at = None
                existing.updated_at = utc_now_naive()
                old_rows = (await session.execute(
                    select(RewardBatchRecipient).where(RewardBatchRecipient.batch_id == batch_id).with_for_update()
                )).scalars().all()
                for old_row in old_rows:
                    old_row.delivery_status = "not_attempted"
                    old_row.updated_at = utc_now_naive()
                await write_admin_action(
                    session, actor_telegram_id=c.from_user.id, action="bulk_reward_batch_reopened",
                    entity_type="reward_batch", entity_id=batch_id,
                    details={"recipient_count": len(old_rows)},
                )
                await session.commit()
            await state.clear()
        else:
            batch = RewardBatch(
                batch_key=batch_key,
                created_by_telegram_id=int(c.from_user.id),
                config_json=json.dumps(config, ensure_ascii=False, separators=(",", ":")),
                status="preview",
                created_at=utc_now_naive(), updated_at=utc_now_naive(),
            )
            session.add(batch)
            await session.flush()
            batch_id = int(batch.id)
            users = (await session.execute(select(User).where(User.telegram_id.in_(recipient_ids)))).scalars().all()
            users_by_tg = {int(user.telegram_id): user for user in users}
            blocked_ids = set((await session.execute(select(BlockedUser.telegram_id).where(BlockedUser.telegram_id.in_(recipient_ids)))).scalars().all())
            conflicts = set((await session.execute(
                select(DiscountCode.recipient_telegram_id)
                .join(DiscountCodeEvent, DiscountCodeEvent.discount_code_id == DiscountCode.id)
                .where(
                    DiscountCode.kind == "personal", DiscountCode.active.is_(True),
                    DiscountCode.recipient_telegram_id.in_(recipient_ids),
                    DiscountCodeEvent.event_id.in_(event_ids),
                )
            )).scalars().all())
            for telegram_id in recipient_ids:
                user = users_by_tg.get(telegram_id)
                if user is None:
                    creation_status, why = "skipped", "شناسه در ربات ثبت نشده است؛ برای حفظ یکپارچگی، حساب ساخته نشد"
                elif user.is_bot:
                    creation_status, why = "skipped", "حساب ربات قابل دریافت هدیه نیست"
                elif telegram_id in blocked_ids:
                    creation_status, why = "skipped", "حساب مسدود است"
                elif telegram_id in conflicts:
                    creation_status, why = "skipped", "هدیه فعال با محدودهٔ پنل انتخاب‌شده تداخل دارد"
                else:
                    creation_status, why = "pending", None
                session.add(RewardBatchRecipient(
                    batch_id=batch_id, telegram_id=telegram_id,
                    creation_status=creation_status, delivery_status="not_attempted",
                    outcome_reason=why, updated_at=utc_now_naive(),
                ))
            await write_admin_action(
                session, actor_telegram_id=c.from_user.id, action="bulk_reward_batch_previewed",
                entity_type="reward_batch", entity_id=batch_id,
                details={"recipient_count": len(recipient_ids), "event_ids": event_ids, "discount_type": config["discount_type"], "discount_value": config["discount_value"]},
            )
            await session.commit()
            await state.clear()
    await _render_bulk_batch_preview(c, batch_id)
    await c.answer("پیش‌نمایش آماده شد.")


@router.callback_query(F.data.regexp(r"^admin:discount:bulk:cancel:\d+$"))
async def admin_bulk_reward_cancel_batch(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    batch_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, batch_id, with_for_update=True)
        if not batch:
            return await c.answer("این نوبت پیدا نشد.", show_alert=True)
        if batch.status != "preview":
            return await c.answer("نوبتی که پردازش آن شروع شده قابل لغو نیست؛ از گزارش وضعیت استفاده کنید.", show_alert=True)
        batch.status = "cancelled"
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="bulk_reward_batch_cancelled", entity_type="reward_batch", entity_id=batch_id)
        await session.commit()
    await c.message.edit_text("نوبت هدیهٔ گروهی لغو شد؛ هیچ هدیه‌ای ایجاد نشد.", reply_markup=discount_manage_keyboard())
    await c.answer()


async def _bulk_reward_summary(batch_id: int) -> tuple[str, bool]:
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, int(batch_id))
        if not batch:
            return "نوبت پیدا نشد.", False
        config = json.loads(batch.config_json)
        recipients = (await session.execute(select(RewardBatchRecipient).where(
            RewardBatchRecipient.batch_id == batch_id
        ))).scalars().all()
    created = sum(r.creation_status == "created" for r in recipients)
    failed_creation = sum(r.creation_status == "failed" for r in recipients)
    skipped = sum(r.creation_status == "skipped" for r in recipients)
    sent = sum(r.delivery_status == "sent" for r in recipients)
    failed_delivery = sum(r.delivery_status == "failed" for r in recipients)
    unknown_delivery = sum(r.delivery_status == "unknown" for r in recipients)
    pending = sum(r.creation_status == "pending" or (r.creation_status == "created" and r.delivery_status in ("not_attempted", "sending")) for r in recipients)
    parse_data = config.get("parse", {})
    text = (
        f"🎁 <b>گزارش نوبت هدیهٔ گروهی #{batch_id}</b>\n\n"
        f"هدیه ایجادشده: <b>{created}</b>\nپیام ارسال‌شده: <b>{sent}</b>\n"
        f"خطای ایجاد: <b>{failed_creation}</b>\nخطای ارسال پیام: <b>{failed_delivery}</b>\n"
        f"نتیجهٔ ارسال نامشخص: <b>{unknown_delivery}</b>\nردشده/حذف‌شده از فهرست: <b>{skipped}</b>\n"
        f"ورودی تکراری: <b>{len(parse_data.get('duplicates', []))}</b> | ورودی نامعتبر: <b>{len(parse_data.get('invalid', []))}</b>\n"
        f"وضعیت نوبت: <b>{escape(admin_status_display_label(batch.status))}</b>"
    )
    return text, bool(pending and batch.status in ("processing", "partial"))


async def _process_bulk_reward_batch(c: CallbackQuery, batch_id: int, *, resume: bool = False):
    # On an explicit resume, a prior 'sending' state is ambiguous (the Telegram
    # request may have succeeded just before the process stopped). Mark it unknown
    # rather than sending again and risking duplicate notifications.
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, batch_id, with_for_update=True)
        if not batch:
            return await c.answer("نوبت پیدا نشد.", show_alert=True)
        if batch.status == "preview":
            return await c.answer("ابتدا نوبت را از پیش‌نمایش تأیید کنید.", show_alert=True)
        if batch.status == "cancelled":
            return await c.answer("این نوبت لغو شده است.", show_alert=True)
        if batch.status == "completed":
            await _render_bulk_batch_preview(c, batch_id)
            return await c.answer("این نوبت قبلاً پردازش شده است.")
        if batch.status == "processing" and not resume:
            await _render_bulk_batch_preview(c, batch_id)
            return await c.answer("پردازش این نوبت قبلاً آغاز شده است؛ برای بررسی ادامهٔ کار از دکمهٔ ادامه استفاده کنید.", show_alert=True)
        if resume:
            stale_sending = (await session.execute(select(RewardBatchRecipient).where(
                RewardBatchRecipient.batch_id == batch_id,
                RewardBatchRecipient.delivery_status == "sending",
            ).with_for_update())).scalars().all()
            for row in stale_sending:
                row.delivery_status = "unknown"
                row.outcome_reason = "پاسخ تلگرام هنگام ارسال نامشخص بود؛ برای جلوگیری از پیام تکراری خودکار ارسال مجدد نشد"
                row.updated_at = utc_now_naive()
        batch.status = "processing"
        batch.updated_at = utc_now_naive()
        config = json.loads(batch.config_json)
        await session.commit()

    try:
        bot_user = await c.bot.me()
        bot_username = getattr(bot_user, "username", None)
    except Exception:
        bot_username = None
        logger.info("Could not obtain bot username while processing reward batch %s", batch_id, exc_info=True)

    async with SessionLocal() as session:
        event_rows = (await session.execute(select(Event).where(Event.id.in_(config["event_ids"])))).scalars().all() if config.get("event_ids") else []
        event_labels = [f"{volume_label(e.volume)} — {e.title}" for e in event_rows]
    for telegram_id in config.get("recipient_ids", []):
        send_payload = None
        # Isolate every recipient in its own transaction. The unique recipient row
        # plus row lock makes a repeated confirmation idempotent.
        try:
            async with SessionLocal() as session:
                row = (await session.execute(select(RewardBatchRecipient).where(
                    RewardBatchRecipient.batch_id == batch_id,
                    RewardBatchRecipient.telegram_id == int(telegram_id),
                ).with_for_update())).scalar_one_or_none()
                if row is None or row.creation_status in ("skipped", "failed"):
                    continue
                if row.creation_status == "pending":
                    user = (await session.execute(select(User).where(User.telegram_id == int(telegram_id)))).scalar_one_or_none()
                    if user is None:
                        row.creation_status, row.outcome_reason = "skipped", "شناسه هنگام تأیید دیگر در ربات ثبت نشده است"
                        row.updated_at = utc_now_naive()
                        await session.commit()
                        continue
                    if user.is_bot or await is_telegram_id_blocked(session, int(telegram_id)):
                        row.creation_status, row.outcome_reason = "skipped", "حساب ربات یا مسدود است"
                        row.updated_at = utc_now_naive()
                        await session.commit()
                        continue
                    event_ids = [int(x) for x in config["event_ids"]]
                    available_events = (await session.execute(select(Event.id).where(
                        Event.id.in_(event_ids), Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
                    ))).scalars().all()
                    if set(available_events) != set(event_ids):
                        row.creation_status, row.outcome_reason = "skipped", "یکی از پنل‌های انتخاب‌شده دیگر واجد شرایط نیست"
                        row.updated_at = utc_now_naive()
                        await session.commit()
                        continue
                    conflict = (await session.execute(select(DiscountCode.id).join(
                        DiscountCodeEvent, DiscountCodeEvent.discount_code_id == DiscountCode.id
                    ).where(
                        DiscountCode.kind == "personal", DiscountCode.active.is_(True),
                        DiscountCode.recipient_telegram_id == int(telegram_id),
                        DiscountCodeEvent.event_id.in_(event_ids),
                    ).limit(1).with_for_update())).scalar_one_or_none()
                    if conflict is not None:
                        row.creation_status, row.outcome_reason = "skipped", "هدیه فعال با پنل انتخاب‌شده تداخل پیدا کرده است"
                        row.updated_at = utc_now_naive()
                        await session.commit()
                        continue
                    value = Decimal(str(config["discount_value"]))
                    code = DiscountCode(
                        code=None,
                        label=f"هدیه {int(value)}٪" if config["discount_type"] == "percent" else f"هدیه {int(value):,} تومان",
                        kind="personal", discount_type=config["discount_type"], discount_value=value,
                        requires_approval=False, active=True, max_redemptions=1,
                        usage_policy="once_total", recipient_telegram_id=int(telegram_id),
                        created_by_telegram_id=int(c.from_user.id), reason=str(config.get("reason") or "")[:500] or None,
                        created_at=utc_now_naive(),
                    )
                    session.add(code)
                    await session.flush()
                    for event_id in event_ids:
                        session.add(DiscountCodeEvent(discount_code_id=int(code.id), event_id=event_id))
                    row.creation_status = "created"
                    row.reward_code_id = int(code.id)
                    row.delivery_status = "not_attempted"
                    row.outcome_reason = None
                    row.updated_at = utc_now_naive()
                    await write_admin_action(
                        session, actor_telegram_id=c.from_user.id, action="personal_reward_created",
                        entity_type="discount_code", entity_id=int(code.id),
                        details={"recipient_telegram_id": int(telegram_id), "batch_id": int(batch_id), "event_ids": event_ids},
                    )
                    await session.commit()
                # Reload durable recipient data after the create transaction.
                async with SessionLocal() as check_session:
                    current = await check_session.get(RewardBatchRecipient, row.id)
                    if current is None or current.creation_status != "created":
                        continue
                    if current.delivery_status == "sent" or current.delivery_status in ("failed", "unknown", "sending"):
                        continue
                    current.delivery_status = "sending"
                    current.updated_at = utc_now_naive()
                    code_id = int(current.reward_code_id)
                    await check_session.commit()
                    send_payload = (code_id, str(config.get("reason") or ""), int(telegram_id))
        except Exception as exc:
            logger.exception("Failed to create one personal reward in batch %s", batch_id, extra={"telegram_id": int(telegram_id)})
            async with SessionLocal() as session:
                row = (await session.execute(select(RewardBatchRecipient).where(
                    RewardBatchRecipient.batch_id == batch_id,
                    RewardBatchRecipient.telegram_id == int(telegram_id),
                ).with_for_update())).scalar_one_or_none()
                if row and row.creation_status == "pending":
                    row.creation_status = "failed"
                    row.outcome_reason = f"خطای ایجاد هدیه: {type(exc).__name__}"[:255]
                    row.updated_at = utc_now_naive()
                    await session.commit()
            continue

        if send_payload:
            code_id, reason, recipient_id = send_payload
            deep_link = f"https://t.me/{bot_username}?start=reward_{code_id}" if bot_username else None
            try:
                await c.bot.send_message(
                    recipient_id,
                    "🎁 <b>یک هدیه ویژه برای شما!</b>\n\n"
                    f"میزان تخفیف: <b>{escape(_bulk_value_label(config['discount_type'], config['discount_value']))}</b>\n"
                    + (f"علت هدیه: {escape(reason)}\n" if reason else "")
                    + "پنل‌های مجاز:\n" + "\n".join(f"• {escape(label)}" for label in event_labels[:8])
                    + (f"\nو {len(event_labels)-8} پنل دیگر" if len(event_labels) > 8 else "")
                    + "\n\nاین هدیه فقط در پنل‌های فهرست‌شده قابل استفاده است و صندلی را پیشاپیش رزرو نمی‌کند.",
                    reply_markup=personal_reward_keyboard(code_id),
                    disable_web_page_preview=True,
                )
                delivery_status, delivery_reason = "sent", None
            except Exception as exc:
                delivery_status = "failed"
                delivery_reason = f"ارسال پیام شکست خورد: {type(exc).__name__}"[:255]
                logger.info("Could not deliver reward batch message; batch_id=%s telegram_id=%s", batch_id, recipient_id, exc_info=True)
            async with SessionLocal() as session:
                current = (await session.execute(select(RewardBatchRecipient).where(
                    RewardBatchRecipient.batch_id == batch_id,
                    RewardBatchRecipient.telegram_id == recipient_id,
                ).with_for_update())).scalar_one_or_none()
                if current and current.delivery_status == "sending":
                    current.delivery_status = delivery_status
                    current.outcome_reason = delivery_reason
                    current.updated_at = utc_now_naive()
                    await session.commit()

    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, batch_id, with_for_update=True)
        rows = (await session.execute(select(RewardBatchRecipient).where(RewardBatchRecipient.batch_id == batch_id))).scalars().all()
        all_terminal = all(r.creation_status in ("created", "skipped", "failed") and r.delivery_status != "not_attempted" for r in rows)
        # Creation-failed/skipped rows never attempt delivery and are terminal.
        all_terminal = all(r.creation_status in ("skipped", "failed") or (r.creation_status == "created" and r.delivery_status in ("sent", "failed", "unknown")) for r in rows)
        batch.status = "completed" if all_terminal else "partial"
        batch.updated_at = utc_now_naive()
        if all_terminal:
            batch.completed_at = utc_now_naive()
        await write_admin_action(
            session, actor_telegram_id=c.from_user.id, action="bulk_reward_batch_processed",
            entity_type="reward_batch", entity_id=batch_id,
            details={"status": batch.status, "created": sum(r.creation_status == "created" for r in rows), "sent": sum(r.delivery_status == "sent" for r in rows)},
        )
        await session.commit()
    summary, resumable = await _bulk_reward_summary(batch_id)
    await c.message.edit_text(summary, reply_markup=bulk_reward_result_keyboard(batch_id, resumable=resumable))
    await c.answer("پردازش نوبت پایان یافت.")


@router.callback_query(F.data.regexp(r"^admin:discount:bulk:confirm:\d+$"))
async def admin_bulk_reward_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    batch_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, batch_id, with_for_update=True)
        if not batch:
            return await c.answer("این نوبت پیدا نشد.", show_alert=True)
        if batch.status != "preview":
            await _render_bulk_batch_preview(c, batch_id)
            return await c.answer("این نوبت قبلاً تأیید یا پردازش شده است؛ هدیهٔ تکراری ایجاد نمی‌شود.", show_alert=True)
        batch.status = "processing"
        batch.updated_at = utc_now_naive()
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="bulk_reward_batch_confirmed", entity_type="reward_batch", entity_id=batch_id)
        await session.commit()
    await c.message.edit_text("پردازش هدیه‌ها آغاز شد. نتیجهٔ هر دریافت‌کننده جداگانه ذخیره می‌شود؛ خطای یک نفر هدیه‌های دیگران را حذف نمی‌کند.")
    # The status was atomically advanced above. Resume mode here processes it
    # without treating the current confirmed callback as a duplicate.
    await _process_bulk_reward_batch(c, batch_id, resume=True)


@router.callback_query(F.data.regexp(r"^admin:discount:bulk:resume:\d+$"))
async def admin_bulk_reward_resume(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    batch_id = int((c.data or "").rsplit(":", 1)[1])
    await _process_bulk_reward_batch(c, batch_id, resume=True)


@router.callback_query(F.data.regexp(r"^admin:discount:bulk:report:\d+:\d+$"))
async def admin_bulk_reward_report(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    batch_id, page = int(parts[-2]), int(parts[-1])
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, batch_id)
        if not batch:
            return await c.answer("نوبت پیدا نشد.", show_alert=True)
        config = json.loads(batch.config_json)
        recipients = (await session.execute(select(RewardBatchRecipient).where(
            RewardBatchRecipient.batch_id == batch_id
        ).order_by(RewardBatchRecipient.telegram_id))).scalars().all()
    page_size = 15
    last_page = max(0, (len(recipients) - 1) // page_size)
    page = min(max(0, page), last_page)
    rows = recipients[page * page_size:(page + 1) * page_size]
    lines = [f"📄 <b>گزارش جزئی نوبت #{batch_id}</b> — صفحه {page+1}/{last_page+1}"]
    if page == 0:
        parse_data = config.get("parse", {})
        if parse_data.get("invalid"):
            lines.append(f"\n<b>ورودی‌های نامعتبر ({len(parse_data['invalid'])})</b>")
            lines.extend(f"• {escape(str(x.get('entry','')))}: <code>{escape(str(x.get('value',''))[:50])}</code>" for x in parse_data["invalid"][:8])
        if parse_data.get("duplicates"):
            lines.append(f"\n<b>تکراری‌ها ({len(parse_data['duplicates'])})</b>")
            lines.extend(f"• {escape(str(x.get('entry','')))}: <code>{int(x.get('telegram_id',0))}</code>" for x in parse_data["duplicates"][:8])
    for row in rows:
        name_status = row.creation_status
        if row.creation_status == "created":
            name_status = "ایجاد شد"
        elif row.creation_status == "skipped":
            name_status = "رد شد"
        elif row.creation_status == "failed":
            name_status = "خطای ایجاد"
        else:
            name_status = "در انتظار"
        delivery = {"sent": "پیام ارسال شد", "failed": "ارسال ناموفق", "unknown": "ارسال نامشخص", "sending": "در حال ارسال", "not_attempted": "بدون تلاش"}.get(row.delivery_status, row.delivery_status)
        line = f"• <code>{row.telegram_id}</code> — {name_status}; {delivery}"
        if row.outcome_reason:
            line += f"\n  {escape(row.outcome_reason[:140])}"
        if row.reward_code_id and row.delivery_status in ("failed", "unknown"):
            try:
                me = await c.bot.me()
                if me.username:
                    line += f"\n  لینک هدیه: https://t.me/{escape(me.username)}?start=reward_{row.reward_code_id}"
            except Exception:
                pass
        lines.append(line)
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:discount:bulk:report:{batch_id}:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:discount:bulk:report:{batch_id}:{page+1}"))
    keyboard_rows = [nav] if nav else []
    parse_data = config.get("parse", {})
    if parse_data.get("invalid") or parse_data.get("duplicates"):
        keyboard_rows.append([InlineKeyboardButton(
            text="📋 جزئیات همهٔ ورودی‌های نامعتبر و تکراری",
            callback_data=f"admin:discount:bulk:inputerrors:{batch_id}:0",
        )])
    keyboard_rows.append([InlineKeyboardButton(text="🔙 خلاصه نوبت", callback_data=f"admin:discount:bulk:summary:{batch_id}")])
    await c.message.edit_text(limit_telegram_html("\n".join(lines)), reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard_rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:bulk:inputerrors:\d+:\d+$"))
async def admin_bulk_reward_input_errors(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    batch_id, page = int(parts[-2]), max(0, int(parts[-1]))
    async with SessionLocal() as session:
        batch = await session.get(RewardBatch, batch_id)
        if not batch:
            return await c.answer("نوبت پیدا نشد.", show_alert=True)
        parse_data = json.loads(batch.config_json).get("parse", {})
    errors = []
    errors.extend(("نامعتبر", item.get("entry", "—"), str(item.get("value", "")), str(item.get("reason", "شناسه معتبر نیست"))) for item in parse_data.get("invalid", []))
    errors.extend(("تکراری", item.get("entry", "—"), str(item.get("telegram_id", "")), "این شناسه قبلاً در فهرست وارد شده است") for item in parse_data.get("duplicates", []))
    page_size = 15
    last_page = max(0, (len(errors) - 1) // page_size)
    page = min(page, last_page)
    lines = [f"📋 <b>ورودی‌های نامعتبر و تکراری نوبت #{batch_id}</b>", f"صفحه {page + 1} از {last_page + 1} · مجموع {len(errors)} مورد"]
    for kind, entry, value, reason in errors[page * page_size:(page + 1) * page_size]:
        lines.append(f"• <b>{escape(str(kind))}</b> · {escape(str(entry))}: <code>{escape(value[:70])}</code>\n  {escape(reason[:100])}")
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:discount:bulk:inputerrors:{batch_id}:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:discount:bulk:inputerrors:{batch_id}:{page+1}"))
    rows = [nav] if nav else []
    rows.append([InlineKeyboardButton(text="🔙 گزارش دریافت‌کنندگان", callback_data=f"admin:discount:bulk:report:{batch_id}:0")])
    await c.message.edit_text(limit_telegram_html("\n".join(lines)), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:bulk:summary:\d+$"))
async def admin_bulk_reward_summary(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    batch_id = int((c.data or "").rsplit(":", 1)[1])
    await _render_bulk_batch_preview(c, batch_id)
    await c.answer()


@router.callback_query(F.data == "admin:discounts")
async def admin_discount_menu(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text(
        "🎟 <b>مدیریت کدهای تخفیف</b>\n\n"
        "کد عادی: کاربر کد را وارد می‌کند و تخفیف بدون تأیید مدیر اعمال می‌شود.\n"
        "کد ویژه: کاربر کد را وارد می‌کند و درخواست تا تأیید مدیر منتظر می‌ماند.\n"
        "هدیه شخصی: فقط برای شناسه تلگرام مشخص ارسال می‌شود.\n\n"
        + code_format_help(),
        reply_markup=discount_manage_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:list:(active|inactive):\d+$"))
async def admin_discount_list(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    scope = parts[3]
    page = max(0, int(parts[4]))
    await _render_discount_list(c, scope, page)
    await c.answer()


@router.callback_query(F.data == "admin:discount:create:public")
@router.callback_query(F.data == "admin:discount:create:restricted")
async def admin_discount_start_public(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    kind = "restricted" if c.data.endswith("restricted") else "public"
    await state.clear()
    await state.update_data(discount_draft={"kind": kind, "selected_event_ids": []})
    await state.set_state(DiscountAdminStates.waiting_public_code)
    type_label = "ویژه – با تأیید مدیر" if kind == "restricted" else "عادی – بدون تأیید مدیر"
    await c.message.edit_text(
        f"➕ <b>ایجاد کد {type_label}</b>\n\n"
        + code_format_help() + "\n\nاکنون کد را وارد کنید؛ مقدار تخفیف از عدد انتهایی کد محاسبه می‌شود.",
        reply_markup=discount_cancel_keyboard(),
    )
    await c.answer()


@router.message(DiscountAdminStates.waiting_public_code, F.text)
async def admin_discount_receive_public_code(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    try:
        definition = parse_public_code_definition(m.text)
    except ValueError as exc:
        msg = "فرمت کد درست نیست. از حروف انگلیسی و عدد انتهایی استفاده کنید؛ برای مبلغ ثابت K بنویسید."
        if str(exc) == "VALUE":
            msg = "مقدار تخفیف معتبر نیست. درصد باید بین ۱ تا ۱۰۰ باشد؛ مبلغ ثابت نیز باید مثبت باشد."
        return await m.answer(msg + "\n\n" + code_format_help(), reply_markup=discount_cancel_keyboard())
    async with SessionLocal() as session:
        existing = (await session.execute(select(DiscountCode.id).where(DiscountCode.code == definition.canonical_code))).scalar_one_or_none()
    if existing:
        return await m.answer("این کد قبلاً ثبت شده است. نام دیگری وارد کنید یا کد قبلی را از فهرست مدیریت کنید.", reply_markup=discount_cancel_keyboard())
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    draft.update({
        "code": definition.canonical_code,
        "label": definition.canonical_code,
        "discount_type": definition.discount_type,
        "discount_value": str(definition.discount_value),
        "selected_event_ids": [],
    })
    await state.update_data(discount_draft=draft)
    await state.set_state(DiscountAdminStates.selecting_events)
    await _render_discount_event_picker(m, state, 0)


@router.callback_query(F.data == "admin:discount:create:personal")
async def admin_personal_reward_start(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await state.update_data(discount_draft={"kind": "personal", "selected_event_ids": []})
    await state.set_state(DiscountAdminStates.waiting_personal_telegram_id)
    await c.message.edit_text(
        "🎁 <b>ارسال هدیه شخصی</b>\n\nشناسهٔ عددی تلگرام برنده را وارد کنید. این هدیه فقط به همین حساب اختصاص می‌یابد.\n"
        "اگر کاربر هنوز ربات را شروع نکرده باشد، لینک قابل‌اشتراک در پایان نمایش داده می‌شود.",
        reply_markup=discount_cancel_keyboard(),
    )
    await c.answer()


@router.message(DiscountAdminStates.waiting_personal_telegram_id, F.text)
async def admin_personal_reward_receive_id(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    target_id = parse_telegram_numeric_id(m.text)
    if target_id is None:
        return await m.answer("شناسهٔ معتبر نیست. فقط عدد مثبت تلگرام را وارد کنید؛ مثال: <code>318109687</code>.", reply_markup=discount_cancel_keyboard())
    if target_id in settings.super_admin_id_set:
        return await m.answer("برای جلوگیری از تخصیص اشتباه، شناسهٔ مدیران را به‌عنوان برنده وارد نکنید.", reply_markup=discount_cancel_keyboard())
    async with SessionLocal() as session:
        blocked_target = await session.get(BlockedUser, target_id)
    if blocked_target:
        return await m.answer("این حساب در حال حاضر در ربات مسدود است؛ ابتدا وضعیت دسترسی را در مدیریت کاربران بررسی کنید.", reply_markup=discount_cancel_keyboard())
    draft = dict((await state.get_data()).get("discount_draft") or {})
    draft["recipient_telegram_id"] = target_id
    await state.update_data(discount_draft=draft)
    await state.set_state(DiscountAdminStates.waiting_personal_value)
    await m.answer(
        "میزان هدیه را وارد کنید: درصد مثل <code>100%</code> یا مبلغ ثابت با K مثل <code>100K</code> برای ۱۰۰٬۰۰۰ تومان.\n"
        "هدیه فقط یک‌بار و فقط برای یک پذیرش اعمال می‌شود.",
        reply_markup=discount_cancel_keyboard(),
    )


@router.message(DiscountAdminStates.waiting_personal_value, F.text)
async def admin_personal_reward_receive_value(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    try:
        discount_type, discount_value = parse_personal_discount_value(m.text)
    except ValueError:
        return await m.answer("مقدار نامعتبر است. مثال: <code>100%</code>، <code>80%</code> یا <code>100K</code>.", reply_markup=discount_cancel_keyboard())
    draft = dict((await state.get_data()).get("discount_draft") or {})
    draft.update({"discount_type": discount_type, "discount_value": str(discount_value), "selected_event_ids": []})
    await state.update_data(discount_draft=draft)
    await state.set_state(DiscountAdminStates.waiting_personal_reason)
    await m.answer(
        "علت این هدیه را کوتاه بنویسید؛ مثلاً «با تشکر از معرفی دوستان» یا «برندهٔ چالش». "
        "این توضیح همراه هدیه برای دریافت‌کننده ارسال می‌شود.",
        reply_markup=discount_cancel_keyboard(),
    )


@router.message(DiscountAdminStates.waiting_personal_reason, F.text, ~F.text.startswith("/"))
async def admin_personal_reward_receive_reason(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    reason = (m.text or "").strip()
    if not reason or len(reason) > 500:
        return await m.answer("لطفاً علت را در ۱ تا ۵۰۰ کاراکتر وارد کنید.", reply_markup=discount_cancel_keyboard())
    draft = dict((await state.get_data()).get("discount_draft") or {})
    if draft.get("kind") != "personal" or not draft.get("recipient_telegram_id"):
        await state.clear()
        return await m.answer("اطلاعات هدیه ناقص است؛ دوباره ساخت هدیه را شروع کنید.", reply_markup=discount_manage_keyboard())
    draft["reason"] = reason
    draft["selected_event_ids"] = []
    await state.update_data(discount_draft=draft)
    await state.set_state(DiscountAdminStates.selecting_events)
    await _render_discount_event_picker(m, state, 0)


@router.callback_query(F.data.regexp(r"^admin:discount:events:page:\d+$"))
async def admin_discount_event_page(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند انتخاب پنل منقضی شده است؛ دوباره ایجاد کد را شروع کنید.", show_alert=True)
    page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    await _render_discount_event_picker(c, state, page)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:events:select_all:\d+$"))
async def admin_discount_events_select_all(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند انتخاب پنل منقضی شده است.", show_alert=True)
    async with SessionLocal() as session:
        selectable_ids = sorted((await session.execute(select(Event.id).where(
            Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ).order_by(Event.id.desc()))).scalars().all())
    if not selectable_ids:
        return await c.answer("پنل واجد شرایطی برای انتخاب وجود ندارد.", show_alert=True)
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    draft["selected_event_ids"] = [int(event_id) for event_id in selectable_ids]
    await state.update_data(discount_draft=draft)
    page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    await _render_discount_event_picker(c, state, page)
    await c.answer(f"همهٔ {len(selectable_ids)} پنل فعلی انتخاب شدند.")


@router.callback_query(F.data.regexp(r"^admin:discount:events:clear:\d+$"))
async def admin_discount_events_clear(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند انتخاب پنل منقضی شده است.", show_alert=True)
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    draft["selected_event_ids"] = []
    await state.update_data(discount_draft=draft)
    page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    await _render_discount_event_picker(c, state, page)
    await c.answer("همهٔ انتخاب‌ها پاک شد.")


@router.callback_query(F.data.regexp(r"^admin:discount:event:toggle:\d+:\d+$"))
async def admin_discount_event_toggle(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند انتخاب پنل منقضی شده است.", show_alert=True)
    parts = (c.data or "").split(":")
    event_id, page = int(parts[-2]), max(0, int(parts[-1]))
    async with SessionLocal() as session:
        event = await session.get(Event, event_id)
        if not event or event.archived or event.status not in (EventStatus.DRAFT, EventStatus.PUBLISHED):
            return await c.answer("این پنل دیگر برای کد تخفیف قابل انتخاب نیست.", show_alert=True)
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    selected = {int(x) for x in draft.get("selected_event_ids", [])}
    if event_id in selected:
        selected.remove(event_id)
    else:
        selected.add(event_id)
    draft["selected_event_ids"] = sorted(selected)
    await state.update_data(discount_draft=draft)
    await _render_discount_event_picker(c, state, page)
    await c.answer("انتخاب به‌روزرسانی شد.")


async def _apply_discount_code_edit(session, *, code_id: int, event_ids: list[int], max_uses: int | None, usage_policy: str, commit: bool = True):
    """Update scope/settings; production handler includes audit entry before committing."""
    return await reactivate_inactive_discount_code(
        session,
        code_id=code_id,
        event_ids=event_ids,
        max_redemptions=max_uses,
        usage_policy=usage_policy,
        commit=commit,
    )

async def _persist_discount_code(c: CallbackQuery, state: FSMContext, *, max_uses: int | None, usage_policy: str = "once_total"):
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    event_ids = sorted({int(x) for x in draft.get("selected_event_ids", [])})
    if not event_ids:
        return await c.answer("حداقل یک پنل را انتخاب کنید.", show_alert=True)
    kind = draft.get("kind")
    if kind not in ("public", "restricted", "personal"):
        await state.clear()
        return await c.answer("اطلاعات کد ناقص است؛ دوباره ایجاد را شروع کنید.", show_alert=True)
    if kind != "personal" and not draft.get("code"):
        return await c.answer("کد وارد نشده است؛ دوباره ایجاد کد را شروع کنید.", show_alert=True)
    recipient_id = int(draft["recipient_telegram_id"]) if kind == "personal" else None
    discount_type = str(draft["discount_type"])
    discount_value = Decimal(str(draft["discount_value"]))
    code_label_value = draft.get("code") or (f"هدیه {int(discount_value)}٪" if discount_type == "percent" else f"هدیه {int(discount_value):,} تومان")
    async with SessionLocal() as session:
        event_rows = (await session.execute(select(Event).where(
            Event.id.in_(event_ids), Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ))).scalars().all()
        valid_ids = {int(event.id) for event in event_rows}
        if valid_ids != set(event_ids):
            return await c.answer("یکی از پنل‌های انتخاب‌شده دیگر قابل استفاده نیست؛ فهرست را تازه کنید.", show_alert=True)
        edit_code_id = data.get("discount_edit_code_id")
        if edit_code_id is not None:
            try:
                code, event_rows = await _apply_discount_code_edit(
                    session, code_id=int(edit_code_id), event_ids=event_ids,
                    max_uses=max_uses, usage_policy=usage_policy, commit=False,
                )
            except ValueError as exc:
                messages = {
                    "NOT_EDITABLE": "این کد دیگر قابل ویرایش نیست؛ فهرست کدهای غیرفعال را تازه کنید.",
                    "INVALID_EVENTS": "یکی از پنل‌های انتخاب‌شده دیگر قابل استفاده نیست؛ فهرست را تازه کنید.",
                    "LIMIT_BELOW_USAGE": "سقف جدید از تعداد استفاده‌ها/درخواست‌های قبلی کمتر است. سقف بالاتری انتخاب کنید یا بدون محدودیت فعال کنید.",
                }
                return await c.answer(messages.get(str(exc), "ویرایش کد انجام نشد."), show_alert=True)
            event_summary = [_discount_event_label(e) for e in event_rows]
            code_label_value = code.code or code.label
            code_value = discount_display(code)
            await write_admin_action(session, actor_telegram_id=c.from_user.id, action="discount_code_updated_and_activated", entity_type="discount_code", entity_id=int(code.id), details={"event_ids": event_ids, "max_redemptions": max_uses, "usage_policy": usage_policy})
            await session.commit()
            await state.clear()
            await c.message.edit_text(
                f"✅ <b>کد غیرفعال ویرایش و دوباره فعال شد</b>\n\n"
                f"کد: <code>{escape(code_label_value)}</code>\nتخفیف: <b>{escape(code_value)}</b>\n"
                f"سقف کل استفاده: {max_uses if max_uses is not None else 'بدون محدودیت'}\n"
                f"سیاست استفاده: {'یک‌بار در مجموع برای هر کاربر' if usage_policy == 'once_total' else 'یک‌بار در هر پنل برای هر کاربر'}\n"
                f"پنل‌های مجاز: {escape(', '.join(event_summary))}",
                reply_markup=discount_manage_keyboard(),
            )
            await c.answer("کد دوباره فعال شد.")
            return
        if kind != "personal":
            exists = (await session.execute(select(DiscountCode.id).where(DiscountCode.code == draft["code"]))).scalar_one_or_none()
            if exists is not None:
                return await c.answer("این کد قبلاً ساخته شده است؛ کد دیگری انتخاب کنید.", show_alert=True)
        else:
            overlap = (await session.execute(
                select(DiscountCode.id).join(
                    DiscountCodeEvent, DiscountCodeEvent.discount_code_id == DiscountCode.id
                ).where(
                    DiscountCode.kind == "personal",
                    DiscountCode.active.is_(True),
                    DiscountCode.recipient_telegram_id == recipient_id,
                    DiscountCodeEvent.event_id.in_(event_ids),
                ).limit(1)
            )).scalar_one_or_none()
            if overlap is not None:
                return await c.answer(
                    "برای این حساب و یکی از پنل‌های انتخاب‌شده، هدیه فعال دیگری وجود دارد. "
                    "ابتدا هدیه قبلی را غیرفعال کنید یا پنل‌های دیگری انتخاب کنید.",
                    show_alert=True,
                )
        code = DiscountCode(
            code=draft.get("code"), label=code_label_value, kind=kind,
            discount_type=discount_type, discount_value=discount_value,
            requires_approval=(kind == "restricted"), active=True,
            max_redemptions=(1 if kind == "personal" else max_uses),
            usage_policy=("once_total" if kind == "personal" else usage_policy),
            recipient_telegram_id=recipient_id, created_by_telegram_id=int(c.from_user.id),
            reason=(str(draft.get("reason") or "").strip() or None) if kind == "personal" else None,
            created_at=utc_now_naive(),
        )
        session.add(code)
        await session.flush()
        for event_id in event_ids:
            session.add(DiscountCodeEvent(discount_code_id=code.id, event_id=event_id))
        await write_admin_action(session, actor_telegram_id=c.from_user.id, action="personal_reward_created" if kind == "personal" else "discount_code_created", entity_type="discount_code", entity_id=int(code.id), details={"kind": kind, "recipient_telegram_id": recipient_id, "discount_type": discount_type, "discount_value": str(discount_value), "event_ids": event_ids})
        await session.commit()
        await session.refresh(code)
        code_id = int(code.id)
        event_summary = [_discount_event_label(e) for e in event_rows]
    await state.clear()

    if kind == "personal":
        bot_username = None
        try:
            me = await c.bot.me()
            bot_username = me.username
        except Exception:
            logger.exception("Could not obtain bot username for personal reward deep link")
        deep_link = f"https://t.me/{bot_username}?start=reward_{code_id}" if bot_username else None
        try:
            await c.bot.send_message(
                recipient_id,
                f"🎁 <b>یک هدیه ویژه برای شما!</b>\n\n"
                f"میزان تخفیف: <b>{escape(discount_display(code))}</b>\n"
                + (f"علت هدیه: {escape(code.reason)}\n" if code.reason else "")
                + "پنل‌های مجاز:\n" + "\n".join(f"• {escape(x)}" for x in event_summary[:8])
                + (f"\nو {len(event_summary) - 8} پنل دیگر" if len(event_summary) > 8 else "")
                + "\n\nاین هدیه فقط در پنل‌های فهرست‌شده قابل استفاده است. برای استفاده، هدیه را بپذیرید و خودتان رزروکننده باشید. هدیه صندلی را پیشاپیش رزرو نمی‌کند و در ثبت‌نام چندنفره فقط هزینهٔ یک نفر را پوشش می‌دهد.",
                reply_markup=personal_reward_keyboard(code_id),
            )
            delivery = "✅ پیام هدیه مستقیماً ارسال شد."
        except Exception:
            logger.info("Could not directly deliver personal reward id=%s to telegram_id=%s", code_id, recipient_id, exc_info=True)
            delivery = "⚠️ ربات نتوانست پیام خصوصی را ارسال کند؛ احتمالاً کاربر هنوز ربات را شروع نکرده است. لینک زیر را شخصاً برای او بفرستید."
        extra_link = f"\nلینک هدیه: {deep_link}" if deep_link else "\nنام کاربری ربات در دسترس نبود؛ لینک را از طریق ربات بررسی کنید."
        await c.message.edit_text(
            f"🎁 <b>هدیه شخصی ساخته شد</b>\nشناسه دریافت‌کننده: <code>{recipient_id}</code>\n"
            f"تخفیف: {escape(discount_display(code))}\n"
            + (f"علت: {escape(code.reason)}\n" if code.reason else "")
            + f"پنل‌ها: {escape(', '.join(event_summary))}\n{delivery}{escape(extra_link)}",
            reply_markup=discount_manage_keyboard(),
        )
    else:
        scope_text = "ویژه – با تأیید مدیر" if kind == "restricted" else "عادی – بدون تأیید مدیر"
        await c.message.edit_text(
            f"✅ <b>کد تخفیف ساخته شد</b>\n\nکد: <code>{escape(code.code or '')}</code>\n"
            f"تخفیف: <b>{escape(discount_display(code))}</b>\nنوع: {scope_text}\n"
            f"سیاست استفاده: {'یک‌بار در مجموع برای هر کاربر' if usage_policy == 'once_total' else 'یک‌بار در هر پنل برای هر کاربر'}\n"
            f"سقف کل استفاده: {max_uses if max_uses is not None else 'بدون محدودیت'}\n"
            f"پنل‌های مجاز: {escape(', '.join(event_summary))}\n\n"
            "کد را دقیقاً با همین املای انگلیسی روی پوستر اعلام کنید. هر زمان خواستید می‌توانید آن را غیرفعال کنید.",
            reply_markup=discount_manage_keyboard(),
        )
    await c.answer("ذخیره شد.")


@router.callback_query(F.data == "admin:discount:events:done")
async def admin_discount_events_done(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند انتخاب پنل منقضی شده است.", show_alert=True)
    data = await state.get_data()
    draft = dict(data.get("discount_draft") or {})
    if not draft.get("selected_event_ids"):
        return await c.answer("حداقل یک پنل را انتخاب کنید.", show_alert=True)
    if draft.get("kind") == "personal":
        return await _persist_discount_code(c, state, max_uses=1, usage_policy="once_total")
    if draft.get("kind") == "personal_bulk":
        return await _create_bulk_reward_preview(c, state)
    selected_ids = sorted({int(x) for x in draft.get("selected_event_ids", [])})
    if len(selected_ids) == 1:
        # With only one panel, once_total and once_per_panel are equivalent.
        # Skip the redundant question and move directly to the global cap.
        await state.update_data(discount_usage_policy="once_total")
        await c.message.edit_text(
            "🔢 <b>سقف استفادهٔ کلی</b>\n\n"
            "این سقف بین همهٔ کاربران و پنل‌های انتخاب‌شده مشترک است و تعداد رزروها را می‌شمارد، نه تعداد نفرات را.\n"
            "مثلاً ۱۰ یعنی حداکثر ۱۰ رزرو در مجموع؛ رزرو سه‌نفره هم یک استفاده حساب می‌شود.\n"
            "برای نامحدود بودن، گزینهٔ «بدون محدودیت کلی» را انتخاب کنید.",
            reply_markup=discount_max_uses_keyboard(),
        )
    else:
        await c.message.edit_text(
            "🔐 <b>دفعات استفاده برای هر کاربر</b>\n\n"
            "یک‌بار در مجموع: هر حساب فقط در یکی از پنل‌های انتخاب‌شده از کد استفاده می‌کند.\n"
            "یک‌بار در هر پنل: هر حساب می‌تواند در هر پنل انتخاب‌شده یک‌بار از کد استفاده کند.\n\n"
            "سقف کلیِ همهٔ استفاده‌ها را در مرحلهٔ بعد تعیین می‌کنید.",
            reply_markup=discount_usage_policy_keyboard(),
        )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:policy:(once_total|once_per_panel)$"))
async def admin_discount_set_policy(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    data = await state.get_data()
    if await state.get_state() != DiscountAdminStates.selecting_events.state or not data.get("discount_draft"):
        return await c.answer("فرآیند ایجاد کد منقضی شده است.", show_alert=True)
    policy = (c.data or "").rsplit(":", 1)[1]
    await state.update_data(discount_usage_policy=policy)
    await c.message.edit_text(
        "🔢 <b>سقف استفادهٔ کلی</b>\n\n"
        "این سقف بین همهٔ کاربران و پنل‌های انتخاب‌شده مشترک است و تعداد رزروها را می‌شمارد، نه تعداد نفرات.\n"
        "مثلاً ۲۰ یعنی حداکثر ۲۰ رزرو در مجموع؛ رزرو سه‌نفره هم یک استفاده حساب می‌شود. رزروها/درخواست‌های در انتظار و تأییدشده ظرفیت را اشغال می‌کنند؛ درخواست ردشده نمی‌کند.\n\n"
        "برای نامحدود بودن، گزینهٔ «بدون محدودیت کلی» را انتخاب کنید.",
        reply_markup=discount_max_uses_keyboard(),
    )
    await c.answer()


@router.callback_query(F.data == "admin:discount:max:unlimited")
async def admin_discount_max_unlimited(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    data = await state.get_data()
    if not data.get("discount_draft") or await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند ایجاد کد منقضی شده است.", show_alert=True)
    policy = data.get("discount_usage_policy", "once_total")
    return await _persist_discount_code(c, state, max_uses=None, usage_policy=policy)


@router.callback_query(F.data == "admin:discount:max:limited")
async def admin_discount_max_limited(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    if await state.get_state() != DiscountAdminStates.selecting_events.state:
        return await c.answer("فرآیند ایجاد کد منقضی شده است.", show_alert=True)
    await state.set_state(DiscountAdminStates.waiting_max_uses)
    await c.message.edit_text(
        "🔢 <b>سقف استفادهٔ کلی</b>\n\n"
        "این عدد حداکثر تعداد رزروهایی است که می‌توانند از کد در مجموعِ همهٔ پنل‌های انتخاب‌شده استفاده کنند؛ سقف جداگانه برای هر پنل نیست و تعداد نفرات را هم نمی‌شمارد.\n"
        "مثلاً ۱۰ یعنی حداکثر ۱۰ رزرو در مجموع؛ رزرو سه‌نفره یک استفاده حساب می‌شود.\n"
        "عدد صحیحی بین ۱ تا ۱٬۰۰۰٬۰۰۰ وارد کنید.",
        reply_markup=discount_cancel_keyboard(),
    )
    await c.answer()


@router.message(DiscountAdminStates.waiting_max_uses, F.text)
async def admin_discount_receive_max_uses(m: Message, state: FSMContext):
    if not await is_admin(m.from_user.id):
        await state.clear()
        return await m.answer("دسترسی مجاز نیست.")
    maximum = parse_integer(m.text, minimum=1, maximum=1_000_000)
    if maximum is None:
        return await m.answer("سقف استفاده باید عدد صحیحی بین ۱ تا ۱٬۰۰۰٬۰۰۰ باشد؛ عدد ۲۰ فقط یک مثال است.", reply_markup=discount_cancel_keyboard())
    data = await state.get_data()
    policy = data.get("discount_usage_policy", "once_total")
    # Persist via a short-lived callback-compatible object adapter isn't safe; create
    # directly here after revalidating every selected panel and code uniqueness.
    draft = dict(data.get("discount_draft") or {})
    if not draft or draft.get("kind") not in ("public", "restricted"):
        await state.clear()
        return await m.answer("اطلاعات کد ناقص است؛ دوباره ایجاد کد را شروع کنید.", reply_markup=discount_manage_keyboard())
    event_ids = sorted({int(x) for x in draft.get("selected_event_ids", [])})
    async with SessionLocal() as session:
        valid_ids = set((await session.execute(select(Event.id).where(
            Event.id.in_(event_ids), Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED))
        ))).scalars().all())
        if valid_ids != set(event_ids):
            return await m.answer("یکی از پنل‌های انتخاب‌شده دیگر قابل استفاده نیست. گفت‌وگو را لغو کنید و دوباره اقدام کنید.", reply_markup=discount_cancel_keyboard())
        edit_code_id = data.get("discount_edit_code_id")
        if edit_code_id is not None:
            try:
                code, event_rows = await _apply_discount_code_edit(
                    session, code_id=int(edit_code_id), event_ids=event_ids,
                    max_uses=maximum, usage_policy=policy, commit=False,
                )
            except ValueError as exc:
                messages = {
                    "NOT_EDITABLE": "این کد دیگر قابل ویرایش نیست؛ دوباره فهرست کدهای غیرفعال را باز کنید.",
                    "INVALID_EVENTS": "یکی از پنل‌های انتخاب‌شده دیگر قابل استفاده نیست. فهرست را تازه کنید.",
                    "LIMIT_BELOW_USAGE": "سقف جدید از تعداد استفاده‌ها/درخواست‌های قبلی کمتر است. سقف بالاتری انتخاب کنید یا بدون محدودیت را انتخاب کنید.",
                }
                return await m.answer(messages.get(str(exc), "ویرایش کد انجام نشد."), reply_markup=discount_cancel_keyboard())
            label = code.code or code.label
            value = discount_display(code)
            events_text = ", ".join(f"{volume_label(event.volume)} — {event.title}" for event in event_rows)
            await write_admin_action(session, actor_telegram_id=m.from_user.id, action="discount_code_updated_and_activated", entity_type="discount_code", entity_id=int(code.id), details={"event_ids": event_ids, "max_redemptions": maximum, "usage_policy": policy})
            await session.commit()
            await state.clear()
            return await m.answer(
                f"✅ <b>کد غیرفعال ویرایش و دوباره فعال شد</b>\n\nکد: <code>{escape(label)}</code>\n"
                f"تخفیف: {escape(value)}\nسقف کل استفاده: {maximum}\n"
                f"سیاست استفاده: {'یک‌بار در مجموع برای هر کاربر' if policy == 'once_total' else 'یک‌بار در هر پنل برای هر کاربر'}\n"
                f"پنل‌های مجاز: {escape(events_text)}",
                reply_markup=discount_manage_keyboard(),
            )
        if (await session.execute(select(DiscountCode.id).where(DiscountCode.code == draft.get("code")))).scalar_one_or_none() is not None:
            await state.clear()
            return await m.answer("این کد قبلاً ساخته شده است. کد دیگری انتخاب کنید.", reply_markup=discount_manage_keyboard())
        code = DiscountCode(
            code=draft["code"], label=draft["code"], kind=draft["kind"],
            discount_type=draft["discount_type"], discount_value=Decimal(str(draft["discount_value"])),
            requires_approval=draft["kind"] == "restricted", active=True,
            max_redemptions=maximum, usage_policy=policy,
            created_by_telegram_id=int(m.from_user.id), created_at=utc_now_naive(),
        )
        session.add(code)
        await session.flush()
        event_rows = (await session.execute(select(Event).where(Event.id.in_(event_ids)))).scalars().all()
        for event_id in event_ids:
            session.add(DiscountCodeEvent(discount_code_id=code.id, event_id=event_id))
        await write_admin_action(session, actor_telegram_id=m.from_user.id, action="discount_code_created", entity_type="discount_code", entity_id=int(code.id), details={"kind": draft["kind"], "discount_type": draft["discount_type"], "discount_value": str(draft["discount_value"]), "event_ids": event_ids})
        await session.commit()
        label = code.code
        value = discount_display(code)
        events_text = ", ".join(f"{volume_label(event.volume)} — {event.title}" for event in event_rows)
    await state.clear()
    await m.answer(
        f"✅ <b>کد تخفیف ساخته شد</b>\n\nکد: <code>{escape(label)}</code>\nتخفیف: {escape(value)}\n"
        f"سقف کل استفاده: {maximum}\nسیاست استفاده: {'یک‌بار در مجموع برای هر کاربر' if policy == 'once_total' else 'یک‌بار در هر پنل برای هر کاربر'}\n"
        f"پنل‌های مجاز: {escape(events_text)}\n\nکد را دقیقاً با همین املای انگلیسی اعلام کنید.",
        reply_markup=discount_manage_keyboard(),
    )


@router.callback_query(F.data.regexp(r"^admin:discount:code:view:\d+:\d+:(active|inactive)$"))
async def admin_discount_code_view(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    code_id, page, scope = int(parts[4]), int(parts[5]), parts[6]
    async with SessionLocal() as session:
        code = await session.get(DiscountCode, code_id)
        if not code:
            return await c.answer("کد پیدا نشد.", show_alert=True)
        events = (await session.execute(select(Event).join(
            DiscountCodeEvent, DiscountCodeEvent.event_id == Event.id
        ).where(DiscountCodeEvent.discount_code_id == code_id).order_by(Event.id.desc()))).scalars().all()
        status_counts = (await session.execute(
            select(DiscountRedemption.status, func.count(DiscountRedemption.id))
            .where(DiscountRedemption.discount_code_id == code_id)
            .group_by(DiscountRedemption.status)
        )).all()
        occupied, redeemed, pending, approved = summarize_redemption_counts(status_counts)
    event_lines = "\n".join(f"• {volume_label(e.volume)} — {escape(e.title)} ({admin_status_display_label('draft' if e.status == EventStatus.DRAFT else e.status)})" for e in events) or "پنل واجد شرایطی باقی نمانده است."
    body = (
        f"🎟 <b>{escape(code.code or code.label)}</b>\n\n"
        f"نوع: {escape({'public':'عادی – بدون تأیید مدیر','restricted':'ویژه – با تأیید مدیر','personal':'هدیه شخصی'}.get(code.kind, code.kind))}\n"
        f"تخفیف: <b>{escape(discount_display(code))}</b>\n"
        + (f"علت هدیه: {escape(code.reason)}\n" if code.reason else "")
        + f"وضعیت: {'فعال' if code.active else 'غیرفعال'}\n"
        f"سقف کلی: {code.max_redemptions if code.max_redemptions is not None else 'بدون محدودیت'}\n"
        f"سیاست استفاده: {'یک‌بار در مجموع برای هر کاربر' if code.usage_policy == 'once_total' else 'یک‌بار در هر پنل برای هر کاربر'}\n"
        f"سهمیه اشغال‌شده: {occupied}/{code.max_redemptions if code.max_redemptions is not None else 'بدون محدودیت'}\n"
        f"استفاده نهایی‌شده: {redeemed} | در انتظار بررسی مدیر: {pending} | تأییدشده، منتظر ادامه کاربر: {approved}\n"
        + (f"دریافت‌کننده: <code>{code.recipient_telegram_id}</code>\n" if code.recipient_telegram_id else "")
        + f"\n<b>پنل‌های انتخاب‌شده</b>\n{event_lines}"
    )
    rows = []
    if code.active:
        rows.append([InlineKeyboardButton(text="⛔ غیرفعال کردن کد", callback_data=f"admin:discount:disable:{code.id}")])
    elif code.kind in ("public", "restricted"):
        rows.append([InlineKeyboardButton(
            text="✏️ ویرایش پنل‌ها و سقف استفاده، سپس فعال‌سازی",
            callback_data=f"admin:discount:edit:{code.id}",
        )])
    elif events and not redeemed:
        rows.append([InlineKeyboardButton(text="✅ فعال‌سازی دوباره", callback_data=f"admin:discount:enable:confirm:{code.id}")])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به فهرست", callback_data=f"admin:discount:list:{scope}:{page}")])
    rows.append([InlineKeyboardButton(text="🏠 مدیریت کدهای تخفیف", callback_data="admin:discounts")])
    await c.message.edit_text(limit_telegram_html(body), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:edit:\d+$"))
async def admin_discount_edit_start(c: CallbackQuery, state: FSMContext):
    """Reconfigure a disabled public/restricted code before reactivating it."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    code_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        code = await session.get(DiscountCode, code_id, with_for_update=True)
        if not code:
            return await c.answer("کد پیدا نشد.", show_alert=True)
        if code.active:
            return await c.answer("این کد فعال است؛ ابتدا آن را غیرفعال کنید.", show_alert=True)
        if code.kind not in ("public", "restricted"):
            return await c.answer("ویرایش دوباره فقط برای کدهای عادی و ویژه انجام می‌شود؛ هدیه شخصی به گیرنده و پنل اولیه وابسته است.", show_alert=True)
        eligible_events = (await session.execute(
            select(Event).join(DiscountCodeEvent, DiscountCodeEvent.event_id == Event.id).where(
                DiscountCodeEvent.discount_code_id == code_id,
                Event.archived.is_(False),
                Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED)),
            )
        )).scalars().all()
        selected_ids = [int(event.id) for event in eligible_events]
        code_payload = {
            "kind": code.kind,
            "code": code.code,
            "label": code.label,
            "discount_type": code.discount_type,
            "discount_value": str(code.discount_value),
            "selected_event_ids": selected_ids,
        }
    await state.clear()
    await state.update_data(discount_draft=code_payload, discount_edit_code_id=code_id)
    await state.set_state(DiscountAdminStates.selecting_events)
    await _render_discount_event_picker(c, state, 0)
    await c.answer("پنل‌ها را انتخاب کنید.")


@router.callback_query(F.data == "admin:discount:clear-inactive:start")
async def admin_discount_clear_inactive_start(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    async with SessionLocal() as session:
        inactive_ids = select(DiscountCode.id).where(DiscountCode.active.is_(False))
        code_count = int((await session.execute(select(func.count(DiscountCode.id)).where(
            DiscountCode.active.is_(False)
        ))).scalar_one())
        redemption_count = int((await session.execute(select(func.count(DiscountRedemption.id)).where(
            DiscountRedemption.discount_code_id.in_(inactive_ids)
        ))).scalar_one()) if code_count else 0
    if not code_count:
        return await c.answer("کد غیرفعالی برای پاک‌سازی وجود ندارد.", show_alert=True)
    await c.message.edit_text(
        "⚠️ <b>پاک‌سازی کامل کدهای غیرفعال</b>\n\n"
        f"تعداد کدهایی که برای همیشه حذف می‌شوند: <b>{code_count}</b>\n"
        f"سوابق درخواست و استفاده‌ای که حذف می‌شوند: <b>{redemption_count}</b>\n\n"
        "کدهای غیرفعال و تمام سوابق مرتبط با آن‌ها از پایگاه داده حذف می‌شوند. "
        "رزروها، وضعیت پرداخت و مبلغ ثبت‌شدهٔ رزروها حفظ می‌شوند.\n\n"
        "این عملیات قابل بازگشت نیست. آیا ادامه می‌دهید؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🗑 بله، همه کدهای غیرفعال حذف شوند", callback_data="admin:discount:clear-inactive:confirm")],
            [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discount:list:inactive:0")],
        ]),
    )
    await c.answer()


@router.callback_query(F.data == "admin:discount:clear-inactive:confirm")
async def admin_discount_clear_inactive_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    pending_requests = []
    try:
        async with SessionLocal() as session:
            # Lock the exact inactive set before collecting notices so a concurrent
            # reactivation cannot be reported as deleted when it was actually kept.
            inactive_ids = [int(value) for value in (await session.execute(
                select(DiscountCode.id).where(DiscountCode.active.is_(False)).with_for_update()
            )).scalars().all()]
            pending = (await session.execute(select(DiscountRedemption).where(
                DiscountRedemption.discount_code_id.in_(inactive_ids),
                DiscountRedemption.status == "pending",
            ))).scalars().all() if inactive_ids else []
            for item in pending:
                pending_requests.append((
                    int(item.user_telegram_id), int(item.request_message_id or 0),
                    str(item.code_snapshot or "کد تخفیف"), str(item.event_label_snapshot or "پنل انتخاب‌شده"),
                ))
            deleted_codes, deleted_redemptions = await purge_inactive_discount_codes(session)
            await session.commit()
    except Exception:
        logger.exception("Failed to purge inactive discount codes", extra={"admin_id": c.from_user.id})
        return await c.answer("پاک‌سازی انجام نشد؛ اطلاعات تغییری نکرده است. دوباره تلاش کنید.", show_alert=True)

    for telegram_id, request_message_id, code_name, event_name in pending_requests:
        notice = (
            f"⚠️ درخواست تخفیف <b>{escape(code_name)}</b> برای <b>{escape(event_name)}</b> "
            "به دلیل حذف کد غیرفعال دیگر قابل پیگیری نیست. صندلی‌ای رزرو نشده بود؛ "
            "در صورت تمایل می‌توانید از پنل دوباره و با قیمت عادی ثبت‌نام کنید."
        )
        delivered = False
        if request_message_id:
            try:
                await c.bot.edit_message_text(
                    chat_id=telegram_id, message_id=request_message_id, text=notice,
                    disable_web_page_preview=True,
                )
                delivered = True
            except Exception:
                logger.info("Could not update pending request after inactive-code purge; telegram_id=%s", telegram_id, exc_info=True)
        if not delivered:
            try:
                await c.bot.send_message(telegram_id, notice, disable_web_page_preview=True)
            except Exception:
                logger.info("Could not notify user after inactive-code purge; telegram_id=%s", telegram_id, exc_info=True)

    await c.message.edit_text(
        f"✅ پاک‌سازی انجام شد.\nکدهای حذف‌شده: {deleted_codes}\nسوابق درخواست/استفاده حذف‌شده: {deleted_redemptions}\n\n"
        "رزروها و وضعیت‌های پرداخت حفظ شدند.",
        reply_markup=discount_manage_keyboard(),
    )
    await c.answer("پاک‌سازی انجام شد.")


@router.callback_query(F.data.regexp(r"^admin:discount:disable:\d+$"))
async def admin_discount_disable_start(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    code_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        code = await session.get(DiscountCode, code_id)
    if not code or not code.active:
        return await c.answer("این کد از قبل غیرفعال است یا وجود ندارد.", show_alert=True)
    await c.message.edit_text(
        f"آیا کد <code>{escape(code.code or code.label)}</code> غیرفعال شود؟\n"
        "کاربران دیگر نمی‌توانند آن را استفاده کنند. درخواست‌های در انتظار نیز با امکان ادامه با قیمت عادی رد می‌شوند؛ سوابق قبلی باقی می‌ماند.",
        reply_markup=admin_discount_disable_keyboard(code_id),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:disable:confirm:\d+$"))
async def admin_discount_disable_confirm(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    code_id = int((c.data or "").rsplit(":", 1)[1])
    notify: list[tuple[int, int]] = []
    async with SessionLocal() as session:
        code = await session.get(DiscountCode, code_id, with_for_update=True)
        if not code:
            return await c.answer("کد پیدا نشد.", show_alert=True)
        code_label_value = code.code or code.label
        if code.active:
            code.active = False
            code.disabled_at = utc_now_naive()
            code.disabled_reason = "Disabled manually by admin"
            requests = (await session.execute(select(DiscountRedemption).where(
                DiscountRedemption.discount_code_id == code_id,
                DiscountRedemption.status.in_(("pending", "approved")),
            ).with_for_update())).scalars().all()
            for item in requests:
                item.status = "rejected"
                item.reviewed_by_telegram_id = int(c.from_user.id)
                item.reviewed_at = utc_now_naive()
                item.updated_at = utc_now_naive()
                notify.append((int(item.user_telegram_id), int(item.id)))
            await write_admin_action(session, actor_telegram_id=c.from_user.id, action="discount_code_deactivated", entity_type="discount_code", entity_id=code_id, details={"code": code_label_value, "pending_requests_rejected": len(notify)})
        await session.commit()
    for telegram_id, item_id in notify:
        try:
            await c.bot.send_message(
                telegram_id,
                f"⚠️ کد تخفیف <b>{escape(code_label_value)}</b> غیرفعال شد و درخواست تخفیف قابل تأیید نیست.\n"
                "می‌توانید با قیمت عادی ادامه دهید یا ثبت‌نام را لغو کنید.",
                reply_markup=discount_request_user_keyboard(item_id),
            )
        except Exception:
            logger.info("Could not notify user after disabling discount code; code_id=%s redemption_id=%s", code_id, item_id, exc_info=True)
    await c.message.edit_text("✅ کد غیرفعال شد؛ سوابق آن حفظ شده است.", reply_markup=discount_manage_keyboard())
    await c.answer("کد غیرفعال شد.")


@router.callback_query(F.data.regexp(r"^admin:discount:enable:confirm:\d+$"))
async def admin_discount_enable(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    code_id = int((c.data or "").rsplit(":", 1)[1])
    async with SessionLocal() as session:
        code = await session.get(DiscountCode, code_id, with_for_update=True)
        if not code:
            return await c.answer("کد پیدا نشد.", show_alert=True)
        if code.kind in ("public", "restricted"):
            return await c.answer("برای فعال‌سازی دوبارهٔ کدهای عادی و ویژه، از جزئیات کد گزینهٔ «ویرایش پنل‌ها و سقف استفاده، سپس فعال‌سازی» را انتخاب کنید.", show_alert=True)
        eligible = int((await session.execute(select(func.count(DiscountCodeEvent.id)).join(
            Event, Event.id == DiscountCodeEvent.event_id
        ).where(DiscountCodeEvent.discount_code_id == code_id, Event.archived.is_(False), Event.status.in_((EventStatus.DRAFT, EventStatus.PUBLISHED)) ))).scalar_one())
        if not eligible:
            return await c.answer("برای فعال‌سازی، ابتدا یک پنل واجد شرایط به کد اضافه کنید.", show_alert=True)
        if code.kind == "personal" and code.recipient_telegram_id is None:
            return await c.answer("هدیه شخصی گیرنده معتبر ندارد و قابل فعال‌سازی نیست.", show_alert=True)
        if code.kind == "personal" and (await session.execute(select(DiscountRedemption.id).where(
            DiscountRedemption.discount_code_id == code_id, DiscountRedemption.status == "redeemed"
        ).limit(1))).scalar_one_or_none() is not None:
            return await c.answer("هدیه شخصی قبلاً مصرف شده و قابل فعال‌سازی مجدد نیست.", show_alert=True)
        was_active = bool(code.active)
        code.active = True
        code.disabled_at = None
        code.disabled_reason = None
        if not was_active:
            await write_admin_action(session, actor_telegram_id=c.from_user.id, action="personal_reward_activated" if code.kind == "personal" else "discount_code_activated", entity_type="discount_code", entity_id=code_id, details={"kind": code.kind, "recipient_telegram_id": code.recipient_telegram_id})
        await session.commit()
    await c.message.edit_text("✅ کد دوباره فعال شد.", reply_markup=discount_manage_keyboard())
    await c.answer()


async def _render_discount_requests(c: CallbackQuery, page: int = 0):
    async with SessionLocal() as session:
        total = int((await session.execute(select(func.count(DiscountRedemption.id)).where(DiscountRedemption.status == "pending"))).scalar_one())
        last_page = max(0, (total - 1) // DISCOUNT_PAGE_SIZE)
        page = min(max(0, page), last_page)
        items = (await session.execute(
            select(DiscountRedemption, User).outerjoin(User, User.telegram_id == DiscountRedemption.user_telegram_id)
            .where(DiscountRedemption.status == "pending")
            .order_by(DiscountRedemption.created_at.asc(), DiscountRedemption.id.asc())
            .offset(page * DISCOUNT_PAGE_SIZE).limit(DISCOUNT_PAGE_SIZE)
        )).all()
    if not items:
        await c.message.edit_text("🎟 <b>درخواست‌های تخفیف</b>\n\n✅ درخواست در انتظار بررسی ندارید.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")],
            [InlineKeyboardButton(text="🏠 منوی مدیریت", callback_data="admin:home")],
        ]))
        return
    rows = []
    lines = [f"🎟 <b>درخواست‌های تخفیف</b> — صفحه {page+1}/{last_page+1}", ""]
    for redemption, user in items:
        name = (getattr(user, "display_name", None) or " ".join(x for x in [getattr(user, "first_name", None), getattr(user, "last_name", None)] if x) or "کاربر ناشناس") if user else "کاربر ناشناس"
        code = escape(redemption.code_snapshot or "کد")
        lines.append(f"• {escape(name)} | {escape(redemption.event_label_snapshot)} | <code>{code}</code>")
        rows.append([InlineKeyboardButton(text=f"🔎 {name[:18]} · {redemption.code_snapshot[:18]}", callback_data=f"admin:discount:request:view:{redemption.id}:{page}")])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ جدیدتر", callback_data=f"admin:discount:requests:page:{page-1}"))
    if page < last_page:
        nav.append(InlineKeyboardButton(text="قدیمی‌تر ➡️", callback_data=f"admin:discount:requests:page:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")])
    await c.message.edit_text(limit_telegram_html("\n".join(lines)), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:discount:requests:page:\d+$"))
async def admin_discount_requests(c: CallbackQuery, state: FSMContext):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    await _render_discount_requests(c, page)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:discount:request:view:\d+:\d+$"))
async def admin_discount_request_view(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    request_id, page = int(parts[-2]), int(parts[-1])
    async with SessionLocal() as session:
        redemption = await session.get(DiscountRedemption, request_id)
        if not redemption or redemption.status != "pending":
            return await c.answer("این درخواست قبلاً بررسی یا لغو شده است.", show_alert=True)
        user = (await session.execute(select(User).where(User.telegram_id == redemption.user_telegram_id))).scalar_one_or_none()
        code = await session.get(DiscountCode, redemption.discount_code_id) if redemption.discount_code_id else None
        event = await session.get(Event, redemption.event_id) if redemption.event_id else None
        draft = json.loads(redemption.draft_json or "{}")
    name = (user.display_name or " ".join(x for x in [user.first_name, user.last_name] if x) or "—") if user else "—"
    names = [" ".join(filter(None, [p.get("first_name"), p.get("last_name")])) for p in draft.get("participants", [])]
    username_line = ""
    if user and user.telegram_username:
        safe_username = user.telegram_username.strip().lstrip("@")
        if safe_username and safe_username.replace("_", "a").isalnum():
            username_line = f" | <a href=\"https://t.me/{safe_username}\">@{escape(safe_username)}</a>"
    body = (
        "🎟 <b>بررسی درخواست تخفیف</b>\n\n"
        f"<b>کد:</b> <code>{escape(redemption.code_snapshot)}</code> · "
        f"<b>نوع:</b> {'ویژه با تأیید' if code and code.kind == 'restricted' else 'نامشخص'}\n"
        f"<b>پنل:</b> {escape(redemption.event_label_snapshot)}\n"
        f"<b>رزروکننده:</b> {escape(name)}\n"
        f"<b>شناسه تلگرام:</b> <a href=\"tg://user?id={int(redemption.user_telegram_id)}\">{int(redemption.user_telegram_id)}</a>"
        f"{username_line}\n"
        f"<b>تلفن تماس:</b> {escape(redemption.contact_phone or '—')}\n"
        f"<b>شرکت‌کنندگان ({redemption.participant_count}):</b> {escape(', '.join(n for n in names if n) or '—')}\n\n"
        f"هزینه اصلی: {int(redemption.original_total or 0):,} تومان\n"
        f"تخفیف درخواستی (یک نفر): −{int(redemption.discount_amount or 0):,} تومان\n"
        f"<b>مبلغ پس از تخفیف: {int(redemption.final_total or 0):,} تومان</b>\n\n"
        "تأیید درخواست، صندلی رزرو نمی‌کند؛ کاربر پس از تأیید باید فرایند پرداخت را ادامه دهد."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👤 مشاهده پروفایل تلگرام", url=f"tg://user?id={int(redemption.user_telegram_id)}")],
        [InlineKeyboardButton(text="✅ تأیید تخفیف", callback_data=f"admin:discount:request:approve:{request_id}"), InlineKeyboardButton(text="❌ رد درخواست", callback_data=f"admin:discount:request:reject:{request_id}")],
        [InlineKeyboardButton(text="🔙 فهرست درخواست‌ها", callback_data=f"admin:discount:requests:page:{page}")],
    ])
    await c.message.edit_text(limit_telegram_html(body), reply_markup=kb)
    await c.answer()


async def _resolve_discount_request(c: CallbackQuery, redemption_id: int, *, approve: bool):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    recipient_id = None
    request_message_id = None
    code_name = "کد تخفیف"
    event_name = "پنل انتخاب‌شده"
    error = None
    async with SessionLocal() as session:
        redemption = (await session.execute(select(DiscountRedemption).where(
            DiscountRedemption.id == redemption_id
        ).with_for_update())).scalar_one_or_none()
        if not redemption or redemption.status != "pending":
            return await c.answer("این درخواست قبلاً بررسی شده است.", show_alert=True)
        code = await session.get(DiscountCode, int(redemption.discount_code_id or 0), with_for_update=True)
        event = await session.get(Event, int(redemption.event_id or 0), with_for_update=True)
        if not code or not code.active or not event or event.archived or event.status in (EventStatus.CANCELLED, EventStatus.COMPLETED):
            approve = False
            error = "کد غیرفعال شده یا پنل دیگر واجد شرایط نیست."
        else:
            linked = (await session.execute(select(DiscountCodeEvent.id).where(
                DiscountCodeEvent.discount_code_id == code.id, DiscountCodeEvent.event_id == event.id
            ))).scalar_one_or_none()
            if linked is None:
                approve = False
                error = "این پنل دیگر در محدودهٔ کد تخفیف نیست."
        redemption.status = "approved" if approve else "rejected"
        redemption.reviewed_by_telegram_id = int(c.from_user.id)
        redemption.reviewed_at = utc_now_naive()
        redemption.updated_at = utc_now_naive()
        recipient_id = int(redemption.user_telegram_id)
        request_message_id = int(redemption.request_message_id) if redemption.request_message_id else None
        code_name = (code.code or code.label or "کد تخفیف") if code else "کد تخفیف"
        event_name = redemption.event_label_snapshot
        await session.commit()

    notification_delivered = False
    notification_error = None
    if recipient_id:
        if approve:
            user_text = (
                f"✅ <b>درخواست کد تخفیف شما تأیید شد!</b>\n"
                f"کد: <code>{escape(code_name)}</code>\nپنل: {escape(event_name)}\n\n"
                "برای ادامه، روی «ادامه ثبت‌نام و پرداخت با تخفیف» بزنید. سپس مبلغ نهایی را تأیید کرده و رسید را ارسال کنید.\n"
                "توجه: هنوز صندلی‌ای رزرو نشده؛ ظرفیت هنگام ادامه دوباره بررسی می‌شود."
            )
            user_keyboard = discount_request_user_keyboard(redemption_id, approved=True)
        else:
            user_text = (
                f"❌ <b>درخواست تخفیف شما تأیید نشد.</b>\n"
                f"کد: <code>{escape(code_name)}</code>\nپنل: {escape(event_name)}\n"
                f"{escape(error or 'درخواست تخفیف رد شد.')}\n\n"
                "این حساب پس از رد درخواست نمی‌تواند دوباره از همین کد استفاده کند. می‌توانید برای این ثبت‌نام با قیمت عادی ادامه دهید یا آن را لغو کنید؛ برای درخواست تخفیف دیگر باید از کد دیگری استفاده کنید."
            )
            user_keyboard = discount_request_user_keyboard(redemption_id, approved=False)

        # Prefer editing the original pending message so the bot chat stays tidy.
        # Older rows may not have a message ID; if Telegram no longer permits editing,
        # send one actionable replacement message and surface delivery failures to admins.
        if request_message_id:
            try:
                await c.bot.edit_message_text(
                    chat_id=recipient_id,
                    message_id=request_message_id,
                    text=user_text,
                    reply_markup=user_keyboard,
                    disable_web_page_preview=True,
                )
                notification_delivered = True
            except Exception:
                logger.info(
                    "Could not edit original discount-request message; sending fallback. redemption_id=%s message_id=%s",
                    redemption_id, request_message_id, exc_info=True,
                )
        if not notification_delivered:
            try:
                await c.bot.send_message(
                    recipient_id, user_text, reply_markup=user_keyboard, disable_web_page_preview=True
                )
                notification_delivered = True
            except Exception as exc:
                notification_error = type(exc).__name__
                logger.exception("Could not notify user about discount review; redemption_id=%s", redemption_id)

    status_text = "✅ درخواست تخفیف تأیید شد." if approve else f"❌ درخواست تخفیف رد شد. {error or ''}"
    if recipient_id and not notification_delivered:
        status_text += "\n\n⚠️ وضعیت در پایگاه داده ثبت شد، اما پیام به کاربر ارسال نشد. دسترسی ربات به گفت‌وگوی کاربر را بررسی کنید."
    elif recipient_id and notification_delivered:
        status_text += "\n\n📨 پیام نتیجه به کاربر اطلاع داده شد."
    await c.message.edit_text(status_text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➡️ درخواست‌های در انتظار", callback_data="admin:discount:requests:page:0")],
        [InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")],
    ]))
    await c.answer("ثبت شد.")

@router.callback_query(F.data.regexp(r"^admin:discount:request:approve:\d+$"))
async def admin_discount_request_approve(c: CallbackQuery):
    try:
        rid = int((c.data or "").rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("شناسه درخواست نامعتبر است.", show_alert=True)
    await _resolve_discount_request(c, rid, approve=True)


@router.callback_query(F.data.regexp(r"^admin:discount:request:reject:\d+$"))
async def admin_discount_request_reject(c: CallbackQuery):
    try:
        rid = int((c.data or "").rsplit(":", 1)[1])
    except ValueError:
        return await c.answer("شناسه درخواست نامعتبر است.", show_alert=True)
    await _resolve_discount_request(c, rid, approve=False)


@router.callback_query(F.data.regexp(r"^admin:pending_payments:page:\d+$"))
async def admin_pending_payments(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    except ValueError:
        page = 0
    rows = await _payment_rows()
    if not rows:
        await c.message.edit_text(
            "🧾 <b>رسیدهای در انتظار بررسی</b>\n\n✅ رسیدی برای بررسی وجود ندارد.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🎟 درخواست‌های تخفیف", callback_data="admin:discount:requests:page:0")],
                [InlineKeyboardButton(text="🔙 بازگشت به مدیریت", callback_data="admin:home")],
            ]),
        )
        return await c.answer()
    page = min(page, len(rows) - 1)
    if len(rows) > 1:
        await c.answer(f"رسید {page + 1} از {len(rows)}")
    else:
        await c.answer()
    await _show_payment(c, rows[page], None, receipt_count=len(rows))



@router.callback_query(F.data.regexp(r"^admin:event:links:\d+$"))
async def admin_event_registration_links(c: CallbackQuery):
    """Build the real selected-panel deep links from the configured Telegram bot identity."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    eid = await read_callback_id(c, "پنل")
    if eid is None:
        return
    async with SessionLocal() as session:
        event = await session.get(Event, eid)
        if not event:
            return await c.answer("پنل پیدا نشد یا حذف شده است.", show_alert=True)
        is_archived = bool(event.archived)
        status = str(getattr(event.status, "value", event.status))
        open_for_registration = registration_is_open(event) and not is_archived and status == "published"
        used = await seats_used(session, eid) if not is_archived else 0
        is_full = used >= int(event.capacity or 0)
        title = f"{volume_label(event.volume)} — {event.title}"
    if is_archived or status == "cancelled":
        await c.message.answer(
            f"🔗 <b>{escape(title)}</b>\n\nاین پنل آرشیو یا لغو شده است؛ لینک ثبت‌نام فعال ساخته نمی‌شود.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{eid}")
            ]]),
        )
        return await c.answer()
    if status != "published":
        await c.message.answer(
            f"🔗 <b>{escape(title)}</b>\n\nاین پنل هنوز منتشر نشده است. پس از انتشار می‌توانید لینک عمومی جزئیات و ثبت‌نام را دریافت کنید.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{eid}")
            ]]),
        )
        return await c.answer()
    try:
        bot_identity = await c.bot.get_me()
    except Exception:
        logger.exception("Could not resolve bot username for panel deep link; event_id=%s", eid)
        return await c.answer("نام کاربری ربات از تلگرام دریافت نشد؛ لینک ساخته نشد.", show_alert=True)
    if not bot_identity.username:
        return await c.answer("برای ساخت لینک، ربات باید در تلگرام نام کاربری داشته باشد.", show_alert=True)
    details_url = f"https://t.me/{bot_identity.username}?start=panel_{eid}"
    rows = [[InlineKeyboardButton(text="کپی لینک جزئیات", copy_text=CopyTextButton(text=details_url))]]
    status_text = "ثبت‌نام باز است و ظرفیت موجود دارد."
    registration_line = ""
    if open_for_registration and not is_full:
        register_url = f"https://t.me/{bot_identity.username}?start=reg_{eid}"
        rows.append([InlineKeyboardButton(text="کپی لینک ثبت‌نام", copy_text=CopyTextButton(text=register_url))])
        registration_line = f"\nلینک ثبت‌نام: <code>{escape(register_url)}</code>"
    elif is_full:
        status_text = "ظرفیت تکمیل است؛ لینک ثبت‌نام فعال ارائه نمی‌شود."
    else:
        status_text = "ثبت‌نام بسته است؛ فقط لینک جزئیات قابل کپی است."
    rows.append([InlineKeyboardButton(text="🔙 مدیریت پنل", callback_data=f"admin:event:view:{eid}")])
    await c.message.answer(
        f"🔗 <b>{escape(title)}</b>\n\n{status_text}\n\n"
        f"لینک جزئیات: <code>{escape(details_url)}</code>{registration_line}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), disable_web_page_preview=True,
    )
    await c.answer()


@router.callback_query(F.data == "admin:referrals:export")
async def export_referral_report(c: CallbackQuery):
    """Admins only: export all referrer counts and the profiles attributed to each code."""
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    try:
        async with SessionLocal() as session:
            users = (await session.execute(select(User).order_by(User.id))).scalars().all()
            # Participation metrics use the application's actual booking and attendance states.
            confirmed_stats_rows = (await session.execute(
                select(
                    Booking.booked_by_user_id,
                    func.count(Booking.id),
                    func.count(func.distinct(Booking.event_id)),
                ).where(Booking.status == RegistrationStatus.CONFIRMED)
                .group_by(Booking.booked_by_user_id)
            )).all()
            attended_stats_rows = (await session.execute(
                select(
                    Booking.booked_by_user_id,
                    func.count(func.distinct(Booking.event_id)),
                ).join(Participant, Participant.booking_id == Booking.id)
                .where(
                    Booking.status == RegistrationStatus.CONFIRMED,
                    Participant.attendance_status == AttendanceStatus.ATTENDED,
                ).group_by(Booking.booked_by_user_id)
            )).all()
        users_by_id = {int(user.id): user for user in users}
        confirmed_stats = {int(uid): (int(booking_count), int(panel_count)) for uid, booking_count, panel_count in confirmed_stats_rows}
        attended_stats = {int(uid): int(panel_count) for uid, panel_count in attended_stats_rows}
        counts: dict[int, int] = {}
        for user in users:
            referrer_id = getattr(user, "referred_by_user_id", None)
            if referrer_id is not None:
                counts[int(referrer_id)] = counts.get(int(referrer_id), 0) + 1

        def user_name(user):
            full = " ".join(part for part in (user.first_name, user.last_name) if part).strip()
            return user.display_name or full or str(user.telegram_id)

        summary_rows = []
        for user in users:
            summary_rows.append({
                "name": user_name(user),
                "telegram_id": int(user.telegram_id),
                "username": f"@{user.telegram_username}" if user.telegram_username else "—",
                "referral_count": counts.get(int(user.id), 0),
            })
        summary_rows.sort(key=lambda row: (-int(row["referral_count"]), str(row["name"]).casefold(), int(row["telegram_id"])))
        detail_rows = []
        for user in users:
            referrer_id = getattr(user, "referred_by_user_id", None)
            if referrer_id is None:
                continue
            referrer = users_by_id.get(int(referrer_id))
            if not referrer:
                continue
            detail_rows.append({
                "referrer_name": user_name(referrer),
                "referrer_telegram_id": int(referrer.telegram_id),
                "referred_name": user_name(user),
                "referred_telegram_id": int(user.telegram_id),
                "username": f"@{user.telegram_username}" if user.telegram_username else "—",
                "phone_number": user.phone_number or "—",
                "created_at": user.created_at,
                "ever_confirmed_booking": "Yes" if int(user.lifetime_confirmed_bookings or 0) > 0 else "No",
                "lifetime_confirmed_bookings": int(user.lifetime_confirmed_bookings or 0),
                "confirmed_bookings": confirmed_stats.get(int(user.id), (0, 0))[0],
                "confirmed_panels": confirmed_stats.get(int(user.id), (0, 0))[1],
                "panels_attended": attended_stats.get(int(user.id), 0),
                "ever_attended_panel": "Yes" if attended_stats.get(int(user.id), 0) > 0 else "No",
            })
        detail_rows.sort(key=lambda row: (str(row["referrer_name"]).casefold(), str(row["referred_name"]).casefold()))
        payload = build_referral_report_xlsx(summary_rows, detail_rows)
    except Exception:
        logger.exception("Could not build referral report for admin_id=%s", c.from_user.id)
        return await c.answer("ساخت گزارش معرفی دوستان ناموفق بود؛ لطفاً دوباره تلاش کنید.", show_alert=True)

    await c.answer("گزارش معرفی دوستان آماده شد.")
    try:
        await c.bot.send_document(
            int(c.from_user.id),
            BufferedInputFile(payload, filename="panel_flow_referral_report.xlsx"),
            caption=(
                "🤝 <b>گزارش معرفی دوستان</b>\n"
                f"تعداد حساب‌ها: {len(users):,}\n"
                f"ثبت‌نام‌های دارای کد معرفی: {len(detail_rows):,}\n"
                "برگهٔ اول تعداد معرفی هر کاربر و برگهٔ دوم اطلاعات کامل افراد معرفی‌شده، سابقهٔ رزرو تأییدشدهٔ مادام‌العمر، وضعیت رزروهای فعلی و حضور ثبت‌شده در پنل‌ها را نشان می‌دهد."
            ),
        )
    except Exception:
        logger.exception("Could not send referral report to admin_id=%s", c.from_user.id)
        await c.bot.send_message(int(c.from_user.id), "گزارش ساخته شد اما ارسال فایل ناموفق بود. دوباره تلاش کنید.")


# --- Persistent admin-editable bot settings (V65) ------------------------------

# Sensitive admin settings are accessible only in the authorized admin's private chat.
async def _authorize_admin_settings_callback(c: CallbackQuery) -> bool:
    if not await is_admin(c.from_user.id):
        await c.answer("دسترسی مجاز نیست.", show_alert=True)
        return False
    chat = getattr(c.message, "chat", None)
    chat_type = getattr(chat, "type", None)
    chat_type = getattr(chat_type, "value", chat_type)
    if chat_type != "private":
        await c.answer("برای حفظ حریم اطلاعات، تنظیمات را در گفت‌وگوی خصوصی ربات باز کنید.", show_alert=True)
        return False
    return True


_SETTING_LABELS = {
    "community_group_url": "لینک گروه تلگرام",
    "community_channel_url": "لینک کانال تلگرام",
    "community_instagram_url": "لینک اینستاگرام",
    "community_website_url": "لینک وب‌سایت",
}
_SETTING_PROMPTS = {
    "community_group_url": "لینک دعوت یا نشانی عمومی گروه تلگرام را با https://t.me/... وارد کنید.",
    "community_channel_url": "لینک کانال تلگرام را با https://t.me/... وارد کنید.",
    "community_instagram_url": "لینک صفحهٔ اینستاگرام را با https://www.instagram.com/... وارد کنید.",
    "community_website_url": "لینک وب‌سایت رسمی را با https://... وارد کنید. برای غیرفعال‌کردن لینک، «—» بفرستید.",
}


def _full_card(value: str) -> str:
    """Return the configured card value unchanged for authorized admin settings."""
    return str(value or "").strip() or "تنظیم نشده"


def _admin_settings_text(values: dict[str, str]) -> str:
    shown_card = escape(_full_card(values.get("payment_card_number", "")))
    return (
        "⚙️ <b>تنظیمات ربات</b>\n\n"
        f"👥 لینک گروه: <code>{escape(values.get('community_group_url') or 'تنظیم نشده')}</code>\n"
        f"📢 لینک کانال: <code>{escape(values.get('community_channel_url') or 'تنظیم نشده')}</code>\n"
        f"📷 لینک اینستاگرام: <code>{escape(values.get('community_instagram_url') or 'تنظیم نشده')}</code>\n"
        f"🌐 لینک وب‌سایت: <code>{escape(values.get('community_website_url') or 'هنوز ثبت نشده')}</code>\n\n"
        f"💳 شماره کارت: <code>{shown_card}</code>\n"
        f"👤 نام صاحب کارت: <b>{escape(values.get('payment_account_name') or 'تنظیم نشده')}</b>"
    )


async def _show_admin_settings(target) -> None:
    async with SessionLocal() as session:
        values = await get_bot_settings(session)
    text = _admin_settings_text(values)
    markup = admin_settings_keyboard()
    if hasattr(target, "edit_text"):
        try:
            await target.edit_text(text, reply_markup=markup, disable_web_page_preview=True)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=markup, disable_web_page_preview=True)


@router.callback_query(F.data == "admin:settings")
async def admin_settings_home(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    await state.clear()
    await _show_admin_settings(c.message)
    await c.answer()


@router.callback_query(F.data.regexp(r"^admin:settings:edit:(community_group_url|community_channel_url|community_instagram_url|community_website_url)$"))
async def admin_settings_edit_link(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    field = str(c.data).rsplit(":", 1)[1]
    await state.clear()
    await state.update_data(settings_field=field)
    await state.set_state(AdminSettingsStates.waiting_link)
    async with SessionLocal() as session:
        values = await get_bot_settings(session)
    prompt = f"✏️ <b>تغییر { _SETTING_LABELS[field] }</b>\n\n{_SETTING_PROMPTS[field]}\n\nمقدار فعلی: <code>{escape(values.get(field) or 'تنظیم نشده')}</code>"
    await c.message.edit_text(prompt, reply_markup=admin_settings_cancel_keyboard(), disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data == "admin:settings:edit:card")
async def admin_settings_edit_card(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    await state.clear()
    await state.set_state(AdminSettingsStates.waiting_card_number)
    await c.message.edit_text(
        "💳 <b>تغییر اطلاعات کارت بانکی</b>\n\nشماره کارت ۱۶ رقمی را وارد کنید. می‌توانید از ارقام فارسی یا انگلیسی استفاده کنید.\n\nاطلاعات فعلی تا زمان تأیید نهایی تغییر نمی‌کند.",
        reply_markup=admin_settings_cancel_keyboard(),
    )
    await c.answer()


@router.message(AdminSettingsStates.waiting_link)
async def admin_settings_link_input(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    data = await state.get_data()
    field = str(data.get("settings_field") or "")
    raw_link = (message.text or "").strip()
    try:
        candidate = "" if field == "community_website_url" and raw_link in {"—", "-", ""} else validate_admin_setting_value(field, raw_link)
    except ValueError:
        return await message.answer(
            f"لینک معتبر نیست. لطفاً نشانی https معتبر برای { _SETTING_LABELS.get(field, 'این بخش') } وارد کنید.",
            reply_markup=admin_settings_cancel_keyboard(),
        )
    await state.update_data(settings_pending_value=candidate)
    await state.set_state(AdminSettingsStates.confirming_link)
    await message.answer(
        f"<b>بررسی تغییر</b>\n\n{_SETTING_LABELS[field]}:\n<code>{escape(candidate)}</code>\n\nآیا این تغییر ذخیره شود؟",
        reply_markup=admin_settings_link_confirm_keyboard(),
        disable_web_page_preview=True,
    )


@router.callback_query(F.data == "admin:settings:confirm_link")
async def admin_settings_confirm_link(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    if await state.get_state() != AdminSettingsStates.confirming_link.state:
        return await c.answer("این مرحله منقضی شده است؛ تنظیمات را دوباره باز کنید.", show_alert=True)
    data = await state.get_data()
    field = str(data.get("settings_field") or "")
    try:
        candidate = "" if field == "community_website_url" and not str(data.get("settings_pending_value") or "").strip() else validate_admin_setting_value(field, str(data.get("settings_pending_value") or ""))
    except ValueError:
        await state.clear()
        return await c.answer("اطلاعات تغییر نامعتبر است؛ دوباره تلاش کنید.", show_alert=True)
    if field not in _SETTING_LABELS:
        await state.clear()
        return await c.answer("بخش تنظیمات معتبر نیست.", show_alert=True)
    try:
        async with SessionLocal() as session:
            await set_setting(session, field, candidate)
            await write_admin_action(session, actor_telegram_id=int(c.from_user.id), action="update_bot_setting", entity_type="app_setting", details={"setting": field})
            await session.commit()
    except Exception as exc:
        # Never log the URL value or DB statement parameters.
        logger.error("Could not persist admin bot setting field=%s error_type=%s", field, type(exc).__name__)
        return await c.answer("ذخیره انجام نشد؛ اطلاعات قبلی بدون تغییر باقی ماند. دوباره تلاش کنید.", show_alert=True)
    await state.clear()
    await _show_admin_settings(c.message)
    await c.answer("ذخیره شد.")


@router.callback_query(F.data == "admin:settings:edit_pending_link")
async def admin_settings_edit_pending_link(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    if await state.get_state() != AdminSettingsStates.confirming_link.state:
        return await c.answer("این مرحله منقضی شده است.", show_alert=True)
    field = str((await state.get_data()).get("settings_field") or "")
    if field not in _SETTING_LABELS:
        await state.clear()
        return await c.answer("بخش تنظیمات معتبر نیست.", show_alert=True)
    await state.set_state(AdminSettingsStates.waiting_link)
    await c.message.edit_text(f"✏️ { _SETTING_PROMPTS[field] }", reply_markup=admin_settings_cancel_keyboard())
    await c.answer()


@router.message(AdminSettingsStates.waiting_card_number)
async def admin_settings_card_number_input(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    try:
        candidate = validate_admin_setting_value("payment_card_number", message.text or "")
    except ValueError:
        return await message.answer("شماره کارت معتبر نیست. شماره کارت بانکی ۱۶ رقمی با رقم کنترلی معتبر را وارد کنید.", reply_markup=admin_settings_cancel_keyboard())
    await state.update_data(settings_pending_card_number=candidate)
    await state.set_state(AdminSettingsStates.waiting_cardholder_name)
    await message.answer("نام و نام خانوادگی صاحب کارت را وارد کنید (حداکثر ۱۰۰ نویسه).", reply_markup=admin_settings_cancel_keyboard())


@router.message(AdminSettingsStates.waiting_cardholder_name)
async def admin_settings_cardholder_input(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    try:
        candidate = validate_admin_setting_value("payment_account_name", message.text or "")
    except ValueError:
        return await message.answer("نام صاحب کارت معتبر نیست. نام و نام خانوادگی را کامل وارد کنید.", reply_markup=admin_settings_cancel_keyboard())
    data = await state.get_data()
    card_number = str(data.get("settings_pending_card_number") or "")
    try:
        card_number = validate_admin_setting_value("payment_card_number", card_number)
    except ValueError:
        await state.set_state(AdminSettingsStates.waiting_card_number)
        return await message.answer("شماره کارت موقت معتبر نیست؛ لطفاً دوباره آن را وارد کنید.", reply_markup=admin_settings_cancel_keyboard())
    await state.update_data(settings_pending_cardholder_name=candidate)
    await state.set_state(AdminSettingsStates.confirming_card)
    await message.answer(
        "💳 <b>پیش‌نمایش اطلاعات جدید کارت</b>\n\n"
        f"شماره کارت: <code>{escape(card_number)}</code>\n"
        f"نام صاحب کارت: <b>{escape(candidate)}</b>\n\n"
        "فقط پس از تأیید این اطلاعات ذخیره می‌شود.",
        reply_markup=admin_settings_card_confirm_keyboard(),
    )


@router.callback_query(F.data == "admin:settings:confirm_card")
async def admin_settings_confirm_card(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    if await state.get_state() != AdminSettingsStates.confirming_card.state:
        return await c.answer("این مرحله منقضی شده است؛ دوباره اطلاعات کارت را وارد کنید.", show_alert=True)
    data = await state.get_data()
    try:
        card_number = validate_admin_setting_value("payment_card_number", str(data.get("settings_pending_card_number") or ""))
        cardholder = validate_admin_setting_value("payment_account_name", str(data.get("settings_pending_cardholder_name") or ""))
    except ValueError:
        await state.clear()
        return await c.answer("اطلاعات کارت کامل یا معتبر نیست؛ فرایند را از نو شروع کنید.", show_alert=True)
    try:
        async with SessionLocal() as session:
            await set_setting(session, "payment_card_number", card_number)
            await set_setting(session, "payment_account_name", cardholder)
            # Audit only which fields changed; never put payment credentials in audit details.
            await write_admin_action(session, actor_telegram_id=int(c.from_user.id), action="update_bot_setting", entity_type="app_setting", details={"setting": "payment_card_details"})
            await session.commit()
    except Exception as exc:
        logger.error("Could not persist admin payment setting error_type=%s", type(exc).__name__)
        return await c.answer("ذخیره انجام نشد؛ اطلاعات پرداخت قبلی بدون تغییر باقی ماند. دوباره تلاش کنید.", show_alert=True)
    await state.clear()
    await _show_admin_settings(c.message)
    await c.answer("اطلاعات کارت ذخیره شد.")


@router.callback_query(F.data == "admin:settings:edit_pending_card_number")
async def admin_settings_edit_pending_card_number(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    if await state.get_state() != AdminSettingsStates.confirming_card.state:
        return await c.answer("این مرحله منقضی شده است.", show_alert=True)
    await state.set_state(AdminSettingsStates.waiting_card_number)
    await c.message.edit_text("شماره کارت ۱۶ رقمی جدید را وارد کنید.", reply_markup=admin_settings_cancel_keyboard())
    await c.answer()


@router.callback_query(F.data == "admin:settings:edit_pending_cardholder")
async def admin_settings_edit_pending_cardholder(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    if await state.get_state() != AdminSettingsStates.confirming_card.state:
        return await c.answer("این مرحله منقضی شده است.", show_alert=True)
    await state.set_state(AdminSettingsStates.waiting_cardholder_name)
    await c.message.edit_text("نام و نام خانوادگی صاحب کارت را وارد کنید.", reply_markup=admin_settings_cancel_keyboard())
    await c.answer()


@router.callback_query(F.data == "admin:settings:cancel")
async def admin_settings_cancel(c: CallbackQuery, state: FSMContext):
    if not await _authorize_admin_settings_callback(c):
        return
    await state.clear()
    await _show_admin_settings(c.message)
    await c.answer("تغییری ذخیره نشد.")


@router.callback_query(F.data.startswith("admin:"))
async def stale_admin_callback(c: CallbackQuery):
    if not await is_admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await c.answer("این دکمه منقضی شده یا دیگر در دسترس نیست. لطفاً از منو دوباره انتخاب کنید.", show_alert=True)
