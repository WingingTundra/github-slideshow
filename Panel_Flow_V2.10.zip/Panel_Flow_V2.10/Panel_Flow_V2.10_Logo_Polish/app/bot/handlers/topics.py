"""Community topic suggestion and voting flows."""
from __future__ import annotations

from datetime import datetime, timedelta
from html import escape

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select

from app.config import settings
from app.db.models import TopicSuggestion, TopicVote, User
from app.db.session import SessionLocal
from app.services.admin_audit import write_admin_action
from app.time_utils import utc_now_naive
from app.display_utils import status_display_label
from app.services.user_access import has_active_feature_restriction
from app.services.app_settings import get_setting
from app.bot.states import TopicSuggestionStates

user_router = Router()
admin_router = Router()
TOPIC_PAGE_SIZE = 8
ADMIN_TOPIC_PAGE_SIZE = 6


async def _admin(tg_id: int) -> bool:
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(tg_id)


async def _user_for_telegram(telegram_user) -> User:
    from app.bot.handlers.user import get_or_create_user
    return await get_or_create_user(telegram_user)


async def _protect_topic_navigation(c: CallbackQuery, state: FSMContext) -> bool:
    if await state.get_state():
        await c.answer("یک فرایند ناتمام دارید. ابتدا آن را ادامه دهید یا /cancel را بزنید.", show_alert=True)
        return True
    return False


@user_router.callback_query(F.data == "user:topics")
async def topic_voting_home(c: CallbackQuery, state: FSMContext):
    if await _protect_topic_navigation(c, state):
        return
    await _render_topic_voting(c, page=0, answer=True)


@user_router.callback_query(F.data.regexp(r"^topics:page:\d+$"))
async def topic_voting_page(c: CallbackQuery, state: FSMContext):
    if await _protect_topic_navigation(c, state):
        return
    try:
        page = max(0, int((c.data or "").rsplit(":", 1)[1]))
    except (TypeError, ValueError, IndexError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    await _render_topic_voting(c, page=page, answer=True)


async def _render_topic_voting(target: Message | CallbackQuery, *, page: int = 0, answer: bool = True):
    user = await _user_for_telegram(target.from_user)
    page = max(0, int(page))
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(TopicSuggestion.id)).where(
            TopicSuggestion.status.in_(("open", "planned"))
        )) or 0)
        page_count = max(1, (total + TOPIC_PAGE_SIZE - 1) // TOPIC_PAGE_SIZE)
        page = min(page, page_count - 1)
        rows = (await session.execute(
            select(TopicSuggestion, func.count(TopicVote.id).label("votes"))
            .outerjoin(TopicVote, TopicVote.topic_id == TopicSuggestion.id)
            .where(TopicSuggestion.status.in_(("open", "planned")))
            .group_by(TopicSuggestion.id)
            .order_by(func.count(TopicVote.id).desc(), TopicSuggestion.created_at.desc(), TopicSuggestion.id.desc())
            .offset(page * TOPIC_PAGE_SIZE).limit(TOPIC_PAGE_SIZE)
        )).all()
        topic_ids = [int(topic.id) for topic, _ in rows]
        my_votes = set()
        if topic_ids:
            my_votes = set((await session.execute(select(TopicVote.topic_id).where(
                TopicVote.user_id == user.id, TopicVote.topic_id.in_(topic_ids)))).scalars().all())
    lines = ["<b>🗳 پیشنهاد و رأی‌گیری موضوع‌های پنل</b>",
             "موضوع‌های موردعلاقه‌ات را انتخاب کن؛ پیشنهادها پیش از نمایش عمومی بررسی می‌شوند.", ""]
    buttons = []
    if not rows:
        lines.append("فعلاً موضوعی برای رأی‌گیری منتشر نشده است.")
    for topic, votes in rows:
        status = "🗓 برنامه‌ریزی‌شده" if topic.status == "planned" else "برای رأی‌گیری"
        lines.append(f"• <b>{escape(topic.title)}</b> — {int(votes)} رأی · {status}")
        if topic.status == "open":
            voted = int(topic.id) in my_votes
            buttons.append([InlineKeyboardButton(
                text=("✅ رأی شما ثبت شده · لغو رأی" if voted else f"🗳 رأی دادن · {int(votes)}"),
                callback_data=f"topics:vote:{topic.id}:{page}",
            )])
    navigation = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"topics:page:{page - 1}"))
    navigation.append(InlineKeyboardButton(text=f"صفحه {page + 1}/{page_count} · {total} موضوع", callback_data=f"topics:page:{page}"))
    if page + 1 < page_count:
        navigation.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"topics:page:{page + 1}"))
    if total > TOPIC_PAGE_SIZE:
        buttons.append(navigation)
    async with SessionLocal() as session:
        suggestions_enabled = str(await get_setting(session, "topic_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"}
    if suggestions_enabled:
        buttons.append([InlineKeyboardButton(text="➕ پیشنهاد موضوع جدید", callback_data="topics:suggest")])
    else:
        lines.append("\nامکان ثبت موضوع جدید موقتاً غیرفعال است؛ رأی‌گیری و مشاهدهٔ موضوع‌های قبلی همچنان فعال است.")
    buttons.append([InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")])
    text = "\n".join(lines)
    markup = InlineKeyboardMarkup(inline_keyboard=buttons)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=markup)
        if answer:
            await target.answer()
    else:
        await target.answer(text, reply_markup=markup)


@user_router.callback_query(F.data == "topics:suggest")
async def topic_suggestion_start(c: CallbackQuery, state: FSMContext):
    if await _protect_topic_navigation(c, state):
        return
    async with SessionLocal() as session:
        enabled = str(await get_setting(session, "topic_suggestions_enabled", "true")).lower() in {"1", "true", "yes", "on", "enabled"}
    if not enabled:
        return await c.answer("امکان ثبت موضوع جدید موقتاً غیرفعال است.", show_alert=True)
    await state.set_state(TopicSuggestionStates.waiting_text)
    await c.message.edit_text("موضوع پیشنهادی را در یک پیام بنویسید (۳ تا ۲۰۰ کاراکتر). پیشنهاد ابتدا برای بررسی مدیران ارسال می‌شود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="↩️ لغو", callback_data="topics:cancel")]]))
    await c.answer()


@user_router.callback_query(F.data == "topics:cancel")
async def topic_suggestion_cancel(c: CallbackQuery, state: FSMContext):
    if await state.get_state() == TopicSuggestionStates.waiting_text.state:
        await state.clear()
    await c.message.edit_text("ثبت پیشنهاد لغو شد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🗳 بازگشت به رأی‌گیری", callback_data="user:topics")],
        [InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")],
    ]))
    await c.answer()


@user_router.message(TopicSuggestionStates.waiting_text)
async def topic_suggestion_submit(message: Message, state: FSMContext):
    title = (message.text or "").strip()
    if not 3 <= len(title) <= 200:
        return await message.answer("موضوع باید بین ۳ تا ۲۰۰ کاراکتر باشد. دوباره ارسال کنید.")
    user = await _user_for_telegram(message.from_user)
    async with SessionLocal() as session:
        if await has_active_feature_restriction(session, int(message.from_user.id), "suggestions"):
            await state.clear()
            return await message.answer("ارسال پیشنهاد موضوع برای حساب شما به‌طور موقت محدود شده است.")
        if str(await get_setting(session, "topic_suggestions_enabled", "true")).lower() not in {"1", "true", "yes", "on", "enabled"}:
            await state.clear()
            return await message.answer("ثبت موضوع جدید در حال حاضر غیرفعال است؛ متن شما ثبت نشد.")
        # Modest friction prevents a single account from flooding the moderation queue.
        recent = int((await session.execute(select(func.count(TopicSuggestion.id)).where(
            TopicSuggestion.user_id == user.id,
            TopicSuggestion.created_at >= utc_now_naive() - timedelta(days=1),
        ))).scalar_one())
        if recent >= 5:
            return await message.answer("در هر ۲۴ ساعت حداکثر ۵ پیشنهاد می‌توانید ثبت کنید.")
        session.add(TopicSuggestion(user_id=user.id, title=title, status="pending"))
        await session.commit()
    await state.clear()
    await message.answer("✅ پیشنهاد شما برای بررسی مدیران ثبت شد. پس از تأیید، در رأی‌گیری موضوع‌ها نمایش داده می‌شود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🗳 رأی‌گیری موضوع‌ها", callback_data="user:topics")],
            [InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")],
        ]))


@user_router.callback_query(F.data.regexp(r"^topics:vote:\d+(?::\d+)?$"))
async def topic_vote(c: CallbackQuery, state: FSMContext):
    if await _protect_topic_navigation(c, state):
        return
    parts = (c.data or "").split(":")
    try:
        topic_id = int(parts[2])
        page = max(0, int(parts[3])) if len(parts) > 3 else 0
        if topic_id <= 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("موضوع انتخاب‌شده معتبر نیست.", show_alert=True)
    user = await _user_for_telegram(c.from_user)
    async with SessionLocal() as session:
        topic = await session.get(TopicSuggestion, topic_id, with_for_update=True)
        if not topic or topic.status != "open":
            return await c.answer("این موضوع دیگر در حال رأی‌گیری نیست.", show_alert=True)
        vote = (await session.execute(select(TopicVote).where(
            TopicVote.topic_id == topic_id, TopicVote.user_id == user.id).with_for_update())).scalar_one_or_none()
        if vote:
            await session.delete(vote)
            message = "رأی شما لغو شد."
        else:
            session.add(TopicVote(topic_id=topic_id, user_id=user.id))
            message = "رأی شما ثبت شد."
        await session.commit()
    await c.answer(message)
    await _render_topic_voting(c, page=page, answer=False)


@admin_router.callback_query(F.data == "admin:topics")
async def topic_admin_home(c: CallbackQuery):
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await _render_topic_admin_home(c, answer=True)


async def _render_topic_admin_home(c: CallbackQuery, *, answer: bool):
    """Status-separated admin queues with counts sourced from TopicSuggestion."""
    async with SessionLocal() as session:
        groups = (await session.execute(
            select(TopicSuggestion.status, func.count(TopicSuggestion.id))
            .group_by(TopicSuggestion.status)
        )).all()
    counts = {str(status): int(count) for status, count in groups}
    buttons = [
        [InlineKeyboardButton(text=f"⏳ در انتظار بررسی · {counts.get('pending', 0)}",
                              callback_data="admin:topics:queue:pending:0")],
        [InlineKeyboardButton(text=f"🗳 رأی‌گیری باز · {counts.get('open', 0)}",
                              callback_data="admin:topics:queue:open:0")],
        [InlineKeyboardButton(text=f"🗓 برنامه‌ریزی‌شده · {counts.get('planned', 0)}",
                              callback_data="admin:topics:queue:planned:0")],
        [InlineKeyboardButton(text=f"🚫 ردشده · {counts.get('declined', 0)}",
                              callback_data="admin:topics:queue:declined:0")],
        [InlineKeyboardButton(text="🔙 منوی مدیریت", callback_data="admin:home")],
    ]
    await c.message.edit_text(
        "<b>مدیریت پیشنهاد موضوع‌ها</b>\n\n"
        "صف‌ها جدا هستند؛ تعداد هر صف از وضعیت ثبت‌شده در پایگاه داده محاسبه می‌شود.\n"
        "تغییر وضعیت، پیشنهاد را حذف نمی‌کند.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )
    if answer:
        await c.answer()


@admin_router.callback_query(F.data.regexp(r"^admin:topics:queue:(pending|open|planned|declined):\d+$"))
async def topic_admin_queue(c: CallbackQuery):
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    status = parts[3]
    try:
        page = max(0, int(parts[4]))
    except (ValueError, IndexError):
        return await c.answer("صفحهٔ انتخاب‌شده معتبر نیست.", show_alert=True)
    async with SessionLocal() as session:
        total = int(await session.scalar(select(func.count(TopicSuggestion.id)).where(
            TopicSuggestion.status == status
        )) or 0)
        page_count = max(1, (total + ADMIN_TOPIC_PAGE_SIZE - 1) // ADMIN_TOPIC_PAGE_SIZE)
        page = min(page, page_count - 1)
        rows = (await session.execute(
            select(TopicSuggestion, func.count(TopicVote.id).label("votes"))
            .outerjoin(TopicVote, TopicVote.topic_id == TopicSuggestion.id)
            .where(TopicSuggestion.status == status)
            .group_by(TopicSuggestion.id)
            .order_by(TopicSuggestion.created_at.desc(), TopicSuggestion.id.desc())
            .offset(page * ADMIN_TOPIC_PAGE_SIZE).limit(ADMIN_TOPIC_PAGE_SIZE)
        )).all()
    labels = {"pending": "Pending review", "open": "Voting open", "planned": "Planned", "declined": "Declined"}
    lines = [f"<b>Topic queue: {labels.get(status, status_display_label(status))}</b>", f"صفحه {page + 1}/{page_count} · مجموع {total} مورد", ""]
    buttons = []
    for topic, votes in rows:
        lines.append(f"#{topic.id} · {escape(topic.title)}\n{int(votes)} رأی")
        buttons.append([InlineKeyboardButton(
            text=f"#{topic.id} · {topic.title[:35]}",
            callback_data=f"admin:topics:view:{topic.id}",
        )])
    if not rows:
        lines.append("این صف خالی است.")
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:topics:queue:{status}:{page - 1}"))
    nav.append(InlineKeyboardButton(text=f"صفحه {page + 1}/{page_count}", callback_data=f"admin:topics:queue:{status}:{page}"))
    if page + 1 < page_count:
        nav.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"admin:topics:queue:{status}:{page + 1}"))
    if total > ADMIN_TOPIC_PAGE_SIZE:
        buttons.append(nav)
    buttons.append([InlineKeyboardButton(text="🔙 صف‌ها", callback_data="admin:topics")])
    await c.message.edit_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
    await c.answer()


@admin_router.callback_query(F.data.regexp(r"^admin:topics:view:\d+$"))
async def topic_admin_view(c: CallbackQuery):
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    topic_id=int((c.data or "").rsplit(":",1)[1])
    async with SessionLocal() as session:
        row=(await session.execute(select(TopicSuggestion,func.count(TopicVote.id))
            .outerjoin(TopicVote,TopicVote.topic_id==TopicSuggestion.id)
            .where(TopicSuggestion.id==topic_id).group_by(TopicSuggestion.id))).first()
    if not row: return await c.answer("پیشنهاد پیدا نشد.",show_alert=True)
    topic,votes=row
    markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید و بازکردن رأی‌گیری",callback_data=f"admin:topics:status:{topic_id}:open")],
        [InlineKeyboardButton(text="🗓 انتخاب‌شده برای پنل آینده",callback_data=f"admin:topics:status:{topic_id}:planned")],
        [InlineKeyboardButton(text="🚫 رد پیشنهاد",callback_data=f"admin:topics:status:{topic_id}:declined")],
        [InlineKeyboardButton(text="⏳ بازگرداندن به صف بررسی",callback_data=f"admin:topics:status:{topic_id}:pending")],
        [InlineKeyboardButton(text="🔙 فهرست پیشنهادها",callback_data="admin:topics")],
    ])
    await c.message.edit_text(f"<b>Topic suggestion #{topic.id}</b>\n\n{escape(topic.title)}\n\nStatus: {escape(status_display_label(topic.status))}\nVotes: {int(votes)}",reply_markup=markup)
    await c.answer()


@admin_router.callback_query(F.data.regexp(r"^admin:topics:status:\d+:(open|planned|declined|pending)$"))
async def topic_admin_change_status(c: CallbackQuery):
    if not await _admin(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts=(c.data or "").split(":"); topic_id=int(parts[3]); new_status=parts[4]
    async with SessionLocal() as session:
        topic=await session.get(TopicSuggestion,topic_id,with_for_update=True)
        if not topic: return await c.answer("پیشنهاد پیدا نشد.",show_alert=True)
        old=topic.status; topic.status=new_status
        topic.moderator_telegram_id=int(c.from_user.id)
        topic.moderated_at=utc_now_naive()
        await write_admin_action(session,actor_telegram_id=c.from_user.id,action="topic_suggestion_moderated",
            entity_type="topic_suggestion",entity_id=topic_id,details={"old_status":old,"new_status":new_status})
        await session.commit()
    await c.answer("وضعیت پیشنهاد ذخیره شد.")
    await _render_topic_admin_home(c, answer=False)
