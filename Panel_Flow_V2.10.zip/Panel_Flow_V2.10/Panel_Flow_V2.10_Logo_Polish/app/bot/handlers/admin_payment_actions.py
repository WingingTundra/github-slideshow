from __future__ import annotations

import hashlib
import logging
from html import escape

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.bot.handlers.admin_utils import resolve_upload_path
from app.bot.keyboards import (
    questions_keyboard, retry_payment_keyboard, rejected_payment_closed_panel_keyboard,
    payment_rejection_reasons_keyboard, payment_rejection_confirm_keyboard, payment_review_keyboard,
)
from app.bot.states import AdminReceiptRejectStates
from app.bot.content import support_link_html
from app.config import settings
from app.display_utils import volume_label, status_display_label
from app.bot.text_limits import limit_telegram_html
from app.services.pricing import booking_option_detail_label
from app.db.models import (
    AdminAction, Booking, Event, EventStatus, Payment, PaymentStatus,
    PaymentReviewAttempt, RegistrationStatus, User, UserRole,
)
from app.db.session import SessionLocal
from app.services.admin_audit import write_admin_action
from app.services.channel_status import reconcile_event_channel_status
from app.services.confirmation_ledger import record_confirmed_booking
from app.services.events import registration_is_open, seats_used
from app.services.payment_review import receipt_fingerprint, receipt_review_token, lock_payment_review_rows
from app.services.waitlist import notify_waitlist_capacity_available
from app.time_utils import utc_now_naive

router = Router()
logger = logging.getLogger(__name__)

REJECTION_REASONS = {
    "not_received": "پرداخت دریافت نشده است",
    "amount_mismatch": "مبلغ پرداخت با مبلغ رزرو مطابقت ندارد",
    "unclear": "رسید ناخوانا یا ناقص است",
    "duplicate": "این رسید قبلاً ارسال شده است",
    "other": "دلیل دیگر",
}


def _parse_compact_rejection_callback(data: str, expected: str):
    """Parse compact, Telegram-safe rejection callbacks; accept legacy payloads for cached keyboards."""
    parts = (data or "").split(":")
    try:
        if expected == "reason" and parts[0] == "prr" and len(parts) == 5:
            return int(parts[1]), parts[2], int(parts[3]), parts[4]
        if expected == "custom" and parts[0] == "prc" and len(parts) == 4:
            return int(parts[1]), parts[2], int(parts[3])
        if expected == "confirm" and parts[0] == "prf" and len(parts) == 5:
            return int(parts[1]), parts[2], int(parts[3]), parts[4]
        if expected == "back" and parts[0] == "prb" and len(parts) == 4:
            return int(parts[1]), parts[2], int(parts[3])
        if expected == "reason" and parts[:4] == ["admin", "payment", "reject", "reason"] and len(parts) == 8:
            return int(parts[4]), parts[5], int(parts[6]), parts[7]
        if expected == "custom" and parts[:4] == ["admin", "payment", "reject", "custom"] and len(parts) == 7:
            return int(parts[4]), parts[5], int(parts[6])
        if expected == "confirm" and parts[:4] == ["admin", "payment", "reject", "confirm"] and len(parts) == 8:
            return int(parts[4]), parts[5], int(parts[6]), parts[7]
        if expected == "back" and parts[:4] == ["admin", "payment", "reject", "back"] and len(parts) == 7:
            return int(parts[4]), parts[5], int(parts[6])
    except (TypeError, ValueError):
        return None
    return None


async def allowed(tg_id: int) -> bool:
    """Payment review requires canonical owner/Admin authorization."""
    from app.services.authorization import is_admin_telegram_id
    return await is_admin_telegram_id(tg_id)


async def _pending_payment_matches(payment_id: int, token: str) -> bool:
    async with SessionLocal() as session:
        payment = (await session.execute(
            select(Payment).options(selectinload(Payment.booking))
            .where(Payment.id == int(payment_id))
        )).scalar_one_or_none()
        if not payment or not payment.booking:
            return False
        return bool(
            payment.status == PaymentStatus.PENDING
            and payment.booking.status == RegistrationStatus.PENDING_VERIFICATION
            and (payment.receipt_file or payment.receipt_text)
            and receipt_review_token(payment) == token
        )


async def _render_rejection_confirmation(target, state: FSMContext):
    data = await state.get_data()
    payment_id = int(data.get("reject_payment_id") or 0)
    token = str(data.get("reject_token") or "")
    event_scope = int(data.get("reject_event_scope") or 0)
    category = str(data.get("reject_category") or "")
    reason_text = (str(data.get("reject_reason_text") or "")).strip()
    if not payment_id or not token or category not in REJECTION_REASONS or not reason_text:
        return await target.answer("اطلاعات دلیل رد کامل نیست؛ فرایند را دوباره شروع کنید.")
    if not await _pending_payment_matches(payment_id, token):
        await state.clear()
        return await target.answer("رسید تغییر کرده یا دیگر در انتظار بررسی نیست؛ فهرست را تازه کنید.")
    async with SessionLocal() as session:
        row = (await session.execute(
            select(Payment).options(selectinload(Payment.booking).selectinload(Booking.event))
            .where(Payment.id == payment_id)
        )).scalar_one_or_none()
        if not row or not row.booking or not row.booking.event:
            await state.clear()
            return await target.answer("رزرو یا پنل پیدا نشد؛ فهرست را تازه کنید.")
        panel_label = f"{volume_label(row.booking.event.volume)} — {row.booking.event.title}"
        amount = int(row.amount or 0)
    await state.set_state(AdminReceiptRejectStates.confirming)
    text = (
        "<b>تأیید رد رسید پرداخت</b>\n\n"
        f"پنل: <b>{escape(panel_label)}</b>\n"
        f"شناسه رزرو: <code>{int(row.booking.id)}</code>\n"
        f"مبلغ: {amount:,} تومان\n"
        f"دلیل: <b>{escape(REJECTION_REASONS[category])}</b>\n"
        f"توضیح ثبت‌شونده و ارسالی به کاربر: {escape(reason_text)}\n\n"
        "فقط در صورت تأیید، رسید فعلی رد می‌شود. اگر رسید جایگزین شده باشد، این دکمه بی‌اثر خواهد بود."
    )
    markup = payment_rejection_confirm_keyboard(payment_id, token, event_scope, category)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=markup)
        await target.answer()
    else:
        await target.answer(text, reply_markup=markup)


async def _show_next_pending_payment(
    c: CallbackQuery, *, event_scope: int, reviewed_payment_id: int, reviewed_created_at
) -> bool:
    """Render the next live pending receipt in the same review message.

    Returns True if another receipt was rendered, otherwise renders an explicit
    empty-queue state and returns False. The query is re-run after the decision
    commits, so concurrent reviewers cannot leave a stale receipt on screen.
    """
    async with SessionLocal() as session:
        stmt = (
            select(Payment)
            .join(Payment.booking)
            .options(
                selectinload(Payment.booking).selectinload(Booking.booked_by),
                selectinload(Payment.booking).selectinload(Booking.event),
                selectinload(Payment.booking).selectinload(Booking.participants),
            )
            .where(
                Payment.status == PaymentStatus.PENDING,
                Booking.status == RegistrationStatus.PENDING_VERIFICATION,
                (
                    (Payment.receipt_file.is_not(None) & (Payment.receipt_file != ""))
                    | (Payment.receipt_text.is_not(None) & (Payment.receipt_text != ""))
                ),
            )
            .order_by(Payment.created_at, Payment.id)
        )
        if event_scope:
            stmt = stmt.where(Booking.event_id == int(event_scope))
        rows = list((await session.execute(stmt)).scalars().all())
        if not rows:
            text = (
                "✅ رسید بررسی شد.\n\n"
                + ("برای این پنل رسید دیگری در انتظار بررسی نیست." if event_scope else "رسید دیگری در صف بررسی نیست.")
            )
            empty_queue_buttons = []
            if event_scope:
                empty_queue_buttons.append([InlineKeyboardButton(text="🔙 مدیریت پنل‌ها", callback_data="admin:events")])
            empty_queue_buttons.append([InlineKeyboardButton(text="🔙 مدیریت", callback_data="admin:home")])
            markup = InlineKeyboardMarkup(inline_keyboard=empty_queue_buttons)
        else:
            # Prefer the next receipt in queue order; wrap to the oldest pending
            # item when the reviewed receipt was the last item in the queue.
            later_rows = [
                row for row in rows
                if reviewed_created_at is not None
                and row.created_at is not None
                and (row.created_at, int(row.id)) > (reviewed_created_at, int(reviewed_payment_id))
            ]
            payment = later_rows[0] if later_rows else rows[0]
            booking = payment.booking
            event = booking.event
            owner = booking.booked_by
            current_token = receipt_review_token(payment)
            text = (
                f"<b>پرداخت #{payment.id}</b>\n"
                f"{volume_label(event.volume)} — {escape(event.title)}\n"
                f"صاحب رزرو: {escape(owner.display_name or str(owner.telegram_id))}\n"
                f"تعداد نفرات: {booking.participant_count}\n"
                f"مبلغ: {int(payment.amount or 0):,} تومان\n"
                f"شیوهٔ ثبت‌نام: {escape(booking_option_detail_label(getattr(booking, 'pricing_option', None), base_price=getattr(booking, 'base_price_snapshot', None), alternative_price=getattr(booking, 'alternative_price_snapshot', None)))}\n"
                + (f"🎟 کد تخفیف اعمال‌شده: <code>{escape(booking.discount_code_snapshot)}</code> (تخفیف {int(booking.discount_amount or 0):,} تومان)\n" if booking.discount_code_snapshot else "")
                + f"زمان: {payment.created_at:%Y-%m-%d %H:%M}\n"
                + f"وضعیت: {status_display_label(payment.status)}\n"
                + f"نوع رسید: {'متن' if payment.receipt_text else 'فایل/تصویر'}"
            )
            if payment.receipt_text:
                text += f"\n\n<b>متن رسید:</b>\n{escape(payment.receipt_text)}"
            can_navigate = len(rows) > 1
            if not can_navigate:
                text += "\n\nℹ️ این تنها رسید باقی‌مانده برای بررسی است؛ رسید دیگری در صف نیست."
            markup = payment_review_keyboard(
                int(payment.id), current_token, int(event_scope or 0), can_navigate=can_navigate,
            )
            file_path = resolve_upload_path(payment.receipt_file or "")
            payment_id = int(payment.id)

    await c.message.edit_text(limit_telegram_html(text), reply_markup=markup, disable_web_page_preview=True)
    if rows:
        if file_path:
            try:
                await c.bot.send_document(c.from_user.id, FSInputFile(file_path), caption=f"🧾 رسید پرداخت #{payment_id}")
            except Exception:
                logger.exception("Could not send next pending receipt file; payment_id=%s", payment_id)
        elif not payment.receipt_text:
            await c.message.answer("رسید ذخیره‌شده پیدا نشد.")
        await c.answer("رسید قبلی بررسی شد؛ رسید بعدی نمایش داده شد.")
        return True
    await c.answer("رسید بررسی شد؛ صف پرداخت‌ها خالی است.")
    return False


async def review(
    c: CallbackQuery,
    approve: bool,
    *,
    data_override: str | None = None,
    reason_category: str | None = None,
    reason_text: str | None = None,
):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    callback_data = data_override or (c.data or "")
    parts = callback_data.split(":")
    try:
        payment_id = int(parts[3])
        token = parts[4]
        event_scope = int(parts[5]) if len(parts) > 5 else 0
        if payment_id <= 0 or event_scope < 0:
            raise ValueError
    except (ValueError, IndexError):
        return await c.answer("دکمه نامعتبر است؛ فهرست پرداخت‌ها را تازه کنید.", show_alert=True)

    if not approve:
        reason_category = str(reason_category or "")
        reason_text = (str(reason_text or "").strip())
        if reason_category not in REJECTION_REASONS or not reason_text or len(reason_text) > 500:
            return await c.answer("دلیل رد نامعتبر است؛ فرایند را دوباره شروع کنید.", show_alert=True)

    async with SessionLocal() as session:
        payment = (await session.execute(
            select(Payment).options(
                selectinload(Payment.booking).selectinload(Booking.event),
                selectinload(Payment.booking).selectinload(Booking.booked_by),
            ).where(Payment.id == payment_id)
        )).scalar_one_or_none()
        if not payment or not payment.booking or not payment.booking.event:
            return await c.answer("پرداخت یا رزرو پیدا نشد.", show_alert=True)

        payment, booking, event = await lock_payment_review_rows(session, payment_id)
        if not payment or not booking or not event:
            return await c.answer("پرداخت، رزرو یا پنل پیدا نشد.", show_alert=True)
        current_token = receipt_review_token(payment)
        fingerprint = receipt_fingerprint(payment)
        if (
            payment.status != PaymentStatus.PENDING
            or booking.status != RegistrationStatus.PENDING_VERIFICATION
            or current_token != token
            or not (payment.receipt_file or payment.receipt_text)
        ):
            return await c.answer("رسید تغییر کرده یا قبلاً بررسی شده است؛ فهرست را تازه کنید.", show_alert=True)

        if approve and (event.status != EventStatus.PUBLISHED or event.archived):
            return await c.answer("این پنل دیگر فعال نیست؛ تأیید پرداخت مجاز نیست. در صورت نیاز، رسید را رد کنید.", show_alert=True)

        admin = (await session.execute(select(User).where(User.telegram_id == c.from_user.id))).scalar_one_or_none()
        if not admin and c.from_user.id in settings.super_admin_id_set:
            admin = User(telegram_id=c.from_user.id, role=UserRole.SUPER_ADMIN)
            session.add(admin)
            await session.flush()
        if not admin:
            return await c.answer("حساب مدیر پیدا نشد.", show_alert=True)

        now = utc_now_naive()
        reviewed_created_at = payment.created_at
        previous_status = booking.status
        payment.status = PaymentStatus.APPROVED if approve else PaymentStatus.REJECTED
        payment.reviewed_at = now
        payment.reviewed_by = admin.id
        booking.status = RegistrationStatus.CONFIRMED if approve else RegistrationStatus.REJECTED
        booking.confirmed_at = now if approve else None
        booking.expires_at = None
        if approve and previous_status != RegistrationStatus.CONFIRMED:
            await record_confirmed_booking(session, booking, confirmed_at=now)
        if approve and int(payment.amount or 0) > 0:
            from app.services.community import record_paid_panel_award
            await record_paid_panel_award(session, booking, payment)

        prior_attempts = int((await session.execute(
            select(func.count(PaymentReviewAttempt.id)).where(PaymentReviewAttempt.payment_id == payment_id)
        )).scalar_one())
        session.add(PaymentReviewAttempt(
            booking_id=int(booking.id), payment_id=payment_id, receipt_fingerprint=fingerprint,
            decision="approved" if approve else "rejected",
            reason_category=None if approve else reason_category,
            reason_text=None if approve else reason_text,
            reviewer_telegram_id=int(c.from_user.id), attempt_number=prior_attempts + 1, reviewed_at=now,
        ))
        await write_admin_action(
            session, actor_telegram_id=c.from_user.id,
            action="receipt_approved" if approve else "receipt_rejected",
            entity_type="payment", entity_id=payment_id,
            details={"booking_id": int(booking.id), "event_id": int(event.id), "reason_category": reason_category, "reason": reason_text},
        )
        owner_id = int(booking.booked_by.telegram_id)
        title = str(event.title)
        volume = str(event.volume)
        bid = int(booking.id)
        pdf_path = resolve_upload_path(event.questions_pdf_path or "")
        amount = int(payment.amount)
        event_id = int(event.id)
        event_state_at_review = event.status
        event_archived = bool(event.archived)
        await session.commit()

    # Use the shared capacity/waitlist reconciler after the rejection has committed.
    # It reopens only capacity-closed published panels and never overrides manual closure.
    if not approve:
        try:
            await notify_waitlist_capacity_available(c.bot, event_id)
        except Exception:
            logger.exception("Capacity/waitlist reconciliation failed after receipt rejection for event_id=%s", event_id)

    try:
        await reconcile_event_channel_status(c.bot, event_id)
    except Exception:
        logger.exception("Channel reconciliation failed after payment review for event_id=%s", event_id)

    if approve:
        try:
            from app.services.community import unlock_eligible_achievements
            async with SessionLocal() as session:
                await unlock_eligible_achievements(session, owner_id)
                await session.commit()
        except Exception:
            logger.exception("Could not evaluate achievements after payment approval for event_id=%s", event_id)
        message = (
            "✅ <b>پرداخت شما با موفقیت تأیید شد.</b>\n\n"
            f"ثبت‌نام شما برای <b>{volume_label(volume)} — {escape(title)}</b> با موفقیت نهایی شد.\n\n"
            "منتظرتون هستیم!"
            + ("\n\nفایل سؤالات این پنل هم در دسترس شماست." if pdf_path else "")
        )
        try:
            await c.bot.send_message(owner_id, message, reply_markup=questions_keyboard(bid) if pdf_path else None)
        except Exception:
            logger.exception("Could not notify user after approved payment; booking_id=%s", bid)
    else:
        async with SessionLocal() as session:
            current_event = await session.get(Event, event_id)
            available = False
            if current_event and current_event.status == EventStatus.PUBLISHED and not current_event.archived:
                used = await seats_used(session, event_id)
                available = registration_is_open(current_event) and used < int(current_event.capacity)
        reason_for_user = reason_text or REJECTION_REASONS.get(reason_category or "other", "دلیل ثبت‌نشده")
        participant_message = (
            f"❌ رسید پرداخت شما برای پنل <b>{escape(volume_label(volume) + ' — ' + title)}</b> تأیید نشد.\n\n"
            f"دلیل: <b>{escape(reason_for_user)}</b>\n"
            f"مبلغ رزرو: {amount:,} تومان\n\n"
            + ("می‌توانید رسید دیگری ارسال کنید یا رزرو خود را لغو کنید." if available else "در حال حاضر ثبت‌نام مجدد برای این پنل ممکن نیست؛ وضعیت پنل/ظرفیت اجازهٔ ارسال رسید جایگزین نمی‌دهد. در صورت نیاز، رزرو را لغو یا با پشتیبانی تماس بگیرید.")
        )
        try:
            await c.bot.send_message(
                owner_id, participant_message,
                reply_markup=retry_payment_keyboard(bid) if available else rejected_payment_closed_panel_keyboard(bid),
            )
        except Exception:
            logger.exception("Could not notify user after rejected payment; booking_id=%s", bid)

    try:
        await _show_next_pending_payment(
            c, event_scope=event_scope, reviewed_payment_id=payment_id,
            reviewed_created_at=reviewed_created_at,
        )
    except Exception:
        logger.exception("Could not advance admin receipt screen after review; payment_id=%s", payment_id)
        try:
            continue_callback = f"admin:event:payments:{event_scope}" if event_scope else "admin:pending_payments:page:0"
            await c.message.edit_text(
                ("✅ پرداخت تأیید شد." if approve else "❌ رسید رد شد و دلیل ثبت شد.") + "\n\nبرای ادامه، صف رسیدها را دوباره باز کنید.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="➡️ باز کردن صف رسیدها", callback_data=continue_callback)],
                    [InlineKeyboardButton(text="🔙 بازگشت به مدیریت", callback_data="admin:home")],
                ]),
            )
        except Exception:
            logger.exception("Could not show receipt-review fallback; payment_id=%s", payment_id)
        await c.answer("تغییر وضعیت ثبت شد، اما نمایش رسید بعدی ناموفق بود.", show_alert=True)


@router.callback_query(F.data.startswith("admin:payment:approve:"))
async def approve(c: CallbackQuery):
    return await review(c, True)


@router.callback_query(F.data.regexp(r"^admin:payment:reject:\d+:[0-9a-f]{12}:\d+$"))
async def reject_start(c: CallbackQuery, state: FSMContext):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parts = (c.data or "").split(":")
    try:
        payment_id, token, event_scope = int(parts[3]), parts[4], int(parts[5])
    except (ValueError, IndexError):
        return await c.answer("دکمه نامعتبر است.", show_alert=True)
    if not await _pending_payment_matches(payment_id, token):
        return await c.answer("رسید تغییر کرده یا قبلاً بررسی شده است؛ فهرست را تازه کنید.", show_alert=True)
    await state.clear()
    await state.update_data(reject_payment_id=payment_id, reject_token=token, reject_event_scope=event_scope)
    await state.set_state(AdminReceiptRejectStates.confirming)
    await c.message.edit_text(
        "<b>دلیل رد رسید را انتخاب کنید.</b>\n\nهیچ تغییری در پرداخت یا رزرو انجام نمی‌شود تا دلیل را تأیید کنید.",
        reply_markup=payment_rejection_reasons_keyboard(payment_id, token, event_scope),
    )
    await c.answer()


@router.callback_query(F.data.regexp(r"^(prr:\d+:[0-9a-f]{12}:\d+:(not_received|amount_mismatch|unclear|duplicate)|admin:payment:reject:reason:\d+:[0-9a-f]{12}:\d+:(not_received|amount_mismatch|unclear|duplicate))$"))
async def reject_preset_reason(c: CallbackQuery, state: FSMContext):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parsed = _parse_compact_rejection_callback(c.data or "", "reason")
    if not parsed:
        return await c.answer("دلیل انتخاب‌شده نامعتبر است.", show_alert=True)
    payment_id, token, event_scope, category = parsed
    data = await state.get_data()
    if data.get("reject_payment_id") != payment_id or data.get("reject_token") != token:
        return await c.answer("نشست بررسی منقضی شده است؛ دوباره رسید را باز کنید.", show_alert=True)
    await state.update_data(reject_event_scope=event_scope, reject_category=category, reject_reason_text=REJECTION_REASONS[category])
    await _render_rejection_confirmation(c, state)


@router.callback_query(F.data.regexp(r"^(prc:\d+:[0-9a-f]{12}:\d+|admin:payment:reject:custom:\d+:[0-9a-f]{12}:\d+)$"))
async def reject_custom_reason_start(c: CallbackQuery, state: FSMContext):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parsed = _parse_compact_rejection_callback(c.data or "", "custom")
    if not parsed:
        return await c.answer("دکمه نامعتبر است.", show_alert=True)
    payment_id, token, event_scope = parsed
    data = await state.get_data()
    if data.get("reject_payment_id") != payment_id or data.get("reject_token") != token or not await _pending_payment_matches(payment_id, token):
        return await c.answer("نشست بررسی منقضی شده یا رسید تغییر کرده است.", show_alert=True)
    await state.update_data(reject_event_scope=event_scope)
    await state.set_state(AdminReceiptRejectStates.waiting_custom_reason)
    await c.message.edit_text(
        "توضیح دلیل رد را در ۳ تا ۵۰۰ کاراکتر بنویسید. این توضیح به کاربر نمایش داده می‌شود؛ اطلاعات داخلی را وارد نکنید.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ انصراف", callback_data="admin:payment:reject:cancel")]]),
    )
    await c.answer()


@router.message(AdminReceiptRejectStates.waiting_custom_reason, F.text, ~F.text.startswith("/"))
async def reject_custom_reason_receive(message: Message, state: FSMContext):
    if not await allowed(message.from_user.id):
        await state.clear()
        return await message.answer("دسترسی مجاز نیست.")
    reason = (message.text or "").strip()
    if len(reason) < 3 or len(reason) > 500:
        return await message.answer("دلیل باید بین ۳ تا ۵۰۰ کاراکتر باشد؛ فاصلهٔ خالی کافی نیست.")
    await state.update_data(reject_category="other", reject_reason_text=reason)
    await _render_rejection_confirmation(message, state)


@router.callback_query(F.data.regexp(r"^(prb:\d+:[0-9a-f]{12}:\d+|admin:payment:reject:back:\d+:[0-9a-f]{12}:\d+)$"))
async def reject_reason_back(c: CallbackQuery, state: FSMContext):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parsed = _parse_compact_rejection_callback(c.data or "", "back")
    if not parsed:
        return await c.answer("دکمه نامعتبر است.", show_alert=True)
    payment_id, token, event_scope = parsed
    data = await state.get_data()
    if data.get("reject_payment_id") != payment_id or data.get("reject_token") != token or not await _pending_payment_matches(payment_id, token):
        await state.clear()
        return await c.answer("نشست بررسی منقضی شده یا رسید تغییر کرده است.", show_alert=True)
    await state.update_data(reject_event_scope=event_scope, reject_category=None, reject_reason_text=None)
    await state.set_state(AdminReceiptRejectStates.confirming)
    await c.message.edit_text("<b>دلیل رد رسید را انتخاب کنید.</b>", reply_markup=payment_rejection_reasons_keyboard(payment_id, token, event_scope))
    await c.answer()


@router.callback_query(F.data.regexp(r"^(prf:\d+:[0-9a-f]{12}:\d+:(not_received|amount_mismatch|unclear|duplicate|other)|admin:payment:reject:confirm:\d+:[0-9a-f]{12}:\d+:(not_received|amount_mismatch|unclear|duplicate|other))$"))
async def reject_confirm(c: CallbackQuery, state: FSMContext):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    parsed = _parse_compact_rejection_callback(c.data or "", "confirm")
    if not parsed:
        return await c.answer("دکمه نامعتبر است.", show_alert=True)
    payment_id, token, event_scope, category = parsed
    data = await state.get_data()
    if (
        await state.get_state() != AdminReceiptRejectStates.confirming.state
        or data.get("reject_payment_id") != payment_id
        or data.get("reject_token") != token
        or data.get("reject_category") != category
        or int(data.get("reject_event_scope") or 0) != event_scope
    ):
        return await c.answer("نشست تأیید منقضی شده است؛ رسید را دوباره باز کنید.", show_alert=True)
    reason_text = (str(data.get("reject_reason_text") or "")).strip()
    if not reason_text:
        return await c.answer("دلیل رد ثبت نشده است.", show_alert=True)
    await review(
        c, False,
        data_override=f"admin:payment:reject:{payment_id}:{token}:{event_scope}",
        reason_category=category, reason_text=reason_text,
    )
    await state.clear()


@router.callback_query(F.data == "admin:payment:reject:cancel")
async def reject_cancel(c: CallbackQuery, state: FSMContext):
    if not await allowed(c.from_user.id):
        return await c.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.clear()
    await c.message.edit_text("رد رسید لغو شد؛ هیچ تغییری در پرداخت یا رزرو ایجاد نشد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 مدیریت", callback_data="admin:home")],
    ]))
    await c.answer()
