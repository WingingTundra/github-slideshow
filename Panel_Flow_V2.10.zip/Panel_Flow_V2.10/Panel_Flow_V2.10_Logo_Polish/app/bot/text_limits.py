"""Helpers for keeping HTML-formatted Telegram messages within Bot API limits."""
from __future__ import annotations

import html
import re

# Telegram applies the text limit after parsing HTML entities. Counting UTF-16
# code units as well as keeping a safety margin avoids emoji-heavy messages that
# fit Python's len() but exceed Telegram's message limit.
DEFAULT_SAFE_TEXT_LIMIT = 3800
_TOKEN_RE = re.compile(
    r"(<[^>]*>|&(?:#[0-9]+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]+);|.)",
    re.DOTALL,
)
_TAG_RE = re.compile(r"^<\s*(/?)\s*([A-Za-z][A-Za-z0-9]*)")


def _utf16_units(value: str) -> int:
    return len(value.encode("utf-16-le")) // 2


def _visible_utf16_units(value: str) -> int:
    total = 0
    for match in _TOKEN_RE.finditer(value):
        token = match.group(0)
        if token.startswith("<") and token.endswith(">"):
            continue
        visible = html.unescape(token) if token.startswith("&") and token.endswith(";") else token
        total += _utf16_units(visible)
    return total


def limit_telegram_html(value: str, max_units: int = DEFAULT_SAFE_TEXT_LIMIT) -> str:
    """Truncate a generated Telegram HTML message without cutting tags/entities.

    The caller must HTML-escape all user-provided values before interpolating
    them. Existing short messages are returned unchanged. Truncated messages end
    with an ellipsis and all opened HTML tags are closed.
    """
    if max_units < 2:
        raise ValueError("max_units must be at least 2")
    if _visible_utf16_units(value) <= max_units:
        return value

    budget = max_units - 1  # reserve one UTF-16 unit for the ellipsis
    output: list[str] = []
    open_tags: list[str] = []
    used = 0

    for match in _TOKEN_RE.finditer(value):
        token = match.group(0)
        if token.startswith("<") and token.endswith(">"):
            tag_match = _TAG_RE.match(token)
            if tag_match:
                closing, name = tag_match.groups()
                name = name.lower()
                if closing:
                    output.append(token)
                    # Generated messages are balanced; tolerate a malformed
                    # fragment without accidentally closing an unrelated tag.
                    for index in range(len(open_tags) - 1, -1, -1):
                        if open_tags[index] == name:
                            del open_tags[index:]
                            break
                elif token.rstrip().endswith("/>"):
                    output.append(token)
                else:
                    output.append(token)
                    open_tags.append(name)
            else:
                output.append(token)
            continue

        visible = html.unescape(token) if token.startswith("&") and token.endswith(";") else token
        units = _utf16_units(visible)
        if used + units > budget:
            break
        output.append(token)
        used += units

    output.append("…")
    output.extend(f"</{tag}>" for tag in reversed(open_tags))
    return "".join(output)


def telegram_html_visible_units(value: str) -> int:
    """Return Telegram-visible UTF-16 units in an HTML-formatted string.

    This lets callers reserve room for important trailing content before
    shortening a long user-authored section such as a panel description.
    """
    return _visible_utf16_units(value)
