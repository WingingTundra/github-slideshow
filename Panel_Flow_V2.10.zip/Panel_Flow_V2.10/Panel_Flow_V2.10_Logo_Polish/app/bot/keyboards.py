from app.display_utils import truncate_display_text, volume_label
from aiogram.types import CopyTextButton, InlineKeyboardMarkup, InlineKeyboardButton


def persistent_main_keyboard(*, include_contact: bool = False, input_field_placeholder: str | None = None):
    """Opt-in compact native menu. Never inject global navigation during FSM forms."""
    from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

    if include_contact:
        return ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="📱 ارسال شمارهٔ خودم", request_contact=True)]],
            resize_keyboard=True,
            one_time_keyboard=True,
            selective=False,
            input_field_placeholder="ارسال شمارهٔ تماس",
        )
    rows = [
        [KeyboardButton(text="🏠 پنل‌های پیش‌رو")],
        [KeyboardButton(text="🎟 ثبت‌نام‌های من")],
        [KeyboardButton(text="👤 پروفایل من"), KeyboardButton(text="📄 سؤالات پنل‌ها")],
        [KeyboardButton(text="📚 پنل‌های گذشته"), KeyboardButton(text="💡 پیشنهادها")],
        [KeyboardButton(text="📝 ثبت نظر")],
        [KeyboardButton(text="🏆 لیدربورد و چالش‌ها")],
        [KeyboardButton(text="💬 جامعه و دربارهٔ ما")],
    ]
    return ReplyKeyboardMarkup(
        keyboard=rows, resize_keyboard=True, is_persistent=True,
        one_time_keyboard=False, selective=False,
        input_field_placeholder=input_field_placeholder or "یک بخش را انتخاب کنید",
    )


def hide_reply_keyboard():
    """Hide Telegram's persistent reply keyboard without changing any inline menu."""
    from aiogram.types import ReplyKeyboardRemove
    return ReplyKeyboardRemove(remove_keyboard=True, selective=False)


def main_menu():
    """Focused main menu: key tasks first, secondary pages next, community hubs last."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏠 پنل‌های پیش‌رو", callback_data="user:events")],
        [InlineKeyboardButton(text="🎟 ثبت‌نام‌های من", callback_data="user:bookings")],
        [InlineKeyboardButton(text="👤 پروفایل من", callback_data="user:profile"),
         InlineKeyboardButton(text="📄 سؤالات پنل‌ها", callback_data="user:questions")],
        [InlineKeyboardButton(text="📚 پنل‌های گذشته", callback_data="user:pastpanels"),
         InlineKeyboardButton(text="💡 پیشنهادها", callback_data="user:suggestions")],
        [InlineKeyboardButton(text="📝 ثبت نظر", callback_data="user:reviews")],
        [InlineKeyboardButton(text="🏆 لیدربورد و چالش‌ها", callback_data="community:home")],
        [InlineKeyboardButton(text="💬 جامعه و دربارهٔ ما", callback_data="user:community_about")],
    ])


def suggestions_keyboard(*, question_enabled: bool = True, topics_enabled: bool = True):
    """Keep topic suggestion/voting together, followed by question suggestions and Back."""
    # The topic-voting screen already contains its own "suggest topic" action.
    # One top-level destination therefore exposes both actions without duplication.
    rows = []
    if topics_enabled:
        rows.append([InlineKeyboardButton(text="💡 پیشنهاد موضوع و رأی‌گیری", callback_data="user:topics")])
    if question_enabled:
        rows.append([InlineKeyboardButton(text="❓ پیشنهاد سؤال", callback_data="user:submit_question")])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="user:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_menu():
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🔙 بازگشت", callback_data="user:home")]])


def profile_keyboard():
    """Actions available from the user's own profile screen."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📱 تغییر شماره", callback_data="user:profile:edit_phone"),
         InlineKeyboardButton(text="✏️ تغییر نام", callback_data="user:profile:edit_name")],
        [InlineKeyboardButton(text="🤝 کد معرفی من", callback_data="user:profile:referral")],
        [InlineKeyboardButton(text="🔙 بازگشت به منوی اصلی", callback_data="user:home")],
    ])



def referral_choice_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ بله، کد دارم", callback_data="user:referral:yes")],
        [InlineKeyboardButton(text="خیر، کدی ندارم", callback_data="user:referral:no")],
    ])


def referral_code_input_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="ادامه بدون کد معرفی", callback_data="user:referral:skip")],
    ])


def referral_code_display_keyboard(telegram_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 کپی کد معرفی", copy_text=CopyTextButton(text=str(int(telegram_id))))],
        [InlineKeyboardButton(text="🔙 بازگشت به پروفایل", callback_data="user:profile")],
    ])

def profile_edit_cancel_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ انصراف از تغییر", callback_data="user:profile:cancel")],
    ])


def event_buttons(
    event_id: int,
    can_register: bool,
    waitlist: bool = False,
    map_url: str | None = None,
    waitlisted: bool = False,
    return_page: int = 0,
):
    rows = []
    if map_url:
        rows.append([InlineKeyboardButton(text="📍 مشاهده موقعیت", url=map_url)])
    if can_register:
        rows.append([InlineKeyboardButton(text="🎟 ثبت‌نام در این پنل", callback_data=f"event:register:{event_id}")])
    elif waitlist and not waitlisted:
        rows.append([InlineKeyboardButton(text="📝 عضویت در لیست انتظار", callback_data=f"event:waitlist:{event_id}")])
    if waitlisted:
        rows.append([InlineKeyboardButton(text="❌ خروج از لیست انتظار", callback_data=f"user:waitlist:leave:{event_id}")])
    back_callback = f"user:events:page:{max(0, int(return_page))}" if int(return_page) > 0 else "user:events"
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به پنل‌ها", callback_data=back_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def available_events_keyboard(events, page: int = 0):
    """Give every panel its own full-width row to keep Telegram keyboard layout stable."""
    rows = []
    for event in events:
        # One panel per row avoids side-by-side button sizing/wrapping issues on mobile.
        title = truncate_display_text(event.title or "پنل", 25)
        label = truncate_display_text(f"📌 {volume_label(event.volume)} · {title}", 64)
        rows.append([
            InlineKeyboardButton(
                text=label[:64],
                callback_data=f"event:open:{event.id}:{max(0, int(page))}",
            )
        ])
    rows.append([InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def duplicate_registration_keyboard(event_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ ثبت‌نام مجدد", callback_data=f"event:register_again:{event_id}")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data="user:home")],
    ])



def booking_count_keyboard(max_count: int):
    """Compact inline choices for booking one, two, or three attendees."""
    maximum = max(1, min(3, int(max_count)))
    labels = {1: "👤 ۱ نفر", 2: "👥 ۲ نفر", 3: "👥 ۳ نفر"}
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=labels[count], callback_data=f"booking:count:{count}")
        for count in range(1, maximum + 1)
    ]])

def booking_confirmation_keyboard():
    """Keep the primary confirmation and a clearly visible cancellation action."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید و ثبت‌نام", callback_data="booking:confirm")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data="booking:cancel")],
    ])


def booking_pricing_keyboard(base_price: int, alternative_price: int):
    """Compact, neutral choices; both options are equally valid."""
    def amount(value: int) -> str:
        # Persian thousands separator and numerals make prices easy to scan in RTL.
        return f"{int(value):,}".replace(",", "٬").translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"{amount(base_price)} تومان + سفارش از منوی کافه", callback_data="booking:pricing:base")],
        [InlineKeyboardButton(text=f"{amount(alternative_price)} تومان بدون سفارش اجباری از کافه", callback_data="booking:pricing:without_cafe")],
    ])


def booking_edit_keyboard(*, has_alternative_price: bool, has_discount: bool = True):
    rows = [[InlineKeyboardButton(text="👥 ویرایش نام شرکت‌کنندگان", callback_data="booking:edit:names")],
            [InlineKeyboardButton(text="📱 ویرایش شماره تماس", callback_data="booking:edit:phone")]]
    extra = []
    if has_alternative_price:
        extra.append(InlineKeyboardButton(text="💰 تغییر گزینهٔ قیمت", callback_data="booking:edit:price"))
    if has_discount:
        extra.append(InlineKeyboardButton(text="🎟 تغییر کد تخفیف", callback_data="booking:edit:discount"))
    if extra:
        rows.append(extra)
    rows.append([InlineKeyboardButton(text="↩️ بازگشت به خلاصه", callback_data="booking:edit:summary")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def booking_edit_participants_keyboard(participants):
    rows = []
    for index, participant in enumerate(participants):
        name = " ".join((str(participant.get("first_name") or ""), str(participant.get("last_name") or ""))).strip()
        rows.append([InlineKeyboardButton(text=f"ویرایش نفر {index + 1}: {name[:32]}", callback_data=f"booking:edit:name:{index}")])
    rows.append([InlineKeyboardButton(text="↩️ بازگشت", callback_data="booking:edit:start")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def profile_phone_keyboard():
    """Use a compact, one-time contact-only keyboard during phone collection."""
    return persistent_main_keyboard(
        include_contact=True,
        input_field_placeholder="شماره را وارد کنید یا از منوی پایین انتخاب کنید",
    )


def payment_card_keyboard(card_number: str | None):
    """Return the existing clipboard-copy button for a configured card number."""
    value = str(card_number or "").strip()
    if not value or len(value) > 256:
        return None
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="کپی شماره کارت", copy_text=CopyTextButton(text=value))
    ]])


def receipt_upload_keyboard(card_number: str | None, booking_id: int):
    """Keep card-copy and cancel actions directly on the receipt-upload message."""
    rows = []
    value = str(card_number or "").strip()
    if value and len(value) <= 256:
        rows.append([InlineKeyboardButton(text="کپی شماره کارت", copy_text=CopyTextButton(text=value))])
    rows.append([InlineKeyboardButton(text="❌ لغو ارسال رسید", callback_data=f"user:payment:cancel_receipt:{int(booking_id)}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def receipt_cancel_reply_keyboard():
    """A native keyboard button shown below Telegram's message composer."""
    from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="❌ لغو ارسال رسید")]],
        resize_keyboard=True,
        one_time_keyboard=False,
        is_persistent=True,
        input_field_placeholder="رسید را ارسال کنید یا پرداخت را لغو کنید",
    )


def admin_event_creation_reply_keyboard(*, show_back: bool = True):
    """Native Reply Keyboard controls for each step of the panel-creation wizard."""
    from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
    row = []
    if show_back:
        row.append(KeyboardButton(text="⬅️ مرحلهٔ قبل"))
    row.append(KeyboardButton(text="❌ لغو ایجاد"))
    return ReplyKeyboardMarkup(
        keyboard=[row], resize_keyboard=True, one_time_keyboard=False,
        is_persistent=True, input_field_placeholder="پاسخ مرحله را وارد کنید",
    )

def community_keyboard(values):
    """Official public links, resolved from persistent app settings per request."""
    rows = []
    if values.get("community_channel_url"):
        rows.append([InlineKeyboardButton(text="📢 Telegram Channel", url=values["community_channel_url"])])
    if values.get("community_group_url"):
        rows.append([InlineKeyboardButton(text="👥 Telegram Group", url=values["community_group_url"])])
    if values.get("community_instagram_url"):
        rows.append([InlineKeyboardButton(text="📷 Instagram", url=values["community_instagram_url"])])
    if values.get("community_website_url"):
        rows.append([InlineKeyboardButton(text="🌐 Website", url=values["community_website_url"])])
    rows.append([InlineKeyboardButton(text="🏠 منوی اصلی", callback_data="user:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_settings_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👥 لینک گروه تلگرام", callback_data="admin:settings:edit:community_group_url"),
         InlineKeyboardButton(text="📢 لینک کانال تلگرام", callback_data="admin:settings:edit:community_channel_url")],
        [InlineKeyboardButton(text="📷 لینک اینستاگرام", callback_data="admin:settings:edit:community_instagram_url"),
         InlineKeyboardButton(text="🌐 لینک وب‌سایت", callback_data="admin:settings:edit:community_website_url")],
        [InlineKeyboardButton(text="💳 اطلاعات کارت بانکی", callback_data="admin:settings:edit:card")],
        [InlineKeyboardButton(text="🔗 لینک و QR صفحهٔ About", callback_data="admin:settings:about_qr")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:settings:hub")],
    ])


def admin_settings_hub_keyboard():
    """Grouped admin tools: business configuration and operational management."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⚙️ تنظیمات عمومی ربات", callback_data="admin:settings")],
        [InlineKeyboardButton(text="🛡 نقش‌ها و میزبان‌ها", callback_data="admin:console:roles"),
         InlineKeyboardButton(text="🚫 دسترسی کاربران", callback_data="admin:users:manage")],
        [InlineKeyboardButton(text="👤 مدیریت کاربران", callback_data="admin:console:users")],
        [InlineKeyboardButton(text="🔙 منوی اصلی مدیریت", callback_data="admin:home")],
    ])


def admin_settings_cancel_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="❌ انصراف", callback_data="admin:settings:cancel")
    ]])

def admin_settings_link_confirm_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید و ذخیره", callback_data="admin:settings:confirm_link")],
        [InlineKeyboardButton(text="✏️ ویرایش", callback_data="admin:settings:edit_pending_link"), InlineKeyboardButton(text="❌ انصراف", callback_data="admin:settings:cancel")],
    ])

def admin_settings_card_confirm_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید و ذخیره اطلاعات کارت", callback_data="admin:settings:confirm_card")],
        [InlineKeyboardButton(text="✏️ تغییر شماره کارت", callback_data="admin:settings:edit_pending_card_number"), InlineKeyboardButton(text="✏️ تغییر نام", callback_data="admin:settings:edit_pending_cardholder")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data="admin:settings:cancel")],
    ])


def admin_menu():
    """Prioritize daily operations and keep settings as the final destination."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ ایجاد پنل جدید", callback_data="admin:event:create")],
        [InlineKeyboardButton(text="📋 مدیریت پنل‌ها", callback_data="admin:events")],
        [InlineKeyboardButton(text="📣 اطلاع‌رسانی‌ها", callback_data="admin:announcements"),
         InlineKeyboardButton(text="🧾 مشاهدهٔ رسیدها", callback_data="admin:pending_payments:page:0")],
        [InlineKeyboardButton(text="🎟 کدهای تخفیف", callback_data="admin:discounts"),
         InlineKeyboardButton(text="🎟 درخواست‌های تخفیف", callback_data="admin:discount:requests:page:0")],
        [InlineKeyboardButton(text="📥 مرکز رسیدگی", callback_data="admin:attention")],
        [InlineKeyboardButton(text="🎯 مدیریت چالش‌ها", callback_data="admin:community")],
        [InlineKeyboardButton(text="👥 مشارکت و بازخورد کاربران", callback_data="admin:content:hub")],
        [InlineKeyboardButton(text="📚 آرشیو پنل‌ها", callback_data="admin:archives:page:0"),
         InlineKeyboardButton(text="📊 آمار و خروجی‌ها", callback_data="admin:reports:hub")],
        [InlineKeyboardButton(text="📊 داشبورد مدیریتی", callback_data="admin:dashboard")],
        [InlineKeyboardButton(text="🧰 ابزارهای تکمیلی", callback_data="admin:v77:home")],
        [InlineKeyboardButton(text="⚙️ تنظیمات و مدیریت بات", callback_data="admin:settings:hub")],
    ])


def admin_content_hub_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📝 بررسی پنل‌های ارسالی", callback_data="admin:console:reviews"),
         InlineKeyboardButton(text="📝 نظرات کاربران", callback_data="admin:reviews")],
        [InlineKeyboardButton(text="❓ سؤالات پیشنهادی", callback_data="admin:questions"),
         InlineKeyboardButton(text="🗳 پیشنهاد موضوع‌ها", callback_data="admin:topics")],
        [InlineKeyboardButton(text="🔙 بازگشت به منوی مدیریت", callback_data="admin:home")],
    ])


def admin_reports_hub_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 آمار کلی", callback_data="admin:stats"),
         InlineKeyboardButton(text="📜 تاریخچهٔ اقدامات مدیریت", callback_data="admin:audit:page:0")],
        [InlineKeyboardButton(text="👥 خروجی کاربران", callback_data="admin:users:export"),
         InlineKeyboardButton(text="🤝 خروجی معرفی‌ها", callback_data="admin:referrals:export")],
        [InlineKeyboardButton(text="💸 پرونده‌های مالی پنل‌های لغوشده", callback_data="admin:cancellation_cases")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")],
    ])


def admin_user_access_keyboard():
    """Small, dedicated admin screen for block/unblock actions."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚫 مسدود کردن با شناسه تلگرام", callback_data="admin:users:block")],
        [InlineKeyboardButton(text="📋 فهرست کاربران مسدودشده", callback_data="admin:users:blocked:page:0")],
        [InlineKeyboardButton(text="🔙 بازگشت به منوی مدیریت", callback_data="admin:home")],
    ])


def admin_block_input_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:users:manage")],
    ])


def admin_block_user_confirmation_keyboard(telegram_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⛔ بله، دسترسی مسدود شود", callback_data=f"admin:users:block:confirm:{telegram_id}")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:users:manage")],
    ])


def admin_unblock_user_confirmation_keyboard(telegram_id: int, page: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ بله، رفع مسدودیت شود", callback_data=f"admin:users:unblock:confirm:{telegram_id}:{page}")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data=f"admin:users:blocked:page:{page}")],
    ])

def alternative_price_keyboard(*, include_keep: bool = False, for_edit: bool = False):
    """Navigation only; users disable the optional price by entering '-' or '0'."""
    rows = []
    if include_keep:
        rows.append([InlineKeyboardButton(text="✅ حفظ قیمت فعلی", callback_data="admin:event:edit:alternative:keep")])
    if not for_edit:
        rows.append([InlineKeyboardButton(text="⬅️ مرحلهٔ قبل", callback_data="admin:event:create:back"), InlineKeyboardButton(text="❌ لغو ایجاد", callback_data="admin:event:create:cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_event_creation_step_keyboard(*, show_back: bool = True, wizard_id: str | None = None):
    """Native Back/Cancel controls below the composer; no buttons attached to prompts."""
    return admin_event_creation_reply_keyboard(show_back=show_back)


def event_creation_choice_keyboard(wizard_id: str | None = None):
    suffix = f":{wizard_id}" if wizard_id else ""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📝 ذخیره به‌صورت پیش‌نویس", callback_data=f"admin:event:create:draft{suffix}")],
        [InlineKeyboardButton(text="🚀 انتشار و بازکردن ثبت‌نام", callback_data=f"admin:event:create:publish{suffix}")],
    ])


def admin_event_field_edit_keyboard(event_id: int):
    """Pick exactly the panel field to edit; legacy full wizard remains available."""
    eid = int(event_id)
    fields = [
        ("✏️ عنوان", "title"), ("📝 توضیحات", "description"),
        ("👤 نام میزبان", "host_name"), ("📄 فایل سؤالات", "questions_pdf"),
        ("🌐 زبان", "language"), ("📅 روز", "day_name"),
        ("🗓 تاریخ نمایشی", "date_text"), ("⏰ ساعت شروع", "start_time"),
        ("⏰ ساعت پایان", "end_time"), ("📍 محل", "venue"),
        ("🏠 آدرس", "address"), ("🔗 لینک نقشه", "map_url"),
        ("👥 ظرفیت", "capacity"), ("💰 قیمت پایه", "price"),
        ("☕ قیمت بدون سفارش کافه", "alternative_price"),
    ]
    rows = []
    for i in range(0, len(fields), 2):
        rows.append([
            InlineKeyboardButton(text=label, callback_data=f"admin:event:fieldedit:{eid}:{field}")
            for label, field in fields[i:i+2]
        ])
    rows.extend([
        [InlineKeyboardButton(text="🧰 ویرایش کامل همهٔ فیلدها", callback_data=f"admin:event:editall:{eid}")],
        [InlineKeyboardButton(text="🔙 بازگشت به پنل", callback_data=f"admin:event:view:{eid}")],
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_event_field_edit_confirm_keyboard(event_id: int, token: str):
    eid = int(event_id)
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید و ذخیره", callback_data=f"admin:event:fieldedit:confirm:{eid}:{token}")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:event:fieldedit:cancel:{eid}")],
    ])


def host_event_creation_choice_keyboard(wizard_id: str | None = None):
    suffix = f":{wizard_id}" if wizard_id else ""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📝 ذخیره پیش‌نویس", callback_data=f"host:event:create:draft{suffix}")],
        [InlineKeyboardButton(text="📨 ذخیره و ارسال برای بررسی مدیر", callback_data=f"host:event:create:submit{suffix}")],
    ])

def admin_event_menu(
    event_id: int,
    stored_status: str,
    display_status: str,
    registration_open: bool,
    archived: bool = False,
    waitlist_enabled: bool = False,
    has_bookings: bool = True,
):
    if archived:
        return InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📚 مشاهده پنل آرشیوشده", callback_data=f"admin:archive:view:{event_id}")],
            [InlineKeyboardButton(text="📊 تطبیق مالی (Excel)", callback_data=f"admin:event:reconciliation:{event_id}")],
            [InlineKeyboardButton(text="🔗 لینک ثبت‌نام پنل", callback_data=f"admin:event:links:{event_id}")],
            [InlineKeyboardButton(text="⚙️ وضعیت نهایی پنل", callback_data=f"admin:event:final:{event_id}")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:events")],
        ])

    rows = [[InlineKeyboardButton(text="✏️ ویرایش اطلاعات پنل", callback_data=f"admin:event:edit:{event_id}")]]
    if stored_status == "draft":
        rows.append([InlineKeyboardButton(text="📢 انتشار پنل", callback_data=f"admin:event:publish:{event_id}")])
    elif stored_status == "published":
        rows.append([InlineKeyboardButton(
            text=("🟢 ثبت‌نام باز است · بستن" if registration_open else "🔴 ثبت‌نام بسته است · بازگشایی"),
            callback_data=f"admin:event:{'close' if registration_open else 'reopen'}:{event_id}",
        )])
    rows += [
        [InlineKeyboardButton(text="🔗 لینک ثبت‌نام پنل", callback_data=f"admin:event:links:{event_id}")],
        [InlineKeyboardButton(text="👥 ثبت‌نام‌شده‌ها", callback_data=f"admin:event:participants:{event_id}"),
         InlineKeyboardButton(text="📋 حضور و غیاب (اختیاری)", callback_data=f"admin:attendance:{event_id}")],
        [InlineKeyboardButton(text="💳 پرداخت‌های این پنل", callback_data=f"admin:event:payments:{event_id}"),
         InlineKeyboardButton(text="📊 تطبیق مالی (Excel)", callback_data=f"admin:event:reconciliation:{event_id}")],
        [InlineKeyboardButton(text="📄 مشاهده سؤالات", callback_data=f"admin:event:questions:{event_id}"),
         InlineKeyboardButton(text="📎 تغییر فایل سؤالات", callback_data=f"admin:event:pdf:{event_id}")],
        [InlineKeyboardButton(text="📡 اتصال پست کانال", callback_data=f"admin:event:linkpost:{event_id}"),
         InlineKeyboardButton(text="👥 اتصال پست گروه", callback_data=f"admin:event:linkgroup:{event_id}")],
        [InlineKeyboardButton(text="📢 اطلاع‌رسانی", callback_data=f"admin:event:announcements:{event_id}"),
         InlineKeyboardButton(text="🔔 یادآوری دستی", callback_data=f"admin:announce:v72:purposepanel:{event_id}:reminder_today")],
        [InlineKeyboardButton(text="⚙️ وضعیت نهایی / لغو / آرشیو", callback_data=f"admin:event:final:{event_id}")],
    ]
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به فهرست پنل‌ها", callback_data="admin:events")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def final_panel_state_keyboard(
    event_id: int,
    stored_status: str,
    archived: bool = False,
    has_bookings: bool = True,
):
    rows = []
    if archived:
        rows.append([InlineKeyboardButton(text="📚 مشاهده پنل آرشیوشده", callback_data=f"admin:archive:view:{event_id}")])
        rows.append([InlineKeyboardButton(text="🗑 حذف کامل پنل و سوابق", callback_data=f"admin:event:delete:{event_id}")])
        rows.append([InlineKeyboardButton(text="🔙 بازگشت به مدیریت پنل", callback_data=f"admin:event:view:{event_id}")])
        return InlineKeyboardMarkup(inline_keyboard=rows)
    if stored_status == "published":
        rows.append([InlineKeyboardButton(text="✅ اعلام برگزاری / پایان پنل", callback_data=f"admin:event:complete:{event_id}")])
    if stored_status == "completed":
        rows.append([InlineKeyboardButton(text="📦 آرشیو + بازخورد", callback_data=f"admin:event:archive:{event_id}")])
    if stored_status != "cancelled":
        rows.append([InlineKeyboardButton(text="❌ لغو پنل", callback_data=f"admin:event:cancel:{event_id}")])
    rows.append([InlineKeyboardButton(text="🗑 حذف کامل پنل و سوابق", callback_data=f"admin:event:delete:{event_id}")])
    if has_bookings:
        rows.append([InlineKeyboardButton(text="ℹ️ حذف کامل، رزروها و رسیدها را هم پاک می‌کند", callback_data=f"admin:event:final:{event_id}")])
    rows.append([InlineKeyboardButton(text="🔙 بازگشت به مدیریت پنل", callback_data=f"admin:event:view:{event_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def archive_confirm_keyboard(event_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید آرشیو", callback_data=f"admin:event:archive:confirm:{event_id}")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:event:archive:cancel:{event_id}")],
    ])


def channel_updates_keyboard(enabled: bool, threshold: int):
    status = "🟢 به‌روزرسانی خودکار کانال: فعال" if enabled else "🔴 به‌روزرسانی خودکار کانال: غیرفعال"
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=status, callback_data="admin:channel_updates:toggle")],
        [InlineKeyboardButton(text=f"🎯 آستانه: {threshold} صندلی", callback_data="admin:channel_updates:threshold")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:home")],
    ])


def review_rating_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ 1", callback_data="review:rating:1"), InlineKeyboardButton(text="⭐ 2", callback_data="review:rating:2"), InlineKeyboardButton(text="⭐ 3", callback_data="review:rating:3")],
        [InlineKeyboardButton(text="⭐ 4", callback_data="review:rating:4"), InlineKeyboardButton(text="⭐ 5", callback_data="review:rating:5")],
        [InlineKeyboardButton(text="بدون امتیاز", callback_data="review:rating:none")],
        [InlineKeyboardButton(text="❌ لغو", callback_data="review:cancel")],
    ])


def review_confirm_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ ارسال", callback_data="review:confirm")],
        [InlineKeyboardButton(text="❌ لغو", callback_data="review:cancel")],
    ])


def payment_review_keyboard(
    payment_id: int, token: str, event_id: int | None = None, *, can_navigate: bool = True,
):
    scope = int(event_id or 0)
    rows = [[
        InlineKeyboardButton(text="✅ تأیید", callback_data=f"admin:payment:approve:{payment_id}:{token}:{scope}"),
        InlineKeyboardButton(text="❌ رد", callback_data=f"admin:payment:reject:{payment_id}:{token}:{scope}"),
    ]]
    if can_navigate:
        rows.append([
            InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin:payment:prev:{payment_id}:{scope}"),
            InlineKeyboardButton(text="➡️ بعدی", callback_data=f"admin:payment:next:{payment_id}:{scope}"),
        ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def channel_link_replacement_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ اتصال جدید جایگزین شود", callback_data="admin:linkchannel:confirm")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data="admin:linkchannel:cancel")],
    ])


def group_link_session_keyboard(token: str):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ لغو این اتصال", callback_data=f"admin:linkgroup:cancel:{token}")],
        [InlineKeyboardButton(text="🔙 مدیریت پنل‌ها", callback_data="admin:events")],
    ])


def group_link_replacement_keyboard(token: str):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید جابه‌جایی", callback_data=f"admin:linkgroup:confirm:{token}")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data=f"admin:linkgroup:cancel:{token}")],
    ])


def payment_rejection_reasons_keyboard(payment_id: int, token: str, event_id: int = 0):
    # Compact callback payloads stay comfortably below Telegram's 64-byte limit.
    scope = int(event_id or 0)
    prefix = f"prr:{int(payment_id)}:{token}:{scope}"
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="پرداخت دریافت نشده", callback_data=f"{prefix}:not_received")],
        [InlineKeyboardButton(text="مبلغ مغایرت دارد", callback_data=f"{prefix}:amount_mismatch")],
        [InlineKeyboardButton(text="رسید ناخوانا یا ناقص", callback_data=f"{prefix}:unclear")],
        [InlineKeyboardButton(text="رسید تکراری", callback_data=f"{prefix}:duplicate")],
        [InlineKeyboardButton(text="✍️ دلیل دلخواه", callback_data=f"prc:{int(payment_id)}:{token}:{scope}")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:payment:reject:cancel")],
    ])


def payment_rejection_confirm_keyboard(payment_id: int, token: str, event_id: int, category: str):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید رد رسید", callback_data=f"prf:{int(payment_id)}:{token}:{int(event_id)}:{category}")],
        [InlineKeyboardButton(text="⬅️ انتخاب دلیل دیگر", callback_data=f"prb:{int(payment_id)}:{token}:{int(event_id)}")],
        [InlineKeyboardButton(text="❌ انصراف", callback_data="admin:payment:reject:cancel")],
    ])


def bulk_reward_entry_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⌨️ ورود شناسه‌ها", callback_data="admin:discount:bulk:manual")],
        [InlineKeyboardButton(text="📎 بارگذاری TXT / CSV", callback_data="admin:discount:bulk:upload")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discounts")],
    ])


def bulk_reward_preview_keyboard(batch_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ تأیید و ایجاد هدیه‌ها", callback_data=f"admin:discount:bulk:confirm:{batch_id}")],
        [InlineKeyboardButton(text="❌ لغو این نوبت", callback_data=f"admin:discount:bulk:cancel:{batch_id}")],
    ])


def bulk_reward_result_keyboard(batch_id: int, *, resumable: bool = False):
    rows = [[InlineKeyboardButton(text="📄 گزارش جزئی", callback_data=f"admin:discount:bulk:report:{batch_id}:0")]]
    if resumable:
        rows.append([InlineKeyboardButton(text="🔄 ادامه موارد باقی‌مانده", callback_data=f"admin:discount:bulk:resume:{batch_id}")])
    rows.append([InlineKeyboardButton(text="🔙 مدیریت کدهای تخفیف", callback_data="admin:discounts")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def booking_cancel_confirm_keyboard(booking_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ بله، همین رزرو لغو شود", callback_data=f"user:booking:cancel:confirm:{booking_id}")],
        [InlineKeyboardButton(text="↩️ بازگشت به ثبت‌نام‌های من", callback_data="user:bookings")],
    ])


def retry_payment_keyboard(booking_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 ارسال مجدد رسید", callback_data=f"user:payment:retry:{booking_id}")],
        [InlineKeyboardButton(text="❌ لغو کامل رزرو", callback_data=f"user:booking:cancel:{booking_id}")],
    ])


def rejected_payment_closed_panel_keyboard(booking_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ لغو کامل رزرو", callback_data=f"user:booking:cancel:{booking_id}")],
    ])


def questions_keyboard(booking_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📄 مشاهده سؤالات پنل", callback_data=f"user:questions:file:{booking_id}")],
    ])


def questions_input_keyboard(wizard_id: str | None = None):
    """File step accepts '-' as text and uses native Back/Cancel controls."""
    return admin_event_creation_reply_keyboard(show_back=True)

def questions_replace_keyboard(event_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏭ حذف فایل سؤالات", callback_data=f"admin:event:pdf:skip:{event_id}")],
    ])


# Discount-code and reward controls. Event pickers use one readable multiline button
# per panel so draft/published state isn't squeezed into tiny labels.
def discount_manage_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ ایجاد کد عادی – بدون تأیید مدیر", callback_data="admin:discount:create:public")],
        [InlineKeyboardButton(text="➕ ایجاد کد ویژه – با تأیید مدیر", callback_data="admin:discount:create:restricted")],
        [InlineKeyboardButton(text="🎁 ارسال جایزه شخصی", callback_data="admin:discount:create:personal")],
        [InlineKeyboardButton(text="🎁 ارسال گروهی هدیه‌ها", callback_data="admin:discount:bulk:start")],
        [
            InlineKeyboardButton(text="✅ کدهای فعال", callback_data="admin:discount:list:active:0"),
            InlineKeyboardButton(text="📦 کدهای غیرفعال", callback_data="admin:discount:list:inactive:0"),
        ],
        [InlineKeyboardButton(text="⏳ درخواست‌های در انتظار", callback_data="admin:discount:requests:page:0")],
        [InlineKeyboardButton(text="🔙 بازگشت به منوی مدیریت", callback_data="admin:home")],
    ])


def discount_create_type_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌐 کد عادی – بدون تأیید مدیر", callback_data="admin:discount:create:public")],
        [InlineKeyboardButton(text="🔐 کد ویژه – با تأیید مدیر", callback_data="admin:discount:create:restricted")],
        [InlineKeyboardButton(text="🎁 جایزه شخصی برای شناسه مشخص", callback_data="admin:discount:create:personal")],
        [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin:discounts")],
    ])


def discount_cancel_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discounts")],
    ])


def discount_event_picker_keyboard(events, selected_ids, page: int, has_prev: bool, has_next: bool):
    selected = set(selected_ids or [])
    rows = []
    for event in events:
        mark = "✅" if int(event.id) in selected else "▫️"
        state = "📝 پیش‌نویس" if getattr(event.status, "value", event.status) == "draft" else ("📣 منتشرشده" if getattr(event.status, "value", event.status) == "published" else "غیرفعال")
        label = f"{mark} {volume_label(event.volume)} — {event.title[:30]}\n{state}"
        rows.append([InlineKeyboardButton(text=label[:64], callback_data=f"admin:discount:event:toggle:{event.id}:{page}")])
    nav = []
    if has_prev:
        nav.append(InlineKeyboardButton(text="⬅️ پنل‌های قدیمی‌تر", callback_data=f"admin:discount:events:page:{page-1}"))
    if has_next:
        nav.append(InlineKeyboardButton(text="پنل‌های جدیدتر ➡️", callback_data=f"admin:discount:events:page:{page+1}"))
    if nav:
        rows.append(nav)
    # These labels are intentionally full-width rows so they remain easy to tap/read on mobile.
    rows.append([InlineKeyboardButton(
        text="☑️ انتخاب همهٔ پنل‌های فعلی",
        callback_data=f"admin:discount:events:select_all:{page}",
    )])
    rows.append([InlineKeyboardButton(
        text="🧹 پاک کردن انتخاب‌ها",
        callback_data=f"admin:discount:events:clear:{page}",
    )])
    rows.append([InlineKeyboardButton(text=f"✅ پایان انتخاب ({len(selected)})", callback_data="admin:discount:events:done")])
    rows.append([InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discounts")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def discount_usage_policy_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="یک‌بار در مجموع", callback_data="admin:discount:policy:once_total")],
        [InlineKeyboardButton(text="یک‌بار در هر پنل", callback_data="admin:discount:policy:once_per_panel")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discounts")],
    ])


def discount_max_uses_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="بدون محدودیت کلی", callback_data="admin:discount:max:unlimited")],
        [InlineKeyboardButton(text="تعیین سقف استفاده", callback_data="admin:discount:max:limited")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discounts")],
    ])


def user_discount_prompt_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎟 وارد کردن کد تخفیف", callback_data="booking:discount:enter")],
        [InlineKeyboardButton(text="ادامه بدون کد", callback_data="booking:discount:skip")],
    ])


def discount_request_user_keyboard(redemption_id: int, *, approved: bool = False):
    rows = []
    if approved:
        rows.append([InlineKeyboardButton(text="➡️ ادامه ثبت‌نام و پرداخت با تخفیف", callback_data=f"user:discount:continue:{redemption_id}")])
    rows.append([InlineKeyboardButton(text="ادامه با قیمت عادی", callback_data=f"user:discount:normal:{redemption_id}")])
    rows.append([InlineKeyboardButton(text="❌ لغو ثبت‌نام", callback_data=f"user:discount:cancel:{redemption_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def personal_reward_keyboard(reward_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎁 پذیرش هدیه", callback_data=f"user:reward:accept:{reward_id}")],
    ])


def admin_discount_request_keyboard(redemption_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ تأیید تخفیف", callback_data=f"admin:discount:request:approve:{redemption_id}"),
            InlineKeyboardButton(text="❌ رد درخواست", callback_data=f"admin:discount:request:reject:{redemption_id}"),
        ],
        [InlineKeyboardButton(text="🔙 فهرست درخواست‌ها", callback_data="admin:discount:requests:page:0")],
    ])


def admin_discount_disable_keyboard(code_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⛔ بله، غیرفعال شود", callback_data=f"admin:discount:disable:confirm:{code_id}")],
        [InlineKeyboardButton(text="↩️ انصراف", callback_data="admin:discount:list:active:0")],
    ])


def help_keyboard():
    return main_menu()


def community_menu_keyboard():
    """Leaderboard and challenge destinations with renamed universal labels."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏆 لیدربورد ⁦Panel Flow⁩", callback_data="community:leaderboard")],
        [InlineKeyboardButton(text="🎯 چالش‌ها", callback_data="community:challenges")],
        [InlineKeyboardButton(text="\u2067🛍 ⁦XP⁩ شاپ\u2069", callback_data="community:shop"),
         InlineKeyboardButton(text="\u2067🎁 ⁦Giveaways⁩\u2069", callback_data="community:draw")],
        [InlineKeyboardButton(text="🪪 پاسپورت من", callback_data="community:passport")],
        [InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="user:home")],
    ])


def admin_community_menu(leaderboard_enabled: bool):
    """Put day-to-day challenge moderation first and secondary settings last."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ ایجاد چالش", callback_data="admin:community:challenge:create")],
        [InlineKeyboardButton(text="🧠 مدیریت چالش‌ها", callback_data="admin:community:challenges")],
        [InlineKeyboardButton(text="👁 بررسی پاسخ‌ها", callback_data="admin:community:submissions:list:0")],
        [InlineKeyboardButton(text="🏆 لیدربورد مدیریتی ⁦Panel Flow⁩", callback_data="admin:community:leaderboard:view:0"),
         InlineKeyboardButton(text="📊 دریافت فایل اکسل", callback_data="admin:community:leaderboard:export")],
        [InlineKeyboardButton(text="🏅 ثبت برندهٔ مسابقه", callback_data="admin:community:competition")],
        [InlineKeyboardButton(text="⚙️ تنظیم امتیازها", callback_data="admin:community:xp"),
         InlineKeyboardButton(
             text=("🟢 لیدربورد عمومی: فعال" if leaderboard_enabled else "🔴 لیدربورد عمومی: غیرفعال"),
             callback_data="admin:community:leaderboard:toggle",
         )],
        [InlineKeyboardButton(text="🎉 ساخت گزارش دوره‌ای", callback_data="admin:community:wrapped")],
        [InlineKeyboardButton(text="⚙️ تنظیمات امکانات جامعه", callback_data="admin:community:settings")],
        [InlineKeyboardButton(text="🧹 پاک‌سازی چالش‌های نهایی‌شده", callback_data="admin:community:clear")],
        [InlineKeyboardButton(text="🔙 بازگشت به منوی مدیریت", callback_data="admin:home")],
    ])
