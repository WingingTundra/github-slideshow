from __future__ import annotations


def positive_callback_id(data: str | None) -> int | None:
    """Return a positive numeric identifier from callback data, otherwise None."""
    if not data:
        return None
    try:
        value = int(data.rsplit(":", 1)[1])
    except (IndexError, TypeError, ValueError):
        return None
    return value if value > 0 else None
