"""Validation and in-memory updates for self-service user profile edits."""

from app.bot.validation import normalize_iranian_mobile, parse_full_name
from app.db.models import User


def apply_profile_name(user: User, value: str) -> bool:
    """Apply a valid full name to the account profile, without touching bookings."""
    parsed = parse_full_name(value)
    if parsed is None:
        return False

    first_name, last_name = parsed
    user.first_name = first_name
    user.last_name = last_name
    user.display_name = f"{first_name} {last_name}".strip()
    return True


def apply_profile_phone(user: User, value: str) -> bool:
    """Apply a valid normalized Iranian mobile number to the account profile."""
    normalized = normalize_iranian_mobile(value)
    if normalized is None:
        return False
    user.phone_number = normalized
    return True
