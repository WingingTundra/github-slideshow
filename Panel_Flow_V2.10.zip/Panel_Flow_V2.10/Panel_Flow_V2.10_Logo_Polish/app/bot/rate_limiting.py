"""aiogram adapter for the standalone in-memory anti-flood limiter."""
from __future__ import annotations
import logging
from typing import Any, Awaitable, Callable
from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message
from app.config import settings
from app.services.rate_limiter import limiter

log = logging.getLogger(__name__)

class RateLimitMiddleware(BaseMiddleware):
    async def __call__(self, handler: Callable[[Any,dict[str,Any]],Awaitable[Any]], event: Any, data: dict[str,Any]):
        user=getattr(event,'from_user',None); uid=getattr(user,'id',None)
        if not isinstance(uid,int): return await handler(event,data)
        is_admin=uid in settings.super_admin_id_set; mult=settings.rate_limit_admin_multiplier if is_admin else 1
        if isinstance(event, CallbackQuery):
            kind='callback'; ceiling=settings.rate_limit_callbacks; window=settings.rate_limit_callback_window_seconds; burst=settings.rate_limit_callback_burst
        elif isinstance(event, Message):
            text=(event.text or event.caption or '').strip()
            if text and text.split(maxsplit=1)[0].split('@')[0].lower() == '/cancel':
                return await handler(event, data)
            kind='message'; ceiling=settings.rate_limit_messages; window=settings.rate_limit_message_window_seconds; burst=settings.rate_limit_message_burst
        else: return await handler(event,data)
        allowed,notify=await limiter.allow(uid,kind,ceiling=ceiling,window=window,burst=burst,refill=1.0,multiplier=mult)
        if allowed: return await handler(event,data)
        log.warning('telegram_update_rate_limited kind=%s admin=%s',kind,is_admin)
        if isinstance(event,CallbackQuery):
            try: await event.answer('لطفاً کمی آهسته‌تر تلاش کنید.',show_alert=False)
            except Exception: pass
        elif notify:
            try: await event.answer('لطفاً چند لحظه صبر کنید و دوباره تلاش کنید.')
            except Exception: pass
        return None
