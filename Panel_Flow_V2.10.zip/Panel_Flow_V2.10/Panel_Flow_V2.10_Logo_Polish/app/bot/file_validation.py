from __future__ import annotations

from pathlib import Path

PDF_MIME = "application/pdf"
ALLOWED_RECEIPT_MIMES = {"image/jpeg", "image/png", PDF_MIME}
ALLOWED_RECEIPT_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf"}


def is_pdf_document(document) -> bool:
    name = (getattr(document, "file_name", None) or "").lower()
    mime = (getattr(document, "mime_type", None) or "").lower()
    if mime and name:
        return mime == PDF_MIME and name.endswith(".pdf")
    if mime:
        return mime == PDF_MIME
    return name.endswith(".pdf")


def is_text_document(document) -> bool:
    name = (getattr(document, "file_name", None) or "").lower()
    mime = (getattr(document, "mime_type", None) or "").lower()
    if Path(name).suffix != ".txt":
        return False
    return not mime or mime == "text/plain"


def receipt_allowed(document) -> bool:
    """Check receipt metadata while supporting MIME-typed documents without a filename."""
    name = (getattr(document, "file_name", None) or "").lower()
    suffix = Path(name).suffix
    mime = (getattr(document, "mime_type", None) or "").lower()
    expected = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".pdf": PDF_MIME}
    if suffix:
        if suffix not in ALLOWED_RECEIPT_EXTENSIONS:
            return False
        return not mime or mime == expected.get(suffix)
    return mime in ALLOWED_RECEIPT_MIMES


def receipt_extension(document) -> str | None:
    """Return a trusted supported extension based on consistent filename/MIME metadata."""
    if not receipt_allowed(document):
        return None
    name = (getattr(document, "file_name", None) or "").lower()
    suffix = Path(name).suffix
    if suffix:
        return suffix
    mime = (getattr(document, "mime_type", None) or "").lower()
    return {"image/jpeg": ".jpg", "image/png": ".png", PDF_MIME: ".pdf"}.get(mime)


def file_content_matches(path: str, extension: str) -> bool:
    """Check downloaded file signatures/content rather than trusting a name or MIME type."""
    ext = (extension or "").lower()
    try:
        with open(path, "rb") as handle:
            header = handle.read(16)
            if ext == ".pdf":
                return header.startswith(b"%PDF-")
            if ext in {".jpg", ".jpeg"}:
                return header.startswith(b"\xff\xd8\xff")
            if ext == ".png":
                return header.startswith(b"\x89PNG\r\n\x1a\n")
            if ext == ".txt":
                handle.seek(0)
                content = handle.read()
                if not content or b"\x00" in content:
                    return False
                content.decode("utf-8")
                return True
    except (OSError, UnicodeDecodeError):
        return False
    return False
