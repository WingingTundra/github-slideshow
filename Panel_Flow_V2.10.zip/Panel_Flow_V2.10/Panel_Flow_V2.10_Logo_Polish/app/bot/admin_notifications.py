"""Escaped HTML formatters for operational administrator notifications."""
from __future__ import annotations

import re
from html import escape

_TELEGRAM_USERNAME_RE = re.compile(r"[A-Za-z0-9_]{5,32}\Z")


def format_receipt_stage_cancel_notice(
    *,
    event_label: str,
    booking_id: int,
    participant_count: int,
    telegram_id: int,
    username: str | None = None,
    cancellation_method: str = "command",
) -> str:
    """Build a safe, clickable admin notice for receipt-stage cancellation.

    The numeric Telegram-ID link works even if the user has no public username.
    When a username is available, a second public profile link is included.
    User-supplied names/titles are always HTML-escaped.
    """
    safe_telegram_id = int(telegram_id)
    profile = f'<a href="tg://user?id={safe_telegram_id}">{safe_telegram_id}</a>'
    normalized_username = str(username or "").strip().lstrip("@")
    if _TELEGRAM_USERNAME_RE.fullmatch(normalized_username):
        username_link = (
            f' (<a href="https://t.me/{normalized_username}">'
            f'@{escape(normalized_username)}</a>)'
        )
    else:
        username_link = ""

    cancellation_text = (
        "با دکمهٔ انصراف لغو کرد."
        if cancellation_method == "button"
        else "با /cancel لغو کرد."
    )
    return (
        f"ℹ️ <b>کاربر هنگام ارسال رسید، رزرو را {cancellation_text}</b>\n"
        f"پنل: {escape(str(event_label))}\n"
        f"رزرو: #{int(booking_id)} | تعداد نفرات: {max(0, int(participant_count))} | "
        f"Telegram ID: {profile}{username_link}"
    )
