"""Shared user-facing copy. Dynamic support details always come from config."""
from html import escape

from app.config import settings
from app.display_utils import rtl_isolate, ltr_isolate


def support_link_html() -> str:
    username = escape(settings.support_display_username)
    url = escape(settings.support_url, quote=True)
    return f'<a href="{url}">{username}</a>'



def main_menu_welcome_text() -> str:
    """Short, welcoming copy shown on the user's main menu."""
    return (
        "🧩 به Panel Flow خوش آمدید!\n"
        "فضایی برای گفت‌وگو و آشنایی با آدم‌های تازه."
    )



def onboarding_full_name_prompt() -> str:
    """One consistent first-contact prompt for normal and deep-link onboarding."""
    return "به Panel Flow خوش آمدید. 🎉\n\nلطفاً نام و نام خانوادگی خود را در یک پیام وارد کنید."


def invalid_full_name_prompt() -> str:
    """Helpful validation feedback, without exposing internal validation rules."""
    return "لطفاً نام و نام خانوادگی‌تان را در یک پیام وارد کنید. مثال: سینا ضیائی یا Sara Williams."


def accepted_name_phone_prompt() -> str:
    return (
        "✅ نام و نام خانوادگی ثبت شد.\n\n"
        "شمارهٔ تماس خود را وارد کنید.\n"
        "<i>شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود.</i>"
    )


def phone_number_prompt() -> str:
    return (
        "شمارهٔ تماس خود را وارد کنید.\n"
        "<i>شمارهٔ تماس در مواقع ضروری برای هماهنگی استفاده می‌شود.</i>"
    )


def user_help_text() -> str:
    support = support_link_html()
    return (
        "<b>راهنمای Panel Flow</b>\n\n"
        + rtl_isolate("🏠 <b>پنل‌های پیش‌رو</b>\nمشاهدهٔ جزئیات و ثبت‌نام پنل‌ها.") + "\n\n"
        + rtl_isolate("🎟 <b>ثبت‌نام‌های من</b>\nپیگیری وضعیت رزروها و پرداخت‌ها.") + "\n\n"
        + rtl_isolate("👤 <b>پروفایل من</b>\nمدیریت اطلاعات تماس و کد معرفی.") + "\n\n"
        + rtl_isolate("📄 <b>سؤالات پنل‌ها</b>\nدریافت فایل‌های منتشرشدهٔ پنل‌هایی که رزرو تأییدشده دارید؛ همهٔ پنل‌ها فایل سؤال ندارند.") + "\n\n"
        + rtl_isolate("📝 <b>ثبت نظر</b>\nثبت بازخورد خصوصی پس از برگزاری پنل.") + "\n\n"
        + rtl_isolate("💡 <b>پیشنهادها</b>\nپیشنهاد سؤال، پیشنهاد موضوع و رأی‌گیری.") + "\n\n"
        + rtl_isolate("💬 <b>جامعه و دربارهٔ ما</b>\nمعرفی Panel Flow و لینک‌های رسمی.") + "\n\n"
        + rtl_isolate("🏆 <b>لیدربورد و چالش‌ها</b>") + "\n"
        + rtl_isolate("🏆 لیدربورد " + ltr_isolate("Panel Flow") + ": مشاهدهٔ ۱۰ نفر برتر و تنظیم نمایش نام.") + "\n"
        + rtl_isolate("🎯 چالش‌ها: مشاهده و شرکت در چالش‌های فعال.") + "\n"
        + rtl_isolate("🛍 " + ltr_isolate("XP") + " شاپ: استفاده از امتیازها برای دریافت پاداش.") + "\n"
        + rtl_isolate("🎁 " + ltr_isolate("Giveaways") + ": شرکت داوطلبانه در کمپین‌های فعال.") + "\n"
        + rtl_isolate("🪪 پاسپورت من: مجموع XP، آمار، هدف‌ها و نشان‌ها؛ گزارش سالانهٔ Wrapped پس از انتشار مدیر نمایش داده می‌شود.") + "\n\n"
        + rtl_isolate("برای منوی اصلی /start و برای لغو فرایند /cancel را بفرستید.") + "\n\n"
        + rtl_isolate(f"🧑‍💻 <b>پشتیبانی انسانی</b>\nبرای راهنمایی یا گزارش مشکل: {support}")
    )


def about_text() -> str:
    """Return the approved bilingual About copy for Panel Flow."""
    return (
        "<b>🧩 ABOUT PANEL FLOW</b>\n\n"
        "<b>Who we are</b>\n"
        "Panel Flow is a community in Mashhad, Iran, bringing people together for regular, structured discussion panels, with room for different topics and languages.\n\n"
        "<b>🌱 Our beginnings</b>\n"
        "What began as a passion for hosting discussions, encouraged by a friend, became our first session on 3 Tir 1404 (June 24, 2025). From a small, private gathering of friends, Panel Flow has grown into a welcoming public community.\n\n"
        "<b>💬 What brings us together</b>\n"
        "Our sessions create space to exchange ideas, explore different perspectives, learn from one another, and connect with new people.\n\n"
        "<b>🤝 A place for everyone</b>\n"
        "Whether you come ready to contribute or prefer to listen at first, there's a place for you at Panel Flow.\n\n"
        "──────────\n\n"
        "<b>🧩 دربارهٔ پنل فلو</b>\n\n"
        "<b>ما که هستیم</b>\n"
        "پنل فلو جامعه‌ای در مشهد است که افراد را برای شرکت در پنل‌های گفت‌وگوی منظم و ساختارمند گرد هم می‌آورد؛ با فضایی برای موضوعات متنوع و زبان‌های مختلف.\n\n"
        "<b>🌱 آغاز ما</b>\n"
        "علاقه به برگزاری گفت‌وگوها و تشویق یکی از دوستان کمک کرد تا این ایده به نخستین جلسه در ۳ تیر ۱۴۰۴ تبدیل شود. آنچه با دورهمی خصوصی و کوچکی میان دوستان آغاز شد، امروز به جامعه‌ای عمومی و پذیرا تبدیل شده است.\n\n"
        "<b>💬 آنچه ما را دور هم جمع می‌کند</b>\n"
        "جلسات ما فرصتی برای تبادل ایده‌ها، آشنایی با دیدگاه‌های گوناگون، یادگیری از یکدیگر و ارتباط با افراد جدید فراهم می‌کنند.\n\n"
        "<b>🤝 جایی برای همه</b>\n"
        "چه آمادهٔ مشارکت در گفت‌وگو باشید و چه ترجیح دهید ابتدا شنونده باشید، در پنل فلو جایی برای شما هست."
    )
