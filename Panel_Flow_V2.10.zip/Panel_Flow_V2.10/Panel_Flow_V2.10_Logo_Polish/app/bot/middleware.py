"""Cross-cutting Telegram user-access enforcement middleware."""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message

from app.services.authorization import inspect_account_access

logger = logging.getLogger(__name__)

BLOCKED_MESSAGE = "⛔ دسترسی شما به ربات در حال حاضر محدود است. در صورت نیاز، با پشتیبانی تماس بگیرید."
ACCESS_CHECK_UNAVAILABLE = "⚠️ بررسی دسترسی موقتاً امکان‌پذیر نیست. لطفاً کمی بعد دوباره تلاش کنید."


class UserAccessMiddleware(BaseMiddleware):
    """Reject restricted users before any message, callback, or FSM handler runs."""

    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        telegram_user = getattr(event, "from_user", None)
        telegram_id = getattr(telegram_user, "id", None)
        if not isinstance(telegram_id, int):
            return await handler(event, data)

        try:
            blocked, should_send_notice = await inspect_account_access(
                telegram_id, record_block_notice=isinstance(event, Message),
            )
        except Exception:
            # Fail closed for ordinary users when enforcement cannot be checked.
            logger.exception("Could not verify access restriction for incoming Telegram update")
            try:
                if isinstance(event, Message):
                    await event.answer(ACCESS_CHECK_UNAVAILABLE)
                elif isinstance(event, CallbackQuery):
                    await event.answer(ACCESS_CHECK_UNAVAILABLE, show_alert=True)
            except Exception:
                logger.debug("Could not send access verification notice")
            return None

        if blocked:
            # Messages receive at most one blocked-account notice per 24 hours;
            # callback taps get a toast so Telegram stops showing a spinner.
            try:
                if isinstance(event, Message) and should_send_notice:
                    await event.answer(BLOCKED_MESSAGE)
                elif isinstance(event, CallbackQuery):
                    await event.answer(BLOCKED_MESSAGE, show_alert=True)
            except Exception:
                logger.debug("Could not send blocked-user notice")
            return None
        return await handler(event, data)
