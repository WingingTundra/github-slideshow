import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand, BotCommandScopeChat

from app.config import settings
from app.db.init import init_db
from app.db.session import dispose_database_engines
from app.bot.handlers.reply_menu import router as reply_menu_router
from app.bot.handlers.v77_features import router as v77_features_router
from app.bot.handlers.user import router as user_router
from app.bot.handlers.admin import router as admin_router
from app.bot.handlers.admin_console import router as admin_console_router, recover_interrupted_announcements
from app.bot.handlers.admin_payment_actions import router as payment_router
from app.bot.handlers.community import router as community_router
from app.bot.handlers.attendance import router as attendance_router
from app.bot.handlers.admin_features import router as admin_features_router
from app.bot.handlers.topics import user_router as topics_user_router, admin_router as topics_admin_router
from app.bot.middleware import UserAccessMiddleware
from app.bot.persistent_storage import PostgresEventIsolation, PostgresFSMStorage, periodic_fsm_cleanup
from app.bot.rate_limiting import RateLimitMiddleware
from app.services.channel_status import periodic_channel_reconciliation, reconcile_all_channel_statuses
from app.services.reservation_maintenance import periodic_booking_expiry
from app.services.upload_maintenance import periodic_orphan_upload_cleanup
from app.services.waitlist import periodic_waitlist_maintenance
from app.services.event_notifications import periodic_registration_reminders, periodic_notification_retries

logger = logging.getLogger(__name__)

async def main():
    await init_db()
    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    # Resume safe pending announcement deliveries after a restart. Any send whose
    # Telegram outcome was interrupted is marked unknown, never blindly duplicated.
    try:
        await recover_interrupted_announcements(bot)
    except Exception:
        logger.exception("Startup announcement recovery failed; bot startup will continue")
    try:
        public_commands = [
            BotCommand(command="start", description="بازگشت به منوی اصلی"),
            BotCommand(command="help", description="راهنمای استفاده از ربات"),
            BotCommand(command="cancel", description="لغو گفت‌وگوی در حال انجام"),
        ]
        await bot.set_my_commands(public_commands)
        # Also overwrite any stale per-admin command list left by older releases:
        # /admin remains a working command but is intentionally not advertised in menus.
        for admin_id in sorted(settings.super_admin_id_set):
            try:
                await bot.set_my_commands(
                    public_commands,
                    scope=BotCommandScopeChat(chat_id=admin_id),
                )
            except Exception:
                logger.exception("Could not register admin command for configured admin_id=%s", admin_id)
    except Exception:
        # Telegram command registration is best-effort; an API hiccup must not
        # prevent the existing bot from starting. The handlers still work.
        logger.exception("Could not register Telegram bot commands")
    fsm_storage = PostgresFSMStorage()
    event_isolation = PostgresEventIsolation()
    # Recover active flows across restarts while expiring stale forms safely.
    await fsm_storage.cleanup_expired()
    dp = Dispatcher(storage=fsm_storage, events_isolation=event_isolation)
    # Enforce numeric-Telegram-ID blocks on every incoming message and inline
    # callback before any user FSM state or callback handler can run.
    rate_middleware = RateLimitMiddleware()
    access_middleware = UserAccessMiddleware()
    # Outer middleware executes in registration order: cheap in-memory limit first.
    dp.message.outer_middleware(rate_middleware)
    dp.callback_query.outer_middleware(rate_middleware)
    dp.message.outer_middleware(access_middleware)
    dp.callback_query.outer_middleware(access_middleware)
    # These feature routers contain callbacks with user: prefixes that would
    # otherwise be swallowed by user_router's stale-button fallback.
    # Exact reply-keyboard menu labels must be handled before any active FSM
    # text handler so they are never mistaken for form input.
    dp.include_router(reply_menu_router)
    dp.include_router(attendance_router)
    dp.include_router(topics_user_router)
    # V77-compatible community callbacks (including V78 additions) must be registered before broad user/community fallback routes.
    dp.include_router(v77_features_router)
    dp.include_router(user_router)
    # Specialized admin callbacks must precede admin_router's broad admin:* fallback.
    dp.include_router(payment_router)
    dp.include_router(community_router)
    dp.include_router(topics_admin_router)
    dp.include_router(admin_features_router)
    dp.include_router(admin_console_router)
    dp.include_router(admin_router)
    await bot.delete_webhook(drop_pending_updates=False)
    await reconcile_all_channel_statuses(bot)
    reconciliation_task = asyncio.create_task(periodic_channel_reconciliation(bot))
    expiry_task = asyncio.create_task(periodic_booking_expiry(bot))
    waitlist_task = asyncio.create_task(periodic_waitlist_maintenance(bot))
    upload_cleanup_task = asyncio.create_task(periodic_orphan_upload_cleanup(bot=bot))
    fsm_cleanup_task = asyncio.create_task(periodic_fsm_cleanup(fsm_storage))
    reminder_task = asyncio.create_task(periodic_registration_reminders(bot))
    notification_retry_task = asyncio.create_task(periodic_notification_retries())
    try:
        await dp.start_polling(bot)
    finally:
        reconciliation_task.cancel()
        expiry_task.cancel()
        waitlist_task.cancel()
        upload_cleanup_task.cancel()
        fsm_cleanup_task.cancel()
        reminder_task.cancel()
        notification_retry_task.cancel()
        for task in (reconciliation_task, expiry_task, waitlist_task, upload_cleanup_task, fsm_cleanup_task, reminder_task, notification_retry_task):
            try:
                await task
            except asyncio.CancelledError:
                pass
        await fsm_storage.close()
        await dispose_database_engines()
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
