# Panel Flow V2.10 — Logo geometry and icon polish

## Brand artwork refinement
- Rebuilt the circular emblem rings as exact concentric SVG arcs for consistent circular geometry across the large logo, app icon, and favicon.
- Smoothed the traced wave contours into cubic Bézier paths to remove raster stair-stepping and sharp, uneven edges.
- Re-exported light/dark SVG and high-resolution PNG variants from one shared vector master.
- Standardized icon artboards and centered, uniform scaling; the app icon now uses a true circular medallion rather than separately scaled artwork.
- Updated responsive CSS so header, footer, homepage hero, and sign-in marks retain the original 855:524 symbol aspect ratio on desktop, tablet, and small phones.
- Regenerated the browser favicon, Apple touch icon, and 1200×630 social preview from the refined master.

## Preserved platform behavior
- This is a visual-only refinement. Backend behavior, APIs, migrations, bookings, payments, attendance, notifications, and the canonical `Asia/Tehran` timezone are unchanged.

---

# Panel Flow V2.09 — Brand identity integration

## Website logo system
- Integrated the supplied Panel Flow wave emblem as the site's official brand identity.
- Created clean transparent vector assets in navy/red and white/red variants, plus high-resolution PNG exports.
- Updated the responsive header and footer lockups, homepage hero centerpiece, sign-in panel, browser favicon, Apple touch icon, and social-sharing preview.
- Added narrow-screen header behavior: compact logo sizing, hidden micro-tagline, and a menu-based mobile sign-in entry to avoid navigation overflow.
- Added `BRAND_GUIDE.md` with asset inventory, palette, theme usage, responsive behavior, and brand handling rules.

## Preserved platform behavior
- No backend, API, database migration, event lifecycle, booking, payment, attendance, or `Asia/Tehran` timezone behavior was changed for this visual release.

---

# Panel Flow V2.08 — Tehran Time & Technical Optimization

## Platform timezone contract
- Standardized the application on IANA `Asia/Tehran`; the Pydantic settings validator rejects any other `APP_TIMEZONE` value.
- Both bot and API Compose services receive `APP_TIMEZONE=Asia/Tehran` and `TZ=Asia/Tehran`.
- Added shared helpers for Tehran wall-clock values, Tehran calendar dates, UTC instant normalization, and Tehran-to-UTC persistence conversion.
- Preserved the existing PostgreSQL convention: `DateTime(timezone=False)` timestamps are naive UTC. Each async PostgreSQL connection explicitly runs `SET TIME ZONE 'UTC'` so server defaults/raw SQL remain aligned with that convention.
- Website timestamp rendering explicitly interprets backend-naive timestamps as UTC and formats them in `Asia/Tehran`. The Persian calendar now anchors date-only values at UTC noon and computes “today” from the Tehran clock, so the visitor's browser timezone cannot shift a calendar day. Calendar exports convert the selected date/time as a Tehran wall clock through the IANA timezone database.
- City/upcoming activity counts, host subscription remaining days, recommendation attendance/saved-interest age calculations, and host-application date validation now use Tehran-local date boundaries.
- Event day/date/start/end labels supplied by hosts remain display text only. This release does not parse them into schedule instants, close registration automatically, or reject display dates because they are in the past.

## Durable notification outbox and lifecycle
- Added a common `enqueue_event_notification()` path for event publication and public changes.
- Website staff publication/edit/cover-image updates and Telegram-admin publication/edit/completion flows enqueue durable outbox rows inside the same SQL transaction as the event change.
- Outbox jobs use event-scoped deduplication keys, `FOR UPDATE SKIP LOCKED` claims, stale-processing recovery, bounded retries/backoff, and the existing per-recipient delivery ledger for recipient-level idempotency.
- Centralized event state policy for draft → published, published → completed/cancelled, postponement/resumption, and completed-event archival. Cancellation service, admin completion/archive, website status updates, and postponement actions use the shared lifecycle helper.
- Registration-open/closed policy remains separate from lifecycle state. A manually closed registration is not reopened by publishing or waitlist maintenance.

## Attendance and reviews
- New QR bearer tokens use 96 bits of random entropy. Telegram callback buttons carry a separate 64-bit event-scoped session nonce, not the bearer token.
- QR bearer tokens and manual codes have explicit 12-hour expiries. Every entry, page-navigation callback, and attendance-mark callback revalidates the current proof/session and expiry; rotating a proof invalidates older callbacks.
- Existing stored proofs receive a one-time 12-hour grace period during migration 055; operators should rotate any QR/manual code that needs to remain available after that grace window.
- New completed panels require the account holder's own participant row to be marked `ATTENDED` before a review can be created. The rule is checked both when listing reviewable panels and again at selection/confirmation.
- Completed panels that already existed when migration 055 is applied are grandfathered because historical participant-to-account attendance attribution may not be reconstructable. New events retain the attendance requirement.

## Frontend and API performance
- Public anonymous GET responses are cached in memory for 10 seconds with an 80-entry bound, and duplicate in-flight GET requests are coalesced. Authenticated/private routes and requests with an `AbortSignal` bypass the cache. Every mutation invalidates the cache generation to prevent stale results from being written after changes.
- `useRequest` aborts superseded requests and cleans up active requests on unmount. Abort errors are not shown as user-facing network failures.
- Added opaque keyset cursors for newest-first public event discovery. Existing offset pagination continues to work; cursor mode requires newest sort and zero offset.
- Retained grouped seat-usage/organization/brand lookups for public discovery and removed an unused aggregate query. Added migration indexes for discovery, city listings, booking lookup, waitlist ordering, participant attendance, reviews, discussion series, attendance audit cursors, and event notification claims.
- Public image uploads now generate a full WebP image and a 640-pixel thumbnail variant, with both files included in quota/free-space accounting. Event details prefer the thumbnail where appropriate; old media falls back to the original full image.
- Added `/health/operational` counts for pending/processing/failed outbox jobs and failed event-delivery rows. `/health/ready` remains the database readiness probe and is used by the API container healthcheck.
- Lazy-loaded the Iran city map and Persian calendar, and retained explicit Vite chunks for React, routing, and icons. The large `App.tsx` page module has not been fully decomposed into per-route files in this release.

## Waitlist, discussion series, and host communication
- A postponed published panel no longer produces new waitlist invitations. An in-flight invitation is returned to the waiting queue if the panel is postponed or the queue is paused; cancelled/completed/archived panels close their queue entries.
- Waitlist expiration maintenance preserves entries while a panel is postponed and only returns resumed, eligible panels to the invitation sweep. Existing FIFO, group-fit, cooldown, invitation TTL, capacity revalidation, and no-seat-hold behavior remain intact.
- Hosts cannot add postponed panels to new or updated discussion series. Existing series, public series ordering, and host roster features remain in place.
- Existing panel-scoped host communication remains based on actor authorization, preview/explicit confirmation, and the established delivery ledger; no parallel messaging subsystem was introduced.

## Deployment and compatibility
- Added migration `055_v208_tehran_hardening.sql`; it is additive and uses `IF NOT EXISTS` for new schema objects.
- Added `--check` mode to `python -m app.db.migrate_cli` to validate applied migration checksums and detect pending migrations without applying them. Default/`--apply` mode applies pending migrations.
- Migration `054` and earlier history remains immutable. Migration 055 adds QR/session expiry fields, review policy, image thumbnail URL, and targeted indexes.
- No destructive data migration, database reset, runtime dependency, or existing feature removal is intended.
