# Panel Flow

**Current source package: V2.10 — refined Panel Flow brand assets and responsive logo geometry on the V2.09 website / V2.08 platform baseline**

Panel Flow is a bilingual, Persian-first community platform for discovering, hosting, and managing discussion panels. The repository contains the Telegram bot, HTTP API, React website, PostgreSQL schema migrations, operational scripts, regression tests, and the official navy/red Panel Flow logo asset set. The V2.10 refinement replaces traced, angular outlines with smoothed Bézier wave paths, mathematically concentric circular rings, and uniformly scaled icon exports.

This package is prepared for a technical review in Google AI Studio. It contains the current application source and the documentation needed to understand, run, and review it. Superseded release READMEs, old release notes, and historical QA reports have been removed; application code, tests, migrations, and operational assets have been retained.

## Platform timezone contract

The single canonical platform timezone is **`Asia/Tehran`**.

- Bot, API, website calendar behavior, date-boundary calculations, notification quiet hours, and calendar exports use Tehran time.
- `APP_TIMEZONE` is fixed to `Asia/Tehran`; the application rejects a conflicting value. Docker Compose also sets `TZ=Asia/Tehran` for the bot and API.
- Operational timestamps continue to use the established **naive-UTC PostgreSQL storage convention** for compatibility. Conversion to/from Tehran is explicit at application boundaries.
- Host-entered event day/date/time labels are presentation text. They must not be parsed to infer event instants, automatically close registration, or reject a panel because its displayed date is in the past.

Do not change this contract without reviewing the database timestamp conventions, timezone utilities, frontend calendar behavior, exports, scheduled jobs, and regression tests together.

## Main components

| Area | Implementation | Location |
|---|---|---|
| Telegram bot | Python 3.12, Aiogram 3, FSM handlers and keyboards | `app/bot/` |
| HTTP API | FastAPI, async SQLAlchemy, PostgreSQL | `app/api.py`, `app/http_api/` |
| Business services | Booking, events, payments, waitlists, notifications, attendance, media, community and organizations | `app/services/` |
| Database | SQLAlchemy models and ordered SQL migrations | `app/db/`, `migrations/` |
| Website | React, TypeScript, Vite, React Router | `website/src/` |
| Operations | Docker Compose, backups, restore and maintenance scripts | `docker-compose.yml`, `scripts/` |
| Regression coverage | Pytest unit, integration-contract and static regression tests | `tests/` |

The Compose stack defines PostgreSQL (`db`), Telegram bot (`bot`), API (`api`), website (`website`), and backup (`backup`) services.

## Repository layout

```text
app/
  bot/                 Telegram bot, middleware, FSM and handlers
  db/                  SQLAlchemy models, sessions and migration runner
  http_api/             API routes, schemas, security and dependencies
  services/             Domain and application services
  config.py             Validated environment configuration
  time_utils.py         Canonical Tehran and UTC conversion helpers
migrations/              Append-only SQL migration history
scripts/                  Backup, restore, pruning and maintenance tools
tests/                    Automated regression tests
website/
  src/                   React application, API client, components and styles
  public/                Icons, social preview assets and licensed fonts
  scripts/               Public-page prerendering
.github/workflows/        CI quality checks
Dockerfile                Python bot/API image
docker-compose.yml        Multi-service deployment
.env.example              Safe configuration template
CONFIGURATION.md          Environment variable reference
DEPLOYMENT.md             Current deployment and rollout guidance
CHANGELOG.md              Current release scope
```

## Getting started

### Docker Compose (recommended)

1. Copy `.env.example` to `.env` and set deployment-specific values. At minimum, configure the Telegram bot token, PostgreSQL password, administrator IDs, API signing secret when the API is enabled, and public URLs/origins appropriate to the deployment.
2. Keep the timezone exactly `Asia/Tehran`. Generate fresh high-entropy secrets; never use example values for production.
3. Back up the existing database and uploads volume before upgrading an existing installation.
4. Apply pending migrations and validate the migration state:

   ```sh
   docker compose run --rm api python -m app.db.migrate_cli --apply
   docker compose run --rm api python -m app.db.migrate_cli --check
   ```

5. Build and start the services:

   ```sh
   docker compose up -d --build
   ```

6. Check API readiness:

   ```sh
   curl -fsS http://127.0.0.1:8000/health/ready
   ```

Use the actual host bindings and URLs configured in `.env`. Read [DEPLOYMENT.md](DEPLOYMENT.md) before upgrading a live instance. **Do not run `docker compose down -v`** on an installation whose data must be retained.

### Local development

Backend (Python 3.12):

```sh
python -m venv .venv
# Activate the virtual environment for your shell.
pip install -r requirements.txt
cp .env.example .env
python -m app.db.migrate_cli --check
```

The API entry point is `app.api:api`; the bot/application entry point is `python -m app`. A reachable PostgreSQL database and valid local configuration are required for full runtime operation.

Website:

```sh
cd website
npm install
npm run dev
```

The website build command is `npm run build`. Its API base URL and public deployment metadata are supplied through the `VITE_*` build variables documented in `website/Dockerfile` and the Compose configuration.

## Tests and quality checks

Run the Python regression suite from the repository root:

```sh
python -m compileall -q app tests
pytest -q
```

Run the website TypeScript check/build from `website/`:

```sh
npm install
npm test
npm run build
```

Some integration tests require PostgreSQL or deployment services and may need an appropriately configured test environment. A local source-level test pass is not a substitute for staging checks of migrations, concurrent delivery, Telegram interactions, browser rendering, or mobile performance.

## Architecture and change-safety notes

- Preserve the existing service and data-access boundaries. Booking, payment, attendance, lifecycle, and authorization rules belong in backend services and database constraints—not only in button visibility or frontend checks.
- Keep database migrations append-only. Never edit an already-applied migration; add a new migration and maintain compatibility with existing data.
- Keep Telegram callback/FSM contracts and existing API response behavior backward compatible unless a reviewed migration plan explicitly changes them.
- Preserve Persian-first RTL behavior, English content where supported, accessible interactions, and responsive layouts.
- Optimize for older Android devices and slower connections. Avoid large dependencies, unnecessary render work, unbounded caches, and eager loading of nonessential screens/media.
- Keep secrets and real user data out of source files, logs, commits, AI prompts, and shared review packages.

## Useful operational endpoints

- `GET /health` — process liveness.
- `GET /health/db` — database connectivity.
- `GET /health/ready` — readiness, including database connectivity and configured timezone.
- `GET /health/operational` — low-cardinality notification outbox and delivery-failure counters.

See [CONFIGURATION.md](CONFIGURATION.md) for environment variables, [DEPLOYMENT.md](DEPLOYMENT.md) for rollout procedures, [BRAND_GUIDE.md](BRAND_GUIDE.md) for logo usage, and [CHANGELOG.md](CHANGELOG.md) for the current release's implementation scope.
